#!/bin/bash
# for osx 

tempfoo=`basename $0`
TMPFILE=`mktemp /tmp/${tempfoo}.XXXXXX` || exit 1
#hook=$(readlink -n $(git rev-parse --git-dir))/hooks/commit-msg
hook=$(readlink -n .git/hooks/commit-msg)
git filter-branch -f --msg-filter "cat > $TMPFILE; \"$hook\" $TMPFILE; cat $TMPFILE" origin/master..master


