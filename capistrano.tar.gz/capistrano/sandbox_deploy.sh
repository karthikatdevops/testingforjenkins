#!/bin/sh

./mci_deploy.bash \
"com.theplatform.data.tv.ingest.$1" \
"pl-data-tv-ingest-clover-graphs-$1-impl" \
"$2" \
merdevl