#!/bin/bash

for env in merdevl
do
  for jmxType in requestStatistics phaseExecutionStatistics java.lang servers
  do
    echo "cap -f capfile_${env} update_jmxtrans_${env} -S nobom -S jmxstats=${jmxType} -S deploy=true"
    cap -f capfile_${env} update_jmxtrans_${env} -S nobom -S jmxstats=${jmxType} -S deploy=true
  done

done


