# temp cap file for dumping configs as we move to hiera

#
# Example usage:
# 1. write yaml files
#   capistrano$ bundle exec cap -f dump_configs.rb -S svc=imageWebService -S nobom -S write_to_files
#
# 2. compare to yaml files
#   capistrano$ bundle exec cap -f dump_configs.rb -S svc=imageWebService -S nobom 2>/dev/null
# 

require 'yaml'

# use any vars for now
set :env, 'merqaTest104'
raise "Specify :svc" unless exists?(:svc)
set :nobom, true
set :no_hiera_branch_check, true

load 'Capfile'

# get envs that have this task
def svc_envs
  Dir['/etc/hiera/data/nodes/*.yaml'].select { |f|
    f.end_with?('.yaml') && YAML.load_file(f)[svc]
  }.collect { |f|
    f.split('/').last.split('.yaml').first
  }
end

puts svc_envs.inspect
if exists?(:write_to_files)
  cmds = svc_envs.collect { |e|
    "bundle exec cap -S nobom -S no_hiera_branch_check -S env=#{e} -S svc=#{svc} -S dump_config #{e}_#{svc} serviceSpecificConfigUpdates_#{svc} -S write_to_file -S noLog=true &> /dev/null"
  }
  exec_cmds_and_wait(cmds, true)
else
  Dir["working/dump_configs/#{svc}/*.yaml"].each { |f|
    e = f.split('/').last.split('.yaml').first
    cap_vars = YAML.load_file(f)
    set :hiera_env, e
    puts "===== #{e} ====="
    hiera_vars = hiera('ws_properties', :hash)
    in_cap_but_not_hiera = cap_vars.sort - hiera_vars.sort
    in_hiera_but_not_cap = hiera_vars.sort - cap_vars.sort
    puts "---- In Cap but not hiera ---"
    puts in_cap_but_not_hiera.to_yaml
    puts "---- In hiera but not Cap ---"
    puts in_hiera_but_not_cap.to_yaml 
  }
end