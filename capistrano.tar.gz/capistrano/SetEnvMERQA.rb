class SetEnvMERQA
  @fname=String.new
  @uname=String.new
  @idx_tbs=String.new
  @tbl_tbs=String.new
  @ing_uname=String.new
  @ing_idx_tbs=String.new
  @ing_tbl_tbs=String.new
  @changelog=String.new
  @passcode =String.new
  def initialize(ffname,service = nil)
  		      @changelog="CHANGELOG"
  		       @passcode = "xcal09"
			  if ffname.include?  "linear"
			   @uname="DS_LINEAR_MERQA"
			   @idx_tbs="mmws_idx_01"
			   @tbl_tbs="mmws_data_01"
			   @ing_uname="DS_INGEST_LINEAR_MERQA"
			   @ing_idx_tbs="ming_idx_01"
			   @ing_tbl_tbs="ming_data_01"
			  elsif ffname.include?  "offer"
			   @uname="DS_OFFER_MERQA"
			   @idx_tbs="mmws_idx_01"
			   @tbl_tbs="mmws_data_01"
			   @ing_uname="DS_INGEST_OFFER_MERQA"
			   @ing_idx_tbs="ming_idx_01"
			   @ing_tbl_tbs="ming_data_01"
			  elsif ffname.include?  "location"
			   @uname="DS_LOCATION_MERQA"
			   @idx_tbs="mmws_idx_01"
			   @tbl_tbs="mmws_data_01"
			   @ing_uname="DS_INGEST_LOCATION_MERQA"
			   @ing_idx_tbs="ming_idx_01"
			   @ing_tbl_tbs="ming_data_01"
			  elsif ffname.include?  "entity"
			   @uname="DS_ENTITY_MERQA"
			   @idx_tbs="mmws_entity_idx_01"
			   @tbl_tbs="MMWS_ENITITY_DATA_01"
			   @ing_uname="DS_INGEST_ENTITY_MERQA"
			   @ing_idx_tbs="ming_idx_01"
			   @ing_tbl_tbs="ming_data_01"
			  elsif (ffname.include?  "clover-graphs-") || (ffname.include? "ingest-clover-mappings") 
			    #### This is  to identiy  hash schema only
			   @uname="DS_INGEST_HASH_MERQA"
			   @idx_tbs="ming_idx_01"
			   @tbl_tbs="ming_data_01"
			        if ffname.include?  "alg"
			        @changelog=@changelog+"_ALG"
			        elsif ffname.include?  "map"
			        @changelog=@changelog+"_MAP"
			        elsif ffname.include?  "amg"
			        @changelog=@changelog+"_AMG"
			        elsif ffname.include?  "cim"
			        @changelog=@changelog+"_CIM"
			        elsif ffname.include?  "csm"
			        @changelog=@changelog+"_CSM"
			        elsif ffname.include?  "edit"
			        @changelog=@changelog+"_EDIT"    
			        elsif ffname.include?  "id"
			        @changelog=@changelog+"_ID"
			        elsif ffname.include?  "misc"
			        @changelog=@changelog+"_MISC"
			        elsif ffname.include?  "music"
			        @changelog=@changelog+"_MUSIC"
			        elsif ffname.include?  "ncds"
			        @changelog=@changelog+"_NCDS"
			        elsif ffname.include?  "tvg"
			        @changelog=@changelog+"_TVG"
			        elsif ffname.include?  "util"
			        @changelog=@changelog+"_UTIL"
			        end
			  elsif   ffname.include?  "tv-id"  ### THIS IS ID
			   @uname="DS_INGEST_ID_MERQA"
			   @idx_tbs="mid_idx_01"
			   @tbl_tbs="mid_data_01"

			  elsif   ffname.include?  "job"  ### THIS IS job
			   @uname="DS_JOB_MERQA"
			   @idx_tbs="mmws_idx_01"
			   @tbl_tbs="mmws_data_01"
			  end
		end #initialize

	   def get_uname
	    @uname
	   end
	   def get_idx_tbs
	    @idx_tbs
	   end
	    def get_tbl_tbs
	    @tbl_tbs
	   end
	   def get_ing_uname
	    @ing_uname
	   end
	   def get_ing_idx_tbs
	    @ing_idx_tbs
	   end
	    def get_ing_tbl_tbs
	    @ing_tbl_tbs
	   end
	   def get_changelog
	   	@changelog
	   end
	   def get_passcode
	   	@passcode
	   end
end
