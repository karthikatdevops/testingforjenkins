
require 'optparse'
require 'date'
require 'getoptlong'
require 'fileutils'
load "./Wfile.rb"  ### created the .properties file for merqa
load "./Mtag.rb"  ### gets latest  tag from  git repo local
load "./SetEnvMERQA.rb" ### set merqa env variables  by filename in artifactory
load "./get_artifactory_file_name.rb"  ## function to get the url for artifactory file to download

desc"Gets most recent tag"
task "get_tag".to_sym  do
    set :dd,Mtag.new("#{cloneloc}/#{service}DataService")
    set :mytag, dd.getit.chop
    puts " \n The most recent tag for #{service} is #{mytag}"
    puts  "\n . ~/.bash_profile; a=`pwd`; cd #{repobase} ; rm -rf #{cloneloc}\n " 
    system ". ~/.bash_profile; a=`pwd`; cd #{repobase} ; rm -rf #{cloneloc}" 
  end

desc "Download file form artifactory"
task "clone_repo".to_sym do
    case service
    when "id"
      set :reponame, "ingestCloverGraphsId"
    when "alg"
      set :reponame, "ingestCloverGraphsAlgorithmic"
    when "amg"
      set :reponame, "ingestCloverGraphsAmg"
    when "cim"
     set :reponame,"ingestCloverGraphsCim"
    when "csm"
      set :reponame,"ingestCloverGraphsCsm"
    when "edit"
      set :reponame,"ingestCloverGraphsEditorial"
    when "music"
      set :reponame,"ingestCloverGraphsMisc"
    when "tvg"
      set :reponame, "ingestCloverGraphsTvGuide"
    when "ncds"
      set :reponame, "ingestCloverGraphsNcds"
    when "util"
      set :reponame,"ingestCloverGraphsUtil"
    when "misc" 
      set :reponame,"ingestCloverGraphsMisc"
    when "map" 
      set :reponame,"ingestCloverMappings"
    when "ID" 
      set :reponame,"IdDataService"
   when "linear","entity","location","offer","job"
      set :reponame, service+"DataService"
    else
      set :reponame,"ERROR"
    end
    puts "\n cloneloc= #{cloneloc}, user=#{user}, pass=#{pass}"
    puts "\n . ~/.bash_profile;  mkdir -p #{cloneloc} ; cd #{cloneloc}; a=`pwd`; echo $a; git clone https://#{user}:#{pass}@github.comcast.com/merlin/#{reponame}.git #{service}DataService"
    system". ~/.bash_profile;  mkdir -p #{cloneloc} ; cd #{cloneloc}; a=`pwd`; echo $a; git clone https://#{user}:#{pass}@github.comcast.com/merlin/#{reponame}.git #{service}DataService"
    puts "\n Done cloning at #{cloneloc}/#{service}DataService \n"
  end

desc "Set where in artifactory the build .gz file is"
task "set_file".to_sym do
   case service
   when "linear","entity","location","offer"
    set :ll,"http://maven.compass.chalybs.net:8081/artifactory/compass-all-repos/com/theplatform/data/tv/#{service}/pl-data-tv-#{service}-db/#{mytag}/pl-data-tv-#{service}-db-#{mytag}.tar.gz   " 
   when "job"
    set :ll,"http://maven.compass.chalybs.net:8081/artifactory/simple/compass-all-repos/com/theplatform/data/commons/job/pl-data-commons-job-db/#{mytag}/pl-data-commons-job-db-#{mytag}.tar.gz  " 
   when "ID"
    set :ll,"http://maven.compass.chalybs.net:8081/artifactory/compass-all-repos/com/theplatform/data/tv/id/pl-data-tv-id-db/#{mytag}/pl-data-tv-id-db-#{mytag}.tar.gz "
   when "alg","amg","cim","csm","edit","music","tvg","id","ncds","util","misc" 
    set :ll,"http://maven.compass.chalybs.net:8081/artifactory/compass-all-repos/com/theplatform/data/tv/ingest/#{service}/pl-data-tv-ingest-clover-graphs-#{service}-impl/#{mytag}/pl-data-tv-ingest-clover-graphs-#{service}-impl-#{mytag}-db-migration.tar.gz" 
   when "map"
    set :ll,"http://maven.compass.chalybs.net:8081/artifactory/simple/compass-merlin-releases/com/theplatform/data/tv/ingest/pl-data-tv-ingest-clover-mappings/#{mytag}/pl-data-tv-ingest-clover-mappings-#{mytag}.tar.gz "
   else
    set :ll, "error"
   end #case
    puts " \n The file is #{ll} \n "
  end
 desc "Wget .gz file form  artifactory"
  task "download_file".to_sym do
    system " . ~/.bash_profile; wget #{ll} -P ./#{loc}"
  end

desc "Creates jdbc string,and .properties file for the run"
task "prepare_env".to_sym do
    ### GET THE FILE NAME OUT OF URL FOR GUNZIP
    set :fname,ll.split('/').last.delete("\"")
    set :tarf,fname[0..fname.rindex('.')-1]
    system ". ~/.bash_profile; cd ./#{loc}; gunzip -d #{fname}; tar -xvf #{tarf}; \
    chmod 766 ./#{loc}/migrations/bin/migrate "
    find_and_execute_task("prepare_#{env}")
    set :properties,loc+"/migrations/environments/work.properties"
    #prepare info for properties file
    set :gg,SetEnvMERQA.new(fname)
    set :uname,gg.get_uname  
    set :idx_tbs,gg.get_idx_tbs
    set :tbl_tbs,gg.get_tbl_tbs
    set :changelog,gg.get_changelog
    set :passcode,gg.get_passcode
    ### write .properties file
    set :f, File.open("./"+properties, "w")
    set :nf,Wfile.new(jdbc,gg.get_uname,gg.get_passcode,gg.get_idx_tbs,gg.get_tbl_tbs,gg.get_changelog)
    f.puts nf.fill_template
    f.close
    if "#{service}" .eql?("linear") ||"#{service}" .eql?("entity") || "#{service}" .eql?("location")||"#{service}" .eql?("offer")  then
      set :ing_properties,loc+"/migrations/environments/ing_work.properties"
      set :ing_uname,gg.get_ing_uname
      set :ing_idx_tbs,gg.get_ing_idx_tbs
      set :ing_tbl_tbs,gg.get_ing_tbl_tbs
      ## write .ing properties file
      set :ing_f,File.open("./"+ing_properties, "w")
      set :ing_nf,Wfile.new(jdbc,gg.get_ing_uname,gg.get_passcode,gg.get_ing_idx_tbs,gg.get_ing_tbl_tbs,gg.get_changelog)
      ing_f.puts ing_nf.fill_template
      ing_f.close
    end
  end

desc"jdbc for DRYRUN_ING env"
task "prepare_dryrun_ing".to_sym do
### Form JDBC string for host,port and db service_name
    set :hh,"10.253.15.71"
    set :pt,"1521"
    set :svnm,"MerqaING02D"
    set :jdbc,"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="  + hh.to_s + ")(PORT=" + pt.to_s + "))(CONNECT_DATA=(SERVICE_NAME=" + svnm.to_s + ")(SERVER = DEDICATED)))"
    puts "\n JDBC STRING is as following #{jdbc} \n"
end

desc"jdbc for MERQA_ING env"
task "prepare_merqa_ing".to_sym do
  set :hh,"10.251.132.101"
    set :pt,"1521"
    set :svnm,"cmping_dbserv"
    set :jdbc,"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="  + hh.to_s + ")(PORT=" + pt.to_s + "))(CONNECT_DATA=(SERVICE_NAME=" + svnm.to_s + ")(SERVER = DEDICATED)))"
    puts "\n JDBC STRING is as following #{jdbc} \n"
puts "prepare_merqa_ing"
end

desc"jdbc for MERQA_ID env"
task "prepare_merqa_id".to_sym do
  set :hh,"10.151.132.107"
    set :pt,"1521"
    set :svnm,"cmpid_dbserv"
    set :jdbc,"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="  + hh.to_s + ")(PORT=" + pt.to_s + "))(CONNECT_DATA=(SERVICE_NAME=" + svnm.to_s + ")(SERVER = DEDICATED)))"
    puts "\n JDBC STRING is as following #{jdbc} \n"
    puts "prepare_merqa_id"
end

desc"jdbc for DRYRUN_ID env"
task "prepare_dryrun_id".to_sym do
    set :hh,"10.253.15.71"
    set :pt,"1521"
    set :svnm,"MerqaID02D"
    set :jdbc,"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="  + hh.to_s + ")(PORT=" + pt.to_s + "))(CONNECT_DATA=(SERVICE_NAME=" + svnm.to_s + ")(SERVER = DEDICATED)))"
    puts "\n JDBC STRING is as following #{jdbc} \n"
    puts "prepare_dryrun_id"
end

desc"Runs mybatis migrate up command"
task "migrate_up".to_sym do
    pth=Dir.pwd+"/"+loc+"/migrations" 
    if "#{service}" .eql?("linear") ||"#{service}" .eql?("entity") || "#{service}" .eql?("location")||"#{service}" .eql?("offer")  then
    system " . ~/.bash_profile; cd #{loc}/migrations ; \
                a=`pwd`;\
                PATH=$a/bin:$PATH;\
                echo 'bash bin/migrate up --path=#{pth} --env=work'; \
                bash bin/migrate up --path=#{pth} --env=work;\
                echo 'bash bin/migrate up --path=#{pth} --env=ing_work'; \
                bash bin/migrate up --path=#{pth} --env=ing_work"
    else
      system " . ~/.bash_profile; cd #{loc}/migrations ; \
                a=`pwd`;\
                PATH=$a/bin:$PATH;\
                echo 'bash bin/migrate up --path=#{pth} --env=work'; \
                bash bin/migrate up --path=#{pth} --env=work"
    end
  end

desc"Runs mybatis migrate status command"
  task "migrate_status".to_sym do
       pth=Dir.pwd+"/"+loc+"/migrations" 
       if "#{service}" .eql?("linear") ||"#{service}" .eql?("entity") || "#{service}" .eql?("location")||"#{service}" .eql?("offer")  then 
        system " . ~/.bash_profile; cd #{loc}/migrations ; \
                a=`pwd`;\
                PATH=$a/bin:$PATH;\
                echo 'bash bin/migrate status --path=#{pth} --env=work'; \
                bash bin/migrate status --path=#{pth} --env=work;\
                echo 'bash bin/migrate status --path=#{pth} --env=ing_work'; \
                bash bin/migrate status --path=#{pth} --env=ing_work"
       else
                system " . ~/.bash_profile; cd #{loc}/migrations ; \
                a=`pwd`;\
                PATH=$a/bin:$PATH;\
                echo 'bash bin/migrate status --path=#{pth} --env=work'; \
                bash bin/migrate status --path=#{pth} --env=work"
       end
  end

desc"Delete the temp dir  for this run"
  task "cleanup_tmp".to_sym do
        FileUtils.rm_rf(loc)
  end
  
 ##### MAIN STARTS HERE  DS_MIGRATE TASK#########
desc "<<-EOF
    \nThis will download the most recent artifact and  leave it in tmp dir
         \ncap -f db_migrate.rb  db_migrate -s  ser=<service> -s pppp=<password> -s eenv=<env> -s action=<act> -DataService cleanup=<clean>

         
         
         where 
          <service > - repo  entity,linear,offer,job,ID,tvg,map,alg,amg,ncds,tvg,etc.
          <password > - to login to github and  clone repo
          <cleanup> - clean  to delete temp dir after it worked or nill to leave  dir after it is done
          <act> - action for migrate either up or status        
          \n
         Examples:
         \n
         Entity
              cap -f istest_new.rb ds_migrate  -s ser=entity -s pppp=April2015  -s eenv=dryrun_ing -s action=status -S cleanup=clean
           \n 
         Id
              cap -f istest_new.rb ds_migrate  -s ser=ID -s pppp=April2015  -s eenv=dryrun_id -s action=status -S cleanup=clean
          EOF"
task :ds_migrate do 
set :service ,ser
set :pass,pppp
set :env, eenv
now = DateTime.now
set :loc,"tmp#{now.strftime("%Y%m%d%H%M%S")}"
puts "loc = #{loc}"
set :repobase,"~/tmpmine/"  #### Temporary repo for this service location base
set :cloneloc, repobase+loc
set :user, IO.popen ("whoami").gets.chomp 
puts "#{service}"

		 find_and_execute_task("clone_repo")
		 find_and_execute_task("get_tag")
		 find_and_execute_task("set_file")
		 find_and_execute_task("download_file")
		 find_and_execute_task("prepare_env")
  	 case action
     when "status" 
          find_and_execute_task("migrate_status")
          puts "status"
     when "up" 
       find_and_execute_task("migrate_up")
       puts "up"
     else
       find_and_execute_task("migrate_status")
       puts "else part"
     end
		 if cleanup=="clean"
       then
       find_and_execute_task("cleanup_tmp")
     end
end ## ds_migrate







