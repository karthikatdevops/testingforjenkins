#!/Users/istens200/.rbenv/shims/ruby
require 'fileutils'


class Mtag
  @locpath=String.new
  @locmytag=String.new
  def initialize(pft)

    @locpath=pft[0..-1].chomp
     if File.exist?("./naturalTagSort.txt")
         File.delete("./naturalTagSort.txt")
     end
     if File.exist?("./naturalTagSort2.txt")
         File.delete("./naturalTagSort2.txt")
     end
     if File.exist?("./naturalTagSort3.txt")
         File.delete("./naturalTagSort3.txt")
     end
     system". ~/.bash_profile; a=`pwd`; cd #{@locpath}; git fetch;  git tag > ${a}/naturalTagSort.txt"
		 ff= File.open("./naturalTagSort2.txt", "w");
		 File.readlines("./naturalTagSort.txt").each do |line|
        line1=line.gsub('.9-','.09-').gsub('.8-','.08-').gsub('.7-','.07-').gsub('.6-','.06-').gsub('.5-','.05-').gsub('.4-','.04-').gsub('.3-','.03-').gsub('.2-','.02-').gsub('.1-','.01-').gsub('.0-','.00-')
		    line2=line1.gsub('.9.','.09.').gsub('.8.','.08.').gsub('.7.','.07.').gsub('.6.','.06.').gsub('.5.','.05.').gsub('.4.','.04.').gsub('.3.','.03.').gsub('.2.','.02.').gsub('.1.','.01.').gsub('.0.','.00.')
        ff.puts line2
		 end
		 ff.close
     system ". ~/.bash_profile; a=`pwd`;sort  $a/naturalTagSort2.txt  |tail -1 > $a/naturalTagSort3.txt"
     File.open('./naturalTagSort3.txt', 'r') do |f1|  
        while line = f1.gets
        line1=line.gsub('.09-','.9-').gsub('.08-','.8-').gsub('.07-','.7-').gsub('.06-','.6-').gsub('.05-','.5-').gsub('.04-','.4-').gsub('.03-','.3-').gsub('.02-','.2-').gsub('.01-','.1-').gsub('.00-','.0-')
        line2=line1.gsub('.09.','.9.').gsub('.08.','.8.').gsub('.07.','.7.').gsub('.06.','.6.').gsub('.05.','.5.').gsub('.04.','.4.').gsub('.03.','.3.').gsub('.02.','.2.').gsub('.01.','.1.').gsub('.00.','.0.')   
        @locmytag=line2
        end 
     end 
     if File.exist?("./naturalTagSort.txt")
      File.delete("./naturalTagSort.txt")
     end
     if File.exist?("./naturalTagSort2.txt")
      File.delete("./naturalTagSort2.txt")
     end
     if File.exist?("./naturalTagSort3.txt")
     File.delete("./naturalTagSort3.txt")
    end
  end
  def getit
     @locmytag
  end
end # end of class




 
