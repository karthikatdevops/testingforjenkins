#!/bin/bash

# clean out old files before the filesystem fills up
# andrew_diller@comcast.com
# Sep 2012
# v1.3
################################
# v1.4 Nov 2012
####################################
COMMAND='rm -vrf' # what to do with found (older) files in the data-in dirs?
HOMEDIR='/opt/ds/jetty-cloverServer'
NCDSBASE=$HOMEDIR/sandboxes/ncds/data-in
CIMBASE=$HOMEDIR/sandboxes/cim/data-in
DIRROOT=$HOMEDIR/sandboxes
LOGROOT=$HOMEDIR/logs
TEMPROOT=$HOMEDIR/tmp
FEEDKEEPDAYS=10
LOGSKEEPDAYS=5
TMPKEEPDAYS=2

echo '======================================================'
echo 'Running on: ' `date '+%c'`
echo '======================================================'
echo " Cleaning clover sandboxes of files and symlinks "
echo " older than $FEEDKEEPDAYS "


# start a loop for these sandboxes, go in and clean out their data-in dirs
#
for DIR in alg amg id ncds tvg cim music
  do
    echo --------------------------------------------
    echo "Working in : $DIR"
    echo "Path is    : $DIRROOT/$DIR/data-in"
    find $DIRROOT/$DIR/data-in -type f -mtime +$FEEDKEEPDAYS | grep -E '(\.xml|\.zip|\.txt|.csv|\.lst|\.tar\.gz)' | grep -v -E '(collapsed_tags\.txt|controllers\.txt|channel_duplicates\.txt|job-record\.txt|locations_excluded\.txt|search_vips\.txt)' | xargs $COMMAND

#     now go in and remove any invalid symlinks, this tests for any 
#   file that is a symlink not linked to a file, and then removes it
    cd $DIRROOT/$DIR/data-in
    for file in `ls `
      do
        if [ ! -f ${file} ] && [  -L ${file} ]
        then
          echo "%ERROR: ${file} is a symlink to nothing, removing..."
          rm -rf ${file}
        fi
      done
  done

echo '======================================================'
echo " Cleaning Log files over $LOGSKEEPDAYS "
find $LOGROOT -type f -mtime +$LOGSKEEPDAYS -print|xargs $COMMAND

echo '======================================================'
echo " Cleaning jetty tmp files over $TMPKEEPDAYS "
NUMDAYS=3
find $TEMPROOT -type f -mtime +$TMPKEEPDAYS -print|xargs $COMMAND


# clean NCDS date based directories
echo '======================================================'
echo " Cleaning NCDS sandbox of Dated Dirs "
TODAY=`date +%Y%m%d`
if [[ `uname` == "Darwin" ]];
  then  
    TODAY1=`date -j -v-1d +%Y%m%d`
  else
    TODAY1=`date +%Y%m%d -d "1 day ago"`
fi

echo "Today is     : $TODAY"
echo "Yesterday is : $TODAY1"
echo "System is    : `uname`"
# regexp - [0-9]{4}[0-9]{2}[0-9]{2}
REGEX='[0-9]{4}[0-9]{2}[0-9]{2}$'
cd $NCDSBASE

for DIRS in `find . -maxdepth 1 -type d | sed "s|^\./||"`
do
  if [[ ${DIRS} =~ ${REGEX} ]] ; 
    then 
      echo "MatchDateDir---> $DIRS, Today is $TODAY"
      if grep -q "$TODAY" <<< "$DIRS" || grep -q "$TODAY1" <<< "$DIRS" 
        then
          echo "   Keeping: $DIRS"
        else
          echo "   Removing $DIRS"
          rm -rf $BASEDIR/$DIRS
          echo "   Removed $DIRS"
        fi
    else
      echo "$DIRS is not a datedir"
  fi
  echo --------------------------------------------
done


# clean CIM date based directories
echo '======================================================'
echo " Cleaning CIM sandbox of Dated Dirs "
REGEX='[0-9]{4}[0-9]{2}[0-9]{2}$'
cd $CIMBASE

for DIR in `find . -maxdepth 1 -type d -mtime +14 | sed "s|^\./||"`
do
  if [[ ${DIR} =~ ${REGEX} ]] ; then
    echo "* Dated dir older than 14 days: $DIR, I'm going to delete it"
    rm -rf $CIMBASE/$DIR
    echo "** deleted!"
  else
    echo "${DIR} is not a dated DIR, or it's not old enough"
  fi
done


echo '======================================================'
echo    finished all cleanings
echo '======================================================'

echo DONE
exit 0