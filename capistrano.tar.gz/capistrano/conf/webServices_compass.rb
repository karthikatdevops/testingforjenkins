## this file contains common tasks that span all environments and all Compass WS apps.

# what to write in sirius.cluster.config
def get_sirius_config_str
  set :sirius_bulkLoadMode, false unless exists?(:sirius_bulkLoadMode)
  if hiera('static_config')
    sirius_cluster_config = hiera('static_config')
  elsif sirius_bulkLoadMode
    sirius_cluster_config = "/user/sirius"
  else
    # get all other gridWS nodes
    ws_nodes = hiera(hiera_svc, :priority, "nodes/#{hiera_env}")
    other_ws_nodes = ws_nodes.reject { |n| n == hiera_host }
    # use short names?
    if hiera('short_hostnames')
      other_ws_nodes = other_ws_nodes.collect { |n| n.split('.').first }
    end
    akka_lines = other_ws_nodes.collect { |n| "akka://sirius-system@#{n}:2552/user/sirius" }
    sirius_cluster_config = ['/user/sirius', akka_lines].flatten.join("\n")
  end
  sirius_cluster_config
end

[svc].each do |name|

    # Called by "cap dependencies_localListingInfoWebService" or a general deploy task
    desc "called by serviceSpecificConfigUpdates_#{name}"
    task "serviceSpecificConfigUpdates_#{name}".to_sym do

      # hiera migration
      if exists?(:dump_config)
        set :app, "#{name}"
        set :web_port, hiera("#{name}_web_port")
        set :jmx_port, hiera("#{name}_jmx_port")
        set :stop_port, hiera("#{name}_stop_port")
        set :alive_path, hiera("#{name}_alive")
      end

        logger.level = Capistrano::Logger::INFO
        logger.info "Checking configs for #{name}"

       ########################################
       # ACCOUNTCONTENTEVENT  WS SUBSTITUTIONS
       ########################################
       # see hiera
      $accountContentEventWebService_config_overrides = {}

       ########################################
       # AUTH PROXY WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $authProxy_config_overrides = {}

       ########################################
       # CARETAKER WEB SERVICE SUBSTITUTIONS
       ########################################
       # moved to hiera
       $caretakerWebService_config_overrides = {}

       ########################################
       # TRIAGE WEB SERVICE SUBSTITUTIONS
       ########################################
       # moved to hiera
       $triageWebService_config_overrides = {}


	########################################
        # COAT GWT WEB SERVICE SUBSTITUTIONS
        # Note: COAT is not a real WebService Shell, but we are  treating it like one for deployment
        ########################################
        # see hiera
        $coatGWTService_config_overrides = {}

       ########################################
       # CFIG WEB SERVICE SUBSTITUTIONS
       ########################################
       if app == "cfigWebService"
         $cfigWebService_config_overrides = {
           "ws.base.url"                                      => "http://#{cfigVip}:#{hiera('caretakerCfig_web_port')}/#{app}",
           "cfigWebService.ncds.localFileUploadDirectory"     => "/opt/nfs/uploads/dacProdUploads",
           "cfigWebService.ncds.controllersFileDacs"          => "controllers-cfig.txt.prod",
           "cfigWebService.ncds.controllersFileCfig"          => "",
           "cfigWebService.vcw.controllerPollingIsOn"         => "true",
           "cfigWebService.vcw.controllerDownloadIsOn"        => "true",
           "cfigWebService.vcw.controllerPollingSchedule"     => "1 0/5 * * * ?",
           "cfigWebService.vcw.currentControllersFileName"    => "current_controllers.csv",
#           "cfigWebService.vcw.filesDropDirectory"            => "/opt/nfs/feeds/vcw/controllers",
           "cfigWebService.vcw.db.jdbcUrl"                    => "jdbc:oracle:thin:@(DESCRIPTION_LIST=(LOAD_BALANCE=off)(FAILOVER=on)(DESCRIPTION=(CONNECT_TIMEOUT=5)(TRANSPORT_CONNECT_TIMEOUT=3)(RETRY_COUNT=3)(ADDRESS_LIST=(LOAD_BALANCE=on)(ADDRESS=(PROTOCOL=TCP)(HOST=vcw-cmc-p-grid.cmc.co.ndcwest.comcast.net)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=VCW_DR_APPUSER)))(DESCRIPTION=(CONNECT_TIMEOUT=5)(TRANSPORT_CONNECT_TIMEOUT=3)(RETRY_COUNT=3)(ADDRESS_LIST=(LOAD_BALANCE=on)(ADDRESS=(PROTOCOL=TCP)(HOST=vcwdb-ch2-apgrd.sys.comcast.net)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=VCW_DR_APPUSER))))",
           "cfigWebService.vcw.db.driverClass"                => "oracle.jdbc.driver.OracleDriver",
           "cfigWebService.vcw.db.username"                   => "merlin_app",
           "cfigWebService.vcw.db.password"                   => "u8d=idNAnda180Abz",
           "cfigWebService.vcw.db.maxConnectionsPerPartition" => "20",
           "cfigWebService.vcw.db.minConnectionsPerPartition" => "1",
           "cfigWebService.vcw.db.partitionCount"             => "1",
           "cfigWebService.vcw.db.acquireIncrement"           => "1",
           "cfigWebService.filesDropDirectory"                => "/opt/nfs/feeds",
           "cfigWebService.rabbitmq.host"                     => hiera('cfigRabbitHost'),
           "cfigWebService.rabbitmq.port"                     => "#{cfigRabbitPort}",
           "cfigWebService.rabbitmq.username"                 => "#{cfigRabbitUsername}",
           "cfigWebService.rabbitmq.password"                 => "#{cfigRabbitPassword}",
           "cfigWebService.rabbitmq.virtual.host"             => "#{cfigRabbitVhost}" ,
	         "streamsage.host"				                          => "REXWKFL-ch2-01.sys.comcast.net",
	         "streamsage.user"				                          => "merlin",
	         "streamsage.password"			                        => "icPgxeru7KBf2q",
	         "streamsage.localDirecctory"			                  => "${cfigWebService.filesDropDirectory}/streamsage/feeds/rex-browse-rank",
          "cfigWebService.ncds.controllersFileDacs"           => "#{cfigWebService_ncds_controllersFileDacs}" ,
          "cfigWebService.ncds.controllersFileCfig"           => "#{cfigWebService_ncds_controllersFileCfig}" ,
          "cfigWebService.ncds.useUploadFiles"                => "#{cfigWebService_ncds_useUploadFiles}" ,
          "cfigWebService.ncds.proxyHost"                     => "#{cfigWebService_ncds_proxyHost}" ,
          "cfigWebService.ncds.proxyPort"                     => "#{cfigWebService_ncds_proxyPort}" ,
          "csgi.scheduleCronExpression"                       => "0 0 8 * * ?",
         }
	if confType == 'meridkQA'
	  $cfigWebService_config_overrides["ws.base.url"]                          = "http://#{cfigVip}:#{hiera('cfigWebService_web_port')}/#{app}"
          $cfigWebService_config_overrides["cfigWebService.filesDropDirectory"]   =  "/opt/nfs/qa/feeds"
          $cfigWebService_config_overrides["cfigWebService.ncds.localFileUploadDirectory"]   =  "/opt/nfs/qa/feeds/dacPushedfromRed"
          $cfigWebService_config_overrides["cfigWebService.ncds.controllersFileDacs"]   =  "controllers-dummy-generated-from-script"
	end
       end # app == "cfigWebService"

       ########################################
       # CFIG DEV WEB SERVICE SUBSTITUTIONS
       ########################################
       if app == "cfigdevWebService"
         $cfigdevWebService_config_overrides = {
          "ws.base.url"                                      => "http://#{cfigdevVip}:#{hiera('cfigdevWebService_web_port')}/#{app}",
          "ws.instance.name"                                 => "cfigdevWebService",
          "cfigWebService.ncds.localFileUploadDirectory"     => "/opt/nfs/uploads/dacUploads",
          "cfigWebService.ncds.controllersFileDacs"          => "controllers-cfig-dacs.txt.dev",
          "cfigWebService.ncds.controllersFileCfig"          => "controllers-cfig-in-cfig.txt.dev",
          "cfigWebService.vcw.controllerPollingIsOn"         => "true",
          "cfigWebService.vcw.controllerDownloadIsOn"        => "true",
          "cfigWebService.vcw.controllerPollingSchedule"     => "1 0/5 * * * ?",
          "cfigWebService.vcw.currentControllersFileName"    => "current_controllers.csv",
          "cfigWebService.vcw.db.jdbcUrl"                    => "jdbc:oracle:thin:@(DESCRIPTION_LIST=(LOAD_BALANCE=off)(FAILOVER=on)(DESCRIPTION=(CONNECT_TIMEOUT=5)(TRANSPORT_CONNECT_TIMEOUT=3)(RETRY_COUNT=3)(ADDRESS_LIST=(LOAD_BALANCE=on)(ADDRESS=(PROTOCOL=TCP)(HOST=vcw-cmc-p-grid.cmc.co.ndcwest.comcast.net)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=VCW_DR_APPUSER)))(DESCRIPTION=(CONNECT_TIMEOUT=5)(TRANSPORT_CONNECT_TIMEOUT=3)(RETRY_COUNT=3)(ADDRESS_LIST=(LOAD_BALANCE=on)(ADDRESS=(PROTOCOL=TCP)(HOST=vcwdb-ch2-apgrd.sys.comcast.net)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=VCW_DR_APPUSER))))",
          "cfigWebService.vcw.db.driverClass"                => "oracle.jdbc.driver.OracleDriver",
          "cfigWebService.vcw.db.username"                   => "merlin_app",
          "cfigWebService.vcw.db.password"                   => "u8d=idNAnda180Abz",
          "cfigWebService.vcw.db.maxConnectionsPerPartition" => "5",
          "cfigWebService.vcw.db.minConnectionsPerPartition" => "1",
          "cfigWebService.vcw.db.partitionCount"             => "1",
          "cfigWebService.vcw.db.acquireIncrement"           => "1",
          "cfigWebService.filesDropDirectory"                => "/opt/nfs/dev/feeds",
          "cfigWebService.rabbitmq.host"                     => hiera('cfigRabbitHost'),
          "cfigWebService.rabbitmq.port"                     => "#{cfigRabbitPort}",
          "cfigWebService.rabbitmq.username"                 => "#{cfigRabbitUsername}",
          "cfigWebService.rabbitmq.password"                 => "#{cfigRabbitPassword}",
          "cfigWebService.rabbitmq.virtual.host"             => "#{cfigRabbitVhost}" ,
          "streamsage.host"                                  => "#{streamsage_host}" ,
          "streamsage.user"                                  => "#{streamsage_user}" ,
          "streamsage.password"                              => "#{streamsage_password}" ,
	        "streamsage.localDirecctory"			          => "${cfigWebService.filesDropDirectory}/streamsage/feeds/rex-browse-rank",
          "cfigWebService.ncds.controllersFileDacs"   => "#{cfigWebService_ncds_controllersFileDacs}" ,
          "cfigWebService.ncds.controllersFileCfig"   => "#{cfigWebService_ncds_controllersFileCfig}" ,
          "cfigWebService.ncds.useUploadFiles"        => "#{cfigWebService_ncds_useUploadFiles}" ,
          "cfigWebService.ncds.proxyHost"             => "#{cfigWebService_ncds_proxyHost}" ,
          "cfigWebService.ncds.proxyPort"             => "#{cfigWebService_ncds_proxyPort}" ,
          "csgi.scheduleCronExpression"               => "0 0 9 * * ?",
          # these are set only in dev, the default works in all other env (not capified)

         }
       end # app == "cfigdevWebService"

       ########################################
       # CONSISTENCY WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $consistencyWebService_config_overrides = {}

       ########################################
       # FEEDGEN WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $feedgenWebService_config_overrides = {}

       ########################################
       # COMBINE WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $combineService_config_overrides = {}
       ########################################
       # CACHEPROFILE WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $cacheProfileWebService_config_overrides = {}

       ########################################
       # GRACENOTE COMBINE WEB SERVICE SUBSTITUTIONS
       ########################################
       $gracenoteCombineService_config_overrides = {}

       ########################################
       # GRID WEB SERVICE SUBSTITUTIONS
       ########################################
       if app == "gridWebService"
          
          $gridWebService_config_overrides = {}
         
         # adjust config for bulk load
         set :sirius_bulkLoadMode, false unless exists?(:sirius_bulkLoadMode)
         if sirius_bulkLoadMode == true
           # remove bulk files otherwise this won't work
           run "rm -rf /opt/ds/sirius/gridWebService"
           $gridWebService_config_overrides["sirius.bulkLoadPoolSize"] = "8"
           $gridWebService_config_overrides["sirius.bulkLoadMode"]     = "true"
         else
           $gridWebService_config_overrides["sirius.bulkLoadMode"]     = "false"
         end

         # write sirius.cluster.config
         upload(StringIO.new(get_sirius_config_str),"#{basedir}/jetty-#{app}/config/sirius.cluster.config", :via => :scp, :mode => 0664)

         # make directories
         run "mkdir -p #{basedir}/sirius"
         run "rm -fr #{basedir}/sirius/gridWebService" if hiera('sirius_test_mode')

         # copy bulk file from before and untar
         if exists?(:bootstrap)
           run "mkdir -p #{basedir}/sirius/gridWebService"
           set_vars_from_hiera(['sirius_log_file'])
           run "if [ -e \"#{sirius_log_dir}/#{sirius_log_file}\" ]; then cd #{basedir}/sirius/gridWebService; rm -fr *; cp #{sirius_log_dir}/#{sirius_log_file} .;  tar xzvf *; rm -fr *.gz; else echo \"Cannot find file #{sirius_log_file} in #{sirius_log_dir}\"; fi"
         end
       end #app == "gridWebService"

       ########################################
       # IMAGE WEB SERVICE SUBSTITUTIONS
       ########################################
       # moved to hiera
       $imageWebService_config_overrides = {}
       messagePreference = hiera('messagePreference')
       if messagePreference == "bulk+incremental"
         $imageWebService_config_overrides["imageWebService.entity.api.message.processing.enabled"] = "false"
         $imageWebService_config_overrides["imageWebService.linear.api.message.processing.enabled"] = "false"
         $imageWebService_config_overrides["imageWebService.menu.api.message.processing.enabled"] = "false"
         $imageWebService_config_overrides["imageWebService.menu.message.processing.enabled"] = "true"
         $imageWebService_config_overrides["imageWebService.linear.message.processing.enabled"] = "true"
         $imageWebService_config_overrides["imageWebService.entity.message.processing.enabled"] = "true"
       elsif messagePreference == "api"
         $imageWebService_config_overrides["imageWebService.entity.api.message.processing.enabled"] = "true"
         $imageWebService_config_overrides["imageWebService.linear.api.message.processing.enabled"] = "true"
         $imageWebService_config_overrides["imageWebService.menu.api.message.processing.enabled"] = "true"
         $imageWebService_config_overrides["imageWebService.menu.message.processing.enabled"] = "false"
         $imageWebService_config_overrides["imageWebService.linear.message.processing.enabled"] = "false"
         $imageWebService_config_overrides["imageWebService.entity.message.processing.enabled"] = "false"
       end

       ########################################
       # IMAGE MANAGEMENT WS SUBSTITUTIONS
       ########################################
       # see hiera
       $imageManagementWebService_config_overrides = {}

       ########################################
       # IMAGE EVENT WS SUBSTITUTIONS
       ########################################
       # see hiera
       $imageEventWebService_config_overrides = {}

       ########################################
       # IMAGE EVENT WS SUBSTITUTIONS
       ########################################
       # see hiera
       $imageSelectorWebService_config_overrides = {}

       ########################################
       # IMAGE REPORTS VIEWER SUBSTITUTIONS
       ########################################
       # see hiera
       $imageReportsViewer_config_overrides = {}

       ########################################
       # INGEST WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $ingestWebService_config_overrides = {}

       ########################################
       # INGESTROVI SUBSTITUTIONS
       ########################################
       # see hiera
       $ingestRovi_config_overrides = {}
	
	     ###################################
       # INGESTTMS SUBSTITUTIONS
       ########################################
       # see hiera
       $ingestTms_config_overrides = {}

       ########################################
       # LOCAL LISTING INFO WEB SERVICE SUBSTITUTIONS
       ########################################
       # moved to hiera
       $localListingInfoWebService_config_overrides = {}

       ########################################
       # MATCH WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $matchWebService_config_overrides = {}

       ########################################
       # MMM WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $mmmWebService_config_overrides = {}

       ########################################
       # MMP WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $mmpWebService_config_overrides = {}

       ########################################
       # OFFER WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $offerWebService_config_overrides = {}

        ########################################
       # PARTNERINGEST WEB SERVICE SUBSTITUTIONS
       ########################################
       $partnerIngestWebService_config_overrides = {}
       
	 ########################################
       # SCHEDULED TASK  WEB SERVICE SUBSTITUTIONS
       ########################################
	$scheduledTaskWebService_config_overrides = {}
       
	########################################
       # PERSONA INGEST WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $personaIngestWebService_config_overrides = {}

       ########################################
        # REAT GWT WEB SERVICE SUBSTITUTIONS
        # Note: REAT is not a real WebService Shell, but we are treating it like one for deployment
        ########################################
        # moved to hiera
        if app == "reatGWTService"
          check_my_dir(hiera('reatImagesBase'))
          $reatGWTService_config_overrides = {}
        end

       ########################################
       # SCHEDULED INGEST WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $scheduledIngestWebService_config_overrides = {}

       ########################################
       # SEARCH UPDATER 2 WEB SERVICE SUBSTITUTIONS
       ########################################
       # see hiera
       $searchUpdaterWebService2_config_overrides = {}

	     $sportsIngestWebService_config_overrides = {}

       ########################################
       # UDB MOCK SERVICE SUBSTITUTIONS
       ########################################
       $udbMockService_config_overrides = {}

       # hiera migration
       if exists?(:dump_config)
         config = eval("$#{app}_config_overrides")
         yaml_dir = ['working', 'dump_configs', svc].join('/')
         yaml_file = [yaml_dir, '/', env, '.yaml'].join
         if exists?(:write_to_file)
           FileUtils::mkdir_p yaml_dir
           File.open(yaml_file, 'w') {|f| f.write(config.to_yaml) }
         else
           puts "will compare to yaml file"
         end
         # exit, do not go further
         exit 0
       end

    end # "serviceSpecificConfigUpdates_#{name}".to_sym do

    desc "called by #{env}_#{name} in #{env}.rb"
     task "#{name}_main_#{env}".to_sym do
       logger.level = Capistrano::Logger::INFO
       
       set :app, "#{name}"

       if exists?(:noBom) or exists?(:nobom)
         #set :skipWriteServiceVersion, "true"
         logger.info "skipping read bom"
       else
         check_service_version
         read_bom
       end

       set :web_port, hiera("#{name}_web_port")
       set :jmx_port, hiera("#{name}_jmx_port")
       set :stop_port, hiera("#{name}_stop_port")
       set :alive_path, "#{app}/management/alive"

       # backup properties file?
       if hiera("backup_properties_file")
         run "cp #{basedir}/jetty-#{app}/config/DS_Configuration.properties #{tmpdir}/#{svc}_DS_Configuration.properties || true"
       end

       if exists?(:cleanServer) && cleanServer.to_s == "true"
         logger.info "clean installing #{app}"
         stop_jetty
         # special line for fixing gridWS - use "-S cleanGridWebService" when wanting to clean index and data files"
         run "rm -rf /opt/ds/sirius/gridWebService" if exists?(:cleanGridWebService)
         removeApp
         check
       else
         check
         stop_jetty
       end

       if jetty_version.match(/^9/)
         find_and_execute_task("jettyrealm#{name}")
       end
       find_and_execute_task("jettywrapper#{name}")
       find_and_execute_task("initd#{name}")
# Do special stuff here for MICE (for now)
# These exceptions are for special services that need jetty
# but not a bunch of other things we do for web services
       if app == "miceGWTService"
        set :alive_path, "#{app}"
        logger.info "**** In GWT exclusion zone, deploying the war ball"
        run "cd #{basedir}/jetty-#{app}/work ; rm -rf * "
        logger.info "Just cleaned out the #{basedir}/jetty-#{app}/work directory for #{app}"
        begin
            run "cd #{basedir}/jetty-#{app}/webapps ; wget #{wget_params} \"#{url}\" -O #{app}.war "
        rescue
            logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
            `wget #{wget_params} \"#{url}\" -O working/#{app}.war`
            upload("working/#{app}.war","#{basedir}/jetty-#{app}/webapps/#{app}.war", :via => :scp)
        end

        if exists?(:noBom) or exists?(:nobom)
          set :skipWriteServiceVersion, "true"
          logger.info "skipping read bom"
        else
          write_service_version
        end

        # We still need a logback stuff set up
        logger.info "About to start logback deployment"
        # Note-- we aren't going to call createLogback, but instead call createLogback_mice which does the same, but
        # omits the copy_pl_logging_extensions step, which is special for services that have code from TP
        createLogback_mice
        logger.info "Finished logback deployment"
       else
         find_and_execute_task("copy_#{name}_#{env}")
         find_and_execute_task("prepare_#{name}_#{env}")
       end
         if exists?(:do_not_start) && do_not_start == true
           logger.info "not starting b/c :do_not_start == true"
         else
           start_jetty
           if app == "feedgenWebService"
             logger.info "starting up service monitoring for feedgenWebService..."
             find_servers(:role => :feedgenWebServiceWebHosts).each do |h|
               op5_api_client.enable_service("Feedgen", h.to_s)
               if ( h.to_s.split('.')[1] == 'br' ) and ( confType != 'merbrocIngest' )
                 other_op5_api_client = Op5ApiClient.new(self, 'merbrocIngest', logger)
                 other_op5_api_client.enable_service("Feedgen", h.to_s)
               end
             end
           end
# Changing this to skip alive checks in GBENV for CI set value in cap to skip alives
#           alive
           if exists?(:skip_alive)
            logger.info ">>>>>>>>>>>>>>>>>>>>>>>>**** skip_alive set, skipping alive checks"
          else
            logger.info "Running alive check.."
          end
           alive unless exists? :skip_alive
           get_ver
         end
       end

       task "updateConfigAndRestart_#{name}".to_sym do
         logger.level = Capistrano::Logger::INFO
         find_and_execute_task("hosts_file_override_#{name}") if exists?(:hosts_file_overrides)

         find_and_execute_task("#{env}_#{name}")

         run_serially_in_batches(:find_server_opts => {:roles => "#{name}".to_sym}) do |server_options|
           set :app, "#{name}"
           set :jetty_wrapper_path, "#{basedir}/jetty-#{app}/jetty-wrapper.sh"
           set :web_port, hiera("#{name}_web_port")
           set :jmx_port, hiera("#{name}_jmx_port")
           set :stop_port, hiera("#{name}_stop_port")
           set :alive_path, hiera("#{name}_alive")
           stop_jetty
           if jetty_version.match(/^9/)
             find_and_execute_task("jettyrealm#{name}")
           end
           find_and_execute_task("jettywrapper#{name}")
           find_and_execute_task("initd#{name}")
           find_and_execute_task("prepare_#{name}_#{env}")
           if exists?(:do_not_start) && do_not_start == true
             logger.info "not starting b/c :do_not_start == true"
           else
             start_jetty
             alive
             get_ver
           end
         end
       end # task "updateConfigAndRestart_#{name}".to_sym do

     desc "called by install_jetty"
      task "install_jetty_#{name}".to_sym do
        logger.info "TASK: Entered install_jetty_#{name} in webServices_compass.rb"
       
       jetty_install("#{name}", "#{jetty_version}")
       logger.info "Moving the old bdb to new jetty #{jetty_version} bdb...."
       #run "old_bdb_dir=`find #{basedir}/**/ -name bdb | grep #{name} | grep -e '[0-9]\\+\\.[0-9]\\+\\.[0-9]\\+\\/bdb' | grep -v #{jetty_version} | sort -t- -k3 | tail -1`; echo \"Found old bdb in \$old_bdb_dir \""
       run "old_bdb_dir=\`find #{basedir}/**/ -name bdb | grep #{name} | grep -e '[0-9]\\+\\.[0-9]\\+\\.[0-9]\\+\\/bdb' | grep -v #{jetty_version} | sort -t- -k3 | tail -1\`;\
       echo \"Found old bdb in \$old_bdb_dir \"; \
       if [ -d \"\$old_bdb_dir\" ]; then \
         old_jetty_version=\`echo \$old_bdb_dir | cut -d '-' -f3 | cut -d '/' -f1\`; \
         echo \"Found old jetty version \$old_jetty_version\"; \
         if [ -n \"\$old_jetty_version\" ] && [ \"\$old_jetty_version\" != \"#{jetty_version}\" ]; then\
            mv \$old_bdb_dir #{basedir}/jetty-#{name}/; \
         fi;\
       fi"
       logger.info "Moved the old bdb to new jetty #{jetty_version} bdb...."
       #end
      end

     desc "used to deploy #{name}"
        task "deploy_#{name}_#{env}".to_sym do
          find_and_execute_task("hosts_file_override_#{name}") if exists?(:hosts_file_overrides)
          find_and_execute_task("#{env}_#{name}")
          run_serially_in_batches({
            :find_server_opts => {:roles => "#{name}".to_sym}, 
            :run_on_first_host => (exists?(:sirius_bulkLoadMode) && sirius_bulkLoadMode == true)
          }) do |server_options|
            # run main task
            find_and_execute_task ("#{name}_main_#{env}")

            # possibly deploy matchbox
            if (app == "caretakerWebService")
              find_and_execute_task("deploy_matchbox") 
              run "find #{basedir}/caretakerWS_outputFiles/ -type f -mtime +15 -exec rm {} \\;"
              logger.info ">>>> -- bootstrapping (copying) outputfiles back into caretaker matchbox for this deployment....."
#              run "cp -pf #{basedir}/caretakerWS_outputFiles/* #{basedir}/jetty-#{app}/matchbox/outputFiles"
              run " files=(#{basedir}/caretakerWS_outputFiles/*); if [ ${#files[@]} -gt 0 ]; then cp -pf #{basedir}/caretakerWS_outputFiles #{basedir}/jetty-#{app}/matchbox/outputFiles; else echo \"Cannot find files in caretakerWS_outputFiles\"; fi; true"
            end
          end
            logger.info "TASK: FINISHED---- deploy_#{svc}_#{env} in webServices_compass.rb"
        end


    desc "called by #{name}_main_#{env}"
    task "copy_#{name}_#{env}".to_sym do
        logger.info "TASK: Entered copy_#{name}_#{env} in webServices_compass.rb"

        if variables[:localUrl]
            # If we're using a local file, there is nothing to wget
            logger.info "BEGIN: install service inside webServices_compass.rb"
            logger.info " using a localUrl: #{localUrl}"
            # remove contents of tmpdir
            run "rm -rf #{tmpdir}/#{name}"
            run "mkdir -p #{tmpdir}/#{name}"
            logger.info " Upload the tarball to the server"
            upload("#{localUrl}","#{tmpdir}/#{name}.tar.gz", :via => :scp)
            logger.info " Unpack the tarball on the server"
            run "cd #{tmpdir}/#{name} && tar -zxf ../#{name}.tar.gz"
            logger.info " Clean up by removing the tarball from the server"
            run "rm -rf #{tmpdir}/#{name}.tar.gz"
        else
            # Without a localUrl, we will do a wget
            set(:url) do
                Capistrano::CLI.ui.ask "Enter URL to tar.gz file:"
            end unless variables[:url]
            # remove contents of tmpdir
            run "rm -rf #{tmpdir}/#{name}"
            run "mkdir -p #{tmpdir}/#{name}"
            logger.info "BEGIN: install service inside webServices_compass.rb"
            logger.info " attempting to wget #{url}"
            logger.info " using cmd: wget #{wget_params} \"#{url}\" -O- | tar -zxpf -"
            # grab the zip file, unzip it, and mv it to a meaningful name
            # web_params is in global.rb line ~206
            begin
                run "cd #{tmpdir}/#{name} && . ~/.bash_profile ; wget #{wget_params} \"#{url}\" -O- | tar -zxpf -"
            rescue
                logger.info "MARK:190 failing back to a local wget and scp up to the server, this will take a bit more time..."
                `wget #{wget_params} \"#{url}\" -O working/#{name}.tar.gz`
                upload("working/#{name}.tar.gz","#{tmpdir}/#{name}.tar.gz", :via => :scp)
                run "cd #{tmpdir}/#{name} && tar -zxf ../#{name}.tar.gz"
                logger.info " Clean up by removing the tarball from the server"
                run "rm -rf #{tmpdir}/#{name}.tar.gz"
            end
        end # if variables[:localUrl]

        # if you're setting "noBom", then don't go through the bom related tasks
        if exists?(:noBom) or exists?(:nobom)
            #set :skipWriteServiceVersion, "true"
            logger.info "skipping write_service_version"
            puts "I have no BOM-- guessing what version of service I have using regex"
            if variables[:localUrl]
                puts "My package is :#{localUrl}... so, I can't really guess my version from this"
                puts " since the package name could be anything.  Just putting 'localUrl' as the version string"
                run "echo #{localUrl} > #{basedir}/jetty-#{app}/version.txt"
            else
                puts "My package is :#{url}"
                myNoBomVersion = url.gsub(/-package.tar.gz.*/, "")
                myNoBomVersion = myNoBomVersion.gsub(/.*\//, "")
                puts "#{myNoBomVersion}"
                run "echo #{myNoBomVersion} > #{basedir}/jetty-#{app}/version.txt"
            end
        else
            write_service_version
        end

        run "mv #{tmpdir}/#{name}/capistrano/* #{tmpdir}/#{name}"
        # clean out the working directory
        run "rm -rf #{basedir}/jetty-#{app}/work/*"
        # cp the war and logback.xml into place
        run "cp #{tmpdir}/#{name}/war/*.war #{basedir}/jetty-#{app}/webapps/#{app}.war"

        logger.info " if this gridWebService copy config files. app is #{app}"
        if app == "gridWebService"
            logger.info " attempting to cp #{tmpdir}/#{name}/config/* #{basedir}/jetty-#{app}/config/"
            run "cp #{tmpdir}/#{name}/config/* #{basedir}/jetty-#{app}/config/"
        end

        # begin cramming jars in the war file
#        if splunkLogging == true
        if splunkLogging
          run "cd #{basedir}/jetty-#{app}/webapps && unzip #{context_path}.war -d temp"
          run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && wget #{wget_params}  #{repo}/splunkJavaLogging/0.3.0/splunk.jar" unless app.include?("triageWebService") || app.include?("ingestStagingWebService")
          run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && wget #{wget_params}  #{repo}/splunkJavaLogging/0.3.0/splunklogging.jar"
          run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && wget #{wget_params}  #{repo}/splunkJavaLogging/0.3.0/splunk-sdk.jar"
          unless jetty_version.match(/^8/) || jetty_version.match(/^9/)
            run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && rm -f logback-classic-0.9.24.jar && wget #{wget_params} #{repo}/logback/#{logback_version}/logback-classic-#{logback_version}.jar -O logback-classic-0.9.24.jar"
            run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && rm -f logback-core-0.9.24.jar && wget #{wget_params} #{repo}/logback/#{logback_version}/logback-core-#{logback_version}.jar -O logback-core-0.9.24.jar"
            run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && rm -f pl-management-trace-1.1.0.jar && wget #{wget_params} #{repo}/logback/pl-management-trace-1.1.3.jar -O pl-management-trace-1.1.0.jar"
          end
          run "cd #{basedir}/jetty-#{app}/webapps/temp && zip -r #{context_path} *"
          run "cd #{basedir}/jetty-#{app}/webapps && mv temp/#{context_path}.zip ./#{context_path}.war && rm -rf ./temp"
        end
        # cp ROOT dir into place if available
        run "if [ -e #{tmpdir}/#{name}/ROOT ]; then cp -rp #{tmpdir}/#{name}/ROOT #{basedir}/jetty-#{app}/webapps/ ; fi"

        # If we're production, we don't populate certificates this way (we do it another way)
        run "if [ -e #{tmpdir}/#{name}/resources ]; then cp -rp #{tmpdir}/#{name}/resources/* #{basedir}/jetty-#{app}/resources ; fi"
        # if there is an environment config for this env use it otherwise use "test"
        logger.info "Using test.properties as a base"
        # First, we need to determine if we're DSS 2.5 or greater
        run "if [ -e #{tmpdir}/#{name}/config/test.properties ]; then cp #{tmpdir}/#{name}/config/test.properties #{basedir}/jetty-#{app}/config/DS_Configuration.properties ; fi"
        run "if [ ! -e #{tmpdir}/#{name}/config/test.properties ]; then ls -1 #{tmpdir}/#{name}/config/* | grep -i test_config | xargs -i cp {} #{basedir}/jetty-#{app}/config/DS_Configuration.xml ; fi"

	run "if [ `ls #{tmpdir}/#{name}/config/*.drl 2> /dev/null | wc -l` != 0 ]; then cp #{tmpdir}/#{name}/config/*.drl #{basedir}/jetty-#{app}/config/. ; fi"
        # If we're udbMock service, there's a copy needed
        run "if [ -e #{tmpdir}/#{name}/udbmocksql/schema.sql ]; then mkdir -p #{basedir}/jetty-#{app}/udbmocksql ; cp #{tmpdir}/#{name}/udbmocksql/schema.sql #{basedir}/jetty-#{app}/udbmocksql/schema.sql; fi"
        logger.info "TASK: FINISHED---- copy_#{name}_#{env} in webServices_compass.rb"
    end # task "copy_#{name}_#{env}".to_sym do


   desc "called by #{name}_main_#{env}"
   task "prepare_#{name}_#{env}".to_sym do
     logger.info "TASK: Entered prepare_#{name}_#{env} file manipulations in dataServices_compass.rb"

     logger.info "About to start logback deployment for jetty version #{jetty_version}"
     if jetty_version.match(/^8/) || jetty_version.match(/^9/)
         createLogback_jetty8
     else
         createLogback
     end
     logger.info "Finished logback deployment"

     #########################
     # GENERAL SUBSTITUTIONS
     #########################
     # First, we need to determine if we're DSS 2.5 or greater
     #grab the zip file, unzip it, and mv it to a meaningful name
     dssversion=""
     begin
       download("#{basedir}/jetty-#{app}/config/DS_Configuration.xml","working/Configuration.#{ENV['HOSTS']}.#{name}.current", :via => :scp)
       logger.info "just pulled the DS_Configuration.xml from jetty-#{app} in webServices_compass.rb"
       dssversion="2.4"
     rescue
       dssversion="2.6"
     end
     if dssversion=="2.6"
       logger.info "================================="
       logger.info "DSS "+dssversion
       logger.info "================================="

       # Make trace Log directories
       run "mkdir -p #{basedir}/jetty-#{name}/logs/trace"
       run "chmod 775 #{basedir}/jetty-#{name}/logs/trace"

       ########################################
       # GENERIC DATA SERVICE SUBSTITITIONS
       ########################################
       global_config_overrides = hiera('ws_properties', :hash)
       global_config_overrides["service.allowedHostNames"] =  "#{ENV['HOSTS']}," + global_config_overrides["service.allowedHostNames"]

       unless hiera('ds_read_only')
         global_config_overrides["cluster.multicast.address"] = generate_cluster_address('ds', hiera('cluster_name'))
       end

       find_and_execute_task("serviceSpecificConfigUpdates_#{name}")

       #####################
       # SUBSTITUTION MAGIC
       #####################
       # Start with a blank regex string
       regex=""
       regex_commented=""

       begin
         eval("global_config_overrides.merge($#{app}_config_overrides)").each do |key, value|
           escaped_key, escaped_value = escape(key), escape(value.to_s)
           regex = regex + "s/^\s*#{escaped_key}=.*/#CAPIFIED\n#{escaped_key}=#{escaped_value}/g ; "
           regex_commented = regex_commented + "s/^\s*#\s*#{escaped_key}=.*/\#CAPIFIED\n\##{escaped_key}=#{escaped_value}/g ; "
         end
       rescue NameError => e
         logger.info "had no override definition exists with the name #{e.name}... creating a dummy one now"
         eval("#{e.name} = Hash.new")
         retry
       end

       # Perform the substitution
       run "perl -pi -e '#{regex}' #{basedir}/jetty-#{app}/config/DS_Configuration.properties"
       run "perl -pi -e '#{regex_commented}' #{basedir}/jetty-#{app}/config/DS_Configuration.properties"
       run "perl -pi -e 's/(.*password=.*)\\\\(.*)/$1\\\\\\\\$2/' #{basedir}/jetty-#{app}/config/DS_Configuration.properties"

       # compare to old properties file?
       if hiera("backup_properties_file")
         logger.info "DIFF to old properties file:"
         run "diff #{basedir}/jetty-#{app}/config/DS_Configuration.properties #{tmpdir}/#{svc}_DS_Configuration.properties || true"
       end

     ######################
     # END OF DSS 2.6 CODE
     ######################
     elsif dssversion=="2.4" && app == "udbMockService"

       # udbMockService is Spring 3.0.  Global "xml_SearchReplaceContent" functions fail right away, since config files are messed up

       logger.info "================================="
       logger.info "DSS "+dssversion
       logger.info "================================="

       key = "<jdbc:script location=\"SUBSTITUTED_BY_CAPISTRANO\"></jdbc:script>"
       key = key.gsub(/\./, "\\.")
       key = key.gsub(/\-/, "\\-")
       key = key.gsub(/\,/, "\\,")
       key = key.gsub(/\//, "\\/")
       value = "<jdbc:script location=\"file:#{basedir}/jetty-#{app}/udbmocksql/schema.sql\"></jdbc:script>"
       value = value.gsub(/\./, "\\.")
       value = value.gsub(/\-/, "\\-")
       value = value.gsub(/\,/, "\\,")
       value = value.gsub(/\//, "\\/")
       regex = "s/#{key}/#{value}/g ; "
       run "perl -pi -e '#{regex}' #{basedir}/jetty-#{app}/config/DS_Configuration.xml"

     elsif dssversion=="2.4" && app != "udbMockService"

       logger.info "================================="
       logger.info "DSS "+dssversion
       logger.info "================================="

       exit 1;

     end # dssversion=="2.4"

   end # task "prepare_#{name}_#{env}".to_sym do

end #end Services iteration block

logger.info ">>>>> loaded webServices_compass"
