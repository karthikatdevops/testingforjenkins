liferay_portlets = [
			    'maxPortlet',
			    'editorialCollectionPortlet',
			    'vampPortlet',
			    'queryBuilder',
]

set :liferay_version, "6.0.6"

set :default_web_port, "8080"
set :default_stop_port, "8005"

["liferay"].each do |name| 
  desc "Start Liferay"
  task "start_liferay".to_sym do
    logger.info "Starting Liferay................"
    run "/etc/init.d/liferay start; sleep 60;"
    logger.info "Liferay is started successfully."
  end
  
  desc "Stop Liferay and related java process"
  task "stop_liferay".to_sym do
    logger.info "Stopping Liferay................"
    run "LIFERAY_PID=`ps -aef | grep liferay | grep -v grep |  awk '{print \$2}'| uniq`; if [ -n \"$LIFERAY_PID\" ]; then sudo /etc/init.d/liferay stop; sleep 5; LPID=`ps -aef | grep $LIFERAY_PID | grep -v grep |  awk '{print \$2}' | uniq`; if [ -z \"$LPID\" ]; then sudo kill -9 $LPID; fi;fi"
    run "pid=`sudo lsof -i :#{web_port} | grep java | awk '{print $2}' | uniq`;  if [ -n \"$pid\" ]; then sudo kill -9 $pid || true; fi"
    run "pid=`ps -ef | grep liferay | grep -v grep | awk '{print $2}' | uniq`; if [ -n \"$pid\" ]; then sudo kill -9 $pid || true; fi"      
    logger.info "Liferay is stopped successfully."  
  end
  
  desc "Cleanup liferay portlets"
  task "cleanup_liferay".to_sym do
    logger.info "Cleanup Liferay............."
    liferay_portlets.each { |portlet_name|
      aid=portlet_name.gsub(/([A-Z])/,'-\1').strip.downcase
      run "sudo rm -fr #{liferay_dir}/tomcat-*/webapps/#{aid}"
      run "sudo rm -fr #{liferay_dir}/tomcat-*/temp"
      run "sudo rm -fr #{liferay_dir}/tomcat-*/work/localhost/#{aid}"    
    }
    run "if [ -f \"#{liferay_dir}/tomcat-*/logs/catalina.out\" ]; then mv #{liferay_dir}/tomcat-*/logs/catalina.out #{tmpdir}/catalina.out.old; fi"   
    logger.info "Cleaned up Liferay"  
  end
  
    desc "called by main #{name}"
    task "install_and_config_liferay".to_sym do
     logger.level = Capistrano::Logger::INFO
     logger.info "DEBUG: TASK #install_and_config_tomcat"
     
     logger.info "START: this is #{name}"
     set(:url) do
        Capistrano::CLI.ui.ask "Enter URL to liferay tomcat bundle zip file:"
     end unless variables[:url]
     
     # Create #{tmpdir} if it does not exist
     run "if [ ! -d \"#{tmpdir}\" ]; then mkdir -p #{tmpdir}; else rm -fr #{tmpdir}; mkdir -p #{tmpdir};fi"
     # remove contents of tmpdir
     run "rm -rf #{tmpdir}/#{name}-#{liferay_version}.zip"
     
     #set :liferaywar_webapps, "webapps"
     begin
        logger.info "BEGIN: install #{name} (inside file: tomcat bundle zip file)"
        logger.info "Liferay Tomcat ZIP: wget #{wget_params} #{url} -O #{name}-#{liferay_version}.zip"
        run "cd #{tmpdir} && wget #{wget_params} #{url} -O #{name}-#{liferay_version}.zip"
     rescue
        logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
        `wget #{wget_params} #{url} -O working/#{name}-#{liferay_version}.zip`
        upload("working/#{name}-#{liferay_version}.zip","#{tmpdir}/#{name}-#{liferay_version}.zip", :via => :scp)
     end
     
    
     #Cleanup the liferay_dir
     run "if [ -L \"#{liferay_dir}\" ]; then unlink #{liferay_dir}; fi;"
     run "if [ -d \"#{liferay_dir}\" ]; then rm -fr #{liferay_dir}; fi;"
     run "rm -fr #{basedir}/liferay-*"
     
     #  the tar.gz and untar it into place
     run "cp #{tmpdir}/#{name}-#{liferay_version}.zip #{basedir}/;"
     run "cd #{basedir}/; LIFERAY_DIR=`unzip #{name}-#{liferay_version}.zip | grep creating | awk '{print $2}' | egrep  'liferay-[^\\/]*\\/$'`; if [ -n \"$LIFERAY_DIR\" ]; then sudo ln -fs #{basedir}/$LIFERAY_DIR #{liferay_dir} ;fi"
     
     tomcat_dir=(capture("ls #{liferay_dir}/ | grep tomcat")).strip
     logger.info "Tomcat Dir is : #{tomcat_dir}"
     
     #Replace the web port in tomcat/conf/server.xml
     run "sed -i -e 's/#{default_web_port}/#{web_port}/g' #{liferay_dir}/tomcat-*/conf/server.xml"
     run "sed -i -e 's/#{default_stop_port}/#{stop_port}/g' #{liferay_dir}/tomcat-*/conf/server.xml"
     
     #Set the appconfig variable
     
     #Cannot use sed because it contains single quote
     `rm -fr working/#{ENV['HOSTS']}.#{name}.setenv.current`
     download("#{liferay_dir}/#{tomcat_dir}/bin/setenv.sh","working/#{ENV['HOSTS']}.#{name}.setenv.current", :via => :scp)
     
     
     appconfig_str= <<-APPCONFIG
     
DEFAULTIFACE=`netstat -rn | grep ^0.0 | awk '{print $8}'`
IPADDRESS=`/sbin/ifconfig $DEFAULTIFACE | grep 'inet addr:' | awk '{print $2}' | awk -F: '{print $2}'`
HOST_NAME=`hostname | perl -pe 's/\\..*//'`
if [ -z "$LIFERAY_DIR" ]; then export LIFERAY_DIR=#{liferay_dir}; fi
export RESOURCE_PATH=$LIFERAY_DIR/appconfig     
export JAVA_OPTS="$JAVA_OPTS -server \\
     -Dcom.sun.management.jmxremote \\
     -Djava.rmi.server.hostname=$IPADDRESS \\
     -Dcom.sun.management.jmxremote.port=#{jmx_port} \\
     -Dcom.sun.management.jmxremote.authenticate=false \\
     -Dcom.sun.management.jmxremote.ssl=false \\
     -DHOSTNAME=$HOST_NAME"
     APPCONFIG
      
     
     File.open("working/#{ENV['HOSTS']}.#{name}.setenv.current",'a'){|f| f.puts appconfig_str;}
     run "mv #{liferay_dir}/tomcat-*/bin/setenv.sh #{tmpdir}/setenv.sh.orig"
     upload("working/#{ENV['HOSTS']}.#{name}.setenv.current","#{liferay_dir}/#{tomcat_dir}/bin/setenv.sh", :via => :scp)
            
     #Add chkconfig to catalina.sh
     liferay_initd_script = <<-INITD_SCRIPT
     
# chkconfig: 345 90 10
# description: Manages Liferay server #{liferay_version}.
# Liferay Initd Script  
  
     INITD_SCRIPT
     
     run "has_chkconfig=`grep '\#chkconfig' #{liferay_dir}/tomcat-*/bin/catalina.sh`; if [ -z \"$has_chkconfig\" ] ; then sed -i -e '2 i #{liferay_initd_script}' #{liferay_dir}/tomcat-*/bin/catalina.sh; fi"
     run "if [ ! -L \"/etc/init.d/liferay\" ]; then sudo ln -fs #{liferay_dir}/tomcat-*/bin/catalina.sh /etc/init.d/liferay; sudo chkconfig liferay on; fi"
  end   
   
    desc "called by #{env}_#{name} in #{env}.rb"
    task "#{name}_main_#{env}".to_sym do
       set :app, "#{name}"
          logger.level = Capistrano::Logger::INFO
          

          if exists?(:noBom) or exists?(:nobom)
            puts "skipping read bom"
          else
            read_bom
          end

          if exists?(:cleanServer) && cleanServer.to_s == "true"
            logger.info "clean installing #{app}"
            stop_liferay
            cleanup_liferay
            check
          else
            check
            stop_liferay
          end
          find_and_execute_task("install_and_config_liferay")         
          liferay_portlets.each do |portlet_name|
            find_and_execute_task("deploy_#{portlet_name}_#{env}")
          end          
          start_liferay         
          alive
#          get_ver
    end
       
    desc "used to deploy #{name}"
    task "deploy_#{name}_#{env}".to_sym do 
      eval("#{env}_#{name}")
      set :alive_path, ""
      set :liferay_dir, "#{basedir}/#{hiera('servlet_container')}-liferay"
      set :tmpdir, "#{basedir}/tmp"
      #Create the basedir if it does not exist
      run "if [ ! -d \"#{basedir}\" ]; then sudo mkdir -p #{basedir}; sudo chown -fR xdeploy:xdeploy #{basedir}; fi"
      
      set :web_port, hiera("#{name}_web_port")
      set :jmx_port, hiera("#{name}_jmx_port")
      set :stop_port, hiera("#{name}_stop_port")
      
      find_servers(:roles => "#{name}".to_sym).each do |server|
        ENV['HOSTS'] = "#{server.host}"
        find_and_execute_task ("#{name}_main_#{env}")       
      end
    end 
  end
end

liferay_portlets.each do |portlet_name|
  
  desc "Cleanup liferay single portlet"
  task "cleanup_#{portlet_name}".to_sym do
    logger.info "Cleanup Liferay #{portlet_name}............."
    aid=portlet_name.gsub(/([A-Z])/,'-\1').strip.downcase
    run "sudo rm -fr #{liferay_dir}/tomcat-*/webapps/#{aid}"
    run "sudo rm -fr #{liferay_dir}/tomcat-*/work/localhost/#{aid}"        
    logger.info "Cleaned up Liferay Portlet #{portlet_name}"  
  end
  
    desc "used to deploy #{portlet_name}_#{env}"
  	task "deploy_#{portlet_name}_#{env}".to_sym do
      logger.info "Deploying #{portlet_name}........"
      eval("#{env}_liferay")
      set :liferay_dir, "#{basedir}/#{hiera('servlet_container')}-liferay"
      set :tmpdir, "#{basedir}/tmp"
      
      #Save the old app name
      
      has_liferay=(capture "if [ -L \"#{liferay_dir}\" ]; then echo \"true\"; else echo \"false\"; fi").strip
      logger.info "has_liferay:#{has_liferay}>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
      if has_liferay.eql?("false")
        logger.info "cap -f capfile_#{confType} deploy_liferay_#{confType} -S cleanServer=true -S bamaBOM=#{bamaBOM} -S bom=#{bom} -S force=true 2>&1 | tee /dev/stderr"                 
        cap_log=`cap -f capfile_#{confType} deploy_liferay_#{confType} -S cleanServer=true -S bamaBOM=#{bamaBOM} -S bom=#{bom} -S force=true 2>&1 | tee /dev/stderr`
        logger.info cap_log       
      else
    		find_and_execute_task("main_#{portlet_name}_#{env}")
      end 		
      
    end
  
  	task "main_#{portlet_name}_#{env}".to_sym do
      logger.level = Capistrano::Logger::INFO
      
      set :app, "#{portlet_name}"
                     
      find_and_execute_task("cleanup_#{portlet_name}")
      check

      if exists?(:noBom) or exists?(:nobom)
        #set :skipWriteServiceVersion, "true"
        logger.info "skipping read bom"
      else
        read_bom
      end
      find_and_execute_task("install_and_config_#{app}_#{env}")     
  	end

    desc "called by #{env}_#{portlet_name} in #{env}.rb"
    task "install_and_config_#{portlet_name}_#{env}".to_sym do
     logger.level = Capistrano::Logger::INFO
     logger.info "DEBUG: TASK #install_and_config_#{portlet_name}_#{env}"
     
     logger.info "START: this is #{portlet_name}"    
     set(:url) do
        Capistrano::CLI.ui.ask "Enter URL to liferay portlet #{portlet_name} tar.gz file:"
     end unless variables[:url]
     
     if exists?(:url) && !url.empty? && url.end_with?("tar.gz")
       set :portlet_tmpdir, "#{tmpdir}/#{portlet_name}"
       # Create #{tmpdir} if it does not exist or cleanup it if it does exist
       run "if [ ! -d \"#{portlet_tmpdir}\" ]; then mkdir -p #{portlet_tmpdir}; else  mv -f #{portlet_tmpdir} #{portlet_tmpdir}.old; mkdir -p #{portlet_tmpdir}; fi"
    
       begin
          logger.info "BEGIN: install #{name} (inside file: portlet #{portlet_name} tar.gz file)"
          logger.info "Liferay Portlet Tar.GZ: wget #{wget_params} #{url} -O #{portlet_tmpdir}/#{portlet_name}.tar.gz"
          run "wget #{wget_params} #{url} -O #{portlet_tmpdir}/#{portlet_name}.tar.gz"
       rescue
          logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
          `wget #{wget_params} #{url} -O working/#{portlet_name}.tar.gz`
          upload("working/#{portlet_name}.tar.gz","#{portlet_tmpdir}/#{portlet_name}.tar.gz", :via => :scp)
       end
     
       #  copy the tar.gz and untar it into place
       aid=portlet_name.gsub(/([A-Z])/,'-\1').strip.downcase
       run "if [ ! -d \"#{liferay_dir}/deploy\" ]; then mkdir -p #{liferay_dir}/deploy; fi"
       run "if [ ! -d \"#{liferay_dir}/appconfig\" ]; then mkdir -p #{liferay_dir}/appconfig; fi"
     
       run "cd #{portlet_tmpdir}; tar xzf #{portlet_name}.tar.gz; cp #{aid}-*/*.properties #{liferay_dir}/appconfig/; cp #{aid}-*/*.war #{liferay_dir}/deploy;"
     
       case portlet_name
       when "maxPortlet"
         #Put portlet specific configuration here
  	   when "editorialCollectionPortlet"
         #Put portlet specific configuration here
  	   when "vampPortlet"
         #Put portlet specific configuration here
  	   when "queryBuilder"
         #Put portlet specific configuration here
       end 
     else
       logger.info "ERROR:The artifact url #{url} does not set correctly for portlet #{portlet_name}"    
     end
    end
    	      
end