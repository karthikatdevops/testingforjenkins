name="haproxy"
#
# Notes:
# -S lockdown - will write out ACLs that drop all connections to back-ends except what is permitted
# Merqa and merdevl need the special startup script in /etc/init.d on the haproxies to use the multi-configs
#

# this task will push a startup script out to the haproxy
load "./conf/haproxyStartupScript.rb"

SERVICES_IGNORE = ["jmxtrans", "gdash", "nginx", "haproxy", "nagios", "oracle", "oracle2", "ppvGapReport", "qamParityReport" ]
FAILOVER_SERVICES = ["imageWebService", "offerWebService", "consistencyWebService", "personaIngestWebService", "imageEventWebService" ]
CLIENTS_CONSUMERS = ["consistencyWebService","imageWebService"]

desc "used to update_#{name}_#{env} configuration file"
task "update_#{name}_#{env}".to_sym do
  logger.level = Capistrano::Logger::INFO
  logger.info "--------------------------------------------------------------------------------------------"
  logger.info "M1 TASK: update_conf_#{name}_#{env}.to_sym do"

  logger.info ">>>> about to call task #{env}_#{name}"
  find_and_execute_task ("#{env}_#{name}".to_sym)
  logger.info ">>>> exited  task #{env}_#{name}"

  set :app, "#{name}"
  set :install_path, "/etc/#{name}/#{name}.d"
  run "sudo mkdir -p #{install_path}"

  logger.info "clean local and remote old json files"
  run "sudo mv #{install_path}/#{name}_head.cfg #{install_path}/#{name}_head.cfg.bk" if exists?(:clean) && clean
  run "sudo mv #{install_path}/#{name}-#{env}.cfg #{install_path}/#{name}-#{env}.cfg.bk" if exists?(:clean) && clean
  `rm -fr working/#{name}; mkdir -p working/#{name};`

  find_servers(:roles => "#{name}".to_sym).each do |ha_svr|
    set :ha_host, "#{ha_svr.host}"
    logger.info "Updating haproxy on host(s): #{ha_host}........"

    # loop through tasks and get listen lines
    listen_lines_arr = Array.new        
    self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each do |tsk|
      service_name = tsk.fully_qualified_name.split("#{env}_").last
      set :hiera_svc, service_name

      logger.info " "
      logger.info "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
      logger.info "Self.task_list for: #{hiera_svc}"

      if SERVICES_IGNORE.include?(service_name)
        next
      end

      set :web_port, hiera("#{service_name}_web_port")

      # execute task
      find_and_execute_task ("#{tsk.name}")

      # loop through servers and get server_lines
      server_lines_arr = Array.new
      haproxy_get_servers_for_task(tsk, service_name).each do |svr|
        set :hiera_host, "#{svr}"
        server_line = get_server_line(service_name, svr)
        if server_line
          server_lines_arr << server_line
        end
      end
      server_lines = server_lines_arr.join("\n  ")

      # add to listen lines
      listen_lines_arr << get_svc_listen_lines(tsk, service_name, server_lines)
    end
    listen_lines = listen_lines_arr.join("\n")

    # get string for haproxy.cfg head
    haproxy_cfg_head = get_haproxy_cfg_head()

    # write files
    File.open("working/#{name}/#{name}_#{ha_host}_head.cfg",'w+'){|f| f.puts haproxy_cfg_head}
    File.open("working/#{name}/#{name}_#{ha_host}-#{env}.cfg",'w+'){|f| f.puts listen_lines }

    # clear roles
    roles.clear

    # upload files and restart?
    if exists?(:deploy) && deploy
      # set user
      set :user, haproxy_user

      # upload files
      logger.info "--------------------------------------------------------------------------------------------"
      logger.info " "
      logger.info "Deploying config file pieces to host #{ha_host}...."
      logger.info " "
      logger.info " "


      logger.info " backup head 1 "
      run "if [ -f #{install_path}/#{name}_head.cfg ]; then sudo mv #{install_path}/#{name}_head.cfg #{install_path}/#{name}_head.cfg.bk; fi", {:hosts => "#{ha_host}"}
      logger.info " backup cfg file 1"
      run "if [ -f #{install_path}/#{name}-#{env}.cfg ]; then sudo mv #{install_path}/#{name}-#{env}.cfg #{install_path}/#{name}-#{env}.cfg.bk; fi", {:hosts => "#{ha_host}"}
      logger.info " upload head to /tmp on target server"
      upload("working/#{name}/#{name}_#{ha_host}_head.cfg","/tmp/#{name}_head.cfg", :via => :scp,:hosts => ha_host)
      logger.info "upload cfg to /tmp on target server"
      upload("working/#{name}/#{name}_#{ha_host}-#{env}.cfg","/tmp/#{name}-#{env}.cfg", :via => :scp, :hosts => ha_host)
      logger.info " move head files from /tmp to #{install_path} - if deploy is set"
      run "sudo mv /tmp/#{name}_head.cfg #{install_path}/#{name}_head.cfg; sudo chown root:root #{install_path}/#{name}_head.cfg; sudo chmod 644 #{install_path}/#{name}_head.cfg;", {:hosts => "#{ha_host}"} if exists?(:deploy) && deploy
      logger.info "move cfg file from /tmp to #{install_path} - if deploy is set"
      run "sudo mv /tmp/#{name}-#{env}.cfg #{install_path}/#{name}-#{env}.cfg; sudo chown root:root #{install_path}/#{name}-#{env}.cfg; sudo chmod 644 #{install_path}/#{name}-#{env}.cfg;", {:hosts => "#{ha_host}"} if exists?(:deploy) && deploy


      logger.info ">>>>> ABOUT TO EVAL IF BLOCK FOR env = #{env}....."
      # possibly deploy the enchanced startup script...
      if ["merqaFo", "cmpstkMerlinIngest", "merdevlFo", "merdevl", "cmpstkMerlinImages", "mciGbenv" ].include?(env)

      #if env.eql?("merqaFo") || env.eql?("merdevlFo") ||  env.eql?("cmpstkMerlinImages") || env.eql?("cmpstkMerlinIngest") ||  env.eql?("merdevl")
        logger.info ">>>>>---------- Deploy startup scripts for DEV and MERQA------------------"
        logger.info "starting deployment of enhanced startup script...."
        find_and_execute_task("deploy_haproxy_start_script")
        logger.info "finished deployment of enhanced startup script...."
      else
        logger.info "Didn't match build, dev and qa - so skipping deployment of enchanced startup script"
      end

      # possibly restart haproxy
      if ["merch2cIngest", "ch2c", "merch2cImages"].include?(env)
        logger.info "Just overwrote files, run make_haproxy_cfg_and_restart to start"
      else
        run "sudo /etc/init.d/haproxy restart", {:hosts => "#{ha_host}"}
      end
    end
  end
end

################################
#
# Make the haproxy.cfg from the multiple cfgs in haproxy.d
# Use this to associate multiple envs together 
# Uses pcs (cluster) to restart
#
###############################

desc "Make haproxy.cfg and restart"
task :make_haproxy_cfg_and_restart do

  # get haproxy hosts
  find_and_execute_task "#{confType}_haproxy"

  # find related envs
  related_envs = case confType
  when "merch2cIngest"
    ["ch2c", "merch2cImages"]
  else
    raise "Don't know how to handle confType #{confType.inspect}"
  end

  # go one at a time
  run_serially_in_batches(:find_server_opts => {:roles => :haproxy}) do |server_options|
    # set user
    set :user, haproxy_user

    # make backup of haproxy.cfg
    run "sudo cp /etc/haproxy/haproxy.cfg /etc/haproxy/haproxy.cfg.bak"

    # overwrite haproxy.cfg
    cfg_files = ["haproxy_head.cfg"] + ([confType] + related_envs).collect {|e| "haproxy-#{e}.cfg"}
    full_path_cfg_files_str = cfg_files.collect {|f| "/etc/haproxy/haproxy.d/#{f}"}.join(" ")
    run "sudo bash -c 'cat #{full_path_cfg_files_str} > /etc/haproxy/haproxy.cfg'"
    run "sudo chmod 644 /etc/haproxy/haproxy.cfg"

    # restart
    run "sudo /etc/init.d/haproxy restart"

    # restart
    # run "sudo pcs resource stop HAPROXY; sudo pcs resource start HAPROXY"
  end
end

################################
#
# Make the haproxy.cfg from the multiple cfgs in haproxy.d
# Use this to deploy/update just a single env to haproxy 
# Uses regular restart
#
###############################

desc "Make Simple haproxy.cfg and restart"
task :make_simple_haproxy_cfg_and_restart do
  # get haproxy hosts
  find_and_execute_task "#{confType}_haproxy"
  
  set :user, haproxy_user

  # make backup of haproxy.cfg
  run "sudo cp /etc/haproxy/haproxy.cfg /etc/haproxy/haproxy.cfg.bak"

  # overwrite haproxy.cfg
  cfg_files = ["haproxy_head.cfg"] + ([confType]).collect {|e| "haproxy-#{e}.cfg"}
  full_path_cfg_files_str = cfg_files.collect {|f| "/etc/haproxy/haproxy.d/#{f}"}.join(" ")
  run "sudo cat #{full_path_cfg_files_str} > /etc/haproxy/haproxy.cfg"
  run "sudo chmod 644 /etc/haproxy/haproxy.cfg"

  # restart
  run "sudo /etc/init.d/haproxy restart"
end

### methods for haproxy ###
def haproxy_get_servers_for_task(task, service_name)
  # check hiera for overrides
  servers = hiera('haproxy_servers')
  if servers
    res = servers
  else
    res = find_servers_for_task(task, :roles => service_name.to_sym).collect { |s|
      s.host
    }
  end
  res
end

def get_vod_menu_vip_listen()
  if env.include?("cmpstk")
    <<-LISTEN_STR
  frontend http-in
                bind #{dsHAProxyVip}:80
                acl is_nav url_beg  /nav
                acl is_unu url_beg  /unu
                acl is_persona url_beg  /persona
                use_backend nav if is_nav
                use_backend unu if is_unu
                use_backend persona if is_persona
                default_backend default_website

  backend nav
                mode http
                balance roundrobin
                option httpchk
                option forwardfor
                server NAV 10.252.241.112:80 weight 1 check

  backend unu
                mode http
                balance roundrobin
                option httpchk
                option forwardfor
                server UNU 10.252.241.112:80 weight 1 check

  backend persona
                mode http
                balance roundrobin
                option httpchk
                option forwardfor
                server PERSONA 10.252.241.106:80 weight 1 check

  backend default_website
                mode http
                balance roundrobin
                option httpchk
                option forwardfor
                server local #{ha_host}:8888 weight 1 check
      LISTEN_STR
  else
    ''
  end
end

def get_haproxy_cfg_head()
  vod_menu_vip_listen = get_vod_menu_vip_listen()
  <<-HAPROXY_CFG_STR
global
  log 127.0.0.1 local5 warning
  maxconn 80960
  tune.bufsize 5242880
  tune.maxrewrite 2621440
  chroot /usr/share/haproxy
  uid 99
  gid 99
  stats socket /tmp/haproxy.socket uid haproxy mode 770 level admin
  daemon
  # debug
  # quiet

defaults
  log global
  mode http
  option dontlognull
  retries 5
  option redispatch
  maxconn 80960
  timeout connect 120s
  timeout client 20m
  timeout server 20m
  timeout http-request 120s
  timeout http-keep-alive 20m

listen monitoring *:8888
  mode http
  option httplog
  option forwardfor
  stats enable
  stats uri   /
  stats refresh 30s
  stats show-node

#{vod_menu_vip_listen}
HAPROXY_CFG_STR
end


def get_server_line(service_name, svr)
#  logger.info ">>>>>>>>>>>>> #{service_name} <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
  short_host_name = svr.gsub(/\..*/,'')
#  logger.info "entered get_server_line for #{short_host_name}"
  if CLIENTS_CONSUMERS.include?(service_name) and hiera('consistencyWebServiceMode') == "consumer" || hiera('imageWebServiceMode') == "consumer" || (hiera('client') == "true" && ! hiera('put_in_vip'))
    server_line = nil

  # Handle SOLR instances - recall- if this is a master, with a master/slave combo we do NOT want
  #  traffic from the VOP going to the master - it should only go to the slave.
  # if this is a solr instance, stop here and check if it's a combined master/slave or a master and a slave  
  elsif service_name.include?("Solr") || service_name.include?("Index") and hiera('replication') == "master"
    logger.info ">>>>>>>>>>>>> got a solr instance!"
    if hiera('masterAndSolr') == "true"
      logger.info ">>>>>>>>>>>>> got a solr master and slave combo system, adding server_line!"
      server_line = "server #{short_host_name} #{svr}:#{web_port} weight 1 check inter 2s rise 5 fall 5 slowstart 30s "
    else
      logger.info ">>>>>>>>>>>>> got a solr master #{service_name} , so not putting a serverline in (use slave)"
      server_line = nil
    end

  elsif FAILOVER_SERVICES.include?(service_name)
    server_line = "server #{short_host_name} #{svr}:#{web_port} weight 1 check inter 2s rise 5 fall 5 slowstart 60s "
  elsif service_name.start_with?("rabbit") || service_name.start_with?("image_rabbit") || service_name.start_with?("imageRabbit")
    set :amqp_port, hiera('amqp_port')
    server_line = "server #{short_host_name} #{svr}:#{amqp_port} check inter 120s rise 2 fall 3"
  else
    server_line = "server #{short_host_name} #{svr}:#{web_port} weight 1 check inter 2s rise 5 fall 5 slowstart 30s "
  end
  logger.info "> Final server_line: #{server_line}"
  server_line
end


def get_svc_http_check(service_name)
  # get http_check_line
  if FAILOVER_SERVICES.include?(service_name)
    logger.info "NOTE:>> FAILOVER SERVICE DETECTED: #{service_name} - setting special alive check here."
    check_master_status = service_name == "personaIngestWebService" ? "PersonaIngestService" : service_name.gsub(/WebService$/, '')
    http_check_line = "\n  option httpchk GET /#{service_name}/web/#{check_master_status}/isMaster?form=json&schema=1.0\n  http-check disable-on-404\n  http-check expect string {\"isMasterResponse\":true} "
  elsif hiera("#{service_name}_alive")
    check_path=hiera("#{service_name}_alive")
    if !check_path.include?("port check")
      http_check_line = "\n  option httpchk GET /#{check_path}\n  http-check disable-on-404\n  http-check expect rstatus ^2"
    end
  else
    http_check_line=""
  end
end


def get_svc_listen_lines(tsk, service_name, server_lines)
  http_check_line = get_svc_http_check(service_name)
  if service_name.eql?("rabbitMQ") || service_name.eql?("image_rabbitmq")
    listen = <<-RABBIT_LISTEN_STR
  listen #{env}.#{service_name} #{dsHAProxyVip}:#{hiera('rabbitMQ_web_port')}
    mode tcp
    balance roundrobin
    timeout connect 50s
    timeout client 50s
    timeout server 50s
    #{server_lines}
    RABBIT_LISTEN_STR
  elsif service_name.eql?("imageRabbitMQ")
    listen = <<-IMAGE_RABBIT_LISTEN_STR
  listen #{env}.#{service_name} #{dsHAProxyVip}:#{hiera('imageRabbitMQ_web_port')}
    mode tcp
    balance roundrobin
    timeout connect 50s
    timeout client 50s
    timeout server 50s
    #{server_lines}
    IMAGE_RABBIT_LISTEN_STR
  elsif service_name.eql?("rabbitMGT") || service_name.eql?("image_rabbitmgt")
    listen = <<-RABBITMGT_LISTEN_STR
  listen #{env}.#{service_name} #{dsHAProxyVip}:#{hiera('rabbitMGT_web_port')}
    mode http
    balance roundrobin
    option httplog
    option forwardfor
    appsession JSESSIONID len 52 timeout 3h
    timeout connect 500s
    timeout client 500s
    timeout server 500s
    stats enable
    stats hide-version
    stats scope   .
    stats uri /admin?stats
    stats realm Haproxy\ Statistics
    stats show-node
    #{server_lines}
    RABBITMGT_LISTEN_STR
  elsif service_name.eql?("imageRabbitMQ")
    listen = <<-IMAGE_RABBITMGT_LISTEN_STR
  listen #{env}.#{service_name} #{dsHAProxyVip}:#{hiera('imageRabbitMGT_web_port')}
    mode http
    balance roundrobin
    option httplog
    option forwardfor
    appsession JSESSIONID len 52 timeout 3h
    timeout connect 500s
    timeout client 500s
    timeout server 500s
    stats enable
    stats hide-version
    stats scope   .
    stats uri /admin?stats
    stats realm Haproxy\ Statistics
    stats show-node
    #{server_lines}
    IMAGE_RABBITMGT_LISTEN_STR
  elsif  exists?(:lockdown)
    listen = <<-MERLIN_LOCKDOWN_LISTEN_STR
listen #{env}.#{service_name} #{dsHAProxyVip}:#{web_port}
  # stop anything not listed here from contacting our VIP and our ingest
  acl white_list src 127.0.0.1 10.251.132.0/23 10.21.136.0/24 10.21.138.0/24
  tcp-request inspect-delay 1s
  tcp-request content accept if white_list
  tcp-request content reject
  option httplog
  option forwardfor
  balance roundrobin#{http_check_line}
  #{server_lines}
  MERLIN_LOCKDOWN_LISTEN_STR
  else
    listen = <<-LISTEN_STR
listen #{env}.#{service_name} #{dsHAProxyVip}:#{web_port}
  option httplog
  option forwardfor
  balance roundrobin#{http_check_line}
  #{server_lines}
  LISTEN_STR
    if service_name.eql?("feedgenWebService")
      server_lines=""
      find_servers_for_task(tsk, :roles => "#{service_name}WebHosts".to_sym).each do |svr|
        logger.info "WebHosts server===#{svr.host}"
         short_host_name=svr.host.gsub(/\..*/,'')
         server_line="server #{short_host_name} #{svr.host}:80 weight 1 check inter 2s rise 5 fall 5 slowstart 30s "
         server_lines << server_line << "\n        "
      end
      unless server_lines.empty?
        listen << <<-LISTEN_STR
listen #{env}.#{service_name}WebHosts #{dsHAProxyVip}:80
  option httplog
  option forwardfor
  balance roundrobin
  option httpchk GET /alive
  http-check disable-on-404
  http-check expect rstatus ^2
  #{server_lines}
  LISTEN_STR
      end
    end
  end
  listen
end

logger.info ">>>>> loaded haproxy"
