name="ppvGapReport"    

    #============
    # DEPLOY TASK
    #  - called from capistrano command-line
    #  - calls MAIN
    #============
    desc "used to deploy #{name}_#{env}"
    task "deploy_#{name}_#{env}".to_sym do
        logger.level = Capistrano::Logger::INFO
        logger.info "M1 TASK: deploy_#{name}_#{env}.to_sym do"
        eval("#{env}_#{name}")
        servers=find_servers(:roles => "#{name}".to_sym)
        logger.info "servers: #{servers.size}"
        find_and_execute_task ("#{name}_main_#{env}")           
    end # desc "used to deploy #{name}_#{env}"

    #============
    # MAIN TASK
    #  - Calls COPY and START tasks.
    #============
    desc "called by #{env}_#{name} in #{env}.rb"
    task "#{name}_main_#{env}".to_sym do
        logger.level = Capistrano::Logger::INFO
        logger.info "DEBUG: TASK: #{name}_main_#{env}"
        
                
        if exists?(:isPPVQa) && isPPVQa   
          set :app, "#{name}-QA"   
        else
          set :app, "#{name}"
        end
        set :install_path, "/opt/ds/#{app}"
        puts "....Set install_path=#{install_path}"

        logger.info "START: this is #{app}"
        logger.info "DEBUG: about to read_bom"
   
        if exists?(:noBom) or exists?(:nobom)
            #set :skipWriteServiceVersion, "true"
            logger.info "skipping read bom"
        else
            check_service_version
            read_bom
        end

        if exists?(:cleanServer) && cleanServer.to_s == "true"
            logger.info "cleaning #{install_path} since cleanServer is TRUE"
            run "[ -d #{install_path}/ppv_gap_report ] && sudo rm -rf #{install_path}/ppv_gap_report; exit 0"
        end
        find_and_execute_task("copy_#{name}_#{env}")   

    end # task "#{name}_main_#{env}".to_sym do

    #============
    # COPY TASK
    #  - calls UPDATECONFIG and INITD tasks
    #============
    desc "called by #{name}_main_#{env}"
    task "copy_#{name}_#{env}".to_sym do
        logger.info "M2 TASK: copy_#{name}_#{env}.to_sym do"
        run "if [[ ! -d /opt/ds ]]; then sudo mkdir /opt/ds; sudo chown xdeploy /opt/ds; fi"
        run "if [[ ! -d #{install_path} ]]; then mkdir -p #{install_path}; fi"
        run "if [[ ! -d #{install_path}/reports ]]; then mkdir -p #{install_path}/reports; fi"
        run "if [[ ! -d #{install_path}/logs ]]; then mkdir -p #{install_path}/logs; fi"
        run "if [[ ! -d #{install_path}/version ]]; then mkdir -p #{install_path}/version; fi" 
        `if [ -d "working/#{app}" ]; then rm -fr working/#{app}; fi; mkdir -p working/#{app};`
        if exists?(:noBom) or exists?(:nobom)
            # remove contents of tmpdir 
            run "rm -rf #{tmpdir}/#{app}"
            run "mkdir -p #{tmpdir}/#{app}"
            logger.info " attempting to wget #{url}"
            logger.info " using cmd: wget #{wget_params} --no-proxy #{url} -O- working/#{name}.tar.gz"
            #grab the zip file, unzip it, and mv it to a meaningful name      
            logger.info "using a local wget and scp up to the server, this will take a bit of time..."
            `wget #{wget_params} --no-proxy #{url} -O working/#{name}.tar.gz`
            upload("working/#{name}.tar.gz","#{install_path}/#{name}.tar.gz", :via => :scp)
            run "cd #{install_path} && tar xzf #{name}.tar.gz"  
            run "cd #{install_path}/ppv_gap_report; ln -fs ../reports .; ln -fs ../logs ."  
            # WRITE SERVICE VERSION
            puts "I have no BOM-- guessing what version of service I have using regex"
            puts "My package is: #{url}"
            myNoBomVersion = url.gsub(/.tar.gz.*/, "")
            myNoBomVersion = myNoBomVersion.gsub(/.*\/ppv-gap-report-/, "")
            puts "My guessed version is: #{myNoBomVersion}"
            run "echo \"#{myNoBomVersion} (noBom)\" > #{install_path}/version/version.txt"
            # POST HISTORY
            run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
            logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
            run "touch #{basedir}/history/#{app}/deploy_history.txt"
            run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
            run "echo \"Version: #{myNoBomVersion} (noBom)\" >> #{basedir}/history/#{app}/deploy_history.txt"
        else
            get_remote_file("#{url}","#{install_path}","#{app}.tar.#{service_version}.gz")
            logger.info "unpacking tarball"
            run "cd #{install_path} && tar xzf #{app}.tar.#{service_version}.gz"
            run "cd #{install_path}/ppv_gap_report; ln -fs ../reports .; ln -fs ../logs ."
            run "echo #{service_version} #{bom} > #{install_path}/version/version.txt"
            # POST HISTORY
            run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
            logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
            run "touch #{basedir}/history/#{app}/deploy_history.txt"
            run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
            run "echo \"Version: #{service_version} #{bom}\" >> #{basedir}/history/#{app}/deploy_history.txt"
        end
        
        logger.info "TASK: END"
    end # end copy_#{name}_#{env}"


logger.info ">>>>> loaded ppvgap_report"