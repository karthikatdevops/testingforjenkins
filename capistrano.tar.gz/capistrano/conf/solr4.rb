## this file contains common tasks that span all environments and all DS apps.
[svc].each do |name|  

     task :solr4 do
       logger.info "SOLR4: --------------------------------------------------------------------------------" 
       logger.info "TASK: Entered solr4 install"
       # get right java version
       check
       logger.info "End checks"

       logger.info "SOLR4: about to wget #{hiera('solr4_rpm_url')}"
       run "cd /tmp/; wget #{wget_params} #{hiera('solr4_rpm_url')}"

       logger.info "SOLR4: about to rpm install #{hiera('solr4_rpm_url')}"
       run "cd /tmp/; sudo rpm --force -U #{hiera('solr4_rpm')}"

       logger.info "SOLR4: END--------------------------------------------------------------------------------"
     end

#################################
#
# dependencies_
#
#

      # cap dependencies_programIndex2 -f capfile_merdevl -S nobom
      desc "called by dependencies_#{name}"
      task "dependencies_#{name}".to_sym do
         logger.info "Entered dependencies_#{name} in solr4.rb-------------------------------------"
         logger.level = Capistrano::Logger::INFO
         logger.info "Checking dependencies for #{name}"

         find_and_execute_task("#{env}_#{name}")
         set :app, "#{name}"
         set :web_port, hiera("#{name}_web_port")
         set :jmx_port, hiera("#{name}_jmx_port")
         set :stop_port, hiera("#{name}_stop_port")
         set :alive_path, hiera("#{name}_alive")


         logger.info " "   
         logger.info " "
               logger.info "VARIABLES SET FOR THIS RUN: "
               logger.info "________________________________________"
               logger.info "env      = #{env} "
               logger.info "name         = #{name} "
               logger.info "app          = #{app}    " 
               logger.info "user         = #{user} "
               logger.info "web_port     = #{web_port} "
               logger.info "jmx_port     = #{jmx_port} "
               logger.info "alive_path   = #{alive_path} "
               logger.info "________________________________________"
         logger.info " "
         logger.info " "
         logger.info " "

         # No dependencies, so we just return
     end


#################################
#
# MAIN
#
#

      desc "called by #{env}_#{name} in #{env}.rb"
      task "#{name}_main_#{env}".to_sym do
         logger.level = Capistrano::Logger::INFO
         logger.info " "
         logger.info " "
         logger.info "---------------------------------------------------------------------------------------------"

         logger.info "Entered #{name}_main_#{env} in solr4.rb--------------------------------------------------"

         set :app, "#{name}" 
         set :targz_file_name, "#{name}"           


         if exists?(:noBom) or exists?(:nobom)
          puts "skipping read bom"
         else
           check_service_version
           read_bom
           set :app, "#{name}"
        end
        
         if exists?(:cleanServer) && cleanServer.to_s == "true"
         
         # find_and_execute_task ("stop_merlin_solr")
          
          find_and_execute_task ("solr4")
          
          run "sudo chown -HR #{user}:#{user} #{appdir}"
          run "sudo sed -e s/xdeploy/#{user}/g -i'' /etc/init.d/merlinsolr"
          
          find_and_execute_task ("update_solr_jetty_xml")

         end

      #  set :jetty_wrapper_path, "#{basedir}/jetty-#{name}/jetty-wrapper.sh"
        set :web_port, hiera("#{name}_web_port")
        set :jmx_port, hiera("#{name}_jmx_port")
        set :stop_port, hiera("#{name}_stop_port")
        set :alive_path, "solr/"
        set :strictAlive, true
        set :solrMaster, hiera('solrMaster')


         logger.info " "   
         logger.info " "
               logger.info "VARIABLES SET FOR THIS RUN: "
               logger.info "________________________________________"
               logger.info "env      = #{env} "
               logger.info "name         = #{name} "
               logger.info "app          = #{app}    " 
               logger.info "user         = #{user} "
               logger.info "web_port     = #{web_port} "
               logger.info "jmx_port     = #{jmx_port} "
               logger.info "alive_path   = #{alive_path} "
               logger.info "________________________________________"
         logger.info " "
         logger.info " "
         logger.info " "
        
        
         find_and_execute_task ("stop_merlin_solr")
         run "if [ -e #{tmpsolrdir} ]; then echo 'dir #{tmpsolrdir} exists'; else mkdir -p #{tmpsolrdir} ; fi"        
         logger.info "DEBUG: cd #{appdir}; wget #{wget_params} \"#{url}\" -O- | tar -zxpf -"   
         
         begin
           run "cd #{tmpsolrdir}; wget #{wget_params} \"#{url}\" -O- | tar -zxpf -"
         rescue
           logger.info "WARN: failing back to a local wget and scp up to the server, this will take a bit more time..."
           `wget #{wget_params} \"#{url}\" -O working/#{name}.tar.gz`
           upload("working/#{name}.tar.gz","#{tmpsolrdir}/#{name}.tar.gz", :via => :scp)
           run "cd #{tmpsolrdir} && tar -zxf #{name}.tar.gz"
           logger.info " Clean up by removing the tarball from the server"
           run "rm -rf #{tmpsolrdir}/#{name}.tar.gz"
         end
         
         run "cd #{tmpsolrdir}; cp -R solr #{appdir}"
         find_and_execute_task ("update_solr_configs")
         run "cd #{tmpsolrdir}; cp -R solr/lib/* #{appdir}/lib/ || true"
         run "cd #{appdir}; rm -R #{tmpsolrdir}"
        solr4_java_args = hiera("solr4_java_args")
        jettystart_string = <<-jettystart
#! /bin/bash
export JAVA_HOME=/usr/java/latest
export PATH=$JAVA_HOME/bin:$PATH
/usr/bin/nohup java -jar \\
  -Djetty.port=#{web_port} \\
  #{solr4_java_args} \\
  -Xdebug \\
  -Djava.security.egd=file:///dev/urandom \\
  -XX:MaxPermSize=#{permgenspace}m \\
  -XX:+UseConcMarkSweepGC \\
  -XX:+CMSClassUnloadingEnabled \\
  -XX:+DisableExplicitGC \\
  #{'-XX:ParallelGCThreads=3' if ( confType.include?("ch2")) } \\
  -Dnet.sf.ehcache.skipUpdateCheck=true \\
  -Dhibernate.jdbc.use_scrollable_resultset=true \\
  -verbose:gc -XX:+PrintGCDateStamps -XX:+PrintGCDetails -Xloggc:#{appdir}/logs/gc.log \\
  -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=#{appdir}/logs/#{name}-`date +%Y_%m_%d-%H_%M`.heapDump \\
  start.jar > /dev/null  2>&1 &
echo $! > $APP_PID
jettystart
         
         upload(StringIO.new(jettystart_string),"#{appdir}/jetty.sh", :via => :scp, :mode => 0775)
         
         log4j_properties_str = <<-LOG4J
#  Logging level
solr.log=logs/
log4j.rootLogger=INFO, file, CONSOLE

log4j.appender.CONSOLE=org.apache.log4j.ConsoleAppender

log4j.appender.CONSOLE.layout=org.apache.log4j.PatternLayout
log4j.appender.CONSOLE.layout.ConversionPattern=%-4r [%t] %-5p %c %x \u2013 %m%n

#- size rotation with log cleanup.
log4j.appender.file=org.apache.log4j.RollingFileAppender
log4j.appender.file.MaxFileSize=40MB
log4j.appender.file.MaxBackupIndex=9

#- File to log to and log format
log4j.appender.file.File=${solr.log}/solr.log
log4j.appender.file.layout=org.apache.log4j.PatternLayout
log4j.appender.file.layout.ConversionPattern=%-5p - %d{yyyy-MM-dd HH:mm:ss.SSS}; %C; %m\n

log4j.logger.org.apache=ERROR
log4j.logger.org.apache.zookeeper=WARN
log4j.logger.org.apache.hadoop=WARN

# set to INFO to enable infostream log messages
log4j.logger.org.apache.solr.update.LoggingInfoStream=OFF
LOG4J
        upload(StringIO.new(log4j_properties_str),"#{appdir}/resources/log4j.properties", :via => :scp, :mode => 0644)
         
         
         run "sudo /sbin/chkconfig --add merlinsolr"
         find_and_execute_task ("start_merlin_solr")
      end
      
      
      task :update_solr_jetty_xml do

      jetty_xml = <<-here
<?xml version="1.0"?>
<!DOCTYPE Configure PUBLIC "-//Jetty//Configure//EN" "http://www.eclipse.org/jetty/configure.dtd">

      <!-- =============================================================== -->
      <!-- Configure the Jetty Server                                      -->
      <!--                                                                 -->
      <!-- Documentation of this file format can be found at:              -->
      <!-- http://wiki.eclipse.org/Jetty/Reference/jetty.xml_syntax        -->
      <!--                                                                 -->
      <!-- =============================================================== -->


      <Configure id="Server" class="org.eclipse.jetty.server.Server">

          <!-- =========================================================== -->
          <!-- Server Thread Pool                                          -->
          <!-- =========================================================== -->
          <Set name="ThreadPool">
            <!-- Default queued blocking threadpool -->
            <New class="org.eclipse.jetty.util.thread.QueuedThreadPool">
              <Set name="minThreads">10</Set>
              <Set name="maxThreads">10000</Set>
              <Set name="detailedDump">false</Set>
            </New>
          </Set>

          <!-- =========================================================== -->
          <!-- Set connectors                                              -->
          <!-- =========================================================== -->

        <!--
          <Call name="addConnector">
            <Arg>
                <New class="org.eclipse.jetty.server.nio.SelectChannelConnector">
                  <Set name="host"><SystemProperty name="jetty.host" /></Set>
                  <Set name="port"><SystemProperty name="jetty.port" default="8983"/></Set>
                  <Set name="maxIdleTime">50000</Set>
                  <Set name="Acceptors">2</Set>
                  <Set name="statsOn">false</Set>
                  <Set name="confidentialPort">8443</Set>
      	    <Set name="lowResourcesConnections">5000</Set>
      	    <Set name="lowResourcesMaxIdleTime">5000</Set>
                </New>
            </Arg>
          </Call>
        -->

          <!-- This connector is currently being used for Solr because it
                showed better performance than nio.SelectChannelConnector
                for typical Solr requests.  -->
          <Call name="addConnector">
            <Arg>
                <New class="org.eclipse.jetty.server.bio.SocketConnector">
                  <Set name="host"><SystemProperty name="jetty.host" /></Set>
                  <Set name="port"><SystemProperty name="jetty.port" default="8983"/></Set>
                  <Set name="maxIdleTime">50000</Set>
                  <Set name="lowResourceMaxIdleTime">1500</Set>
                  <Set name="statsOn">false</Set>
      			<Set name="requestHeaderSize">8192</Set> 
                </New>
            </Arg>
          </Call>

          <!-- if the connector below is uncommented, then jetty will also accept SSL
               connections on port 8984, using a self signed certificate and can 
               optionally require the client to authenticate with a certificate. 
               (which can be the same as the server certificate_
         
               # Run solr example with SSL on port 8984
               java -jar start.jar
               # 
               # Run post.jar so that it trusts the server cert...
               java -Djavax.net.ssl.trustStore=../etc/solrtest.keystore -Durl=https://localhost:8984/solr/update -jar post.jar *.xml

               # Run solr example with SSL requiring client certs on port 8984
               java -Djetty.ssl.clientAuth=true -jar start.jar
               #
               # Run post.jar so that it trusts the server cert, 
               # and authenticates with a client cert
               java -Djavax.net.ssl.keyStorePassword=secret -Djavax.net.ssl.keyStore=../etc/solrtest.keystore -Djavax.net.ssl.trustStore=../etc/solrtest.keystore -Durl=https://localhost:8984/solr/update -jar post.jar *.xml

          -->
          <!--
          <Call name="addConnector">
            <Arg>
              <New class="org.eclipse.jetty.server.ssl.SslSelectChannelConnector">
                <Arg>
                  <New class="org.eclipse.jetty.http.ssl.SslContextFactory">
                    <Set name="keyStore"><SystemProperty name="jetty.home" default="."/>/etc/solrtest.keystore</Set>
                    <Set name="keyStorePassword">secret</Set>
                    <Set name="needClientAuth"><SystemProperty name="jetty.ssl.clientAuth" default="false"/></Set>
                  </New>
                </Arg>
                <Set name="port"><SystemProperty name="jetty.ssl.port" default="8984"/></Set>
                <Set name="maxIdleTime">30000</Set>
              </New>
            </Arg>
          </Call>
          -->

          <!-- =========================================================== -->
          <!-- Set handler Collection Structure                            --> 
          <!-- =========================================================== -->
          <Set name="handler">
            <New id="Handlers" class="org.eclipse.jetty.server.handler.HandlerCollection">
              <Set name="handlers">
               <Array type="org.eclipse.jetty.server.Handler">
                 <Item>
                   <New id="Contexts" class="org.eclipse.jetty.server.handler.ContextHandlerCollection"/>
                 </Item>
                 <Item>
                   <New id="DefaultHandler" class="org.eclipse.jetty.server.handler.DefaultHandler"/>
                 </Item>
                 <Item>
                   <New id="RequestLog" class="org.eclipse.jetty.server.handler.RequestLogHandler"/>
                 </Item>
               </Array>
              </Set>
            </New>
          </Set>
    
          <!-- =========================================================== -->
          <!-- Configure Request Log                                       -->
          <!-- =========================================================== -->
          <!-- 
          <Ref id="Handlers">
            <Call name="addHandler">
              <Arg>
                <New id="RequestLog" class="org.eclipse.jetty.server.handler.RequestLogHandler">
                  <Set name="requestLog">
                    <New id="RequestLogImpl" class="org.eclipse.jetty.server.NCSARequestLog">
                      <Set name="filename">
                         logs/request.yyyy_mm_dd.log
                      </Set>
                      <Set name="filenameDateFormat">yyyy_MM_dd</Set>
                      <Set name="retainDays">90</Set>
                      <Set name="append">true</Set>
                      <Set name="extended">false</Set>
                      <Set name="logCookies">false</Set>
                      <Set name="LogTimeZone">UTC</Set>
                    </New>
                  </Set>
                </New>
              </Arg>
            </Call>
          </Ref>
          -->

          <!-- =========================================================== -->
          <!-- extra options                                               -->
          <!-- =========================================================== -->
          <Set name="stopAtShutdown">true</Set>
          <Set name="sendServerVersion">false</Set>
          <Set name="sendDateHeader">false</Set>
          <Set name="gracefulShutdown">1000</Set>
          <Set name="dumpAfterStart">false</Set>
          <Set name="dumpBeforeStop">false</Set>




          <Call name="addBean">
            <Arg>
              <New id="DeploymentManager" class="org.eclipse.jetty.deploy.DeploymentManager">
                <Set name="contexts">
                  <Ref id="Contexts" />
                </Set>
                <Call name="setContextAttribute">
                  <Arg>org.eclipse.jetty.server.webapp.ContainerIncludeJarPattern</Arg>
                  <Arg>.*/servlet-api-[^/]*\.jar$</Arg>
                </Call>
          
          
                <!-- Add a customize step to the deployment lifecycle -->
                <!-- uncomment and replace DebugBinding with your extended AppLifeCycle.Binding class 
                <Call name="insertLifeCycleNode">
                  <Arg>deployed</Arg>
                  <Arg>starting</Arg>
                  <Arg>customise</Arg>
                </Call>
                <Call name="addLifeCycleBinding">
                  <Arg>
                    <New class="org.eclipse.jetty.deploy.bindings.DebugBinding">
                      <Arg>customise</Arg>
                    </New>
                  </Arg>
                </Call>
                -->
          
              </New>
            </Arg>
          </Call>
          
          <Call name="addBean">
                <Arg>
                  <New class="org.eclipse.jetty.security.HashLoginService">
                    <Set name="name">Auth</Set>
                    <Set name="config"><SystemProperty name="jetty.home" default="."/>/etc/realm.properties</Set>
                    <Set name="refreshInterval">0</Set>
                  </New>
                </Arg>
              </Call>
    
          <Ref id="DeploymentManager">
            <Call name="addAppProvider">
              <Arg>
                <New class="org.eclipse.jetty.deploy.providers.ContextProvider">
                  <Set name="monitoredDirName"><SystemProperty name="jetty.home" default="."/>/contexts</Set>
                  <Set name="scanInterval">0</Set>
                </New>
              </Arg>
            </Call>
          </Ref>

</Configure>
here

      File.open("working/jetty.xml.new", 'w') {|f| f.write(jetty_xml) }
      upload("working/jetty.xml.new","/opt/solr/etc/jetty.xml")
      end # end of update_solr_jetty_xml task     
      
      

#################################
#
# Stop solr
#
#

      task :stop_merlin_solr do
         run "sudo /etc/init.d/merlinsolr stop"
      end

#################################
#
# start solr
#
#

      task :start_merlin_solr do
         run "sudo /etc/init.d/merlinsolr start"
      end
      
#################################
#
# update configs
#
#

      task :update_solr_configs do
                if "#{replication}" == "master"
                       logger.info ">>>>>>>>>>>>>>>>>>>>>> configuring a 'master' solr server"
                       repxml = <<-HERE
                       <!--
                       added by capistrano
                       -->
                       <requestHandler name="/replication" class="solr.ReplicationHandler" >
                           <lst name="master">
                             <str name="replicateAfter">commit</str>
                             <str name="replicateAfter">startup</str>
                             <str name="confFiles">schema.xml</str>
                           </lst>
                       </requestHandler>

                       HERE
                 end
                 
                 if "#{replication}" == "slave"
                   
                  # myPort = hiera('entityIndex_web_port')
                   myPort = hiera("#{app}_web_port")
                   solr_core_name="\${solr.core.name}/"
                   schema_solr_core_name="_\${solr.core.name}"
                   
                   
                   logger.info "configuring a 'slave' solr server"
                    repxml = <<-HERE
                 <!--
                  added by capistrano
                  -->
                  <requestHandler name="/replication" class="solr.ReplicationHandler" >
                      <lst name="slave">
                        <str name="masterUrl">http://#{solrMaster}:#{myPort}/solr/#{solr_core_name}replication</str>
                        <str name="pollInterval">00:00:10</str>
                      </lst>
                  </requestHandler>

                  HERE
                  
                end

                 if "#{replication}" == "repeater"
                   
                  # myPort = hiera('entityIndex_web_port')
                   myPort = hiera("#{app}_web_port")
                   solr_core_name="\${solr.core.name}/"
                   schema_solr_core_name="_\${solr.core.name}"
                   
                   
                   logger.info "configuring a 'slave' solr server"
                    repxml = <<-HERE
                 <!--
                  added by capistrano
                  -->
                  <requestHandler name="/replication" class="solr.ReplicationHandler" >
                      <lst name="master">
                         <str name="replicateAfter">commit</str>
                         <str name="replicateAfter">startup</str>
                         <str name="confFiles">schema.xml</str>
                       </lst>
                      <lst name="slave">
                        <str name="masterUrl">http://#{solrMaster}:#{myPort}/solr/#{solr_core_name}replication</str>
                        <str name="pollInterval">00:00:10</str>
                      </lst>
                  </requestHandler>

                  HERE
                  
                end                 

                 solrcores.each do |core|
                   
                   puts core.inspect
                   
                   set :corename, remove_quotations(core.inspect)
                   
                   
                   
                   if "#{corename}" == "rovi_programs"


                                   regex=""
                                   regex_commented=""

                                   ########################################
                                   # Rovi _Programs core.prperties substitutions
                                   ########################################
                                       # all these settings are now in hiera
                                      rovi_config_overrides = hiera('rovicore_properties', :hash)


                                       rovi_config_overrides.each do |key, value|
                                           key = key.gsub(/\./, "\\.")
                                           key = key.gsub(/\-/, "\\-")
                                           key = key.gsub(/\,/, "\\,")
                                           key = key.gsub(/\//, "\\/")
                                           key = key.gsub(/\@/, "\\@")
                                           value = value.to_s.gsub(/\./, "\\.")
                                           value = value.to_s.gsub(/\-/, "\\-")
                                           value = value.to_s.gsub(/\,/, "\\,")
                                           value = value.to_s.gsub(/\//, "\\/")
                                           value = value.to_s.gsub(/\@/, "\\@")
                                           regex = regex + "s/^\s*#{key}=.*/#CAPIFIED\n#{key}=#{value}/g ; "
                                           regex_commented = regex_commented + "s/^\s*#\s*#{key}=.*/#CAPIFIED\n##{key}=#{value}/g ; "
                                       end


                                       run "perl -pi -e '#{regex}' /opt/solr/solr/rovi_programs/core.properties"
                                       run "perl -pi -e '#{regex_commented}' /opt/solr/solr/rovi_programs/core.properties"
                   
                   
                      end
                   
                   
                                                      
                  download("/opt/solr/solr/#{corename}/conf/solrconfig.xml","working/solrconfig.xml.#{corename}", :via => :scp)
                      
                      
                      logger.info "just pulled the solrconfig.xml"                  
                  
                    
                     io = File.open( "working/solrconfig.xml.#{corename}", 'r')
                      solrConfig = Nokogiri::XML(io)
                      io.close
                      solrConfig.search("config").each do |here|
                      here.add_child(repxml)
                    end
                                            

                     File.open("working/solrconfig.xml.#{corename}.new", 'w') {|f| f.write(solrConfig) }
 
                      
                      upload_if_needed("working/solrconfig.xml.#{corename}.new", "/opt/solr/solr/#{corename}/conf/solrconfig.xml")
                  
                     
                 end
                 
                  
                 
               end   
               
               
               def remove_quotations(str)
                 if str.starts_with?('"')
                   str = str.slice(1..-1)
                 end
                 if str.ends_with?('"')
                   str = str.slice(0..-2)
                 end
               end      

      desc "used to deploy #{name}"
      task "deploy_#{name}_#{env}".to_sym do
       eval("#{env}_#{name}")
       
       set :appdir, "/opt/solr"
       set :tmpsolrdir, "/opt/solr/tmp"
      
       run_serially_in_batches(:find_server_opts => {:roles => "#{name}".to_sym}) do |server_options|
        set :replication, server_options[:replication]   
        set :server_option_master, server_options[:master]
        set :solrcores, server_options[:solr_cores]
     
        logger.info "DEBUG URL: http://#{solrMaster}:"
        
        find_and_execute_task ("#{name}_main_#{env}")

       end
      end
  end #end Services iteration block

logger.info ">>>>> loaded solr4"
