[svc].each do |name|

    desc "called by #{env}_#{name} in #{env}.rb"
    task "#{name}_main_#{env}".to_sym do
      logger.level = Capistrano::Logger::INFO
      logger.info "DEBUG: TASK: #{name}_main_#{env}"

       #### check_versions will check for and install the items in the depends variable ####
      logger.info ">>>>>>>>> About to start check_versions"
      check_versions
      logger.info ">>>>>>>>> About to start check_curl"
      check_curl
      set :app, "#{name}"
          
       # set this here, since the RPM will install it here
      if "#{name}" .eql?("commerceDataService") ; then
        set :install_path, "/opt/ds/jetty-#{svcHome}"
      else
        set :install_path, "/opt/ds/#{svcHome}"
      end  
      set :web_port, hiera("#{name}_web_port")
      set :jmx_port, hiera("#{name}_jmx_port") || "4999"
      set :alive_path, hiera("#{name}_alive") || "healthCheck"
      
 logger.info " "   
 logger.info " "
       logger.info "VARIABLES SET FOR THIS RUN: "
       logger.info "________________________________________"
       logger.info "env      = #{env} "
       logger.info "name         = #{name} "
       logger.info "app          = #{app}    " 
       logger.info "install_path = #{install_path} "
       logger.info "user         = #{user} "
       logger.info "web_port     = #{web_port} "
       logger.info "jmx_port     = #{jmx_port} "
       logger.info "alive_path   = #{alive_path} "
       logger.info "________________________________________"
 logger.info " "
 logger.info " "
 logger.info " "

 #################################
 #
 # Read BOM
 #
 #

      logger.info "DEBUG: about to read_bom"

      if exists?(:noBom) or exists?(:nobom)
        logger.info "skipping read bom"
      else
        read_bom
      end

      if exists?(:cleanServer) && cleanServer.to_s == "true"
        logger.info "DEBUG: called cleanServer - going to remove #{install_path} "
        run "[ -d #{install_path} ] && sudo rm -rf #{install_path}; exit 0"
        logger.info "DEBUG: just deleted #{install_path} from system"
      else   
        logger.info "Not a CleanServer install !!!"  
      end
       
       # this task calls the RPM deploy logic below
      logger.info "STARTING MAIN INSTALL ('copy') task - install via RPM ..................................................."
      find_and_execute_task("copy_#{name}_#{env}")
      logger.info "OUT STARTING MAIN INSTALL (copy) Task ..................................................................."

  


      if "#{startService}" == "false"
        logger.info "Not starting #{name} due to startService=#{startService}"
      else
        find_and_execute_task("start_#{name}")
      end
       
      if exists?(:skip_alive)
        logger.info ">>>>>>>>>>>>>>>>>>>>>>>>**** skip_alive set, skipping alive checks"
      else
        logger.info "Running alive check.."
        alive
      end
    
    end # MAIN TASK

     

######### Start Service Task ###################################

    desc "called by #{name}_main_#{env}"
    task "start_#{name}".to_sym do
 	    run "sudo /etc/init.d/#{svcHome} start ; sleep 5"
    end 


     
######### Deploy Task ###########################################

    desc "used to deploy #{name}_#{env}"
    task "deploy_#{name}_#{env}".to_sym do
      set :app, name
      logger.level = Capistrano::Logger::INFO
      logger.info "M1 TASK: deploy_#{name}_#{env}.to_sym do"
      logger.info "DEBUG: env-->#{env}<  name/app-->#{name}< "
      eval("#{env}_#{name}")
      find_servers(:roles => "#{name}".to_sym).each do |server|
        ENV['HOSTS'] = "#{server.host}"
        set :startService, server.options[:startService]
        set :startServiceAtBoot, server.options[:startServiceAtBoot]
        find_and_execute_task ("#{name}_main_#{env}")
      end
    end # task "deploy_#{name}_#{env}".to_sym do



######### Deploy RPM Task #######################################  
  
    desc "called by #{name}_main_#{env}"
    task "copy_#{name}_#{env}".to_sym do
      logger.info "M2 TASK: copy_#{name}_#{env}.to_sym do"
      logger.info "stopping service"
      run "[ -f /etc/init.d/#{svcHome} ] && sudo /etc/init.d/#{svcHome} stop ;sleep 15; exit 0"
      logger.info "sudo /etc/init.d/#{svcHome} stop"
      
      set(:url) do
        Capistrano::CLI.ui.ask "Enter URL to rpm builder:"
      end unless variables[:url]
   
      run "sudo rpm -Uv --force #{url}"       
      logger.info "installing rpm into #{install_path}"  
      find_and_execute_task("updateConfig_#{name}_#{env}")
      logger.info "TASK: END"

    end # task "copy_#{name}_#{env}".to_sym d


##################################################################
#
# UPDATE CONFIG


    desc "called by copy_#{name}_#{env} to search and replace the sample"
    task "updateConfig_#{name}_#{env}".to_sym do

      if exists?(:useLocalWorking) && useLocalWorking == true
     
      else
      
        if "#{name}" .eql?("commerceDataService") ; then
          (logger.info "Backing up the property file"
          run "if [ -e #{install_path}/config/#{propertyFile} ]; then sudo cp #{install_path}/config/#{propertyFile} #{install_path}/config/#{propertyFile}.cap.bk ; fi"
          logger.info "Copying over the sample props file to the real one"
          run "if [ -e #{install_path}/config/#{propertyFile}.sample ]; then sudo cp #{install_path}/config/#{propertyFile}.sample #{install_path}/config/#{propertyFile} ; fi"
          logger.info "Copy over the sample logback xml file if and only if logback.xml doesn't exist"
          run "if [ ! -e #{install_path}/config/logback.xml ]; then sudo cp #{install_path}/config/logback.xml.sample #{install_path}/config/logback.xml ; fi")
        
        find_and_execute_task ("update_config_edn")
       
       
        else
          
          (logger.info "Backing up the property file"
          run "if [ -e #{install_path}/conf/#{propertyFile} ]; then sudo cp #{install_path}/conf/#{propertyFile} #{install_path}/conf/#{propertyFile}.cap.bk ; fi"
          logger.info "Copying over the sample props file to the real one"
          run "if [ -e #{install_path}/conf/#{propertyFile}.sample ]; then sudo cp #{install_path}/conf/#{propertyFile}.sample #{install_path}/conf/#{propertyFile} ; fi"
          logger.info "Copying over hazelcast config xml from backup"
          run "if [ -e #{install_path}/conf/hazelcast-config.xml.bk ]; then sudo cp #{install_path}/conf/hazelcast-config.xml.bk #{install_path}/conf/hazelcast-config.xml ; fi"
          logger.info "Copy over the sample logback xml file if and only if logback.xml doesn't exist"
          run "if [ ! -e #{install_path}/conf/logback.xml ]; then sudo cp #{install_path}/conf/logback.xml.sample #{install_path}/conf/logback.xml ; fi")
        end  
      
        
      end #if exists?(:useLocalWorking) && useLocalWorking == true


      #####################
      # SUBSTITUTION MAGIC
      #####################
      # Start with a blank regex string
      logger.info "DEBUG: starting substitution config_overrides for #{name}"
      
      regex=""
      regex_commented=""
      
      ########################################
      # Properties substitutions
      ########################################
          # all these settings are now in hiera
      config_overrides = hiera("#{name}_properties", :hash)
      config_overrides.each do |key, value|
        key = key.gsub(/\./, "\\.")
        key = key.gsub(/\-/, "\\-")
        key = key.gsub(/\,/, "\\,")
        key = key.gsub(/\//, "\\/")
        key = key.gsub(/\@/, "\\@")
        value = value.gsub(/\./, "\\.")
        value = value.gsub(/\-/, "\\-")
        value = value.gsub(/\,/, "\\,")
        value = value.gsub(/\//, "\\/")
        value = value.gsub(/\@/, "\\@")
        regex = regex + "s/^\s*#{key}=.*/#CAPIFIED\n#{key}=#{value}/g ; "
        regex_commented = regex_commented + "s/^\s*#\s*#{key}=.*/#CAPIFIED\n#{key}=#{value}/g ; "
      end
          
      if "#{name}" .eql?("commerceDataService") ; then
        run "sudo perl -pi -e '#{regex}' /opt/ds/jetty-#{svcHome}/config/#{propertyFile}"
        run "sudo perl -pi -e '#{regex_commented}' /opt/ds/jetty-#{svcHome}/config/#{propertyFile}"
        global_config_injections =  config_overrides.merge(hiera("#{name}_properties",:hash))
        global_config_injections.delete_if {|key, value| value=="REMOVE_KEY"}
        global_config_injections.sort.each do |key, value|
          run "if grep -q '^#{key}=' /opt/ds/jetty-#{svcHome}/config/#{propertyFile} ; then echo \"#{key}= is already present\" ; else sudo echo -e \"\\n#{key}=#{value}\" >> /opt/ds/jetty-#{svcHome}/config/#{propertyFile} ; fi ;"
        end  
      else
        run "sudo perl -pi -e '#{regex}' /opt/ds/#{svcHome}/conf/#{propertyFile}"
        run "sudo perl -pi -e '#{regex_commented}' /opt/ds/#{svcHome}/conf/#{propertyFile}"
        global_config_injections =  config_overrides.merge(hiera("#{name}_properties",:hash))
        global_config_injections.delete_if {|key, value| value=="REMOVE_KEY"}
        global_config_injections.sort.each do |key, value|
          run "if grep -q '^#{key}=' /opt/ds/#{svcHome}/conf/#{propertyFile} ; then echo \"#{key}= is already present\" ; else sudo echo -e \"\\n#{key}=#{value}\" >> /opt/ds/#{svcHome}/conf/#{propertyFile} ; fi ;"
        end
      end  
    end  
    
    task :update_config_edn do
   
      config_edn = <<-here
      {:axon

       {:io {:http {:pool {:timeout 15
                           :threads 5}}}

        :backoff {:initial-wait-ms 1
                  :max-wait-ms 120
                  :wait-fn (fn [ms] (* ms 2))}

        :source {:xbo {:aws
                       {:access-key "AKIAIT6BQRDRENPMSQ4Q"
                        :secret-key "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"
                        :region "us-east-1"
                        :visiblity-timeout-sec 30
                        :queue "compass-demo"}

                       :partner "Comcast"}

                 :rtve {:aws
                        {:access-key "AKIAJQA4TZANGWS4XOKQ"
                         :secret-key "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"
                         :region "us-east-1"
                         :visiblity-timeout-sec 30
                         :queue "PRD_BillerUpdate_RPIL"}

                        :aes-key "hZBp1yD/qkHT1ofHI+4SMN/oESbWJ+yC"}

                 :persona {:url "http://udbps.g.comcast.net/availabilityTags"}

                 :wpil {:url "http://ccpmer-phl-v001-d.compass.chalybs.net:9015/partnerIngestWebService/web/subscriberIngest?schema=1.0"
                        :codebig-key ["X-Codebig-Principal" "/foo/bar/czwt9y5bp5dhwh2x7fthuzsw"]
                        :batch-size 50
                        :crn-prefix {:xbo "comcast:xcalibur:xbo:" :entitlement "comcast:merlin:Offer:Entitlement:"}}

                 :es {:url-template "http://entapp-po-a1p.sys.comcast.net:7011/EntitlementService/account?billingAccountNum=%s&responseElements=acc,resAll,user,chm,sa,rcad,udata"
                      :headers {"X-sourceSystemId" "ES-UDB"}
                      :es-xml-paths {:path-to-node-id [:Accounts :Account :ServiceLocationInfo :NodeId]
                                     :path-to-location-id [:Accounts :Account :ServiceLocationInfo :Id]
                                     :path-to-zip [:Accounts :Account :ServiceLocationInfo :Zip]
                                     :path-to-zip4 [:Accounts :Account :ServiceLocationInfo :Zip4]
                                     :path-to-billing-sys-id [:Accounts :Account :BillingSystemId]
                                     :id-path [:Accounts :Account :Id]
                                     :account-id-path [:Accounts :Account :Number]
                                     :account-epc-codes-path [:Accounts :Account :AccountProducts :ProductInfo :Number]}}

                 :eloc {:url "jdbc:oracle:thin:@10.253.15.4:1521:merdev"
                        :username "rpiluser"
                        :password "rpilpass"}}}

       :shubao {:client-mode? false                                    ;; if true, will use a hz client to connect to hz cluster
                :hz-client {:hosts ["0.0.0.0"]                         ;; will have real IP/hosnames
                            :retry-ms 5000                             ;; time between reconnect tries
                            :retry-max 720000}                         ;; 720000 * 5000 = one hour
                :tracker "shubao-tracker"
                :data-service {:ingest {:limit 20000}
                               :entity {:url "http://ccpmer-po-v003-p.po.ccp.cable.comcast.com:9002/entityDataService"
                                        :ingest-batch-size 1000
                                        :subscribe-to-notifications? false}
                               :linear {:url "http://ccpmer-po-v003-p.po.ccp.cable.comcast.com:9003/linearDataService"
                                        :ingest-batch-size 1000
                                        :subscribe-to-notifications? false}
                               :location {:url "http://ccpmer-po-v003-p.po.ccp.cable.comcast.com:9037/locationDataService" ;; "http://mwsprod.ccp.xcal.tv:9037/locationDataService"
                                          :ingest-batch-size 1000
                                          :subscribe-to-notifications? false}
                               :commerce {:url "http://10.252.241.35:10118/commerceDataService"
                                          :ingest-batch-size 1000
                                          :id-form :none
                                          :subscribe-to-notifications? false}
                               :offer {:url "http://ccpmer-po-v003-p.po.ccp.cable.comcast.com:9023/offerDataService"
                                       :ingest-batch-size 1000
                                       :subscribe-to-notifications? false}}}}
   
      here
   
      File.open("working/config.edn.new", 'w') {|f| f.write(config_edn) }
      upload("working/config.edn.new","/opt/ds/jetty-#{svcHome}/config/config.edn.new")
   
  
     end 
    
    
end #end Services iteration block

logger.info ">>>>> loaded ngbServices"