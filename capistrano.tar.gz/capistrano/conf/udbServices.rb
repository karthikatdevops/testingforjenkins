########
# README
#
# this is a little funky - we need to use the xdeploy user for call cap deployment commands,
#  but the RPMs install services as the 'unu' user so make sure that all scripts dirs etc
#  are properly set to be own by unu and any scripts created by cap also reference the 'unu'
#  user inside them.


[svc].each do |name|

    desc "called by #{env}_#{name} in #{env}.rb"
    task "#{name}_main_#{env}".to_sym do
      logger.level = Capistrano::Logger::INFO
      logger.info "DEBUG: TASK: #{name}_main_#{env}"

      #### check_versions will check for and install the items in the depends variable ####
      logger.info ">>>>>>>>> About to start check_versions"
      check_versions
      logger.info ">>>>>>>>> About to start check_curl"
      check_curl
      set :app, "#{name}"

      # set this here, since the RPM will install it here
      if "#{name}" .eql?("cuUnuServer") ; then
        set :install_path, "/opt/app/#{installdir}"

      elsif "#{name}" .eql?("commerceDataService") ; then
         set :install_path, "/opt/ds/#{svcHome}"

      else
        set :install_path, "/opt/app/#{svcHome}"
      end
      set :web_port, hiera("#{name}_web_port")
      set :jmx_port, hiera("#{name}_jmx_port") || "4999"
      set :debug_port, hiera("#{name}_debug_port") || "5999"
      set :alive_path, hiera("#{name}_alive") || "healthCheck"

logger.info " "
logger.info " "
      logger.info "VARIABLES SET FOR THIS RUN: "
      logger.info "________________________________________"
      logger.info "env      = #{env} "
      logger.info "name         = #{name} "
      logger.info "app          = #{app}    "
      logger.info "install_path = #{install_path} "
      logger.info "user         = #{user} "
      logger.info "web_port     = #{web_port} "
      logger.info "jmx_port     = #{jmx_port} "
      logger.info "debug_port   = #{debug_port} "
      logger.info "alive_path   = #{alive_path} "
      logger.info "________________________________________"
logger.info " "
logger.info " "
logger.info " "


#################################
#
# Read BOM
#
#

      logger.info "DEBUG: about to read_bom"
      if exists?(:noBom) or exists?(:nobom)
        logger.info "skipping read bom"
      else
         read_bom
      end

      if exists?(:cleanServer) && cleanServer.to_s == "true"
        logger.info "DEBUG: called cleanServer - going to remove #{install_path} "
        run "[ -d #{install_path} ] && sudo rm -rf #{install_path}; exit 0"
        logger.info "DEBUG: just deleted #{install_path} from system"
      else
         logger.info "Not a CleanServer install !!!"
      end



#################################
#
# Main Install Routine
#
#
#  1. Deploy service via RPM
#  2. Start the service
#  3. Ensure the service is running (alive)


      # this task calls the RPM deploy logic below
      logger.info "STARTING MAIN INSTALL ('copy') task - install via RPM ..................................................."
      find_and_execute_task("copy_#{name}_#{env}")
      logger.info "FINISHED MAIN INSTALL (copy) Task ..................................................................."



      if "#{startService}" == "false"
        logger.info "Not starting #{name} due to startService=#{startService}"
      else
        find_and_execute_task("start_#{name}")
      end

      if exists?(:skip_alive)
         logger.info ">>>>>>>>>>>>>>>>>>>>>>>>**** skip_alive set, skipping alive checks"
      
      elsif "#{name}" .eql?("shubao") ; then
            logger.info ">>>>>>>>>>>>>>>>>>>>>>>>**** skip_alive set, skipping alive checks"
      else
         logger.info "Running alive check.."
         alive
      end

      if exists?(:executeCI)
         set(:executeCI) do
           Capistrano::CLI.ui.ask "Enter URL to CI Automation test suite:"
         end unless variables[:executeCI]

         run "curl -s -X POST #{executeCI}"
         logger.info "Called CI automation test suite"

      else
        logger.info "No CI Automation available !!!"

      end

    end ###################### MAIN TASK


#########################################################################################################################
# Main Deployment Task is done
#########################################################################################################################


#################################
#
# Start Service
#
#

    desc "called by #{name}_main_#{env}"
    task "start_#{name}".to_sym do
      if app.include?("fandangoIngestService") ; then

        run "sudo /etc/init.d/#{name} start ; sleep 2"

      elsif app.include?("playTimeService") ; then

        run "sudo /etc/init.d/#{name} start ; sleep 2"


      else

	    run "sudo /etc/init.d/#{svcHome} start ; sleep 2"

      end
    end # task "start_#{name}".to_sym do


#################################
#
# Deploy Service (not really used since these are RPM installs)
#
#

    desc "used to deploy #{name}_#{env}"
    task "deploy_#{name}_#{env}".to_sym do
      set :app, name
      logger.level = Capistrano::Logger::INFO
      logger.info "M1 TASK: deploy_#{name}_#{env}.to_sym do"
      logger.info "DEBUG: env-->#{env}<  name/app-->#{name}< "
      eval("#{env}_#{name}")
      find_servers(:roles => "#{name}".to_sym).each do |server|
        ENV['HOSTS'] = "#{server.host}"
        set :startService, server.options[:startService]
        set :startServiceAtBoot, server.options[:startServiceAtBoot]
        find_and_execute_task ("#{name}_main_#{env}")
      end
    end # task "deploy_#{name}_#{env}".to_sym do


#################################
#
# Deploy Service (via RPM)
#
#

    desc "called by #{name}_main_#{env}"
    task "copy_#{name}_#{env}".to_sym do
      logger.info "M2 TASK: copy_#{name}_#{env}.to_sym do"
      logger.info "Installing RPM in this task, calling update config and install init scripts"

      logger.info "stopping service"

      if "#{name}" .eql?("fandangoIngestService") ; then

       run "sudo /etc/init.d/#{name} stop ;sleep 15; exit 0"
       # run "[ -f /etc/init.d/#{name} ] && sudo /etc/init.d/#{name} stop ;sleep 15; exit 0"
        logger.info "sudo /etc/init.d/#{name} stop"

      elsif app.include?("playTimeService") ; then

        run "sudo /etc/init.d/#{name} stop ;sleep 15; exit 0"
       # run "[ -f /etc/init.d/#{name} ] && sudo /etc/init.d/#{name} stop ;sleep 15; exit 0"
        logger.info "sudo /etc/init.d/#{name} stop"

      elsif "#{name}" .eql?("axon") ; then

        run "sudo /etc/init.d/#{svcHome} stop ;sleep 45; exit 0"
        # run "[ -f /etc/init.d/#{svcHome} ] && sudo /etc/init.d/#{svcHome} stop ;sleep 60; exit 0"
        logger.info "sudo /etc/init.d/#{svcHome} stop"

      else

        run "sudo /etc/init.d/#{svcHome} stop ;sleep 15; exit 0"
        # run "[ -f /etc/init.d/#{svcHome} ] && sudo /etc/init.d/#{svcHome} stop ;sleep 60; exit 0"
        logger.info "sudo /etc/init.d/#{svcHome} stop"

      end


      set(:url) do
        Capistrano::CLI.ui.ask "Enter URL to rpm builder:"
      end unless variables[:url]

      logger.info "installing rpm into #{install_path}"
      begin
      run "sudo rpm -Uv --force #{url}"
      rescue
        logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
        `wget #{wget_params} \"#{url}\" -O working/#{name}.rpm`
        upload("working/#{name}.rpm","/var/tmp/#{name}.rpm", :via => :scp)
        run "cd /var/tmp && sudo rpm -Uv --force #{name}.rpm"
        logger.info " Clean up by removing the tarball from the server"
        run "rm -rf /var/tmp/#{name}.rpm"
      end
      logger.info " finished installing rpm into #{install_path}"

      logger.info "TASK: updateConfig +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
      find_and_execute_task("updateConfig_#{name}_#{env}")
      logger.info "> OUT updateConfig+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

      if "#{hazelcast}" == "true"

        logger.info "TASK: update hazelcast +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

        find_and_execute_task("update_hazelcast_xml")

        logger.info "> OUT update hazelcast+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

       else

         logger.info "+++++++this service does not use hazelcast++++++"

       end


      if exists?(:merlinStartup) && merlinStartup.to_s == "true" || "#{app}" == "playTimeService" || "#{app}" == "fandangoIngestService"
        logger.info "TASK: setup_udb_initd_and_wrapper +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
      find_and_execute_task("setup_udb_initd_and_wrapper_#{name}")
      logger.info "> OUT setup_udb_initd_and_wrapper +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

      else
         logger.info "<<<>>>>> <>>>>>>> Using init.d and wrapper from RPM !!! +++++++++++++++++++++++++++++++++++++++++++++++"
      end


      logger.info "TASK: END"
    end # task "copy_#{name}_#{env}".to_sym d



#################################
#
# UPDATE CONFIG
#
#
    desc "called by copy_#{name}_#{env} to search and replace the sample"
    task "updateConfig_#{name}_#{env}".to_sym do

       if "#{name}" .eql?("axon") ; then
         find_and_execute_task("update_config_edn")
        
        elsif "#{name}" .eql?("shubao") ; then
        
         logger.info "using existing config,ed from rpm"
       
       else
         logger.info "This is all I could do..... I'm not axon"

      if exists?(:useLocalWorking) && useLocalWorking == true
        logger.info "Why would use use local stuff?"
      else
        logger.info "Backing up the property file"
        run "if [ -e '#{install_path}/conf/#{propertyFile}' ]; then sudo cp #{install_path}/conf/#{propertyFile} #{install_path}/conf/#{propertyFile}.cap.bk ; fi"
        logger.info "Copy over the sample prop file"
        run "if [ -e #{install_path}/conf/#{propertyFile}.sample ]; then sudo cp #{install_path}/conf/#{propertyFile}.sample #{install_path}/conf/#{propertyFile} ; fi"
        logger.info "Copying over hazelcast config xml from backup"
        run "if [ -e #{install_path}/conf/hazelcast-config.xml.bk ]; then sudo cp #{install_path}/conf/hazelcast-config.xml.bk #{install_path}/conf/hazelcast-config.xml ; fi"

        run "if [ -e '#{install_path}/config/#{propertyFile}' ]; then sudo cp #{install_path}/config/#{propertyFile} #{install_path}/config/#{propertyFile}.cap.bk ; fi"
        run "if [ -e #{install_path}/config/#{propertyFile}.sample ]; then sudo cp #{install_path}/config/#{propertyFile}.sample #{install_path}/config/#{propertyFile} ; fi"
        run "if [ -e #{install_path}/config/hazelcast-config.xml.bk ]; then sudo cp #{install_path}/config/hazelcast-config.xml.bk #{install_path}/config/hazelcast-config.xml ; fi"

        run "if [ -e '#{install_path}/appconfig/#{propertyFile}' ]; then sudo cp #{install_path}/appconfig/#{propertyFile} #{install_path}/appconfig/#{propertyFile}.cap.bk ; fi"
        run "if [ -e #{install_path}/appconfig/#{propertyFile}.sample ]; then sudo cp #{install_path}/appconfig/#{propertyFile}.sample #{install_path}/appconfig/#{propertyFile} ; fi"
        run "if [ -e #{install_path}/appconfig/hazelcast-config.xml.bk ]; then sudo cp #{install_path}/appconfig/hazelcast-config.xml.bk #{install_path}/appconfig/hazelcast-config.xml ; fi"

        if splunkLogging
          #unu ownership need deploy user access to scp logback.xml
          run "sudo chmod 666 #{install_path}/conf/*"
          # make logback.xml

          # inject is the new logback + localfiles with env injection in the files
          # true is to use the TCP Splunk logging (no local files)
          if splunkLogging == "inject"
            find_and_execute_task("createLogback_for_netty")
            logger.info ">>>>> Using UDB local log file with env injection... BITT-8851 "
          else
            find_and_execute_task("create_splunk_logback")
            logger.info ">>>>> Using splunk TCP Logging... "
          end
        else
          logger.info "Copy over the sample logback xml file if and only if logback.xml doesn't exist"
          run "if [  -e #{install_path}/conf/logback.xml ]; then sudo cp #{install_path}/conf/logback.xml.sample #{install_path}/conf/logback.xml ; fi"
          run "if [  -e #{install_path}/config/logback.xml ]; then sudo cp #{install_path}/config/logback.xml.sample #{install_path}/config/logback.xml ; fi"
          run "if [  -e #{install_path}/config/log4j.xml ]; then sudo cp #{install_path}/config/log4j.xml.sample #{install_path}/config/log4j.xml ; fi"
          run "if [  -e #{install_path}/appconfig/logback.xml ]; then sudo cp #{install_path}/appconfig/logback.xml.sample #{install_path}/appconfig/logback.xml ; fi"
          run "sudo chmod 666 #{install_path}/*conf*/#{propertyFile}"
        end
      end #if exists?(:useLocalWorking) && useLocalWorking == true



      #####################
      # SUBSTITUTION MAGIC
      #####################
      # Start with a blank regex string
      logger.info "DEBUG: starting substitution config_overrides for #{name}"

      regex=""
      regex_commented=""

      ########################################
      # Properties substitutions
      ########################################
      config_overrides = hiera("#{name}_properties", :hash)
      if "#{app}".eql?('playTimeService'); then
        config_overrides["cluster.multicast.address"] = generate_cluster_address('ds', hiera('cluster_name'))
      end
      config_overrides.each do |key, value|
        key = key.to_s.gsub(/\./, "\\.")
        key = key.gsub(/\-/, "\\-")
        key = key.gsub(/\,/, "\\,")
        key = key.gsub(/\//, "\\/")
        key = key.gsub(/\@/, "\\@")
        key = key.gsub(/\$/, "\\$")
        value = value.to_s.gsub(/\./, "\\.")
        value = value.gsub(/\-/, "\\-")
        value = value.gsub(/\,/, "\\,")
        value = value.gsub(/\//, "\\/")
        value = value.gsub(/\@/, "\\@")
        value = value.gsub(/\$/, "\\$")
        regex = regex + "s/^\s*#{key}=.*/#CAPIFIED\n#{key}=#{value}/g ; "
        regex_commented = regex_commented + "s/^\s*#*\s*#{key}=.*/#CAPIFIED\n#{key}=#{value}/g ; "
      end

      if "#{name}" .eql?("cuUnuServer") ; then
        run "sudo perl -pi -e '#{regex}' /opt/app/#{installdir}/conf/#{propertyFile}"
        run "sudo perl -pi -e '#{regex_commented}' /opt/app/#{installdir}/conf/#{propertyFile}"
        global_config_injections =  config_overrides.merge(hiera("#{name}_properties",:hash))
        global_config_injections.delete_if {|key, value| value=="REMOVE_KEY"}
        global_config_injections.sort.each do |key, value|
          run "if grep -q '^#{key}=' /opt/app/#{installdir}/conf/#{propertyFile} ; then echo \"#{key}= is already present\" ; else sudo echo -e \"\\n#{key}=#{value}\" >> /opt/app/#{installdir}/conf/#{propertyFile} ; fi ;"
        end
      elsif "#{name}" .eql?("tim") ; then
        run "sudo perl -pi -e \"#{regex}\" /opt/app/#{svcHome}/*conf*/#{propertyFile}"
        run "sudo perl -pi -e \"#{regex_commented}\" /opt/app/#{svcHome}/*conf*/#{propertyFile}"
        global_config_injections =  config_overrides.merge(hiera("#{name}_properties",:hash))
        global_config_injections.delete_if {|key, value| value=="REMOVE_KEY"}
        global_config_injections.sort.each do |key, value|
          run "if grep -q '^#{key}=' /opt/app/#{svcHome}/*conf*/#{propertyFile} ; then echo \"#{key}= is already present\" ; else sudo echo -e \"\\n#{key}=#{value}\" >> /opt/app/#{svcHome}/*conf*/#{propertyFile} ; fi ;"
        end
      elsif "#{name}" .eql?("ngbTimServer") ; then
        run "sudo perl -pi -e \"#{regex}\" /opt/app/#{svcHome}/*conf*/#{propertyFile}"
        run "sudo perl -pi -e \"#{regex_commented}\" /opt/app/#{svcHome}/*conf*/#{propertyFile}"
        global_config_injections =  config_overrides.merge(hiera("#{name}_properties",:hash))
        global_config_injections.delete_if {|key, value| value=="REMOVE_KEY"}
        global_config_injections.sort.each do |key, value|
          run "if grep -q '^#{key}=' /opt/app/#{svcHome}/*conf*/#{propertyFile} ; then echo \"#{key}= is already present\" ; else sudo echo -e \"\\n#{key}=#{value}\" >> /opt/app/#{svcHome}/*conf*/#{propertyFile} ; fi ;"
        end
      elsif "#{name}" .eql?("ngbServerForTim") ; then
        run "sudo perl -pi -e \"#{regex}\" /opt/app/#{svcHome}/*conf*/#{propertyFile}"
        run "sudo perl -pi -e \"#{regex_commented}\" /opt/app/#{svcHome}/*conf*/#{propertyFile}"
        global_config_injections =  config_overrides.merge(hiera("#{name}_properties",:hash))
        global_config_injections.delete_if {|key, value| value=="REMOVE_KEY"}
        global_config_injections.sort.each do |key, value|
          run "if grep -q '^#{key}=' /opt/app/#{svcHome}/*conf*/#{propertyFile} ; then echo \"#{key}= is already present\" ; else sudo echo -e \"\\n#{key}=#{value}\" >> /opt/app/#{svcHome}/*conf*/#{propertyFile} ; fi ;"
        end
      else
         run "sudo perl -pi -e '#{regex}' /opt/app/#{svcHome}/*conf*/#{propertyFile}"
        run "sudo perl -pi -e '#{regex_commented}' /opt/app/#{svcHome}/*conf*/#{propertyFile}"
        global_config_injections =  config_overrides.merge(hiera("#{name}_properties",:hash))
        global_config_injections.delete_if {|key, value| value=="REMOVE_KEY"}
        global_config_injections.sort.each do |key, value|
          run "if grep -q '^#{key}=' /opt/app/#{svcHome}/*conf*/#{propertyFile} ; then echo \"#{key}= is already present\" ; else sudo echo -e \"\\n#{key}=#{value}\" >> /opt/app/#{svcHome}/*conf*/#{propertyFile} ; fi ;"
        end
      end
    end


  end

      task :update_hazelcast_xml do

      hazelcast_xml = <<-here
<?xml version="1.0" encoding="UTF-8"?>
<!--
        ~ Copyright (c) 2008-2013, Hazelcast, Inc. All Rights Reserved.
        ~
        ~ Licensed under the Apache License, Version 2.0 (the "License");
        ~ you may not use this file except in compliance with the License.
        ~ You may obtain a copy of the License at
        ~
        ~ http://www.apache.org/licenses/LICENSE-2.0
        ~
        ~ Unless required by applicable law or agreed to in writing, software
        ~ distributed under the License is distributed on an "AS IS" BASIS,
        ~ WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        ~ See the License for the specific language governing permissions and
        ~ limitations under the License.
        -->

      <hazelcast xsi:schemaLocation="http://www.hazelcast.com/schema/config hazelcast-config-3.2.xsd"
                 xmlns="http://www.hazelcast.com/schema/config"
                 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <group>
              <name>dev</name>
              <password>dev-pass</password>
          </group>
          <management-center enabled="false">http://localhost:8080/mancenter</management-center>
          <network>
              <port auto-increment="true" port-count="100">5701</port>
              <outbound-ports>
                  <!--
                  Allowed port range when connecting to other nodes.
                  0 or * means use system provided port.
                  -->
                  <ports>0</ports>
              </outbound-ports>
              <join>
                  <multicast enabled="false">
                      <multicast-group>224.2.2.3</multicast-group>
                      <multicast-port>54327</multicast-port>
                  </multicast>
                  <tcp-ip enabled="true">
                      <interface>127.0.0.1</interface>
                  </tcp-ip>
                  <aws enabled="false">
                      <access-key>my-access-key</access-key>
                      <secret-key>my-secret-key</secret-key>
                      <!--optional, default is us-east-1 -->
                      <region>us-west-1</region>
                      <!--optional, default is ec2.amazonaws.com. If set, region shouldn't be set as it will override this property -->
                      <host-header>ec2.amazonaws.com</host-header>
                      <!-- optional, only instances belonging to this group will be discovered, default will try all running instances -->
                      <security-group-name>hazelcast-sg</security-group-name>
                      <tag-key>type</tag-key>
                      <tag-value>hz-nodes</tag-value>
                  </aws>
              </join>
              <interfaces enabled="false">
                  <interface>10.10.1.*</interface>
              </interfaces>
              <ssl enabled="false" />
              <socket-interceptor enabled="false" />
              <symmetric-encryption enabled="false">
                  <!--
                     encryption algorithm such as
                     DES/ECB/PKCS5Padding,
                     PBEWithMD5AndDES,
                     AES/CBC/PKCS5Padding,
                     Blowfish,
                     DESede
                  -->
                  <algorithm>PBEWithMD5AndDES</algorithm>
                  <!-- salt value to use when generating the secret key -->
                  <salt>thesalt</salt>
                  <!-- pass phrase to use when generating the secret key -->
                  <password>thepass</password>
                  <!-- iteration count to use when generating the secret key -->
                  <iteration-count>19</iteration-count>
              </symmetric-encryption>
          </network>
          <partition-group enabled="false"/>
          <executor-service name="default">
              <pool-size>16</pool-size>
              <!--Queue capacity. 0 means Integer.MAX_VALUE.-->
              <queue-capacity>0</queue-capacity>
          </executor-service>
          <queue name="default">
              <!--
                  Maximum size of the queue. When a JVM's local queue size reaches the maximum,
                  all put/offer operations will get blocked until the queue size
                  of the JVM goes down below the maximum.
                  Any integer between 0 and Integer.MAX_VALUE. 0 means
                  Integer.MAX_VALUE. Default is 0.
              -->
              <max-size>0</max-size>
              <!--
                  Number of backups. If 1 is set as the backup-count for example,
                  then all entries of the map will be copied to another JVM for
                  fail-safety. 0 means no backup.
              -->
              <backup-count>1</backup-count>

              <!--
                  Number of async backups. 0 means no backup.
              -->
              <async-backup-count>0</async-backup-count>

              <empty-queue-ttl>-1</empty-queue-ttl>
          </queue>
          <map name="default">
              <!--
                 Data type that will be used for storing recordMap.
                 Possible values:
                 BINARY (default): keys and values will be stored as binary data
                 OBJECT : values will be stored in their object forms
                 OFFHEAP : values will be stored in non-heap region of JVM
              -->
              <in-memory-format>BINARY</in-memory-format>

              <!--
                  Number of backups. If 1 is set as the backup-count for example,
                  then all entries of the map will be copied to another JVM for
                  fail-safety. 0 means no backup.
              -->
              <backup-count>1</backup-count>
              <!--
                  Number of async backups. 0 means no backup.
              -->
              <async-backup-count>0</async-backup-count>
              <!--
      			Maximum number of seconds for each entry to stay in the map. Entries that are
      			older than <time-to-live-seconds> and not updated for <time-to-live-seconds>
      			will get automatically evicted from the map.
      			Any integer between 0 and Integer.MAX_VALUE. 0 means infinite. Default is 0.
      		-->
              <time-to-live-seconds>0</time-to-live-seconds>
              <!--
      			Maximum number of seconds for each entry to stay idle in the map. Entries that are
      			idle(not touched) for more than <max-idle-seconds> will get
      			automatically evicted from the map. Entry is touched if get, put or containsKey is called.
      			Any integer between 0 and Integer.MAX_VALUE. 0 means infinite. Default is 0.
      		-->
              <max-idle-seconds>0</max-idle-seconds>
              <!--
                  Valid values are:
                  NONE (no eviction),
                  LRU (Least Recently Used),
                  LFU (Least Frequently Used).
                  NONE is the default.
              -->
              <eviction-policy>NONE</eviction-policy>
              <!--
                  Maximum size of the map. When max size is reached,
                  map is evicted based on the policy defined.
                  Any integer between 0 and Integer.MAX_VALUE. 0 means
                  Integer.MAX_VALUE. Default is 0.
              -->
              <max-size policy="PER_NODE">0</max-size>
              <!--
                  When max. size is reached, specified percentage of
                  the map will be evicted. Any integer between 0 and 100.
                  If 25 is set for example, 25% of the entries will
                  get evicted.
              -->
              <eviction-percentage>25</eviction-percentage>
              <!--
                  While recovering from split-brain (network partitioning),
                  map entries in the small cluster will merge into the bigger cluster
                  based on the policy set here. When an entry merge into the
                  cluster, there might an existing entry with the same key already.
                  Values of these entries might be different for that same key.
                  Which value should be set for the key? Conflict is resolved by
                  the policy set here. Default policy is PutIfAbsentMapMergePolicy

                  There are built-in merge policies such as
                  com.hazelcast.map.merge.PassThroughMergePolicy; entry will be added if there is no existing entry for the key.
                  com.hazelcast.map.merge.PutIfAbsentMapMergePolicy ; entry will be added if the merging entry doesn't exist in the cluster.
                  com.hazelcast.map.merge.HigherHitsMapMergePolicy ; entry with the higher hits wins.
                  com.hazelcast.map.merge.LatestUpdateMapMergePolicy ; entry with the latest update wins.
              -->
              <merge-policy>com.hazelcast.map.merge.PassThroughMergePolicy</merge-policy>

          </map>


          <multimap name="ars-account-details">

              <backup-count>0</backup-count>
              <value-collection-type>SET</value-collection-type>

          </multimap>

          <map name="billing-to-xbo">

              <in-memory-format>BINARY</in-memory-format>
              <backup-count>0</backup-count>
              <async-backup-count>0</async-backup-count>

              <!-- will be refreshed by UES incremental updates -->
              <time-to-live-seconds>0</time-to-live-seconds>

              <max-idle-seconds>0</max-idle-seconds>
              <eviction-policy>NONE</eviction-policy>
              <max-size policy="PER_NODE">0</max-size>
              <eviction-percentage>25</eviction-percentage>
              <merge-policy>com.hazelcast.map.merge.PassThroughMergePolicy</merge-policy>

          </map>

          <map name="xbo-to-billing">

              <in-memory-format>BINARY</in-memory-format>
              <backup-count>1</backup-count>
              <async-backup-count>0</async-backup-count>

              <!-- one week = 604800 seconds -->
              <time-to-live-seconds>604800</time-to-live-seconds>

              <max-idle-seconds>0</max-idle-seconds>
              <eviction-policy>NONE</eviction-policy>
              <max-size policy="PER_NODE">0</max-size>
              <eviction-percentage>25</eviction-percentage>
              <merge-policy>com.hazelcast.map.merge.PassThroughMergePolicy</merge-policy>

          </map>

          <map name="vod-services">

              <in-memory-format>BINARY</in-memory-format>
              <backup-count>1</backup-count>
              <async-backup-count>0</async-backup-count>

              <!-- 23 hours = 82800 seconds -->
              <time-to-live-seconds>82800</time-to-live-seconds>

              <max-idle-seconds>0</max-idle-seconds>
              <eviction-policy>NONE</eviction-policy>
              <max-size policy="PER_NODE">0</max-size>
              <eviction-percentage>25</eviction-percentage>
              <merge-policy>com.hazelcast.map.merge.PassThroughMergePolicy</merge-policy>

          </map>

          <map name="persona">

              <in-memory-format>BINARY</in-memory-format>
              <backup-count>1</backup-count>
              <async-backup-count>0</async-backup-count>

              <!-- 23 hours = 82800 seconds -->
              <time-to-live-seconds>82800</time-to-live-seconds>

              <max-idle-seconds>0</max-idle-seconds>
              <eviction-policy>NONE</eviction-policy>
              <max-size policy="PER_NODE">0</max-size>
              <eviction-percentage>25</eviction-percentage>
              <merge-policy>com.hazelcast.map.merge.PassThroughMergePolicy</merge-policy>

          </map>

          <map name="custom-availability">
              <!--
                 Data type that will be used for storing recordMap.
                 Possible values:
                 BINARY (default): keys and values will be stored as binary data
                 OBJECT : values will be stored in their object forms
                 OFFHEAP : values will be stored in non-heap region of JVM
              -->
              <in-memory-format>BINARY</in-memory-format>

              <!--
                  Number of backups. If 1 is set as the backup-count for example,
                  then all entries of the map will be copied to another JVM for
                  fail-safety. 0 means no backup.
              -->
              <backup-count>1</backup-count>
              <!--
                  Number of async backups. 0 means no backup.
              -->
              <async-backup-count>0</async-backup-count>
              <!--
      			Maximum number of seconds for each entry to stay in the map. Entries that are
      			older than <time-to-live-seconds> and not updated for <time-to-live-seconds>
      			will get automatically evicted from the map.
      			Any integer between 0 and Integer.MAX_VALUE. 0 means infinite. Default is 0.
      		-->
              <time-to-live-seconds>0</time-to-live-seconds>
              <!--
      			Maximum number of seconds for each entry to stay idle in the map. Entries that are
      			idle(not touched) for more than <max-idle-seconds> will get
      			automatically evicted from the map. Entry is touched if get, put or containsKey is called.
      			Any integer between 0 and Integer.MAX_VALUE. 0 means infinite. Default is 0.
      		-->
              <max-idle-seconds>0</max-idle-seconds>
              <!--
                  Valid values are:
                  NONE (no eviction),
                  LRU (Least Recently Used),
                  LFU (Least Frequently Used).
                  NONE is the default.
              -->
              <eviction-policy>NONE</eviction-policy>
              <!--
                  Maximum size of the map. When max size is reached,
                  map is evicted based on the policy defined.
                  Any integer between 0 and Integer.MAX_VALUE. 0 means
                  Integer.MAX_VALUE. Default is 0.
              -->
              <max-size policy="PER_NODE">0</max-size>
              <!--
                  When max. size is reached, specified percentage of
                  the map will be evicted. Any integer between 0 and 100.
                  If 25 is set for example, 25% of the entries will
                  get evicted.
              -->
              <eviction-percentage>25</eviction-percentage>
              <!--
                  While recovering from split-brain (network partitioning),
                  map entries in the small cluster will merge into the bigger cluster
                  based on the policy set here. When an entry merge into the
                  cluster, there might an existing entry with the same key already.
                  Values of these entries might be different for that same key.
                  Which value should be set for the key? Conflict is resolved by
                  the policy set here. Default policy is PutIfAbsentMapMergePolicy

                  There are built-in merge policies such as
                  com.hazelcast.map.merge.PassThroughMergePolicy; entry will be added if there is no existing entry for the key.
                  com.hazelcast.map.merge.PutIfAbsentMapMergePolicy ; entry will be added if the merging entry doesn't exist in the cluster.
                  com.hazelcast.map.merge.HigherHitsMapMergePolicy ; entry with the higher hits wins.
                  com.hazelcast.map.merge.LatestUpdateMapMergePolicy ; entry with the latest update wins.
              -->
              <merge-policy>com.hazelcast.map.merge.PassThroughMergePolicy</merge-policy>

              <map-store enabled="true">
                  <!--
                     Name of the class implementing MapLoader and/or MapStore.
                     The class should implement at least of these interfaces and
                     contain no-argument constructor. Note that the inner classes are not supported.
                  -->
                  <class-name>com.comcast.compass.availability.store.CustomTagFileStore</class-name>
                  <!--
                     Number of seconds to delay to call the MapStore.store(key, value).
                     If the value is zero then it is write-through so MapStore.store(key, value)
                     will be called as soon as the entry is updated.
                     Otherwise it is write-behind so updates will be stored after write-delay-seconds
                     value by calling Hazelcast.storeAll(map). Default value is 0.
                  -->

                  <write-delay-seconds>0</write-delay-seconds>

                  <properties>
                      <property name="db.file.path">/opt/app/#{svcHome}/custom-availability.leveldb</property>
                  </properties>

              </map-store>

          </map>

          <multimap name="default">
              <backup-count>1</backup-count>
              <value-collection-type>SET</value-collection-type>
          </multimap>

          <list name="default">
              <backup-count>1</backup-count>
          </list>

          <set name="default">
              <backup-count>1</backup-count>
          </set>

          <jobtracker name="default">
              <max-thread-size>0</max-thread-size>
              <!-- Queue size 0 means number of partitions * 2 -->
              <queue-size>0</queue-size>
              <retry-count>0</retry-count>
              <chunk-size>1000</chunk-size>
              <communicate-stats>true</communicate-stats>
              <topology-changed-strategy>CANCEL_RUNNING_OPERATION</topology-changed-strategy>
          </jobtracker>

          <semaphore name="default">
              <initial-permits>0</initial-permits>
              <backup-count>1</backup-count>
              <async-backup-count>0</async-backup-count>
          </semaphore>

          <serialization>
              <portable-version>0</portable-version>
          </serialization>

          <properties>
              <property name="hazelcast.logging.type">slf4j</property>
          </properties>

          <services enable-defaults="true" />

      </hazelcast>
      here

      File.open("working/hazelcast-config.xml.new", 'w') {|f| f.write(hazelcast_xml) }
      upload("working/hazelcast-config.xml.new","/opt/app/#{svcHome}/conf/hazelcast-config.xml")
      end # end of update_hazelcast_xml task

      # 11/10/2015 - work around for :update_config_edn_orig - phil
      task :update_config_edn do
        run "sudo cp -p /opt/app/#{svcHome}/conf/qa/qa-config.edn /opt/app/#{svcHome}/conf/config.edn"
      end

      task :update_config_edn_orig do

        set :commerceUrl, hiera("commerce.ds.base.url")
        set :entityUrl, hiera("entity.ds.base.url")
        set :offerUrl, hiera("offer.ds.base.url")
        set :locationUrl, hiera("location.ds.base.url")
        set :linearUrl, hiera("linear.ds.base.url")
        set :partnerIngestUrl, hiera("partner.ingest.ds.base.url")
        set :personaUrl, hiera("persona.ws.tags.url")
        set :awsQueue, hiera("aws.queue")
        set :rtveQueue, hiera("rtve.queue")
        set :shubaoHost, hiera("shubao.host")
        set :shubaoGroup, hiera("shubao.group")
        set :shubaoGroupPass, hiera("shubao.group.pass")
        set :shubaoClient, hiera("shubao.client.mode")
        set :shubaoIngestLimit, hiera("shubao.ingest.limit")
        set :amberConf, hiera("amber.conf")
        set :awsAccessKey, hiera("aws.access.key")
        set :awsSecretKey, hiera("aws.secret.key")
        set :awsRegion, hiera("aws.region")
        set :rtveAccessKey, hiera("rtve.access.key")
        set :rtveSecretKey, hiera("rtve.secret.key")
        set :rtveAwsQueue, hiera("rtve.aws.queue")
        set :rtveAwsAesKey, hiera("rtve.aws.aeskey")
        set :wpilAuthInfoIdentity, hiera("wpil.authinfo.identity")
        set :wpilAuthInfoOwner, hiera("wpil.authinfo.owner")
        set :wpilAuthInfoUser, hiera("wpil.authinfo.user")
        set :wpilAuthInfoPassword, hiera("wpil.authinfo.password")
        set :esUrlTemplate, hiera("es.urltemplate")
        set :elocUrlHostname, hiera("eloc.url.hostname")
        set :elocUrlPort, hiera("eloc.url.port")
        set :elocUrlSid, hiera("eloc.url.sid")
        set :elocUrlUsername, hiera("eloc.url.username")
        set :elocUrlPassword, hiera("eloc.url.password")

        config_edn = <<-here
        {:axon

        {:io {:http {:pool {:socket-timeout 600000
                               :conn-timeout 600000
                               :conn-req-timeout 600000
                               :max-total 50
                               :max-per-route 10}}}

          :firewall {:on? false
                     :allow {:prefixes ["8069"]}}


          :backoff {:initial-wait-ms 1000
                    :max-wait-ms 300000
                    :wait-fn (fn [ms] (* ms 2))}

          :dash {:config "conf/dash.config"}

          :nrepl {:port 7889}
          
          :default-entitlements {:service \#\{4908057179088585182\}
                                  :content \#\{8139324167008277182\}} 

          :source {:xbo {:aws
                         {:access-key "#{awsAccessKey}"
                          :secret-key "#{awsSecretKey}"
                          :region "#{awsRegion}"
                          :visiblity-timeout-sec 30
                          :max-conn 50
                          :queue "#{awsQueue}"}
                          

                          :partner "Comcast"}

                   :rtve {:aws
                          {:access-key "#{rtveAccessKey}"
                           :secret-key "#{rtveSecretKey}"
                           :region "#{awsRegion}"
                           :visiblity-timeout-sec 30
                           :max-conn 50
                           :queue "#{rtveAwsQueue}"}

                          :aes-key "hZBp1yD/qkHT1ofHI+4SMN/oESbWJ+yC"}

                   :persona {:url "http://udbps.g.comcast.net/availabilityTags"}

                   :wpil {:url "#{partnerIngestUrl}/web/subscriberIngest?schema=1.0"
                           :auth-info {:identity  "#{wpilAuthInfoIdentity}"
                                       :owner "#{wpilAuthInfoOwner}"
                                       :user "#{wpilAuthInfoUser}"
                                       :password "#{wpilAuthInfoPassword}"}
                          :batch-size 50
                          :crn-prefix {:xbo-prefix "comcast:xcalibur:xbo:" :entitlement-prefix "comcast:merlin:Offer:Entitlement:"}}

                   :xbo-notifier {:host "http://ccpwmg-ae-a005-p.ae.ccp.cable.comcast.com:5555"
                          :add-stream-uri "/accountProduct/setStreamForAccount"
                          :remove-stream-uri "/accountProduct/removeStreamForAccount"
                          :request-template "{\\"serviceAccountId\\":\\"%s\\",\\"trackingId\\":\\"%s\\"}"
                          :retry-ms 3600000}

                   :es {:url-template "#{esUrlTemplate}"
                        :headers {"X-sourceSystemId" "ES-UDB"}
                        :es-xml-paths {:path-to-node-id [:Accounts :Account :ServiceLocationInfo :NodeId]
                                       :path-to-location-id [:Accounts :Account :ServiceLocationInfo :Id]
                                       :path-to-zip [:Accounts :Account :ServiceLocationInfo :Zip]
                                       :path-to-zip4 [:Accounts :Account :ServiceLocationInfo :Zip4]
                                       :path-to-billing-sys-id [:Accounts :Account :BillingSystemId]
                                       :id-path [:Accounts :Account :Id]
                                       :pre-active [:Accounts :Account :isPreActive]
                                       :account-id-path [:Accounts :Account :Number]
                                       :account-epc-codes-path [:Accounts :Account :AccountProducts :ProductInfo :Number]}}

                   :eloc {:url "jdbc:oracle:thin:@#{elocUrlHostname}:#{elocUrlPort}:#{elocUrlSid}"
                          :username "#{elocUrlUsername}"
                          :password "#{elocUrlPassword}"}}
                      :amber {:hbase {:hb-conf {"hbase.zookeeper.quorum" "#{amberConf}"
                                                     "zookeeper.session.timeout" 30000}
                                           :tables {:audit "axon:audit" 
                                                    :inflight "axon:inflight"
                                                    :stream-status "axon:stream-status"
                                                    :billing-xbo-index "axon:billing-xbo-index"
                                                    :progress "axon:progress"
                                                    :white-list "axon:white-list"}}
                                   :ready-to-wpil \#\{\#\{"arrived" "availabled" "entitlered"} 
                                                    \#\{"arrived" "availabled" "entitlered" "backed-off"}}
                                   :no-longer-stream \#\{\#\{"account-is-no-longer-stream"}}}}

         :shubao {:client-mode? #{shubaoClient}
                  :hz-client {:hosts [#{shubaoHost}]
                              :retry-ms 5000
                              :retry-max 720000
                              :group-name "#{shubaoGroup}"
                              :group-password "#{shubaoGroupPass}"}

                  :tracker "shubao-tracker"
                  :data-service {:linear {:url "#{linearUrl}"
                                          :ingest-batch-size 1000
                                          :subscribe-to-notifications? true}
                                 :location {:url "#{locationUrl}"
                                            :ingest-batch-size 1000
                                            :subscribe-to-notifications? true}
                                 :commerce {:url "#{commerceUrl}"
                                            :ingest-batch-size 5000
                                            :id-form :none
                                            :subscribe-to-notifications? true}
                                 :offer {:url "#{offerUrl}"
                                         :ingest-batch-size 1000
                                         :subscribe-to-notifications? true}}}}

        here

        File.open("working/config.edn.new", 'w') {|f| f.write(config_edn) }
        upload("working/config.edn.new","/opt/app/#{svcHome}/conf/config.edn")


       end


end # UDB Service - each

#EOF
logger.info ">>>>> loaded udbServices"
