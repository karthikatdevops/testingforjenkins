###############
# FILE LOADING
###############
 

load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## cacheProfileWebService ############################## #:nodoc:
task :chaz1Fo_cacheProfileWebService do
  assign_roles
end

############################## Entity DS ############################## #:nodoc:
task :chaz1Fo_entityDataService do
  assign_roles
end

############################## gridWebService  ############################## #:nodoc:
task :chaz1Fo_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :chaz1Fo_idDataService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :chaz1Fo_jobDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :chaz1Fo_linearDataService do
  assign_roles
end

############################## localListingInfoWebService ############################## #:nodoc:
task :chaz1Fo_localListingInfoWebService do
  assign_roles
end

############################## locationDataService ############################## #:nodoc:
task :chaz1Fo_locationDataService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :chaz1Fo_menuDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :chaz1Fo_offerDataService do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :chaz1Fo_sportsDataService do
  assign_roles
end

############################## commerceDataService  ############################## #:nodoc:
task :chaz1Fo_commerceDataService do
  assign_roles
end

############################## subscriberDataService ############################## #:nodoc:
task :chaz1Fo_subscriberDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

############################## fedRex ###################################### #:nodoc:
task :chaz1Fo_fedRex do
  # NGB service
  assign_roles

  set_vars_from_hiera(%w[ app_main depends permgenspace projectArtifactId propertyFile rexBaseUrl xms xmx fedRex_menu_ds_url fedRex_server_port fedrex_browse_url grid_web_service_trending_url linear_ds_url menu_web_service_base_url id_ds_url ])
end

############################## playTimeService ############################## #:nodoc:
task :chaz1Fo_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome xmx ])
end

#########################################################################################
# SPECIAL TASKS
#########################################################################################

############################## qamParityReport ##############################
task :chaz1Fo_qamParityReport do
  assign_roles
end

#########################################################################################
# END SPECIAL TASKS
#########################################################################################

