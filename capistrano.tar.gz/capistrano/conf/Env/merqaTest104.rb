 load "./conf/Env/global.rb"



#######################
# MERQA 104 Test
#######################

# Used for BITT Quick Deployment Testing, i.e. validating CAP
# 2012, 2013
#


set_vars_from_hiera(%w[ logback_root_level rabbitmq_hostwget_params app  ])



############################## PLAYTIME SERVICE  ############################## #:nodoc:
task :merqaTest104_playTimeService do
 assign_roles
 set_vars_from_hiera(%w[ depends propertyFile svcHome xmx xms app_main playTimeService_debug_port ])
end


task :merqaTest104_cloverServer do
  assign_roles
end

############################## Entity DS ############################## #:nodoc:
task :merqaTest104_entityDataService do
  assign_roles
  
end

############################## job DS ############################## #:nodoc:
task :merqaTest104_jobDataService do
  assign_roles
end


############################## Linear DS ############################## #:nodoc:
task :merqaTest104_linearDataService do
 assign_roles
end

############################## Location DS ############################## #:nodoc:
task :merqaTest104_locationDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merqaTest104_offerDataService do
 assign_roles
 
end


############################## id DS ############################## #:nodoc:
task :merqaTest104_idDataService do
 assign_roles
end

############################## sports DS ############################## #:nodoc:
task :merqaTest104_sportsDataService do
 assign_roles
end

############################## sportsIngestWebService  ############################## #:nodoc:
task :merqaTest104_sportsIngestWebService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :merqaTest104_menuDataService do
  assign_roles
  
end

############################## subscriberDataService  ############################## #:nodoc:
task :merqaTest104_subscriberDataService do
  assign_roles
end

	############################## CRATE ############################## #:nodoc: 
task :merqaTest104_crate do	
 assign_roles	
 set_vars_from_hiera(%w[ depends propertyFile svcHome ])	
end	

############################## CASTLE ############################## #:nodoc: 	
task :merqaTest104_castl do	
 assign_roles	
 set_vars_from_hiera(%w[ depends propertyFile svcHome ])	
end
### END END END

