###############
# FILE LOADING
###############
load "./conf/Env/global.rb"

set_vars_from_hiera(%w[ hosts_file_overrides ])

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :merbrCbe_entityDataService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :merbrCbe_idDataService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :merbrCbe_jobDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :merbrCbe_linearDataService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :merbrCbe_locationDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merbrCbe_offerDataService do
  assign_roles
end

############################## grid WS ############################## #:nodoc:
task :merbrCbe_gridWebService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

