###############
# FILE LOADING
###############
load "./conf/Env/global.rb"

set_vars_from_hiera(%w[ hosts_file_overrides ])

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :merbrCim_entityDataService do
  assign_roles
end

############################## grid WS ############################## #:nodoc:
task :merbrCim_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :merbrCim_idDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :merbrCim_linearDataService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :merbrCim_locationDataService do
  assign_roles
end


############################## offer DS ############################## #:nodoc:
task :merbrCim_offerDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

