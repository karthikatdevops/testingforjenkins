###############
# FILE LOADING
###############
 
load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## accountContentEventWebService ##################
task :chaz2Ingest_accountContentEventWebService do
  assign_roles
end

############################## caretakerWebService ############################## #:nodoc:
task :chaz2Ingest_caretakerWebService do
  assign_roles
end

############################## coatGWTService ############################## #:nodoc:
task :chaz2Ingest_coatGWTService do
 assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :chaz2Ingest_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :chaz2Ingest_combineService do
  assign_roles
end

############################## consistency WS ############################## #:nodoc:
task :chaz2Ingest_consistencyWebService do
  assign_roles
end


############################## Entity DS ############################## #:nodoc:
task :chaz2Ingest_entityDataService do
  assign_roles
end

############################## entityIndex Solr ############################## #:nodoc:
task :chaz2Ingest_merlinSolr do
  assign_roles
end

############################## entityIndexer ############################## #:nodoc:
task :chaz2Ingest_entityIndexer do
  assign_roles
end

############################## entityIngest DS ############################## #:nodoc:
task :chaz2Ingest_entityIngest do
  assign_roles
end

############################## feedgenWebService ############################## #:nodoc:
task :chaz2Ingest_feedgenWebService do
  assign_roles
  role :feedgenWebServiceWebHosts, "ccpccm-po-c003-p.po.ccp.cable.comcast.com", "ccpccm-po-c004-p.po.ccp.cable.comcast.com", "ccpccm-br-c003-p.br.ccp.cable.comcast.com", "ccpccm-br-c004-p.br.ccp.cable.comcast.com"
end

############################## gridWebService  ############################## #:nodoc:
task :chaz2Ingest_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :chaz2Ingest_idDataService do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :chaz2Ingest_ingestRovi do
  assign_roles
end

############################## imageWebService ############################## #:nodoc:
task :chaz2Ingest_imageWebService do
  assign_roles
end

############################## ingestStagingWebService ############################## #:nodoc:
task :chaz2Ingest_ingestStagingWebService do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :chaz2Ingest_ingestWebService do
  assign_roles
  
  
end

############################## job DS ############################## #:nodoc:
task :chaz2Ingest_jobDataService do
  assign_roles
  
  
end

############################## Linear DS ############################## #:nodoc:
task :chaz2Ingest_linearDataService do
  assign_roles
  
  
end

############################## linear Indexer ############################## #:nodoc:
task :chaz2Ingest_linearIndexer do
  assign_roles
end

############################## linearIngest DS ############################## #:nodoc:
task :chaz2Ingest_linearIngest do
  assign_roles
  
  
end

############################## location DS ############################## #:nodoc:
task :chaz2Ingest_locationDataService do
  assign_roles

  
end

############################## location Indexer ############################## #:nodoc:
task :chaz2Ingest_locationIndexer do
  assign_roles
end

############################## location Ingest ############################## #:nodoc:
task :chaz2Ingest_locationIngest do
  assign_roles
  
  
end

############################## matchWebService ############################## #:nodoc:
task :chaz2Ingest_matchWebService do
  assign_roles

  
end

############################## menuDataService ############################## #:nodoc:
task :chaz2Ingest_menuDataService do
  assign_roles
  
  
end

############################# Menu Indexer ########################### #:nodoc
task :chaz2Ingest_menuIndexer do
  assign_roles
end

############################## miceGWTService ############################## #:nodoc:
task :chaz2Ingest_miceGWTService do
  assign_roles  
end

############################## mmmWebService  ############################## #:nodoc:
task :chaz2Ingest_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :chaz2Ingest_mmpWebService do
  assign_roles
end

########################## monsterEntityDataService  ####################### #:nodoc:
task :chaz2Ingest_monsterEntityDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :chaz2Ingest_offerDataService do
  assign_roles

end

############################# offerIngest ############################## #:nodoc:
task :chaz2Ingest_offerIngest do
  assign_roles
 
  
end

############################## offerWebService ############################## #:nodoc:
task :chaz2Ingest_offerWebService do
  assign_roles

end

############################# partnerIngest WS ############################## #:nodoc:
task :chaz2Ingest_partnerIngestWebService do
  assign_roles
  

end

############################## personaIngest WS ############################## #:nodoc:
task :chaz2Ingest_personaIngestWebService do
  # personaIngest cannot be clustered... only deploy on one host.
  assign_roles
end

############################## playTimeService ############################## #:nodoc:
task :chaz2Ingest_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## Program Availability2 ############################## #:nodoc:
task :chaz2Ingest_programAvailability2 do
  assign_roles
  

end

############################## programIndex2 Solr ############################## #:nodoc:
task :chaz2Ingest_programIndex2 do
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :chaz2Ingest_reatGWTService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :chaz2Ingest_scheduledIngestWebService do
  assign_roles
end

############################## scheduledTaskWebService ############################## #:nodoc:
task :chaz2Ingest_scheduledTaskWebService do
  assign_roles
end

############################## Search Updater 2 ############################## #:nodoc:
task :chaz2Ingest_searchUpdaterWebService2 do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :chaz2Ingest_sportsDataService do
  assign_roles
end

############################## sportsIngestWebService ######################### #:nodoc:
task :chaz2Ingest_sportsIngestWebService do
  assign_roles
end

############################## subscriberDataService ############################## #:nodoc:
task :chaz2Ingest_subscriberDataService do
  assign_roles
end

############################## rabbitmq ##############################
task :chaz2Ingest_rabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :chaz2Ingest_rabbitMGT do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

############################## triageWebService ############################## #:nodoc:
task :chaz2Ingest_triageWebService do
  assign_roles
end

############################## TPDS  ############################## #:nodoc:
task :chaz2Ingest_toolPreferenceDataService do
  assign_roles
end

############################## commerceDataService  ############################## #:nodoc:
task :chaz2Ingest_commerceDataService do
  assign_roles
end

############################## cacheProfileWebService  ############################## #:nodoc:
task :chaz2Ingest_cacheProfileWebService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

