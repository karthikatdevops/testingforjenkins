###############
# FILE LOADING
###############
 
load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## accountContentEventWebService ##################
task :ap_accountContentEventWebService do
  assign_roles
end

############################## caretakerWebService ############################## #:nodoc:
task :ap_caretakerWebService do
  assign_roles
end

############################## coatGWTService ############################## #:nodoc:
task :ap_coatGWTService do
 assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :ap_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :ap_combineService do
  assign_roles
end

############################## consistency WS ############################## #:nodoc:
task :ap_consistencyWebService do
  assign_roles
end


############################## Entity DS ############################## #:nodoc:
task :ap_entityDataService do
  assign_roles
end

############################## entityIndex Solr ############################## #:nodoc:
task :ap_merlinSolr do
  assign_roles
end

############################## entityIndexer ############################## #:nodoc:
task :ap_entityIndexer do
  assign_roles
end

############################## entityIngest DS ############################## #:nodoc:
task :ap_entityIngest do
  assign_roles
end

############################## feedgenWebService ############################## #:nodoc:
task :ap_feedgenWebService do
  assign_roles
  role :feedgenWebServiceWebHosts, "ccpccm-po-c003-p.po.ccp.cable.comcast.com", "ccpccm-po-c004-p.po.ccp.cable.comcast.com", "ccpccm-br-c003-p.br.ccp.cable.comcast.com", "ccpccm-br-c004-p.br.ccp.cable.comcast.com"
end

############################## gridWebService  ############################## #:nodoc:
task :ap_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :ap_idDataService do
  assign_roles
end

############################# ingestCsgi ############################## #:nodoc:
task :ap_ingestCsgi do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :ap_ingestRovi do
  assign_roles
end

############################## Image Services ############################## #:nodoc:
task :ap_imageWebService do
  assign_roles
end

task :ap_imageIndex do
  assign_roles
end

task :ap_imageDataService do
  assign_roles
end

task :ap_imageIngest do
  assign_roles
end

task :ap_imageIngestWebService do
  assign_roles
end

task :ap_imageEventWebService do
  assign_roles
end

task :ap_imageManagementWebService do
  assign_roles
end
############################## End Image Services ########################## #:nodoc:


############################## ingestStagingWebService ############################## #:nodoc:
task :ap_ingestStagingWebService do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :ap_ingestWebService do
  assign_roles
  
  
end

############################## job DS ############################## #:nodoc:
task :ap_jobDataService do
  assign_roles
  
  
end

############################## Linear DS ############################## #:nodoc:
task :ap_linearDataService do
  assign_roles
  
  
end

############################## linear Indexer ############################## #:nodoc:
task :ap_linearIndexer do
  assign_roles
end

############################## linearIngest DS ############################## #:nodoc:
task :ap_linearIngest do
  assign_roles
  
  
end

############################## location DS ############################## #:nodoc:
task :ap_locationDataService do
  assign_roles

  
end

############################## location Indexer ############################## #:nodoc:
task :ap_locationIndexer do
  assign_roles
end

############################## location Ingest ############################## #:nodoc:
task :ap_locationIngest do
  assign_roles
  
  
end

############################## matchWebService ############################## #:nodoc:
task :ap_matchWebService do
  assign_roles

  
end

############################## menuDataService ############################## #:nodoc:
task :ap_menuDataService do
  assign_roles
  
  
end

############################# Menu Indexer ########################### #:nodoc
task :ap_menuIndexer do
  assign_roles
end

############################## miceGWTService ############################## #:nodoc:
task :ap_miceGWTService do
  assign_roles  
end

############################## mmmWebService  ############################## #:nodoc:
task :ap_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :ap_mmpWebService do
  assign_roles
end

########################## monsterEntityDataService  ####################### #:nodoc:
task :ap_monsterEntityDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :ap_offerDataService do
  assign_roles

end

############################## playTimeService ############################## #:nodoc:
task :ap_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################# offerIngest ############################## #:nodoc:
task :ap_offerIngest do
  assign_roles
 
  
end

############################## offerWebService ############################## #:nodoc:
task :ap_offerWebService do
  assign_roles

end

############################# partnerIngest WS ############################## #:nodoc:
task :ap_partnerIngestWebService do
  assign_roles
  

end

############################## personaIngest WS ############################## #:nodoc:
task :ap_personaIngestWebService do
  # personaIngest cannot be clustered... only deploy on one host.
  assign_roles
end

############################## Program Availability2 ############################## #:nodoc:
task :ap_programAvailability2 do
  assign_roles
  

end

############################## programIndex2 Solr ############################## #:nodoc:
task :ap_programIndex2 do
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :ap_reatGWTService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :ap_scheduledIngestWebService do
  assign_roles
end

############################## Search Updater 2 ############################## #:nodoc:
task :ap_searchUpdaterWebService2 do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :ap_sportsDataService do
  assign_roles
end

############################## sportsIngestWebService ######################### #:nodoc:
task :ap_sportsIngestWebService do
  assign_roles
end

############################## subscriberDataService ############################## #:nodoc:
task :ap_subscriberDataService do
  assign_roles
end

############################## rabbitmq ##############################
task :ap_rabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :ap_rabbitMGT do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

############################## triageWebService ############################## #:nodoc:
task :ap_triageWebService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

