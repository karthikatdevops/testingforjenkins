 

load "./conf/Env/global.rb"



#############
# MERQA QAF - QA Functional HEAD (was Legacy)
#############

set_vars_from_hiera(%w[       newRelic_license_key ])

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :merqaQaf_entityDataService do
  assign_roles
    
  
end

############################## menuDataService  ############################## #:nodoc:
task :merqaQaf_menuDataService do
  assign_roles
    
  
end

############################## gridWebService  ############################## #:nodoc:
task :merqaQaf_gridWebService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :merqaQaf_jobDataService do
  assign_roles
    
  
end

############################## Linear DS ############################## #:nodoc:
task :merqaQaf_linearDataService do
  assign_roles
    
  
end

############################## localListingInfoWebService ############################## #:nodoc:
task :merqaQaf_localListingInfoWebService do
  assign_roles
    
  
end

############################## locationDataService ############################## #:nodoc:
task :merqaQaf_locationDataService do
  assign_roles
    
  
end

############################## offerDataService ############################## #:nodoc:
task :merqaQaf_offerDataService do
  assign_roles
    
  
end

############################## Program Availability2 ############################## #:nodoc:
task :merqaQaf_programAvailability2 do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

