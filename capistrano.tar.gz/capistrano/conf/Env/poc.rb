###############
# FILE LOADING
###############
 

load "./conf/Env/global.rb"



#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## cacheProfileWebService ############################## #:nodoc:
task :poc_cacheProfileWebService do
  assign_roles
end

############################## Entity DS ############################## #:nodoc:
task :poc_entityDataService do
  assign_roles
end

############################## gridWebService  ############################## #:nodoc:
task :poc_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :poc_idDataService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :poc_jobDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :poc_linearDataService do
  assign_roles
end

############################## localListingInfoWebService ############################## #:nodoc:
task :poc_localListingInfoWebService do
  assign_roles
end

############################## locationDataService ############################## #:nodoc:
task :poc_locationDataService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :poc_menuDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :poc_offerDataService do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :poc_sportsDataService do
  assign_roles
end

############################## commerceDataService  ############################## #:nodoc:
task :poc_commerceDataService do
  assign_roles
end

############################## subscriberDataService ############################## #:nodoc:
task :poc_subscriberDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

############################## fedRex ###################################### #:nodoc:
task :poc_fedRex do
  # NGB service
  assign_roles

  set_vars_from_hiera(%w[ app_main depends projectArtifactId propertyFile rexBaseUrl fedRex_menu_ds_url fedRex_server_port fedrex_browse_url grid_web_service_trending_url linear_ds_url menu_web_service_base_url id_ds_url ])
end

############################## playTimeService ############################## #:nodoc:
task :poc_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

#########################################################################################
# SPECIAL TASKS
#########################################################################################

############################## qamParityReport ##############################
task :poc_qamParityReport do
  assign_roles
end

#########################################################################################
# END SPECIAL TASKS
#########################################################################################

