###############
# FILE LOADING
###############
 

load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :chaz1Cim_entityDataService do
  assign_roles
end

############################## grid WS ############################## #:nodoc:
task :chaz1Cim_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :chaz1Cim_idDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :chaz1Cim_linearDataService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :chaz1Cim_locationDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :chaz1Cim_offerDataService do
  assign_roles
end


