 

load "./conf/Env/global.rb"



######################################
# This is the new proto Ingest env in Compass Stack in the CC 38th server room
# yongjun_rong@cable.comcast.com Sept. 12th, 2013
######################################

set_vars_from_hiera(%w[ logback_access_pattern_override puppet_prefix wget_params wget_params_proxy ])

# do not use these, see below
############################## oracle ##############################
#task :cmpstkRex_rexQE do
#  assign_roles
#end


# Use Rex in TB1 F5- special port/service in ports.rb = rexQETB1
# to map this to port 80 on the TQM TB1 F5
############################## oracle ##############################
task :cmpstkRex_rexQETB1 do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end


############################## haproxy ##############################
task  :cmpstkRex_haproxy do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end
