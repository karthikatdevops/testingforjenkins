load "./conf/Env/global.rb"

############################## Entity DS ############################## #:nodoc:
task :merdevlFo_entityDataService do
  assign_roles
end

############################## gridWebService  ############################## #:nodoc:
task :merdevlFo_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :merdevlFo_idDataService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :merdevlFo_jobDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :merdevlFo_linearDataService do
  assign_roles
end

############################## localListingInfoWebService ############################## #:nodoc:
task :merdevlFo_localListingInfoWebService do
  assign_roles
end

############################## locationDataService ############################## #:nodoc:
task :merdevlFo_locationDataService do
  assign_roles
end

############################## offerDataService ############################## #:nodoc:
task :merdevlFo_offerDataService do
  assign_roles
end

############################## Program Availability2 ############################## #:nodoc:
task :merdevlFo_programAvailability2 do
  assign_roles
end

############################# haproxy ##############################
task :merdevlFo_haproxy do
  assign_roles
end

### END END END
