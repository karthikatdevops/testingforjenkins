###############
# FILE LOADING
###############
 

load "./conf/Env/global.rb"



#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :merpoCbe_entityDataService do
  assign_roles
end

############################## grid WS ############################## #:nodoc:
task :merpoCbe_gridWebService do
  assign_roles
    
  set_vars_from_hiera(%w[   static_config ])
end

############################## id DS ############################## #:nodoc:
task :merpoCbe_idDataService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :merpoCbe_jobDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :merpoCbe_linearDataService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :merpoCbe_locationDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merpoCbe_offerDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

