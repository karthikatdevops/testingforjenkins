 

load "./conf/Env/global.rb"



################################
# MERQA Client
# Now in 46th floor Server Room
# in 1717 Arch
################################

##########################################################
# DATABASE - check basic.rb ALSO or you will reget it!
##########################################################

############################## Entity DS ############################## #:nodoc:
task :merqaClient_entityDataService do
  assign_roles
  
end

############################## gridWebService  ############################## #:nodoc:
task :merqaClient_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :merqaClient_idDataService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :merqaClient_jobDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :merqaClient_linearDataService do
  assign_roles
  
end

############################## localListingInfoWebService ############################## #:nodoc:
task :merqaClient_localListingInfoWebService do
  assign_roles
  
end

############################## locationDataService ############################## #:nodoc:
task :merqaClient_locationDataService do
  assign_roles
  
end

############################## offerDataService ############################## #:nodoc:
task :merqaClient_offerDataService do
  assign_roles
  
end

############################## Program Availability2 ############################## #:nodoc:
task :merqaClient_programAvailability2 do
  assign_roles
end

############################## programIndex2 Solr ############################## #:nodoc:
task :merqaClient_programIndex2 do
  assign_roles
end

############################## miceGWTService ############################## #:nodoc:
task :merqaClient_miceGWTService do
  assign_roles
end

####################### #:nodoc:
# END MERLIN SERVICES   #:noDoc:
####################### #:nodoc:

############################## gdash ##############################
task :merqaClient_gdash do
  logger.info "Executing task merqaClient_gdash......."
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## jmxtrans ##############################
task :merqaClient_jmxtrans do
  assign_roles
  set_vars_from_hiera(%w[ metrics_host metrics_port noBom url ])
end
############################# nagios ##############################
task :merqaClient_nagios do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end
############################# haproxy ##############################
task :merqaClient_haproxy do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

### END END END
