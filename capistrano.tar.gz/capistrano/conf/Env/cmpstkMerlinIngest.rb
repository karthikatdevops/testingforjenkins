 #2014 Comcast Compass Destro

load "./conf/Env/global.rb"




set_vars_from_hiera(%w[   
      
  envname     
      
  logback_access_pattern_override   puppet_prefix rabbitmq_host 
 wget_params wget_params_proxy splunkHost logback_version ])

# SERVICES ##################################################################################### #:nodoc:
# Put in Alpha order please
############################## accountContentEventWebService ############################## #:nodoc:
task :cmpstkMerlinIngest_accountContentEventWebService do
  assign_roles
  
end
############################## cacheProfileWebService ############################## #:nodoc:
task :cmpstkMerlinIngest_cacheProfileWebService do
  assign_roles
end

############################## caretakerWebService ############################## #:nodoc:
task :cmpstkMerlinIngest_caretakerWebService do
  assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :cmpstkMerlinIngest_cloverServer do
  assign_roles
end

############################## coatGWTService ############################## #:nodoc:
task :cmpstkMerlinIngest_coatGWTService do
  assign_roles
 
end

############################## combine WS ############################## #:nodoc:
task :cmpstkMerlinIngest_combineService do
  assign_roles
  
end

############################## Commerce DS ############################## #:nodoc:
task :cmpstkMerlinIngest_commerceDataService do
  assign_roles
  
end

############################## consistencyWebService ############################## #:nodoc:
task :cmpstkMerlinIngest_consistencyWebService do
  assign_roles
  
end

############################## Entity DS ############################## #:nodoc:
task :cmpstkMerlinIngest_entityDataService do
  assign_roles
  
end

############################## entityIngest DS ############################## #:nodoc:
task :cmpstkMerlinIngest_entityIngest do
  assign_roles
  
end

############################## fandangoIngestService ############################## #:nodoc:
task :cmpstkMerlinIngest_fandangoIngestService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end


############################## feedgenWebService ############################## #:nodoc:
task :cmpstkMerlinIngest_feedgenWebService do
  assign_roles
end

############################## gridWebService  ############################## #:nodoc:
task :cmpstkMerlinIngest_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :cmpstkMerlinIngest_idDataService do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :cmpstkMerlinIngest_ingestRovi do
  assign_roles
  
end

############################## ingest WebService ############################## #:nodoc:
task :cmpstkMerlinIngest_ingestWebService do
  assign_roles
  
end

############################## job DS ############################## #:nodoc:
task :cmpstkMerlinIngest_jobDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :cmpstkMerlinIngest_linearDataService do
  assign_roles
end

############################## linearIngest DS ############################## #:nodoc:
task :cmpstkMerlinIngest_linearIngest do
  assign_roles
  
end

############################## Location DS ############################## #:nodoc:
task :cmpstkMerlinIngest_locationDataService do
  assign_roles
end

############################## location Ingest ############################## #:nodoc:
task :cmpstkMerlinIngest_locationIngest do
  assign_roles
end


############################## matchWebService ############################## #:nodoc:
task :cmpstkMerlinIngest_matchWebService do
  assign_roles
end

############################## mmmWebService  ############################## #:nodoc:
task :cmpstkMerlinIngest_mmmWebService do
  assign_roles
    
 end

############################## mmpWebService  ############################## #:nodoc:
task :cmpstkMerlinIngest_mmpWebService do
  assign_roles
  
end

############################## offer DS ############################## #:nodoc:
task :cmpstkMerlinIngest_offerDataService do
  assign_roles
  
end

############################## offerIngest ############################## #:nodoc:
task :cmpstkMerlinIngest_offerIngest do
  assign_roles
  
end

############################## offerWebService ############################## #:nodoc:
task :cmpstkMerlinIngest_offerWebService do
  assign_roles
end

############################## partnerIngest WS ############################## #:nodoc:
task :cmpstkMerlinIngest_partnerIngestWebService do
  assign_roles
 
end

############################## personaIngest WS ############################## #:nodoc:
task :cmpstkMerlinIngest_personaIngestWebService do
  assign_roles
end

############################## playTimeService ############################## #:nodoc:
task :cmpstkMerlinIngest_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## Search Updater 2 ############################## #:nodoc:
task :cmpstkMerlinIngest_searchUpdaterWebService2 do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :cmpstkMerlinIngest_sportsDataService do
  assign_roles
  
end

############################## sportsIngest WebService ############################## #:nodoc:
task :cmpstkMerlinIngest_sportsIngestWebService do
  assign_roles
  
end

############################## subscriberDataService  ############################## #:nodoc:
task :cmpstkMerlinIngest_subscriberDataService do
  assign_roles
  
end

############################### merlinSolr replaces entityIndex  ############################## #:nodoc:
task :cmpstkMerlinIngest_merlinSolr do
  assign_roles
end


############################## scheduledIngestWS ############################## #:nodoc:
task :cmpstkMerlinIngest_scheduledIngestWebService do
  assign_roles
  
end

############################## scheduledTaskWebService ############################## #:nodoc:
task :cmpstkMerlinIngest_scheduledTaskWebService do
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :cmpstkMerlinIngest_reatGWTService do
  assign_roles
  
end

############################## triageWebService ############################## #:nodoc:
task :cmpstkMerlinIngest_triageWebService do
  assign_roles
end

############################## TPDS ############################## #:nodoc:
task :cmpstkMerlinIngest_toolPreferenceDataService do
  assign_roles
end

################################################################################################
# I N D E X E R S
############################# Entity Indexer ########################### #:nodoc
task :cmpstkMerlinIngest_entityIndexer do
  assign_roles
end
############################## Location Indexer ############################## #:nodoc:
task :cmpstkMerlinIngest_locationIndexer do
  assign_roles
end
############################## Linear Indexer ############################## #:nodoc:
task :cmpstkMerlinIngest_linearIndexer do
  assign_roles
end
################################################################################################



#__________________________________________________________________________________#
# Below this are service definitions for things that are not actually deployed
# they are for thinks like bookmarks, setting haproxy vips and metrics
#____________________________________________________________________________________#

############################# nagios ##############################
task :cmpstkMerlinIngest_nagios do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## haproxy ##############################
task  :cmpstkMerlinIngest_haproxy do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## oracle ##############################
task :cmpstkMerlinIngest_oracle do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## rabbitmq ##############################
task :cmpstkMerlinIngest_rabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :cmpstkMerlinIngest_imageRabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end
############################## rabbitmq MGT Ui ##############################
task :cmpstkMerlinIngest_rabbitMGT do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :cmpstkMerlinIngest_imageRabbitMGT do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end
############################### mongoDB##################################
task :cmpstkMerlinIngest_mongoDB do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end
### END END END

