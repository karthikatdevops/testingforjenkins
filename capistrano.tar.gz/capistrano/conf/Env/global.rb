set_vars_from_hiera(%w[
  confType
  context_path
  use_bundle_exec
  ver
  basedir
  shell
  logdir
  tmpdir
  user
  haproxy_user
  wget_params_noDebug_proxy
  wget_params_proxy
  wget_params_noDebug
  wget_params_noproxy
  wget_params_debug_noproxy
  wget_params_debug_proxy 
  wget_params
  java_version
  java_info
  jetty_version
  jira_auth_user
  jira_auth_password
  jira_auth_url
  custom_JDBC_logging_level
  debug_port_on
  ds_read_only
  jetty_maxIdleTime
  jetty_requestBufferSize
  jetty_responseBufferSize
  jetty_http_headerbuffersize
  cim_sftp_host
  cloverman_repo
  cfigVip
  post_seeds
  do_not_start
  xmx
  permgenspace
  dbuser
  repo
  allowed
  solrMaster
  logback_version
  service_environment
  splunkTcpPort
  dbpasswd
  dynaTrace_collectors
  hash_dbuser
  mpx_identity_url
  mpx_access_url
  mpx_account_base_url
  combine_commons_default_ownerid
  vodmt_media_account_url
  fss_media_account_url
  vod_media_account_url
  image_media_account_url
  asp_mpx_identity_url
  asp_media_url
  logback_level_debug
  logback_level_error
  logback_level_info
  logback_level_warn
  dsMerlinVip
  dsMerlinIngestVip
  dsHAProxyVip
  hazelcast
  jmx_tunings
  alive_path
  persistent_directory
  otis_dbuser
  otis_dburl
])

# Generate bama JSON request post for tasks given on command line
set :bamatasks, true
set :bamatasks, false if(exists?(:bama_json) && bama_json.to_s == "false")

load "./common/tracer.rb"

#http://www.itechp2pexchange.com/content/linux-unix-difference-between-who-whoami-and-who-am-i
set :source_user, [`who am i`.chomp.split(" ").first, "@", `hostname`.chomp].join

#BITT_4574 for sirius log file NAS dir
set_vars_from_hiera(%w[ 
  sirius_log_dir 
])
