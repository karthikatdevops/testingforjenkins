 

load "./conf/Env/global.rb"

set_vars_from_hiera(%w[     rabbitmq_host     ])

set_vars_from_hiera(%w[ availabilityTagHost availabilityTagPort browseSessionServiceHost commerceDataServiceHost commerceDataServicePassword commerceDataServiceUser confType contextServiceHost contextServicePort enableAuthenticationMerlinAndXBO enableAuthenticationXBO logback_level_debug logback_level_error logback_level_info logback_level_warn menuDataServiceHost menuDataServicePassword menuDataServiceUser menuVisibilityCountServiceHost menuVisibilityCountServiceTitlesEndpoint menuVisibilityCountServicepropertyFile menuWebServiceHost    mpx_base_url offerServicePassword offerServiceUser rabbitMQExchangeName rabbitMQExchangeVhost rabbitMQHost rabbitMQPort rexBaseHost rexBasePath rexBasePort subscriberRiakHost subscriberRiakHttpPort subscriberRiakPbcPort subscriberServiceHost subscriberServicePort titleServerPrimePort  uesEntitlementsServiceHost uesEntitlementsServicePort universalResumePointHost universalResumePointPort useproxy userPreferenceDataServiceHost userPreferenceDataServicePassword userPreferenceDataServiceUser videoDataServiceBaseUrl videoDataServiceHost offerIngestHost combineServiceHost locationDataServiceHost linearDataServiceHost entityServiceHost idServiceHost linearServiceHost offerServiceHost linearDataServiceBaseUrl entityServiceBaseUrl locationDataServiceBaseUrl idServiceBaseUrl linearServiceBaseUrl browseSessionServiceBaseUrl menuDataServiceBaseUrl offerServiceAdmin combineServiceBaseUrl userPreferenceDataServiceBaseUrl subscriberServiceBaseUrl commerceDataServiceBaseUrl videoDataServiceBaseUrl menuVisibilityCountServiceBaseUrl menuWebServiceBaseUrl offerServiceBaseUrl offerIngestBaseUrl subscriberRiakHttpBaseUrl offerServiceOwnerid rexBaseUrl menuWebServicePort browseSessionServicePort userPreferenceDataServiceAdmin menuDataServicePort videoDataServicePort commerceDataServiceAdmin menuVisibilityCountServicePort commerceDataServicePort menuDataServiceAdmin userPreferenceDataServicePort subscriberRiakPbcBaseUrl ])

set_vars_from_hiera(%w[ menuDataServiceOwnerid userPreferenceDataServiceOwnerid commerceDataServiceOwnerid ])

############################## mapsdev_menuDataService ############################## #:nodoc:
task :mapsdev_menuDataService do
  assign_roles
  
  set_vars_from_hiera(%w[ dburl dbuser  svcHome])
end

############################## mapsdev_menuVisibilityCountService ############################## #:nodoc:
task :mapsdev_menuVisibilityCountService do
  assign_roles
  
  set_vars_from_hiera(%w[ depends projectArtifactId propertyFile svcHome])
end


############################## mapsdev_menuWebService ############################## #:nodoc:
task :mapsdev_menuWebService do
  assign_roles
  
  set_vars_from_hiera(%w[ depends projectArtifactId propertyFile svcHome])
end

task  :mapsdev_tRex do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome])
end

############################## fedRex ###################################### #:nodoc:
task :mapsdev_fedRex do
  assign_roles
  set_vars_from_hiera(%w[ app_main depends projectArtifactId propertyFile rexBaseUrl fedRex_menu_ds_url fedRex_server_port fedrex_browse_url grid_web_service_trending_url linear_ds_url menu_web_service_base_url id_ds_url ])
end

#########################################################################################
# END UDB DEPLOYMENT TASKS
#########################################################################################
