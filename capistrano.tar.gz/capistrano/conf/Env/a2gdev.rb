load "./conf/Env/global.rb"

############################## a2gdev_castl ############################## #:nodoc:
task :a2gdev_castl do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

############################## a2gdev_crate ############################## #:nodoc:
task :a2gdev_crate do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

task :a2gdev_cru do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

task :a2gdev_alfred do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

############################## a2gdev_availabilityResolutionService ############################## #:nodoc:
task :a2gdev_availabilityResolutionService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

############################## a2gdev_digitalRightsLocker ############################## #:nodoc:
task :a2gdev_digitalRightsLocker do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

############################## a2gdev_commerceDataService ############################## #:nodoc:
task :a2gdev_commerceDataService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end


############################## unuServer_unuServer ############################## #:nodoc:
task :a2gdev_unuServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome])
end


############################## unuServer_tim ############################## #:nodoc:
task :a2gdev_tim do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome])
end

############################## haproxy ##############################
task :a2gdev_haproxy do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end
############################# nagios ##############################
task :a2gdev_nagios do
	assign_roles
 	set_vars_from_hiera(%w[ noBom ])
end
