###############
# FILE LOADING
###############
 
load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## accountContentEventWebService ##################
task :dev_bo_po_accountContentEventWebService do
  assign_roles
end

############################## caretakerWebService ############################## #:nodoc:
task :dev_bo_po_caretakerWebService do
  assign_roles
end

############################## coatGWTService ############################## #:nodoc:
task :dev_bo_po_coatGWTService do
 assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :dev_bo_po_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :dev_bo_po_combineService do
  assign_roles
end

############################## consistency WS ############################## #:nodoc:
task :dev_bo_po_consistencyWebService do
  assign_roles
end


############################## Entity DS ############################## #:nodoc:
task :dev_bo_po_entityDataService do
  assign_roles
end

############################## entityIndex Solr ############################## #:nodoc:
task :dev_bo_po_merlinSolr do
  assign_roles
end

############################## entityIndexer ############################## #:nodoc:
task :dev_bo_po_entityIndexer do
  assign_roles
end

############################## entityIngest DS ############################## #:nodoc:
task :dev_bo_po_entityIngest do
  assign_roles
end

############################## feedgenWebService ############################## #:nodoc:
task :dev_bo_po_feedgenWebService do
  assign_roles
  role :feedgenWebServiceWebHosts, "ccpccm-po-c003-p.po.ccp.cable.comcast.com", "ccpccm-po-c004-p.po.ccp.cable.comcast.com", "ccpccm-br-c003-p.br.ccp.cable.comcast.com", "ccpccm-br-c004-p.br.ccp.cable.comcast.com"
end

############################## gridWebService  ############################## #:nodoc:
task :dev_bo_po_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :dev_bo_po_idDataService do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :dev_bo_po_ingestRovi do
  assign_roles
end

############################## Image Services ############################## #:nodoc:
task :dev_bo_po_imageWebService do
  assign_roles
end

task :dev_bo_po_imageIndex do
  assign_roles
end

task :dev_bo_po_imageDataService do
  assign_roles
end

task :dev_bo_po_imageIngest do
  assign_roles
end

task :dev_bo_po_imageIngestWebService do
  assign_roles
end

task :dev_bo_po_imageEventWebService do
  assign_roles
end

task :dev_bo_po_imageManagementWebService do
  assign_roles
end
############################## End Image Services ########################## #:nodoc:


############################## ingestStagingWebService ############################## #:nodoc:
task :dev_bo_po_ingestStagingWebService do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :dev_bo_po_ingestWebService do
  assign_roles
  
  
end

############################## job DS ############################## #:nodoc:
task :dev_bo_po_jobDataService do
  assign_roles
  
  
end

############################## Linear DS ############################## #:nodoc:
task :dev_bo_po_linearDataService do
  assign_roles
  
  
end

############################## linear Indexer ############################## #:nodoc:
task :dev_bo_po_linearIndexer do
  assign_roles
end

############################## linearIngest DS ############################## #:nodoc:
task :dev_bo_po_linearIngest do
  assign_roles
  
  
end

############################## location DS ############################## #:nodoc:
task :dev_bo_po_locationDataService do
  assign_roles

  
end

############################## location Indexer ############################## #:nodoc:
task :dev_bo_po_locationIndexer do
  assign_roles
end

############################## location Ingest ############################## #:nodoc:
task :dev_bo_po_locationIngest do
  assign_roles
  
  
end

############################## matchWebService ############################## #:nodoc:
task :dev_bo_po_matchWebService do
  assign_roles

  
end

############################## menuDataService ############################## #:nodoc:
task :dev_bo_po_menuDataService do
  assign_roles
  
  
end

############################# Menu Indexer ########################### #:nodoc
task :dev_bo_po_menuIndexer do
  assign_roles
end

############################## miceGWTService ############################## #:nodoc:
task :dev_bo_po_miceGWTService do
  assign_roles  
end

############################## mmmWebService  ############################## #:nodoc:
task :dev_bo_po_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :dev_bo_po_mmpWebService do
  assign_roles
end

########################## monsterEntityDataService  ####################### #:nodoc:
task :dev_bo_po_monsterEntityDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :dev_bo_po_offerDataService do
  assign_roles

end

############################## playTimeService ############################## #:nodoc:
task :dev_bo_po_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################# offerIngest ############################## #:nodoc:
task :dev_bo_po_offerIngest do
  assign_roles
 
  
end

############################## offerWebService ############################## #:nodoc:
task :dev_bo_po_offerWebService do
  assign_roles

end

############################# partnerIngest WS ############################## #:nodoc:
task :dev_bo_po_partnerIngestWebService do
  assign_roles
  

end

############################## personaIngest WS ############################## #:nodoc:
task :dev_bo_po_personaIngestWebService do
  # personaIngest cannot be clustered... only deploy on one host.
  assign_roles
end

############################## Program Availability2 ############################## #:nodoc:
task :dev_bo_po_programAvailability2 do
  assign_roles
  

end

############################## programIndex2 Solr ############################## #:nodoc:
task :dev_bo_po_programIndex2 do
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :dev_bo_po_reatGWTService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :dev_bo_po_scheduledIngestWebService do
  assign_roles
end

############################## scheduledTaskWebService ############################## #:nodoc:
task :dev_bo_po_scheduledTaskWebService do
  assign_roles
end

############################## Search Updater 2 ############################## #:nodoc:
task :dev_bo_po_searchUpdaterWebService2 do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :dev_bo_po_sportsDataService do
  assign_roles
end

############################## sportsIngestWebService ######################### #:nodoc:
task :dev_bo_po_sportsIngestWebService do
  assign_roles
end

############################## subscriberDataService ############################## #:nodoc:
task :dev_bo_po_subscriberDataService do
  assign_roles
end

############################## rabbitmq ##############################
task :dev_bo_po_rabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :dev_bo_po_rabbitMGT do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

############################## triageWebService ############################## #:nodoc:
task :dev_bo_po_triageWebService do
  assign_roles
end

############################## TPDS  ############################## #:nodoc:
task :dev_bo_po_toolPreferenceDataService do
  assign_roles
end

############################## commerceDataService  ############################## #:nodoc:
task :dev_bo_po_commerceDataService do
  assign_roles
end

############################## cacheProfileWebService  ############################## #:nodoc:
task :dev_bo_po_cacheProfileWebService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

