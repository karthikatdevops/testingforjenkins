###############
# FILE LOADING
###############
 
load "./conf/Env/global.rb"

set_vars_from_hiera(%w[ hosts_file_overrides ])

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## accountContentEventWebService ##################
task :merbrocIngest_accountContentEventWebService do
  assign_roles
end

############################## cacheProfileWebService ############################## #:nodoc:
task :merbrocIngest_cacheProfileWebService do
  assign_roles
end

############################## caretakerWebService ############################## #:nodoc:
task :merbrocIngest_caretakerWebService do
  assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :merbrocIngest_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :merbrocIngest_combineService do
  assign_roles
end

############################## consistency WS ############################## #:nodoc:
task :merbrocIngest_consistencyWebService do
  assign_roles
end


############################# Entity DS ############################## #:nodoc:
task :merbrocIngest_entityDataService do
  assign_roles
end

############################## entityIndex Solr ############################## #:nodoc:
task :merbrocIngest_merlinSolr do
  assign_roles
end

############################## entityIndexer ############################## #:nodoc:
task :merbrocIngest_entityIndexer do
  assign_roles
end

############################# entityIngest DS ############################## #:nodoc:
task :merbrocIngest_entityIngest do
  assign_roles
end

############################## feedgenWebService ############################## #:nodoc:
task :merbrocIngest_feedgenWebService do
  assign_roles
  role :feedgenWebServiceWebHosts, "ccpccm-br-c003-p.br.ccp.cable.comcast.com", "ccpccm-br-c004-p.br.ccp.cable.comcast.com" 
end

############################## gridWebService  ############################## #:nodoc:
task :merbrocIngest_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :merbrocIngest_idDataService do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :merbrocIngest_ingestRovi do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :merbrocIngest_ingestWebService do
  assign_roles
end

############################# job DS ############################## #:nodoc:
task :merbrocIngest_jobDataService do
  assign_roles
end

############################# Linear DS ############################## #:nodoc:
task :merbrocIngest_linearDataService do
  assign_roles
end

############################## linear Indexer ############################## #:nodoc:
task :merbrocIngest_linearIndexer do
  assign_roles
end

############################# linearIngest DS ############################## #:nodoc:
task :merbrocIngest_linearIngest do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :merbrocIngest_locationDataService do
  assign_roles
end

############################## location Indexer ############################## #:nodoc:
task :merbrocIngest_locationIndexer do
  assign_roles
end

############################## location Ingest ############################## #:nodoc:
task :merbrocIngest_locationIngest do
  assign_roles
end

############################## matchWebService ############################## #:nodoc:
task :merbrocIngest_matchWebService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :merbrocIngest_menuDataService do
  assign_roles
end

############################# Menu Indexer ########################### #:nodoc
task :merbrocIngest_menuIndexer do
  assign_roles
end

############################## miceGWTService ############################## #:nodoc:
task :merbrocIngest_miceGWTService do
  assign_roles
end

############################## mmmWebService  ############################## #:nodoc:
task :merbrocIngest_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :merbrocIngest_mmpWebService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merbrocIngest_offerDataService do
  assign_roles

  
end

############################# offerIngest ############################## #:nodoc:
task :merbrocIngest_offerIngest do
  assign_roles
end

############################## offerWebService ############################## #:nodoc:
task :merbrocIngest_offerWebService do
  assign_roles
end

############################# partnerIngest WS ############################## #:nodoc:
task :merbrocIngest_partnerIngestWebService do
  assign_roles
end

############################## personaIngest WS ############################## #:nodoc:
task :merbrocIngest_personaIngestWebService do
  # personaIngest cannot be clustered... only deploy on one host.
  assign_roles
end

############################## programIndex2 Solr ############################## #:nodoc:
task :merbrocIngest_programIndex2 do
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :merbrocIngest_reatGWTService do
  assign_roles
end

############################## scheduledTaskWebService ############################## #:nodoc:
task :merbrocIngest_scheduledTaskWebService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :merbrocIngest_scheduledIngestWebService do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :merbrocIngest_sportsDataService do
  assign_roles
end

############################## sportsIngestWebService ######################### #:nodoc:
task :merbrocIngest_sportsIngestWebService do
  assign_roles
end

############################## subscriberDataService ############################## #:nodoc:
task :merbrocIngest_subscriberDataService do
  assign_roles
end

############################## rabbitmq ##############################
task :merpocIngest_rabbitMQ do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

task :merpocIngest_rabbitMGT do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

############################## triageWebService ############################## #:nodoc:
task :merbrocIngest_triageWebService do
  assign_roles
end

############################## TPDS  ############################## #:nodoc:
task :merbrocIngest_toolPreferenceDataService do
  assign_roles
end

############################## commerceDataService  ############################## #:nodoc:
task :merbrocIngest_commerceDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

