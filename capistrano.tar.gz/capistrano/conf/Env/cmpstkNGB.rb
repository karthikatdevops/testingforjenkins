 

load "./conf/Env/global.rb"



#################################################################################################### #:nodoc:
# UDB DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

set_vars_from_hiera(%w[  combineMpxOwnerid combineServiceBaseUrl combineServiceHost confType contextServiceBaseUrl contextServiceHost contextServicePort enableAuthenticationMerlinAndXBO entityServiceBaseUrl entityServiceHost 
  fedRex_menu_ds_url fedRex_server_port fedrex_browse_url grid_web_service_trending_url idServiceBaseUrl idServiceHost id_ds_url linearDataServiceBaseUrl linearDataServiceHost linearServiceBaseUrl linearServiceHost linear_ds_url locationDataServiceBaseUrl locationDataServiceHost logback_access_pattern_override logback_level_debug logback_level_error logback_level_info logback_level_warn menuDataServiceAdmin menuDataServiceBaseUrl menuDataServiceHost 
  menuDataServiceOwnerid menuDataServicePassword menuDataServicePort menuDataServiceUser menuVisibilityCountServiceBaseUrl menuVisibilityCountServiceHost menuVisibilityCountServicePort menuVisibilityCountServiceTitlesEndpoint menuWebServiceBaseUrl menuWebServiceHost menuWebServicePort menu_web_service_base_url    mpxIdentityURL 
  mpx_base_url offerIngestBaseUrl offerIngestHost offerServiceAdmin offerServiceBaseUrl offerServiceHost offerServiceOwnerid offerServicePassword offerServiceUser personalizedMenuWebServiceBaseUrl rabbitMQExchangeName rabbitMQExchangeVhost rabbitMQHost rabbitMQPort rexBaseHost rexBasePath rexBasePort rexBaseUrl sessionRiakActive sessionRiakHost sessionRiakInitialPoolSize sessionRiakMaxPoolSize sessionRiakPort subscriberRiakHost subscriberRiakHttpBaseUrl 
  subscriberRiakHttpPort subscriberRiakPbcBaseUrl subscriberRiakPbcPort subscriberServiceBaseUrl subscriberServiceHost subscriberServicePort titleServerPrimePort udbDemoMode  uesEntitlementsServiceBaseUrl uesEntitlementsServiceHost uesEntitlementsServicePort universalResumePointHost universalResumePointPort useproxy userPreferenceDataServiceBaseUrl userPreferenceDataServiceHost userPreferenceDataServicePort 
  videoDataServiceBaseUrl videoDataServiceHost videoDataServicePort wget_params splunkHost logback_version])



##############################  cmpstkNGB_fedRex ############################## #:nodoc:
task :cmpstkNGB_fedRex do
  assign_roles
  
  set_vars_from_hiera(%w[ app_main depends permgenspace projectArtifactId propertyFile rexBaseUrl xms xmx fedRex_menu_ds_url fedRex_server_port fedRex_debug_port fedrex_browse_url grid_web_service_trending_url linear_ds_url menu_web_service_base_url id_ds_url ])
end


############################## menuDataService ############################## #:nodoc:
task :cmpstkNGB_menuDataService do
  assign_roles
  
end


############################# menuIndexer ########################### #:nodoc
task :cmpstkNGB_menuIndexer do
  assign_roles
end


############################## haproxy ##############################
task  :cmpstkNGB_haproxy do
  assign_roles
    
  set_vars_from_hiera(%w[ noBom ])
end



#########################################################################################
# END UDB DEPLOYMENT TASKS
#########################################################################################
