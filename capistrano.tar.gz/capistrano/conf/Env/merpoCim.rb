###############
# FILE LOADING
###############
load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :merpoCim_entityDataService do
  assign_roles
end

############################## grid WS ############################## #:nodoc:
task :merpoCim_gridWebService do
  assign_roles
    
  set_vars_from_hiera(%w[   static_config ])
end

############################## id DS ############################## #:nodoc:
task :merpoCim_idDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :merpoCim_linearDataService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :merpoCim_locationDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merpoCim_offerDataService do
  assign_roles
end
