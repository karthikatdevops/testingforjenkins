 

load "./conf/Env/global.rb"


set_vars_from_hiera(%w[   logback_level_debug logback_level_error logback_level_info logback_level_warn    mpx_base_url udbDemoMode useproxy userPreferenceDataServiceAdmin userPreferenceDataServiceBaseUrl userPreferenceDataServiceHost userPreferenceDataServiceOwnerid userPreferenceDataServicePassword userPreferenceDataServicePort userPreferenceDataServiceUser wget_params ])

#Control add the c3p0.tcl jmxsh logger cron job

############################## haproxy ##############################
task  :udbcmpstk_haproxy do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end


############################## udbcmpstk_userPreferenceDataService ############################## #:nodoc:
task :udbcmpstk_userPreferenceDataService do
  assign_roles
end

############################## udbcmpstk_ars2DataService ############################## #:nodoc:
task :udbcmpstk_ars2DataService do
  assign_roles
end

#########################################################################################
# END UDB DEPLOYMENT TASKS
#########################################################################################
