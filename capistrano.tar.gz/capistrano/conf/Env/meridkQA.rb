 

load "./conf/Env/global.rb"

set_vars_from_hiera(%w[ cfigRabbitPort cfigVip cfigdevVip cim_sftp_host clientFTPVip logback_level_debug logback_level_error logback_level_info logback_level_warn  ])

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:


task :meridkQA_cfigWebService do
  assign_roles

  set_vars_from_hiera(%w[ cfigRabbitPassword cfigRabbitUsername cfigRabbitVhost cfigWebService_ncds_controllersFileCfig cfigWebService_ncds_controllersFileDacs cfigWebService_ncds_proxyHost cfigWebService_ncds_proxyPort cfigWebService_ncds_useUploadFiles streamsage_host streamsage_password streamsage_user ])
end
