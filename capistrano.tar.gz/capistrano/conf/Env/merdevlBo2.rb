# MERDEVLBO2- the merdevl backoffice virtualized on 43rd floor
# aug 2015

load "./conf/Env/global.rb"

set_vars_from_hiera(%w[ cfigRabbitPort cim_sftp_host   logback_access_pattern_override logback_root_level logback_level_debug logback_level_error logback_level_info logback_level_warn ])


#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## caretakerWebService ############################## #:nodoc:
task :merdevlBo2_caretakerWebService do
  assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :merdevlBo2_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :merdevlBo2_combineService do
  # assign_roles
  assign_roles
end

############################## Commerce DS ############################## #:nodoc:
task :merdevlBo2_commerceDataService do
  assign_roles
  
end

############################## consistencyWebService ############################## #:nodoc:
task :merdevlBo2_consistencyWebService do
  assign_roles
  
end

############################## Entity DS ############################## #:nodoc:
task :merdevlBo2_entityDataService do
  assign_roles
  
end

############################## fandangoIngestService ############################## #:nodoc:
task :merdevlBo2_fandangoIngestService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end


############################### merlinSolr replaces entityIndex  ############################## #:nodoc:
task :merdevlBo2_merlinSolr do
  assign_roles
end

############################### imageIndex separate Solr for images  ############################## #:nodoc:
task :merdevlBo2_imageIndex do
  assign_roles
end

############################# Entity Indexer ########################### #:nodoc
task :merdevlBo2_entityIndexer do
  assign_roles
end

############################# Menu Indexer ########################### #:nodoc
task :merdevlBo2_menuIndexer do
  assign_roles
end


############################## entityIngest DS ############################## #:nodoc:
task :merdevlBo2_entityIngest do
  assign_roles
  
end

############################## feedgenWebService ############################## #:nodoc:
task :merdevlBo2_feedgenWebService do
  assign_roles
end

############################## gridWebService  ############################## #:nodoc:
task :merdevlBo2_gridWebService do
  assign_roles

end

############################## id DS ############################## #:nodoc:
task :merdevlBo2_idDataService do
 assign_roles
end

############################## image WS ############################## #:nodoc:
task :merdevlBo2_imageWebService do
  assign_roles
end

############################## image DS ############################## #:nodoc:
task :merdevlBo2_imageDataService do
  assign_roles
  
end

############################## image Ingest ############################## #:nodoc:
task :merdevlBo2_imageIngest do
  assign_roles
  
end

############################## imageIngestWebService ############################## #:nodoc:
task :merdevlBo2_imageIngestWebService do
  assign_roles
end

############################## imageEventWebService ############################## #:nodoc:
task :merdevlBo2_imageEventWebService do
  assign_roles
end

############################## imageManagementWebService ############################## #:nodoc:
task :merdevlBo2_imageManagementWebService do
  assign_roles
end

############################## imageReportsViewer ############################## #:nodoc:
task :merdevlBo2_imageReportsViewer do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :merdevlBo2_ingestWebService do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :merdevlBo2_ingestRovi do
  assign_roles
end


############################## job DS ############################## #:nodoc:
task :merdevlBo2_jobDataService do
  assign_roles
  
end

############################## Linear DS ############################## #:nodoc:
task :merdevlBo2_linearDataService do
  assign_roles
  
end

############################## linearIngest DS ############################## #:nodoc:
task :merdevlBo2_linearIngest do
  assign_roles
  
end

############################## Linear Indexer ############################## #:nodoc:
task :merdevlBo2_linearIndexer do
  assign_roles
end

############################## Local Listing Info WS ############################## #:nodoc:
task :merdevlBo2_localListingInfoWebService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :merdevlBo2_locationDataService do
  assign_roles
  
end

############################## location Ingest ############################## #:nodoc:
task :merdevlBo2_locationIngest do
  assign_roles
  
end

############################## Location Indexer ############################## #:nodoc:
task :merdevlBo2_locationIndexer do
  assign_roles
end

############################## matchWebService ############################## #:nodoc:
task :merdevlBo2_matchWebService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :merdevlBo2_menuDataService do
  assign_roles
  
end


############################## mmmWebService  ############################## #:nodoc:
task :merdevlBo2_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :merdevlBo2_mmpWebService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merdevlBo2_offerDataService do
  assign_roles
  
end

############################## offerIngest ############################## #:nodoc:
task :merdevlBo2_offerIngest do
  assign_roles
  
end

############################## offerWebService ############################## #:nodoc:
task :merdevlBo2_offerWebService do
  assign_roles
end

############################## partnerIngest WS ############################## #:nodoc:
task :merdevlBo2_partnerIngestWebService do
  assign_roles
 
end

############################## personaIngest WS ############################## #:nodoc:
task :merdevlBo2_personaIngestWebService do
  assign_roles
end

############################## playTimeService ############################## #:nodoc:
task :merdevlBo2_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end


############################## reatGWTService ############################## #:nodoc:
task :merdevlBo2_reatGWTService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :merdevlBo2_scheduledIngestWebService do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :merdevlBo2_sportsDataService do
  assign_roles
end

############################## sportsIngest WebService ############################## #:nodoc:
task :merdevlBo2_sportsIngestWebService do
  assign_roles
end

############################## subscriberDataService  ############################## #:nodoc:
task :merdevlBo2_subscriberDataService do
  assign_roles
end

############################## triageWebService ############################## #:nodoc:
task :merdevlBo2_triageWebService do
  assign_roles
end

############################## TPDS ############################## #:nodoc:
task :merdevlBo2_toolPreferenceDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################


#########################################################################################
# SPECIAL TASKS
#########################################################################################

############################## gdash ##############################
task :merdevlBo2_gdash do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## jmxtrans ##############################
task :merdevlBo2_jmxtrans do
  assign_roles
  set_vars_from_hiera(%w[ metrics_host metrics_port noBom url ])
end


############################## haproxy ##############################
task :merdevlBo2_haproxy do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## rabbitmq ##############################
task :merdevlBo2_rabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :merdevlBo2_rabbitMGT do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :merdevlBo2_imageRabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :merdevlBo2_imageRabbitMGT do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end
############################### mongoDB##################################
task :merdevlBo2_mongoDB do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## AccountContentEventWebService ############################## #:nodoc:
task :merdevlBo2_accountContentEventWebService do
  assign_roles
end
############################## cacheProfileWebService ############################## #:nodoc:
task :merdevlBo2_cacheProfileWebService do
  assign_roles
end
############################## scheduledTaskWebService ############################## #:nodoc:
task :merdevlBo2_scheduledTaskWebService do
  assign_roles
end
############################# nagios ##############################
task :merdevlBo2_nagios do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

#########################################################################################
# END SPECIAL TASKS
#########################################################################################
