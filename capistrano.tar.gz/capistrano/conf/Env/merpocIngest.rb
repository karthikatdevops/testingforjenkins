###############
# FILE LOADING
###############
 

load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## accountContentEventWebService ##################
task :merpocIngest_accountContentEventWebService do
  assign_roles
end

############################## cacheProfileWebService ############################## #:nodoc:
task :merpocIngest_cacheProfileWebService do
  assign_roles
end

############################## caretakerWebService ############################## #:nodoc:
task :merpocIngest_caretakerWebService do
  assign_roles
end

############################## coatGWTService ############################## #:nodoc:
task :merpocIngest_coatGWTService do
 assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :merpocIngest_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :merpocIngest_combineService do
  assign_roles
end

############################## consistency WS ############################## #:nodoc:
task :merpocIngest_consistencyWebService do
  assign_roles
end


############################## Entity DS ############################## #:nodoc:
task :merpocIngest_entityDataService do
  assign_roles
end

############################## entityIndex Solr ############################## #:nodoc:
task :merpocIngest_merlinSolr do
  assign_roles
end

############################## entityIndexer ############################## #:nodoc:
task :merpocIngest_entityIndexer do
  assign_roles
end

############################## entityIngest DS ############################## #:nodoc:
task :merpocIngest_entityIngest do
  assign_roles
end

############################## feedgenWebService ############################## #:nodoc:
task :merpocIngest_feedgenWebService do
  assign_roles
  role :feedgenWebServiceWebHosts, "ccpccm-po-c003-p.po.ccp.cable.comcast.com", "ccpccm-po-c004-p.po.ccp.cable.comcast.com", "ccpccm-br-c003-p.br.ccp.cable.comcast.com", "ccpccm-br-c004-p.br.ccp.cable.comcast.com"
end

############################## gridWebService  ############################## #:nodoc:
task :merpocIngest_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :merpocIngest_idDataService do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :merpocIngest_ingestRovi do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :merpocIngest_ingestWebService do
  assign_roles
  
  
end

############################## job DS ############################## #:nodoc:
task :merpocIngest_jobDataService do
  assign_roles
  
  
end

############################## Linear DS ############################## #:nodoc:
task :merpocIngest_linearDataService do
  assign_roles
  
  
end

############################## linear Indexer ############################## #:nodoc:
task :merpocIngest_linearIndexer do
  assign_roles
end

############################## linearIngest DS ############################## #:nodoc:
task :merpocIngest_linearIngest do
  assign_roles
  
  
end

############################## location DS ############################## #:nodoc:
task :merpocIngest_locationDataService do
  assign_roles

  
end

############################## location Indexer ############################## #:nodoc:
task :merpocIngest_locationIndexer do
  assign_roles
end

############################## location Ingest ############################## #:nodoc:
task :merpocIngest_locationIngest do
  assign_roles
  
  
end

############################## matchWebService ############################## #:nodoc:
task :merpocIngest_matchWebService do
  assign_roles

  
end

############################## menuDataService ############################## #:nodoc:
task :merpocIngest_menuDataService do
  assign_roles
  
  
end

############################# Menu Indexer ########################### #:nodoc
task :merpocIngest_menuIndexer do
  assign_roles
end

############################## miceGWTService ############################## #:nodoc:
task :merpocIngest_miceGWTService do
  assign_roles  
end

############################## mmmWebService  ############################## #:nodoc:
task :merpocIngest_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :merpocIngest_mmpWebService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merpocIngest_offerDataService do
  assign_roles

end

############################# offerIngest ############################## #:nodoc:
task :merpocIngest_offerIngest do
  assign_roles
 
  
end

############################## offerWebService ############################## #:nodoc:
task :merpocIngest_offerWebService do
  assign_roles

end

############################# partnerIngest WS ############################## #:nodoc:
task :merpocIngest_partnerIngestWebService do
  assign_roles
  

end

############################## personaIngest WS ############################## #:nodoc:
task :merpocIngest_personaIngestWebService do
  # personaIngest cannot be clustered... only deploy on one host.
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :merpocIngest_reatGWTService do
  assign_roles
end

############################## scheduledTaskWebService ############################## #:nodoc:
task :merpocIngest_scheduledTaskWebService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :merpocIngest_scheduledIngestWebService do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :merpocIngest_sportsDataService do
  assign_roles
end

############################## sportsIngestWebService ######################### #:nodoc:
task :merpocIngest_sportsIngestWebService do
  assign_roles
end

############################## subscriberDataService ############################## #:nodoc:
task :merpocIngest_subscriberDataService do
  assign_roles
end

############################## rabbitmq ##############################
task :merpocIngest_rabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :merpocIngest_rabbitMGT do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

############################## triageWebService ############################## #:nodoc:
task :merpocIngest_triageWebService do
  assign_roles
end

############################## TPDS  ############################## #:nodoc:
task :merpocIngest_toolPreferenceDataService do
  assign_roles
end

############################## commerceDataService  ############################## #:nodoc:
task :merpocIngest_commerceDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

