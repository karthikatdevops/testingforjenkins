 

load "./conf/Env/global.rb"


set_vars_from_hiera(%w[ arsBaseUrl availabilityTagBaseUrl availabilityTagHost availabilityTagPort browseSessionServiceBaseUrl browseSessionServiceHost browseSessionServicePort combineMpxOwnerid combineServiceBaseUrl combineServiceHost entityDataServiceBaseUrl entityServiceBaseUrl idServiceBaseUrl linearServiceBaseUrl linearServiceHost localVip locationDataServiceBaseUrl locationDataServiceHost logback_level_debug logback_level_error logback_level_info logback_level_warn menuDataServiceBaseUrl menuDataServiceHost menuDataServiceOwnerid menuDataServicePassword menuDataServicePort menuDataServiceUser menuVisibilityCountServiceBaseUrl menuVisibilityCountServiceHost menuVisibilityCountServicePort menuVisibilityCountServiceTitlesEndpoint menuWebServiceBaseUrl menuWebServiceHost menuWebServicePort merlinBackOfficeVip merlinFrontOfficeVip mpxAccessURL mpxIdentityURL offerIngestBaseUrl offerIngestHost offerServiceAdmin offerServiceBaseUrl offerServiceHost offerServiceOwnerid offerServicePassword offerServiceUser personalizedMenuWebServiceBaseUrl rabbitMQExchangeName rabbitMQExchangeVhost rabbitMQHost rabbitMQPort rexBaseHost rexBasePath rexBasePort rexBaseUrl rexBuilderUrl rexSearchUrl sessionRiakActive sessionRiakHost sessionRiakInitialPoolSize sessionRiakMaxPoolSize sessionRiakPort udbDemoMode uesEntitlementsServiceBaseUrl uesEntitlementsServiceHost uesEntitlementsServicePort useproxy userPreferenceDataServiceBaseUrl userPreferenceDataServiceHost userPreferenceDataServicePort videoDataServiceBaseUrl videoDataServiceHost videoDataServicePort wget_params ])

############################## udbprodNGB_browseSessionService ############################## #:nodoc:
def setProperties_udbprodNGB_browseSessionService
  set_vars_from_hiera(%w[ app_main projectArtifactId propertyFile ])
end

task :udbprodNGB_browseSessionService do
  assign_roles
  setProperties_udbprodNGB_browseSessionService
  set_vars_from_hiera(%w[ depends ])
end

############################## udbprodNGB_menuWebService ############################## #:nodoc:
def setProperties_udbprodNGB_menuWebService
  set_vars_from_hiera(%w[ app_main projectArtifactId propertyFile ])
end

task :udbprodNGB_menuWebService do
  assign_roles
  setProperties_udbprodNGB_menuWebService
  set_vars_from_hiera(%w[ depends ])
end

############################## udbprodNGB_menuVisibilityCountService ############################## #:nodoc:
def setProperties_udbprodNGB_menuVisibilityCountService
  set_vars_from_hiera(%w[ app_main projectArtifactId propertyFile ])
end

task :udbprodNGB_menuVisibilityCountService do
  assign_roles
  setProperties_udbprodNGB_menuVisibilityCountService
  set_vars_from_hiera(%w[ depends ])
end

############################## videoDataService ############################## #:nodoc:
def setProperties_udbprodNGB_videoDataService
  set_vars_from_hiera(%w[ app_main projectArtifactId propertyFile ])
end

task :udbprodNGB_videoDataService do
  assign_roles
  setProperties_udbprodNGB_videoDataService
  set_vars_from_hiera(%w[ depends ])
end

############################## tRex ############################## #:nodoc:
def setProperties_udbprodNGB_tRex
  set_vars_from_hiera(%w[ app_main projectArtifactId propertyFile ])
end

task  :udbprodNGB_tRex do
  assign_roles
  setProperties_udbprodNGB_tRex
  set_vars_from_hiera(%w[ depends ])
end

#########################################################################################
# END UDB DEPLOYMENT TASKS
#########################################################################################
