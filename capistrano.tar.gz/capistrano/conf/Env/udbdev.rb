 

load "./conf/Env/global.rb"

set_vars_from_hiera(%w[     rabbitmq_host     ])

set_vars_from_hiera(%w[ availabilityTagHost availabilityTagPort browseSessionServiceHost commerceDataServiceHost commerceDataServicePassword commerceDataServiceUser confType contextServiceHost contextServicePort enableAuthenticationMerlinAndXBO enableAuthenticationXBO logback_level_debug logback_level_error logback_level_info logback_level_warn menuDataServiceHost menuDataServicePassword menuDataServiceUser menuVisibilityCountServiceHost menuVisibilityCountServiceTitlesEndpoint menuVisibilityCountServicepropertyFile menuWebServiceHost    mpx_base_url offerServicePassword offerServiceUser rabbitMQExchangeName rabbitMQExchangeVhost rabbitMQHost rabbitMQPort rexBaseHost rexBasePath rexBasePort subscriberRiakHost subscriberRiakHttpPort subscriberRiakPbcPort subscriberServiceHost subscriberServicePort titleServerPrimePort  uesEntitlementsServiceHost uesEntitlementsServicePort universalResumePointHost universalResumePointPort useproxy userPreferenceDataServiceHost userPreferenceDataServicePassword userPreferenceDataServiceUser videoDataServiceBaseUrl videoDataServiceHost offerIngestHost combineServiceHost locationDataServiceHost linearDataServiceHost entityServiceHost idServiceHost linearServiceHost offerServiceHost linearDataServiceBaseUrl entityServiceBaseUrl locationDataServiceBaseUrl idServiceBaseUrl linearServiceBaseUrl browseSessionServiceBaseUrl menuDataServiceBaseUrl offerServiceAdmin combineServiceBaseUrl userPreferenceDataServiceBaseUrl subscriberServiceBaseUrl commerceDataServiceBaseUrl videoDataServiceBaseUrl menuVisibilityCountServiceBaseUrl menuWebServiceBaseUrl offerServiceBaseUrl offerIngestBaseUrl subscriberRiakHttpBaseUrl offerServiceOwnerid rexBaseUrl menuWebServicePort browseSessionServicePort userPreferenceDataServiceAdmin menuDataServicePort videoDataServicePort commerceDataServiceAdmin menuVisibilityCountServicePort commerceDataServicePort menuDataServiceAdmin userPreferenceDataServicePort subscriberRiakPbcBaseUrl ])

set_vars_from_hiera(%w[ menuDataServiceOwnerid userPreferenceDataServiceOwnerid commerceDataServiceOwnerid ])

############################## udbdev_menuDataService ############################## #:nodoc:
task :udbdev_menuDataService do
  assign_roles
end

############################## udbdev_userPreferenceDataService ############################## #:nodoc:
task :udbdev_userPreferenceDataService do
  assign_roles
end

############################## udbdev_commerceDataService ############################## #:nodoc:
task :udbdev_commerceDataService do
  assign_roles
end


############################## udbdev_browseSessionService ############################## #:nodoc:
task :udbdev_browseSessionService do
  assign_roles
    
  set_vars_from_hiera(%w[ depends projectArtifactId propertyFile ])
end

############################## udbdev_contextDataService ############################## #:nodoc:
task :udbdev_contextDataService do
  assign_roles
  
  set_vars_from_hiera(%w[ depends projectArtifactId propertyFile ])
end

############################## videoDataService ############################## #:nodoc:
task :udbdev_videoDataService do
  assign_roles
  
  set_vars_from_hiera(%w[ depends projectArtifactId propertyFile ])
end


############################## udbdev_menuVisibilityCountService ############################## #:nodoc:
task :udbdev_menuVisibilityCountService do
  assign_roles
  
  set_vars_from_hiera(%w[ depends projectArtifactId propertyFile ])
end

############################## udbdev_titleServerPrime ############################## #:nodoc:
task :udbdev_titleServerPrime do
  assign_roles
  
  set_vars_from_hiera(%w[ depends projectArtifactId propertyFile ])
end

############################## udbdev_menuWebService ############################## #:nodoc:
task :udbdev_menuWebService do
  assign_roles
  
  set_vars_from_hiera(%w[ depends projectArtifactId propertyFile ])
end
#########################################################################################
# END UDB DEPLOYMENT TASKS
#########################################################################################
