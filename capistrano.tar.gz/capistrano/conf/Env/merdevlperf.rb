 

###############
# FILE LOADING
###############
load "./conf/Env/global.rb"

set_vars_from_hiera(%w[ logback_access_pattern_override ])

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## caretakerWebService ############################## #:nodoc:
task :merdevlperf_caretakerWebService do
  assign_roles
end

############################## coatGWTService ############################## #:nodoc:
task :merdevlperf_coatGWTService do
  assign_roles
    
 
end

############################## cfig WS ############################## #:nodoc:
task :merdevlperf_cfigdevWebService do
  assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :merdevlperf_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :merdevlperf_combineService do
  assign_roles
end

############################## consistencyWebService ############################## #:nodoc:
task :merdevlperf_consistencyWebService do
  assign_roles
end

############################## Entity DS ############################## #:nodoc:
task :merdevlperf_entityDataService do
  assign_roles
    
  
end

############################### entityIndex Solr ############################## #:nodoc:
task :merdevlperf_entityIndex do
  assign_roles
end

############################# Entity Indexer ########################### #:nodoc
task :merdevlperf_entityIndexer do
  assign_roles
end

############################## entityIngest DS ############################## #:nodoc:
task :merdevlperf_entityIngest do
  assign_roles
end


############################## gridWebService  ############################## #:nodoc:
task :merdevlperf_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :merdevlperf_idDataService do
  assign_roles
end

############################## image WS ############################## #:nodoc:
task :merdevlperf_imageWebService do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :merdevlperf_ingestWebService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :merdevlperf_jobDataService do
  assign_roles
  
  
end

############################## Linear DS ############################## #:nodoc:
task :merdevlperf_linearDataService do
  assign_roles
  
  
end

############################## linearIngest DS ############################## #:nodoc:
task :merdevlperf_linearIngest do
  assign_roles
  
  
end

############################## Local Listing Info WS ############################## #:nodoc:
task :merdevlperf_localListingInfoWebService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :merdevlperf_locationDataService do
  assign_roles
  
  
end

############################## location Ingest ############################## #:nodoc:
task :merdevlperf_locationIngest do
  assign_roles
  
  
end

############################## jiraSprintReport ############################## #:nodoc:
# task :merdevlperf_jiraSprintReport do
#   assign_roles
# end

############################## matchWebService ############################## #:nodoc:
task :merdevlperf_matchWebService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :merdevlperf_menuDataService do
  assign_roles
  
  
end

############################## miceGWTService ############################## #:nodoc:
task :merdevlperf_miceGWTService do
  assign_roles
end

############################## mmmWebService  ############################## #:nodoc:
task :merdevlperf_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :merdevlperf_mmpWebService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merdevlperf_offerDataService do
  assign_roles
  
  
end

############################## offerIngest ############################## #:nodoc:
task :merdevlperf_offerIngest do
  assign_roles
  
  
end

############################## offerWebService ############################## #:nodoc:
task :merdevlperf_offerWebService do
  assign_roles
end

############################## personaIngest WS ############################## #:nodoc:
task :merdevlperf_personaIngestWebService do
  assign_roles
end

############################## Program Availability 2.0 ############################## #:nodoc:
task :merdevlperf_programAvailability2 do
  assign_roles
end

############################## programIndex2 Solr ############################## #:nodoc:
task :merdevlperf_programIndex2 do
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :merdevlperf_reatGWTService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :merdevlperf_scheduledIngestWebService do
  assign_roles
end

############################## Search Updater 2 ############################## #:nodoc:
##  mpx stuff will be broken in DS_Configuration.xml settings don't match  ##
##  someone should fix the cap scripts so that the entries match ##
task :merdevlperf_searchUpdaterWebService2 do
  assign_roles
end


############################## udbMockService ############################## #:nodoc:
task :merdevlperf_udbMockService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################


#########################################################################################
# SPECIAL TASKS
#########################################################################################

############################## gdash ##############################
task :merdevlperf_gdash do
  assign_roles
    
  set_vars_from_hiera(%w[ noBom ])
end

############################## jmxtrans ##############################
task :merdevlperf_jmxtrans do
  assign_roles
    
  set_vars_from_hiera(%w[ metrics_host metrics_port noBom url ])
end

############################# nagios ##############################
task :merdevlperf_nagios do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

############################## qamParityReport ##############################
task :merdevlperf_qamParityReport do
  assign_roles
end

############################## qamParityReport ##############################
task :merdevlperf_ppvGapReport do
  assign_roles
end

############################## haproxy ##############################
task :merdevlperf_haproxy do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end


#########################################################################################
# END SPECIAL TASKS
#########################################################################################
