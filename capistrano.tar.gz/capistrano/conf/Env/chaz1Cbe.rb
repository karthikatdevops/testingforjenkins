###############
# FILE LOADING
###############
 

load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :chaz1Cbe_entityDataService do
  assign_roles
end

############################## grid WS ############################## #:nodoc:
task :chaz1Cbe_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :chaz1Cbe_idDataService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :chaz1Cbe_jobDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :chaz1Cbe_linearDataService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :chaz1Cbe_locationDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :chaz1Cbe_offerDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

