 

load "./conf/Env/global.rb"

################################ **** A2G ***** #################################

############################## tqmTb1_castl ############################## #:nodoc:
task :tqmTb1_castl do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_crate ############################## #:nodoc:
task :tqmTb1_crate do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

task :tqmTb1_alfred do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

############################## tqmTb1_exileBootstrap ############################## #:nodoc:
task :tqmTb1_exileBootstrap do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_exileWebServer ############################## #:nodoc:
task :tqmTb1_exileWebServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




################################ **** MAPS ***** #################################

############################## tqmTb1_menuWebService ############################## #:nodoc:
task :tqmTb1_menuWebService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_menuVisibilityCountService ############################## #:nodoc:
task :tqmTb1_menuVisibilityCountService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_browseSessionService ############################## #:nodoc:
task :tqmTb1_browseSessionDataService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_videoDataService ############################## #:nodoc:
task :tqmTb1_videoDataService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_tRex ############################## #:nodoc:
task :tqmTb1_tRex do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




################################ **** UNU ***** #########################################

############################## tqmTb1_digitalRightsLocker ############################## #:nodoc:
task :tqmTb1_digitalRightsLocker do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_remoteDigitalRightsLocker ############################## #:nodoc:
task :tqmTb1_remoteDigitalRightsLocker do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_unuHazelcastServer ############################## #:nodoc:
task :tqmTb1_unuHazelcastServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_luna ############################## #:nodoc:
task :tqmTb1_luna do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_unuServer ############################## #:nodoc:
task :tqmTb1_unuServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_cuUnuServer ############################## #:nodoc:
task :tqmTb1_cuUnuServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome installdir])
end

############################## tqmTb1_menuItemServer ############################## #:nodoc:
task :tqmTb1_menuItemServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_titleServer ############################## #:nodoc:
task :tqmTb1_titleServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_unuRolo ############################## #:nodoc:
task :tqmTb1_unuRolo do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_vps-campaign-agent ############################## #:nodoc:
task :tqmTb1_vps do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_mms ############################## #:nodoc:
task :tqmTb1_mms do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_tim ############################## #:nodoc:
task :tqmTb1_tim do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_ngpServerForTim ############################## #:nodoc:
task :tqmTb1_ngpServerForTim do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




############################## tqmTb1_availabilityResolutionService ############################## #:nodoc:
task :tqmTb1_availabilityResolutionService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end


############################## tqmTb1_commerceDataService ############################## #:nodoc:
task :tqmTb1_commerceDataService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_maestroServer ############################## #:nodoc:
task :tqmTb1_maestroServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_ngpServer ############################## #:nodoc:
task :tqmTb1_ngpServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




################################ **** UES ***** ############################################

############################## tqmTb1_uesWebApp ############################## #:nodoc:
task :tqmTb1_uesWebApp do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_uesProducer ############################## #:nodoc:
task :tqmTb1_uesProducer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_uesB1NotificationIngestConsumer ############################## #:nodoc:
task :tqmTb1_uesB1NotificationIngestConsumer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_uesNotificationIngestConsumer ############################## #:nodoc:
task :tqmTb1_uesNotificationIngestConsumer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_uesServer ############################## #:nodoc:
task :tqmTb1_uesServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb1_e2gWebService ############################## #:nodoc:
task :tqmTb1_e2gWebService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_maestroServer ############################## #:nodoc:
task :tqmTb3_maestroServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




#########################################################################################
# END UDB DEPLOYMENT TASKS
#########################################################################################
