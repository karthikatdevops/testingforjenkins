load "./conf/Env/global.rb"

# Updated July 2014 for 3rd cfig vm, now we have one for dev, qa, prod

# DEV : app-br-12e.idk.cable.comcast.com - 69.252.220.142 - dev.cfig.compass.comcast.com
# QA  : app-br-14b.idk.cable.comcast.com - 69.252.220.172 - qa.cfig.compass.comcast.com
# PROD: app-br-19e.idk.cable.comcast.com - 69.252.220.162 - prod.cfig.compass.comcast.com

set_vars_from_hiera(%w[ cfigRabbitPort cfigVip cfigdevVip cim_sftp_host clientFTPVip logback_level_debug logback_level_error logback_level_info logback_level_warn  ])

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## CFIG PROD ############################## #:nodoc:
task :meridk_cfigWebService do
  assign_roles

  set_vars_from_hiera(%w[ cfigRabbitPassword cfigRabbitUsername cfigRabbitVhost cfigWebService_ncds_controllersFileCfig cfigWebService_ncds_controllersFileDacs cfigWebService_ncds_proxyHost cfigWebService_ncds_proxyPort cfigWebService_ncds_useUploadFiles ])
end
