###############
# FILE LOADING
###############
load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## accountContentEventWebService ##################
task :merch2cIngest_accountContentEventWebService do
  assign_roles
end

############################## cacheProfileWebService ############################## #:nodoc:
task :merch2cIngest_cacheProfileWebService do
  assign_roles
end

############################## caretakerWebService ############################## #:nodoc:
task :merch2cIngest_caretakerWebService do
  assign_roles
end

############################## coatGWTService ############################## #:nodoc:
task :merch2cIngest_coatGWTService do
  assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :merch2cIngest_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :merch2cIngest_combineService do
  assign_roles
end

############################## consistency WS ############################## #:nodoc:
task :merch2cIngest_consistencyWebService do
  assign_roles
end

############################## Entity DS ############################## #:nodoc:
task :merch2cIngest_entityDataService do
  assign_roles
end

############################## entityIndex Solr ############################## #:nodoc:
task :merch2cIngest_merlinSolr do
  assign_roles
end

############################## entityIndexer ############################## #:nodoc:
task :merch2cIngest_entityIndexer do
  assign_roles
end

############################## entityIngest DS ############################## #:nodoc:
task :merch2cIngest_entityIngest do
  assign_roles
end

############################## fedRex ###################################### #:nodoc:
desc "Keeping this here just to preserve fedRex vip in haproxy - see ch2c_fedRex for deployment"
task :merch2cIngest_fedRex do
  # NGB service
  assign_roles
end

############################## feedgenWebService ############################## #:nodoc:
task :merch2cIngest_feedgenWebService do
  assign_roles
  role :feedgenWebServiceWebHosts, "merlin-ch2-a22p.cable.comcast.com"
end

############################## id DS ############################## #:nodoc:
task :merch2cIngest_idDataService do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :merch2cIngest_ingestRovi do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :merch2cIngest_ingestWebService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :merch2cIngest_jobDataService do
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :merch2cIngest_linearDataService do
  assign_roles
end

############################## linear Indexer ############################## #:nodoc:
task :merch2cIngest_linearIndexer do
  assign_roles
end

############################## linearIngest DS ############################## #:nodoc:
task :merch2cIngest_linearIngest do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :merch2cIngest_locationDataService do
  assign_roles
end

############################## location Indexer ############################## #:nodoc:
task :merch2cIngest_locationIndexer do
  assign_roles
end

############################## location Ingest ############################## #:nodoc:
task :merch2cIngest_locationIngest do
  assign_roles
end

############################## matchWebService ############################## #:nodoc:
task :merch2cIngest_matchWebService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :merch2cIngest_menuDataService do
  assign_roles
end

############################# Menu Indexer ########################### #:nodoc
task :merch2cIngest_menuIndexer do
  assign_roles
end

############################# miceGWTService ############################## #:nodoc:
task :merch2cIngest_miceGWTService do
  assign_roles
end

############################## mmmWebService  ############################## #:nodoc:
task :merch2cIngest_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :merch2cIngest_mmpWebService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merch2cIngest_offerDataService do
  assign_roles
end

############################# offerIngest ############################## #:nodoc:
task :merch2cIngest_offerIngest do
  assign_roles
end

############################## offerWebService ############################## #:nodoc:
task :merch2cIngest_offerWebService do
  assign_roles
end

############################# partnerIngest WS ############################## #:nodoc:
task :merch2cIngest_partnerIngestWebService do
  assign_roles
end

############################## personaIngest WS ############################## #:nodoc:
task :merch2cIngest_personaIngestWebService do
  # personaIngest cannot be clustered... only deploy on one host.
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :merch2cIngest_reatGWTService do
  assign_roles
end

############################## scheduledTaskWebService ############################## #:nodoc:
task :merch2cIngest_scheduledTaskWebService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :merch2cIngest_scheduledIngestWebService do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :merch2cIngest_sportsDataService do
  assign_roles
end

############################## sportsIngestWebService ######################### #:nodoc:
task :merch2cIngest_sportsIngestWebService do
  assign_roles
end

############################## subscriberDataService ############################## #:nodoc:
task :merch2cIngest_subscriberDataService do
  assign_roles
end

############################## rabbitmq ##############################
task :merch2cIngest_rabbitMQ do
  assign_roles

  set_vars_from_hiera(%w[ noBom rabbitMQ_web_port ])
end

task :merch2cIngest_rabbitMGT do
  assign_roles

  set_vars_from_hiera(%w[ noBom rabbitMGT_web_port ])
end

task :merch2cIngest_haproxy do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

task :merch2cIngest_image_rabbitmq do
  assign_roles
end

task :merch2cIngest_image_rabbitmgt do
  assign_roles
end

############################## triageWebService ############################## #:nodoc:
task :merch2cIngest_triageWebService do
  assign_roles
end

############################## TPDS  ############################## #:nodoc:
task :merch2cIngest_toolPreferenceDataService do
  assign_roles
end

############################## commerceDataService ############################## #:nodoc:
task :merch2cIngest_commerceDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

