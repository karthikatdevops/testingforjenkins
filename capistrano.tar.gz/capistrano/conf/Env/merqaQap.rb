 

load "./conf/Env/global.rb"



##############
# MERQA QAP - QA Performance HEAD (was Legacy)
#############

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :merqaQap_entityDataService do
  assign_roles
    
  
end

############################## gridWebService  ############################## #:nodoc:
task :merqaQap_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :merqaQap_idDataService do
  assign_roles
    
end

############################## job DS ############################## #:nodoc:
task :merqaQap_jobDataService do
  assign_roles
    
  
end

############################## Linear DS ############################## #:nodoc:
task :merqaQap_linearDataService do
  assign_roles
    
  
end
 
############################## localListingInfoWebService ############################## #:nodoc:
task :merqaQap_localListingInfoWebService do
  assign_roles
    
  
end

############################## locationDataService ############################## #:nodoc:
task :merqaQap_locationDataService do
  assign_roles
    
  
end

############################## offerDataService ############################## #:nodoc:
task :merqaQap_offerDataService do
  assign_roles
    
  
end

############################## Program Availability2 ############################## #:nodoc:
#Adding a013 & a014 per CHANGE-2643
task :merqaQap_programAvailability2 do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

