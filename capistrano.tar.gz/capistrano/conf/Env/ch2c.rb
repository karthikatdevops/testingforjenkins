###############
# FILE LOADING
###############
load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :ch2c_entityDataService do
    assign_roles
end

############################## id DS ############################## #:nodoc:
task :ch2c_idDataService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :ch2c_jobDataService do  
  assign_roles
end

############################## Linear DS ############################## #:nodoc:
task :ch2c_linearDataService do  
  assign_roles
end

############################## localListingInfoWebService ############################## #:nodoc:
task :ch2c_localListingInfoWebService do
  assign_roles
end

############################## locationDataService ############################## #:nodoc:
task :ch2c_locationDataService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :ch2c_menuDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :ch2c_offerDataService do
  assign_roles
end

############################## playTimeService ############################## #:nodoc:
task :ch2c_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## commerceDataService ############################## #:nodoc:
task :ch2c_commerceDataService do
  assign_roles
end

############################## cacheProfileWebService ############################## #:nodoc:
task :ch2c_cacheProfileWebService do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :ch2c_sportsDataService do
  assign_roles
end

task :ch2c_haproxy do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

############################## fedRex ###################################### #:nodoc:
task :ch2c_fedRex do
  # NGB service
  assign_roles
  set_vars_from_hiera(%w[ app_main depends projectArtifactId propertyFile rexBaseUrl fedRex_menu_ds_url fedRex_server_port fedrex_browse_url grid_web_service_trending_url linear_ds_url menu_web_service_base_url id_ds_url enhanced_entity_service_url xbi_memsql_jdbc ])
end

# task :ch2c_availabilityResolutionService2 do
#   # NGB service
#   assign_roles
# end


#########################################################################################
# SPECIAL TASKS
#########################################################################################

############################## qamParityReport ##############################
task :ch2c_qamParityReport do
  assign_roles
end

#########################################################################################
# END SPECIAL TASKS
#########################################################################################
