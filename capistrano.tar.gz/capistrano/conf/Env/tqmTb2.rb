 

load "./conf/Env/global.rb"

################################ **** A2G ***** #################################

############################## tqmTb2_castl ############################## #:nodoc:
task :tqmTb2_castl do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_crate ############################## #:nodoc:
task :tqmTb2_crate do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

task :tqmTb2_alfred do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end



################################ **** MAPS ***** #######################################

############################## tqmTb2_menuWebService ############################## #:nodoc:
task :tqmTb2_menuWebService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_menuVisibilityCountService ############################## #:nodoc:
task :tqmTb2_menuVisibilityCountService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_browseSessionService ############################## #:nodoc:
task :tqmTb2_browseSessionDataService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_videoDataService ############################## #:nodoc:
task :tqmTb2_videoDataService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_tRex ############################## #:nodoc:
task :tqmTb2_tRex do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




################################ **** UNU ***** ############################################

############################## tqmTb2_digitalRightsLocker ############################## #:nodoc:
task :tqmTb2_digitalRightsLocker do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_remoteDigitalRightsLocker ############################## #:nodoc:
task :tqmTb2_remoteDigitalRightsLocker do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_dscBundy ############################## #:nodoc:
task :tqmTb2_dscBundy do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_exileBootstrap ############################## #:nodoc:
task :tqmTb2_exileBootstrap do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_exileWebServer ############################## #:nodoc:
task :tqmTb2_exileWebServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_unuHazelcastServer ############################## #:nodoc:
task :tqmTb2_unuHazelcastServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_luna ############################## #:nodoc:
task :tqmTb2_luna do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_unuServer ############################## #:nodoc:
task :tqmTb2_unuServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_cuUnuServer ############################## #:nodoc:
task :tqmTb2_cuUnuServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome installdir])
end

############################## tqmTb2_menuItemServer ############################## #:nodoc:
task :tqmTb2_menuItemServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_titleServer ############################## #:nodoc:
task :tqmTb2_titleServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_unuRolo ############################## #:nodoc:
task :tqmTb2_unuRolo do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_vps-campaign-agent ############################## #:nodoc:
task :tqmTb2_vps do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_tim ############################## #:nodoc:
task :tqmTb2_tim do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_availabilityResolutionService ############################## #:nodoc:
task :tqmTb2_availabilityResolutionService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_maestroServer ############################## #:nodoc:
task :tqmTb2_maestroServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_ngpServer ############################## #:nodoc:
task :tqmTb2_ngpServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end



################################ **** UES ***** ############################################

############################## tqmTb2_uesWebApp ############################## #:nodoc:
task :tqmTb2_uesWebApp do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_uesProducer ############################## #:nodoc:
task :tqmTb2_uesProducer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_uesB1NotificationIngestConsumer ############################## #:nodoc:
task :tqmTb2_uesB1NotificationIngestConsumer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_uesNotificationIngestConsumer ############################## #:nodoc:
task :tqmTb2_uesNotificationIngestConsumer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_uesServer ############################## #:nodoc:
task :tqmTb2_uesServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb2_e2gWebService ############################## #:nodoc:
task :tqmTb2_e2gWebService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end



#########################################################################################
# END UDB DEPLOYMENT TASKS
#########################################################################################
