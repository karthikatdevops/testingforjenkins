###############
# FILE LOADING
###############
 
load "./conf/Env/global.rb"

set_vars_from_hiera(%w[ post_seeds ])

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## Entity DS ############################## #:nodoc:
task :ccpcicap_entityDataService do
  assign_roles
end

############################## Local Listing Info WS ############################## #:nodoc:
task :ccpcicap_localListingInfoWebService do
  assign_roles
end


#################################################################################################### #:nodoc:
