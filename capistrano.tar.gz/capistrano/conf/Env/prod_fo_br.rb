###############
# FILE LOADING
###############
 
load "./conf/Env/global.rb"

#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## accountContentEventWebService ##################
task :prod_fo_br_accountContentEventWebService do
  assign_roles
end

############################## caretakerWebService ############################## #:nodoc:
task :prod_fo_br_caretakerWebService do
  assign_roles
end

############################## coatGWTService ############################## #:nodoc:
task :prod_fo_br_coatGWTService do
 assign_roles
end

############################## cloverServer ############################## #:nodoc:
task :prod_fo_br_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :prod_fo_br_combineService do
  assign_roles
end

############################## consistency WS ############################## #:nodoc:
task :prod_fo_br_consistencyWebService do
  assign_roles
end


############################## Entity DS ############################## #:nodoc:
task :prod_fo_br_entityDataService do
  assign_roles
end

############################## entityIndex Solr ############################## #:nodoc:
task :prod_fo_br_merlinSolr do
  assign_roles
end

############################## entityIndexer ############################## #:nodoc:
task :prod_fo_br_entityIndexer do
  assign_roles
end

############################## entityIngest DS ############################## #:nodoc:
task :prod_fo_br_entityIngest do
  assign_roles
end

############################## feedgenWebService ############################## #:nodoc:
task :prod_fo_br_feedgenWebService do
  assign_roles
  role :feedgenWebServiceWebHosts, "ccpccm-po-c003-p.po.ccp.cable.comcast.com", "ccpccm-po-c004-p.po.ccp.cable.comcast.com", "ccpccm-br-c003-p.br.ccp.cable.comcast.com", "ccpccm-br-c004-p.br.ccp.cable.comcast.com"
end

############################## gridWebService  ############################## #:nodoc:
task :prod_fo_br_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :prod_fo_br_idDataService do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :prod_fo_br_ingestRovi do
  assign_roles
end

############################## imageWebService ############################## #:nodoc:
task :prod_fo_br_imageWebService do
  assign_roles
end

############################## ingestStagingWebService ############################## #:nodoc:
task :prod_fo_br_ingestStagingWebService do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :prod_fo_br_ingestWebService do
  assign_roles
  
  
end

############################## job DS ############################## #:nodoc:
task :prod_fo_br_jobDataService do
  assign_roles
  
  
end

############################## Linear DS ############################## #:nodoc:
task :prod_fo_br_linearDataService do
  assign_roles
  
  
end

############################## linear Indexer ############################## #:nodoc:
task :prod_fo_br_linearIndexer do
  assign_roles
end

############################## linearIngest DS ############################## #:nodoc:
task :prod_fo_br_linearIngest do
  assign_roles
  
  
end

############################## localListingInfoWebService ############################## #:nodoc:
task :prod_fo_br_localListingInfoWebService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :prod_fo_br_locationDataService do
  assign_roles

  
end

############################## location Indexer ############################## #:nodoc:
task :prod_fo_br_locationIndexer do
  assign_roles
end

############################## location Ingest ############################## #:nodoc:
task :prod_fo_br_locationIngest do
  assign_roles
  
  
end

############################## matchWebService ############################## #:nodoc:
task :prod_fo_br_matchWebService do
  assign_roles

  
end

############################## menuDataService ############################## #:nodoc:
task :prod_fo_br_menuDataService do
  assign_roles
  
  
end

############################# Menu Indexer ########################### #:nodoc
task :prod_fo_br_menuIndexer do
  assign_roles
end

############################## miceGWTService ############################## #:nodoc:
task :prod_fo_br_miceGWTService do
  assign_roles  
end

############################## mmmWebService  ############################## #:nodoc:
task :prod_fo_br_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :prod_fo_br_mmpWebService do
  assign_roles
end

########################## monsterEntityDataService  ####################### #:nodoc:
task :prod_fo_br_monsterEntityDataService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :prod_fo_br_offerDataService do
  assign_roles

end

############################# offerIngest ############################## #:nodoc:
task :prod_fo_br_offerIngest do
  assign_roles
 
  
end

############################## offerWebService ############################## #:nodoc:
task :prod_fo_br_offerWebService do
  assign_roles

end

############################# partnerIngest WS ############################## #:nodoc:
task :prod_fo_br_partnerIngestWebService do
  assign_roles
  

end

############################## personaIngest WS ############################## #:nodoc:
task :prod_fo_br_personaIngestWebService do
  # personaIngest cannot be clustered... only deploy on one host.
  assign_roles
end

############################## Program Availability2 ############################## #:nodoc:
task :prod_fo_br_programAvailability2 do
  assign_roles
  

end

############################## programIndex2 Solr ############################## #:nodoc:
task :prod_fo_br_programIndex2 do
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :prod_fo_br_reatGWTService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :prod_fo_br_scheduledIngestWebService do
  assign_roles
end

############################## Search Updater 2 ############################## #:nodoc:
task :prod_fo_br_searchUpdaterWebService2 do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :prod_fo_br_sportsDataService do
  assign_roles
end

############################## sportsIngestWebService ######################### #:nodoc:
task :prod_fo_br_sportsIngestWebService do
  assign_roles
end

############################## subscriberDataService ############################## #:nodoc:
task :prod_fo_br_subscriberDataService do
  assign_roles
end

############################## rabbitmq ##############################
task :prod_fo_br_rabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :prod_fo_br_rabbitMGT do
  assign_roles
  
  set_vars_from_hiera(%w[ noBom ])
end

############################## triageWebService ############################## #:nodoc:
task :prod_fo_br_triageWebService do
  assign_roles
end

############################## fedRex ###################################### #:nodoc:
task :prod_fo_br_fedRex do
  # NGB service
  assign_roles

  set_vars_from_hiera(%w[ app_main depends permgenspace projectArtifactId propertyFile rexBaseUrl xms xmx fedRex_menu_ds_url fedRex_server_port fedrex_browse_url grid_web_service_trending_url linear_ds_url menu_web_service_base_url id_ds_url ])
end

############################## playTimeService ############################## #:nodoc:
task :prod_fo_br_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome xmx ])
end

############################## commerceDataService  ############################## #:nodoc:
task :prod_fo_br_commerceDataService do
  assign_roles
end


#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################

