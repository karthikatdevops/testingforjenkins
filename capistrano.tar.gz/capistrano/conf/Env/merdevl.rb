 

load "./conf/Env/global.rb"

set_vars_from_hiera(%w[ cfigRabbitPort cim_sftp_host   logback_access_pattern_override logback_root_level logback_level_debug logback_level_error logback_level_info logback_level_warn machine0 machine1 machine2 machine3  ])


#################################################################################################### #:nodoc:
# DEPLOYMENT TASKS #:nodoc:
#################################################################################################### #:nodoc:

############################## caretakerWebService ############################## #:nodoc:
task :merdevl_caretakerWebService do
  assign_roles
end

############################## coatGWTService ############################## #:nodoc:
task :merdevl_coatGWTService do
  assign_roles
 
end

############################## cloverServer ############################## #:nodoc:
task :merdevl_cloverServer do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :merdevl_combineService do
  # assign_roles
  assign_roles
end

############################## consistencyWebService ############################## #:nodoc:
task :merdevl_consistencyWebService do
  assign_roles
  
end

############################## Entity DS ############################## #:nodoc:
task :merdevl_entityDataService do
  assign_roles
  
end

############################## fandangoIngestService ############################## #:nodoc:
task :merdevl_fandangoIngestService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end


############################### merlinSolr replaces entityIndex  ############################## #:nodoc:
task :merdevl_merlinSolr do
  assign_roles
end

############################### imageIndex separate Solr for images  ############################## #:nodoc:
task :merdevl_imageIndex do
  assign_roles
end

############################# Entity Indexer ########################### #:nodoc
task :merdevl_entityIndexer do
  assign_roles
end

############################# Menu Indexer ########################### #:nodoc
task :merdevl_menuIndexer do
  assign_roles
end


############################## entityIngest DS ############################## #:nodoc:
task :merdevl_entityIngest do
  assign_roles
  
end

############################## feedgenWebService ############################## #:nodoc:
task :merdevl_feedgenWebService do
  assign_roles
end

############################## gridWebService  ############################## #:nodoc:
task :merdevl_gridWebService do
  assign_roles

end

############################## id DS ############################## #:nodoc:
task :merdevl_idDataService do
 assign_roles
end

############################## image WS ############################## #:nodoc:
task :merdevl_imageWebService do
  assign_roles
end

############################## image DS ############################## #:nodoc:
task :merdevl_imageDataService do
  assign_roles
  
end

############################## image Ingest ############################## #:nodoc:
task :merdevl_imageIngest do
  assign_roles
  
end

############################## imageIngestWebService ############################## #:nodoc:
task :merdevl_imageIngestWebService do
  assign_roles
end

############################## imageEventWebService ############################## #:nodoc:
task :merdevl_imageEventWebService do
  assign_roles
end

############################## imageManagementWebService ############################## #:nodoc:
task :merdevl_imageManagementWebService do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :merdevl_ingestWebService do
  assign_roles
end

############################## ingestRovi ############################## #:nodoc:
task :merdevl_ingestRovi do
  assign_roles
end

############################## ingestTms ############################## #:nodoc:
task :merdevl_ingestTms do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :merdevl_jobDataService do
  assign_roles
  
end

############################## Linear DS ############################## #:nodoc:
task :merdevl_linearDataService do
  assign_roles
  
end

############################## linearIngest DS ############################## #:nodoc:
task :merdevl_linearIngest do
  assign_roles
  
end

############################## Linear Indexer ############################## #:nodoc:
task :merdevl_linearIndexer do
  assign_roles
end

############################## Local Listing Info WS ############################## #:nodoc:
task :merdevl_localListingInfoWebService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :merdevl_locationDataService do
  assign_roles
  
end

############################## location Ingest ############################## #:nodoc:
task :merdevl_locationIngest do
  assign_roles
  
end

############################## Location Indexer ############################## #:nodoc:
task :merdevl_locationIndexer do
  assign_roles
end

############################## matchWebService ############################## #:nodoc:
task :merdevl_matchWebService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :merdevl_menuDataService do
  assign_roles
  
end

############################## miceGWTService ############################## #:nodoc:
task :merdevl_miceGWTService do
  assign_roles
end

############################## mmmWebService  ############################## #:nodoc:
task :merdevl_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :merdevl_mmpWebService do
  assign_roles
end

############################## offer DS ############################## #:nodoc:
task :merdevl_offerDataService do
  assign_roles
  
end

############################## offerIngest ############################## #:nodoc:
task :merdevl_offerIngest do
  assign_roles
  
end

############################## offerWebService ############################## #:nodoc:
task :merdevl_offerWebService do
  assign_roles
end

############################## partnerIngest WS ############################## #:nodoc:
task :merdevl_partnerIngestWebService do
  assign_roles
 
end

############################## personaIngest WS ############################## #:nodoc:
task :merdevl_personaIngestWebService do
  assign_roles
end

############################## playTimeService ############################## #:nodoc:
task :merdevl_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## Program Availability 2.0 ############################## #:nodoc:
task :merdevl_programAvailability2 do
  assign_roles
end

############################## programIndex2 Solr ############################## #:nodoc:
task :merdevl_programIndex2 do
  assign_roles
end

############################## reatGWTService ############################## #:nodoc:
task :merdevl_reatGWTService do
  assign_roles
end

############################## scheduledIngest WebService ############################## #:nodoc:
task :merdevl_scheduledIngestWebService do
  assign_roles
end

############################## Search Updater 2 ############################## #:nodoc:
##  mpx stuff will be broken in DS_Configuration.xml settings don't match  ##
##  someone should fix the cap scripts so that the entries match ##
task :merdevl_searchUpdaterWebService2 do
  assign_roles
end

############################## sportsDataService ############################## #:nodoc:
task :merdevl_sportsDataService do
  assign_roles
end

############################## sportsIngest WebService ############################## #:nodoc:
task :merdevl_sportsIngestWebService do
  assign_roles
end

############################## subscriberDataService  ############################## #:nodoc:
task :merdevl_subscriberDataService do
  assign_roles
end

############################## triageWebService ############################## #:nodoc:
task :merdevl_triageWebService do
  assign_roles
end

############################## udbMockService ############################## #:nodoc:
task :merdevl_udbMockService do
  assign_roles
end

############################## TPDS ############################## #:nodoc:
task :merdevl_toolPreferenceDataService do
  assign_roles
end

#########################################################################################
# END MERLIN/MWS SERVICES
#########################################################################################


#########################################################################################
# SPECIAL TASKS
#########################################################################################

############################## gdash ##############################
task :merdevl_gdash do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## jmxtrans ##############################
task :merdevl_jmxtrans do
  assign_roles
  set_vars_from_hiera(%w[ metrics_host metrics_port noBom url ])
end

############################# nagios ##############################
task :merdevl_nagios do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## qamParityReport ##############################
task :merdevl_qamParityReport do
  assign_roles
end

############################## PPVReport ##############################
task :merdevl_ppvGapReport do
  assign_roles
end

############################## haproxy ##############################
task :merdevl_haproxy do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## rabbitmq ##############################
task :merdevl_rabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :merdevl_rabbitMGT do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :merdevl_imageRabbitMQ do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

task :merdevl_imageRabbitMGT do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end
############################## monsterEntityDataService ############################## #:nodoc:
task :merdevl_monsterEntityDataService do
  assign_roles
  set_vars_from_hiera(%w[  nosql_db_port service_shouldListen  monster_queue_username  monster_queue_virtualhost ])
end

############################## AccountContentEventWebService ############################## #:nodoc:
task :merdevl_accountContentEventWebService do
  assign_roles
end


#########################################################################################
# END SPECIAL TASKS
#########################################################################################
