 
  
###############
# FILE LOADING
###############
load "./conf/Env/global.rb"

################
# Environment specifics
################

############################## auth Proxy ############################## #:nodoc:
task :mciGbenv_authProxy do
  assign_roles
end

############################## combine WS ############################## #:nodoc:
task :mciGbenv_combineService do
  assign_roles
end

############################## gracenote combine WS ############################## #:nodoc:
task :mciGbenv_gracenoteCombineService do
  assign_roles
end

############################## consistency WS ############################## #:nodoc:
task :mciGbenv_consistencyWebService do
  assign_roles
  
  
end

############################## caretaker WS ############################## #:nodoc:
task :mciGbenv_caretakerWebService do
  assign_roles
end

############################## Entity DS ############################## #:nodoc:
task :mciGbenv_entityDataService do
  assign_roles
  
  
end

############################## Commerce DS ############################## #:nodoc:
task :mciGbenv_commerceDataService do
  assign_roles
  
end

task :mciGbenv_cru do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

############################## fandangoIngestService ############################## #:nodoc:
task :mciGbenv_fandangoIngestService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################### merlinSolr replaces entityIndex  ############################## #:nodoc:
task :mciGbenv_merlinSolr do
  assign_roles
end

############################### imageIndex separate Solr for images ############################## #:nodoc:
task :mciGbenv_imageIndex do
  assign_roles
end

############################# Entity Indexer########################### #:nodoc
task :mciGbenv_entityIndexer do
  assign_roles
  set_vars_from_hiera(%w[ ws_properties ])
end

############################## entityIngest DS ############################## #:nodoc:
task :mciGbenv_entityIngest do
  assign_roles
  
  
end

############################## feedgen WS ############################## #:nodoc:
task :mciGbenv_feedgenWebService do
  assign_roles
end

############################## gridWebService  ############################## #:nodoc:
task :mciGbenv_gridWebService do
  assign_roles
        
 
end

############################## id DS ############################## #:nodoc:
task :mciGbenv_idDataService do
  assign_roles
end

############################## gracenote id DS ############################## #:nodoc:
task :mciGbenv_idDataServiceGracenote do
  assign_roles
end

############################## ingest WebService ############################## #:nodoc:
task :mciGbenv_ingestWebService do
  assign_roles
end

############################## image DS ############################## #:nodoc:
task :mciGbenv_imageDataService do
  assign_roles
  
  
end

############################## imageManagementWebService ############################## #:nodoc:
task :mciGbenv_imageManagementWebService do
  assign_roles
end

############################## image Ingest ############################## #:nodoc:
task :mciGbenv_imageIngest do
  assign_roles
  
  
end

############################## job DS ############################## #:nodoc:
task :mciGbenv_jobDataService do
  assign_roles
  
  
end

############################## Linear DS ############################## #:nodoc:
task :mciGbenv_linearDataService do
  assign_roles
  
  
end

############################## linearIngest DS ############################## #:nodoc:
task :mciGbenv_linearIngest do
  assign_roles
  
  
end

############################# linear Indexer########################### #:nodoc
task :mciGbenv_linearIndexer do
  assign_roles
    
end

############################## Local Listing Info WS ############################## #:nodoc:
task :mciGbenv_localListingInfoWebService do
  assign_roles
end

############################## location DS ############################## #:nodoc:
task :mciGbenv_locationDataService do
  assign_roles
  
  
end

############################## location Ingest ############################## #:nodoc:
task :mciGbenv_locationIngest do
  assign_roles
  
  
end

############################# location Indexer########################### #:nodoc
task :mciGbenv_locationIndexer do
  assign_roles
    
end

############################## matchWebService ############################## #:nodoc:
task :mciGbenv_matchWebService do
  assign_roles
end

############################## menuDataService ############################## #:nodoc:
task :mciGbenv_menuDataService do
  assign_roles
  
  
end
############################# Menu Indexer ########################### #:nodoc
task :mciGbenv_menuIndexer do
  assign_roles
end

############################## mmmWebService  ############################## #:nodoc:
task :mciGbenv_mmmWebService do
  assign_roles
end

############################## mmpWebService  ############################## #:nodoc:
task :mciGbenv_mmpWebService do
  assign_roles
end

############################## monsterEntityDataService ############################## #:nodoc:
task :mciGbenv_monsterEntityDataService do
  assign_roles
  set_vars_from_hiera(%w[  nosql_db_port service_shouldListen  monster_queue_username  monster_queue_virtualhost ])
end

############################## offer DS ############################## #:nodoc:
task :mciGbenv_offerDataService do
  assign_roles
  
  
end

############################## offerIngest ############################## #:nodoc:
task :mciGbenv_offerIngest do
  assign_roles
  
  
end

############################## partnerIngest WS ############################## #:nodoc:
task :mciGbenv_partnerIngestWebService do
  assign_roles
  
 
end

############################## personaIngest WS ############################## #:nodoc:
task :mciGbenv_personaIngestWebService do
  assign_roles
end


############################## playTimeService ############################## #:nodoc:
task :mciGbenv_playTimeService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end


############################## Program Availability 2 ############################## #:nodoc:
task :mciGbenv_programAvailability2 do
  assign_roles
  
  
end

############################## programIndex2 Solr ############################## #:nodoc:
task :mciGbenv_programIndex2 do
  assign_roles
end

############################## Search Updater 2 ############################## #:nodoc:
task :mciGbenv_searchUpdaterWebService2 do
  assign_roles
end

############################## sportsIngestWebService  ############################## #:nodoc:
task :mciGbenv_sportsIngestWebService do
  assign_roles
end

############################## sports DS ############################## #:nodoc:
task :mciGbenv_sportsDataService do
  assign_roles
end

############################## subscriberDataService  ############################## #:nodoc:
task :mciGbenv_subscriberDataService do
  assign_roles
end

############################## udbMockService ############################## #:nodoc:
task :mciGbenv_udbMockService do
  assign_roles
end

############################## haproxy ##############################
task :mciGbenv_haproxy do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################## haproxy ##############################
task :mciGbenv_rabbitMQ do
  assign_roles
end

############################## haproxy ##############################
task :mciGbenv_rabbitMGT do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

############################### mongoDB##################################
task :mciGbenv_mongoDB do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

#################################################################################################### #:nodoc:
