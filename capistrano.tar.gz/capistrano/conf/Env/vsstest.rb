load "./conf/Env/global.rb"


############################## vsstest_crate ############################## #:nodoc:
task :vsstest_crate do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

############################## vsstest_commerceDataService ############################## #:nodoc:
task :vsstest_commerceDataService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

############################## a2gdev_digitalRightsLocker ############################## #:nodoc:
task :vsstest_digitalRightsLocker do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end
