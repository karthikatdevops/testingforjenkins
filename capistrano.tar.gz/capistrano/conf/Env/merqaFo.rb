 

load "./conf/Env/global.rb"



################################
# MERQA Front Office
################################

##########################################################
# DATABASE - check basic.rb ALSO or you will reget it!
##########################################################


set_vars_from_hiera(%w[ splunkHost ])

############################## Entity DS ############################## #:nodoc:
task :merqaFo_entityDataService do
  assign_roles
  
end


############################## monsterEntityDataService ############################## #:nodoc:
task :merqaFo_monsterEntityDataService do
  assign_roles
  set_vars_from_hiera(%w[  nosql_db_port service_shouldListen  monster_queue_username  monster_queue_virtualhost ])
end

############################## gridWebService  ############################## #:nodoc:
task :merqaFo_gridWebService do
  assign_roles
end

############################## id DS ############################## #:nodoc:
task :merqaFo_idDataService do
  assign_roles
end

############################## job DS ############################## #:nodoc:
task :merqaFo_jobDataService do
  assign_roles
  
end

############################## Linear DS ############################## #:nodoc:
task :merqaFo_linearDataService do
  assign_roles
  
end

############################## localListingInfoWebService ############################## #:nodoc:
task :merqaFo_localListingInfoWebService do
  assign_roles
  
end

############################## locationDataService ############################## #:nodoc:
task :merqaFo_locationDataService do
  assign_roles
  
end

############################## menuDataService ############################## #:nodoc:
task :merqaFo_menuDataService do
  assign_roles
  
end


############################## miceGWTService ############################## #:nodoc:
task :merqaFo_miceGWTService do
  assign_roles
end

############################## Program Availability2 ############################## #:nodoc:
task :merqaFo_programAvailability2 do
  assign_roles
end

############################## offerDataService ############################## #:nodoc:
task :merqaFo_offerDataService do
  assign_roles
  
end

####################### #:nodoc:
# END MERLIN SERVICES   #:noDoc:
####################### #:nodoc:

############################# haproxy ##############################
task :merqaFo_haproxy do
  assign_roles
  set_vars_from_hiera(%w[ noBom ])
end

### END END END
