load "./conf/Env/global.rb"

set_vars_from_hiera(%w[ hazelcast ])

################################ **** A2G ***** #################################

############################## tqmTb3_castl ############################## #:nodoc:
task :tqmTb3_castl do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_crate ############################## #:nodoc:
task :tqmTb3_crate do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_crateFeeder ############################## #:nodoc:
task :tqmTb3_crateFeeder do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_crateLoader ############################## #:nodoc:
task :tqmTb3_crateLoader do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

task :tqmTb3_axon do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

task :tqmTb3_alfred do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome hazelcast ])
end

############################## tqmTb3_exileBootstrap ############################## #:nodoc:
task :tqmTb3_exileBootstrap do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_exileWebServer ############################## #:nodoc:
task :tqmTb3_exileWebServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end


################################ **** MAPS ***** #######################################

############################## tqmTb3_menuWebService ############################## #:nodoc:
task :tqmTb3_menuWebService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




################################ **** UNU ***** ############################################

############################## tqmTb2_digitalRightsLocker ############################## #:nodoc:
task :tqmTb3_digitalRightsLocker do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_remoteDigitalRightsLocker ############################## #:nodoc:
task :tqmTb3_remoteDigitalRightsLocker do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_tRex ############################## #:nodoc:
task :tqmTb3_tRex do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_unuHazelcastServer ############################## #:nodoc:
task :tqmTb3_unuHazelcastServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_luna ############################## #:nodoc:
task :tqmTb3_luna do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_unuServer ############################## #:nodoc:
task :tqmTb3_unuServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_cuUnuServer ############################## #:nodoc:
task :tqmTb3_cuUnuServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome installdir])
end

############################## tqmTb3_menuItemServer ############################## #:nodoc:
task :tqmTb3_menuItemServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_titleServer ############################## #:nodoc:
task :tqmTb3_titleServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_unuRolo ############################## #:nodoc:
task :tqmTb3_unuRolo do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_mms ############################## #:nodoc:
task :tqmTb3_mms do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_tim ############################## #:nodoc:
task :tqmTb3_tim do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




############################## tqmTb3_availabilityResolutionService ############################## #:nodoc:
task :tqmTb3_availabilityResolutionService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_arsHazelcast ############################## #:nodoc:
task :tqmTb3_arsHazelcast do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_arsLoader ############################## #:nodoc:
task :tqmTb3_arsLoader do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_commerceDataService ############################## #:nodoc:
task :tqmTb3_commerceDataService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




################################ **** MAPS ***** #######################################

############################## tqmTb2_browseSessionService ############################## #:nodoc:
task :tqmTb3_browseSessionDataService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end




################################ **** UES ***** ############################################

############################## tqmTb3_uesWebApp ############################## #:nodoc:
task :tqmTb3_uesWebApp do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_uesProducer ############################## #:nodoc:
task :tqmTb3_uesProducer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_uesServer ############################## #:nodoc:
task :tqmTb3_uesServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_uesB1NotificationIngestConsumer ############################## #:nodoc:
task :tqmTb3_uesB1NotificationIngestConsumer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_uesNotificationIngestConsumer ############################## #:nodoc:
task :tqmTb3_uesNotificationIngestConsumer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_e2gWebService ############################## #:nodoc:
task :tqmTb3_e2gWebService do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_maestroServer ############################## #:nodoc:
task :tqmTb3_maestroServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end

############################## tqmTb3_ngpServer ############################## #:nodoc:
task :tqmTb3_ngpServer do
  assign_roles
  set_vars_from_hiera(%w[ depends propertyFile svcHome ])
end



#########################################################################################
# END UDB DEPLOYMENT TASKS
#########################################################################################
