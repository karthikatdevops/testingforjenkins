 
  
###############
# FILE LOADING
###############
load "./conf/Env/global.rb"

################
# Environment specifics
################

############################### entityIndex Solr ############################## #:nodoc:
task :solrTest_merlinSolr do
  assign_roles
end

############################### entityIndex Solr ############################## #:nodoc:
task :solrTest_imageIndex do
  assign_roles
end

############################## tqmTb1_castl ############################## #:nodoc:
task :solrTest_playTimeService do
  assign_roles
end

