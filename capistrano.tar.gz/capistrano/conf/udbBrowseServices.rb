=begin
UDBBrowsebootstrap = {
"menuWebService" => "com.theplatform.web.tv.menu.bootstrap.Bootstrap"
"menuVisibilityCountService" => "com.comcast.compass.browse.mas.bootstrap.Bootstrap"
"browseSessionService" => "browseSessionService com.comcast.browse.session.server.Bootstrap"
"contextDataService" => "contextDataService com.comcast.browse.context.bootstrap.Bootstrap"
"titleServerPrime" => "com.comcast.compass.browse.titleServerPrime.bootstrap.Bootstrap"
"videoDataService" => "com.comcast.compass.browse.vds.server.Bootstrap"
}
=end


[svc].each do |name|

     desc "called by #{env}_#{name} in #{env}.rb"
     task "#{name}_main_#{env}".to_sym do
       logger.level = Capistrano::Logger::INFO
       logger.info "DEBUG: TASK: #{name}_main_#{env}"

       

       #### check_versions will check for and install the items in the depends variable ####
       #### check_curl makes sure curl is installed ####
       check_versions
       check_curl

       set :app, "#{name}"

       set :install_path, "/opt/ds/#{name}"
       puts "....Set install_path=#{install_path} app=#{app}"
       #set :appstagingdir, "/opt/ds/staging/#{name}"

       logger.info "START: this is #{app}"
       logger.info "DEBUG: about to read_bom"

       if exists?(:noBom) or exists?(:nobom)
         #set :skipWriteServiceVersion, "true"
         logger.info "skipping read bom"
       else
         check_service_version
         read_bom
       end

       if exists?(:cleanServer) && cleanServer.to_s == "true"
        logger.info "NOT IMPLEMENTED clean installing #{name}"
       end
       find_and_execute_task("copy_#{name}_#{env}")
       if "#{startService}" == "false"
          logger.info "Not starting #{name} due to startService=#{startService}"
       else
         find_and_execute_task("start_#{name}")
       end
     end # task "#{name}_main_#{env}".to_sym do


     desc "called by #{name}_main_#{env}"
     task "start_#{name}".to_sym do
 	    run "sudo /etc/init.d/#{app} start ; sleep 2"
     end # task "start_#{name}".to_sym do


    desc "called by install_jetty"
    task "install_jetty_#{name}".to_sym do
        logger.info "TASK: Entered install_jetty_#{name} in udbBrowseService_compass.rb"

        jetty_install("#{name}", "#{jetty_version}")
        restore_dir("#{name}", hiera("persistent_directory"))
    end

    desc "used to deploy #{name}_#{env}"
    task "deploy_#{name}_#{env}".to_sym do
      set :app, name
      logger.level = Capistrano::Logger::INFO
      logger.info "M1 TASK: deploy_#{name}_#{env}.to_sym do"
      logger.info "DEBUG: env-->#{env}<  name/app-->#{name}< "
      
      find_and_execute_task("#{env}_#{name}")
      run_serially_in_batches(:find_server_opts => {:roles => "#{name}".to_sym}) do |server_options|
        set :startService, server_options[:startService]
        set :startServiceAtBoot, server_options[:startServiceAtBoot]
        find_and_execute_task ("#{name}_main_#{env}")
      end
    end # task "deploy_#{name}_#{env}".to_sym do

    desc "updateConfigAndRestart"
    task "updateConfigAndRestart_#{name}_#{env}".to_sym do
      set :app, name
      set :install_path, "/opt/ds/#{name}"
      logger.level = Capistrano::Logger::INFO
      find_and_execute_task("#{env}_#{name}")
      run_serially_in_batches(:find_server_opts => {:roles => "#{name}".to_sym}) do |server_options|
        set :startService, server_options[:startService]
        set :startServiceAtBoot, server_options[:startServiceAtBoot]
        
        run "[ -f /etc/init.d/#{app} ] && sudo /etc/init.d/#{app} stop ; exit 0"
        find_and_execute_task("updateConfig_#{name}_#{env}")
        find_and_execute_task("start_#{name}")
      end
    end

    desc "called by #{name}_main_#{env}"
    task "copy_#{name}_#{env}".to_sym do
      logger.info "M2 TASK: copy_#{name}_#{env}.to_sym do"
      set(:url) do
        Capistrano::CLI.ui.ask "Enter URL to tar.gz file:"
      end unless variables[:url]

      run "[ -f /etc/init.d/#{app} ] && sudo /etc/init.d/#{app} stop ; exit 0"
      run "rm -rf #{install_path}"
      run "[ ! -d /opt/ds ] && sudo mkdir /opt/ds ; sudo chown #{user}:#{user} /opt/ds"
      run "mkdir -p #{install_path}/version"
      if exists?(:noBom) or exists?(:nobom)

        # remove contents of tmpdir
        run "rm -rf #{tmpdir}/#{name}"
        run "mkdir -p #{tmpdir}/#{name}"
        logger.info " attempting to wget #{url}"
        logger.info " using cmd: wget #{wget_params} --no-proxy #{url} -O- working/#{name}.tar.gz"
        #grab the zip file, unzip it, and mv it to a meaningful name
        logger.info "using a local wget and scp up to the server, this will take a bit of time..."
        `wget #{wget_params} --no-proxy #{url} -O working/#{projectArtifactId}.tgz`
        upload("working/#{projectArtifactId}.tgz","#{install_path}/#{projectArtifactId}.tgz", :via => :scp)
        run "cd #{install_path} && tar xzf #{projectArtifactId}.tgz && rm #{projectArtifactId}.tgz"
        # WRITE SERVICE VERSION
        puts "I have no BOM-- guessing what version of service I have using regex"
        puts "My package is: #{url}"
        myNoBomVersion = url.gsub(/-indexer.tar.gz.*/, "")
        myNoBomVersion = myNoBomVersion.gsub(/.*\/pl-data-tv-entity-indexer-/, "")
        puts "My guessed version is: #{myNoBomVersion}"
        run "echo \"#{myNoBomVersion} (noBom)\" > #{install_path}/version/version.txt"
        # POST HISTORY
        run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
        logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
        run "touch #{basedir}/history/#{app}/deploy_history.txt"
        run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
        run "echo \"Version: #{myNoBomVersion} (noBom)\" >> #{basedir}/history/#{app}/deploy_history.txt"

      else

        get_remote_file("#{url}","#{install_path}","#{app}.tgz")
        logger.info "unpacking tarball into #{install_path}"
        run "cd #{install_path} && tar xzf #{app}.tgz"
        run "echo #{service_version} #{bom} > #{install_path}/version/version.txt"
        # POST HISTORY
        run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
        logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
        run "touch #{basedir}/history/#{app}/deploy_history.txt"
        run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
        run "echo \"Version: #{service_version} #{bom}\" >> #{basedir}/history/#{app}/deploy_history.txt"

      end
      if splunkLogging && ['fedRex'].include?(app)
        # make logback.xml

          load "./common/splunkJavaLogging.rb"

          if app == "playTimeService"

            # inject is the new logback + localfiles with env injection in the files
            # true is to use the TCP Splunk logging (no local files)
            if splunkLogging == "inject"
              find_and_execute_task("createLogback_for_netty")
              logger.info ">>>>> Using UDB local log file with env injection... BITT-8851 "
            else
              find_and_execute_task("create_splunk_logback")
              logger.info ">>>>> Using splunk TCP Logging... "
            end

          end
          
        load "./common/splunkJavaLogging.rb"
        
        # make logback.xml
        find_and_execute_task("create_splunk_logback")

        # fetch jars
        find_and_execute_task("fetch_splunk_logging_jars")
      else
        run "cp #{install_path}/conf/logback.xml.sample #{install_path}/conf/logback.xml"
      end
      logger.info "copied over logback.sample to logback"

      find_and_execute_task("updateConfig_#{name}_#{env}")
      find_and_execute_task("initd#{name}")
      logger.info "TASK: END"

    end # task "copy_#{name}_#{env}".to_sym d


#################################
#
# UPDATE CONFIG
#
#


    desc "called by copy_#{name}_#{env} to search and replace the sample"
    task "updateConfig_#{name}_#{env}".to_sym do

      if exists?(:useLocalWorking) && useLocalWorking == true
      else
      # Copy the test.properties file over to the used config file
      run "if [ -e #{install_path}/conf/#{propertyFile}.sample ]; then cp #{install_path}/conf/#{propertyFile}.sample #{install_path}/conf/#{propertyFile} ; fi"
      logger.info "Just copied over the sample props file to the real one"
      logger.info "if [ -e #{install_path}/conf/#{propertyFile}.sample ]; then cp #{install_path}/conf/#{propertyFile}.sample #{install_path}/conf/#{propertyFile} ; fi"
      end #if exists?(:useLocalWorking) && useLocalWorking == true

      if name == "browseSessionService"
        ########################################
        # browseSessionService SUBSTITUTIONS
        ########################################
        logger.info "DEBUG----> MATCHED on #{name}"
        config_overrides = {
          "server.port"                         => "#{hiera('browseSessionService_web_port')}",
          "vds.baseUrl"                         => "#{availabilityTagBaseUrl}",
          "ues.baseUrl"                         => "#{uesEntitlementsServiceBaseUrl}",
          "offer.baseUrl"                       => "#{offerServiceBaseUrl}",
          "rex.baseUrl"                         => "#{rexBaseUrl}",
          "session.riak.host"                   => "#{sessionRiakHost}",
          "session.riak.port"                   => "#{sessionRiakPort}",
          "session.riak.max.connection.pool.size"   => "#{sessionRiakMaxPoolSize}",
          "session.riak.init.connection.pool.size"  => "#{sessionRiakInitialPoolSize}",
          "cache.active"                        => "#{sessionRiakActive}",
          "udb.demo.mode"                        => "#{udbDemoMode}",
          "userpreferences.baseUrl"             => "#{userPreferenceDataServiceBaseUrl}",
          "ars.baseUrl"                         => "#{arsBaseUrl}",
        }
      end # name == "browseSessionService"

##########################################################################################
     # look in data/env/fedrex.yaml to set these ports via hiera
     # 
     if name == "fedRex"
      logger.info "DEBUG----> MATCHED on #{name}"
      config_overrides = {
          "server.port"                      => "#{fedRex_server_port}",
          "grid.web.service.trending.url"    => "#{hiera('grid_web_service_trending_url')}",
          "linear.ds.url"                    => "#{hiera('linear_ds_url')}",
          "entity.ds.url"                    => "#{hiera('entity_ds_url')}",
          "id.ds.url"                        => "#{hiera('id_ds_url')}",
          "menu.web.service.base.url"        => "#{menu_web_service_base_url}",
          "fedrex.menu.ds.url"               => "#{fedRex_menu_ds_url}",
          "browse.service.base.url"          => "#{rexBaseUrl}",
          "fedrex.browse.url"                => "#{fedrex_browse_url}",
          "fedrex.proxy.server.host"         => "proxy",
          "fedrex.proxy.server.port"         => "3128",
          "proxy.url"                        => "#{hiera('proxy_url')}",
          "application.url"                  => "#{hiera('application_url')}",
          "default.max.age"        	   => "0",
          "accept.personalization.ds.url.xre"       => "false",
          "personalization.ds.max.results.recent.programs" => "250",
          "personalization.ds.max.results.recent.networks" => "20",
          "personalization.ds.max.time.frame"              => "30",
          "use.proxy.enhanced.entity"	   => "true",
          "enhanced.entity.service.url"      => "#{hiera('enhanced_entity_service_url')}",
          "enhanced.entity.cache.refresh.interval"  => "#{hiera('enhanced_entity_cache_refresh_interval')}",
          "eep.http.client.timeout"       => "#{hiera('eep_http_client_timeout')}",
          "kafka.topic"       => "#{hiera('kafka_topic')}",
          "kafka.zookeeper.hosts" => "#{hiera('kafka_zookeeper_hosts')}",
          "trending.topics.rex.request" => "#{hiera('trending_topics_rex_request')}",
		  "xbi.trending.cache.refresh.interval"  => "#{hiera('xbi_trending_cache_refresh_interval')}"
        }
        config_injections = {
          "service.name"                => "fedRex",
          "service.environment"         => env,
        }
      end # name == "fedRex"


      if name == "menuVisibilityCountService"
        ########################################
        # menuVisibilityCountService SUBSTITUTIONS
        ########################################
        logger.info "DEBUG----> MATCHED on #{name}"
        config_overrides = {
          "mas.port"                            => "#{hiera('menuVisibilityCountService_web_port')}",
          "queue.host"                          => "#{rabbitMQHost}",
          "queue.port"                          => "#{rabbitMQPort}",
          "queue.exchange.name"                 => "#{rabbitMQExchangeName}",
          "queue.exchange.vhost"                => "#{rabbitMQExchangeVhost}",
          "rex.url"                             => "#{rexBaseHost}",
          "rex.port"                            => "#{rexBasePort}",
          "rex.path"                            => "#{rexBasePath}",
          "menu.ds.base.url"                    => "#{menuDataServiceBaseUrl}",
          "offer.ds.base.url"                   => "#{offerServiceBaseUrl}",
          "linear.ds.base.url"                  => "#{linearServiceBaseUrl}",
          "menu_ds.ownerid"                     => "#{menuDataServiceOwnerid}",
          "menu_ds.admin.identity.url"          => "#{mpx_identity_url}",
          "menu_ds.username"                    => "#{menuDataServiceUser}",
          "menu_ds.password"                    => "#{menuDataServicePassword}",
          "offer_ds.ownerid"                    => "#{combine_commons_default_ownerid}",
          "offer_ds.admin.identity.url"         => "#{mpx_identity_url}",
          "offer_ds.username"                   => "#{offerServiceUser}",
          "offer_ds.password"                   => "#{offerServicePassword}"
        }
      end # name == "menuVisibilityCountService"

      if name == "menuWebService"
        ########################################
        # menuWebService SUBSTITUTIONS
        ########################################
        logger.info "DEBUG----> MATCHED on #{name}"
        config_overrides = {
          "server.port"                         => "#{menuWebServicePort}",
          "menu.ds.base.url"                    => "#{menuDataServiceBaseUrl}",
          "offer.ds.base.url"                   => "#{offerServiceBaseUrl}",
          "session.service.host"                => "#{browseSessionServiceHost}",
          "session.service.port"                => "#{browseSessionServicePort}",
          "menu.vs.url"                         => "#{menuVisibilityCountServiceBaseUrl}",
          "menu.vs.url.titles"                  => "#{menuVisibilityCountServiceTitlesEndpoint}",
          "menu.vs.amqp.host"                   => "#{rabbitMQHost}",
          "menu.vs.amqp.port"                   => "#{rabbitMQPort}",
          "menu.vs.amqp.exchange.name"          => "#{rabbitMQExchangeName}",
          "menu.vs.amqp.virtual.host"           => "#{rabbitMQExchangeVhost}",
          "mws.base.url"                        => "#{menuWebServiceBaseUrl}",
          "rex.base.url"                        => "#{rexBaseUrl}",
          "linear.ds.base.url"                  => "#{linearServiceBaseUrl}",
          "pmws.base.url"                       => "#{personalizedMenuWebServiceBaseUrl}",

        }
      end # name == "menuWebService"

      if name == "titleServerPrime"
        ########################################
        # titleServerPrime SUBSTITUTIONS
        ########################################
        logger.info "DEBUG----> MATCHED on #{name}"
        config_overrides = {
          "titleServerPrimePort"        => "#{titleServerPrimePort}",
        }
      end # name == "titleServerPrime"

      if name == "videoDataService"
        ########################################
        # videoDataService SUBSTITUTIONS
        ########################################
        logger.info "DEBUG----> MATCHED on #{name}"
        config_overrides = {
          "server.port"                         => "#{videoDataServicePort}",
          "data.service.user"                   => "#{menuDataServiceUser}",
          "data.service.password"               => "#{menuDataServicePassword}",
          "auth.url"                            => "#{mpxIdentityURL}",
          "account.url"                         => "#{combineMpxOwnerid}",
          "combine.service.base.url"            => "#{combineServiceBaseUrl}",
          "linear.data.base.url"                => "#{linearServiceBaseUrl}",
          "location.data.base.url"              => "#{locationDataServiceBaseUrl}",
          "menu.data.base.url"                  => "#{menuDataServiceBaseUrl}",
          "offer.ingest.base.url"               => "#{offerIngestBaseUrl}",
          "video.data.base.url"                 => "#{videoDataServiceBaseUrl}",
        }
      end # name == "videoDataService"

      if name == "editorial-collection-portlet"
        ########################################
        # editorial-collection-portlet SUBSTITUTIONS
        ########################################
        logger.info "DEBUG----> MATCHED on #{name}"
        config_overrides = {
          "menuDataService.endpoint"            => "#{menuDataServiceBaseUrl}",
          "entityDataService.endpoint"          => "#{entityDataServiceBaseUrl}",
          "authenticationClient.user"           => "#{eddieUser}",
          "authenticationClient.password"       => "#{eddiePassword}",
          "auth.url"                            => "#{mpxIdentityURL}",
          "account.url"                         => "#{combineMpxOwnerid}",
          "rexSearchUrl"                        => "#{rexSearchUrl}",
          "roloUrl"                             => "#{offerIngestBaseUrl}",

        }
      end # name == "editorial-collection-portlet"

      if name == "max-portlet"
        ########################################
        # max-portlet SUBSTITUTIONS
        ########################################
        logger.info "DEBUG----> MATCHED on #{name}"
        config_overrides = {
          "authenticationClient.user"           => "#{eddieUser}",
          "authenticationClient.password"       => "#{eddiePassword}",
          "authenticationClient.baseUrl"        => "#{mpxIdentityURL}",
          "authenticationClient.accountId"      => "#{combineMpxOwnerid}",
          "menuDataService.endpoint"            => "#{menuDataServiceBaseUrl}",
          "combineService.endpoint"             => "#{entityDataServiceBaseUrl}",
          "offerIngestService.endpoint"         => "#{offerServiceBaseUrl}",
          "entityDataService.endpoint"          => "#{entityDataServiceBaseUrl}",
          "locationDataService.endpoint"        => "#{entityDataServiceBaseUrl}",
          "browseService.endpoint"              => "#{rexBaseUrl}",
          "builder.endpoint"                    => "#{rexBuilderUrl}",
          "linearDataService.endpoint"          => "#{linearServiceBaseUrl}",
          "roloUrl"                             => "#{offerIngestBaseUrl}",
        }
      end # name == "max-portlet"
      
      if name == "tRex"
        ########################################
        # tRex SUBSTITUTIONS
        ########################################
        logger.info "DEBUG----> MATCHED on #{name}"
        config_overrides = {
          "app.port"                            => "#{hiera('tRex_web_port')}",
          "mds.base.url"                        => "#{menuDataServiceBaseUrl}",
          "mds.identity.url"                    => "#{mpx_identity_url}",
          "mds.username"                        => "#{menuDataServiceUser}",
          "mds.password"                        => "#{menuDataServicePassword}",
          "mds.account"                         => "#{combine_commons_default_ownerid}",
          "rex.base.url"                        => "#{rexBaseUrl}",
          "entity.base.url"                     => "#{entityServiceBaseUrl}",
          "id.base.url"                         => "#{idServiceBaseUrl}",
          "linear.base.url"                     => "#{linearServiceBaseUrl}",   

        }
      end # name == "tRex"

      #####################
      # SUBSTITUTION MAGIC
      #####################
      # Start with a blank regex string
      logger.info "DEBUG: starting substitution config_overrides for #{name}"
      regex=""
      regex_commented=""

      config_overrides.each do |key, value|
        key = key.gsub(/\./, "\\.")
        key = key.gsub(/\-/, "\\-")
        key = key.gsub(/\,/, "\\,")
        key = key.gsub(/\//, "\\/")
        key = key.gsub(/\@/, "\\@")
        value = value.gsub(/\./, "\\.")
        value = value.gsub(/\-/, "\\-")
        value = value.gsub(/\,/, "\\,")
        value = value.gsub(/\//, "\\/")
        value = value.gsub(/\@/, "\\@")
        value = value.gsub(/\$/, "\\$")
        regex = regex + "s/^\s*#{key}=.*/#{key}=#{value}/g ; "
        regex_commented = regex_commented + "s/^\s*#\s*#{key}=.*/##{key}=#{value}/g ; "
        logger.info "DEBUG: completed substitution config_overrides for #{name}"
        logger.info "DEBUG--> REGEX-> #{regex}"
      end # config_overrides.each do |key, value|

      config_injections ||= {}

      if exists?(:useLocalWorking) && useLocalWorking == true
        # Perform the substitution locally
        `perl -pi -e '#{regex}' working/#{app}-#{service_version}/conf/#{propertyFile}.sample`
        `perl -pi -e '#{regex_commented}' working/#{app}-#{service_version}/conf/#{propertyFile}.sample`

        # Perform injections locally
        config_injections.each do |key, value|
          `if grep -q #{key}= working/#{app}-#{service_version}/conf/#{propertyFile}.sample ; then echo \"#{key}= is already present\" ; else echo -e \"\\n#{key}=#{value}\" >> working/#{app}-#{service_version}/conf/#{propertyFile}.sample ; fi ;`
        end
      else
        # Perform the substitution remotely
        run "perl -pi -e '#{regex}' #{install_path}/conf/#{propertyFile}"
        run "perl -pi -e '#{regex_commented}' #{install_path}/conf/#{propertyFile}"

        # Perform injections remotely
        config_injections.each do |key, value|
          run "if grep -q #{key}= #{install_path}/conf/#{propertyFile} ; then echo \"#{key}= is already present\" ; else echo -e \"\\n#{key}=#{value}\" >> #{install_path}/conf/#{propertyFile} ; fi ;"
        end
      end # if exists?(:useLocalWorking) && useLocalWorking == true
    end # task "updateConfig_#{name}_#{env}".to_sym do


#################################
#
#  init.d and start.sh scripts for this service
#
#

    desc "called by updateConfig_#{name}_#{env} or updateConfig_local_#{name}_#{env} to set variables"
    task "setConfigVariables_#{name}_#{env}".to_sym do
    end # task setConfigVariables


#################################
#
# setup init.d and start.sh scripts for this service
#
#


    desc  "called by copy_#{name}_#{env} to write init and wrapper"
    task "initd#{name}".to_sym do
    logger.info "M3 TASK: initd#{name}"

    #find_and_execute_task("setup_initd#{name}")

    find_and_execute_task("setup_udb_initd_and_wrapper_#{name}")


    logger.info "============================================================================="
    logger.info "DEBUG: completed initd and start.sh setup task"
    logger.info "============================================================================="
    end #end task "initd#{name}"




#################################
#
# setup RPMs for this service
#
#

    desc  "called by createRPM_#{name}_#{env} to create rpm source file in working directory"
    task "createRPMSource_#{name}_#{env}".to_sym do
    logger.info "M3 TASK: createRPMSource#{name}_#{env}"


      if exists?(:noBom) or exists?(:nobom)
       logger.info ">>>>>>>>> You set nobom for some reason....."

      else

        
        send("setProperties_#{env}_#{name}")
        set :app, "#{name}"
        logger.info " setting up local directory in working"
        write_local_service_version
        set :rpmBuild, true
        read_bom

        logger.info " attempting to wget #{url}"
        logger.info " using cmd: wget #{wget_params} --no-proxy #{url} -O- working/#{app}-#{service_version}/#{app}.tgz"
        #grab the zip file, unzip it, and mv it to a meaningful name
        logger.info "using a local wget and scp up to the server, this will take a bit of time..."
        `wget #{wget_params} --no-proxy #{url} -O working/#{app}-#{service_version}/#{app}.tgz`

        logger.info "unpacking tarball"
        `cd working/#{app}-#{service_version} && tar xzf #{app}.tgz`

        logger.info "removing tarball"
        `rm working/#{app}-#{service_version}/#{app}.tgz`


#####REMOVE THIS WHEN SPECS ADDED TO TARBALLS
#        logger.info "DEBUG moving spec file into working/#{app}-#{service_version} directory"
#        `cp working/comcast-RPM-CAPISTRANO.spec working/#{app}-#{service_version}/`
#############################################



        set :useLocalWorking, true
        find_and_execute_task("updateConfig_#{name}_#{env}")

        set :install_path, "/opt/ds/#{name}"
        find_and_execute_task("setup_initd#{name}")
        logger.info "DEBUG moving init.d into working/#{app}-#{service_version} directory"
        `cp working/#{app}initd working/#{app}-#{service_version}/#{app}`
#        find_and_execute_task("updateLogback_local_#{name}_#{env}")



        logger.info "Setting up Spec File Substitution"
        config_overrides = {
          "APPNAME"        => "#{app}",
          "VERSION"        => "#{service_version.split("-").first}",
          "RELEASE"        => "#{service_version.split("-").second}",
          "INSTALLPATH"    => "#{install_path}",
          "PROPERTYFILE"   => "#{propertyFile}",
          "env"        => "#{env}",
        }

        #####################
        # SUBSTITUTION MAGIC
        #####################
        # Start with a blank regex string
        logger.info "DEBUG: starting substitution config_overrides for #{name}"
        regex=""

        config_overrides.each do |key, value|
          key = key.gsub(/\./, "\\.")
          key = key.gsub(/\-/, "\\-")
          key = key.gsub(/\,/, "\\,")
          key = key.gsub(/\//, "\\/")
          key = key.gsub(/\@/, "\\@")
          value = value.gsub(/\./, "\\.")
          value = value.gsub(/\-/, "\\-")
          value = value.gsub(/\,/, "\\,")
          value = value.gsub(/\//, "\\/")
          value = value.gsub(/\@/, "\\@")
          value = value.gsub(/\$/, "\\$")
          regex = regex + "s/#{key}/#{value}/g ; "
          logger.info "DEBUG: completed substitution config_overrides for specfile"
          logger.info "DEBUG--> REGEX-> #{regex}"
        end # config_overrides.each do |key, value|

        # Perform the substitution
        `perl -pi -e '#{regex}' working/#{app}-#{service_version}/comcast-RPM-CAPISTRANO.spec`

        logger.info "DEBUG moving spec file into working directory"
        `mv working/#{app}-#{service_version}/comcast-RPM-CAPISTRANO.spec working/comcast-#{app}-#{env}-#{service_version}.spec`

      end
    end #end task "createRPMSource_#{name}_#{env}"

    desc  "called by copy_#{name}_#{env} to create rpm source file in working directory"
    task "createRPM_#{name}_#{env}".to_sym do
    logger.info "M3 TASK: createRPM_#{name}_#{env}"

      find_and_execute_task("createRPMSource_#{name}_#{env}")

      logger.info "DEBUG tar up directory to be used as source"
      `cd working; tar czf #{app}-#{env}-#{service_version}.tgz #{app}-#{service_version}/`

      set :rpm_host,"rollingthunder"
      set :user, "rpm"
      logger.info "Pushing spec file and source tar to #{rpm_host} rpm build box"
      upload("working/comcast-#{app}-#{env}-#{service_version}.spec","/opt/app/rpm/SPECS/", :via => :scp,:hosts => rpm_host)
      upload("working/#{app}-#{env}-#{service_version}.tgz","/opt/app/rpm/SOURCES/", :via => :scp,:hosts => rpm_host)
      run "cd /opt/app/rpm/SPECS/; rpmbuild -ba comcast-#{app}-#{env}-#{service_version}.spec",{:hosts => "#{rpm_host}"}

    end #end task "createRPM_#{name}_#{env}"

    desc  "called by copy_#{name}_#{env} to create rpm source file in working directory"
    task "showConfig_#{name}_#{env}".to_sym do
    logger.info "M3 TASK: showConfig_#{name}_#{env}"

      find_and_execute_task("createRPMSource_#{name}_#{env}")
      contents = File.open("working/#{app}-#{service_version}/conf/#{propertyFile}.sample", "rb").read
      logger.info "\nworking/#{app}-#{service_version}/conf/#{propertyFile}.sample\n\n#{contents}\n\n\n"

    end #end task "showConfig_#{name}_#{env}"
end #end Services iteration block

logger.info ">>>>> loaded udbBrowseServices"
