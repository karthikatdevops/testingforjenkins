  desc "called by #{env}_#{svc} in #{env}.rb"
  task "deployCloverWar_#{svc}_#{env}".to_sym do
    logger.level = Capistrano::Logger::INFO
    logger.info "M1 TASK: deployCloverWar_#{svc}_#{env}.to_sym do"
    find_and_execute_task("#{env}_#{svc}")
    servers=find_servers(:roles => "#{svc}".to_sym)
    logger.info "servers: #{servers}"
	  set :app, "#{svc}"
	  set :cloverwar_webapps, "webapps"
	  stop_jetty
    set :install_path, "/opt/ds/jetty-#{svc}"

    begin
      logger.info "BEGIN: install #{svc} (inside file: cloverServer.rb)"
      logger.info "CLOVER TAR GZ: wget #{wget_params} \"#{url}\" -O #{svc}.tar.gz"
      run "cd #{tmpdir} && wget #{wget_params} \"#{url}\" -O #{svc}.tar.gz"
    rescue
      logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
      `wget #{wget_params} \"#{url}\" -O working/#{svc}.tar.gz`
      upload("working/#{svc}.tar.gz","#{tmpdir}/#{svc}.tar.gz", :via => :scp)
    end

    logger.info "Reconfiguring log4j.xml inside the WAR"
    run "cd #{tmpdir}; rm -fr #{svc};mkdir #{svc};cd #{svc}; mv ../#{svc}.tar.gz .; tar xzf #{svc}.tar.gz; mv #{svc}.tar.gz ../#{svc}.tar.gz.bk;jar -xf #{cloverwar_webapps}/#{svc}.war WEB-INF/classes/log4j.xml; sed -ie 's/{java.io.tmpdir}/{theplatform.log.dir}/g' WEB-INF/classes/log4j.xml; jar -uf #{cloverwar_webapps}/#{svc}.war WEB-INF/classes/log4j.xml;rm -fr WEB-INF;tar czf ../#{svc}.tar.gz ."

    logger.info "Moving package #{tmpdir}/#{svc}.tar.gz to #{basedir}/jetty-#{app} to be unpacked"
    run "cp #{tmpdir}/#{svc}.tar.gz #{basedir}/jetty-#{app}"

    logger.info "Unpacking #{svc}.tar.gz in #{install_path}"
    run "cd #{install_path} && tar xzvf #{svc}.tar.gz"

    # clean out the working directory
    run "rm -rf #{install_path}/work/*"
    start_jetty
  end

  task "#{svc}_main_#{env}".to_sym do
    set :app, "#{svc}"
    logger.level = Capistrano::Logger::INFO
  
    set :web_port, hiera("#{svc}_web_port")
    set :jmx_port, hiera("#{svc}_jmx_port")
    set :stop_port, hiera("#{svc}_stop_port")
    set :alive_path, "cloverServer/gui/login.jsf"

    if exists?(:noBom) or exists?(:nobom)
      puts "skipping read bom"
    else
      check_service_version
      read_bom_cloverServer
    end

    if exists?(:cleanServer) && cleanServer.to_s == "true"
      logger.info "clean installing #{app}"
      stop_jetty
      removeClover
      check
    else
      check
      stop_jetty
    end

    find_and_execute_task("jettywrapper#{svc}")
    find_and_execute_task("initd#{svc}")
    find_and_execute_task("copy_#{svc}_#{env}")
    find_and_execute_task("prepare_#{svc}_#{env}")
    find_and_execute_task("sandbox_deploy")

    if exists?(:updateCloverman) && updateCloverman.to_s == "true"
      logger.info ">> Updating CloverMan files for this deployment of  #{app}"
      find_and_execute_task("update_cloverman")
    end

    if exists?(:do_not_start) && do_not_start == true
      logger.info "not starting b/c :do_not_start == true"
    else
      start_jetty
      alive
      get_ver
    end
  end

  task "updateConfigAndRestart_#{svc}".to_sym do
    if exists?(:noBom) or exists?(:nobom)
      puts "skipping read bom"
    else
      read_bom_cloverServer
    end
    find_and_execute_task("#{env}_#{svc}")
    logger.level = Capistrano::Logger::INFO
    run_serially_in_batches(:find_server_opts => {:roles => "#{svc}".to_sym}) do |server_options|
      set :app, "#{svc}"
      set :jetty_wrapper_path, "#{basedir}/jetty-#{app}/jetty-wrapper.sh"
      set :web_port, hiera("#{svc}_web_port")
      set :jmx_port, hiera("#{svc}_jmx_port")
      set :stop_port, hiera("#{svc}_stop_port")
      set :alive_path, hiera("#{svc}_alive")
      stop_jetty
      find_and_execute_task("jettywrapper#{svc}")
      find_and_execute_task("initd#{svc}")
      find_and_execute_task("prepare_#{svc}_#{env}")
      find_and_execute_task("sandbox_deploy")

      if exists?(:updateCloverman) && updateCloverman.to_s == "true"
        logger.info ">> Updating CloverMan files for this deployment of  #{app}"
        update_cloverman
      end

      if exists?(:do_not_start) && do_not_start == true
        logger.info "not starting b/c :do_not_start == true"
      else
        start_jetty
        alive
        get_ver
      end
    end
  end

  task "sandbox_deploy_#{svc}_#{env}".to_sym do
    set :app, "#{svc}"

    if exists?(:noBom) or exists?(:nobom)
      puts "skipping read bom"
    else
      read_bom_cloverServer
    end

    find_and_execute_task("#{env}_#{svc}")
    logger.level = Capistrano::Logger::INFO
    run_serially_in_batches(:find_server_opts => {:roles => "#{svc}".to_sym}) do |server_options|
      set :jetty_wrapper_path, "#{basedir}/jetty-#{app}/jetty-wrapper.sh"
      set :web_port, hiera("#{svc}_web_port")
      set :jmx_port, hiera("#{svc}_jmx_port")
      set :stop_port, hiera("#{svc}_stop_port")
      set :alive_path, hiera("#{svc}_alive")
    
      find_and_execute_task("sandbox_deploy")

      if exists?(:updateCloverman) && updateCloverman.to_s == "true"
        logger.info ">> Updating CloverMan files for this deployment of  #{app}"
        find_and_execute_task("update_cloverman")
      end

    end
  end

  desc "Update #{svc} cloverman for #{env}..."
  task "update_#{svc}_cloverman_#{env}".to_sym do
    logger.info ">>>>>>>>>>>>>>>>> In Update cloverman Phase1, task: update_X_cloverman_X "
    set :app, "#{svc}"

    if exists?(:noBom) or exists?(:nobom)
      puts "skipping read bom"
    else
      read_bom_cloverServer
    end
    find_and_execute_task("#{env}_#{svc}")
    logger.level = Capistrano::Logger::INFO
    run_serially_in_batches(:find_server_opts => {:roles => "#{svc}".to_sym}) do |server_options|
      find_and_execute_task("update_cloverman")
    end
  end

  desc "Update cloverman"
  task :update_cloverman do
    logger.info ">>>>>>>>>>>>>>>>> In Update cloverman Phase2 "
    logger.info ">>>>>>>>>>>>>>>>> task update_cloverman "
    sandboxBaseDir = "#{basedir}/jetty-#{app}/sandboxes"

    # NOTE:
    # cloverman_repo is set in global.rb

    # if noBom, then we want the graphList to derive from url
    if exists?(:noBom)
      set :graphList, [ url ]
    end

    graphList.each do |graph|
      logger.info "Updating Cloverman >> Starting graph: #{graph}"
      graphProject = ""
      graphVersion = ""
      graphProject = graph.sub(/(.*clover-graphs-)(.*)(-\d.*|-CCP-BRANCH-SNAPSHOT.*|-CCP-LATEST-SNAPSHOT.*|-CCP-CERTIFIED-SNAPSHOT.*)/, '\2')
      # strip off impl if it's on the end of a graph
      graphProject = graphProject.sub(/(.*)(-impl.*)/, '\1')
      logger.info " >> graphVersion: #{graphProject}"
      # the above will fail if using CCP-LATEST-SNAPSHOT, since no number in it, so handle it
      if graphProject == graph
        logger.info " this is a graph, so figure out which ones..."
        graphProject = graph.sub(/(.*clover-graphs-)(.*)(-CCP-LATEST-SNAPSHOT.*)/, '\2')
      end
      graphVersion = graph.sub(/.*clover-graphs.*?-(.+)-graphs.tar.gz/, '\1')
      logger.info " >> graphVersion: #{graphVersion}"

      logger.info " Found a graph match working on Project: #{graphProject}..."

      existingGraphVersion = ""
      run "grep -m3 version /opt/ds/jetty-#{svc}/sandboxes/#{graphProject}/mypom/pom.xml | perl -pe 's/.*>(.+)\<.*/$1/' | tail -1" do |channel, stream, data|
        existingGraphVersion = data.chomp
      end

      #we want to skip graphs that are already the correct version unless the "force" flag is set
      unless exists?(:force)
        if existingGraphVersion == graphVersion
          logger.info "skipping #{graphProject}..."
          logger.info "existing version = #{existingGraphVersion}"
          logger.info "targeted version = #{graphVersion}"
          next
        end
      end
      sandboxDir = "#{sandboxBaseDir}/#{graphProject}"
      dataInDir = "#{sandboxDir}/data-in"

      # for wget params
      if svc == "merdevl" || svc == "cmpstkMerlinIngest" || svc == "merdevlBo2"
        set :cloverman_cfig_repo, "true"
      end

      def getCloverManFile(source,targetDir,targetName)
          get_remote_file("#{cloverman_repo}/" + source,targetDir,targetName)
      end

      # ncds updates
      if graphProject == "ncds"
        # Cloverman Bamboo rsyncs to /uploads/cloverman
        logger.info " >>>>> Starting NCDS processing using: #{cloverman_repo} "
        # controllers.txt
        logger.info " >>> Cleaning out old controllers file and existing channelmap files "
        run "rm -f #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers.*"
        logger.info "Just removed controllers file from sandboxes/#{graphProject}/data-in"
        run "rm -f #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/channelmaps_*"
        logger.info "Just removed all channelmap files from sandboxes/#{graphProject}/data-in"
        run "ls -1 #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in"

        logger.info " >>> Env matched to: #{svc} "

        # env specific updates
        if ["poc","ch2","chaz2"].any?{ |s| svc.include? s }
          getCloverManFile("controllers/controllers-cfig.txt.prod",dataInDir,"controllers.txt")
        elsif ["merdevl","ap","dev_bo_po"].any?{ |s| s == svc } 
          getCloverManFile("controllers/controllers-cfig-dacs.txt.dev",dataInDir,"controllers-dacs.txt")
          getCloverManFile("controllers/controllers-cfig-in-cfig.txt.dev",dataInDir,"controllers-in-cfig.txt")
        elsif svc.include?("merqa") or svc == "cmpstkMerlinIngest"

          # controllers-dacs.txt
          logger.info " >>> updating: controllers-dacs.txt "
          run "if [ -f \"#{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-dacs.txt\" ];  then mv #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-dacs.txt #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-dacs.txt_old; else touch #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-dacs.txt #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-dacs.txt_old; fi;"
          getCloverManFile("controllers/controllers-cfig-dacs.txt.dev",dataInDir,"controllers-dacs.txt")
          logger.info " >>> DIFF For controllers-dacs.txt: "
          run "diff #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-dacs.txt #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-dacs.txt_old; true"
          logger.info " >>> END DIFF "

          # controllers-in-cfig.txt
          logger.info " >>> updating: controllers-in-cfig.txt "
          run "if [ -f \"#{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-in-cfig.txt\" ];  then mv #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-in-cfig.txt #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-in-cfig.txt_old ; else touch #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-in-cfig.txt_old; fi;"
          getCloverManFile("controllers/controllers-cfig-in-cfig.txt.dev",dataInDir,"controllers-in-cfig.txt")
          logger.info " >>> DIFF For controllers-in-cfig.txt: "
          run "diff --from-file=#{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-in-cfig.txt #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/controllers-in-cfig.txt_old; true"
          logger.info " >>> END DIFF "
        end

        # locations_excluded.txt
        logger.info " >>> updating: locations_excluded.txt "
        # Remove the existing file, if it exists
        run "rm -f #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/locations_excluded.txt"
        if ["poc","ch2","chaz2"].any?{ |s| env.include? s } or ["merdevl","ap","dev_bo_po"].any?{ |s| s == env }
          getCloverManFile("controllers/locations_excluded.txt.prod",dataInDir,"locations_excluded.txt")
        elsif env == "cmpstkMerlinIngest"
          getCloverManFile("controllers/locations_excluded.txt.dev",dataInDir,"locations_excluded.txt")
        end

        # channel_duplicates.txt
        logger.info " >>> updating: channel_duplicates.txt "
        run "rm -f #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/channel_duplicates.txt"
        getCloverManFile("TXT/channel_duplicates.txt",dataInDir,"channel_duplicates.txt")
      end

      # edit updates
      if graphProject == "edit"
        logger.info " >>>>> Starting EDIT graph processing using: #{cloverman_repo} "
        logger.info " >>> Env matched to: #{svc} "
        run "rm -f #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/data-in/vod_locations.txt" 
        if svc.include? "po" or svc.include? "ch2" or svc.include? "br"
          getCloverManFile("controllers/vod_locations_vbn.txt",dataInDir,"vod_locations.txt")
        else
          getCloverManFile("controllers/vod_locations_lab.txt",dataInDir,"vod_locations.txt")
        end
      end
    end
  end

  desc "called by install_jetty"
  task "install_jetty_#{svc}".to_sym do
    run_serially_in_batches(:find_server_opts => {:roles => "#{svc}".to_sym}) do |server_options|
      jetty_install("#{svc}", "#{jetty_version}")
    end
  end

  desc "used to deploy #{svc}"
  task "deploy_#{svc}_#{env}".to_sym do
    find_and_execute_task("#{env}_#{svc}")
    run_serially_in_batches(:find_server_opts => {:roles => "#{svc}".to_sym}) do |server_options|
      find_and_execute_task("#{svc}_main_#{env}")
    end
  end

  desc "#called by #{svc}_main_#{env}"
  task "copy_#{svc}_#{env}".to_sym do
    set :url, Capistrano::CLI.ui.ask("Enter URL to cloverSerever tar.gz file:") unless exists?(:url)

    # Create #{tmpdir} if it does not exist
    run "mkdir -p #{tmpdir}"
    # remove contents of tmpdir
    run "rm -rf #{tmpdir}/#{svc}"
    set :cloverwar_webapps, "webapps"
    begin
      logger.info "BEGIN: install #{svc} (inside file: cloverServer.rb)"
      logger.info "CLOVER TAR GZ: wget #{wget_params} \"#{url}\" -O #{svc}.tar.gz"
      run "cd #{tmpdir} && wget #{wget_params} \"#{url}\" -O #{svc}.tar.gz"
    rescue
      logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
      `wget #{wget_params} \"#{url}\" -O working/#{svc}.tar.gz`
      upload("working/#{svc}.tar.gz","#{tmpdir}/#{svc}.tar.gz", :via => :scp)
    end

    # if you're setting "noBom", then don't go through the bom related tasks
    if exists?(:noBom) or exists?(:nobom)
        puts "skipping write_service_version"
    else
        write_service_version
    end

    #Subsitute the log4j java.io.tmpdir to theplatform.log.dir
    logger.info "==============#{tmpdir}========================"
    run "cd #{tmpdir}; rm -fr #{svc};mkdir #{svc};cd #{svc}; mv ../#{svc}.tar.gz .; tar xvf #{svc}.tar.gz; mv #{svc}.tar.gz ../#{svc}.tar.gz.bk;jar -xf #{cloverwar_webapps}/#{svc}.war WEB-INF/classes/log4j.xml; sed -ie 's/{java.io.tmpdir}/{theplatform.log.dir}/g' WEB-INF/classes/log4j.xml; jar -uf #{cloverwar_webapps}/#{svc}.war WEB-INF/classes/log4j.xml;rm -fr WEB-INF;tar czf ../#{svc}.tar.gz ."

    # cp the tar.gz and untar it into place
    run "cp #{tmpdir}/#{svc}.tar.gz #{basedir}/jetty-#{app}"
    run "cd #{basedir}/jetty-#{app}; tar xzf #{svc}.tar.gz"

    # clean out the working directory
    run "rm -rf #{basedir}/jetty-#{app}/work/*"
  end

  task "prepare_#{svc}_#{env}".to_sym do
    createLogback_clover
    get_remote_file("#{repo}/#{app}/ojdbc6-11.2.0.1.0.jar","#{basedir}/jetty-#{app}/lib/ext/","ojdbc6-11.2.0.1.0.jar")

    # Figure out what version of clover we're deploying.
    # This is important, because different versions of clover have different crons, etc...
    puts "Guessing what version of service I have using regex"
    puts "My package is: #{url}" # example: http://yum.dt.ccp.cable.comcast.com/caprepo/mvnrepo/cloveretl.server-3.0.8-a.tar.gz
    myCloverVersion = url.gsub(/.*cloveretl.server-/, "")
    myCloverVersion = myCloverVersion.gsub(/\.tar.gz.*/, "")
    puts "My guessed version is: #{myCloverVersion}"

    # Upload cloverServer.cfg
    # attend to the config file
    # create the primary Oracle DB Connection for CLover (NOT HASH)
    # this is used by the Admin interface and MUST be a SID, not a service name
    # ensure the DBA has created a SID and has setup the TNS:Listener to work with the SID
    logger.info "Clover: Creating #{app}.properties"
    if hiera('useMysqlForCloverAdmin')
      # if we are using a local Mysql server for the Clover Admin, then
      # use this alternate Clover config file
      # CREATE DATABASE IF NOT EXISTS clover_admin DEFAULT CHARACTER SET 'utf8';
      # CREATE USER 'CLOVER_MERQA'@'localhost' IDENTIFIED BY 'xcal09';
      # GRANT ALL PRIVILEGES ON clover_admin.* TO 'CLOVER_MERQA'@'localhost' WITH GRANT OPTION;
      logger.info "Clover: Using altername Mysql Admin config"
      cloverConfig = <<-file
jdbc.driverClassName=com.mysql.jdbc.Driver
jdbc.url=jdbc:mysql://127.0.0.1:3306/clover_admin?useUnicode=true&characterEncoding=utf8
jdbc.username=CLOVER_MERQA
jdbc.password=#{dbpasswd}
jdbc.dialect=org.hibernate.dialect.MySQLDialect
graph.debug_path=#{basedir}/jetty-#{app}/logs/cloverdebug
graph.logs_path=#{basedir}/jetty-#{app}/logs/graph
cluster.node.id=#{svc}
cluster.group.name=group
service.name=#{svc}
service.environment=#{service_environment}
engine.config.file=#{basedir}/jetty-#{app}/config/cloverEngine.properties
file
    else
	if (env == "cmpstkMerlinIngest")	
      cloverConfig = <<-file
jdbc.driverClassName=oracle.jdbc.OracleDriver
jdbc.url=#{hiera('clover_jdbc_dburl')}
jdbc.username=#{dbuser}
jdbc.password=#{dbpasswd}
jdbc.dialect=org.hibernate.dialect.Oracle9Dialect
graph.debug_path=#{basedir}/jetty-#{app}/logs/cloverdebug
graph.logs_path=#{basedir}/jetty-#{app}/logs/graph
cluster.node.id=#{svc}
cluster.group.name=group
service.name=#{svc}
service.environment=#{service_environment}
engine.config.file=#{basedir}/jetty-#{app}/config/cloverEngine.properties
file
   else
	cloverConfig = <<-file
jdbc.driverClassName=oracle.jdbc.OracleDriver
jdbc.url=#{hiera('dburl')}
jdbc.username=#{dbuser}
jdbc.password=#{dbpasswd}
jdbc.dialect=org.hibernate.dialect.Oracle9Dialect
graph.debug_path=#{basedir}/jetty-#{app}/logs/cloverdebug
graph.logs_path=#{basedir}/jetty-#{app}/logs/graph
cluster.node.id=#{svc}
cluster.group.name=group
service.name=#{svc}
service.environment=#{service_environment}
engine.config.file=#{basedir}/jetty-#{app}/config/cloverEngine.properties
file
   end
    end
    upload(StringIO.new(cloverConfig),"#{basedir}/jetty-#{app}/config/#{app}.properties", :via => :scp)
    
    # upload cron file
    time1 = Time.new
    puts "=========================="
    puts "Handling crons"
    puts "=========================="
    if env == "cmpstkMerlinIngest" || env == "chaz2Ingest"
    cloverCron = <<-CRON_FOR_CLOVER
# cleanup the feed files
0 6 * * * #{user} find /opt/ds/jetty-cloverServer/sandboxes -name *#{time1.year}* -mtime 14 -exec rm -rf {} +
0 6 * * * #{user} find /opt/ds/jetty-cloverServer/sandboxes -name *#{time1.year+1}* -mtime 14 -exec rm -rf {} +
0 6 * * * #{user} rm -f /opt/ds/jetty-cloverServer/tmp/.fbuf*
0 6 * * * #{user} rm -f /opt/ds/jetty-cloverServer/logs/graph/*gz
0 6 * * * #{user} find /opt/ds/jetty-cloverServer/logs -type f -mtime +95 -exec rm -rf {} +
CRON_FOR_CLOVER
    else
    cloverCron = <<-CRON_FOR_CLOVER
# cleanup the feed files
0 6 * * * #{user} find /opt/ds/jetty-cloverServer/sandboxes -name *#{time1.year}* -mtime 14 -exec rm -rf {} +
0 6 * * * #{user} find /opt/ds/jetty-cloverServer/sandboxes -name *#{time1.year+1}* -mtime 14 -exec rm -rf {} +
0 6 * * * #{user} rm -f /opt/ds/jetty-cloverServer/tmp/.fbuf*
0 6 * * * #{user} rm -f /opt/ds/jetty-cloverServer/logs/graph/*gz
0 6 * * * #{user} find /opt/ds/jetty-cloverServer/logs -type f -mtime +95 -exec rm -rf {} +
30 9 * * * root /etc/init.d/cloverServer restart
CRON_FOR_CLOVER
    end
    upload(StringIO.new(cloverCron), "/tmp/cloverCron", :via => :scp, :mode => 0644)
    run "sudo chown root:root /tmp/cloverCron ; sudo mv /tmp/cloverCron /etc/cron.d/cloverServer"

    logger.info "Clover: going to create the sandboxes dir"
    run "mkdir -p #{basedir}/jetty-#{app}/sandboxes"

    logger.info "Clover: setting up logging on /var partition"
    run "sudo mkdir -p /var/log/cloverServer/graph"
    run "sudo chown -R #{user}:#{user} /var/log/cloverServer"
    run "if [ -d \"#{basedir}/jetty-#{app}/logs/graph\" ] && ! [ -L \"#{basedir}/jetty-#{app}/logs/graph\" ]; then mv #{basedir}/jetty-#{app}/logs/graph/* /var/log/cloverServer/graph/; rmdir #{basedir}/jetty-#{app}/logs/graph; fi"
    run "if ! [ -L \"#{basedir}/jetty-#{app}/logs/graph\" ]; then ln -s /var/log/cloverServer/graph #{basedir}/jetty-#{app}/logs/graph; fi"

    # Upload clover.cfg
    # create Oracle db configs for the graphs to use the HASH user
    # this is a regular service name
    logger.info "Creating #{basedir}/jetty-#{svc}/sandboxes/clover.cfg"
    cloverString = <<-string
threadSafeConnection=true
dbDriver=oracle.jdbc.driver.OracleDriver
user=#{hash_dbuser}
password=#{dbpasswd}
name=clover
dbURL=#{hiera('dburl')}
jdbcSpecific=ORACLE
string
    upload(StringIO.new(cloverString),"#{basedir}/jetty-#{svc}/sandboxes/clover.cfg", :via => :scp)
  end

  def perl_sub_key_value(graphProject,file,key,value)
    value.gsub!(/@/, '\x{40}')
    value.gsub!(/&/, '\&')
    # & is the regular expression delimiter
    run "perl -pi -e 's&(^\s*#{key}=).*&${1}#{value}&' #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/#{file}"
  end

  def sub_file(graphProject,file,v)
    v.each{|k1,v1|
      perl_sub_key_value(graphProject,file,k1,v1)
    }
  end

  def migrateBootstrap(dir)
    if env.include?("mci") || env.include?("dev_bo_po")
      if env == "mciGbenv2"
        migenv = "systest2"
      elsif env == "dev_bo_po"
        migenv = "dev_bo_po"
      else
        migenv = "systest"
      end
         
      logger.info "Running migrations command: migrate bootstrap --env=#{migenv} --basedir=#{basedir} --app=#{app}"
      run ". ~/.bash_profile; cd #{dir}/migrations; bash bin/migrate bootstrap --env=#{migenv}", :once => true
    end
  end

  def migrateUp(dir)
    if env.include?("mci") || env.include?("merdevlBo2") || env.include?("dev_bo_po")
      if env.include?("mci")
        if env == "mciGbenv2"
          migenv = "systest2"
        else
          migenv = "systest"
        end
      elsif env == "dev_bo_po"
        migenv = "dev_bo_po"
      else
        migenv = "merdevl"
      end
         
      logger.info "Running migrations command: migrate up --env=#{migenv}"
      run ". ~/.bash_profile; cd #{dir}/migrations; bash bin/migrate up --env=#{migenv}", :once => true
    end
  end

  # Use wget to fetch a remote tar and unzip it to the dir
  def wgetAndExtractToDir(dir,remoteFile) 
    logger.info " >>  Pulling #{remoteFile} via wget, and extracting to #{dir}"
    run "cd #{dir} && wget #{wget_params_noproxy} \"#{remoteFile}\" -O- | tar -zvxpf -"
  end

  def dbPropReplace(f,user,url,pass,sandboxDir)
    cfgFile = "#{sandboxDir}/conn/#{f}.cfg" 
    run "perl -pi -e 's\#(user=).*\#${1}#{user}\#' #{cfgFile}"
    run "perl -pi -e 's\#(dbURL=).*\#${1}#{url}\#' #{cfgFile}"
    run "perl -pi -e 's\#(password=).*\#${1}#{pass}\#' #{cfgFile}"
  end

  def copyDbConfigurations(sandboxDir)
        run "cd #{sandboxDir}/conn && cp sample/entity-ingest.cfg entity-ingest.cfg || : && cp sample/entity-mw.cfg entity-mw.cfg || : && cp sample/linear-mw.cfg linear-mw.cfg  || : && cp sample/linear-ingest.cfg linear-ingest.cfg || : && cp sample/id.cfg id.cfg || :"
        run "cp #{sandboxDir}/conn/clover.cfg #{sandboxDir}/conn/sandbox.cfg || : && cp #{sandboxDir}/conn/clover.cfg #{sandboxDir}/conn/staging.cfg || :"
          
        # replace the db props in the clover conn files
        dbPropReplace('entity-mw', hiera('entityDataService_dbuser'), hiera('jdbc_url'), dbpasswd, sandboxDir)  
        dbPropReplace('entity-ingest', hiera('entityIngest_dbuser'), hiera('jdbc_url'), dbpasswd, sandboxDir)
        dbPropReplace('linear-ingest', hiera('linearIngest_dbuser'), hiera('jdbc_url'), dbpasswd, sandboxDir)
        dbPropReplace('linear-mw', hiera('linearDataService_dbuser'), hiera('jdbc_url'), dbpasswd, sandboxDir)
        dbPropReplace("id", hiera('idDataService_dbuser'), hiera('id_jdbc_url'), dbpasswd, sandboxDir)
        dbPropReplace('sandbox', hiera('gracenote_dbuser'), hiera('gracenote_jdbc_url'), hiera('gracenote_dbpasswd'), sandboxDir)
        dbPropReplace('staging', hiera('clover_staging_schema'), hiera('gracenote_jdbc_url'), hiera('gracenote_dbpasswd'), sandboxDir)        
  end

  task :sandbox_deploy do

    logger.info " >>>TASK: sandbox_deploy starting..."

    # if noBom, then we want the graphList to derive from url
    set :graphList, [ url ] if exists?(:noBom)
         
    logger.info "  starting graphList..."
    graphList.each do |graph|

      graphProject = graph.sub(/(.*clover-graphs-)(\w+).*/, '\2')
      graphVersion = graph.sub(/(.*)(v=)(.*?)\&.*/, '\3')

      logger.info " >> artifact: #{graph}"
      logger.info " >> graphProject: #{graphProject}"
      logger.info " >> graphVersion: #{graphVersion}"
      logger.info " _____________________________________________________________________"
      logger.info "working on: #{graphProject}..."

      existingGraphVersion = ""
      run "grep -m3 version /opt/ds/jetty-#{svc}/sandboxes/#{graphProject}/mypom/pom.xml | perl -pe 's/.*>(.+)\<.*/$1/' | tail -1" do |channel, stream, data|
        existingGraphVersion = data.chomp
      end

      logger.debug "cleaning up old on #{graphProject}..."

      sandboxBaseDir = "#{basedir}/jetty-#{app}/sandboxes"
      sandboxDir = "#{sandboxBaseDir}/#{graphProject}"

      # clean up the directories in the sandbox as residual files may cause issues
      ['lib','dlib','graph','trans','migrations'].each { |d| 
        logger.info "Cleaning up #{sandboxDir}/#{d}"
        run "rm -rf #{sandboxDir}/#{d}" 
      }

      begin
        wgetAndExtractToDir(sandboxBaseDir,graph) 
      rescue
        logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
        `wget #{wget_params} \"#{graph}\" -O working/#{graphProject}.tar.gz`
        upload("working/#{graphProject}.tar.gz", "#{basedir}/jetty-#{app}/sandboxes/#{graphProject}.tar.gz", :via => :scp)
        logger.info "Extracting #{graphProject} in #{basedir}/jetty-#{app}/sandboxes/#{graphProject}"
        run "cd #{basedir}/jetty-#{app}/sandboxes && tar -zxf #{graphProject}.tar.gz"
        logger.info "Removing #{graphProject} from #{basedir}/jetty-#{app}/sandboxes"
        run "cd #{basedir}/jetty-#{app}/sandboxes && rm -rf #{graphProject}.tar.gz"
      end

      # => if we add more environments that qualify as prod they should be added here
      dataInDir = "#{sandboxDir}/data-in"

      # Resources sandbox does not have migrations
      unless graphProject == "resources"
        logger.info(" >> Running migrations")
        migrateBootstrap(sandboxDir)
        migrateUp(sandboxDir)
        logger.info(" >> migrations complete")
      end

      unless graph.include?("resources")  # (resources doesn't have endpoint.prm or other standard sandbox files)
              
        logger.info " >> Have graph"

        logger.info(" >> Copying configs")

        if env == "chaz2Ingest"
          run "cd #{sandboxDir} && cp endpoint.prm.sample endpoint.prm ; cp workspace.prm.sample workspace.prm"
        else
          run "cd #{sandboxDir} && cp endpoint.prm.sample endpoint.prm ; cp workspace.prm.sample workspace.prm; cp day.prm.sample day.prm"
        end

        run "cd #{sandboxDir}/conn && ln -fs #{basedir}/jetty-#{app}/sandboxes/clover.cfg clover.cfg"

        if exists?(:useEBR) && useEBR
         run "perl -pi -e 's\#(E.._SUFFIX=).*\#${1}_rt\#' #{sandboxDir}/endpoint.prm"
        end

        logger.info " .........."
        logger.info " >> Config changes: now going in and fixing the configs..."

        # update the graph's workspace.prm
        workspace_prm_hash = {
          "PROJECT" => sandboxDir
        }
        sub_file(graphProject, 'workspace.prm', workspace_prm_hash)

        # update the graph's endpoint.prm
        endpoint_prm_general = hiera('endpoint.prm.general', :hash)
        endpoint_prm_graph = hiera("endpoint.prm.#{graphProject}", :hash) || {}
        endpoint_prm_hash = endpoint_prm_general.merge(endpoint_prm_graph)
        sub_file(graphProject, 'endpoint.prm', endpoint_prm_hash)
    
        check_my_dir(dataInDir)

        copyDbConfigurations(sandboxDir)

        if graphProject == "ncds"
        
          get_remote_file("#{cloverman_repo}/TXT/channel_duplicates.txt",dataInDir,"channel_duplicates.txt")
          
          if env.include?("po") or env.include?("chaz2Ingest")
            set :ppvUrl, 'ftp://\$\{BARCELONA_PROD_IP\}/ppv/current'
            run "perl -pi -e 's\#(NCDS_PLANT_URL=).*\#${1}http://76.96.5.27:7091/\#' #{sandboxDir}/endpoint.prm"
            run "perl -pi -e 's\#(PPV_URL=).*\#${1}#{ppvUrl}\#' #{sandboxDir}/endpoint.prm"
            run "perl -pi -e 's\#(VCW_MIGRATION=).*\#${1}true\#' #{sandboxDir}/endpoint.prm"
            run "if grep -q FILTER_BY_EXISTING_VCW= #{sandboxDir}/endpoint.prm ; then echo \"FILTER_BY_EXISTING_VCW= is already present\" ; else echo -e \"\\nFILTER_BY_EXISTING_VCW=true\" >> #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/endpoint.prm ; fi ;"
            run "perl -pi -e 's\#(FILTER_BY_EXISTING_VCW=).*\#${1}true\#' #{basedir}/jetty-#{app}/sandboxes/#{graphProject}/endpoint.prm"
          elsif ["merch2cIngest", "merdevl"].include?(svc) # defV temporarily points to production - this may be removed later
            set :ppvUrl, 'ftp://\$\{BARCELONA_PROD_IP\}/ppv/current'
            run "perl -pi -e 's\#(PPV_URL=).*\#${1}#{ppvUrl}\#' #{sandboxDir}/endpoint.prm"
          else #  any other ingest env
            logger.info "NCDS: - >>>>>> PPVURL - Setting in MERQA, so lets set it to BARCELONA_IP"
            set :ppvUrl, 'ftp://\$\{BARCELONA_IP\}/ppv/current'
            run "perl -pi -e 's\#(PPV_URL=).*\#${1}#{ppvUrl}\#' #{sandboxDir}/endpoint.prm"
            logger.info "NCDS: - >>>>>> PPVURL - set to #{ppvUrl}"
          end

          # run update_cloverman after deploying ncds graph
          find_and_execute_task("update_cloverman")
        elsif graphProject == "edit"
          get_remote_file("#{cloverman_repo}/XLS/itheme-tag-mapping.xls",dataInDir,"itheme-tag-mapping.xls")
          get_remote_file("#{cloverman_repo}/XLS/station-company-mapping.xls",dataInDir,"station-company-mapping.xls")
          get_remote_file("#{cloverman_repo}/XLS/company-tags-spreadsheet.xls",dataInDir,"company-tags-spreadsheet.xls")
          get_remote_file("#{cloverman_repo}/XLS/native-itheme-tag-mapping.xls",dataInDir,"native-itheme-tag-mapping.xls")
          get_remote_file("#{cloverman_repo}/XLS/persona-channel-map.xls",dataInDir,"persona-channel-map.xls")
          get_remote_file("#{cloverman_repo}/XLS/company_ids_for_firstrun_series.xls",dataInDir,"company_ids_for_firstrun_series.xls")
          get_remote_file("#{cloverman_repo}/XLS/company.xls",dataInDir,"company.xls")
          get_remote_file("#{cloverman_repo}/XML/mainImages.xml",dataInDir,"mainImages.xml")
          get_remote_file("#{cloverman_repo}/TXT/main-image-linear.txt",dataInDir,"main-image-linear.txt")
          get_remote_file("#{cloverman_repo}/TXT/main-image-entity.txt",dataInDir,"main-image-entity.txt")
          get_remote_file("#{cloverman_repo}/CSV/network-provider-mapping.csv",dataInDir,"network-provider-mapping.csv")
          get_remote_file("#{cloverman_repo}/CSV/zip-codes-database-DELUXE.csv",dataInDir,"zip-codes-database-DELUXE.csv")
          get_remote_file("#{cloverman_repo}/CSV/cim_tags.csv",dataInDir,"cim_tags.csv")
          get_remote_file("#{cloverman_repo}/TXT/cibo_source_map.lst",dataInDir,"cibo_source_map.lst")
        elsif graphProject == "alg"
           get_remote_file("#{cloverman_repo}/XLS/imdb-top-movies.xls",dataInDir,"imdb-top-movies.xls")
           get_remote_file("#{cloverman_repo}/XLS/tvguide-top-programs.xls",dataInDir,"tvguide-top-programs.xls")
        elsif graphProject == "amg"
           get_remote_file("#{cloverman_repo}/XLS/amg-music-adi-id-mapping.xls",dataInDir,"amg-music-adi-id-mapping.xls")
        elsif graphProject == "cim"
          # BITT-2568 - CIM SFTP HOST
          run "perl -pi -e 's\#(CIM_SFTP_HOST=).*\#${1}#{cim_sftp_host}\#' #{sandboxDir}/endpoint.prm"
        elsif graphProject == "misc"
           check_my_dir(dataInDir)
	elsif graphProject == "id"
           check_my_dir(dataInDir)
           run "cd #{sandboxDir}/conn && cp sample/otis.cfg otis.cfg"
           dbPropReplace('otis', hiera('otis_dbuser'), hiera('otis_dburl'), dbpasswd,  sandboxDir)
        elsif graphProject == "music"
           check_my_dir(dataInDir)
           run "cd #{sandboxDir}/conn && cp sample/entity-ingest.cfg entity-ingest.cfg"
           dbPropReplace('entity-ingest', hiera('entityIngest_dbuser'), hiera('jdbc_url'), dbpasswd, sandboxDir)
	elsif graphProject == "tvg"
           check_my_dir(dataInDir)
           run "cd #{sandboxDir}/conn && cp sample/entity-ingest.cfg entity-ingest.cfg"
           dbPropReplace('entity-ingest', hiera('entityIngest_dbuser'), hiera('jdbc_url'), dbpasswd, sandboxDir)
        elsif graphProject == "gracenote"
          check_my_dir(dataInDir)
          run "cp #{sandboxDir}/../clover.cfg #{sandboxDir}/conn/sandbox.cfg"
          dbPropReplace('sandbox', hiera('gracenote_dbuser'), hiera('gracenote_jdbc_url'), hiera('gracenote_dbpasswd'), sandboxDir)
          run "cp #{sandboxDir}/endpoint.prm #{sandboxDir}/migration.prm"
          migration_prm_general = hiera('migration.prm.general', :hash)
          migration_prm_graph = hiera("migration.prm.#{graphProject}", :hash) || {}
          migration_prm_hash = migration_prm_general.merge(migration_prm_graph)
          sub_file(graphProject, 'migration.prm', migration_prm_hash)
        end

        logger.info "Contents of data-in -"
        run "ls -l #{dataInDir}"
      end
    end
  end

logger.info ">>>>> loaded cloverServer"
