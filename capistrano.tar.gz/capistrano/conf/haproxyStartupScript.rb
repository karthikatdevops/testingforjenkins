################################
#
#  Make the haproxy startup script and deploy it on the server
#  This script uses md4 hashes to detect changed cfg files in haproxy.d
#  and then regenerate the actual /etc/haproxy/haproxy.cfg file
# 
#
###############################


desc "called by #{name}_main_#{env}"
task :deploy_haproxy_start_script do
  logger.info "called by #{name}_main_#{env}"
  logger.info "Creating the haproxy special edition 2015 Ultra coreduo /etc/init.d file and uploading to haproxy server...."
  haproxy_startup_script = <<-HAPROXY_STARTUP 
#!/bin/sh
# HAPROXY with Config checker and builder
# 2013,14,15 Comcast Compass
#
# chkconfig: 2345 99 01
# description: HA-Proxy is a TCP/HTTP reverse proxy which is particularly suited 
#              for high availability environments.
# processname: haproxy
# config: /etc/haproxy/haproxy.cfg
# pidfile: /var/run/haproxy.pid

# Script Author: Simon Matter <simon.matter@invoca.ch>
# Version: 2004060600
# Updates by YJR and Andrew Diller (andrew_diller@comcast.com)
#
# Jan 2015 - followed logic for 1st time, cried for an hour and then worked it
#            so that it actually seems to work now, and stays out of /tmp [dillera]
####################################################################################

# Source function library.
if [ -f /etc/init.d/functions ]; then
  . /etc/init.d/functions
elif [ -f /etc/rc.d/init.d/functions ] ; then
  . /etc/rc.d/init.d/functions
else
  exit 0
fi

# Source networking configuration.
. /etc/sysconfig/network

# Check that networking is up.
[ ${NETWORKING} = "no" ] && exit 0

# This is our service name
BASENAME=`basename $0`
if [ -L $0 ]; then
  BASENAME=`find $0 -name $BASENAME -printf %l`
  BASENAME=`basename $BASENAME`
fi
echo "================================================================"
echo "BASENAME is set to $BASENAME"
echo "Starting UltraAdvanced 2015 haproxy init.d script"
echo " "

# bailout if the head.cfg file dosen't exist
function checkForConfigurationHeadFile {
   if [ -f "/etc/$BASENAME/${BASENAME}.d/${BASENAME}_head.cfg" ]; then
      echo "Found ${BASENAME}_head.cfg"
   else
      echo "HARD STOP - cannot find /etc/$BASENAME/${BASENAME}.d/${BASENAME}_head.cfg"
      echo " THIS FILE MUST EXIST PRIOR To the script running"
      echo " HINT: copy over from other haproxy server or make cap install it"
      # go no further
      exit 1
   fi
}


function checkForSaveDirectory {
   MD5SAVEDIR=/etc/haproxy/MD5
   if [ -d $MD5SAVEDIR ]; then
      echo "md5 dir exists at $MD5SAVEDIR"
   else
      echo "creating dir $MD5SAVEDIR"
      mkdir -p $MD5SAVEDIR
   fi
}


function gen_cfg_file {
   echo "called gen_cfg file...."
   cat /etc/$BASENAME/${BASENAME}.d/${BASENAME}_head.cfg > /etc/$BASENAME/$BASENAME.cfg.new
   cat /etc/$BASENAME/${BASENAME}.d/${BASENAME}-*.cfg >> /etc/$BASENAME/$BASENAME.cfg.new
   /usr/sbin/$BASENAME -c -q -f /etc/$BASENAME/$BASENAME.cfg.new
   if [ $? -ne 0 ]; then
      echo "Errors found in configuration file, check it with '$BASENAME check'."
      return 1
   else
      mv /etc/$BASENAME/$BASENAME.cfg /etc/$BASENAME/$BASENAME.cfg.old
      cp /etc/$BASENAME/$BASENAME.cfg.new /etc/$BASENAME/$BASENAME.cfg
   fi
}


function saveNewMD5File {
   echo called saveNewMD5File
   local full_name=$1
   local file_name=$(basename "${full_name}") 
   local current_md5=`md5sum $full_name | cut -d ' ' -f1`
   echo $current_md5 > ${MD5SAVEDIR}/${file_name}.md5
   echo "${MD5SAVEDIR}/${file_name}.md5 written out."
}

function isTheSameFile {
   checkForSaveDirectory
   full_name=$1
   file_name=$(basename "${full_name}") 
   current_md5=`md5sum $full_name | cut -d ' ' -f1`
   echo " "
   echo "full_name= $full_name"
   echo "file_name= $file_name"
   echo "current_md5= $current_md5"
   if [ -f "${MD5SAVEDIR}/${file_name}.md5" ]; then
      echo "found a saved md5 for ${file_name}"
      saved_md5=`cat $MD5SAVEDIR/${file_name}.md5`
      echo "saved_md5= $saved_md5"
      if [ "$saved_md5" == "$current_md5" ];then
         echo "Matched - md5 sums on this file, no changes to integrate." 
         return 0
      else
         echo "Unmatched - md5 sum does not match on this new file compared to current one."
         return 1
     fi
   else
      echo "Warning: did not find a saved md5 file for ${file_name}, going to save current."
      echo "Creating new md5 config file now......"
      echo $new_md5 > ${MD5SAVEDIR}/${file_name}.md5
      echo "${MD5SAVEDIR}/${file_name}.md5 created."
      return 1
   fi
   echo "ending of isTheSameFile" 
}


# Main loop of the config checker/builder

# ensure we have the top of the haproxy file already on this system (cap code should have pushed it down)
checkForConfigurationHeadFile

# loop over each cfg file found in .d directory and check to see if there are changes
# pushed over from capistrano
for f in `ls /etc/$BASENAME/${BASENAME}.d/${BASENAME}*.cfg`; do
   echo "----------------------------------------"
   echo " MAIN LOOP.... Currently Checking: $f"  

   isTheSameFile $f
   is_the_same=$?

   if isTheSameFile $f ; then
        echo "the file $f matches the saved md5, so there are no changes to this section"
    else
        echo "the config file does not match the saved md5 or there is none found, going to call gen_cfg_file"
        gen_cfg_file
        saveNewMD5File $f
        break
    fi  
done

#######################################################################################################
#
# Regular init.d functions are below:
#
#######################################################################################################

RETVAL=0

stop() {
  echo -n "Shutting down $BASENAME: "
  killproc -p /var/run/$BASENAME.pid $BASENAME
#  killproc $BASENAME -USR1
  RETVAL=$?
  echo
  [ $RETVAL -eq 0 ] && rm -f /var/lock/subsys/$BASENAME
  [ $RETVAL -eq 0 ] && rm -f /var/run/$BASENAME.pid
  return $RETVAL
}

forcestart() {
  echo -n "Starting $BASENAME: "
  daemon /usr/sbin/$BASENAME -D -f /etc/$BASENAME/$BASENAME.cfg -p /var/run/$BASENAME.pid
  RETVAL=$?
  if [ $RETVAL -ne 0 ]; then
        stop
        echo -n "somthing failed..... "
  fi
  echo
  [ $RETVAL -eq 0 ] && touch /var/lock/subsys/$BASENAME
  return $RETVAL
} 

start() {
  /usr/sbin/$BASENAME -c -q -f /etc/$BASENAME/$BASENAME.cfg
  if [ $? -ne 0 ]; then
    echo "Errors found in configuration file, check it with '$BASENAME check'."
    return 1
  fi

  echo -n "Starting $BASENAME: "
  daemon /usr/sbin/$BASENAME -D -f /etc/$BASENAME/$BASENAME.cfg -p /var/run/$BASENAME.pid
  RETVAL=$?
  if [ $RETVAL -ne 0 ]; then
        stop
        echo -n "Restarting $BASENAME with old cfg file: "
  cp /etc/$BASENAME/$BASENAME.cfg.old /etc/$BASENAME/$BASENAME.cfg
  daemon /usr/sbin/$BASENAME -D -f /etc/$BASENAME/$BASENAME.cfg -p /var/run/$BASENAME.pid
        RETVAL=$?
  fi
  echo
  [ $RETVAL -eq 0 ] && touch /var/lock/subsys/$BASENAME
  return $RETVAL
}

restart() {
  /usr/sbin/$BASENAME -c -q -f /etc/$BASENAME/$BASENAME.cfg
  if [ $? -ne 0 ]; then
    echo "Errors found in configuration file, check it with '$BASENAME check'."
    return 1
  fi
  stop
  start
}

reload() {
  /usr/sbin/$BASENAME -c -q -f /etc/$BASENAME/$BASENAME.cfg
  if [ $? -ne 0 ]; then
    echo "Errors found in configuration file, check it with '$BASENAME check'."
    return 1
  fi
  /usr/sbin/$BASENAME -D -f /etc/$BASENAME/$BASENAME.cfg -p /var/run/$BASENAME.pid -sf $(cat /var/run/$BASENAME.pid)
}

check() {
  /usr/sbin/$BASENAME -c -q -V -f /etc/$BASENAME/$BASENAME.cfg
}

rhstatus() {
  status $BASENAME
}

condrestart() {
  [ -e /var/lock/subsys/$BASENAME ] && restart || :
}

# See how we were called.
case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  forcestart)
    forcestart
    ;;    
  restart)
    restart
    ;;
  reload)
    reload
    ;;
  condrestart)
    condrestart
    ;;
  status)
    rhstatus
    ;;
  check)
    check
    ;;
  *)
    echo $"Usage: $BASENAME {start|stop|restart|reload|condrestart|status|check}"
    exit 1
esac
 
exit $?
    HAPROXY_STARTUP

  File.open("working/haproxy.tmp",'w+'){|f| f.puts haproxy_startup_script;} 
  logger.info " about to upload startup... "
  upload("working/haproxy.tmp","/tmp/haproxy.hold", :via => :scp, :hosts => ha_host) 
  logger.info " uploaded startup.  "
#  logger.info " about to compare to existing startup file "
  #run "if [ `md5sum /tmp/haproxy.hold | awk '{print $1}'` != `md5sum /etc/init.d/haproxy | awk '{print $1}'` ];then sudo mv /tmp/haproxy.hold /etc/init.d/haproxy; else echo '>>>>>> haproxy start files match, no need to update..';fi "
  run "sudo mv /tmp/haproxy.hold /etc/init.d/haproxy && sudo chmod 755 /etc/init.d/haproxy && sudo chown root:root /etc/init.d/haproxy" ,{:hosts => "#{ha_host}"}
  logger.info " Moved new haproxy file into place in /etc/init.d. "
  logger.info " Completed task, leaving deploy_haproxy_start_script. "
 
end 
