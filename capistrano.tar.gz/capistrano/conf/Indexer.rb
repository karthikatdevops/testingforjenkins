[svc].each do |name|

     desc "called by #{env}_#{name} in #{env}.rb"
     task "#{name}_main_#{env}".to_sym do
       logger.level = Capistrano::Logger::INFO
       logger.info "DEBUG: TASK: #{name}_main_#{env}"
       
     
       set :app, "#{name}"
       set :install_path, "/opt/ds/#{name}"
       puts "....Set install_path=#{install_path}"
       #set :appstagingdir, "/opt/ds/staging/#{name}"

       logger.info "START: this is #{app}"
       logger.info "DEBUG: about to read_bom"
       
       if exists?(:noBom) or exists?(:nobom)
         #set :skipWriteServiceVersion, "true"
         logger.info "skipping read bom"
       else
         check_service_version
         read_bom
       end
       

       if exists?(:cleanServer) && cleanServer.to_s == "true"
        logger.info "NOT IMPLEMENTED clean installing #{name}"
       end   
       find_and_execute_task("copy_#{name}_#{env}")   
       if "#{startService}" == "false"
          logger.info "Not starting #{name} due to startService=#{startService}"
       else
         find_and_execute_task("start_#{name}")
       end
     end


     desc "called by #{name}_main_#{env}"
     task "start_#{name}".to_sym do
 	    run "sudo /etc/init.d/#{name} start ; sleep 2"
     end

    desc "used to deploy #{name}_#{env}"
    task "deploy_#{name}_#{env}".to_sym do
      logger.level = Capistrano::Logger::INFO
      logger.info "M1 TASK: deploy_#{name}_#{env}.to_sym do"
      eval("#{env}_#{name}")
      find_servers(:roles => "#{name}".to_sym).each do |server|
        ENV['HOSTS'] = "#{server.host}"
        set :startService, server.options[:startService]
        set :startServiceAtBoot, server.options[:startServiceAtBoot]
        find_and_execute_task ("#{name}_main_#{env}")
      end
    end
    
  desc "called by #{name}_main_#{env}"
  task "copy_#{name}_#{env}".to_sym do
    logger.info "M2 TASK: copy_#{name}_#{env}.to_sym do"
    run "[ -f /etc/init.d/#{name} ] && sudo /etc/init.d/#{name} stop ; exit 0"
    run "rm -rf #{install_path}"
    run "mkdir -p #{install_path}"
    run "cd #{install_path};mkdir -p logs version"
    if exists?(:noBom) or exists?(:nobom)
        # remove contents of tmpdir 
        run "rm -rf #{tmpdir}/#{name}"
        run "mkdir -p #{tmpdir}/#{name}"
        if variables[:localUrl]
            # If we're using a local file, there is nothing to wget
            logger.info "BEGIN: install service inside #{name}"
            logger.info " using a localUrl: #{localUrl}"
            logger.info " Upload the tarball to the server"
            #grab the zip file, unzip it, and mv it to a meaningful name      
            upload("#{localUrl}","#{install_path}/#{name}.tar.gz", :via => :scp)
            run "cd #{install_path} && tar xzf #{name}.tar.gz"
            # WRITE SERVICE VERSION
            puts "I have no BOM-- guessing what version of service I have using regex"
            puts "My package is :#{localUrl}... so, I can't really guess my version from this"
            puts " since the package name could be anything.  Just putting 'localUrl' as the version string"
            run "echo \"#{localUrl} (noBom)\" > #{install_path}/version/version.txt"
            # POST HISTORY
            run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
            logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
            run "touch #{basedir}/history/#{app}/deploy_history.txt"
            run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
            run "echo \"Version: #{localUrl} (noBom)\" >> #{basedir}/history/#{app}/deploy_history.txt"
        else
            logger.info " attempting to wget #{url}"
            logger.info " using cmd: wget #{wget_params} --no-proxy \"#{url}\" -O- working/#{name}.tar.gz"
            #grab the zip file, unzip it, and mv it to a meaningful name      
            logger.info "using a local wget and scp up to the server, this will take a bit of time..."
            `wget #{wget_params} --no-proxy \"#{url}\" -O working/#{name}.tar.gz`
            upload("working/#{name}.tar.gz","#{install_path}/#{name}.tar.gz", :via => :scp)
            run "cd #{install_path} && tar xzf #{name}.tar.gz"
            # WRITE SERVICE VERSION
            puts "I have no BOM-- guessing what version of service I have using regex"
            puts "My package is: #{url}"
            myNoBomVersion = url.gsub(/-indexer.tar.gz.*/, "")
            myNoBomVersion = myNoBomVersion.gsub(/.*\/pl-data-tv-.*-indexer-/, "")
            puts "My guessed version is: #{myNoBomVersion}"
            run "echo \"#{myNoBomVersion} (noBom)\" > #{install_path}/version/version.txt"
            # POST HISTORY
            run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
            logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
            run "touch #{basedir}/history/#{app}/deploy_history.txt"
            run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
            run "echo \"Version: #{myNoBomVersion} (noBom)\" >> #{basedir}/history/#{app}/deploy_history.txt"
        end
    else
      get_remote_file("#{url}","#{install_path}","#{app}.tar.#{service_version}.gz")
      logger.info "unpacking tarball"
      run "cd #{install_path} && tar xzf #{app}.tar.#{service_version}.gz"
      run "echo #{service_version} #{bom} > #{install_path}/version/version.txt"
      # POST HISTORY
      run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
      logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
      run "touch #{basedir}/history/#{app}/deploy_history.txt"
      run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
      run "echo \"Version: #{service_version} #{bom}\" >> #{basedir}/history/#{app}/deploy_history.txt"
    end

    find_and_execute_task("updateConfig_#{name}_#{env}")
    find_and_execute_task("initd#{name}")
    logger.info "TASK: END"
    
  end
  
  desc "called by copy_#{name}_#{env} to search and replace the #{name}Configuration.xml"
  task "updateConfig_#{name}_#{env}".to_sym do

     # Copy the test.properties file over to the used config file
     run "if [ -e #{install_path}/config/test.properties ]; then cp #{install_path}/config/test.properties #{install_path}/config/DS_Configuration.properties ; fi"

     #########################
     # GENERAL SUBSTITUTIONS
     #########################
     # First, we need to determine if we're DSS 2.5
     #grab the zip file, unzip it, and mv it to a meaningful name
     dssversion=""

         #####################
         # SUBSTITUTION MAGIC
         #####################
         # Start with a blank regex string
         regex=""
         regex_commented=""

         ########################################
         # LINEAR INDEXER SUBSTITUTIONS
         ########################################
# all these settings are now in hiera
             indexer_config_overrides = hiera('indexer_properties', :hash)
           
             indexer_config_overrides.each do |key, value|
                 key = key.gsub(/\./, "\\.")
                 key = key.gsub(/\-/, "\\-")
                 key = key.gsub(/\,/, "\\,")
                 key = key.gsub(/\//, "\\/")
                 key = key.gsub(/\@/, "\\@")
                 value = value.gsub(/\./, "\\.")
                 value = value.gsub(/\-/, "\\-")
                 value = value.gsub(/\,/, "\\,")
                 value = value.gsub(/\//, "\\/")
                 value = value.gsub(/\@/, "\\@")
                 regex = regex + "s/^\s*#{key}=.*/#CAPIFIED\n#{key}=#{value}/g ; "
                 regex_commented = regex_commented + "s/^\s*#\s*#{key}=.*/#CAPIFIED\n##{key}=#{value}/g ; "
             end
             
             global_config_injections = {
               "indexer.incrementalLookupBatchSize"       => "100"
             }             

         # Perform the substitution
         run "perl -pi -e '#{regex}' #{install_path}/config/DS_Configuration.properties"
         run "perl -pi -e '#{regex_commented}' #{install_path}/config/DS_Configuration.properties"
         global_config_injections.each do |key, value|
           run "if grep -q #{key}= #{basedir}/#{app}/config/DS_Configuration.properties ; then echo \"#{key}= is already present\" ; else echo \"#{key}=#{value}\" >> #{basedir}/#{app}/config/DS_Configuration.properties ; fi ;"       
         end

  end # task "updateConfig_#{name}_#{env}".to_sym do
  
  desc  "called by copy_#{name}_#{env} to write init and wrapper" 
  task "initd#{name}".to_sym do
  logger.info "M3 TASK: initd#{name}"

  download("#{install_path}/config/test.properties","working/DS_Configuration.properties.#{ENV['HOSTS']}.#{name}.current", :via => :scp)
  myConfigString=""
  myConfigDerbyLine=""
  myConfigAgentConfig=""

  initd_string = <<-initdfile
  #!/bin/bash
  #
  # /etc/init.d/#{name}
  # init script for #{name}
  #
  # chkconfig: 2345 90 60
  # description: #{name}
  #
   JAVA_HOME=/usr/java/latest
   JAVA_EXE=$JAVA_HOME/bin/java
   INDEXER_HOME=#{install_path}
   LOCK_FILE=/var/lock/subsys/#{app}
   RUN_AS_USER=#{user}
   
   DEFAULTIFACE=`netstat -rn | grep ^0.0 | awk '{print $8}'`
   IPADDRESS=`/sbin/ifconfig $DEFAULTIFACE | grep 'inet addr:' | awk '{print $2}' | awk -F: '{print $2}'`
   
   EXE_LIB=`ls -1 $INDEXER_HOME/lib/*.jar |tr '\\n' ':'`.q
   EXE_JAR=`ls $INDEXER_HOME/lib/*-data-tv-*-indexer-*.jar`
   
   checkGroup() {
       if [ "X$RUN_AS_USER" != "X" ]
       then
              RUN_AS_GROUP=`groups $RUN_AS_USER | awk '{print $3}' | tail -1`
              if [ "X$RUN_AS_GROUP" = "X" ]
              then
                   RUN_AS_GROUP=$RUN_AS_USER
   		return 0
              fi
       fi
       return 1
   }


   start () {
       echo "Starting #{app} "
       
       # start daemon 
       cd $INDEXER_HOME 
       JAVA_OPTS="-Xms512m -Xmx512m -Xdebug -Djava.compiler=NONE \
       -Djava.rmi.server.hostname=$IPADDRESS \
       -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=#{hiera('jmx_port')} \
       -Dcom.sun.management.jmxremote.authenticate=false \
       -Xrunjdwp:transport=dt_socket,server=y,address=#{hiera('debug_port')},suspend=n \
       -Dcom.sun.management.jmxremote.ssl=false -Dtheplatform.log.dir=$INDEXER_HOME/logs \
       #{myConfigDerbyLine} \
       -Dlogback.configurationFile=$INDEXER_HOME/config/logback.xml \
       #{myConfigAgentConfig} "
 
        pid=`ps uax | grep -e $EXE_JAR |grep -v grep| head -n 1 | awk '{print $2}'`
        if [ -z "$pid" ]; then
        	sudo su - $RUN_AS_USER -c "cd $INDEXER_HOME ; $JAVA_EXE $JAVA_OPTS -cp $EXE_LIB -jar $EXE_JAR > #{app}-daemon.log  &"
        	RETVAL=$?
        else
   	echo "#{name} was started. It cannot be started again!"
           RETVAL=1
        fi
        if [ $RETVAL = 0 ]; then
   	sudo touch $LOCK_FILE 
   	checkGroup 
   	if [ -n "$RUN_AS_GROUP" ]; then
   		sudo chown $RUN_AS_USER:$RUN_AS_GROUP $LOCK_FILE 
   		echo "#{name} has been started successful!"
   	else
   		sudo rm $LOCK_FILE
   		echo "#{name} is started successful. But it cannot create lock file because there the user $RUN_AS_USER does not belong to any group"
   	fi
        fi
        return $RETVAL
   }

   stop () {
       # stop daemon
       echo "Stopping #{name}..."
       pid=`ps uax | grep -e $EXE_JAR |grep -v grep| head -n 1 | awk '{print $2}'`
       if [ -n "$pid" ]; then
   	      kill -9 $pid
   	      RETVAL=$?
       else
   	     echo "#{name} was not running"
   	     RETVAL=1 #There is no #{name} running
       fi
       [ $RETVAL = 0 ] && [ -e "$LOCK_FILE" ] && sudo rm $LOCK_FILE && echo "#{name} has been fully stopped!"
       return $RETVAL
   }
   restart() {
       stop
       start
   }
   rebuild() {
     `bash -c "java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p #{hiera('jmx_port')} <( echo 'puts [ jmx_invoke -m thePlatform:application=IndexerAgent,endpoint=Program,name=management rebuild  ] ; jmx_close;' ) > /dev/null 2>&1"`
   }
   restart_rebuild() {
       restart
       sleep 15
       rebuild
   }

   case $1 in
       start)
           start
       ;;
       stop)
           stop
       ;;
       restart)
            restart
       ;;
       rebuild)
            rebuild
       ;;
       restart_rebuild)
            restart_rebuild
       ;;
       *)

       echo $"Usage: $0 {start|stop|restart|rebuild|restart_rebuild}"
       exit 3
   esac
   exit $RETVAL
initdfile
       
      my_initd_file = File.open("working/#{name}initd", 'w')
      my_initd_file.puts "#{initd_string}"
      my_initd_file.close
      upload("working/#{name}initd","#{install_path}/initd", :via => :scp, :mode => "755")
      run "sudo mv #{install_path}/initd /etc/init.d/#{name} && sudo chmod 755 /etc/init.d/#{name} && sudo chown root:root /etc/init.d/#{name}" 
      if "#{startServiceAtBoot}" == "false"
        logger.info "Not enabling autostart of #{name} due to startServiceAtBoot=#{startServiceAtBoot}"
      else
        run "sudo /sbin/chkconfig --add #{app}"
        logger.info "DEBUG: ran chkconfig add"
      end
      logger.info "DEBUG: completed initd script"
   end #end task "initd#{name}" 
end #end Services iteration block

logger.info ">>>>> loaded Indexer"