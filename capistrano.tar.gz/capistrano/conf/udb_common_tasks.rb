# UDB Common Tasks
# use this for common tasks that will be needed and called by udbBrowseServices.rb
# and udbServices.rb

# 2015 andrew_diller@comcast.com
#############################################################
puts "Loaded udb_common_tasks.rb"

# loop over all these tasks so they get assigned insances
# the services are the arrays at the top of the udbService.rb,
# ngbService.rb files.

[svc].each do |name|


#################################
#
# Build init.d script and start.sh (netty wrappers) and install them
#
#
task "setup_udb_initd_and_wrapper_#{name}".to_sym do
   logger.info "TASK: setup_udb_initd_and_wrapper_#{name}"

   # set up dynaTrace (just sets dynaTrace_options to "" if :dynaTrace_collectors is not set)
   configure_dynaTrace

   set :web_port, hiera("#{name}_web_port")
   set :jmx_port, hiera("#{name}_jmx_port")
   set :jmx_debug, hiera("#{name}_debug_port")
   set :debug_port, hiera("#{name}_debug_port")
   
   set :enable_jmxremote_ssl, "false"
   set :xmx, hiera("xmx")
   set :xms, hiera("xms")
   set :app_main, hiera("app_main")
   set :user, hiera("svc_user")
   set :alive_path, hiera("#{name}_alive")
   set :do_we_debug, hiera("debug_port_on")

   debugOptions = (hiera('debug_port_on') == 'true') ? "-Xrunjdwp:transport=dt_socket,server=y,address=#{hiera("#{app}_debug_port")},suspend=n" : ""

   logger.info " "
   logger.info " ))) We are going to setup the init.d script and netty start script......"
   logger.info " "

   logger.info "********************************************************************"
   logger.info "*                                                                  *"
   logger.info "*   web_port              : #{web_port} "
   logger.info "*   jmx_port              : #{jmx_port} "
   logger.info "*   debug_port            : #{debug_port} "
   logger.info "*   debug_port_on         : #{do_we_debug} "
   logger.info "*   xmx                   : #{xmx}     "
   logger.info "*   xms                   : #{xms}     "
   logger.info "*   enable_jmxremote_ssl  : #{enable_jmxremote_ssl}"
   logger.info "*   app_main              : #{app_main}  "
   logger.info "*   user                  : #{user}  "
   logger.info "*   install_path/app_home : #{install_path}"
   logger.info "*   app                   : #{app}                                 *"
   logger.info "*                                                                  *"
   logger.info "*                                                                  *"



   initd_string = <<-initdfile
#!/bin/bash
#
# Standard Browse Service init.d
#
# From CAP
#
# chkconfig: 345 90 60
# description:   Start up the #{name} Server
# Source function library.
. /etc/init.d/functions

export SERVICE_NAME=#{name}
export APP_HOME=#{install_path}
SHUTDOWN_WAIT=5

# Set the instance specific environment

# Define PID file location
APP_PID_DIR=/var/run/$SERVICE_NAME
export APP_PID=$APP_PID_DIR/$SERVICE_NAME.pid

if [ ! -e $APP_PID_DIR ];
then
  mkdir $APP_PID_DIR
  chown #{user}:#{user} $APP_PID_DIR
fi

RETVAL=0

start() {
  if [ -e $APP_PID ];
  then
      # Confirm PID is no longer running
      status -p $APP_PID > /dev/null 2>&1
      STATUS=$?

      if [ $STATUS -eq 0 ];
      then
          echo "Process is already running..."
          status -p $APP_PID
          exit 1
      fi
  fi

  if [ -f $APP_HOME/bin/start.sh ];
  then
     echo "Starting $SERVICE_NAME..."
     cd ${APP_HOME}/bin
     echo "I am in: [ `pwd` ]"
     /bin/su #{user} ${APP_HOME}/bin/start.sh
     echo " > attempting to start ${SERVICE_NAME}..."
     RETVAL=$?
     touch /var/lock/subsys/$SERVICE_NAME
     status -p $APP_PID
     return $RETVAL;
  fi
}

stop() {

echo "Shutting down $SERVICE_NAME sending Termination signal"

# Confirm PID is  running

status -p $APP_PID
STATUS=$?

if [ $STATUS -eq 0 ];
then
    killproc -p $APP_PID -d $SHUTDOWN_WAIT
    RETVAL=$?
    echo
fi
if [ -f $APP_PID ];
  then
     rm $APP_PID
else
   echo '  pid has been removed properly.'
fi

return $RETVAL;

}

case "$1" in
  start)
      start
      ;;
  restart)
      stop
      start
      ;;
  status)
      status -p $APP_PID
      ;;
  stop)
      stop
      ;;
  *)
echo "Usage: $SERVICE_NAME {start|stop}"
exit 1
  ;;
esac

exit $RETVAL
    initdfile

###########################################################
# startup
#
#
   startscript_string = <<-startscript
 #!/bin/bash
 # UDB Startup Scripts
 # 2015 ComPASS/Created by Capistrano

 umask 000

 ## TODO: Standard APP_HOME processing
 ## For now, assuming that this script is being run from the 'bin' directory

# If APP_HOME is not defined already, assign it to the value
#  that was defined at the time of the capistrano deployment

if [ -z ${APP_HOME+x} ]; then
  export APP_HOME="#{install_path}"
fi

export RESOURCE_PATH="${APP_HOME}/conf"


 CP=$RESOURCE_PATH
 for j in `ls $APP_HOME/lib/*.jar`
 do
   CP=${CP}:${j}
 done

 export JAVA_HOME=/usr/java/latest
 export PATH=$JAVA_HOME/bin:$PATH

 # This is defined in capistrano
 APP_MAIN="#{app_main}"

 # This is needed to set the JMX RMI interface
 # it is designed for redhat/centos based systems
  DEFAULTIFACE=`netstat -rn | grep ^0.0 | awk '{print $8}'`
  IPADDRESS=`/sbin/ifconfig $DEFAULTIFACE | grep 'inet addr:' | awk '{print $2}' | awk -F: '{print $2}'`

JVM_OPTS=" \\
  -server \\#{
  ( app == "playTimeService" || app == "fedRex" ) ?
  "
  -XX:+UseG1GC -Djava.security.egd=file:///dev/urandom -XX:MaxGCPauseMillis=250 -XX:+UseStringDeduplication \\" :
  "
  -XX:NewRatio=2  \\
  -XX:SurvivorRatio=6 \\
  -XX:TargetSurvivorRatio=90  \\" }
  -Duser.timezone=UTC \\
  -Dlogback.configurationFile=${RESOURCE_PATH}/logback.xml \\
  -Xmx#{xmx}m \\
  -Xms#{xms}m \\
  -Dcom.sun.management.jmxremote \\
  -Djava.rmi.server.hostname=$IPADDRESS \\
  -Dcom.sun.management.jmxremote.port=#{jmx_port} \\
  -Dcom.sun.management.jmxremote.authenticate=false \\
  -Dcom.sun.management.jmxremote.ssl=#{enable_jmxremote_ssl} \\
  #{debugOptions} \\
  #{dynaTrace_options if ( app == "playTimeService" || app == "fedRex" ) } \\
  -XX:+DisableExplicitGC \\
  #{"-XX:MaxMetaspaceSize=#{hiera("permgenspace")}m" if ( app == "playTimeService" or app == "fedRex" ) } \\
  -verbose:gc -XX:+PrintGCDateStamps -XX:+PrintGCDetails -Xloggc:$APP_HOME/logs/gc.log \\
  -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=$APP_HOME/logs/`date +%Y_%m_%d-%H_%M`.heapDump \\
  -XX:ErrorFile=$APP_HOME/logs/`date +%Y_%m_%d-%H_%M`.crashReport \\
  -DHOSTNAME=`hostname | perl -pe 's/\\..*//'` \\
  -cp $CP
"


 EXEC_COMMAND="java $JVM_OPTS $APP_MAIN ${RESOURCE_PATH}/#{propertyFile}"
 if [ ! -d "${APP_HOME}/logs" ]; then
   mkdir ${APP_HOME}/logs
 fi

 
/usr/bin/nohup $EXEC_COMMAND > ${APP_HOME}/logs/#{name}-default.log  2>&1 &

 TEMP_APP_PID=$!
 if [ -n "$APP_PID" ]; then
   echo $TEMP_APP_PID > $APP_PID
 fi
 # end
    startscript

###########################################################################################
   if exists?(:useLocalWorking) && useLocalWorking == true
     ##### Write out to local file, so RPM can get it
     my_initd_file = File.open("working/#{name}initd", 'w')
     my_initd_file.puts "#{initd_string}"
     my_initd_file.close

     my_start_file = File.open("working/#{name}-start.sh", 'w')
     my_start_file.puts "#{startscript_string}"
     my_start_file.close
     
     logger.info "UPLOADING init script 1"
     
   else
    ## if "#{name}" != "playTimeService"
       #### Upload and setup perms for init.d, ensure that it will startup w this host
       
       logger.info "UPLOADING init script 2"
      
       upload(StringIO.new(initd_string), "/tmp/#{app}initd", :via => :scp, :mode => 0700)
       logger.info "DEBUG: just uploaded init.d"
       run "sudo mv /tmp/#{app}initd /etc/init.d/#{app} && sudo chown root:root /etc/init.d/#{app}"
       if exists?(:do_not_start) && do_not_start == true
         run "if sudo /sbin/chkconfig --list #{app} ; then sudo /sbin/chkconfig --del #{app} ; echo \"removed #{app} from chkconfig\" ; fi"
       else
        run "sudo /sbin/chkconfig --add #{app}"
        run "sudo /sbin/chkconfig --level 3 #{app} on"

        logger.info "DEBUG: ran chkconfig commands"
       
       ## end #if exists?(:do_not_start) && do_not_start == true
       
       
       
   end
    # remove RPM supplied start script....(need sudo as rpm installs as UNU user)
    logger.info "DEBUG: removing start.sh from RPM"
    run "[ -f #{install_path}/bin/start.sh ] && sudo rm -rf #{install_path}/bin/start.sh ; exit 0"
    #### Upload and setup perms for start.sh
    logger.info "DEBUG: uploading new start.sh from cap"
    upload(StringIO.new(startscript_string),"/tmp/start.sh", :via => :scp, :mode => 0770)
    run "[ -f /tmp/start.sh ] && sudo mv /tmp/start.sh #{install_path}/bin/start.sh; exit 0"
    logger.info "DEBUG: just uploaded start.sh"
    logger.info "DEBUG: chown file to #{install_path} user"
    run "[ -f #{install_path}/bin/start.sh ] && sudo chown #{user} #{install_path}/bin/start.sh; exit 0"
    run "[ -f #{install_path}/bin/start.sh ] && sudo chmod 755 #{install_path}/bin/start.sh; exit 0"
    logger.info "DEBUG: removing startup.sh if it exists on filesystem"
    run "[ -f #{install_path}/bin/startup.sh ] && rm -rf #{install_path}/bin/startup.sh ; exit 0"
   end #if exists?(:useLocalWorking) && useLocalWorking == true

end #end task "setup_initd#{name}"


end # the do for each service!

#EOF

logger.info ">>>>> loaded udb_common_tasks"
