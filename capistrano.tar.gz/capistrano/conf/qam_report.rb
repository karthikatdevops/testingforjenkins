set :qam_interval, 4
def create_crond_hours (servers_size,server_index)
  cron_interval= servers_size*qam_interval
  cron_hours=""
  (server_index*1...24).step(cron_interval){|idex|
      if cron_hours.empty?
        cron_hours="#{idex}"
      else
         cron_hours="#{cron_hours},#{idex}"
      end    
  }
  return cron_hours
end

    #============
    # DEPLOY TASK
    #  - called from capistrano command-line
    #  - calls MAIN
    #============
    desc "used to deploy #{name}_#{env}"
    task "deploy_#{name}_#{env}".to_sym do
        logger.level = Capistrano::Logger::INFO
        logger.info "M1 TASK: deploy_#{name}_#{env}.to_sym do"
        eval("#{env}_#{name}")
        servers=find_servers(:roles => "#{name}".to_sym)
        logger.info "servers: #{servers.size}"
        idx=0  
        set :server_size, "#{servers.size}"
        set :cron_intervals, "#{qam_interval}"
        servers.each do |server|
            ENV['HOSTS'] = "#{server.host}"
            if exists?(:useREX) && useREX or exists?(:useRex) && useRex
              idx+=1
            elsif exists?(:useNP) && useNP
              idx+=2
            end             
            set :cron_hours, create_crond_hours(servers.size,idx)            
            
#            idx+=2
#            set :cron_hours_national_persona, create_crond_hours(servers.size,idx)
            find_and_execute_task ("#{name}_main_#{env}")           
        end
    end # desc "used to deploy #{name}_#{env}"

    #============
    # MAIN TASK
    #  - Calls COPY and START tasks.
    #============
    desc "called by #{env}_#{name} in #{env}.rb"
    task "#{name}_main_#{env}".to_sym do
        logger.level = Capistrano::Logger::INFO
        logger.info "DEBUG: TASK: #{name}_main_#{env}"
        
        set :use_rex,"" 
        if exists?(:useREX) && useREX or exists?(:useRex) && useRex                    
          set :use_rex,"--use_rex"      
        end 
         
        if exists?(:isQAMQa) && isQAMQa
          set :app_dir, "#{name}-QA"
        elsif exists?(:useNP) && useNP                  
          set :app_dir, "#{name}-NP"
        else 
          set :app_dir, "#{name}-REX"
        end
        set :app, "#{name}"
        set :install_path, "/opt/ds/#{app_dir}"
        puts "....Set install_path=#{install_path}"

        logger.info "START: this is #{app_dir}"
        logger.info "DEBUG: about to read_bom"
   
        if exists?(:noBom) or exists?(:nobom)
            #set :skipWriteServiceVersion, "true"
            logger.info "skipping read bom"
        else
            check_service_version
            read_bom
        end

        if exists?(:cleanServer) && cleanServer.to_s == "true"
            logger.info "cleaning #{install_path} since cleanServer is TRUE"
            run "[ -f /etc/cron.d/#{app_dir} ] && sudo rm /etc/cron.d/#{app_dir}; exit 0"
            run "[ -d #{install_path}/qam_parity_report ] && sudo rm -rf #{install_path}/qam_parity_report; exit 0"
        end
        find_and_execute_task("copy_#{name}_#{env}")   

    end # task "#{name}_main_#{env}".to_sym do

    #============
    # COPY TASK
    #  - calls UPDATECONFIG and INITD tasks
    #============
    desc "called by #{name}_main_#{env}"
    task "copy_#{name}_#{env}".to_sym do
        logger.info "M2 TASK: copy_#{name}_#{env}.to_sym do"
        run "[ -f /etc/cron.d/#{app_dir} ] && sudo rm /etc/cron.d/#{app_dir}; exit 0"
        run "if [[ ! -d /opt/ds ]]; then sudo mkdir /opt/ds; sudo chown #{user} /opt/ds; fi"
        run "if [[ ! -d #{install_path} ]]; then mkdir -p #{install_path}; fi"
        run "if [[ ! -d #{install_path}/reports ]]; then mkdir -p #{install_path}/reports; fi"
        run "if [[ ! -d #{install_path}/logs ]]; then mkdir -p #{install_path}/logs; fi"
        run "if [[ ! -d #{install_path}/version ]]; then mkdir -p #{install_path}/version; fi" 
        `if [ -d "working/#{app_dir}" ]; then rm -fr working/#{app_dir}; fi; mkdir -p working/#{app_dir};`
        if exists?(:noBom) or exists?(:nobom)
            # remove contents of tmpdir 
            run "rm -rf #{tmpdir}/#{app_dir}"
            run "mkdir -p #{tmpdir}/#{app_dir}"
            logger.info " attempting to wget #{url}"
            logger.info " using cmd: wget #{wget_params} --no-proxy #{url} -O- working/#{name}.tar.gz"
            #grab the zip file, unzip it, and mv it to a meaningful name      
            logger.info "using a local wget and scp up to the server, this will take a bit of time..."
            `wget #{wget_params} --no-proxy #{url} -O working/#{name}.tar.gz`
            upload("working/#{name}.tar.gz","#{install_path}/#{name}.tar.gz", :via => :scp)
            run "cd #{install_path} && tar xzf #{name}.tar.gz"  
            run "cd #{install_path}/qam_parity_report; ln -fs ../reports .; ln -fs ../logs ."  
            # WRITE SERVICE VERSION
            puts "I have no BOM-- guessing what version of service I have using regex"
            puts "My package is: #{url}"
            myNoBomVersion = url.gsub(/.tar.gz.*/, "")
            myNoBomVersion = myNoBomVersion.gsub(/.*\/qam-parity-report-/, "")
            puts "My guessed version is: #{myNoBomVersion}"
            run "echo \"#{myNoBomVersion} (noBom)\" > #{install_path}/version/version.txt"
            # POST HISTORY
            run "if [ -e #{basedir}/history/#{app_dir} ]; then echo 'dir #{basedir}/history/#{app_dir} exists'; else mkdir -p #{basedir}/history/#{app_dir} ; fi"
            logger.info "Making history in file: #{basedir}/history/#{app_dir}/deploy_history.txt"
            run "touch #{basedir}/history/#{app_dir}/deploy_history.txt"
            run "date +%F-%H%M%S >> #{basedir}/history/#{app_dir}/deploy_history.txt"
            run "echo \"Version: #{myNoBomVersion} (noBom)\" >> #{basedir}/history/#{app_dir}/deploy_history.txt"
        else
            get_remote_file("#{url}","#{install_path}","#{name}.tar.#{service_version}.gz")
            logger.info "unpacking tarball"
            run "cd #{install_path} && tar xzf #{name}.tar.#{service_version}.gz"
            run "cd #{install_path}/qam_parity_report; ln -fs ../reports .; ln -fs ../logs ."
            run "echo #{service_version} #{bom} > #{install_path}/version/version.txt"
            # POST HISTORY
            run "if [ -e #{basedir}/history/#{app_dir} ]; then echo 'dir #{basedir}/history/#{app_dir} exists'; else mkdir -p #{basedir}/history/#{app_dir} ; fi"
            logger.info "Making history in file: #{basedir}/history/#{app_dir}/deploy_history.txt"
            run "touch #{basedir}/history/#{app_dir}/deploy_history.txt"
            run "date +%F-%H%M%S >> #{basedir}/history/#{app_dir}/deploy_history.txt"
            run "echo \"Version: #{service_version} #{bom}\" >> #{basedir}/history/#{app_dir}/deploy_history.txt"
        end
        
        #Create Nagios alert file  
        nagios_alert_script = <<-NAGIOS_ALERT 
#!/usr/bin/env ruby
########################
# This script is to monitor the qam reports to make sure it creates the reports file successfully.
# script to run qam parity report nagios alert
########################
current_time=Time.now
cron_hour=#{cron_intervals}
qam_run_time=2
HOMEDIR="#{install_path}/qam_parity_report"
REPORTDIR="\#\{HOMEDIR\}/reports"
current_hour=current_time.hour     
mod_hour=current_hour % cron_hour
report_seconds=current_time-mod_hour*60*60
report_time=report_seconds.strftime("%Y-%m-%dT%H:00") 
REPORTFILENAME="\#{REPORTDIR}/qp_\#{report_time}.xls"
REPORT_TXT="\#{REPORTDIR}/qp_\#{report_time}.txt"
REPORT_HTML="\#{REPORTDIR}/qp_\#{report_time}.html" 

latest_report_time_str=`ls -tr1 \#{REPORTDIR} | tail -n 1 | cut -d '_' -f 2 | cut -d '.' -f 1`.chomp
if !latest_report_time_str.empty?
  latest_report_time=Time.parse(latest_report_time_str)
	if current_time-latest_report_time < cron_hour*60*60
	  if !(File.size?(REPORTFILENAME).nil?) && !(File.size?(REPORT_TXT).nil?) && !(File.size?(REPORT_HTML).nil?)  
  	  puts "OK:The last reports were created at \#{latest_report_time_str} and was younger than \#{cron_hour} hours."
  	  exit 0
	  else
	     puts "CRITICAL:Zero length QAM Parity Reports found- Reports ran but there is not sufficient data to create report files. Wait for next report run in #{qam_interval} hours."
    	 exit 2
  	 end   
  else       
    if File.file?(REPORTFILENAME) && File.file?(REPORT_TXT) && File.file?(REPORT_HTML) 
      if !(File.size?(REPORTFILENAME).nil?) && !(File.size?(REPORT_TXT).nil?) && !(File.size?(REPORT_HTML).nil?)  
    	  puts "OK:REPORTS ARE READY"
    	  exit 0
  	  else
  	     puts "CRITICAL:Zero length QAM Parity Reports found- Reports ran but there is not sufficient data to create report files. Wait for next report run in #{qam_interval} hours."
      	 exit 2
    	 end
    elsif mod_hour < qam_run_time 
      ps=`ps -aef | grep qam_parity_report  | grep -v grep`.chomp
      if ps.empty?
        puts "CRITICAL:The qam_parity_report process did not start correctly. Checking #{install_path}/qam_parity_report/qam_parity_report_runner_cron.log and #{install_path}/qam_parity_report/qam_parity_report.log for details."
        exit 2
      else      	
    	  puts "OK:The qam parity report process is started but reports are not ready yet. Checking back 30 minutes later.";
    	  exit 0
      end
    else
      puts "CRITICAL:The last reports were created at \#{latest_report_time_str} and older than \#{qam_run_time} hours.";
  	  exit 2;
    end
  end
else  
   ps=`ps -aef | grep qam_parity_report  | grep -v grep`.chomp
   if ! ps.empty?
      puts "OK:The qam parity report process is started but reports are not ready yet. Checking back 30 minutes later.";
  	  exit 0
   else 
       puts "CRITICAL:There are no any report files in \#{REPORTDIR}. Please wait for \#{cron_hour} hours if the cron just started or check #{install_path}/qam_parity_report/qam_parity_report_runner_cron.log and #{install_path}/qam_parity_report/qam_parity_report.log for details if cron has started for more than \#{cron_hour} hours."
       exit 2     		  
   end
end       
        NAGIOS_ALERT
        File.open("working/#{app_dir}/qam_parity_report_nagios_alert.rb",'w+'){|f| f.puts nagios_alert_script;} 
        upload("working/#{app_dir}/qam_parity_report_nagios_alert.rb","#{install_path}/qam_parity_report/", :via => :scp)  
        run "cd #{install_path}/qam_parity_report/; chmod 755 qam_parity_report_nagios_alert.rb"     
        if exists?(:isQAMQa) && isQAMQa
          run "#{install_path}/qam_parity_report/qam_parity_report_runner.sh compass-vod-reports-qa@lists.chalybs.net '11596 5104 5569 6158 10276 6676 10114 9907 6617 9144 11562 8771 7992 7332' #{use_rex}> #{install_path}/qam_parity_report/logs/qam_parity_report_runner_cron.log 2>&1 &"
        else
          find_and_execute_task("crond_#{name}")
        end
        logger.info "TASK: END"
    end # end copy_#{name}_#{env}"

    #============
    # CROND TASK
    #============
    desc  "called by copy_#{name}_#{env} to write init and wrapper" 
    task "crond_#{name}".to_sym do

        logger.info "M3 TASK: crond_#{name}"
        
        if exists?(:useREX) && useREX or  exists?(:useRex) && useRex
          runner_string = <<-runnerfile
#!/bin/sh
#{install_path}/qam_parity_report/qam_parity_report_runner.sh compass-vod-reports-rex@lists.chalybs.net '11596 5104 5569 6158 10276 6676 10114 9907 6617 9144 11562 8771 7992 7332' --use_rex > #{install_path}/qam_parity_report/logs/qam_parity_report_runner_cron.log 2>&1
          runnerfile

        elsif exists?(:useNP) && useNP
          runner_string = <<-runnerfile
#!/bin/sh
#{install_path}/qam_parity_report/qam_parity_report_runner.sh compass-vod-reports-np@lists.chalybs.net '1' --use_rex > #{install_path}/qam_parity_report/logs/qam_parity_report_runner_cron.log 2>&1
          runnerfile

        else
          runner_string = <<-runnerfile
#!/bin/sh
#{install_path}/qam_parity_report/qam_parity_report_runner.sh '11596 5104 5569 6158 10276 6676 10114 9907 6617 9144 11562 8771 7992 7332' > #{install_path}/qam_parity_report/logs/qam_parity_report_runner_cron.log 2>&1
##{install_path}/qam_parity_report/qam_parity_report_runner.sh compass-vod-reports-np@lists.chalybs.net '1' > #{install_path}/qam_parity_report/logs/qam_parity_report_runner_cron.log 2>&1
          runnerfile
        end 

        run "if [[ ! -d /var/lock/qamParityReport ]]; then sudo mkdir /var/lock/qamParityReport; sudo chown #{user} /var/lock/qamParityReport; fi"

        crond_string = <<-crondfile
0 #{cron_hours} * * * #{user} if [[ ! -f /var/lock/qamParityReport/#{app_dir}_lock ]]; then touch /var/lock/qamParityReport/#{app_dir}_lock; /opt/ds/runners/#{app_dir}.sh; rm /var/lock/qamParityReport/#{app_dir}_lock; fi
        crondfile

        logger.info "Crond line: #{crond_string}"
        File.open("working/#{app_dir}/#{app_dir}.cron",'w+'){|f| f.puts crond_string;}     
        upload("working/#{app_dir}/#{app_dir}.cron","#{install_path}/crond", :via => :scp)
        run "sudo mv #{install_path}/crond /etc/cron.d/#{app_dir} && sudo chmod 644 /etc/cron.d/#{app_dir} && sudo chown root:root /etc/cron.d/#{app_dir}" 

        logger.info "Cron runner line: #{runner_string}"
        File.open("working/#{app_dir}/#{app_dir}.sh",'w+'){|f| f.puts runner_string;}
        upload("working/#{app_dir}/#{app_dir}.sh","#{install_path}/runner", :via => :scp)
        run "sudo mv #{install_path}/runner /opt/ds/runners/#{app_dir}.sh && sudo chmod 775 /opt/ds/runners/#{app_dir}.sh && sudo chown #{user}:#{user} /opt/ds/runners/#{app_dir}.sh"
        logger.info "DEBUG: completed cron.d and runner scripts"
    end #end task "crond_#{name}" 

logger.info ">>>>> loaded qam_report"