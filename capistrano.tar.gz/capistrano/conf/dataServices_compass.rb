# this file contains common tasks that span all environments and all Compass DS apps.
DataServicesUsingMigrations = [
  'commerceDataService',
  'entityDataService',
  'entityIngest',
  'idDataService',
  'idDataServiceGracenote',
  'imageDataService',
  'imageIngest',
  'imageIngestWebService',
  'ingestStagingWebService',
  'jobDataService',
  'linearDataService',
  'linearIngest',
  'locationDataService',
  'locationIngest',
  'menuDataService',
  'offerDataService',
  'offerIngest',
  'toolPreferenceDataService',
]


    # Called by "cap dependencies_jobDataService" or a general deploy task
    desc "called by serviceSpecificConfigUpdates_#{svc}"
    task "serviceSpecificConfigUpdates_#{svc}".to_sym do
        logger.level = Capistrano::Logger::INFO
        logger.info "Checking configs for #{svc}"

       ########################################
       # ENTITY DATA SERVICE SUBSTITUTIONS
       ########################################
       if app == "entityDataService"
         set :cache_L1_maximum_size, xmx*1000000/14
         set :cache_L2_maximum_size_total, xmx*1000000/2.5
         $entityDataService_config_overrides = {
           "cache.L1.maximum.size"                                                                           => "#{cache_L1_maximum_size.to_int}",
           "cache.L2.maximum.size.total"                                                                     => "#{cache_L2_maximum_size_total.to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentProgram"                => "#{(cache_L2_maximum_size_total/5).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentEntityTagAssociation"   => "#{(cache_L2_maximum_size_total/150).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentTag"                    => "#{(cache_L2_maximum_size_total/150).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.image.impl.data.PersistentMainImageFile"           => "#{(cache_L2_maximum_size_total/150).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.image.impl.data.PersistentMainImageType"           => "#{(cache_L2_maximum_size_total/150).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentProgramTeamAssociation" => "#{(cache_L2_maximum_size_total/150).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentCredit"                 => "#{(cache_L2_maximum_size_total/10).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentPerson"                 => "#{(cache_L2_maximum_size_total/12).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentReview"                 => "#{(cache_L2_maximum_size_total/9).to_int}",
           "cache.L2.maximum.size"                                                                           => "#{(cache_L2_maximum_size_total/150 ).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentAlbumRelease.contentRatings"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentEntityCollection.entityIds"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentEntityCollection.primaryEntities"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentPerson.aliases"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentPerson.knownFor"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentSong"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentRelatedProgram"  => "#{(cache_L2_maximum_size_total/150 ).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentProgram.contentRatings"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentProgramMediaAssociation"  => "#{(cache_L2_maximum_size_total/150 ).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentProgramMediaAssociation.categoryPaths"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentProgramMediaAssociation.companies"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentRatingsMapping"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentRatingsMapping.ratingsMap"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentSongCollection.songIds"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentVideogame.contentRatings"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.image.impl.data.PersistentImageAssociation.preferForMainImageTypeIds"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.image.impl.data.PersistentMainImageTypeGroup"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.image.impl.data.PersistentMainImageType.defaultImageCriteria"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.image.impl.data.PersistentMainImageType.imageCriteria"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.image.impl.data.PersistentMainImageType.mainImageTypeGroupIds"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentProgramRank"  => "#{(cache_L2_maximum_size_total/150 ).to_int}",
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentAward"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentAwardAssociation"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentVideogame"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentProgramSportsEvent"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentInstitution"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentRelatedAlbum"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentRelatedSong"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentSongCollection"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentEntityMessage"  => 1,
           "cache.L2.maximum.size.com.theplatform.data.tv.entity.impl.data.PersistentEntityCollection" => 1

         }

       end # app == "entityDataService"

        ########################################
        # LINEAR DATA SERVICE SUBSTITUTIONS
        ########################################
        if app == "linearDataService"

          $linearDataService_config_overrides = {
              "cache.L1.maximum.size"                                                                            => "#{(xmx*1000000/10).to_int}",
              "cache.L2.maximum.size.total"                                                                      => "#{(xmx*1000000*3/5).to_int}",
              "cache.channel.L1.maximum.size"								                                                    => "#{(xmx*1000000/20).to_int}",
              "cache.listing.L1.maximum.size" 						                                        		            => "#{(xmx*1000000/40).to_int}",
              "cache.L2.maximum.size.com.theplatform.data.tv.linear.impl.data.PersistentChannel"                 => "#{(xmx*1000000/10).to_int}",
              "cache.L2.maximum.size.com.theplatform.data.tv.linear.impl.data.PersistentStation"                 => "#{(xmx*1000000/54).to_int}",
              "cache.L2.maximum.size.com.theplatform.data.tv.image.impl.data.PersistentMainImageFile"            => "#{(xmx*1000000/54).to_int}",
              "cache.L2.maximum.size.com.theplatform.data.tv.linear.impl.data.PersistentListing"		              => "#{(xmx*1000000/15).to_int}",
              "cache.L2.maximum.size.com.theplatform.data.tv.linear.impl.data.PersistentLocation"                => "#{(xmx*1000000/50).to_int}",
              "cache.L2.maximum.size"                                                                            => "#{(xmx*1000000/100).to_int}",
              "linearDataService.listing.programCacheSize"                                                       => "#{(xmx*10).to_int}",
              "cache.L2.maximum.size.com.theplatform.data.tv.linear.impl.data.PersistentLocalizedPackage"        => "#{(xmx*1000000/50).to_int}"
          }
        end # app == "linearDataService"

         # all these settings are now in hiera and achieved through the subsiquent merge w/ the global config overrides hash
         $entityIngest_config_overrides = {}
         $idDataService_config_overrides = {}
         $idDataServiceGracenote_config_overrides = {}
         $toolPreferenceDataService_config_overrides = {}
         $imageDataService_config_overrides = {}
         $imageIngest_config_overrides = {}
         $imageIngestWebService_config_overrides = {}
         $ingestStagingWebService_config_overrides = {}
         $jobDataService_config_overrides = {}
	       $monsterEntityDataService_config_overrides = {}
         $linearIngest_config_overrides = {}
         $locationDataService_config_overrides = {}
         $locationIngest_config_overrides = {}
         $menuDataService_config_overrides = {}
         $userPreferenceDataService_config_overrides = {}
         $commerceDataService_config_overrides = {}
         $offerDataService_config_overrides = {}
         $offerIngest_config_overrides = {}
         $programAvailability2_config_overrides = {}
         $sportsDataService_config_overrides = {}
         $subscriberDataService_config_overrides = {}


    end # task "serviceSpecificConfigUpdates_#{svc}".to_sym do

    desc "called by deploy_#{svc}_#{env}"
    task "#{svc}_main_#{env}".to_sym do
    logger.level = Capistrano::Logger::INFO
    
    set :app, "#{svc}"
    logger.info ">>>>>>>>>>>>>>>>  Beginning the MAIN Deploy task for :  name=#{svc} inside dataServices_compass.rb <<<<<<<<<<<<<<<<<<<<<<<"

    if exists?(:noBom) or exists?(:nobom)
      #set :skipWriteServiceVersion, "true"
      logger.info "skipping read bom"
    else
      check_service_version
      read_bom
    end

       logger.info "VARIABLES SET FOR THIS RUN: env=#{env} -  name=#{svc}  -  app=#{app} ________________________________________"
       set :web_port, hiera("#{svc}_web_port")
       set :jmx_port, hiera("#{svc}_jmx_port")
       set :stop_port, hiera("#{svc}_stop_port")
       set :alive_path, hiera("#{svc}_alive") || "#{app}/management/alive"

       # backup properties file?
       if hiera("backup_properties_file")
         run "cp #{basedir}/jetty-#{app}/config/DS_Configuration.properties #{tmpdir}/#{svc}_DS_Configuration.properties || true"
       end

       if exists?(:cleanServer) && cleanServer.to_s == "true"
         logger.info "clean installing #{app}"
         stop_jetty
         backup_dir("#{app}", hiera("persistent_directory"))
         removeApp
         check
       else
         check
         stop_jetty
       end

       if jetty_version.match(/^9/)
         find_and_execute_task("jettyrealm#{app}")
       end
       find_and_execute_task("jettywrapper#{app}")
       find_and_execute_task("initd#{app}")
       find_and_execute_task("copy_#{svc}_#{env}")
       find_and_execute_task("prepare_#{svc}_#{env}")
       if exists?(:dbWipe) && dbWipe.to_s == "true"
         find_and_execute_task("migrate_down_#{svc}_#{env}")
       end
       find_and_execute_task("prepare_migrations_#{svc}_#{env}")
       find_and_execute_task("migrate_bootstrap_#{svc}_#{env}")
       find_and_execute_task("migrate_up_#{svc}_#{env}")
       if exists?(:do_not_start) && do_not_start == true
         logger.info "not starting b/c :do_not_start == true"
       else
         # op5 api - enable monitoring if one host is specified
#         op5_api_client.create_services(name, ENV['HOSTS'].split(',')) if (ENV['HOSTS'] && use_op5_api?)
         start_jetty

         # Alive Checks
         # Changing this to skip alive checks in GBENV for CI set value in cap to skip alives
         # alive
          if exists?(:skip_alive)
            logger.info ">>>>>>>>>>>>>>>>>>>>>>>>**** skip_alive set, skipping alive checks"
          else
            logger.info "Running alive check.."
          end

          # this is the actual call to alive, above is just some logging
          alive unless exists? :skip_alive

         if ds_read_only
           puts "skipping json_post since this service is in read_only mode"
         else
          if post_seeds && seed_post_present? && ! exists?(:json_posted)
            logger.info ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> posting seeds to this DS"
            json_post
            # flag so we only post json once (assume deploying one host at a time)
            set :json_posted, true
          end
         end
         get_ver
       end
     end

     task "updateConfigAndRestart_#{svc}".to_sym do
       logger.level = Capistrano::Logger::INFO

#          find_and_execute_task("hosts_file_override_#{svc}") if exists?(:hosts_file_overrides)
       find_and_execute_task("#{env}_#{svc}")
       run_serially_in_batches(:find_server_opts => {:roles => "#{svc}".to_sym}) do |server_options|
         
         set :app, "#{svc}"
         set :web_port, hiera("#{svc}_web_port")
         set :jmx_port, hiera("#{svc}_jmx_port")
         set :stop_port, hiera("#{svc}_stop_port")
         set :alive_path, hiera("#{svc}_alive") || "#{app}/management/alive"
         stop_jetty
         if jetty_version.match(/^9/)
           find_and_execute_task("jettyrealm#{svc}")
         end
         find_and_execute_task("jettywrapper#{svc}")
         find_and_execute_task("initd#{svc}")
         find_and_execute_task("prepare_#{svc}_#{env}")

         if exists?(:do_not_start) && do_not_start == true
           logger.info "not starting b/c :do_not_start == true"
         else
           start_jetty
           alive
           get_ver
         end
       end
       roles.clear
     end

     task "updateLoggingConfigAndRestart_#{svc}".to_sym do
       find_and_execute_task("#{env}_#{svc}")
       logger.level = Capistrano::Logger::INFO
       run_serially_in_batches(:find_server_opts => {:roles => "#{svc}".to_sym}).each do |server_options|
         
         set :app, "#{svc}"
         if jetty_version.match(/^8/) || jetty_version.match(/^9/)
             createLogback_jetty8
         else
             createLogback
         end
       end
     end

    desc "it puts the json in the service or it gets the hose again"
    task :json_post do
      logger.info ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    Checking for local json, i'll post it if its there"

      logger.info ">>>>>>>> ---------------------------------------- my mpx_access_url is: #{mpx_access_url}"
      logger.info ">>>>>>>> ---------------------------------------- my mpx_account_base_url is: #{mpx_account_base_url}"
      logger.info ">>>>>>>> ---------------------------------------- my dsMerlinVip is:         #{dsMerlinVip}"
      logger.info ">>>>>>>> ---------------------------------------- my seed post source:       #{tmpdir}/#{app}/db/seed_posts"

      logger.info "JSON seed: sub 1 for CHANGEME"
       # run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's/CHANGEME/http:\\/\\/#{dsMerlinVip}:#{web_port}\\/#{app}/' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "

      run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then sed -i 's/CHANGEME/http:\\/\\/#{dsMerlinVip}:#{web_port}\\/#{app}/g' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "

      logger.info "JSON seed: sub 2 for ACCESS_URL"
      run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's#ACCESS_URL##{mpx_account_base_url}#' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "

      logger.info "JSON seed: sub 3 for OWNER_ID"
      if exists?(:combine_commons_default_ownerid)
        # The ownerID is what's after the slash in combine_commons_default_ownerid
        myOwnerID = combine_commons_default_ownerid.gsub(/.*\//, "")
        logger.info "-- combine_commons_default_ownerid is: #{combine_commons_default_ownerid}"
        logger.info "-- ownerID is: #{myOwnerID}"
        run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's/OWNER_ID/#{myOwnerID}/' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "
      end # exists?(:combine_commons_default_ownerid)
   
       logger.info "JSON seed: sub 4 for ASP_MPX_IDENTITY_URL"
       if exists?(:asp_mpx_identity_url)
         # The ownerID is what's after the slash in ASP_MPX_IDENTITY_URL
         ASP_MPX_IDENTITY_URL = asp_mpx_identity_url.gsub("/", "\\/")
         logger.info "-- asp_mpx_identity_url is: #{asp_mpx_identity_url}"
         logger.info "-- AspMpxIdentity Url is: #{ASP_MPX_IDENTITY_URL}"
         run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's/ASP_MPX_IDENTITY_URL/#{ASP_MPX_IDENTITY_URL}/' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "
       end # exists?(:asp_mpx_identity_url)

      logger.info "JSON seed: sub 5 for MPX_IDENTITY_URL"
      if exists?(:mpx_identity_url)
        # The ownerID is what's after the slash in mpx_identity_url
        myMpxIdentityUrl = mpx_identity_url.gsub("/", "\\/")
        logger.info "-- mpx_identity_url is: #{mpx_identity_url}"
        logger.info "-- MpxIdentity Url is: #{myMpxIdentityUrl}"
        run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's/MPX_IDENTITY_URL/#{myMpxIdentityUrl}/' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "
      end # exists?(:mpx_identity_url)

      logger.info "JSON seed: sub 6 for VODMT_MEDIA_ACCOUNT_URL"
      if exists?(:vodmt_media_account_url)
        # The ownerID is what's after the slash in VODMT_MEDIA_ACCOUNT_URL
        VODMT_MEDIA_ACCOUNT_URL = vodmt_media_account_url.gsub("/", "\\/")
        logger.info "-- vodmt_media_account_url is: #{vodmt_media_account_url}"
        logger.info "-- VODMT_MEDIA_ACCOUNT_URL Url is: #{VODMT_MEDIA_ACCOUNT_URL}"
        run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's/VODMT_MEDIA_ACCOUNT_URL/#{VODMT_MEDIA_ACCOUNT_URL}/' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "
      end # exists?(:vodmt_media_account_url)

	logger.info "JSON seed: sub 7 for FSS_MEDIA_ACCOUNT_URL"
      if exists?(:fss_media_account_url)
        # The ownerID is what's after the slash in FSS_MEDIA_ACCOUNT_URL
        FSS_MEDIA_ACCOUNT_URL = fss_media_account_url.gsub("/", "\\/")
        logger.info "-- fss_media_account_url is: #{fss_media_account_url}"
        logger.info "-- FSS_MEDIA_ACCOUNT_URL Url is: #{FSS_MEDIA_ACCOUNT_URL}"
        run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's/FSS_MEDIA_ACCOUNT_URL/#{FSS_MEDIA_ACCOUNT_URL}/' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "
      end # exists?(:fss_media_account_url)
	
	logger.info "JSON seed: sub 8 for VOD_MEDIA_ACCOUNT_URL"
      if exists?(:vod_media_account_url)
        # The ownerID is what's after the slash in VOD_MEDIA_ACCOUNT_URL
        VOD_MEDIA_ACCOUNT_URL = vod_media_account_url.gsub("/", "\\/")
        logger.info "-- vod_media_account_url is: #{vod_media_account_url}"
        logger.info "-- VOD_MEDIA_ACCOUNT_URL Url is: #{VOD_MEDIA_ACCOUNT_URL}"
        run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's/VOD_MEDIA_ACCOUNT_URL/#{VOD_MEDIA_ACCOUNT_URL}/' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "
      end # exists?(:vod_media_account_url)

	logger.info "JSON seed: sub 9 for IMAGE_MEDIA_ACCOUNT_URL"
      if exists?(:image_media_account_url)
        # The ownerID is what's after the slash in IMAGE_MEDIA_ACCOUNT_URL
        IMAGE_MEDIA_ACCOUNT_URL = image_media_account_url.gsub("/", "\\/")
        logger.info "-- image_media_account_url is: #{image_media_account_url}"
        logger.info "-- IMAGE_MEDIA_ACCOUNT_URL Url is: #{IMAGE_MEDIA_ACCOUNT_URL}"
        run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's/IMAGE_MEDIA_ACCOUNT_URL/#{IMAGE_MEDIA_ACCOUNT_URL}/' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "
      end # exists?(:image_media_account_url)

	logger.info "JSON seed: sub 10 for ASP_MEDIA_URL"
       if exists?(:asp_media_url)
	 # The ownerID is what's after the slash in ASP_MEDIA_URL
	 ASP_MEDIA_URL = asp_media_url.gsub("/", "\\/")
	 logger.info "-- asp_media_url is: #{asp_media_url}"
	 logger.info "-- AspMedia Url is: #{ASP_MEDIA_URL}"
	 run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then perl -pi -e 's/ASP_MEDIA_URL/#{ASP_MEDIA_URL}/' #{basedir}/tmp/#{app}/db/seed_posts/* ; else echo 'WARNING: no seed posts found' ; fi ; "
       end # exists?(:asp_mpx_identity_url)


      logger.info "JSON post: posting corrected seed posts"
      begin
        # if we're an environment where alive.check.force.up == true, then the db may not yet be initialized, so sleep 30 seconds
        if env.include?("Gbenv") || env.include?("merdevl") ||  env.include?("cmpstkMerlin")
          logger.info ">>>>>>>> ------------------------------- popped in here for a 10 second nap"
          sleep 10
        end
        # wait for vip to come up
        sleep 30

# there is cruft shoved in here to try and stop the curl from using the proxy on our centos6 system for GBENV, seems to work on other systems... but this is not ideal.

        run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then for f in `cd #{basedir}/tmp/#{app}/db/seed_posts/ ; ls -1` ; do  url=`echo $f | perl -pe 's#-Field#/Field#;s#(.+)_(.+)_(.+)_(.+)#http://#{dsMerlinVip}:#{web_port}/#{app}/data/${2}/feed?schema=${3}&form=${4}&token=#{getToken}&httpError=true#'` ; echo \" script: $f --- calling curl -> \" ; echo $url ; curl -x '' -s -S -H 'Content-Type: application/json; charset=utf-8' --data-ascii @#{basedir}/tmp/#{app}/db/seed_posts/$f $url -H \"Host: #{dsMerlinVip}:#{web_port}\" ; curl_exit=$?; echo 'curl_exit='$curl_exit ; echo Just posted $f ; if [ $curl_exit -gt 0 ] ; then exit 1 ; fi ; done ;  else echo 'WARNING: no seed posts found' ; fi ; "
      rescue
        puts "json post failed: re-running with verbose output"
        run "if [ -e #{tmpdir}/#{app}/db/seed_posts ]; then for f in `cd #{basedir}/tmp/#{app}/db/seed_posts/ ; ls -1` ; do  url=`echo $f | perl -pe 's#-Field#/Field#;s#(.+)_(.+)_(.+)_(.+)#http://#{dsMerlinVip}:#{web_port}/#{app}/data/${2}/feed?schema=${3}&form=${4}&token=#{getToken}&httpError=true#'` ; echo \" script: $f --- calling curl -> \" ; echo $url ; curl -x '' -s -S -H 'Content-Type: application/json; charset=utf-8' --data-ascii @#{basedir}/tmp/#{app}/db/seed_posts/$f $url -H \"Host: #{dsMerlinVip}:#{web_port}\" -v ; curl_exit=$?; echo 'curl_exit='$curl_exit ; echo Just posted $f ; if [ $curl_exit -gt 0 ] ; then exit 1 ; fi ; done ;  else echo 'WARNING: no seed posts found' ; fi ; "
        exit 1
      end
    end

    desc "called by install_jetty"
    task "install_jetty_#{svc}".to_sym do
        logger.info "TASK: Entered install_jetty_#{svc} in dataServices_compass.rb"

        jetty_install("#{svc}", "#{jetty_version}")
        restore_dir("#{svc}", hiera("persistent_directory"))
    end

    desc "used to deploy #{svc}"
       task "deploy_#{svc}_#{env}".to_sym do
         logger.info "TASK:-------------DEPLOY______________________________________________________"
         logger.info "TASK: Entered deploy_#{svc}_#{env} in dataServices_compass.rb"
         find_and_execute_task("hosts_file_override_#{svc}") if exists?(:hosts_file_overrides)

         eval("#{env}_#{svc}")
         run_serially_in_batches(:find_server_opts => {:roles => "#{svc}".to_sym}) do |server_options|
           find_and_execute_task ("#{svc}_main_#{env}")
         end
         logger.info "TASK: FINISHED---- deploy_#{svc}_#{env} in dataServices_compass.rb"
       end


    desc "called by #{svc}_main_#{env}"
    task "copy_#{svc}_#{env}".to_sym do
        logger.info "TASK: Entered copy_#{svc}_#{env} in dataServices_compass.rb"

        if variables[:localUrl]
           # If we're using a local file, there is nothing to wget
           logger.info "BEGIN: install service inside dataServices_compass.rb"
           logger.info " using a localUrl: #{localUrl}"
           # remove contents of tmpdir
           run "rm -rf #{tmpdir}/#{svc}"
           run "mkdir -p #{tmpdir}/#{svc}"
           logger.info " Upload the tarball to the server"
           upload("#{localUrl}","#{tmpdir}/#{svc}.tar.gz", :via => :scp)
           logger.info " Unpack the tarball on the server"
           run "cd #{tmpdir}/#{svc} && tar -zxf ../#{svc}.tar.gz"
           logger.info " Clean up by removing the tarball from the server"
           run "rm -rf #{tmpdir}/#{svc}.tar.gz"
        else
           # Without a localUrl, we will do a wget
           set(:url) do
               Capistrano::CLI.ui.ask "Enter URL to tar.gz file:"
           end unless variables[:url]
           # remove contents of tmpdir
           run "rm -rf #{tmpdir}/#{svc}"
           run "mkdir -p #{tmpdir}/#{svc}"
           logger.info "BEGIN: install service inside dataServices_compass.rb"
           logger.info " attempting to wget #{url}"
           logger.info " using cmd: wget #{wget_params} \"#{url}\" -O- | tar -zxpf -"
           # grab the zip file, unzip it, and mv it to a meaningful name
           # web_params is in global.rb line ~206
           begin
               run "cd #{tmpdir}/#{svc} && . ~/.bash_profile ; wget #{wget_params} \"#{url}\" -O- | tar -zxpf -"
           rescue
               logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
               `wget #{wget_params} \"#{url}\" -O working/#{svc}.tar.gz`
               upload("working/#{svc}.tar.gz","#{tmpdir}/#{svc}.tar.gz", :via => :scp)
               run "cd #{tmpdir}/#{svc} && tar -zxf ../#{svc}.tar.gz"
               logger.info " Clean up by removing the tarball from the server"
               run "rm -rf #{tmpdir}/#{svc}.tar.gz"
           end
       end # if variables[:localUrl]

       # if you're setting "noBom", then don't go through the bom related tasks
       if exists?(:noBom) or exists?(:nobom)
            #set :skipWriteServiceVersion, "true"
            logger.info "skipping write_service_version"
            puts "I have no BOM-- guessing what version of service I have using regex"
            if variables[:localUrl]
                puts "My package is :#{localUrl}... so, I can't really guess my version from this"
                puts " since the package name could be anything.  Just putting 'localUrl' as the version string"
                run "echo #{localUrl} > #{basedir}/jetty-#{app}/version.txt"
            else
                puts "My package is :#{url}"
                myNoBomVersion = url.gsub(/-package.tar.gz.*/, "")
                myNoBomVersion = myNoBomVersion.gsub(/.*\//, "")
                puts "#{myNoBomVersion}"
                run "echo #{myNoBomVersion} > #{basedir}/jetty-#{app}/version.txt"
            end
        else
            write_service_version
        end

        run "mv #{tmpdir}/#{svc}/capistrano/* #{tmpdir}/#{svc}"
        # clean out the working directory
        run "rm -rf #{basedir}/jetty-#{app}/work/*"
        # cp the war and logback.xml into place
        run "cp #{tmpdir}/#{svc}/war/*.war #{basedir}/jetty-#{app}/webapps/#{context_path}.war"
        # cp the DB migrations into place if available
        run "if [ -e #{tmpdir}/#{svc}/migrations ]; then cp -R #{tmpdir}/#{svc}/migrations #{basedir}/jetty-#{app} ; fi"
        # begin cramming jars in the war file
#        if splunkLogging == true
        if splunkLogging 
            run "cd #{basedir}/jetty-#{app}/webapps && unzip #{context_path}.war -d temp"
            run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && wget #{wget_params}  #{repo}/splunkJavaLogging/0.3.0/splunk.jar" unless app.include?("triageWebService") || app.include?("ingestStagingWebService")
            run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && wget #{wget_params}  #{repo}/splunkJavaLogging/0.3.0/splunklogging.jar"
            run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && wget #{wget_params}  #{repo}/splunkJavaLogging/0.3.0/splunk-sdk.jar"
            unless jetty_version.match(/^8/) || jetty_version.match(/^9/)
              run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && rm -f logback-classic-0.9.24.jar && wget #{wget_params} #{repo}/logback/#{logback_version}/logback-classic-#{logback_version}.jar -O logback-classic-0.9.24.jar"
              run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && rm -f logback-core-0.9.24.jar && wget #{wget_params} #{repo}/logback/#{logback_version}/logback-core-#{logback_version}.jar -O logback-core-0.9.24.jar"
              run "cd #{basedir}/jetty-#{app}/webapps/temp/WEB-INF/lib && rm -f pl-management-trace-1.1.0.jar && wget #{wget_params} #{repo}/logback/pl-management-trace-1.1.3.jar -O pl-management-trace-1.1.0.jar"
            end
              run "cd #{basedir}/jetty-#{app}/webapps/temp && zip -r #{context_path} *"
              run "cd #{basedir}/jetty-#{app}/webapps && mv temp/#{context_path}.zip ./#{context_path}.war && rm -rf ./temp"
        end

        # cp ROOT dir into place if available
        run "if [ -e #{tmpdir}/#{svc}/ROOT ]; then cp -rp #{tmpdir}/#{svc}/ROOT #{basedir}/jetty-#{app}/webapps/ ; fi"

        #upload the ssh private key to access the gracenote sftp server
        if svc == "ingestStagingWebService"
          upload(StringIO.new(hiera('comcast_gracenote_private_key')),"#{basedir}/jetty-#{svc}/key", :via => :scp, :mode => 0400)
        end

        logger.info "Using test.properties as a base"

        run "if [ -e #{tmpdir}/#{svc}/config/test.properties ]; then cp #{tmpdir}/#{svc}/config/test.properties #{basedir}/jetty-#{app}/config/DS_Configuration.properties ; fi"
        run "if [ ! -e #{tmpdir}/#{svc}/config/test.properties ]; then ls -1 #{tmpdir}/#{svc}/config/* | grep -i test_config | xargs -i cp {} #{basedir}/jetty-#{app}/config/DS_Configuration.xml ; fi"

        logger.info "TASK: FINISHED---- copy_#{svc}_#{env} in dataServices_compass.rb"
    end # task "copy_#{svc}_#{env}".to_sym do


   desc "called by #{svc}_main_#{env}"
   task "prepare_#{svc}_#{env}".to_sym do
     logger.info "TASK: Entered prepare_#{svc}_#{env} file manipulations in dataServices_compass.rb"

     logger.info "About to start logback deployment for jetty version #{jetty_version}"
     if jetty_version.match(/^8/) || jetty_version.match(/^9/)
         createLogback_jetty8
     else
         createLogback
     end
     logger.info "Finished logback deployment"

# OK, dump some interesting variables so we can see in the log files what went down

    logger.info "__________________________________________________ Setting VIPs set for This Deployment......"
    if exists?(:dsMerlinVip)
      logger.info "___________ dsMerlinVip         : #{dsMerlinVip}"
    end
    if exists?(:dsMerlinIngestVip)
      logger.info "___________ dsMerlinIngestVip   : #{dsMerlinIngestVip}"
    end
    if exists?(:logback_level_info)
      logger.info "___________ logback_level_info  : #{logback_level_info}"
    end
    if exists?(:logback_level_error)
      logger.info "___________ logback_level_error : #{logback_level_error}"
    end
    if exists?(:logback_level_warn)
      logger.info "___________ logback_level_warn  : #{logback_level_warn}"
    end
    if exists?(:logback_level_debug)
      logger.info "___________ logback_level_debug : #{logback_level_debug}"
    end
    if exists?(:logback_root_level)
      logger.info "___________ logback_root_level : #{logback_root_level}"
    end

     #########################
     # GENERAL SUBSTITUTIONS
     #########################

       # Make trace Log directories
       run "mkdir -p #{basedir}/jetty-#{svc}/logs/trace"
       run "chmod 775 #{basedir}/jetty-#{svc}/logs/trace"

       ########################################
       # GENERIC DATA SERVICE SUBSTITITIONS
       ########################################

       global_config_overrides = hiera('ds_properties', :hash)
       global_config_overrides["service.allowedHostNames"] =  "#{ENV['HOSTS']}," + global_config_overrides["service.allowedHostNames"]

       if hiera('ds_read_only')
         global_config_overrides["cluster.enabled"] = "false"
       else
         global_config_overrides["cluster.enabled"] = "true"
         global_config_overrides["cluster.multicast.address"] = generate_cluster_address('ds', hiera('cluster_name'))
       end

       find_and_execute_task("serviceSpecificConfigUpdates_#{svc}")

       #####################
       # SUBSTITUTION MAGIC
       #####################
       # Start with a blank regex string
       regex=""
       regex_commented=""

       begin
         eval("global_config_overrides.merge($#{app}_config_overrides)").each do |key, value|
           escaped_key, escaped_value = escape(key), escape(value.to_s)
           regex = regex + "s/^\s*#{escaped_key}=.*/#CAPIFIED\n#{escaped_key}=#{escaped_value}/g ; "
           regex_commented = regex_commented + "s/^\s*#\s*#{escaped_key}=.*/\#CAPIFIED\n\##{escaped_key}=#{escaped_value}/g ; "
         end
         set :config_overrides, eval("global_config_overrides.merge($#{app}_config_overrides)")
       rescue NameError => e
         logger.info "had no override definition exists with the name #{e.name}... creating a dummy one now"
         eval("#{e.name} = Hash.new")
         retry
       end

       logger.info "DEBUG--> REGEX-> #{regex}"

       # Perform the substitution
       run "perl -pi -e '#{regex}' #{basedir}/jetty-#{app}/config/DS_Configuration.properties"
       run "perl -pi -e '#{regex_commented}' #{basedir}/jetty-#{app}/config/DS_Configuration.properties"
       global_config_injections =  config_overrides.merge(hiera('ds_properties',:hash))
       # if we get a key/value from hiera where REMOVE_KEY is the value we drop it here 
       global_config_injections.delete_if {|key, value| value=="REMOVE_KEY"}
       global_config_injections.sort.each do |key, value|
         run "if grep -q #{key}= #{basedir}/jetty-#{app}/config/DS_Configuration.properties ; then echo \"#{key}= is already present\" ; else echo -e \"\\n#{key}=#{value}\" >> #{basedir}/jetty-#{app}/config/DS_Configuration.properties ; fi ;"
       end

       # compare to old properties file?
       if hiera("backup_properties_file")
         logger.info "DIFF to old properties file:"
         run "diff #{basedir}/jetty-#{app}/config/DS_Configuration.properties #{tmpdir}/#{svc}_DS_Configuration.properties || true"
       end

    end # task "prepare_#{svc}_#{env}".to_sym do

   task "migrate_down_#{svc}_#{env}" do
     if DataServicesUsingMigrations.include?(app)
       if env.include?("mci") 
         apptype = app.end_with?("Ingest") ? "_ingest" : ""
         
         if env == "mciGbenv2"
           migenv = "systest2#{apptype}"
         else
           migenv = "systest#{apptype}"
         end

         logger.info "Running migrations command: migrate down 100000 --env=#{migenv}"
         run ". ~/.bash_profile; cd #{basedir}/jetty-#{app}/migrations; bash bin/migrate down 100000 --env=#{migenv}", :once => true
       end
     end
   end

   task "prepare_migrations_#{svc}_#{env}" do
     if DataServicesUsingMigrations.include?(app)
       # just do for Next for now
       if ["merch2cImages", "merbrocImages", "merpocImages", "chaz2Ingest"].include?(env)
         apptype = app.end_with?("Ingest") ? "_ingest" : ""
         if env == "merch2cImages"
           migenv = "next#{apptype}"
         else
           migenv = "prod#{apptype}"
         end
         unless env.include?("chaz2Ingest") && app.include?("ingestStagingWebService")
           if env == "chaz2Ingest"
           migenv = "chaz2Ingest"
          end
         end
         begin
          run "cd #{basedir}/jetty-#{app}/migrations/environments; cp development.properties #{migenv}.properties"
         rescue
          run "cd #{basedir}/jetty-#{app}/migrations/environments; cp local.properties #{migenv}.properties"
         end
           perl_update_properties_file(hiera('migrations.properties', :hash), "#{basedir}/jetty-#{app}/migrations/environments/#{migenv}.properties")
       end
     end
   end

   task "migrate_bootstrap_#{svc}_#{env}" do
     if DataServicesUsingMigrations.include?(app)
       # only do this in mci and AP environments
       if env.include?("mci") || env.include?("dev_bo_po")
         apptype = app.end_with?("Ingest") ? "_ingest" : ""
         
         if env == "mciGbenv2"
           migenv = "systest2#{apptype}"
         elsif env == "dev_bo_po"
           migenv = "dev_bo_po#{apptype}"
         else
           migenv = "systest#{apptype}"
         end
         
         logger.info "Running migrations command: migrate bootstrap --env=#{migenv} --basedir=#{basedir} --app=#{app}"
         run ". ~/.bash_profile; cd #{basedir}/jetty-#{app}/migrations; bash bin/migrate bootstrap --env=#{migenv}", :once => true
       end
     end
   end

   task "migrate_up_#{svc}_#{env}" do     
     if DataServicesUsingMigrations.include?(app)
       apptype = ""

       if env.include?("merdevlBo2") && app.include?("commerceDataService")
           migenv = "merdevl"
           logger.info "Running migrations command: migrate up --env=#{migenv}"
           run ". ~/.bash_profile; cd #{basedir}/jetty-#{app}/migrations; bash bin/migrate up --env=#{migenv}", :once => true
       end

       if env.include?("mci") || env.include?("merdevlBo2") || env.include?("dev_bo_po")
         if ( app.end_with?("Ingest") )
           apptype = "_ingest"
         end
         if env.include?("mci")
           if env == "mciGbenv2"
             migenv = "systest2#{apptype}"
           else
             migenv = "systest#{apptype}"
           end
         elsif env == "cmpstkMerlinImages"
           migenv = "merqa#{apptype}"
         elsif env == "dev_bo_po"
           migenv = "dev_bo_po#{apptype}"
         else
           migenv = "merdevl#{apptype}"
         end
         
         logger.info "Running migrations command: migrate up --env=#{migenv}"
         run ". ~/.bash_profile; cd #{basedir}/jetty-#{app}/migrations; bash bin/migrate up --env=#{migenv}", :once => true
       end
     end
    end   


logger.info ">>>>> loaded dataServices_compass"
