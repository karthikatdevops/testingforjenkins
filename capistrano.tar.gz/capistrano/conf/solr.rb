## this file contains common tasks that span all environments and all DS apps.
[svc].each do |name|

    # cap dependencies_programIndex2 -f capfile_merdevl -S nobom
    desc "called by dependencies_#{name}"
    task "dependencies_#{name}".to_sym do
        logger.level = Capistrano::Logger::INFO
        logger.info "Checking dependencies for #{name}"

        find_and_execute_task("#{env}_#{name}")
        set :app, "#{name}"
        set :web_port, hiera("#{name}_web_port")
        set :jmx_port, hiera("#{name}_jmx_port")
        set :stop_port, hiera("#{name}_stop_port")
        set :alive_path, hiera("#{name}_alive")

        # No dependencies, so we just return
    end

    desc "called by #{env}_#{name} in #{env}.rb"
     task "#{name}_main_#{env}".to_sym do
       logger.level = Capistrano::Logger::INFO
       
       set :app, "#{name}" 
       
       set :targz_file_name, "#{name}"           
          

       if exists?(:noBom) or exists?(:nobom)
         puts "skipping read bom"
       else
         check_service_version
         read_bom
         set :app, "#{name}"
       end

       set :jetty_wrapper_path, "#{basedir}/jetty-#{name}/jetty-wrapper.sh"
       set :web_port, hiera("#{name}_web_port")
       set :jmx_port, hiera("#{name}_jmx_port")
       set :stop_port, hiera("#{name}_stop_port")
       set :alive_path, "solr/"
       set :strictAlive, true

       if exists?(:cleanServer) && cleanServer.to_s == "true"
         logger.info "clean installing #{name}"
         stop_jetty
         removeSolr
         check
         
       else
         check
         stop_jetty
       end   

       find_and_execute_task("jettywrapper#{name}")
       find_and_execute_task("initd#{name}")
       find_and_execute_task("copy_#{name}_#{env}")
       start_jetty
       alive       
     end

    desc "called by install_jetty"
    task "install_jetty_#{name}".to_sym do
     
     jetty_install("#{name}", "#{jetty_version}")
     logger.info "Moving the old solr/data to new jetty solr/data...."
     run "old_solr_data=\`find #{basedir}/**/solr -name data | grep #{name} | grep -e '[0-9]\\+\\.[0-9]\\+\\.[0-9]\\+\\/solr' | grep -v #{jetty_version} | sort -t- -k3 | tail -1\`; \
     echo \"Found old solr data in \$old_solr_data \"; \
     if [ -d \"\$old_solr_data\" ]; then \
       old_jetty_version=\`echo \$old_solr_data | cut -d '-' -f3 | cut -d '/' -f1\`; echo \"Found old jetty version \$old_jetty_version\"; \
       if [ -n \"\$old_jetty_version\" ] && [ \"\$old_jetty_version\" != \"#{jetty_version}\" ];then \
         if [ ! -d \"#{basedir}/jetty-#{name}/solr\" ]; then \
           mkdir #{basedir}/jetty-#{name}/solr;\
         fi; \
         mv $old_solr_data #{basedir}/jetty-#{name}/solr/; \
       fi;\
     fi"
    end

    desc "used to deploy #{name}"
    task "deploy_#{name}_#{env}".to_sym do
      eval("#{env}_#{name}")
      run_serially_in_batches(:find_server_opts => {:roles => "#{name}".to_sym}) do |server_options|
        set :replication, server_options[:replication]
        set :server_option_master, server_options[:master]
        find_and_execute_task ("#{name}_main_#{env}")
      end
    end
    
  desc "#called by #{name}_main_#{env}"
  task "copy_#{name}_#{env}".to_sym do
    logger.info "TASK: copy_#{name}_#{env} in solr.rb"
     set(:url) do
       Capistrano::CLI.ui.ask "Enter URL to tar.gz file:"
     end unless variables[:url]     
     # remove contents of tmpdir 
     run "rm -rf #{tmpdir}/#{name}"      

       #grab the solr tar.gz from the repo
       begin
         logger.info "BEGIN: Pull #{app} from repo in solr.rb "
            run "cd #{tmpdir}; wget #{wget_params} #{repo}/WARs/apache-solr-#{hiera('solr_version')}.tgz -O- | tar -zxpf -"
        rescue
         logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
         `wget #{wget_params} #{repo}/WARs/apache-solr-#{hiera('solr_version')}.tgz -O working/solr.tar.gz`
         upload("working/#{name}.tar.gz","#{tmpdir}/solr.tar.gz", :via => :scp)
         run "cd #{tmpdir} && tar -zxpf solr.tar.gz"
       end        
       # cp the solr war into place
       run "cp #{tmpdir}/apache-solr-#{hiera('solr_version')}/example/webapps/solr.war #{basedir}/jetty-#{app}/webapps/"

       # ensure that the work directory is in place
       run "mkdir -p #{basedir}/jetty-#{name}/work"

       # rebuild the solr war file adding extra jars and removing others
        logger.info "rebuilding the solr.war to add in the logback jars"
        
	run "if [ -e #{basedir}/jetty-#{name}/webapps/solr.war ]; then  \
    rm -rf #{basedir}/jetty-#{name}/cap_tmp && \
		mkdir -p #{basedir}/jetty-#{name}/cap_tmp && \
		cd #{basedir}/jetty-#{name}/cap_tmp  && \
		unzip -q #{basedir}/jetty-#{name}/webapps/solr.war  && \
		cd #{basedir}/jetty-#{name}/cap_tmp/WEB-INF/lib/ && \
		wget  #{wget_params}  \
	            \'#{repo}/slf4j/1.5.6/log4j-over-slf4j-1.5.6.jar\' \
        	    \'#{repo}/logback/0.9.14/logback-core-0.9.14.jar\' \
	            \'#{repo}/slf4j/1.5.6/jcl-over-slf4j-1.5.6.jar\' \
	            \'#{repo}/logback/0.9.14/logback-access-0.9.14.jar\' \
	            \'#{repo}/slf4j/1.5.6/jul-to-slf4j-1.5.6.jar\' \
	            \'#{repo}/logback/0.9.14/logback-classic-0.9.14.jar\' \
	            \'#{repo}/slf4j/1.5.6/slf4j-api-1.5.6.jar\' && \
		cd #{basedir}/jetty-#{name}/cap_tmp/WEB-INF/lib  && \
		rm -rf jcl-over-slf4j-1.5.5.jar slf4j-api-1.5.5.jar slf4j-jdk14-1.5.5.jar  && \
		cd #{basedir}/jetty-#{name}/cap_tmp && \
		zip -rq ../webapps/solr1.war *  && \
		mv ../webapps/solr1.war ../webapps/solr.war && \
		cd ../ && rm -rf cap_tmp  && \
		echo 'solr.war file has been rebuilt' ;\
	    else \
	        echo 'war file not found' ;\
            fi"
            
    logger.info "finished rebuilding the solr.war to add in the logback jars"


	# install logback
	createLogback_solr

        #grab the CCP solr projects from the repo
        begin
             logger.info "DEBUG: cd #{tmpdir}; wget #{wget_params} \"#{url}\" -O- | tar -zxpf -"
             run "cd #{tmpdir}; wget #{wget_params} \"#{url}\" -O- | tar -zxpf -"
         rescue
          logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
          `wget #{wget_params} \"#{url}\" -O working/#{targz_file_name}.tar.gz`
          upload("working/#{targz_file_name}.tar.gz","#{tmpdir}/#{targz_file_name}.tar.gz", :via => :scp)
          run "cd #{tmpdir} && tar -zxpf #{targz_file_name}.tar.gz"
        end

       # if you're setting "noBom", then don't go through the bom related tasks   
       if exists?(:noBom) or exists?(:nobom)
         #set :skipWriteServiceVersion, "true"
         puts "skipping write_service_version"
       else
         write_service_version
       end
       
       # capistrano is the name of extracted tarball from the assembly
 
       logger.info "NOTE: mv #{tmpdir}/capistrano #{tmpdir}/#{name}"
       run "mv #{tmpdir}/capistrano #{tmpdir}/#{name}"
       
       #remove previous contents
       run "rm -rf #{basedir}/jetty-#{name}/solr/lib #{basedir}/jetty-#{name}/solr/conf #{basedir}/jetty-#{name}/solr/bin"

       logger.info "NOTE: mkdir -p #{basedir}/jetty-#{name}/solr/lib"
       run "mkdir -p #{basedir}/jetty-#{name}/solr/lib"

       #copy in new contents
       if app == "entityIndex"
           logger.info "NOTE:  cp -rp #{tmpdir}/#{name}/#{name}/* #{basedir}/jetty-#{app}/solr"
           run "cp -rp #{tmpdir}/#{name}/#{name}/* #{basedir}/jetty-#{app}/solr"
       end
       if app == "programIndex2"
           logger.info "NOTE:  cp -rp #{tmpdir}/#{name}/#{name}/* #{basedir}/jetty-#{app}/solr"
           run "cp -rp #{tmpdir}/#{name}/solr-pa-2/* #{basedir}/jetty-#{app}/solr"
       end

       logger.info "NOTE: cp #{tmpdir}/#{name}/jar/*.jar #{basedir}/jetty-#{name}/solr/lib || true " 
       run "cp #{tmpdir}/#{name}/jar/*.jar #{basedir}/jetty-#{name}/solr/lib || true " 

       # clean out the working directory
       run "rm -rf #{basedir}/jetty-#{name}/work/*"


       if exists?(:replication)

         # =>       Figure out if we are programIndex or entityIndexer or programIndex2 or programIndexShard2
         if name == "entityIndex"
            myPort = hiera('entityIndex_web_port')
            solr_core_name="\${solr.core.name}/"
            schema_solr_core_name="_\${solr.core.name}" 
            run "if [ -d \"#{basedir}/jetty-#{name}/solr/data\" ] && [ ! -d \"#{basedir}/jetty-#{name}/solr/data/program\" ]; then cd #{basedir}/jetty-#{name}/solr; mv data program; mkdir data; mv program data/; fi"              
          end
          if app == "programIndex2"
            myPort = hiera('programIndex2_web_port')
            solr_core_name=""
            schema_solr_core_name="" 
          end
         
         if "#{replication}" == "slave"
           logger.info "configuring a 'slave' solr server"
           
           #added for more complex replication topologies 
           set :solrMaster, server_option_master unless(server_option_master.nil? || server_option_master=="")
           if solrMaster.nil?
             puts "no master configured despite being a slave"
             exit 1
           end
          
           
           slavexml = <<-HERE
             <!--
             added by capistrano
             -->
             <requestHandler name="/replication" class="solr.ReplicationHandler" >
                 <lst name="slave">
                   <str name="masterUrl">http://#{solrMaster}:#{myPort}/solr/#{solr_core_name}replication</str>
                   <str name="pollInterval">00:30:00</str>
                 </lst>
             </requestHandler>

             HERE
             # One solrconfig.xml in well-known location
              download("#{basedir}/jetty-#{name}/solr/conf/solrconfig.xml","working/solrconfig_slave_#{env}.current", :via => :scp)
              logger.info "just pulled the solrconfig.xml from jetty-#{name} in solr.rb"
              io = File.open("working/solrconfig_slave_#{env}.current", 'r')
              solrConfigSlave = Nokogiri::XML(io)
              io.close
              solrConfigSlave.search("config").each do |here|
                 here.add_child(slavexml)
              end
              xml_SearchReplaceAttribute(solrConfigSlave, "//filterCache[@class='solr.FastLRUCache']", "size", "0")
              xml_SearchReplaceAttribute(solrConfigSlave, "//filterCache[@class='solr.FastLRUCache']", "initialSize", "0")
              xml_SearchReplaceAttribute(solrConfigSlave, "//filterCache[@class='solr.FastLRUCache']", "autowarmCount", "0")

              xml_SearchReplaceAttribute(solrConfigSlave, "//queryResultCache[@class='solr.LRUCache']", "size", "5000")
              xml_SearchReplaceAttribute(solrConfigSlave, "//queryResultCache[@class='solr.LRUCache']", "initialSize", "5000")
              xml_SearchReplaceAttribute(solrConfigSlave, "//queryResultCache[@class='solr.LRUCache']", "autowarmCount", "5000")

              xml_SearchReplaceAttribute(solrConfigSlave, "//documentCache[@class='solr.LRUCache']", "size", "5000")
              xml_SearchReplaceAttribute(solrConfigSlave, "//documentCache[@class='solr.LRUCache']", "initialSize", "5000")
              xml_SearchReplaceAttribute(solrConfigSlave, "//documentCache[@class='solr.LRUCache']", "autowarmCount", "5000")

              xml_SearchReplaceContent(solrConfigSlave, "//queryResultWindowSize", "64")
              xml_SearchAndRemove(solrConfigSlave, "//searchComponent[@name='elevator']")
              xml_SearchAndRemove(solrConfigSlave, "//requestHandler[@name='/elevate']")

              File.open("working/solrconfig_slave_#{env}.new", 'w') {|f| f.write(solrConfigSlave) }
              upload_if_needed("working/solrconfig_slave_#{env}.new","#{basedir}/jetty-#{app}/solr/conf/solrconfig.xml")
              run "perl -pi -e 's#/solr-entity/#/solr/#' #{basedir}/jetty-#{app}/solr/conf/solrconfig.xml"   
               
         elsif "#{replication}" == "master"
           logger.info "configuring a 'master' solr server"
           masterxml = <<-HERE
           <!--
           added by capistrano
           -->
           <requestHandler name="/replication" class="solr.ReplicationHandler" >
               <lst name="master">
                 <str name="replicateAfter">commit</str>
                 <str name="replicateAfter">startup</str>
                 <str name="confFiles">schema#{schema_solr_core_name}.xml,stopwords.txt</str>
               </lst>
           </requestHandler>

           HERE
           
           # One solrconfig.xml in well-known location
            download("#{basedir}/jetty-#{name}/solr/conf/solrconfig.xml","working/solrconfig_master_#{env}.current", :via => :scp) 
            logger.info "just pulled the solrconfig.xml from jetty-#{name} in solr.rb"
            io = File.open("working/solrconfig_master_#{env}.current", 'r')
            solrConfigMaster = Nokogiri::XML(io)
            io.close
            solrConfigMaster.search("config").each do |here|
              here.add_child(masterxml)
            end
            xml_SearchAndRemove(solrConfigMaster, "//searchComponent[@name='elevator']")
            xml_SearchAndRemove(solrConfigMaster, "//requestHandler[@name='/elevate']")

            xml_SearchReplaceAttribute(solrConfigMaster, "//filterCache[@class='solr.FastLRUCache']", "size", "0")
            xml_SearchReplaceAttribute(solrConfigMaster, "//filterCache[@class='solr.FastLRUCache']", "initialSize", "0")
            xml_SearchReplaceAttribute(solrConfigMaster, "//filterCache[@class='solr.FastLRUCache']", "autowarmCount", "0")

            xml_SearchReplaceAttribute(solrConfigMaster, "//queryResultCache[@class='solr.LRUCache']", "size", "0")
            xml_SearchReplaceAttribute(solrConfigMaster, "//queryResultCache[@class='solr.LRUCache']", "initialSize", "0")
            xml_SearchReplaceAttribute(solrConfigMaster, "//queryResultCache[@class='solr.LRUCache']", "autowarmCount", "0")

            xml_SearchReplaceAttribute(solrConfigMaster, "//documentCache[@class='solr.LRUCache']", "size", "0")
            xml_SearchReplaceAttribute(solrConfigMaster, "//documentCache[@class='solr.LRUCache']", "initialSize", "0")
            xml_SearchReplaceAttribute(solrConfigMaster, "//documentCache[@class='solr.LRUCache']", "autowarmCount", "0")

            xml_SearchReplaceContent(solrConfigMaster, "//queryResultWindowSize", "64")
            xml_SearchReplaceContent(solrConfigMaster, "//writeLockTimeout", "10000")
        
            File.open("working/solrconfig_master_#{env}.new", 'w') {|f| f.write(solrConfigMaster) }
            upload_if_needed("working/solrconfig_master_#{env}.new","#{basedir}/jetty-#{app}/solr/conf/solrconfig.xml")
            run "perl -pi -e 's#/solr-entity/#/solr/#' #{basedir}/jetty-#{app}/solr/conf/solrconfig.xml"
         elsif "#{replication}" == "repeater"
           logger.info "configuring a 'repeater' solr server"
            repeaterxml = <<-HERE
            <!--
            added by capistrano
            -->
            <requestHandler name="/replication" class="solr.ReplicationHandler">
                <lst name="master">
                  <str name="replicateAfter">commit</str>
                  <str name="replicateAfter">startup</str>
                  <str name="confFiles">schema#{schema_solr_core_name}.xml,stopwords.txt</str>
                </lst>
                <lst name="slave">
                  <str name="masterUrl">http://#{hiera('masterMaster')}:#{myPort}/solr/#{solr_core_name}replication</str>
                  <str name="pollInterval">00:10:00</str>
                </lst>
              </requestHandler>

            HERE
           
             # One solrconfig.xml in well-known location
              download("#{basedir}/jetty-#{app}/solr/conf/solrconfig.xml","working/solrconfig_repeater_#{env}.current", :via => :scp) 
              logger.info "just pulled the solrconfig.xml from jetty-#{app} in solr.rb"
              io = File.open("working/solrconfig_repeater_#{env}.current", 'r')
              solrConfigRepeater = Nokogiri::XML(io)
              io.close
              solrConfigRepeater.search("config").each do |here|
                here.add_child(repeaterxml)
              end
              xml_SearchAndRemove(solrConfigRepeater, "//searchComponent[@name='elevator']")
              xml_SearchAndRemove(solrConfigRepeater, "//requestHandler[@name='/elevate']")

              File.open("working/solrconfig_repeater_#{env}.new", 'w') {|f| f.write(solrConfigRepeater) }
              upload_if_needed("working/solrconfig_repeater_#{env}.new","#{basedir}/jetty-#{app}/solr/conf/solrconfig.xml")
         end
       end     

       end   #end copy_#{name}_#{env}


end #end Services iteration block
 
 
logger.info ">>>>> loaded solr"