[svc].each do |name|

     desc "called by #{env}_#{name} in #{env}.rb"
     task "#{name}_main_#{env}".to_sym do
       logger.level = Capistrano::Logger::INFO
       logger.info "DEBUG: TASK: #{name}_main_#{env}"
       
     
       set :app, "#{name}"
       set :install_path, "/opt/ds/#{name}"
       puts "....Set install_path=#{install_path}"
       #set :appstagingdir, "/opt/ds/staging/#{name}"

       logger.info "START: this is #{app}"
       logger.info "DEBUG: about to read_bom"
       
       if exists?(:noBom) or exists?(:nobom)
         #set :skipWriteServiceVersion, "true"
         logger.info "skipping read bom"
       else
         check_service_version
         read_bom
       end
       

       if exists?(:cleanServer) && cleanServer.to_s == "true"
        logger.info "NOT IMPLEMENTED clean installing #{name}"
       end   
       find_and_execute_task("copy_#{name}_#{env}")   
       if "#{startService}" == "false"
          logger.info "Not starting #{name} due to startService=#{startService}"
       else
         find_and_execute_task("start_#{name}")
       end
     end


     desc "called by #{name}_main_#{env}"
     task "start_#{name}".to_sym do
 	    run "sudo /etc/init.d/#{name} start ; sleep 2"
     end

    desc "used to deploy #{name}_#{env}"
    task "deploy_#{name}_#{env}".to_sym do
      logger.level = Capistrano::Logger::INFO
      logger.info "M1 TASK: deploy_#{name}_#{env}.to_sym do"
      eval("#{env}_#{name}")
      find_servers(:roles => "#{name}".to_sym).each do |server|
        ENV['HOSTS'] = "#{server.host}"
        set :startService, server.options[:startService]
        set :startServiceAtBoot, server.options[:startServiceAtBoot]
        find_and_execute_task ("#{name}_main_#{env}")
      end
    end
    
    desc "called by #{name}_main_#{env}"
    task "copy_#{name}_#{env}".to_sym do
        logger.info "M2 TASK: copy_#{name}_#{env}.to_sym do"
        run "[ -f /etc/init.d/#{name} ] && sudo /etc/init.d/#{name} stop ; exit 0"
        run "rm -rf #{install_path}"
        run "mkdir -p #{install_path}"
        run "cd #{install_path};mkdir -p logs version"
        if exists?(:noBom) or exists?(:nobom)
            # remove contents of tmpdir 
            run "rm -rf #{tmpdir}/#{name}"
            run "mkdir -p #{tmpdir}/#{name}"
            if variables[:localUrl]
                # If we're using a local file, there is nothing to wget
                logger.info "BEGIN: install service inside serviceInterruptus.rb"
                logger.info " using a localUrl: #{localUrl}"
                logger.info " Upload the tarball to the server"
                #grab the zip file, unzip it, and mv it to a meaningful name      
                upload("#{localUrl}","#{install_path}/#{name}.tar.gz", :via => :scp)
                run "cd #{install_path} && tar xzf #{name}.tar.gz"
                # WRITE SERVICE VERSION
                puts "I have no BOM-- guessing what version of service I have using regex"
                puts "My package is :#{localUrl}... so, I can't really guess my version from this"
                puts " since the package name could be anything.  Just putting 'localUrl' as the version string"
                run "echo \"#{localUrl} (noBom)\" > #{install_path}/version/version.txt"
                # POST HISTORY
                run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
                logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
                run "touch #{basedir}/history/#{app}/deploy_history.txt"
                run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
                run "echo \"Version: #{localUrl} (noBom)\" >> #{basedir}/history/#{app}/deploy_history.txt"
            else
                logger.info " attempting to wget #{url}"
                logger.info " using cmd: wget #{wget_params} --no-proxy #{url} -O- working/#{name}.tar.gz"
                #grab the zip file, unzip it, and mv it to a meaningful name      
                logger.info "using a local wget and scp up to the server, this will take a bit of time..."
                `wget #{wget_params} --no-proxy #{url} -O working/#{name}.tar.gz`
                upload("working/#{name}.tar.gz","#{install_path}/#{name}.tar.gz", :via => :scp)
                run "cd #{install_path} && tar xzf #{name}.tar.gz"
                # WRITE SERVICE VERSION
                puts "I have no BOM-- guessing what version of service I have using regex"
                puts "My package is: #{url}"
                myNoBomVersion = url.gsub(/.*pl-data-tv-serviceinterruptus-impl\//, "")
                myNoBomVersion = myNoBomVersion.gsub(/\/pl-data-tv-serviceinterruptus-impl.*/, "")
                puts "My guessed version is: #{myNoBomVersion}"
                run "echo \"#{myNoBomVersion} (noBom)\" > #{install_path}/version/version.txt"
                # POST HISTORY
                run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
                logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
                run "touch #{basedir}/history/#{app}/deploy_history.txt"
                run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
                run "echo \"Version: #{myNoBomVersion} (noBom)\" >> #{basedir}/history/#{app}/deploy_history.txt"
            end
        else
            get_remote_file("#{url}","#{install_path}","#{app}.tar.#{service_version}.gz")
            logger.info "unpacking tarball"
            run "cd #{install_path} && tar xzf #{app}.tar.#{service_version}.gz"
            run "echo #{service_version} #{bom} > #{install_path}/version/version.txt"
            # POST HISTORY
            run "if [ -e #{basedir}/history/#{app} ]; then echo 'dir #{basedir}/history/#{app} exists'; else mkdir -p #{basedir}/history/#{app} ; fi"
            logger.info "Making history in file: #{basedir}/history/#{app}/deploy_history.txt"
            run "touch #{basedir}/history/#{app}/deploy_history.txt"
            run "date +%F-%H%M%S >> #{basedir}/history/#{app}/deploy_history.txt"
            run "echo \"Version: #{service_version} #{bom}\" >> #{basedir}/history/#{app}/deploy_history.txt"
        end

        #find_and_execute_task("updateConfig_#{name}_#{env}")
        find_and_execute_task("initd#{name}")
        logger.info "TASK: END"
    
    end
  
  desc  "called by copy_#{name}_#{env} to write init and wrapper" 
  task "initd#{name}".to_sym do
  logger.info "M3 TASK: initd#{name}"

  initd_string = <<-initdfile
  #!/bin/bash
  #
  # /etc/init.d/#{name}
  # init script for #{name}
  #
  # chkconfig: 2345 99 01
  # description: #{name}
  #
    JAVA_HOME=/usr/java/latest
    JAVA_EXE=$JAVA_HOME/bin/java
    APP_HOME=#{install_path}
    ARTIFACT_ID=pl-data-tv-serviceinterruptus
    LOCK_FILE=/var/lock/subsys/#{name}
    LOG_FILE=$APP_HOME/logs/#{name}-jsvc.log
    CONSOLE_LOG_FILE=$APP_HOME/logs/#{name}-console.log
    ERROR_LOG_FILE=$APP_HOME/logs/#{name}-jsvc-error.log
    RUN_AS_USER=xdeploy
    PID_JAR=${ARTIFACT_ID}-impl-.*.jar
    EXE_JAR=`find #{install_path} -name ${ARTIFACT_ID}-impl-*.jar`
    echo $EXE_JAR
    a=($EXE_JAR)
    if [ ${#a[*]} != 1 ]; then
       echo "The Jar file is not unique. Which one we should run?"; 
       echo $EXE_JAR; 
       exit; 
    fi
    
    export JAVA_OPTS="-Xms512m -Xmx512m -Xdebug -Djava.compiler=NONE \\
        -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=#{hiera('serviceInterruptus_debug_port')} \\
        -Dcom.sun.management.jmxremote \\
        -Dcom.sun.management.jmxremote.port=#{hiera('serviceInterruptus_jmx_port')} \\
        -Dcom.sun.management.jmxremote.authenticate=false \\
        -Dcom.sun.management.jmxremote.ssl=false \\
        -Dlogback.configurationFile=classpath:config/logback.xml"

    JAVA_CMD="$JAVA_OPTS -jar $EXE_JAR -p #{serviceInterruptus_main_port}"
    checkGroup() {
        if [ "X$RUN_AS_USER" != "X" ]
        then
               RUN_AS_GROUP=`groups $RUN_AS_USER | awk '{print $3}' | tail -1`
               if [ "X$RUN_AS_GROUP" = "X" ]
               then
                    RUN_AS_GROUP=$RUN_AS_USER
    		return 0
               fi
        fi
        return 1
    }


    start () {
        echo "Starting #{name} "

        # start daemon 
        cd $APP_HOME 
         pid=`ps uax | grep -e $PID_JAR |grep -v 'grep'| head -n 1 | awk '{print $2}'`
         if [ -z "$pid" ]; then
         	sudo su - $RUN_AS_USER -c "cd $APP_HOME ; $JAVA_EXE $JAVA_CMD  > $CONSOLE_LOG_FILE  2>&1 &"
         	RETVAL=$?
         else
    	echo "#{name} was started. It cannot be started again!"
            RETVAL=1
         fi
         if [ $RETVAL = 0 ]; then
    	sudo touch $LOCK_FILE 
    	checkGroup 
    	if [ -n "$RUN_AS_GROUP" ]; then
    		sudo chown $RUN_AS_USER:$RUN_AS_GROUP $LOCK_FILE 
    		echo "#{name} has been started successful!"
    	else
    		sudo rm $LOCK_FILE
    		echo "#{name} is started successful. But it cannot create lock file because the user $RUN_AS_USER does not belong to any group"
    	fi
         fi
         return $RETVAL
    }

    stop () {
        # stop daemon
        echo "Stopping #{name}..."
        pid=`ps uax | grep -e $PID_JAR |grep -v grep| head -n 1 | awk '{print $2}'`
        if [ -n "$pid" ]; then
          while [ -n "$pid" ]
          do
    	       kill -9 $pid
    	       RETVAL=$?
    	       pid=`ps uax | grep -e $PID_JAR |grep -v grep| head -n 1 | awk '{print $2}'`
    	     done 
        else
    	     echo "#{name} was not running"
    	     RETVAL=1 #There is no #{name} running
        fi
        [ $RETVAL = 0 ] && [ -e "$LOCK_FILE" ] && sudo rm $LOCK_FILE && echo "#{name} has been fully stopped!"
        return $RETVAL
    }

    restart() {
        stop
        start
    }

    case $1 in
        start)
            start
        ;;
        stop)
            stop
        ;;
        restart)
             restart
         ;;
        *)

        echo $"Usage: $0 {start|stop|restart}"
        exit 3
    esac
    exit $RETVAL
initdfile
       
      my_initd_file = File.open("working/#{name}initd", 'w')
      my_initd_file.puts "#{initd_string}"
      my_initd_file.close
      upload("working/#{name}initd","#{install_path}/initd", :via => :scp, :mode => "755")
      run "sudo mv #{install_path}/initd /etc/init.d/#{name} && sudo chmod 755 /etc/init.d/#{name} && sudo chown root:root /etc/init.d/#{name}" 
      if "#{startServiceAtBoot}" == "false"
        logger.info "Not enabling autostart of #{name} due to startServiceAtBoot=#{startServiceAtBoot}"
      else
        run "sudo /sbin/chkconfig --add #{app}"
        logger.info "DEBUG: ran chkconfig add"
      end
      logger.info "DEBUG: completed initd script"
   end #end task "initd#{name}" 
end #end Services iteration block

logger.info ">>>>> loaded serviceInterruptus"