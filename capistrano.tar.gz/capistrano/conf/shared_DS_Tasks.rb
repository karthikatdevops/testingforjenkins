
task "initd#{svc}".to_sym do
  logger.info "TASK: Entered initd in shared_DS_Tasks.rb"
   initd_string = get_string_from_erb("templates/ds/initd", binding)
   upload(StringIO.new(initd_string), "#{basedir}/#{svc}initd", :via => :scp, :mode => 0700)
   run "sudo mv #{basedir}/#{svc}initd /etc/init.d/#{svc} && sudo chown root:root /etc/init.d/#{svc}"
   if exists?(:do_not_start) && do_not_start == true
     run "if sudo /sbin/chkconfig --list #{svc} ; then sudo /sbin/chkconfig --del #{svc} ; echo \"removed #{svc} from chkconfig\" ; fi"
   else
     run "sudo /sbin/chkconfig --add #{svc}"
   end
   install_realm
end #end task "initd#{svc}"


task :deploy_matchbox do
  logger.info "TASK: Entered matchbox in shared_DS_Tasks.rb"
  logger.info "about to verify that the target dir exists on system for #{svc}"
  check_my_dir("#{basedir}/jetty-#{svc}/contexts")
  check_my_dir("#{basedir}/jetty-#{svc}/matchbox")
  check_my_dir("#{basedir}/jetty-#{svc}/matchbox/outputFiles")
  check_my_dir("#{basedir}/jetty-#{svc}/matchbox/work")
  check_my_dir("#{basedir}/jetty-#{svc}/matchbox/sourceFiles")
  logger.info "about to upload matchbox.xml"
  matchbox = get_string_from_erb("templates/ds/matchbox", binding)
  upload(StringIO.new(matchbox),"#{basedir}/jetty-#{svc}/contexts/matchbox.xml", :via => :scp, :mode => 0644)
  logger.info "completed matchbox deployment for #{svc}"
end # end task matchbox

task "jettyrealm#{svc}".to_sym do
  logger.info "TASK: Entered jettyrealm#{svc} in shared_DS_Tasks.rb"
  logger.info "about to add default security realm for #{svc}"
  realm_string = get_string_from_erb("templates/ds/jettyrealm", binding)
  upload(StringIO.new(realm_string),"#{basedir}/jetty-#{svc}/etc/jetty-realm.xml", :via => :scp, :mode => 0660 )
  mod_string = get_string_from_erb("templates/ds/realmmod", binding)
  upload(StringIO.new(mod_string),"#{basedir}/jetty-#{svc}/modules/realm.mod", :via => :scp, :mode => 0660 )
  logger.info "completed default security realm deployment for #{svc}"
end

task "jettywrapper#{svc}".to_sym do
  puts "********************************* I'm in jettywraper tasks, watchout @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
  debugOptions = (hiera('debug_port_on') == 'true') ? "-Xrunjdwp:transport=dt_socket,server=y,address=#{hiera("#{svc}_debug_port")},suspend=n" : ""

  # Make a temp directory
  run "mkdir -p #{basedir}/jetty-#{svc}/tmp"

  extraOptions = hiera('extraOptions')
  extraEnv = ""

  #inject extra Options for cloverServer
  if app == "cloverServer"
    #inject extra environment Variables for cloverServer
    clover_direct_mem = "8192"
    extraEnv = <<-ENVHERE
    function getPropertyFromFile() {
    local retVal=""

    if [[ -n $1 && -f $1 ]]; then
      if [ -n $2 ]; then
        local propNameRegx="^\\s*$2\\s*="

        retVal=`sed '/^\#/d' $1  | grep $propNameRegx | tail -n 1 | cut -d "=" -f2- | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'`
      else
        echo "Error: Property name not provided"
      fi
    else
      echo "Error: File $1 not found"
    fi

    echo "$retVal"
    }
    
  DIRECTMEM=#{clover_direct_mem}
  export clover_config_file="#{basedir}/jetty-#{svc}/config/cloverServer.properties"
  export clover_license_file="#{basedir}/jetty-#{svc}/config/license.dat"
  export graph_logs_path="#{basedir}/jetty-#{svc}/logs";
  export graph_debug_path="#{basedir}/jetty-#{svc}/logs";
  service_name=`getPropertyFromFile $clover_config_file service.name`
  service_env=`getPropertyFromFile $clover_config_file service.environment`
  ENVHERE
  end

  # set up dynaTrace (just sets dynaTrace_options to "" if :dynaTrace_collectors is not set)
  configure_dynaTrace

  java_home = java_info[java_version]['java_home']
  wrapper = get_string_from_erb("templates/ds/wrapper", binding)
  upload(StringIO.new(wrapper),"#{basedir}/jetty-#{svc}/jetty-wrapper.sh", :via => :scp, :mode => 0770)
  find_and_execute_task("OOM_#{svc}")
end


  task "OOM_#{svc}".to_sym do

    # set port vars if not set already
    set :jmx_port, hiera("#{svc}_jmx_port") unless exists?(:jmx_port)
    set :web_port, hiera("#{svc}_web_port") unless exists?(:web_port)

    logger.info "TASK: Entered OOM_#{svc} IN shared_DS_Tasks.rb"

    minRetrieveThreads = 90
    maxRetrieveThreads = 90
    createThreads = 30
    unmarshallingThreads = 30
    minMarshallingThreads = 30
    maxMarshallingThreads = 30
    authThreads = 60
    deleteThreads = 30
    updateThreads = 60

    oom_string = get_string_from_erb("templates/ds/OOM.rb", binding)
    upload(StringIO.new(oom_string),"#{basedir}/jetty-#{svc}/bin/OOM.rb", :via => :scp, :mode => 0770)

    crash_string = get_string_from_erb("templates/ds/CRASH.rb", binding)
    upload(StringIO.new(crash_string),"#{basedir}/jetty-#{svc}/bin/CRASH.rb", :via => :scp, :mode => 0770 )

  diag_string = <<-diag_restart
#!/usr/bin/env ruby
pid = `cat #{basedir}/jetty-#{svc}/jetty.pid`.chomp

# force the health check down
`bash -c \\"java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p #{jmx_port} <( echo 'puts [  jmx_invoke -m thePlatform:application=#{svc},#{"endpoint=#{svc}," if DataServicesCompass.include?(app) }name=aliveCheckConfiguration setForceDown true ] ; jmx_close;' )\\"`
sleep 20
heapDumpFilename = "#{basedir}/jetty-#{svc}/logs/#{svc}-diag_restart-\#{Time.now.to_i}.heapDump"
statusFilename = "\#{heapDumpFilename.sub(/(.*)heapDump/, '\\1')}status.tar.gz".chomp
`cd #{basedir}/jetty-#{svc}/logs ; wget --quiet -nH --cut-dirs=2 --no-proxy --user=xdeploy --password=xcal09 -r http://localhost:#{web_port}/#{svc}/management/status ; tar -czvf \#{statusFilename}.tar.gz status ; rm -rf status`
`bash -c \\"java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p #{jmx_port} <( echo 'puts [  jmx_invoke -m com.sun.management:type=HotSpotDiagnostic dumpHeap \#{heapDumpFilename} false ] ; jmx_close;' )\\"`
jstackFilename = "\#{heapDumpFilename.sub(/(.*)heapDump/, '\\1')}jstack".chomp
sleep 1
# wait until the heapDumpFile has been completely written to disk
`lsof +r 10 \#{heapDumpFilename}`
`jstack -l \#{pid} > \#{jstackFilename}`
`chmod +r \#{heapDumpFilename}`
exec("gzip \#{heapDumpFilename}") if fork.nil?
`logger -t DIAG_restart -p daemon.error \\"service=#{svc} statusFilename=$HOSTNAME:\#{statusFilename} heapDumpFilename=$HOSTNAME:\#{heapDumpFilename}.gz jstackFilename=$HOSTNAME:\#{jstackFilename} \\"`
`sudo /etc/init.d/#{svc} restart`
diag_restart

  upload(StringIO.new(diag_string),"#{basedir}/jetty-#{svc}/bin/diag_restart.rb", :via => :scp, :mode => 0770 )

  if jmx_tunings
    set :jmx_tuning_wait, 60 unless exists?(:jmx_tuning_wait)
    tune_string = get_string_from_erb("templates/ds/TUNE.rb", binding)
    upload(StringIO.new(tune_string),"#{basedir}/jetty-#{svc}/bin/tune.rb", :via => :scp, :mode => 0770 )
  end

end



  desc "helper task that accesses a services's role and ssh's to the first host"
  task "ssh_#{svc}" do
    find_and_execute_task("#{environments}_#{svc}")
    find_servers(:roles => "#{svc}".to_sym).each do |server|
      logger.info "sshing to #{server.host}"
      exec "ssh -q #{user}@#{server.host}"
    end
  end

  desc "helper task that ensures all hosts with a services's role have appropriate hosts file entries, or not, as appropriate"
  task "hosts_file_override_#{svc}" do
    find_and_execute_task("#{confType}_#{svc}")
    logger.level = Capistrano::Logger::INFO
    find_servers(:roles => "#{svc}".to_sym).each do |server|
      if ( exists? :hosts_file_overrides )
        orig_hosts = ENV['HOSTS']
        ENV['HOSTS'] = server.to_s
        hosts_file_overrides.each { |host_with|
          logger.trace "General override: #{host_with[:hostname]} => #{host_with[:with_ip]} a.k.a. #{host_with[:aliases].inspect}"
          if host_with[:with_ip].empty?
              remove_host_entry_via_puppet(host_with[:hostname])
          else
              add_host_entry_via_puppet(host_with[:hostname], host_with[:with_ip], host_with[:aliases])
          end
        }
        ENV['HOSTS'] = orig_hosts
      end
    end
  end

  desc "helper task display all hosts entries for a given services's role"
  task "hosts_file_display_#{svc}" do
    find_and_execute_task("#{confType}_#{svc}")
    get_puppet_resource("host", nil)
  end

logger.info ">>>>> loaded shared_DS_Tasks"
