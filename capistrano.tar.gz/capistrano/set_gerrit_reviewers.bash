#!/bin/bash

function Usage {
    echo "============================"
    echo "=  Error : Incorrect args  ="
    echo "============================"
    echo "Usage: ./set_gerrit_reviewers <SHA1> [user-list,with commas]"
    echo ""
    echo "(Grab the abbreviated SHA1 key from your 'git push origin master:refs/for/master' command)"
    echo "(As an example, in the below message, it's 1b9bce6)"
    echo ""
    echo "Without any set of reviewers listed, the default set will be used. Otherwise, feel free to"
    echo "designate the usernames that should be set as reviewers in a comma-separated list."
    echo ""
    echo "$ git push origin master:refs/for/master"
    echo "Counting objects: 79, done."
    echo "Delta compression using up to 2 threads."
    echo "Compressing objects: 100% (40/40), done."
    echo "Writing objects: 100% (40/40), 3.83 KiB, done."
    echo "Total 40 (delta 38), reused 0 (delta 0)"
    echo "remote: Resolving deltas: 100% (38/38)"
    echo "remote: Processing changes: new: 1, done"
    echo "remote: (W) 1b9bce6: commit subject >65 characters; use shorter first paragraph"
    echo "remote: (W) 1b9bce6: commit message lines >70 characters; manually wrap lines"
    echo "remote:"
    echo "remote: New Changes:"
    echo "remote:   http://gerrit.git.chalybs.net:29000/323"
    echo "remote:"
    echo "To ssh://gerrit.git.chalybs.net:29418/capistrano"
    echo " * [new branch]      master -> refs/for/master"
}

############################
# Check number of arguments
############################
if [ $# -eq 0 ]; then
    Usage;
    exit 1
fi

############################
# Define users to review
############################
if [ $2 ]; then
    user_list=$2
    echo "using defined email list..."
else
    user_list='Joe_Wilcoxson@cable.comcast.com,Andrew_Burnheimer@cable.comcast.com,Kevin_Sin@cable.comcast.com,Andrew_Diller@Comcast.com,Yongjun_Rong@cable.comcast.com,srinivasarao_bollepalli@cable.comcast.com,Kevin_Ruse@cable.comcast.com,Marcus_John@cable.comcast.com'
    echo "using default email list..."
fi

############################
# Add all of BITT and MOPS
############################
user_list=${user_list//,/ }
#for i in $user_list ; do
#    echo "Setting reviewer to $i for $1"
#    ssh -p 29418 gerrit.git.chalybs.net gerrit set-reviewers --project capistrano --add $i $1
#done

# check this page: https://review.openstack.org/Documentation/cmd-review.html

echo "setting commit $1 to verfied, reviewed and submitted - no need to go into the gui"
ssh -p 29418 gerrit.git.chalybs.net gerrit review --verified +1 $1
ssh -p 29418 gerrit.git.chalybs.net gerrit review --code-review +2 -m "'Looks good to me. (this is automated)'" $1
ssh -p 29418 gerrit.git.chalybs.net gerrit review --submit $1
echo 'please wait a moment for merge.....'
git fetch && sleep 10
git fetch 


