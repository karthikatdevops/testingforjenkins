#!/bin/bash

for env in merdevl
do
  for jmxType in requestStatistics phaseExecutionStatistics java.lang servers
  do
    if [ ${1} == 'jmx' ] || [ ${1} == 'both' ]; then
      echo "cap -f capfile_${env} update_jmxtrans_${env} -S nobom -S jmxstats=${jmxType} -S deploy=true"
      cap -f capfile_${env} update_jmxtrans_${env} -S nobom -S jmxstats=${jmxType} -S deploy=true
    fi

    if [ $1 == 'gdash' ] || [ ${1} == 'both' ]; then
      echo "cap -f capfile_${env} update_gdash_${env} -S nobom -S jmxstats=${jmxType} -S deploy=true"
      cap -f capfile_${env} update_gdash_${env} -S nobom -S jmxstats=${jmxType} -S deploy=true
    fi
  done
done




