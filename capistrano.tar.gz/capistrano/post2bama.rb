#!/usr/bin/env ruby
require 'rubygems'
require 'json'
require 'rest_client'
require 'nokogiri' 

SCRIPT_DIR=File.expand_path(File.join(File.dirname(__FILE__)))
puts "SCRIPTS_DIR=#{SCRIPT_DIR}"
JSON_DIR="#{SCRIPT_DIR}/working/json"
if ! File.directory?(JSON_DIR)
  puts "There is no #{JSON_DIR}. Creating this now in working directory..."
	Dir.mkdir(JSON_DIR)
else
  puts "found #{JSON_DIR}."
end

def usage
  puts "Usage: #{__FILE__} -developer={developer for this development} -version={version of the artifact}} [-force=true|false: default to false] [-bama={bama_url}]"
  puts "-version                    Required. It specifies either the artifact version or the version regular expression."  
  puts "-developer                  Optional. It specifies either the developer of the artifact or the jira ticket number which can be used to extract the developer of the artifact."
  puts "-force                      Optional. Force BAMA to overwrite the service record. Value: true|false. default to false."
  puts "-bama                       Optional. When specified it will post to the new BAMA json url specified here.Ex: -bama=\"http://bamaprod.chalybs.net/json/\""
  puts "Example:#{__FILE__} -developer=yrong -version=merlin_sprint_w"
	exit 1
end

if ARGV.length < 1 || ARGV.length > 4
  usage
end
if ARGV.length == 1 && !ARGV[0].start_with?("-version")
  puts "Please specify the capistrano branch version using -version="
  usage
end
  
project_name="capistrano"
service_name=project_name
base_tag_ver=""
#tag_url="http://gitbrowse.chalybs.net/cgit/capistrano/plain/common/basic.rb"
groupId="capistrano"
artifactId="capistrano"
bama_url=""
reporter=""
force="false"
version=""
(0...ARGV.length).each{|i|
  if ARGV[i].start_with?("-developer=")
    reporter=ARGV[i].split("=")[1]   
  elsif ARGV[i].start_with?("-bama=")
    bama_url=ARGV[i].split("=")[1]
  elsif ARGV[i].start_with?("-force=")
    force=ARGV[i].split("=")[1]
  elsif ARGV[i].start_with?("-version=")
    version=ARGV[i].split("=")[1]
  else
    puts "Please specify the right arguments."
    usage
  end
}
if reporter.nil? || reporter.empty? 
  id_nu=`id -nu`.chomp.strip  
  puts "id_nu===#{id_nu}"
  if id_nu.nil? || id_nu.empty?
    puts "Please specify developer from command line using -developer=\#{reporter}"
    usage
  else
    reporter=id_nu
  end   
end


base_tag_ver=version
JSON_URL="http://bamaprod.chalybs.net/json/" 
BAMASTAGE_JSON_URL="http://bamastage.chalybs.net/json/"
BAMADEV_JSON_URL="http://bamadev.chalybs.net/json/"
if bama_url.empty?
  bama_url=JSON_URL
end 

#set bama_url to the routable public vip based on XOPS-17774
env=`hostname | cut -d '-' -f 2`.chomp.strip
if defined?env and !env.empty? and (env.eql?("po") || env.eql?("br"))
  bama_url="http://69.241.25.244:8087/json/"
end

artifacts=<<-SINGLE
{
  "groupId":"#{groupId}",
  "artifactId":"#{artifactId}",
  "url":" "
}
SINGLE

#Create JSON post for BOM management application
if defined?env and !env.empty? and (env.eql?("po") || env.eql?("br"))
  bama_urls=[bama_url]     
else
  bama_urls=[bama_url,BAMASTAGE_JSON_URL,BAMADEV_JSON_URL]
end
 
def validate_json(json_post)
  begin  
    JSON.parse json_post
  rescue Exception => e  
    puts "json_post:\n#{json_post}"
    print e.backtrace.join("\n")  
    exit 1
  end
  #puts "Verfied json:\n#{json_post}"
end

bama_urls.each{ |json_url|
    begin
       puts "Get Secret from #{json_url}secret"
       #Get the BAMA post secret
       http_proxy=ENV['http_proxy']
       if http_proxy.nil? || http_proxy.empty?
           http_proxy="http://proxy:3128"
       end
       begin
          RestClient.proxy = http_proxy
          getResponse=RestClient.get "#{json_url}secret" 
       rescue Exception => get_secret_proxy
          RestClient.proxy = ""
          getResponse=RestClient.get "#{json_url}secret"
       end 
       getResponseJSON=JSON.parse getResponse
       secret=getResponseJSON["secret"]
       json_post = <<-JSON_STR
       {
         "secret":"#{secret}",
         "name":"#{service_name}",
         "version":"#{version}",
         "bittTicket":" ",
         "reporter":"#{reporter}",
         "forced":"#{force}",
         "artifacts":[
           #{artifacts}
         ]
       }
       JSON_STR
       validate_json(json_post)        
       json_file="#{JSON_DIR}/#{service_name}_#{version}_post.json"  
       begin
            puts "Posting #{json_post} \n to #{json_url}build"
            postResponse = RestClient.post "#{json_url}build", json_post, :content_type => 'application/json'
            puts "postResponse=#{postResponse.code}"
            if postResponse.code==200 || 201
              puts "Bama Build JSON post successful: #{postResponse.code}"  
            else         
              File.open(json_file, 'w') {|f| f.write(json_post) }  
              if json_url.eql?(bama_url)
                puts "BAMA BUILD JSON POSTING FAILED!","Error: #{postResponse.code} on post build json message for #{service_name} #{version} to #{json_url}. \n #{postResponse}. \n Re-reun the json post message from #{json_file}."
              end
              case 
               when 400
                 puts "Bad Request:400:#{postResponse}" 
               when 403
                 puts "Forbidden:403:#{postResponse}"
               when 406
                 puts "Already posted:406:#{postResponse}"
               else
                 puts "Unknow Error:#{postResponse}"
               end
            end
       rescue Exception => postEx           
            File.open(json_file, 'w') {|f| f.write(json_post) }
            if json_url.eql?(bama_url)
              puts "BAMA BUILD JSON POSTING FAILED!","Error: #{postEx} on post build json message for #{service_name} #{version} to #{json_url}. \n Re-reun the json post message from #{json_file}."
            end
       end
    rescue Exception => getSecretEx
      json_post = <<-JSON_STR
       {
         "name":"#{service_name}",
         "version":"#{version}",
         "bittTicket":" ",
         "reporter":"#{reporter}",
         "forced":"#{force}",
         "artifacts":[
           #{artifacts}
         ]
       }
       JSON_STR
             
        validate_json(json_post)
        puts json_post
        json_file="#{JSON_DIR}/#{service_name}_#{version}_post.json"
        File.open(json_file, 'w') {|f| f.write(json_post) }
        if json_url.eql?(bama_url)
          puts "BAMA BUILD JSON POSTING FAILED!","Error: Cannot get BAMA JSON post secret:Error=#{getSecretEx} when posting build json message for #{service_name} #{version} to #{json_url}. \n Re-reun the json post message from #{json_file}."
        end
        puts ""
    end
}



