### function to return url to download the file from with given tag and service name
def get_artifactory_file_name(mmytag,mmyservice)
  case mmyservice
when "linear","entity","location","offer"
    ll="http://maven.compass.chalybs.net:8081/artifactory/compass-all-repos/com/theplatform/data/tv/#{mmyservice}/pl-data-tv-#{mmyservice}-db/#{mmytag}/pl-data-tv-#{mmyservice}-db-#{mmytag}.tar.gz   " 
when "job"
   ll="ruby get_migrate_up.rb --file http://maven.compass.chalybs.net:8081/artifactory/simple/compass-all-repos/com/theplatform/data/commons/job/pl-data-commons-job-db/#{mmytag}/pl-data-commons-job-db-#{mmytag}.tar.gz  " 
when "ID"
 ll="http://maven.compass.chalybs.net:8081/artifactory/compass-all-repos/com/theplatform/data/tv/id/pl-data-tv-id-db/#{mytag}/pl-data-tv-id-db-#{mytag}.tar.gz "
when "alg","amg","cim","csm","edit","music","tvg","id","ncds","util","misc" 
 ll="http://maven.compass.chalybs.net:8081/artifactory/compass-all-repos/com/theplatform/data/tv/ingest/#{mmyservice}/pl-data-tv-ingest-clover-graphs-#{mmyservice}-impl/#{mmytag}/pl-data-tv-ingest-clover-graphs-#{mmyservice}-impl-#{mmytag}-db-migration.tar.gz" 
when "map"
  ll="http://maven.compass.chalybs.net:8081/artifactory/simple/compass-merlin-releases/com/theplatform/data/tv/ingest/pl-data-tv-ingest-clover-mappings/#{mmytag}/pl-data-tv-ingest-clover-mappings-#{mmytag}.tar.gz "
else
 ll= "error"
end #case
return ll
end #def get_file_name
