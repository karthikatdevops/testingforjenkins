#!/bin/bash
#
# Deploy CFIG Snapshot to the 'dev' instance in CFIG env
# modified from Chad's mci deploy script
# using the new artifactory mvn repo

# "http://nexus:8081/nexus/groups/master/com/theplatform/web/tv/cfig/pl-web-tv-cfig-webapp/1.0.15-SNAPSHOT/pl-web-tv-cfig-webapp-1.0.15-SNAPSHOT-package.tar.gz"

set -e
server="http://maven.compass.chalybs.net:8081/artifactory"
cfigserver="http://nexus:8081/nexus/groups/master/com/theplatform/web/tv/cfig"
repo="compass-merlin-snapshots"
groupid="com.theplatform.web.tv.cfig"
artifactid="pl-web-tv-cfig-webapp"
service="cfigWebService"


# Find the latest SNAPSHOT version
version=`curl -s "${server}/api/search/versions?g=${groupid}&a=${artifactid}&repos=${repo}" |grep version |head -1 |sed "s/ *\"version\" : \"//" |sed "s/\",//"`
path=`echo "${groupid}" | sed "s/\./\//g"`

classifier="package"

artifactURI="${server}/${repo}/${path}/${artifactid}/${version}/${artifactid}-${version}-${classifier}.tar.gz"
nexusURI="${cfigserver}/${artifactid}/${version}/${artifactid}-${version}-${classifier}.tar.gz"

# Sanity check
echo "going to check via this: curl -sI ${artifactURI}"
artifactExists=`curl -sI "${artifactURI}" | head -1`
if [[ "${artifactExists}" != *"200 OK"* ]] ; then
    echo "Error: artifact not found!"
    exit 1
fi

echo "Deploying"
echo " - GroupId: \"${groupid}\""
echo " - ArtifactId: \"${artifactid}\""
echo " - Version: \"${version}\""
echo " - Service: \"${service}\""
echo " - Environment: \"${env}\""
echo " - ArtifactURI: \"${artifactURI}\""

# old command

# cap deploy_cfigdevWebService_meridk -f capfile_meridk -S force=true -S noBom=true -S url=http://nexus.compass.chalybs.net/content/repositories/master/com/theplatform/web/tv/cfig/pl-web-tv-cfig-webapp/CCP-LATEST-SNAPSHOT/pl-web-tv-cfig-webapp-CCP-LATEST-SNAPSHOT-package.tar.gz HOSTS=app-br-19e.idk.cable.comcast.com

echo ...........................................................................
echo "CFIG DEV service deployment"
#cap deploy_cfigdevWebService_meridk -f capfile_meridk - cleanServer=true -S force=true -S noBom=true -S url=${artifactURI} HOSTS=app-br-19e.idk.cable.comcast.com
 bundle exec cap deploy_cfigdevWebService_meridkDev -S env=meridkDev -S svc=cfigdevWebService  -S cleanServer=true -S force=true -S noBom=true -S url=${artifactURI}

echo done

exit 0

