#! /bin/bash

MASTER=`git log --pretty=format:'%H' master | sort`
DEV=`git log --pretty=format:'%H' $1 | sort`

echo =============================================================
echo "Commits in $1, but not in Master:"
echo ---------------------------------------------------------------
for i in `diff <(echo "${MASTER}") <(echo "${DEV}") | grep '^>' | sed 's/^> //'`; 
do 
  git --no-pager log -1 --pretty=format:"%h-%ar-%an: %s" $i;
  echo 
done
echo ----------------------------------------

