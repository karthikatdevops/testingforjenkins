#!/bin/bash
#
# andrew_diller@comcast.com Dec 2015
# v 1.0
#
# create yaml input files for ansible to push to Nagios
# Uses cap/hiera envs as the source of truth for hosts
# services, ports and alive checks.
#
# You should have cap & hiera checked out and also the
# ansible-nagios project from Destro Github
#
# change the CAPROOT and ANSIBLEROOT to where you have them
# on your system. Ensure you can ssh in without password as
# xdeploy user on the Nagios target host

# Generate configs for these Enviroments
env=( cmpstkMerlinIngest merdevlBo2 a2gdev)

YAMLFILES=working/nagios
CAPROOT=~/compass/bitt/build/capistrano
ANSIBLEROOT=~/compass/GHE/nagios-ansible

echo clean existing files out
pwd
if [ -d "$YAMLFILES" ]; then
  rm -rf working/nagios/*.yml
else
   echo working dir not found, exiting script
   exit 1
fi

# We have to execute this cap command for each env we want to have monitored
# in nagios. The next cap command will bundle them together into one file

echo creating new yaml files from cap
for i in "${env[@]}"
do
   bundle exec cap -S env=$i -S svc=none -S nobom generate_nagios_yaml
done

ls -l $YAMLFILES

echo combine yaml files into one for each type
bundle exec cap -S svc=ars -S env=a2gdev -S nobom combine_nagios_files


if [ ! -d $ANSIBLEROOT/from_cap ]; then
    echo "$ANSIBLEROOT/from_cap not found!"
    echo "Making this dir for you."
    mkdir $ANSIBLEROOT/from_cap
fi


echo copy files over to ansible dir
if [ ! -f $CAPROOT/working/nagios/compass_combined_hostGroups.yml ]; then
    echo "$CAPROOT/working/nagios/compass_combined_hostGroups.yml not found!"
    echo "Bailing out now, check cap output."
    exit 1
else
   cp $CAPROOT/working/nagios/compass_combined_hostGroups.yml $ANSIBLEROOT/from_cap/hostGroups.yml
fi

if [ ! -f $CAPROOT/working/nagios/compass_combined_hosts.yml ]; then
    echo "$CAPROOT/working/nagios/compass_combined_hosts.yml not found!"
    echo "Bailing out now, check cap output."
    exit 1
else
   cp $CAPROOT/working/nagios/compass_combined_hosts.yml $ANSIBLEROOT/nagios-ansible/from_cap/hosts.yml
fi


# move into ansible root and push up the new configs to nagios server
cd $ANSIBLEROOT
ansible-playbook -v -i ./hosts deploy_configuration.yaml 

echo done
