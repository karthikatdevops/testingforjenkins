#build logback.xml
#	place it in JETTY_HOME/config
#
#build logback-access.xml
#	place it in JETTY_HOME/etc
#
#build jetty-logging.xml
#	place it in JETTY_HOME/etc
#
#find replace settings in etc/jetty.xml (include realm)
#
#get logback jars -> JETTY_HOME/lib/ext

task :createLogback do
	create_logback_xml
	create_logging_properties
	disable_jetty_logging_xml
	create_logback_access_xml
	modify_jetty_xml
	fetch_logging_jars
  set_logback_level
end

task :createLogback_jetty8 do
	create_logback_xml
#	create_logging_properties
	disable_jetty_logging_xml
#	create_logback_access_xml
#	modify_jetty_xml
#	fetch_logging_jars
if app == "commerceDataService"
  modify_jetty8_xml
end 
  set_logback_level
end


task :createLogback_solr do
	create_logback_solr_xml
	create_logging_properties
	disable_jetty_logging_xml
	create_logback_access_xml
	modify_jetty_xml
	fetch_logging_jars
        set_logback_level
end

task :createLogback_clover do
	create_logback_xml
#	create_logging_properties
	disable_jetty_logging_xml
#	create_logback_access_xml
#	modify_jetty_xml
#	fetch_logging_jars
  set_logback_level
end

task :createLogback_mice do
        #create_logback_xml # no AsyncAppender, so use the shortened logback (the solr task) instead
        create_logback_solr_xml
        create_logging_properties
        disable_jetty_logging_xml
        create_logback_access_xml
        modify_jetty_xml
        fetch_logging_jars
  set_logback_level
end

task :create_logback_xml do
  logger.info "TASK: Entered create_logback_xml in logback.rb"
logback_string1 = <<-logbackString1
<?xml version="1.0" encoding="UTF-8"?>
<!-- MANAGED BY CAPISTRANO -->
<configuration>
  <jmxConfigurator/>
  <property name="ARCDIR" value="archived_logs"/>

  <appender name="rootOutAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="${theplatform.log.dir}/root_out.log"/>
logbackString1

logback_string_object_not_found = <<-logbackStringObjectNotFound
    <filter class="ch.qos.logback.core.filter.EvaluatorFilter">
      <evaluator>
        <expression>com.theplatform.data.api.exception.ObjectNotFoundException.class.isInstance(throwable)</expression>
      </evaluator>
      <onMatch>DENY</onMatch>
    </filter>
logbackStringObjectNotFound

logback_string_blocking_queue_consumer = <<-logbackStringBlockingQueueConsumer
    <filter class="ch.qos.logback.core.filter.EvaluatorFilter">
      <evaluator name="loggingTaskEval">
        <expression>
          logger.contains("BlockingQueueConsumer") &amp;&amp; level &lt; WARN
        </expression>
      </evaluator>
      <OnMatch>DENY</OnMatch>
    </filter>
logbackStringBlockingQueueConsumer

sportsFeed_log_file = <<-sportsFeedlogfile
  <appender name="sportsIngestWebServiceXmlInputLog" class="ch.qos.logback.core.rolling.RollingFileAppender">
      <param name="File" value="logs/SportsIngest-feeds.log"/>
      <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
        <FileNamePattern>logs/SportsIngest-feeds.log.%d{yyyy-MM-dd}</FileNamePattern>
        <MaxHistory>5</MaxHistory>
      </rollingPolicy>
        <layout class="ch.qos.logback.classic.PatternLayout">
        <!-- pattern is just: Message\n -->
        <Pattern>%m%n</Pattern>
     </layout>
  </appender>
  <appender name="nascarServiceLog" class="ch.qos.logback.core.rolling.RollingFileAppender">
	    <param name="File" value="${theplatform.log.dir}/NascarServiceLog.log"/>
	    <filter class="com.theplatform.module.logging.extension.logback.filter.LevelMatchFilter"/>
	    <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
	        <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/NascarServiceLog.log.%d{yyyy-MM-dd}</FileNamePattern>
	        <MaxHistory>7</MaxHistory>
	    </rollingPolicy>
	    <layout class="ch.qos.logback.classic.PatternLayout">
	        <Pattern>%d %-5p [%t] %c: %m%n</Pattern>
	    </layout>
	</appender>

	<appender name="nascarLiveFeedLog" class="ch.qos.logback.core.rolling.RollingFileAppender">
	    <param name="File" value="${theplatform.log.dir}/NascarLiveFeed.log"/>
	    <filter class="com.theplatform.module.logging.extension.logback.filter.LevelMatchFilter"/>
	    <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
	        <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/NascarLiveFeed.log.%d{yyyy-MM-dd}</FileNamePattern>
	        <MaxHistory>7</MaxHistory>
	    </rollingPolicy>
	    <layout class="ch.qos.logback.classic.PatternLayout">
	        <Pattern>%d : %n%m%n</Pattern>
	    </layout>
	</appender>
  <logger name="XmlInputLogger" level="INFO" additivity="false" >
      <appender-ref ref="sportsIngestWebServiceXmlInputLog"/>
  </logger>
  	<!-- Loggers for NASCAR -->
	<logger name="com.theplatform.web.tv.sportsingest.impl.nascar" level="DEBUG" additivity="true">
	    <appender-ref ref="nascarServiceLog" />
	</logger>
	<logger name="com.theplatform.web.tv.sportsingest.impl.nascar.NascarLiveJson" level="DEBUG" additivity="false">
	    <appender-ref ref="nascarLiveFeedLog" />
	</logger>
sportsFeedlogfile
ingestWS_log_file = <<-ingestWSFeedlogfile
<contextListener class="ch.qos.logback.classic.jul.LevelChangePropagator"/>
	<appender name="sampleWebServiceLog" class="ch.qos.logback.core.rolling.RollingFileAppender">
                <param name="File" value="logs/IngestService.log"/>
                <filter class="com.theplatform.module.logging.extension.logback.filter.LevelMatchFilter"/>
                <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <FileNamePattern>logs/IngestService.log.%d{yyyy-MM-dd}</FileNamePattern>
            <!-- keep 7 days worth of history -->
            <MaxHistory>7</MaxHistory>
        </rollingPolicy>
                <layout class="ch.qos.logback.classic.PatternLayout">
                        <Pattern>%d %-5p [%t] %c: %m%n</Pattern>
        </layout>
        </appender>
ingestWSFeedlogfile

 partnerIngestWS_log_file = <<-partnerIngestWSFeedlogfile
 <contextListener class="ch.qos.logback.classic.jul.LevelChangePropagator"/>
         <appender name="sampleWebServiceLog" class="ch.qos.logback.core.rolling.RollingFileAppender">
                 <param name="File" value="logs/parnetIngestService.log"/>
                 <filter class="com.theplatform.module.logging.extension.logback.filter.LevelMatchFilter"/>
                 <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
             <FileNamePattern>logs/partnerIngestService.log.%d{yyyy-MM-dd}</FileNamePattern>
             <!-- keep 7 days worth of history -->
             <MaxHistory>7</MaxHistory>
         </rollingPolicy>
                 <layout class="ch.qos.logback.classic.PatternLayout">
                         <Pattern>%d %-5p [%t] %c: %m%n</Pattern>
         </layout>
         </appender>
 partnerIngestWSFeedlogfile


logback_string2 = <<-logbackString2
    <filter class="com.theplatform.module.logging.extension.logback.filter.LevelMatchFilter"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/root_out.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p [%t] %c: %m%n</Pattern>
    </layout>
  </appender>
  <appender name="#{app}WebAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="${theplatform.log.dir}/#{app}-web.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/#{app}-web.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p [%t] %c: %m%n</Pattern>
    </layout>
  </appender>
  <appender name="sampleNotificationsWebAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="${theplatform.log.dir}/Notifications-web.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/Notifications-web.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p [%t] %c: %m%n</Pattern>
    </layout>
  </appender>
  <appender name="#{app}SearchAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="${theplatform.log.dir}/#{app}-search.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/#{app}-search.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p [%t] %c: %m%n</Pattern>
    </layout>
  </appender>
  <appender name="#{app}rlstatAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="${theplatform.log.dir}/#{app}-rlstat.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/#{app}-rlstat.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p %m%n</Pattern>
    </layout>
  </appender>

  <appender name="DebugAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="${theplatform.log.dir}/customJDBC.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/root_out.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d INFO [%t] %c: %m%n</Pattern>
    </layout>
  </appender>

  <appender name="asyncRootOutAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="rootOutAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="async#{app}RequestAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="#{app}RequestAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="async#{app}PersistenceAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="#{app}PersistenceAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="async#{app}WebAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="#{app}WebAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncSampleNotificationsWebAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="sampleNotificationsWebAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="async#{app}SearchAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="#{app}SearchAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="async#{app}Appender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="#{app}Appender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="async#{app}rlstatAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="#{app}rlstatAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncSqlAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="SqlAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncDebugAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="DebugAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>

  <logger name="com.theplatform.module.logging.extension.logback.appender.AsyncAppender" level="WARN" additivity="false">
    <appender-ref ref="async#{app}Appender"/>
  </logger>
  <logger name="com.theplatform.data.persistence.logging" level="WARN" additivity="false">
    <appender-ref ref="async#{app}Appender"/>
  </logger>
  <!-- Logger for sql logging. -->
  <logger name="com.theplatform.data.persistence.logging.ConsoleSqlLoggingContext" level="WARN" additivity="false">
    <appender-ref ref="asyncSqlAppender"/>
  </logger>
  <!-- Logger for request logging. -->
  <logger name="com.theplatform.data.endpoint.DataServiceEndpoint" level="DEBUG" additivity="false">
    <appender-ref ref="async#{app}RequestAppender"/>
  </logger>
  <!-- Logger for persistence logging. -->
  <logger name="com.theplatform.data.persistence.logging.PersistenceEventLogger.logger" level="WARN" additivity="false">
    <appender-ref ref="async#{app}PersistenceAppender"/>
  </logger>
  <!-- Logger for web logging. -->
  <logger name="com.theplatform.module.requestlogger.RequestBodyLogger.logger" level="DEBUG" additivity="false">
    <appender-ref ref="async#{app}WebAppender"/>
  </logger>
  <!-- Logger for notifications web logging. -->
  <logger name="com.theplatform.module.requestlogger.RequestBodyLogger.logger.notifications" level="DEBUG" additivity="false">
    <appender-ref ref="asyncSampleNotificationsWebAppender"/>
  </logger>
  <!-- Logger for search logging. -->
  <logger name="com.theplatform.module.requestlogger.RequestLogger.logger.search" level="DEBUG" additivity="false">
    <appender-ref ref="async#{app}SearchAppender"/>
  </logger>
  <!-- Logger for rlstat logging. -->
  <logger name="requestLog" level="DEBUG" additivity="false">
    <appender-ref ref="async#{app}rlstatAppender"/>
  </logger>
  <logger name="org.springframework" level="WARN" />
  <logger name="org.hibernate" level="WARN" />
  <logger name="org.mortbay" level="INFO"/>
  <logger name="org.apache" level="INFO"/>
  <logger name="com.mchange.v2.async.ThreadPoolAsynchronousRunner" level="HARDCODED_ERROR" />
  <logger name="com.theplatform.data.api" level="INFO" additivity="false">
    <appender-ref ref="asyncRootOutAppender"/>
  </logger>
  <logger name="com.theplatform.web.api" level="INFO" additivity="false">
    <appender-ref ref="asyncRootOutAppender"/>
  </logger>
  <logger name="com.theplatform.jdbc.log.LoggingStatement" level="#{custom_JDBC_logging_level}" additivity="true">
    <appender-ref ref="asyncDebugAppender"/>
  </logger><!-- no longer needed in 2.5 DSS
  <logger name="org.hibernate.jdbc.AbstractBatcher" level="#{custom_JDBC_logging_level}" additivity="false">
    <appender-ref ref="asyncDebugAppender"/>
  </logger>-->
  <root level="INFO">
    <appender-ref ref="asyncRootOutAppender"/>
  </root>
  #{'<logger name="com.theplatform.data.api.client" level="WARN"/>
  <logger name="com.theplatform.contrib.client.listener.DataServiceClientLogAdapter" level="WARN"/>' if app == "combineService" }

logbackString2


my_logback_file = File.open("working/#{app}-logback", 'w')
my_logback_file.puts "#{logback_string1}"
if app == "entityDataService" || app == "entityIngest" || app == "linearDataService" || app == "linearIngest" || app == "jobDataService" || app == "offerDataService" || app == "offerIngest" || app == "locationDataService" || app == "locationIngest" || app == "idDataService" || app == "menuDataService"
  my_logback_file.puts "#{logback_string_object_not_found}"
end
if app == "consistencyWebService"
  my_logback_file.puts "#{logback_string_blocking_queue_consumer}"
end
my_logback_file.puts "#{logback_string2}"
if app == "sportsIngestWebService"
  my_logback_file.puts "#{sportsFeed_log_file}"
  my_logback_file.puts "</configuration>"
elsif app == "ingestWebService"
   my_logback_file.puts "#{ingestWS_log_file}"
  my_logback_file.puts "</configuration>"
elsif app == "partnerIngestWebService"
   my_logback_file.puts "#{partnerIngestWS_log_file}"
  my_logback_file.puts "</configuration>"
else
  my_logback_file.puts "</configuration>"
end
my_logback_file.close
upload("working/#{app}-logback","#{basedir}/jetty-#{app}/config/logback.xml")
run "sudo chmod 770 #{basedir}/jetty-#{app}/config/logback.xml"
run "mkdir -p #{basedir}/jetty-#{app}/logs/archived_logs"
run "chmod 775 #{basedir}/jetty-#{app}/logs/archived_logs"
end # end of create_logback_xml task


task :create_logback_solr_xml do
  logger.info "TASK: Entered create_logback_solr_xml in logback.rb"
logback_string = <<-logbackString
<!-- MANAGED BY CAPISTRANO -->
<configuration debug="true">
  <jmxConfigurator/>
  <property name="ARCDIR" value="archived_logs"/>

  <appender name="rootOutAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="${theplatform.log.dir}/root_out.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/root_out.log.%d{yyyy-MM-dd}</FileNamePattern>
     <MaxHistory>3</MaxHistory>
    </rollingPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p [%t] %c: %m%n</Pattern>
    </layout>
  </appender>

  <appender name="mortbayAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="${theplatform.log.dir}/mortbay.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/mortbay.log.%d{yyyy-MM-dd}</FileNamePattern>
     <MaxHistory>3</MaxHistory>
    </rollingPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p [%t] %c: %m%n</Pattern>
    </layout>
  </appender>

  <logger name="org.mortbay" level="ERROR" additivity="false">
    <appender-ref ref="mortbayAppender"/>
  </logger>

  <logger name="org.apache" level="ERROR"/>
  <root level="WARN">
    <appender-ref ref="rootOutAppender"/>
  </root>
</configuration>
logbackString



my_logback_file = File.open("working/#{app}-logback", 'w')
my_logback_file.puts "#{logback_string}"
my_logback_file.close
upload("working/#{app}-logback","#{basedir}/jetty-#{app}/config/logback.xml")
run "sudo chmod 770 #{basedir}/jetty-#{app}/config/logback.xml"
run "mkdir -p #{basedir}/jetty-#{app}/logs/archived_logs"
run "chmod 770 #{basedir}/jetty-#{app}/logs/archived_logs"
end # end of create_logback_solr_xml task


task :create_logging_properties do
  logger.info "TASK: Entered create_logging_properties in logback.rb"
  logprop_string = <<-logpropString
############################################################
# MANAGED BY CAPISTRANO
############################################################
.level = WARNING
java.util.logging.FileHandler.pattern = /tmp/dataservices.log
java.util.logging.FileHandler.limit = 50000
java.util.logging.FileHandler.count = 1
java.util.logging.FileHandler.formatter = java.util.logging.SimpleFormatter
logpropString

  upload(StringIO.new(logprop_string),"#{basedir}/jetty-#{app}/config/logging.properties", :via => :scp, :mode => 0770)

end # end of create_logging_properties task

task :modify_jetty8_xml do
jetty8_xml = <<-here
<?xml version="1.0"?>
<!DOCTYPE Configure PUBLIC "-//Jetty//Configure//EN" "http://www.eclipse.org/jetty/configure.dtd">
<Configure id="Server" class="org.eclipse.jetty.server.Server">

    <!-- =========================================================== -->
    <!-- Server Thread Pool                                          -->
    <!-- =========================================================== -->
    <Set name="ThreadPool">
      <!-- Default queued blocking threadpool -->
      <New class="org.eclipse.jetty.util.thread.QueuedThreadPool">
        <Set name="minThreads">10</Set>
        <Set name="maxThreads">200</Set>
        <Set name="detailedDump">false</Set>
      </New>
    </Set>

    <!-- =========================================================== -->
    <!-- Set connectors                                              -->
    <!-- =========================================================== -->

    <Call name="addConnector">
      <Arg>
          <New class="org.eclipse.jetty.server.nio.SelectChannelConnector">
            <Set name="host"><Property name="jetty.host" /></Set>
            <Set name="port"><Property name="jetty.port" default="8080"/></Set>
            <Set name="maxIdleTime">300000</Set>
            <Set name="Acceptors">2</Set>
            <Set name="statsOn">false</Set>
            <Set name="confidentialPort">8443</Set>
            <Set name="lowResourcesConnections">20000</Set>
            <Set name="lowResourcesMaxIdleTime">5000</Set>
            <Set name="requestHeaderSize">#{jetty_http_headerbuffersize}</Set>
          </New>
      </Arg>
    </Call>
    <!-- =========================================================== -->
      <!-- Set handler Collection Structure                            -->
      <!-- =========================================================== -->
      <Set name="handler">
        <New id="Handlers" class="org.eclipse.jetty.server.handler.HandlerCollection">
          <Set name="handlers">
           <Array type="org.eclipse.jetty.server.Handler">
             <Item>
               <New id="Contexts" class="org.eclipse.jetty.server.handler.ContextHandlerCollection"/>
             </Item>
           </Array>
          </Set>
        </New>
      </Set>

      <!-- =========================================================== -->
      <!-- extra options                                               -->
      <!-- =========================================================== -->
      <Set name="stopAtShutdown">true</Set>
      <Set name="sendServerVersion">false</Set>
      <Set name="sendDateHeader">true</Set>
      <Set name="gracefulShutdown">1000</Set>
      <Set name="dumpAfterStart">false</Set>
      <Set name="dumpBeforeStop">false</Set>

  </Configure>
  here
upload(StringIO.new(jetty8_xml),"#{basedir}/jetty-#{app}/etc/jetty.xml", :via => :scp)
end # end of modify_jetty8_xml task




task :modify_jetty_xml do

jetty_xml = <<-here
<?xml version="1.0"?>

<Configure id="Server" class="org.mortbay.jetty.Server">
    <Set name="ThreadPool">

      <New class="org.mortbay.thread.QueuedThreadPool">
        <Set name="minThreads">10</Set>
        <Set name="maxThreads">200</Set>
        <Set name="lowThreads">20</Set>
        <Set name="SpawnOrShrinkAt">2</Set>
      </New>

    </Set>

    <Call name="addConnector">
      <Arg>
          <New class="org.mortbay.jetty.nio.SelectChannelConnector">
            <Set name="host"><SystemProperty name="jetty.host"/></Set>
            <Set name="port"><SystemProperty name="jetty.port" default="8080"/></Set>
            <Set name="maxIdleTime">#{jetty_maxIdleTime}</Set>
            <Set name="Acceptors">2</Set>
            <Set name="statsOn">false</Set>
            <Set name="confidentialPort">8443</Set>
	          <Set name="lowResourcesConnections">5000</Set>
	          <Set name="lowResourcesMaxIdleTime">5000</Set>
	          <Set name="headerBufferSize">16384</Set>
	          <Set name="requestBufferSize">#{jetty_requestBufferSize}</Set>
	          <Set name="responseBufferSize">#{jetty_responseBufferSize}</Set>
          </New>
      </Arg>
    </Call>

    <Set name="handler">
      <New id="Handlers" class="org.mortbay.jetty.handler.HandlerCollection">
        <Set name="handlers">
         <Array type="org.mortbay.jetty.Handler">
           <Item>
             <New id="Contexts" class="org.mortbay.jetty.handler.ContextHandlerCollection"/>
           </Item>
           <Item>
             <New id="DefaultHandler" class="org.mortbay.jetty.handler.DefaultHandler"/>
           </Item>
           <Item>
             <New id="RequestLog" class="org.mortbay.jetty.handler.RequestLogHandler"/>
           </Item>
         </Array>
        </Set>
      </New>
    </Set>

    <Call name="addLifeCycle">
      <Arg>
        <New class="org.mortbay.jetty.deployer.ContextDeployer">
          <Set name="contexts"><Ref id="Contexts"/></Set>
          <Set name="configurationDir"><SystemProperty name="jetty.home" default="."/>/contexts</Set>
          <Set name="scanInterval">5</Set>
        </New>
      </Arg>
    </Call>

    <Call name="addLifeCycle">
      <Arg>
        <New class="org.mortbay.jetty.deployer.WebAppDeployer">
          <Set name="contexts"><Ref id="Contexts"/></Set>
          <Set name="webAppDir"><SystemProperty name="jetty.home" default="."/>/webapps</Set>
	  <Set name="parentLoaderPriority">false</Set>
	  <Set name="extract">true</Set>
	  <Set name="allowDuplicates">false</Set>
          <Set name="defaultsDescriptor"><SystemProperty name="jetty.home" default="."/>/etc/webdefault.xml</Set>
        </New>
      </Arg>
    </Call>

    <Set name="UserRealms">
      <Array type="org.mortbay.jetty.security.UserRealm">
        <Item>
          <New class="org.mortbay.jetty.security.HashUserRealm">
            <Set name="name">thePlatform</Set>
            <Set name="config"><SystemProperty name="jetty.home" default="."/>/etc/realm.properties</Set>
            <Set name="refreshInterval">0</Set>
          </New>
        </Item>
      </Array>
    </Set>

    <Ref id="RequestLog">
      <Set name="requestLog">
        <New id="RequestLogImpl" class="ch.qos.logback.access.jetty.RequestLogImpl">
        </New>
      </Set>
    </Ref>

    <Set name="stopAtShutdown">true</Set>
    <Set name="sendServerVersion">true</Set>
    <Set name="sendDateHeader">true</Set>
    <Set name="gracefulShutdown">1000</Set>
</Configure>
here

File.open("working/#{app}-jetty.xml.new", 'w') {|f| f.write(jetty_xml) }
upload("working/#{app}-jetty.xml.new","#{basedir}/jetty-#{app}/etc/jetty.xml")
end # end of modify_jetty_xml task

task :fetch_logging_jars do
  logger.info "TASK: Entered LOGBACK--- fetching_logging_jars in logback.rb"
 # set :logback_version, "0.9.14" unless exists? :logback_version
  set :logback_version, "0.9.24" unless exists? :logback_version
   logger.info "---- just set logback_version "
   logger.info "--------------->>>>> LOGBACK--- #{logback_version} "

  MyBigBottleofJars = [
    "logback-core-#{logback_version}.jar",
    "logback-classic-#{logback_version}.jar",
    "logback-access-#{logback_version}.jar"
    ]

    logger.info ">>>>> LOGBACK--- clearing our any existing logback jars from jetty before we upload new ones...."
    begin
      logger.info ">>>>> LOGBACK--- removing in lib/ext"
     run "rm -rf #{basedir}/jetty-#{app}/lib/ext/logback-*"
      logger.info ">>>>> LOGBACK--- removing in lib"
     run "rm -rf #{basedir}/jetty-#{app}/lib/logback-*"
     rescue
        logger.info "Removing logback jars failed for some reason..."
    end

    MyBigBottleofJars.each { |x|
      logger.info "Starting upload for: #{x}"
      begin
        run "cd #{basedir}/jetty-#{app}/lib/ext && wget #{wget_params}  #{repo}/logback/#{logback_version}/#{x}"
      rescue
        logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
        `wget #{wget_params} #{repo}/logback/#{logback_version}/#{x} -O working/#{x} `
        upload("working/#{x}","#{basedir}/jetty-#{app}/lib/ext", :via => :scp)
      end
      logger.info "Just completed upload for: #{x}"
      }

    begin
      logger.info "TASK: Entered SLF4J--- fetching_logging_jars in logback.rb"
      run "cd #{basedir}/jetty-#{app}/lib/ext && wget #{wget_params}  #{repo}/slf4j/1.5.6/jul-to-slf4j-1.5.6.jar"
    rescue
      logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
      `wget #{wget_params} #{repo}/slf4j/1.5.6/jul-to-slf4j-1.5.6.jar -O working/jul-to-slf4j-1.5.6.jar`
      upload("working/jul-to-slf4j-1.5.6.jar","#{basedir}/jetty-#{app}/lib/ext", :via => :scp)
    end

end # end of fetch_logging_jars task


task :disable_jetty_logging_xml do
  run "perl -pi -e 's#\\$\\{JETTY_HOME\\}/etc/jetty-logging.xml##' #{basedir}/jetty-#{app}/bin/jetty.sh"
  run "if [ -e #{basedir}/jetty-#{app}/etc/jetty.conf ]; then perl -pi -e 's#etc/jetty-logging.xml##' #{basedir}/jetty-#{app}/etc/jetty.conf; fi"

end # end of disable_jetty_logging_xml task

task :create_logback_access_xml do
  logback_access_pattern = '%h %l %u %t{yyyy-MM-dd HH:mm:ss} "%r" %s %b "%i{Referer}" "%i{User-Agent}"'
  if exists?(:logback_access_pattern_override)
    logback_access_pattern = logback_access_pattern_override
  end
  logback_access_string = <<-lbaccessmark
<?xml version="1.0"?>
<!-- MANAGED BY CAPISTRANO -->
<configuration debug="false">
  <property name="ARCDIR" value="archived_logs"/>
  <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <File>logs/access.log</File>
    <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
      <FileNamePattern>logs/${ARCDIR}/access.%d{yyyy-MM-dd}.log</FileNamePattern>
     <MaxHistory>3</MaxHistory>
    </rollingPolicy>
    <layout class="ch.qos.logback.access.PatternLayout">
      <Pattern>#{logback_access_pattern}</Pattern>
    </layout>
  </appender>
  <appender-ref ref="FILE"/>
</configuration>

lbaccessmark

  File.open("working/#{app}-logback-access.xml", 'w') {|f| f.write(logback_access_string) }
  upload("working/#{app}-logback-access.xml","#{basedir}/jetty-#{app}/etc/logback-access.xml")
end # end of create_logback_access_xml task

task  :set_logback_level do
   run  " sed -i_back -e 's,level=\"ERROR\",level=\"#{logback_level_error}\",g' -e 's,level=\"INFO\",level=\"#{logback_level_info}\",g' -e 's,level=\"WARN\",level=\"#{logback_level_warn}\",g'  -e 's,level=\"DEBUG\",level=\"#{logback_level_debug}\",g' #{basedir}/jetty-#{app}/config/logback.xml "
   run  " sed -i_back -e 's,level=\"HARDCODED_ERROR\",level=\"ERROR\",g' #{basedir}/jetty-#{app}/config/logback.xml "
   if exists?(:logback_root_level)
     run  " sed -i_back -e 's,<root level=\".*\">,<root level=\"#{logback_root_level}\">,g' #{basedir}/jetty-#{app}/config/logback.xml "
   end
end # end of set_logback_level

logger.info ">>>>> loaded logback"
