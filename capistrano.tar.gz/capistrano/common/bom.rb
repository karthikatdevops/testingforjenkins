
def git_branch
  return `git branch | grep '*'`.chomp.split(' ')[1]
end

# package str from BOM
def get_artifact_url(package_str)
  package_arr = package_str.split('/')
  if env.include?("merdevl") || env.include?("cmpstk") || ["udbprodNGB", "merqaFo", "merqaTest104"].include?(env)
    res = package_str
  elsif hiera('flat_artifact_url')
    res = [hiera('flat_artifact_url'), package_arr.last].join('/')
  else
    idx = package_arr.index("repositories")
    idx = package_arr.index("artifactory") if idx.nil?
    res = [hiera('maven_repo'), package_str.split('/compass-merlin-releases/').last.split('/compass-maps-releases/').last.split('/compass-udb-releases/').last.split('/compass-all-repos/').last].join('/')
  end
  res
end

  logger.info "Determing where the bom is for this deployment......"

  #
  # Note: BAMA is the BOM Mangement Application
  # More info: https://www.teamccp.com/confluence/display/xcal/BAMA+Home
  #


  if exists?(:bamaBOM)
    logger.info ">>>>>>>>> Using BAMA"
    logger.info "BOM = #{bom}"
    if exists?(:bamaURL)
      bama_url = "#{bamaURL}"
    else
      # some data centers use a NAT address
      bama_url = [hiera('bama_url'), 'bom_versions/', bom, '/xml.xml'].join
    end
    logger.info "BAMA URL = #{bama_url}"
    bomDoc = Nokogiri::XML(
      open(bama_url)
    )
    logger.info "just pulled and parsed a BOM from BAMA..."
  elsif exists?(:hieraBOM)
    set_vars_from_hiera(['bom'])
    raise "No bom specified in hiera!" unless bom
    bama_url = [hiera('bama_url'), 'bom_versions/', bom, '/xml.xml'].join
    logger.info "BAMA URL = #{bama_url}"
    bomDoc = Nokogiri::XML(
      open(bama_url)
    )
    logger.info "just pulled and parsed a BOM from BAMA..."
  elsif exists?(:localBOM)
    logger.info "Found the variable localBOM set to: >#{localBOM}< so we'll use it"
    logger.info "BOM = #{bom}"
    io = File.open("#{bom}", 'r')
    bomDoc = Nokogiri::XML(io)
  else
   raise "use :bamaBOM, :hieraBOM, or :localBOM"
  end


  if exists?(:dontCheckCapVersion) && dontCheckCapVersion.to_s == "true"
  logger.info "OK, I'm SKIPPING the cap version check for this deployment because you know what you are doing...."
  cap_version=bomDoc.search("/bom/services/service[@name='capistrano']/version/text()").text
  logger.info "BOM specified capistrano branch verison: #{cap_version}"
  logger.info "Your local capistrano branch verison:    #{git_branch}"

  else
    if !bomDoc.nil?
      logger.info "Checking the capistrano to make sure it is the same as verison defined in BOM....."
      cap_version=bomDoc.search("/bom/services/service[@name='capistrano']/version/text()").text
      logger.info "BOM specified capistrano branch verison #{cap_version}"
      if defined?(cap_version) && !cap_version.nil? && !cap_version.empty?
        cur_ver=git_branch
        if ! cur_ver.eql?(cap_version)
          logger.info "ERROR*************************************************************************************************"
          logger.info "ERROR: Your local capistrano branch \"#{cur_ver}\" does not match the branch defined in BOM"
          logger.info "ERROR: Please check out the right capistrano branch version \"#{cap_version}\""
          logger.info "ERROR*************************************************************************************************"
          exit 2
        end
      else
        logger.info "ERROR*********************************************************************************************************"
        logger.info "ERROR: There is no capistarno branch version specified in BOM."
        logger.info "ERROR: Please run ./post2bama.rb -version={capistrano branch version}  under capistrano to add the cap version"
        logger.info "ERROR: Please also make sure to attach it to the BOM"
        logger.info "ERROR*********************************************************************************************************"
        exit 2
      end
    end # bomDoc
  end # if dontCheckCapVersion

task :read_bom do
  logger.info "TASK: [[ READ BOM ]]"
  logger.info "  APP ---> #{app}"
  logger.info " BOM ----> #{bom}"
  regularService = app
  if (bom =~ /GNOTE/)
     aliasservice = app
     if aliasservice == "idDataService"
	     app = "gracenoteidDataService"
     elsif aliasservice == "consistencyWebService"
	     app = "gracenoteconsistencyWebService"
     elsif  aliasservice == "offerWebService"
	     app = "gracenoteofferWebService"
     elsif aliasservice == "scheduledIngestWebService"
	     app = "gracenotescheduledIngestWebService"
     elsif  aliasservice == "combineService"
	     app = "gracenotescombineWebService"
     elsif  aliasservice == "caretakerWebService"
       app = "gracenoteCaretakerWebService"
     else
       app = regularService
     end
  else
    app = regularService
 end
  if exists?(:bamaBOM)
    logger.info "BAMA URL = #{bama_url}"
  end
  set :service_version, bomDoc.search("service[@name='#{app}']/version").text
  puts service_version
  set :package, bomDoc.search("service[@name='#{app}']/package").text
  logger.info   "  PACKAGE ---> #{bomDoc.search("service[@name='#{app}']/package").text}"
  logger.info   "  VERSION ---> #{bomDoc.search("service[@name='#{app}']/version").text}"
  set :artifact_file, package.gsub( /.*\//, "")
  set :url, get_artifact_url(package)

  logger.info "  REPO URL ---> #{url}"
  logger.info "  Environment ---> #{env}"
  logger.info "TASKEND: [[ READ BOM ]]"
end

task :read_bom_cloverServer do
  logger.info "TASK: [[ READ CloverServer BOM ]]"
  set :service_version, bomDoc.search("service[@name='#{app}']/version").text
  set :package, bomDoc.search("service[@name='#{app}']/package").text
  puts "read_bom_cloverServer.package -> #{package}"
  set :artifact_file, package.gsub( /.*\//, "")
  set :url, get_artifact_url(package)

  logger.info "DEBUG: Setting CloverSERVER URL: #{url} "

  # Build the array of Clover Graphs that we need to go back and deploy
  grapharray = Array.new
  logger.info " > BOM.RB - starting to build new graph array..."
  if  (bom =~ /GNOTE/)
    @collection = bomDoc.search("//service[starts-with(@name,'gracenoteingestClover') or starts-with(@name,'gracenoteIngestClover')]/package")
  else
    @collection = bomDoc.search("service[@name^='ingestClover']/package")
  end
  @collection.each do |myelement|
    logger.info " > here is an element: #{myelement.text.gsub( /.*\//, "")}"
   if get_artifact_url(myelement.text) !~ /db-migration/
    grapharray << get_artifact_url(myelement.text)
   end
  end
  logger.info "  done with building grapharray"

  if exists?(:singleGraph)
    grapharray.delete_if {|x| not x.include?(singleGraph)}
  end
  set :graphList, grapharray
  puts "read_bom_cloverServer.package -> #{graphList}"
  logger.info "  end task: read_bom_cloverServer"
end

task :write_local_service_version do
  logger.info "TASK: BOM: :write_local_service_version"
  if confType.include?("udb") or confType.include?("cmpstkNGB") or confType.include?("cmpstkRex")
    set :fullAppName, app
  else
    set :fullAppName, "jetty-#{app}"
  end
  set :service_version, bomDoc.search("service[@name='#{app}']/version").text
  logger.info "Writing service version, checking: working/#{app}-#{service_version}/version.txt"
  `if [ -f working/#{app}-#{service_version}/version.txt ] ;then rm -rf working/#{app}-#{service_version};else echo $?; fi`
  `mkdir -p working/#{app}-#{service_version} ; echo #{service_version} #{bom} \> working/#{app}-#{service_version}/version.txt`
  logger.info "TASK: BOM: Just wrote out this version: echo #{service_version} #{bom} into working/#{app}-#{service_version}/version.txt"
end

task :write_service_version do
  logger.info "TASK: BOM: :write_service_version"
  set :service_version, bomDoc.search("service[@name='#{app}']/version").text
  # make these agnostic to apps that don't use jetty- in their name on the filesystem
  if confType.include?("udb") or confType.include?("cmpstkNGB") or confType.include?("cmpstkRex")
    set :fullAppName, app
  else
    set :fullAppName, "jetty-#{app}"
  end
  logger.info "Writing service version, checking: #{basedir}/jetty-#{app}/version/version.txt"
  run "if [ -f #{basedir}/#{fullAppName}/version/version.txt ] ;then rm #{basedir}/jetty-#{app}/version/version.txt;else echo $?; fi; true"
  run "mkdir -p #{basedir}/#{fullAppName}/version ; echo #{service_version} #{bom} \> #{basedir}/#{fullAppName}/version/version.txt"
  logger.info "TASK: BOM: Just wrote out this version: echo #{service_version} #{bom} into #{basedir}/#{fullAppName}/version/version.txt"
end

task :check_service_version do
  unless exists?(:force)
      set :force, "false"
  end
  
  unless exists?(:downgrade)
    set :downgrade, "false"
  end
  
  logger.info "running read service version"
  set :service_version, Gem::MerlinVersion.new(bomDoc.search("service[@name='#{app}']/version").text)
  if confType.include?("udb") or confType.include?("cmpstkNGB") or confType.include?("cmpstkRex") or app.include?("Indexer")
    set :fullAppName, app
  else
    set :fullAppName, "#{hiera('servlet_container')}-#{app}"
  end
  run "if [ ! -f #{basedir}/#{fullAppName}/version/version.txt ]; then cd #{basedir}/#{fullAppName}/version; touch version.txt; fi"
  set :current_service_version, Gem::MerlinVersion.new(capture("awk '{print $1}' #{basedir}/#{fullAppName}/version/version.txt || true").chop)
  logger.info "current service version is #{current_service_version}"
  logger.info "to be deployed service version is #{service_version}"
  logger.info "force is set to #{force}"
  if current_service_version == service_version && force == "false"
    print "service is already at the current version skipping #{app}\n"
    exit
  end

  if current_service_version > service_version && downgrade == 'false'
    print "service is at a higher version skipping #{app}.  Override with `-S downgrade=true`\n"
    exit
  end
end

task :get_service_version_from_node do
  logger.info "running get_service_version_from_node"
  if confType.include?("udb") or confType.include?("cmpstkNGB") or confType.include?("cmpstkRex") or app.include?("Indexer")
    set :fullAppName, app
  else
    set :fullAppName, "#{hiera('servlet_container')}-#{app}"
  end
  run "if [ ! -f #{basedir}/#{fullAppName}/version/version.txt ]; then cd #{basedir}/#{fullAppName}/version; touch version.txt; fi", :hosts => current_host_check
  set :current_service_version, Gem::MerlinVersion.new(capture("awk '{print $1}' #{basedir}/#{fullAppName}/version/version.txt || true", :hosts => current_host_check).chop)
  logger.info "current service version is #{current_service_version}"
  current_service_version
end

