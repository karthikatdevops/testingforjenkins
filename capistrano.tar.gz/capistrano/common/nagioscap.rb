name="nagios_HOLD"
#srini bollepalli
#cap update_nagios_merdevl -S env=merdevl -S svc=sportsDataService  -S nobom


services_ignore=["jiraSprintReport","udbMockService","miceGWTService","programIndex2","cloverServer","entityIndex","entityIndexer","jmxtrans","gdash","nginx","rabbitMQ","rabbitMGT","coatGWTService","entityIndexer","locationIndexer","linearIndexer","haproxy","oracle","imageRabbitMQ","imageRabbitMGT","alfred","commerceDataService","unuServer","tim","merlinSolr","imageWebService","monsterEntityDataService","imageIndex","imageDataService","imageIngest","imageIngestWebService","imageEventWebService","imageManagementWebService","imageBackOfficeReportingWebService","searchUpdaterWebService2","mongoDB","nagios","ppvGapReport","qamParityReport"]

   desc "used to list_srvs for the #{env} nagios configuration"
    task "list_srvs".to_sym do
       self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each{|tsk|
          service_name=tsk.fully_qualified_name.split("_")[1]
          if service_name.include?("jmxtrans") || service_name.include?("servicehost")
            next
          end
          #logger.info "Found task #{tsk.fully_qualified_name}"
          begin
             set :web_port, hiera("#{service_name}_web_port")
          rescue
            logger.info "#{service_name}_web_port is not defined."
            next
          end
          find_and_execute_task ("#{tsk.name}")
          find_servers_for_task(tsk,:roles => "#{service_name}".to_sym).each do |svr|
           # logger.info "server===#{svr.host}"
            set :s_host, "#{svr.host}"
            logger.info "#{s_host}:#{service_name}:#{web_port}"
          end
	}
    end
  desc "used to update_#{name}_#{env} configuration file"
  task "update_#{name}_#{env}".to_sym do
environments.each do |envname|
    File.delete("working/#{envname}-nagios_services.txt") if File.exist?("working/#{envname}-nagios_services.txt")
    output = File.open("working/#{envname}-nagios_services.txt", 'w')
    logger.level = Capistrano::Logger::INFO
    logger.info "M1 TASK: update_conf_#{name}_#{env}.to_sym do"
    
    if exists?(:noBom) or exists?(:nobom)
       logger.info "skipping read bom"
    else
       logger.info "There is no need to specify bom for this nagios deployment"
       exit
    end
    find_and_execute_task ("#{env}_#{name}")
    set :app, "#{name}"
    set :install_path, "working/#{name}"
    set :nagios_path, "/etc/#{name}/objects"
    logger.info "....Set install_path=#{install_path}"
    logger.info "clean local and remote old config files"
#    run "rm -f #{install_path}/#{env}.cfg"
#    run "rm -f #{install_path}/#{env}_hosts.cfg"
#    run "rm -f #{install_path}/#{env}_srvgrps.cfg"
    `if [ -d "working/#{name}" ]; then rm -fr working/#{name}; fi; mkdir -p working/#{name};`
    upstreams=Array.new
    hosts=Array.new
    srvcgrps=Array.new
    $sArray = Array.new
    self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each{|tsk|
      service_name=tsk.fully_qualified_name.split("_")[1]
      set :hiera_svc, service_name
      if exists?(:service) && !service_name.eql?(service)
        next
      end
      if services_ignore.include?(service_name)
        next
      end
      logger.info "Found task #{tsk.fully_qualified_name}"
      begin
         set :web_port, hiera("#{service_name}_web_port")
      rescue
        logger.info "#{service_name}_web_port is not defined."
        next
      end
      upstream_server_lines=""
      host_server_lines=""
      srvcgrp_server_lines=""
      find_and_execute_task ("#{tsk.name}")
      find_servers_for_task(tsk,:roles => "#{service_name}".to_sym).each do |svr|
	output << "#{service_name} #{svr.host}\n"
        logger.info "server===#{svr.host}"
	  if (!env.include?("cmpstkMerlin"))
                adr=`nslookup #{svr.host}|grep Address|grep -v "#"|cut -d ":" -f2`
                hostalias=svr.host
                host_server_line="use           linux-server\nhost_name         #{hostalias}\nalias             #{hostalias}\naddress           #{adr.lstrip.chomp}"
                host_server_lines << host_server_line << "\n        "
                $sArray << "#{hostalias},#{service_name}"
                upstream_server_line="host_name                 #{hostalias}\nservice_description               #{service_name}"
                upstream_server_lines << upstream_server_line << "\n        "
         else
                adr1=`nslookup #{svr.host}|grep Address|grep -v "#"|cut -d ":" -f2`
                host_server_line="use           linux-server\nhost_name         #{svr.host}\nalias              #{svr.host}\naddress           #{adr1.lstrip.chomp}"
                host_server_lines << host_server_line << "\n        "
                $sArray << "#{svr.host},#{service_name}"
                upstream_server_line="host_name                 #{svr.host}\nservice_description               #{service_name}"
                upstream_server_lines << upstream_server_line << "\n        "
         end

if (env == "a2gdevl") || (service_name != "availabilityResolutionService" && service_name != "digitalRightsLocker") && (env != "merdevlBo2") && (env != "cmpstkMerlinIngest")
      upstream = <<-UPSTREAM_STR
      define service {
	use                             servicecheck
	#{upstream_server_line}
           check_command                   check_http_md!#{web_port}!/#{service_name}/healthCheck
           }
      UPSTREAM_STR
elsif env == "a2gdevl" || service_name == "availabilityResolutionService"
upstream = <<-UPSTREAM_STR
      define service {
        use                             servicecheck
        #{upstream_server_line}"
           check_command                   check_http_md!#{web_port}!/healthCheck
           }
      UPSTREAM_STR
elsif env == "a2gdevl" || service_name == "digitalRightsLocker"
upstream = <<-UPSTREAM_STR
      define service {
        use                             servicecheck
        #{upstream_server_line}"
           check_command                   check_http_md!#{web_port}!/locker/healthCheck
           }
      UPSTREAM_STR
else 
      upstream = <<-UPSTREAM_STR
      define service {
	use                             servicecheck
	#{upstream_server_line}
	check_command                   check_http_md!#{web_port}!/#{service_name}/management/alive
	}
      UPSTREAM_STR
end

upstreams << upstream


#This is for creating host defs
	host = <<-HOST_STR
	define host{
#{host_server_line}
}
	HOST_STR
      hosts << host
      end
    }
#This is for creating service group defs
        srvcgroup = <<-SRVCGRP_STR
        define servicegroup {
servicegroup_name	#{env}
alias			#{env} Environment
members			#{$sArray.join(",")}
}
        SRVCGRP_STR
      srvcgrps << srvcgroup

    File.open("working/#{name}/#{env}.cfg",'w+'){|f| f.puts upstreams;}
    File.open("working/#{name}/#{env}_hosts.cfg",'w+'){|f| f.puts hosts.uniq;}
    File.open("working/#{name}/#{env}_srvgrps.cfg",'w+'){|f| f.puts srvcgrps;}
    roles.clear
#    find_and_execute_task("#{env}_#{name}")
#    run "sudo rm -f #{install_path}/#{env}.cfg"
#    run "sudo rm -f #{install_path}/#{env}_hosts.cfg"
#    run "sudo rm -f #{install_path}/#{env}_srvgrps.cfg"
#    run "if [ -d working ] ;then sudo mkdir working; fi"
#    run "sudo mkdir #{install_path}"
#    upload("#{install_path}/#{env}.cfg","#{install_path}/#{env}.cfg", :via => :scp,:recursive => true)
#    upload("#{install_path}/#{env}_hosts.cfg","#{install_path}/#{env}_hosts.cfg", :via => :scp,:recursive => true)
#    upload("#{install_path}/#{env}_srvgrps.cfg","#{install_path}/#{env}_srvgrps.cfg", :via => :scp,:recursive => true)
#    run "sudo mv #{install_path}/#{env}.cfg #{nagios_path}/; sudo chown nagios:nagios #{nagios_path}/#{env}.cfg; sudo chmod 644 #{nagios_path}/#{env}.cfg"
#    run "sudo mv #{install_path}/#{env}_hosts.cfg #{nagios_path}/; sudo chown nagios:nagios #{nagios_path}/#{env}_hosts.cfg; sudo chmod 644 #{nagios_path}/#{env}_hosts.cfg"
#    run "sudo mv #{install_path}/#{env}_srvgrps.cfg #{nagios_path}/; sudo chown nagios:nagios #{nagios_path}/#{env}_srvgrps.cfg; sudo chmod 644 #{nagios_path}/#{env}_srvgrps.cfg"
#    run "if [ `sudo /usr/sbin/nagios -v /etc/nagios/nagios.cfg|grep 'Total Errors'|awk '{print $3}'` -eq 0 ];then sudo /etc/init.d/nagios stop;sudo nohup /etc/init.d/nagios start;else echo 'There is configuration issue in nagios please use -v option in nagios to find what it is';exit 0;fi"
  end #end of task update_#{name}_#{env}
end
