#jmx_connect -h localhost -p 9209 <(echo 'set java_obj [  jmx_invoke -n -m thePlatform:application=serviceAccountDataService,name=clusterStatistics getPeers ]')
#set string_list [$java_obj getrange]
#puts $string_list
#jmx_close
#
#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9203 <( echo ' puts [ jmx_invoke -m thePlatform:application=linearDataService,name=clusterStatistics getMessagesSent ]' )
#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9203 <( echo 'puts [  jmx_invoke -m ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator getLoggerLevel root ]' )
#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9203 <( echo 'puts [  jmx_invoke -m ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator setLoggerLevel root DEBUG ]' )
#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9203 <( echo ' jmx_invoke -n -m thePlatform:application=linearDataService,name=cacheStatistics,cache=com.theplatform.data.cache.ResponseCacheImpl clearCache ' )
#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9203 <( echo ' puts [ jmx_invoke -m thePlatform:application=linearDataService,name=cacheStatistics,cache=com.theplatform.data.cache.ResponseCacheImpl getCacheSize ]' )

#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9202 <( echo ' puts [ jmx_invoke -m thePlatform:application=entityDataService,endpoint=entityDataService,name=aliveCheckConfiguration getForceDown ]' )
#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9202 <( echo ' puts [ jmx_invoke -m thePlatform:application=entityDataService,endpoint=entityDataService,name=aliveCheckConfiguration setForceDown true ]' )
#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9202 <( echo ' puts [ jmx_invoke -m thePlatform:application=entityDataService,endpoint=entityDataService,name=aliveCheckConfiguration setForceDown false ]' )

#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9221 <( echo ' jmx_invoke -n -m thePlatform:application=programAvailability,endpoint=programAvailability,name=dsResponseCache clear ' )

#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9203 <( echo 'puts [  jmx_invoke -m ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator reloadDefaultConfiguration ]' )

#java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p 9203 <( echo 'puts [  jmx_invoke -m com.sun.management:type=HotSpotDiagnostic dumpHeap <file> false ]' )

# def hosts_arg_specified? moved to common/orchestration.rb

task :jmxInvokeAndReturnAJavaObject do
  out = Array.new
  run "java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p #{hiera("#{app}_jmx_port")} <( echo \"set java_obj [  jmx_invoke -n -m #{arg} ] ; set string_list [ \\\$java_obj getrange ] ; puts \\\$string_list ; jmx_close;\")" do |channel, stream, data|
    out << channel[:host] + ": " + data.chomp
  end
  out.sort.each do |e|
    if e =~ /: $/
      next
    else
      puts e.gsub(/\{/, "\n  \{" )
    end
  end
end

task :jmxInvokeAndReturnAString do
  out = Array.new
  run "java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p #{hiera("#{app}_jmx_port")} <( echo \"puts [ jmx_invoke -m #{arg} ] ; jmx_close;\")" do |channel, stream, data|
     out << channel[:host] + ": " + data.chomp
  end
  out.sort.each do |e|
    if e =~ /: $/
      next
    else
      puts e
    end
  end
end

task :jmxInvoke do
  out = Array.new
  run "java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p #{hiera("#{app}_jmx_port")} <( echo \" jmx_invoke -m #{arg} ; jmx_close;\")" do |channel, stream, data|
     out << channel[:host] + ": " + data.chomp
  end
end

task :jmx_get do
  run "java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p #{hiera("#{app}_jmx_port")} <( echo \" puts [jmx_get -m #{arg} ]; jmx_close;\")" do |channel, stream, data|
     puts data.chomp
     out << data.chomp
  end
end


def jmxInvokeAndReturnAJavaObjectMethod(*params)
  argString=""
  params.map {|x| argString << "#{x} "}
  set :arg, argString
  find_and_execute_task("jmxInvokeAndReturnAJavaObject")
end

def jmxInvokeAndReturnAString(*params)
  argString=""
  params.map {|x| argString << "#{x} "}
  set :arg, argString
  find_and_execute_task("jmxInvokeAndReturnAString")
end

def jmxInvoke(*params)
  argString=""
  params.map {|x| argString << "#{x} "}
  set :arg, argString
  find_and_execute_task("jmxInvoke")
end

def jmxGet(*params)
  argString=""
  params.map {|x| argString << "#{x} "}
  set :arg, argString
  find_and_execute_task("jmx_get")
end

# task :ingest_shutdown
# task :ingest_restart
# task "sequence_reset_#{service}"
# ... all moved to common/orchestration.rb

# raise exception unless app is set
def ensure_app_is_set
  raise 'Please set app (use "-S app=<app>")' unless exists?(:app)
end

namespace :jmx do
  
  task "get_RecordingCacheService_sizes".to_sym do
    set :app, "schedulerEngineService"
    find_and_execute_task("#{confType}_#{app}")
    response = ""
    run "echo \"jmx_list Coherence\" | java -jar /opt/xcal/bin/jmxsh-R5.jar  -h localhost -p #{hiera("#{app}_jmx_port")} | perl -pe 's/ /\\n/g;s/\\{|\\}//g;' | grep Coherence:type=Cache,service=RecordingCacheService,name=Recording" , :once => true  do |channel, stream, data|
      response << data
    end
    set :out, %w[]
    response.each do |line|
      puts "checking size of #{line}"
      jmxGet("#{line.chomp}", "Size")
    end
    puts "total = #{out.inject(0){|sum,item| sum + item.to_i}}"
  end
    
  
  
  desc <<-HERE
  create a heapDump via jmx
    cap -f capfile_poc jmx:dumpHeap_entityDataService -S nobom HOSTS=ccpdss-po-c002-p.po.ccp.cable.comcast.com
  HERE
  task "dumpHeap".to_sym do
      ensure_app_is_set
      file = "#{basedir}/jetty-#{app}/logs/#{app}-cap-#{Time.now.to_i}.heapDump"
      jmxInvoke("com.sun.management:type=HotSpotDiagnostic", "dumpHeap", file, "false")
      run "chmod +r #{file}"
      puts "created heapDump file at: #{ENV['HOSTS']}:#{file}"
  end


  task "forceDownOn".to_sym do
    ensure_app_is_set
    if WebServicesCompass.include?(app)
      jmxInvoke("thePlatform:application=#{app},name=aliveCheckConfiguration", "setForceDown", "true")
    else
      jmxInvoke("thePlatform:application=#{app},endpoint=#{app},name=aliveCheckConfiguration", "setForceDown", "true")
    end
  end

  task "forceDownOff".to_sym do
    ensure_app_is_set
    if WebServicesCompass.include?(app)
      jmxInvoke("thePlatform:application=#{app},name=aliveCheckConfiguration", "setForceDown", "false")
    else
      jmxInvoke("thePlatform:application=#{app},endpoint=#{app},name=aliveCheckConfiguration", "setForceDown", "false")
    end
  end

  # 2013-11-08: deprecating getPeers, getMessagesReceived, and getMessagesSent tasks
  task "getPeers".to_sym do
     ensure_app_is_set
     find_and_execute_task("#{confType}_#{app}")
     logger.important "Task deprecated.  Use the following, instead:"
     logger.important %Q|curl "http://#{dsMerlinVip}/#{app}/management/status/monitor?mbean=thePlatform%3AthePlatform%3Dclusters%2Ccluster%3D#{app}_#{confType}%2CpeerStatus%3DpeerStatus"|
  end

  task "getMessagesReceived".to_sym do
     ensure_app_is_set
     find_and_execute_task("#{confType}_#{app}")
     logger.important "Task deprecated.  Use the following, instead:"
     logger.important %Q|curl "http://#{dsMerlinVip}/#{app}/management/status/monitor?mbean=thePlatform%3AthePlatform%3Dclusters%2Ccluster%3D#{app}_#{confType}%2CpeerServer%3DpeerServer%5B REPLACE_PEER_HOSTNAME_HERE %5D|
  end

  task "getMessagesSent".to_sym do
     ensure_app_is_set
     find_and_execute_task("#{confType}_#{app}")
     logger.important "Task deprecated.  Use the following, instead:"
     logger.important %Q|curl "http://#{dsMerlinVip}/#{app}/management/status/monitor?mbean=thePlatform%3AthePlatform%3Dclusters%2Ccluster%3D#{app}_#{confType}%2CpeerClient%3DpeerClient%5B REPLACE_PEER_HOSTNAME_HERE %5D|
  end

  task "addAllowedHostName".to_sym do
    ensure_app_is_set
    name = app
    find_and_execute_task("#{confType}_#{app}")
    jmxInvoke("thePlatform:application=entityDataService,endpoint=entityDataService,name=configuration", "addAllowedHostName", allowedHostName)
  end

  task "clearL1".to_sym do
    ensure_app_is_set
    find_and_execute_task("#{confType}_#{app}")
    response = ""
    run "echo \"jmx_list thePlatform\" | java -jar /opt/xcal/bin/jmxsh-R5.jar  -h localhost -p #{hiera("#{app}_jmx_port")} | perl -pe 's/ /\\n/g;s/\\{|\\}//g;' | grep cache=com | grep Response " , :once => true  do |channel, stream, data|
      response << data
    end
    response.each do |line|
      puts "purging L1 cache #{line} on #{app}..."
      jmxInvoke("#{line.chomp}", "clearCache")
    end
  end
  
  task "getCacheSize".to_sym do
    ensure_app_is_set
    find_and_execute_task("#{confType}_#{app}")
    # linearDS mbean name is different
    mbean_name = ["linearDataService"].include?(app) ? "thePlatform:application=#{app},name=cacheStatistics,cache=com.theplatform.contrib.data.cache.response.MerlinResponseCacheImpl" : "thePlatform:application=#{app},name=cacheStatistics,cache=com.theplatform.data.cache.response.ResponseCacheImpl"
    jmxInvokeAndReturnAString(mbean_name, "getCacheSize")
  end

  task "getTotalAverageResponseTime10Minutes".to_sym do
    ensure_app_is_set
    find_and_execute_task("#{confType}_#{app}")
    jmxInvokeAndReturnAString("thePlatform:application=#{app},endpoint=#{app},name=requestStatistics", "getTotalAverageResponseTime10Minutes")
  end

  namespace :logging do
    task "apacheDEBUG".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "org.apache", "DEBUG")
    end

    task "apacheINFO".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "org.apache", "INFO")
    end
    
    task "getRoot".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvokeAndReturnAString("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "getLoggerLevel", "ROOT")
    end

    task "rootDEBUG".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "ROOT", "DEBUG")
    end

    task "rootWARN".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "ROOT", "WARN")
    end
    
    task "rootINFO".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "ROOT", "INFO")
    end

    task "rootOFF".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "ROOT", "OFF")
    end

    task "poolDEBUG".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "com.mchange.v2.resourcepool.BasicResourcePool", "DEBUG")
    end

    task "poolINFO".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "com.mchange.v2.resourcepool.BasicResourcePool", "INFO")
    end

    task "jdbcDEBUG".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "com.theplatform.jdbc.log.LoggingStatement", "DEBUG")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "org.hibernate.jdbc.AbstractBatcher", "DEBUG")
    end

    task "jdbcINFO".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "com.theplatform.jdbc.log.LoggingStatement", "INFO")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "org.hibernate.jdbc.AbstractBatcher", "INFO")
    end

    task "jdbcDEBUG".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "com.theplatform.jdbc.log.LoggingStatement", "DEBUG")
    end

    task "jdbcINFO".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "setLoggerLevel", "com.theplatform.jdbc.log.LoggingStatement", "INFO")
    end

    task "reloadLogback".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("ch.qos.logback.classic:Name=default,Type=ch.qos.logback.classic.jmx.JMXConfigurator", "reloadDefaultConfiguration" )
    end
  end
  
  desc "check logs for mention of heap dump"
  task "heapDumpCheck".to_sym do
    ensure_app_is_set
    find_and_execute_task("#{confType}_#{app}")
    run "ls -ltr /opt/ds/jetty-#{app}/logs | grep heapDump | tail -1"
  end
  
  task "db_reset".to_sym do
    ensure_app_is_set
    find_and_execute_task("#{confType}_#{app}")
    jmxInvoke("com.mchange.v2.c3p0:type=PooledDataSource\\[unboundedQuery\\]", "hardReset")
    jmxInvoke("com.mchange.v2.c3p0:type=PooledDataSource\\[idGenerator\\]", "hardReset")
    jmxInvoke("com.mchange.v2.c3p0:type=PooledDataSource\\[default\\]", "hardReset")
    jmxInvoke("com.mchange.v2.c3p0:type=PooledDataSource\\[notification\\]", "hardReset")
  end

  ### these are for DataServicesCompass ###
  namespace :data_services do
    task "clearL2".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      response = ""
      run "echo \"jmx_list thePlatform\" | java -jar /opt/xcal/bin/jmxsh-R5.jar  -h localhost -p #{hiera("#{app}_jmx_port")} | perl -pe 's/ /\\n/g;s/\\{|\\}//g;' | grep cache=com | grep -v Response" , :once => true  do |channel, stream, data|
        response << data
      end
      response.each do |line|
        if ( not exists? :l2CacheToClear ) or ( exists? :l2CacheToClear and line.chomp.end_with?(l2CacheToClear) )
          puts "purging L2 cache #{line.chomp} on #{app}..."
          jmxInvoke("#{line.chomp}", "clearCache")
        # else
          # defined? l2CacheToClear and l2CacheToClear != line
          # Do NOT clearCache for line
        end
      end
    end
    
    task "clearAllCaches".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      response = ""
      run "echo \"jmx_list thePlatform\" | java -jar /opt/xcal/bin/jmxsh-R5.jar  -h localhost -p #{hiera("#{app}_jmx_port")} | perl -pe 's/ /\\n/g;s/\\{|\\}//g;' | grep cache=com | grep -v AuthorizationClient$AuthorizationResultCache " , :once => true  do |channel, stream, data|
        response << data
      end
      response.each do |line|
        puts "purging cache #{line} on #{app}..."
        jmxInvoke("#{line.chomp}", "clearCache")
      end
    end

    task "setReadOnly".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("thePlatform:application=#{app},endpoint=#{app},name=endpoint", "setReadOnly", "true")
    end

    task "setReadWrite".to_sym do
      ensure_app_is_set
      find_and_execute_task("#{confType}_#{app}")
      jmxInvoke("thePlatform:application=#{app},endpoint=#{app},name=endpoint", "setReadOnly", "false")
    end
  end

  #one off tasks for unique operations
  task :reloadAllMediaAccounts_programAvailability2 do
    find_and_execute_task("#{confType}_programAvailability2")
    set :app, "programAvailability2"
    jmxInvoke("thePlatform:application=programAvailability2,endpoint=programAvailability,name=videoRetriever", "reloadAllMediaAccounts")
  end

  task :reloadVideoLocationMap_programAvailability2 do
    find_and_execute_task("#{confType}_programAvailability2")
    set :app, "programAvailability2"
    jmxInvoke("thePlatform:application=programAvailability2,endpoint=programAvailability2,name=locationMap", "reload")
  end

  desc "provide a HOSTS param please or it will execute on multiple"
  task :loadData_schedulerDataRefresher do
    raise "the HOSTS option must be specified on the commandline for this task to work safely" unless hosts_arg_specified? 
    find_and_execute_task("#{confType}_schedulerDataRefresher")
    set :app, "schedulerDataRefresher"
    jmxInvoke("com.hercules.scheduler:name=deviceDataLoader","loadData")
  end

end #end jmx namespace

task "heapDumpCheck".to_sym do
  DataAndWebServices.each do |e|
    if find_task("#{confType}_#{e}")
      logger.info "checking #{e}"
      set :app, e
      find_and_execute_task("jmx:heapDumpCheck")
    end
    roles.clear
  end
end

task "clearAll".to_sym do
  DataServicesCompass.each do |e|
    if find_task("#{confType}_#{e}")
      logger.info "clearing #{e}"
      set :app, e
      find_and_execute_task("jmx:clearCache")
    end
    roles.clear
  end
end

# task "showDbSchemaMerqaIngest" 
# task "showDbSchemaMerqaMWS"
# task "showHttpMerqaMWS"
# task "showHttpMerqaHead"
# task "showHttpMerqaIngest"
# task "fullDSRestart"
# task "checkRO"
# ... all moved to common/orchestration.rb

task "reset_all_db_connections".to_sym do
  DataServicesCompass.each do |e|
    unless e == "programAvailability2"
    if find_task("#{confType}_#{e}")
      logger.info "resetting #{e}"
      set :app, e
      find_and_execute_task("jmx:db_reset")
    end
    roles.clear
    end
  end
end

task "updateConfigAndGracefulRestart_#{confType}".to_sym do
  ensure_app_is_set
  
  logger.level = Capistrano::Logger::INFO
  find_and_execute_task("hosts_file_override_#{app}")

  find_and_execute_task("#{confType}_#{app}")
  find_servers(:roles => app.to_sym).each do |server|
    ENV['HOSTS'] = "#{server.host}"
    logger.info "ASSIGNED HOST=#{server.host}"
    
    set :web_port, hiera("#{app}_web_port")
    set :jmx_port, hiera("#{app}_jmx_port")
    set :stop_port, hiera("#{app}_stop_port")
    set :alive_path, hiera("#{app}_alive")
    find_and_execute_task("jmx:forceDownOn")
    run "echo 'sleeping 30 while remaining connections die off...' ; sleep 30"
    stop_jetty
    find_and_execute_task("jettywrapper#{app}")
    find_and_execute_task("initd#{app}")    
    find_and_execute_task("prepare_#{app}_#{confType}")
    start_jetty
    alive
    get_ver
  end
  roles.clear
end

task "updateLoggingConfigAndPersist_#{confType}".to_sym do
  ensure_app_is_set
  
  find_and_execute_task("#{confType}_#{app}")
  logger.level = Capistrano::Logger::INFO
  find_servers(:roles => app.to_sym).each do |server|
    ENV['HOSTS'] = "#{server.host}"
    logger.info "ASSIGNED HOST=#{server.host}"
    
    createLogback
    find_and_execute_task("jmx:logging:reloadLogback")
  end       
end

# task "fullDSLogbackReconfig"
# task "fullDStest"
# task "FullDSGracefulReconfig"
# task "FullDSReconfig"
# task "FullWSReconfig"
# task "otherCompassServicesDeploy"
# def getToken
# task :getOutletAccounts
# ... all moved to common/orchestration.rb
