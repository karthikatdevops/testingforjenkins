namespace :dynaTrace do



# Fall 2015 - we have unlimted licenses in DT Dynatrace so moving all merlin services onto it.
#  Yum version doesn't work with our new VS vms, so lets install the newest agent directly using
#  the jar installer on our NFS share...

  task :get_artifact do
    logger.info " "
    logger.info ">>>>>>>>>>>>>>>>>>>>>>>>>>> DYNATRACE================================================"
    logger.info " "
    logger.info "TASK: get_artifact --- Checking if dyantrace agent is  installed"


    if confType.include?("merqaTest104") || confType.include?("merdevl") || confType.include?("mciGbenv") || confType.include?("cmpstkMerlinIngest")
      logger.info "This is Merdevl or mciGbenv - installing agent via direct jar command (version 6.1 of agent)"
      logger.info "...Checking if agent is already installed...."

      if app == "playTimeService"
        logger.info "This is playtime and profiler is not compatible with Dyanatrace, skipping for now"
        set :dynaTrace_options, ""
      else
        # the installer is a one line bash script that just points the installer into /opt/dynatrace, so it matches
        #  up with the rest of the cap here in terms of boot strapping code...
        # all our vms will have the common NFS mount on /opt/storage, so distribute it that way.
        set :dynaAgentInstallString, "/opt/storage/software/dynatrace-agent-installer.sh"
        run "if [ -e /opt/dynatrace/dynatrace-agent/latest/agent/lib64/libdtagent.so ]; then echo installed; else #{dynaAgentInstallString} ; fi"
      end

    else
      logger.info "This is not a destro controlled env - installing agent via yum from XOPS repo (version 5.5 agent)"
      run "sudo yum -y install dynatrace-agent || ( sudo yum clean all ; sudo yum -y install dynatrace-agent )"
  end
 end
end


# main method to configure dynaTrace
def configure_dynaTrace(options = {})
  # do not do anything unless :dynaTrace_collectors is set
  unless (exists?(:dynaTrace_collectors) && dynaTrace_collectors != [])
    logger.info ":dynaTrace_collectors not set"
    set :dynaTrace_options, ""
    return
  end
  
  # set vars
  set :dynaTrace_name, [confType, app, "$HOSTNAME"].join("_")
  set :dynaTrace_options, get_dynaTrace_options
  
  # get and unzip dynaTrace artifact
  find_and_execute_task("dynaTrace:get_artifact")  
end

# :dynaTrace_name should be set
def get_dynaTrace_options
  agent_path_str = " -agentpath:/opt/dynatrace/dynatrace-agent/latest/agent/lib64/libdtagent.so"
  opts = [
    ["name", dynaTrace_name],
    ["server", get_dynaTrace_collector]
  ].collect {|a| a.join("=")}.join(",")
  [agent_path_str, opts].join("=")
end

# :dynaTrace_collectors should be set
def get_dynaTrace_collector
  dynaTrace_collector = dynaTrace_collectors[rand(dynaTrace_collectors.length)]
  [dynaTrace_collector, "6698,exclude=contains:CGLIB"].join(":")
end
