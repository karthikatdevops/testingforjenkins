# usage "bundle exec cap -S env=merdevl -S svc=NONE bookmarks  -S nobom"
services_ignore=["jiraSprintReport","udbMockService","entityIndex","entityIndexer","jmxtrans","gdash","nginx","nagios"]

  desc "used to generate bookmarks for the #{env} bookmarks configuration"
  task "bookmarks".to_sym do

  # Initialize the string
  $output = ''

  # Add in the top of file to make it nice. Cribbed from Chrome's HTML Bookmarks Export
   $output +=  %Q{<!DOCTYPE NETSCAPE-Bookmark-file-1>
<!-- This is an automatically generated file.
Created by BITT's capistrano envbookmarks.rb generator.
This is a bookmarks file for: #{env}
Import me into your fav browser! -->
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>#{env} Bookmarks</TITLE>
<H1>#{env} Bookmarks</H1>
<DL><P>
}



   #	$services=Hash.new { |hash, key| block }
	$services=Hash.new { |hash,key| hash[key] = [] }
self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each{|tsk|
   service_name=tsk.fully_qualified_name.split("_")[1]
   set :hiera_svc, service_name
      if service_name.include?("jmxtrans") || service_name.include?("servicehost") || service_name.include?("entityIndex") || service_name.include?("entityIndexer") || service_name.include?("udbMockService") || service_name.include?("rabbitMQ") || service_name.include?("rabbitMGT") || service_name.include?("coatGWTService") || service_name.include?("locationIndexer") || service_name.include?("linearIndexer") || service_name.include?("nagios") || service_name.include?("haproxy") || service_name.include?("oracle") || service_name.include?("imageRabbitMQ") || service_name.include?("imageRabbitMGT") || service_name.include?("gdash")

            next
          end
          #logger.info "Found task #{tsk.fully_qualified_name}"
          begin
             set :web_port, hiera("#{service_name}_web_port")
          rescue
            logger.info "#{service_name}_web_port is not defined."
            next
          end
          find_and_execute_task ("#{tsk.name}")
         find_servers_for_task(tsk,:roles => "#{service_name}".to_sym).each do |svr| $services["#{service_name}"] << "#{svr.host}:#{web_port}\/#{service_name}"
          end # task: bookmarks
  }
   $services.sort.each {|srvname,url1|
   set :web_port, hiera("#{srvname}_web_port")

##############################################################
# Set the livechecks
   if(srvname == "programIndex2")
    livecheck=""
    path="solr/admin"
  elsif (srvname == "menuWebService" \
          || srvname == "browseSessionService" \
          || srvname == "menuVisibilityCountService" \
          || srvname == "videoDataService")
    livecheck="healthCheck"
  elsif (srvname == "rabbitMGT")
      livecheck="/api/aliveness-test/compass-alive"
      path=""
  elsif (srvname == "cloverServer")
      livecheck=""
      path="gui"
  elsif (srvname == "reatGWTService")
      path=""
      livecheck="management/alive"
   elsif (srvname == "searchUpdaterWebService2" \
        || srvname == "combineService" \
        || srvname == "offerWebService" \
        || srvname == "scheduledIngestWebService" \
        || srvname == "caretakerWebService" \
        || srvname == "consistencyWebService" \
        || srvname == "feedgenWebService" \
        || srvname == "gridWebService" \
        || srvname == "imageWebService" \
        || srvname == "sportsIngestWebService" \
        || srvname == "matchWebService")
      path="console/"
      livecheck="management/alive"
  elsif (srvname =~ /DataService/ \
        ||srvname=="programAvailability2" \
        ||srvname =~ /Ingest/ \
        )
      path="client"
      livecheck="management/alive"
    else
      livecheck="management/alive"
      path=""
    end

##############################################################
# Set the VIP
    if (env == "merdevl")
      dsMVip="ccpmer-phl-v001-d.compass.chalybs.net"
    else
      dsMVip= "#{dsMerlinVip}"
    end

##############################################################
# Set the Main VIP links - Console and Live Check

    # If these are NGB services....
    if (srvname == "menuWebService" \
          || srvname == "browseSessionService" \
          || srvname == "menuVisibilityCountService" \
          || srvname == "videoDataService")
      $output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}/#{livecheck}\">#{srvname} VIP livecheck</A>\n"

    # If they are Merlin, start to figure out which ones...


    elsif (srvname == "programIndex2")
      $output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}/#{path}\">#{srvname} SOLR Admin</A>\n"

    elsif (srvname == "rabbitMGT")
      $output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}\"> RabbitMQ Mgt Page</A>\n"

    elsif (srvname == "cloverServer")
      $output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}/#{srvname}/gui/\"> CloverETL Mgt Pages</A>\n"

    elsif (srvname == "caretakerWebService")
      $output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}/#{srvname}/dashboard/\">#{srvname} VIP Dashboard</A>\n"
      $output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}/#{srvname}/#{path}\">#{srvname} VIP console</A>\n"
      $output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}/#{srvname}/#{livecheck}\">#{srvname} VIP livecheck</A>\n"


    # FInd all the services that HAVE CONSOLES
    elsif ( \
        srvname=="programAvailability2" \
      ||srvname== "combineService" \
      ||srvname== "offerWebService" \
      ||srvname== "scheduledIngestWebService" \
      ||srvname== "searchUpdaterWebService2" \
      ||srvname== "consistencyWebService" \
      ||srvname== "feedgenWebService" \
      ||srvname== "gridWebService" \
      ||srvname== "imageWebService" \
      ||srvname== "sportsIngestWebService" \
      ||srvname== "matchWebService" \
       )
			$output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}/#{srvname}/#{path}\">#{srvname} VIP console *</A>\n"
			$output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}/#{srvname}/#{livecheck}\">#{srvname} VIP livecheck *</A>\n"


   else
         $output += "<DT><A HREF=\"http://#{dsMVip}:#{web_port}/#{srvname}/#{livecheck}\">#{srvname} VIP livecheck ^</A>\n"
   end

##############################################################
# Create the start of an enclosing folder to hold the node links

    $output += "<DT><H3>#{srvname} Nodes</H3>\n"
    $output += "<DL><p>\n"


##############################################################
# Set the Node Links in each sub-folder, per service

		url1.each {|url|
      # Figure out the node name so we can label these correctly
      puts "------------------------------------------------------------------"
      puts "Your Environment - #{env} -----------------"
      puts " Your Service ----> #{srvname}"
      puts "  Your URL ------> #{url}"
      puts "  Your path -----> #{path}"
      puts "  Your livecheck -> #{livecheck}"

      # For the different ENVs, which use different host naming conventions
      #   figure out the best way to get a short node name for the URL description
      if ( env == "cmpstkMerlinIngest" || env == "cmpstkMerlinImages" )
        mynode=url.split(".").first
      else
        #mynode=url.split("-").third
      end
      puts "  Your Node ------> #{mynode}"

      # If this is a NGB service, we need special URLs (no service name)
      if (srvname == "menuWebService" \
          || srvname == "browseSessionService" \
          || srvname == "menuVisibilityCountService" \
          || srvname == "videoDataService")
        # fix URL for NGB services
          urlNGB=url.split("/").first
          puts "  NGB URL fixed -> #{urlNGB}"
          puts "  NGB healthcheck-> #{livecheck}"
          $output += "<DT><A HREF=\"http://#{urlNGB}/#{livecheck}\">#{srvname} #{mynode} health check</A>\n"
          $output += "<DT><A HREF=\"http://#{urlNGB}/config\">#{srvname} #{mynode} configuration</A>\n"
          $output += "<DT><A HREF=\"http://#{urlNGB}/healthCheckWithVersion\">#{srvname} #{mynode} versions</A>\n"

      # Skip these there are no nodes
      elsif (srvname == "rabbitMQ" ||  srvname == "cloverServer")
          next


      else
      # Everything that is not NGB, it's a regular old Merlin Service....
        $output += "<DT><A HREF=\"http://#{url}/management/status \">#{srvname} #{mynode} Status Page</A>\n"
        $output += "<DT><A HREF=\"http://#{url}/config \">#{srvname} #{mynode} Node Configuration Page</A>\n"
        # These special Merlin services have Consoles, so Add them
        if (srvname == "offerWebService" \
           || srvname == "scheduledIngestWebService" \
           || srvname == "searchUpdaterWebService2" \
           || srvname == "consistencyWebService" \
           || srvname == "feedgenWebService" \
           || srvname == "gridWebService" \
           || srvname == "imageWebService" \
           || srvname == "sportsIngestWebService" \
           || srvname == "matchWebService")
          $output += "<DT><A HREF=\"http://#{url}/#{path}\">#{srvname} #{mynode} Console</A>\n"
          $output += "<DT><A HREF=\"http://#{url}/#{livecheck}\">#{srvname} #{mynode} livecheck</A>\n"
        elsif (srvname == "caretakerWebService")
          $output += "<DT><A HREF=\"http://#{url}/#{livecheck}\">#{srvname} #{mynode} livecheck</A>\n"
          $output += "<DT><A HREF=\"http://#{url}/#{path}\">#{srvname} #{mynode} Console</A>\n"
          $output += "<DT><A HREF=\"http://#{url}/dashboard/\">#{srvname} #{mynode} Dashboard</A>\n"
        elsif (srvname == "programIndex2")
          (url2,url3)=url.split("/")
          $output += "<DT><A HREF=\"http://#{url2}/#{livecheck}\">#{srvname} #{mynode} client page</A>\n"
        else
          $output += "<DT><A HREF=\"http://#{url}/#{path}\">#{srvname} #{mynode} client page</A>\n"
          $output += "<DT><A HREF=\"http://#{url}/#{livecheck}\">#{srvname} #{mynode} livecheck</A>\n"
        end # Merlin if-block
      end # NGB if-block

    } # End the for-each URL
      $output += "</DL><p>\n"
    } # End the Master Sort
#}
    #puts $output

    # write out the new bookmarks html file
   File.open("working/#{env}.html", 'w') {|f| f.write($output) }
   puts "-----------> just wrote out: working/#{env}.html for you to use"
  end
