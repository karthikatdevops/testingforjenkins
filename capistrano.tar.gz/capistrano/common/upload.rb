def file_digests_differ?( lfile, rfile, hostname )
  local_digest = Digest::MD5.hexdigest(File.read(lfile))
  remote_digest = (capture "if [ -e #{rfile} ]; then md5sum #{rfile} | awk '{print $1}'; fi", :hosts => hostname).gsub("\n","")
  remote_digest = "<<file not present>>" if remote_digest == ""

  if local_digest == remote_digest
    logger.info "Remote signature and local signature match for #{lfile} on #{hostname} not pushing file."
    return false
  else
    logger.info "Remote signature " + remote_digest + " differs from local signature " + local_digest + " for #{lfile} on #{hostname} so the file will be pushed to the server."
    run "rm -f #{rfile}", :hosts => hostname
    upload("#{lfile}", "#{rfile}", :via => :scp, :hosts => hostname)
    return true
  end
end

def upload_if_needed ( lfile, rfile )
  # use parallel block so this does not have to be called in a loop
  parallel do |session|
    session.when "file_digests_differ?('#{lfile}', '#{rfile}', server.host)", "echo 'Changes detected: uploaded file to $CAPISTRANO:HOST$'"
  end
end

def get_remote_file_via_cap(url,remote_dir,download_file_name)
  logger.info "In local fetch mode for[#{url}] [#{remote_dir}] [#{download_file_name}]"
  # we use a per-host work directory to ensure parallel calls don't step on each other
  # TODO - add serialization logic to download only once
  begin
    work_dir = "working/" + ENV['HOSTS']
    `mkdir -p #{work_dir}`
    `wget #{wget_params} -O #{work_dir}/#{download_file_name} #{url}`
    if File.exists?("#{work_dir}/#{download_file_name}") && (! File.zero?("#{work_dir}/#{download_file_name}"))
      logger.info "Downloaded #{url} -> #{work_dir}/#{download_file_name}"
    else
      logger.info "Failed download for #{url} check it"
      exit 1
    end
    upload("#{work_dir}/#{download_file_name}","#{remote_dir}/#{download_file_name}", :via => :scp)
  rescue Capistrano::Error
#    logger.fatal "could not handle retrieving file from #{url} via cap machine"
    logger.info "could not handle retrieving file from #{url} via cap machine"
    exit 1
  end
end

def check_my_dir(dir)
  if ! File.directory?(dir)
    puts "There is no directory called '#{dir}' - creating this now for you..."
    run "mkdir -m 775 -p #{dir}"
      else
    puts "found #{dir}."
  end
  return
end

def get_remote_file(url,remote_dir,download_file_name)
  logger.info " "
 # logger.info "UPLOAD.RB --> _get_remote_file_ was called with [#{url}] [#{remote_dir}] [#{download_file_name}]"
  logger.info "UPLOAD.RB --> _get_remote_file_ was called !"
  # if the file_name is passed as something real, use that
  # otherwise, we will set it to be the end of the URL
  if download_file_name =~ /^$/
    download_file_name = url.gsub(/.*\//,"")
  end
  logger.info "URL to get=#{url}"
  if url =~ /^file/
     logger.info "Found a local file!"
	 filename = url.gsub(/file:\/\//,"")
     system("cp #{filename} working/#{download_file_name}")
	 #First need to upload the file to the servers
	 upload("working/#{download_file_name}", remote_dir, :via => :scp)
     return
  end

  # if fetch_via_cap is set to true,
  # we will try to fetch the file locally
  if exists?(:fetch_via_cap) && fetch_via_cap.to_s == "true"
    logger.info "Trying via _fetch_via_cap_ "
    get_remote_file_via_cap(url,remote_dir,download_file_name)
  else

    # if we are in the upload controllers task in cloverserver.rb, we are using CFIG
    # and so we need to use --noproxy wgets for CFIG, beacuse we are using the VPN

#   Need to just set cloverman_cfig_repo to true whenever you want to use no proxy
    if exists?(:cloverman_cfig_repo)
      logger.info "*** CFIG ULA wget, so ensuring that wget does _not_ use a proxy in ULA "
      set :wget_params,  hiera('cfig_ula_wget_params')
    end
    begin
#      logger.info "Trying to fetch remotely #{url} as #{remote_dir}/#{download_file_name}"
      logger.info "wget COMMAND: wget #{wget_params} -O #{remote_dir}/#{download_file_name} #{url}"
      run "wget #{wget_params} -O #{remote_dir}/#{download_file_name} #{url}"
    rescue Capistrano::Error
      get_remote_file_via_cap(url,remote_dir,download_file_name)
    end


  end
end
