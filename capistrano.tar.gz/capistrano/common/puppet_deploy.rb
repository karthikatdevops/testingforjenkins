# Cap commands and methods for deploying w/ Merlin Puppet

set_vars_from_hiera(%w[mp_base_dir mp_http_proxy_str])
MOPS_HIERA_SOURCE_DIR = '../mopsCompassHiera'
MOPS_PUPPET_SOURCE_DIR = '../mopsCompassPuppet'

desc 'set hosts, and host_names'
task :mp_set_hosts do
  unless exists?(:host_names)
    # parse nodes/ files from Hiera data dir
    if ENV['HOSTS']
      set :host_names, ENV['HOSTS'].split(',')
    else
      raise "No HOSTS variable set and no svc variable set" unless exists?(:svc)
      set :host_names, hiera(hiera_svc, :priority, "nodes/#{hiera_env}")
    end
    role :hosts, *host_names
  end
end

namespace :puppet do
  namespace :install do
    desc 'set up everything'
    task :everything do
      # find hosts
      find_and_execute_task("mp_set_hosts")
      
      run_serially_in_batches { |server_options|
        ['merlin_base_dir', 'augeas', 'hiera', 'puppet', 'merlin_puppet_repo', 'merlin_hiera_repo', 'bundler', 'highline', 'librarian', 'packages'].each { |i|
          find_and_execute_task("puppet:install:#{i}")
        }
      }
    end

    desc 'install packages'
    task :packages do
      install_versioned_yum_package('gcc', nil)
      install_versioned_yum_package('ruby-devel', nil)
    end

    desc 'make base_dir'
    task :merlin_base_dir do
      run "sudo mkdir -p #{mp_base_dir} && sudo chown #{user}:#{user} #{mp_base_dir}"
    end

    desc 'make Puppet dir'
    task :merlin_puppet_repo do
      # make dir if not there
      run "mkdir -p #{mp_base_dir}/mopsCompassPuppet"
    end
  
    desc 'make Hiera dir and set up symlinks'
    task :merlin_hiera_repo do
      run "mkdir -p #{mp_base_dir}/mopsCompassHiera"
    end
  
    desc 'use puppet 3.7.0'
    task :puppet do
      install_versioned_yum_package('puppet', '3.7.0') unless hiera('puppet_deploy.skip_puppet_install')
    end

    desc 'use augeas 1.0.0'
    task :augeas do
      install_versioned_yum_package('augeas', '1.0.0')
    end
  
    desc 'use hiera 1.3.4'
    task :hiera do
      install_versioned_yum_package('hiera', '1.3.4')
    end
  
    desc 'install bundler'
    task :bundler do
      run "gem list -i bundler || sudo #{mp_http_proxy_str} gem install bundler --no-ri --no-rdoc -v 1.6.3"
    end
  
    desc 'install gem highline for librarian-puppet'
    task :highline do
      run "gem list -i highline || sudo #{mp_http_proxy_str} gem install highline --no-ri --no-rdoc -v 1.6.21"
    end
  
    desc 'install gem librarian-puppet'
    task :librarian do
      run "gem list -i librarian-puppet || sudo #{mp_http_proxy_str} gem install librarian-puppet --no-ri --no-rdoc -v 1.0.9"
    end
  end

  namespace :rsync_update do
    desc 'rsync update everything'
    task :everything do
      # find hosts
      find_and_execute_task("mp_set_hosts")
      
      run_serially_in_batches { |server_options|      
        # rsync
        ['merlin_puppet_repo', 'merlin_hiera_repo'].each { |i|
          find_and_execute_task("puppet:rsync_update:#{i}")
        }
      
        # bundle install
        unless exists?(:no_bundle_install)
          run "cd #{mp_base_dir}/mopsCompassPuppet/run && #{mp_http_proxy_str} bundle install"
        end
    
        # librarian install for puppet modules
        unless exists?(:no_librarian)
          run "cd #{mp_base_dir}/mopsCompassPuppet/run && sudo #{mp_http_proxy_str} https_proxy=http://proxy:3128 librarian-puppet install"
        end
      }
    end
  
    desc 'rsync Puppet repo to host'
    task :merlin_puppet_repo do
      raise "check puppet repo" if Dir[MOPS_PUPPET_SOURCE_DIR].empty?
      rsync_cmds = host_names.collect { |host| "rsync -lrvz -f'- .git/' -f'+ *' --delete #{MOPS_PUPPET_SOURCE_DIR}/ #{user}@#{host}:#{mp_base_dir}/mopsCompassPuppet/" }
      exec_cmds_and_wait(rsync_cmds)
    end

    desc 'rsync Hiera repo to host'
    task :merlin_hiera_repo do
      raise "check hiera repo" if Dir[MOPS_HIERA_SOURCE_DIR].empty?
      rsync_cmds = host_names.collect { |host| "rsync -lrvz -f'- .git/' -f'+ *' --delete #{MOPS_HIERA_SOURCE_DIR}/ #{user}@#{host}:#{mp_base_dir}/mopsCompassHiera/" }
      exec_cmds_and_wait(rsync_cmds)
    end
  end

  namespace :push do
    desc 'take an action on a merlin service'
    task :service do
      # get svc and bom and action
      raise 'set :svc first' unless exists?(:svc)
      set :bom, 'nobom' unless exists?(:bom)
      raise 'set :action first' unless exists?(:action)
    
      # find hosts
      find_and_execute_task("mp_set_hosts")
    
      run_serially_in_batches { |server_options|
        set :url, nil unless exists?(:url)
        set :attrs, get_class_attrs(bom, svc, env, action, url)

        # build and run puppet cmd
        puppet_cmd = get_puppet_cmd(svc, attrs)
        debug_opt = exists?(:debug) ? '-d' : ''
        run "cd #{mp_base_dir}/mopsCompassPuppet/run && sudo bundle exec puppet apply --ignorecache --detailed-exitcodes --modulepath=#{mp_base_dir}/mopsCompassPuppet/run/modules --hiera_config #{mp_base_dir}/mopsCompassHiera/mopsCompassPuppet.yaml #{debug_opt} -e '#{puppet_cmd}' || [[ $? -eq 2 ]]"
      }
    end
  end

  {
    :deploy => 'deploy service',
    :update_config => 'update config for service',
    :gracefully_deploy => 'gracefully deploy service'
  }.each { |k,v|
    namespace k do
      desc v
      task :service do
        set :action, k.to_s
        find_and_execute_task('puppet:push:service')
      end
    end
  }
end

# make a deploy_ task for orchestration tasks
if hiera('puppet_deploy')
  desc "deploy #{hiera_svc} to #{hiera_env} using puppet"
  task "deploy_#{hiera_svc}_#{hiera_env}".to_sym do
    find_and_execute_task('puppet:install:everything')
    find_and_execute_task('puppet:rsync_update:everything')
    find_and_execute_task('puppet:deploy:service')
  end
end

### methods ###
def install_versioned_yum_package(yum_package, package_version)
  # install yum pacakages if not there
  yum_package_name = package_version ? [yum_package, package_version].join('-') : yum_package
  run "sudo yum list installed #{yum_package_name} \
    || ((sudo yum remove -y #{yum_package} || true) && sudo yum install -y #{yum_package_name})"
end

def get_puppet_cmd(svc, attrs)
  attrs_str = attrs.collect { |k, v|
    [k.to_s, v.inspect].join(' => ')
  }.join(', ')
  ['merlin_service::svc::service { ', svc.inspect, ':', attrs_str, '}'].join
end

def get_class_attrs(bom, svc, env, action, url)
  res = {
    :env => env,
    :action => action
  }
  unless bom == 'nobom'
    svc_info_from_bom = get_svc_info_from_bom(bom, svc)
    res.merge!({
      :artifact_url => svc_info_from_bom[:artifact_url],
      :version      => svc_info_from_bom[:version]
    })
  end
  if url
    res.merge!({
      :artifact_url => url
    })
  end
  res
end

def get_push_facts(bom, svc, env, action, url)
  res = {
    "#{svc}_env" => env,
    "#{svc}_action" => action
  }
  unless bom == 'nobom'
    svc_info_from_bom = get_svc_info_from_bom(bom, svc)
    res.merge!({
      "#{svc}_version" => svc_info_from_bom[:version],
      "#{svc}_artifact_url" => svc_info_from_bom[:artifact_url]
    })
  end
  if url
    res.merge!({
      "#{svc}_version" => (exists?(:version) ? version : 'NO_VERSION_SPECIFIED'),
      "#{svc}_artifact_url" => url
    })
  end
  res
end

def get_svc_info_from_bom(bom, svc)
  # fetch BOM XML
  bom_url = [hiera('bama_url'), 'bom_versions/', bom, '/xml.xml'].join
  uri = URI.parse(bom_url)
  response = Net::HTTP.get_response(uri)
  raise "Non-200 response from #{bom_url}" unless response.code=="200"
  
  # parse DOM
  xmldoc = REXML::Document.new(response.body)
  version_node = REXML::XPath.first(xmldoc, "//service[@name='#{svc}']/version") || raise("Could not find version of #{svc} in BOM")
  version = version_node.text
  package_node = REXML::XPath.first(xmldoc, "//service[@name='#{svc}']/package") || raise("Could not find package of #{svc} in BOM")
  package_url = package_node.text
  # keep part of package url
  artifact_url = [hiera('maven_repo'), package_url.split('/compass-merlin-releases/').last.split('/compass-maps-releases/').last.split('/compass-udb-releases/').last].join('/')
  {
    :artifact_url => artifact_url,
    :version => version,
  }
end
