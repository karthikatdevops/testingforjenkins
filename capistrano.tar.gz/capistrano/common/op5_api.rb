# Load this file to get methods to make calls to op5.
# Two things going on right now:
# 1. [since June 2012] op5_api_client.disable_service and op5_api_client.enable_service to disable and enable service checks
#    - services should exist already
#    - these are in the stop_jetty and start_jetty tasks
#    - performs GETs on an op5 endpoint
#    - we'll call this the "simple API"

# add an 'if use_op5_api?' to each op5 method in other Cap files so op5 functionality can be easily turned off
def use_op5_api?
  hiera('use_op5_api')
end

# to check if only one host is specified in ENV['HOSTS']
def one_host_specified?
  ENV['HOSTS'] && ENV['HOSTS'].split(",").size==1
end

# one instance for this whole Cap execution
def op5_api_client
  unless exists? :cap_op5_api_client
    set :cap_op5_api_client, Op5ApiClient.new(self, confType, logger)
  end
  cap_op5_api_client
end

class Op5ApiClient

  attr_accessor :logger, :cap_config

  # for the simple API
  attr_accessor :simple_api_endpoint, :simple_api_id

  def initialize(cap_config, environment, logger)
    @cap_config = cap_config
    @logger = logger

    # don't use simple API by default
    @simple_api_endpoint = nil

    # set vars based on env
    case environment
    when /po/
      # simple API
      @simple_api_endpoint = "https://op5.po.ccp.cable.comcast.com"
      @simple_api_id = "UEFTU1dPUkQK"
    when /br/
      # simple API
      @simple_api_endpoint = "https://op5.br.ccp.cable.comcast.com"
      @simple_api_id = "UEFTU1dPUkQK"
    end
  end

  ### simple API ###
  # enable service checks for service and host
  def enable_service(svc, hosts)
    hosts = hosts.split(',') if hosts.is_a? String
    
    hosts.each do |host|
      make_simple_api_call({"service" => svc, "host" => host, "cmd" => 'ENABLE_SVC_CHECK'})
    end
  end

  # disable service checks for service and host
  def disable_service(svc, hosts)
    hosts = hosts.split(',') if hosts.is_a? String

    hosts.each do |host|
      make_simple_api_call({"service" => svc, "host" => host, "cmd" => 'DISABLE_SVC_CHECK'})
    end
  end

  # called by enable_service and disable_service
  def make_simple_api_call(get_params)
    # do nothing unless simple_api_endpoint is specified
    unless simple_api_endpoint
      logger.info "simple_api_endpoint not defined so no op5 api call"
      return false
    end

    get_params["id"] = simple_api_id
    get_params["host"] = get_params["host"].split(".").first # make ccpmer-po-a105-p.po.ccp.cable.comcast.com => ccpmer-po-a105-p
    get_str = get_params.collect {|k,v| "#{k}=#{v}"}.join("&")
    if system "wget --no-proxy --no-check-certificate -O- '#{simple_api_endpoint}/cmd.php?#{get_str}'"
      logger.info "op5 call succesful"
    else
      logger.info "op5 call failed"
    end
  end
end


# tasks that are run manually - these are not called by other Cap tasks
namespace :op5 do
  desc "can run this to disable monitoring a service for hosts"
  task :disable_service do
    set :op5_service, Capistrano::CLI.ui.ask("Set op5_service (e.g. linearDataService):") unless exists?(:op5_service)
    set :op5_hosts, Capistrano::CLI.ui.ask("Set op5_hosts (e.g. ccpmer-po-a105-p.po.ccp.cable.comcast.com)") unless exists?(:op5_hosts)
    op5_api_client.disable_service(op5_service, op5_hosts.split(",")) if use_op5_api?
  end

  desc "can run this to enable monitoring a service for hosts"
  task :enable_service do
    set :op5_service, Capistrano::CLI.ui.ask("Set op5_service (e.g. linearDataService):") unless exists?(:op5_service)
    set :op5_hosts, Capistrano::CLI.ui.ask("Set op5_hosts (e.g. ccpmer-po-a105-p.po.ccp.cable.comcast.com)") unless exists?(:op5_hosts)
    op5_api_client.enable_service(op5_service, op5_hosts.split(",")) if use_op5_api?
  end
end
