task :install_java_7u72 do
  run "sudo rpm --force -Uhv #{hiera('java_repo')}/jdk-7u72-linux-x64.rpm"
end

task :install_java_8u25 do
   run "sudo rpm --force -Uhv #{hiera('java_repo')}/jdk-8u25-linux-x64.rpm"
end

task :install_java_8u45 do
   run "sudo rpm --force -Uhv #{hiera('java_repo')}/jdk-8u45-linux-x64.rpm"
end

task :install_java_8u60 do
  run "sudo rpm --force -Uhv #{hiera('java_repo')}/jdk-8u60-linux-x64.rpm"
end

task :install_java do
  
  if java_version == "jdk1.7.0_72"
    install_java_7u72
  elsif java_version == "jdk1.8.0_25"
    install_java_8u25
  elsif java_version == "jdk1.8.0_45"
    install_java_8u45
  elsif java_version == "jdk1.8.0_60"
    install_java_8u60
  else
    install_java_8u60
  end
  
end

task :install_jetty do  
  logger.info "TASK: Entered install_jetty"
  find_and_execute_task("install_jetty_#{app}")
  if jetty_version.match(/^9/)
    find_and_execute_task("jettyrealm#{app}")
  end
  find_and_execute_task("jettywrapper#{app}")
  find_and_execute_task("initd#{app}")
  logger.info "TASK: Exited install_jetty"
end
 
task :install_sqlplus do
  install_sqlplus_11_2_0_1_0
end
 
task :install_sqlplus_11_2_0_1_0 do
  logger.info "TASK: Entered install_sqlplus_11_2_0_1_0"
  run "cd /tmp/ ; wget #{hiera('repodir')}/oracle-instantclient11.2-basic-11.2.0.1.0-1.x86_64.rpm"
  run "cd /tmp/ ; wget #{hiera('repodir')}/oracle-instantclient11.2-sqlplus-11.2.0.1.0-1.x86_64.rpm"
  run "sudo rpm -Uhv /tmp/oracle-instantclient11.2-basic-11.2.0.1.0-1.x86_64.rpm"
  run "sudo rpm -Uhv /tmp/oracle-instantclient11.2-sqlplus-11.2.0.1.0-1.x86_64.rpm"
  run "echo 'export LD_LIBRARY_PATH=/usr/lib/oracle/11.2/client64/lib' >> ~/.bash_profile"
  run "echo 'export PATH=$PATH:/usr/lib/oracle/11.2/client64/bin' >> ~/.bash_profile"
end
  
task :install_realm do
  #this one liner depends on the depends 2d array in depcheck.rb
  logger.info "TASK: Entered install_realm"
  realm_user = "xdeploy"
  password = "xcal09"
  puts "About to try and fix the realm config for APP=#{app}."
  if jetty_version.match(/^9/)
    run "cd #{basedir}/jetty-#{app} ; /usr/java/latest/bin/java -cp lib/jetty-*.jar org.eclipse.jetty.util.security.Password #{realm_user} #{password} 2>&1 | grep MD5 | perl -pe \'s/^/#{realm_user}: /;s/$/,admin/\' > etc/realm.properties"
    run "cd #{basedir}/jetty-#{app} ; echo '--module=realm' >> start.ini"
  else
    run "cd #{basedir}/jetty-#{app} ; /usr/java/latest/bin/java -cp lib/jetty-*.jar org.mortbay.jetty.security.Password #{realm_user} #{password} 2>&1 | grep MD5 | perl -pe \'s/^/#{realm_user}: /;s/$/,admin/\' > etc/realm.properties ; perl -pi -e \'s/Test Realm/thePlatform/\' etc/jetty.xml"
  end
end

task :install_crypto_extensions do
  logger.info "TASK: Entered install_crypto_extensions"
  run "cd /tmp/ ; wget http://maven.compass.chalybs.net/artifactory/external-binary/local_policy.jar"
  run "cd /tmp/ ; wget http://maven.compass.chalybs.net/artifactory/external-binary/US_export_policy.jar"
  run "sudo cp /tmp/local_policy.jar /usr/java/latest/jre/lib/security/local_policy.jar"
  run "sudo cp /tmp/US_export_policy.jar /usr/java/latest/jre/lib/security/US_export_policy.jar"
  logger.info "TASK: finish copying crypto_extensions jars"
end

task :removeApp do
  logger.info "TASK: Entered removeApp"
  # We can't just blindly remove jetty-#{app)* because some services have a 2 after them (programAvailability2)
  if (app == "caretakerWebService")
   run "if [ ! -d \"#{basedir}/caretakerWS_outputFiles\" ]; then  mkdir #{basedir}/caretakerWS_outputFiles ; fi"
   run "if [ \"$(ls -A #{basedir}/jetty-#{app}/matchbox/outputFiles)\" ]; then cp -pf #{basedir}/jetty-#{app}/matchbox/outputFiles/* #{basedir}/caretakerWS_outputFiles/; fi"   
  end
  run "sudo rm -rf #{basedir}/#{hiera('servlet_container')}-#{app}"
  run "sudo rm -rf #{basedir}/#{hiera('servlet_container')}-#{app}-*"
  run "sudo rm -rf #{basedir}/backup-#{app}"
  run "sudo rm -rf #{basedir}/backup-#{app}-*"
  run "sudo rm -rf #{basedir}/tmp/#{app}"
  run "if sudo /sbin/chkconfig --list #{app} ; then sudo /sbin/chkconfig --del #{app} ; echo \"removed #{app} from chkconfig\" ; fi"
  run "sudo rm -f /etc/init.d/#{app}"
end

task :removeSolr do
  #solr actually has disk persistence so we don't want to blow this away between upgrades
  logger.info "TASK: Entered removeApp (solr specific)"
  run "sudo rm -rf #{basedir}/jetty-#{app}/logs/* #{basedir}/jetty-#{app}/work/* #{basedir}/jetty-#{app}/webapps/* #{basedir}/jetty-#{app}/solr/lib #{basedir}/jetty-#{app}/solr/conf"
  run "sudo rm -rf #{basedir}/backup-#{app}"
  run "sudo rm -rf #{basedir}/tmp/#{app}"
  run "if sudo /sbin/chkconfig --list #{app} ; then sudo /sbin/chkconfig --del #{app} ; echo \"removed #{app} from chkconfig\" ; fi"
  run "sudo rm -f /etc/init.d/#{app}"
end

task :removeClover do
  #For clover, we don't want to blow away certain directories between upgrades
  logger.info "TASK: Entered removeApp (clover specific)"
  run "sudo rm -rf #{basedir}/jetty-#{app}/work/* #{basedir}/jetty-#{app}/webapps/* #{basedir}/jetty-#{app}/config/* #{basedir}/jetty-#{app}/sandboxes/*/lib/* #{basedir}/jetty-#{app}/sandboxes/*/dlib/* #{basedir}/jetty-#{app}/sandboxes/*/graph/* #{basedir}/jetty-#{app}/sandboxes/*/trans/*; exit 0"
  run "sudo rm -rf #{basedir}/backup-#{app}*"
  run "sudo rm -rf #{basedir}/tmp/#{app}*"
  run "if sudo /sbin/chkconfig --list #{app} ; then sudo /sbin/chkconfig --del #{app} ; echo \"removed #{app} from chkconfig\" ; fi"
  run "sudo rm -f /etc/init.d/#{app}"
end

######################################## BACKUP DIR ######################################### #:nodoc:

# Method to backup named dir to temp area
def backup_dir (app, dirname)
  if dirname
    logger.info "Backing up #{dirname} dir...."
    run "backup_dir=\"#{basedir}/jetty-#{app}-#{jetty_version}/#{dirname}\"; \
         if [ -d \"\$backup_dir\" ]; then \
           echo \"Found #{dirname} in \$backup_dir , backing up to #{tmpdir}/backup-#{app}/#{dirname}\"; \
           if [ -e #{tmpdir}/backup-#{app} ]; then \
             echo 'Directory #{tmpdir}/backup-#{app} exists, continuing'; \
           else \
             sudo mkdir -p #{tmpdir}/backup-#{app} && sudo chown #{user} #{tmpdir}/backup-#{app}; \
           fi; \
           mv \$backup_dir #{tmpdir}/backup-#{app}/#{dirname}; \
         fi"
  end
end

######################################## RESTORE DIR ######################################### #:nodoc:

# Method to restore named dir from temp area
def restore_dir (app, dirname)
  if dirname
    logger.info "Restoring backed up #{dirname} dir...."
    run "restore_dir=\"#{tmpdir}/backup-#{app}/#{dirname}\"; \
         if [ -d \"\$restore_dir\" ]; then \
           echo \"Found backed up #{dirname} in \$restore_dir , restoring to #{basedir}/jetty-#{app}-#{jetty_version}/#{dirname}\"; \
           mv \$restore_dir #{basedir}/jetty-#{app}-#{jetty_version}/#{dirname}; \
         fi"
  end
end

######################################## INSTALL JETTY ######################################### #:nodoc:

# Method to install Jetty to your target machine
def jetty_install (app, jetty_version)
  logger.level = Capistrano::Logger::INFO 
 
  set(:app) do
    Capistrano::CLI.ui.ask "Enter application name: (eg. linearDataService)"
  end unless variables[:app]
  # get jetty
  logger.info "Downloading Jetty #{jetty_version} zip file from the repo"
  run "sudo mkdir -p #{tmpdir} && sudo chown #{user} #{basedir} #{tmpdir}"
  begin
    run "cd #{basedir} && sudo wget #{wget_params} #{hiera('jetty_repodir')}/jetty-#{jetty_version}.new.zip -O jetty-#{jetty_version}_#{app}.zip"
  rescue
    logger.info "jetty_install failing back to a local wget and scp up to the server, this will take a bit more time..."
    `wget #{wget_params} #{hiera('jetty_repodir')}/jetty-#{jetty_version}.new.zip -O working/jetty-#{jetty_version}_#{app}.zip`
    upload("working/jetty-#{jetty_version}_#{app}.zip","#{tmpdir}/jetty-#{jetty_version}_#{app}.zip", :via => :scp)
    run "sudo cp #{tmpdir}/jetty-#{jetty_version}_#{app}.zip #{basedir}/jetty-#{jetty_version}_#{app}.zip"
  end
  # install jetty
  run "cd #{basedir} && if [ ! -e jetty-#{app}-#{jetty_version} ]; then sudo rm -rf #{basedir}/tmp/jetty/#{app} ; sudo mkdir -p #{basedir}/tmp/jetty/#{app} && sudo unzip -q -d #{basedir}/tmp/jetty/#{app} ./jetty-#{jetty_version}_#{app}.zip \"jetty-*#{jetty_version}*/*\" && sudo mv #{basedir}/tmp/jetty/#{app}/jetty-*#{jetty_version}* ./jetty-#{app}-#{jetty_version} ; else echo 'jetty-#{app}-#{jetty_version} exists'; fi "
  run "sudo rm -f #{basedir}/jetty-#{app}"
  run "sudo ln -sf #{basedir}/jetty-#{app}-#{jetty_version} #{basedir}/jetty-#{app}"
  run "if [ ! -e #{basedir}/jetty-#{app}/config ]; then sudo mkdir #{basedir}/jetty-#{app}/config; fi " 
  run "if [ ! -e #{basedir}/jetty-#{app}/work ]; then sudo mkdir #{basedir}/jetty-#{app}/work; fi "

  logger.info "jetty-#{jetty_version}.zip has been unpacked and linked to jetty-#{app}-#{jetty_version}"

  logger.info "Setting permissions on #{basedir}/jetty-#{app}"
  run "sudo chown -R #{user} #{basedir}/jetty-#{app}*"
  
  logger.info "Creating directories for backups"
  run "if [ -e #{basedir}/backup-#{app} ]; then echo 'Directory #{basedir}/backup-#{app} exists, continuing'; else sudo mkdir -p #{basedir}/backup-#{app} && sudo chown #{user} #{basedir}/backup-#{app}; fi"
  
  logger.info "chmod 775'ing all the directories"
  run "find #{basedir}/jetty-#{app} -type d | xargs -I{} -n1 chmod 775 {}"

  logger.info "ensuring that jetty.sh is executable"
  run "chmod 775 #{basedir}/jetty-#{app}/bin/jetty.sh"

  logger.info "removing #{basedir}/META-INF dir which jetty insists on creating..."
  run "if [ -e #{basedir}/META-INF ]; then rm -rf #{basedir}/META-INF ; fi "

  # removing test apps that come with jetty distro
  run "sudo rm -rf  #{basedir}/jetty-#{app}/contexts/* #{basedir}/jetty-#{app}/webapps/*"

  logger.info "Making sure that we have /opt/xcal/bin/jmxsh-R5.jar"
  run "if  [ ! -e /opt/xcal/bin ]; then sudo mkdir -p /opt/xcal/bin ; sudo chown #{user} /opt/xcal/bin ; fi"
  run "if  [ ! -e /opt/xcal/bin/jmxsh-R5.jar ]; then cd /opt/xcal/bin && wget #{wget_params} #{repo}/jmxsh/jmxsh-R5.jar ; fi"

  logger.info "FINISHED: jetty base installation for #{app}"
  
end
