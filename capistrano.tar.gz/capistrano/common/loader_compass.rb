###########################################
# Loader file that loads rb files in order
###########################################

logger.info ">>>>>  Just entered loader_compass.rb "

# load hiera
load "./common/hiera.rb"
logger.info ">>>>> loaded hiera"

# get groups of services
DataServicesCompass = hiera('services.DataServicesCompass')
WebServicesCompass = hiera('services.WebServicesCompass')
SiriusServicesCompass = hiera('services.SiriusServicesCompass')
CloverService = hiera('services.CloverService')
SOLRs = hiera('services.SOLRs')
SOLR_4_SERVICES = hiera('services.SOLR_4_SERVICES')
Indexers = hiera('services.Indexers')
ServiceInterruptus = hiera('services.ServiceInterruptus')
UDBBrowseServices = hiera('services.UDBBrowseServices')
UDBServices = hiera('services.UDBServices')
NGBServices = hiera('services.NGBServices')
SingleNodeServices = hiera('services.SingleNode')

DataAndWebServices = DataServicesCompass | WebServicesCompass 
JettyServices = DataServicesCompass | WebServicesCompass | CloverService | SOLRs
UDBCommonServices = UDBServices | UDBBrowseServices | NGBServices

### selective loading ###
load "./conf/dataServices_compass.rb" if DataServicesCompass.include?(svc)
load "./conf/webServices_compass.rb" if WebServicesCompass.include?(svc)
load "./conf/cloverServer.rb" if CloverService.include?(svc)
load "./conf/solr.rb" if SOLRs.include?(svc)
load "./conf/solr4.rb" if SOLR_4_SERVICES.include?(svc)
load "./conf/Indexer.rb" if Indexers.include?(svc)
load "./conf/serviceInterruptus.rb" if ServiceInterruptus.include?(svc)
load "./conf/udbBrowseServices.rb" if UDBBrowseServices.include?(svc)
load "./conf/udbServices.rb" if UDBServices.include?(svc)
load "./conf/ngbServices.rb" if NGBServices.include?(svc)
load "./conf/qam_report.rb" if svc == "qamParityReport"
load "./conf/ppvgap_report.rb" if svc == "ppvGapReport"
load "./conf/haproxy.rb" if svc == "haproxy"

load "./conf/shared_DS_Tasks.rb" if JettyServices.include?(svc)
load "./conf/udb_common_tasks.rb" if UDBCommonServices.include?(svc)

if svc == "sportsIngestWebService" and env == "chaz2Ingest"
  set :gateway, "ccpmer-po-cb204-p.po.ccp.cable.comcast.com"
end

# load env
if File.exists?("./conf/Env/#{env}.rb") 
  load "./conf/Env/#{env}.rb"
  logger.info ">>>>> loaded Env/#{env}"
else
  load "conf/Env/global.rb"
  raise "no env file to load and puppet_deploy is not set to true!" unless hiera('puppet_deploy') || exists?(:runClean)
end

### load common files ###
# load bom.rb?
unless(exists?(:noBom) || exists?(:nobom) || hiera('puppet_deploy'))
  load "./common/bom.rb"
  logger.info ">>>>> loaded bom"
end

# configure logging to splunk or not
# seting new param for env injection for file-based logging
#set :splunkLogging, (hiera('splunkLogging') && ! exists?(:log_to_files))

set :splunkLogging, (hiera('splunkLogging')) 
logger.info ">>>>> splunkLogging is set to: >#{splunkLogging}"

if splunkLogging == "inject"
  load "./common/logback_svcInjection.rb"
  logger.info ">>>>> Using local log file with env injection... BITT-8851 "
elsif splunkLogging == "true" or splunkLogging
  load "./common/splunkJavaLogging.rb"
  logger.info ">>>>> Using splunk TCP Logging... "
else
  load "./common/logback.rb"
  logger.info ">>>>> Using local log file (original logback)..."
end

load "./common/upload.rb"
logger.info ">>>>> loaded upload"
load "./common/basic.rb"
logger.info ">>>>> loaded basic"
load "./common/install.rb"
logger.info ">>>>> loaded install"
load "./common/op5_api.rb" 
logger.info ">>>>> loaded op5_api"
load "./common/depcheck.rb"
logger.info ">>>>> loaded depcheck"
load "./common/compass_cmd.rb"
logger.info ">>>>> loaded compass_cmd"
load "./common/orchestration.rb"
logger.info ">>>>> loaded orchestration"
load "./common/jmxsh.rb"
logger.info ">>>>> loaded jmxsh"
load "./common/nagiosYaml.rb"
logger.info ">>>>> loaded nagiosYaml"
load "./common/envbookmarks.rb"
logger.info ">>>>> loaded envbookmarks"
load "./common/dynatrace.rb"
logger.info ">>>>> loaded dynatrace"
load "./common/puppet_deploy.rb"
logger.info ">>>>> loaded puppet_deploy"

logger.info ">>>>>  Just exited loader_compass.rb "
