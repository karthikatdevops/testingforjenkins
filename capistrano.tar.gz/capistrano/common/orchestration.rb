# Non-jmx related tasks that work with applications already running in environments

OrchestrationDataServicesCompass = DataServicesCompass.select { |svc|
  ! %w[
    imageDataService
    imageIngestWebService
    imageIngest
    programAvailability2
  ].include?(svc)
}

# filter WebServicesCompass for some orchestration tasks
OrchestrationWebServicesCompass = WebServicesCompass.select { |svc|
  # exclude gridWS b/c it is so different
  # exclude cfigdevWebService since it's in cfig
  # exclude imageIngestWebService b/c we will deploy that separately
  ! %w[
    cfigdevWebService
    gridWebService
    searchUpdaterWebService2
  ].include?(svc)
}

# filter SOLRs and exclude programIndex2
OrchestrationSOLRs = SOLRs.select { |svc|
  ! %w[
    programIndex2
  ].include?(svc)
}

OrchestrationIndexers = Indexers.select { |svc|
  ! %w[

  ].include?(svc)
}

OrchestrationReadWriteServices = [ "cloverServer", "consistencyWebService", "ingestRovi", "offerWebService", "personaIngestWebService", "scheduledIngestWebService", "cacheProfileWebService" ]

OrchestrationCoreWebServices = [  "caretakerWebService",  "combineService", "gracenoteCombineService", "consistencyWebService", "imageWebService", "imageManagementWebService", "imageEventWebService", "ingestWebService", "mmmWebService", "mmpWebService", "offerWebService", "scheduledIngestWebService", "sportsIngestWebService", "imageEventWebService", "imageSelectorWebService" ]

OrchestrationRealTimeWebServices = [  "consistencyWebService", "imageWebService", "imageManagementWebService", "imageEventWebService", "ingestWebService",  "mmpWebService", "offerWebService", "personaIngestWebService", "imageEventWebService", "imageSelectorWebService", "cacheProfileWebService" ]

def get_cap_cmd_str(cap_env, cap_svc)
  "bundle exec cap -S env=#{cap_env} -S svc=#{cap_svc}"
end

def hosts_arg_specified?
  cli_hosts = ENV['HOSTS']
  if cli_hosts.nil?
    return false
  else
    return true
  end
end

# exec cmds and wait for all to complete - called by :orchestration_run
def exec_cmds_and_wait(cmds, prompt=false)

  STDOUT.sync = true

  # possibly prompt for confirmation
  assoc_jira_ticket = Array.new
  if prompt
    while true
      prompt_str = ["Please enter the associated Jira ticket for this work (leave blank if none)"]
      assoc_jira_ticket = Capistrano::CLI.ui.ask(prompt_str)
      if issue_exists_in_jira?(assoc_jira_ticket) or prompt_str.empty?
        break
      else
        logger.debug "Ticket not found"
      end
    end

    while true
      prompt_str = ["About to run:", cmds.collect {|c| [" $ ", c].join}, "Is that okay? [y/n]"].flatten.join("\n")
      case Capistrano::CLI.ui.ask(prompt_str)
      when "y", "Y"
        break
      when "n", "N"
        logger.important "Exiting..."
        exit
      else
        logger.debug "Invalid response"
      end
    end
  end

  comment_str = ["Executing the following commands on #{`hostname`.chomp} now:", cmds.collect {|c| ["* {{", c, "}}"].join}].flatten.join("\n")
  post_comment_to_jira(comment_str, assoc_jira_ticket) unless assoc_jira_ticket.empty?

  pids = Hash.new
  cmds.each { |c|
    pids[c] = fork
    exec(c) if pids[c].nil?
  }

  # wait for all
  pids_statuses = Process.waitall
  error_pids = pids_statuses.select { |p| not p.last.success? }
  error_pids.each do |e|
    failed_cmd = pids.index(e.first)
    logger_str = "Running `{{#{failed_cmd}}}` finished with exit code {{#{e.last.exitstatus}}}"
    logger.important logger_str

    #logger_str += ", logs attached." if failed_cmd.match(/> +(.*\.log)$/)
    post_comment_to_jira(logger_str, assoc_jira_ticket, $1) unless assoc_jira_ticket.empty?
  end

  if error_pids.empty?
    logger_str = "#{pids.count} cmds finished successfully for the #{confType} environment"
    logger.info logger_str
    post_comment_to_jira(logger_str, assoc_jira_ticket) unless assoc_jira_ticket.empty?
  end

  # return true if everything completed fine
  error_pids.empty?
end

# get cmd to run - called by :orchestration_run
def orchestration_run_cmd(svc, logdir)
  # get run_type
  raise "set :run_type" unless exists?(:run_type)
  case run_type
  when "deploy"
    "#{get_cap_cmd_str(confType, svc)} deploy_#{svc}_#{confType} -S bamaBOM=true -S bom=#{bom} #{cmd_opts} &> #{logdir}/#{svc}.log"
  when "shutdown"
    "#{get_cap_cmd_str(confType, svc)} #{confType}_#{svc} -S app=#{svc} stop_jetty -S nobom &> #{logdir}/#{svc}.log"
  when "restart"
    "#{get_cap_cmd_str(confType, svc)} #{confType}_#{svc} -S app=#{svc} restart_jetty -S nobom &> #{logdir}/#{svc}.log"
  when "graceful_restart"
    "#{get_cap_cmd_str(confType, svc)} updateConfigAndGracefulRestart_#{svc} -S nobom &> #{logdir}/#{svc}.log"
  when "reconfig"
    "#{get_cap_cmd_str(confType, svc)} updateConfigAndRestart_#{svc} -S nobom &> #{logdir}/#{svc}.log"
  when "reconfigLogToDisk"
    "#{get_cap_cmd_str(confType, svc)} updateConfigAndRestart_#{svc} -S nobom -S log_to_files &> #{logdir}/#{svc}.log"
  else
    raise "Invalid run_type"
  end
end

desc "Call this from other tasks after setting :run_type"
task :orchestration_run do

  # make logdir in working/
  set :logdir_suffix, "" unless exists?(:logdir_suffix)
  logdir = ["./working/", Time.now.strftime("%F_%H-%M-%S_%Z"), logdir_suffix].join
  `mkdir -p #{logdir}`
  logger.info "using #{logdir} for logs"

  # get services to deploy
  if exists?(:hiera_group)
    set :svcs_to_deploy, hiera("orchestration.#{hiera_group}")
  elsif exists?(:svc_group)
    SERVICE_GROUPS = {
      "data_services" => OrchestrationDataServicesCompass,
      "other_services" => CloverService | OrchestrationSOLRs | SOLR_4_SERVICES | OrchestrationIndexers,
      "web_services" => OrchestrationWebServicesCompass,
      "read_write_services" => OrchestrationReadWriteServices,
      "ngb_services" => UDBBrowseServices,
      "core_web_services" => OrchestrationCoreWebServices,
      "realtime_web_services" => OrchestrationRealTimeWebServices
    }
    set :svcs_to_deploy, SERVICE_GROUPS[svc_group] || raise(":svc_group should be one of #{SERVICE_GROUPS.keys.inspect}")
  elsif exists?(:svcs)
    set :svcs_to_deploy, svcs.split(",")
  else
    raise "Please specify '-S svc_group=<svc_group>' or '-S svcs=<svc,svc,svc>'"
  end

  # fastNFurious option
  set :cmd_opts, "-S dontCheckCapVersion=true -S force=true" if exists?(:fastNFurious)

  # can override opts for each cmd
  unless exists?(:cmd_opts)
    set :cmd_opts, "-S cleanServer=true -S force=true -S dontCheckCapVersion=true -S no_hiera_branch_check"
  end

  # build up commands to run
  cmds = Array.new
  svcs_to_deploy.each { |d|
    if find_task("#{confType}_#{d}")
      cmds << orchestration_run_cmd(d, logdir)
    end
  }

  # raise if no cmds to run
  raise "No cmds to run" if cmds.empty?

  # run commands
  exec_cmds_and_wait(cmds, true)
end

namespace :orchestration do
  desc "shutdown read-write ingest services"
  task :shutdown_ingest do
    find_and_execute_task "ingest_disable_service_monitoring"

    set :logdir_suffix, "_shutdown_ingest"
    set :svc_group, "read_write_services"
    set :run_type, "shutdown"
    find_and_execute_task "orchestration_run"
  end

  desc "restart read-write ingest services"
  task :restart_ingest do
    set :logdir_suffix, "_restart_ingest"
    set :svc_group, "read_write_services"
    set :run_type, "restart"
    find_and_execute_task "orchestration_run"
  end

  desc "restart read-write DataService shells"
  task :restart_ingest_dataservices do
    set :logdir_suffix, "_restart_ingest_dataservices"
    set :svc_group, "data_services"
    set :run_type, "restart"
    find_and_execute_task "orchestration_run"
  end

  desc "restart read-write WebService shells"
  task :restart_ingest_webservices do
    set :logdir_suffix, "_restart_ingest_webservices"
    set :svc_group, "web_services"
    set :run_type, "restart"
    find_and_execute_task "orchestration_run"
  end

  desc "restart Other ingest services"
  task :restart_ingest_other do
    set :logdir_suffix, "_restart_ingest_other"
    set :svc_group, "other_services"
    set :run_type, "restart"
    find_and_execute_task "orchestration_run"
  end

  desc "deploy image services"
  task :deploy_image_services do
    set :logdir_suffix, "_deploy_image_services"
    set :hiera_group, "image_services"
    set :run_type, "deploy"
    find_and_execute_task "orchestration_run"
  end

  desc "deploy data services"
  task :deploy_data_services do
    set :logdir_suffix, "_deploy_data_services"
    set :svc_group, "data_services"
    set :run_type, "deploy"
    find_and_execute_task "orchestration_run"
  end

  desc "deploy web services"
  task :deploy_web_services do
    set :logdir_suffix, "_deploy_web_services"
    set :svc_group, "web_services"
    set :run_type, "deploy"
    find_and_execute_task "orchestration_run"
  end

  desc "deploy realtime web services"
  task :deploy_realtime_web_services do
    set :logdir_suffix, "_deploy_realtime_web_services"
    set :svc_group, "realtime_web_services"
    set :run_type, "deploy"
    find_and_execute_task "orchestration_run"
  end

  desc "deploy other compass services"
  task :deploy_other_compass_services do
    set :logdir_suffix, "_deploy_other_compass_services"
    set :svc_group, "other_services"
    set :run_type, "deploy"
    find_and_execute_task "orchestration_run"
  end

  desc "deploy NGB services"
  task :deploy_ngb_services do
    set :logdir_suffix, "_deploy_ngb_services"
    set :svc_group, "ngb_services"
    set :run_type, "deploy"
    find_and_execute_task "orchestration_run"
  end

  desc "gracefully restart data services"
  task :gracefully_restart_data_services do
    set :logdir_suffix, "_gracefully_restart_data_services"
    set :svc_group, "data_services"
    set :run_type, "graceful_restart"
    find_and_execute_task "orchestration_run"
  end

  desc "reconfigure data services"
  task :reconfig_data_services do
    set :logdir_suffix, "_reconfig_data_services"
    set :svc_group, "data_services"
    set :run_type, "reconfig"
    find_and_execute_task "orchestration_run"
  end

  desc "reconfigure web services"
  task :reconfig_web_services do
    set :logdir_suffix, "_reconfig_web_services"
    set :svc_group, "web_services"
    set :run_type, "reconfig"
    find_and_execute_task "orchestration_run"
  end

desc "reconfigure CORE web services"
  task :reconfig_core_web_services do
    set :logdir_suffix, "_reconfig_core_web_services"
    set :svc_group, "core_web_services"
    set :run_type, "reconfig"
    find_and_execute_task "orchestration_run"
  end

desc "reconfigure REAL TIME web services"
  task :reconfig_realtime_web_services do
    set :logdir_suffix, "_reconfig_realtime_web_services"
    set :svc_group, "realtime_web_services"
    set :run_type, "reconfig"
    find_and_execute_task "orchestration_run"
  end

desc "reconfigure and enable logging to disk in logback"
  task :reconfigLogToDisk_web_services do
    set :logdir_suffix, "_reconfigLogToDisk_web_services"
    set :svc_group, "web_services"
    set :run_type, "reconfigLogToDisk"
    find_and_execute_task "orchestration_run"
  end

  desc "reconfigure and logging to disk enabled in logback"
  task :reconfigLogToDisk_core_web_services do
    set :logdir_suffix, "_reconfigLogToDisk_web_services"
    set :svc_group, "core_web_services"
    set :run_type, "reconfigLogToDisk"
    find_and_execute_task "orchestration_run"
  end

end ###########################################################################

task :ingest_disable_service_monitoring do
    OrchestrationReadWriteServices.each do |e|
      set :hiera_svc, e
      find_and_execute_task("#{confType}_#{e}")
      logger.info "shutting down service monitoring for #{e}..."
      find_servers(:roles => e.to_sym).each do |h|
        op5_api_client.disable_service(e, h.to_s)
      end
    end

    logger.info "Disabling of monitoring for #{OrchestrationReadWriteServices.count} ingest-service(s) finished"

    set :hiera_svc, "feedgenWebService"
    find_and_execute_task("#{confType}_feedgenWebService")
    logger.info "shutting down service monitoring for feedgenWebService..."
    find_servers(:roles => :feedgenWebServiceWebHosts).each do |h|
      op5_api_client.disable_service("Feedgen", h.to_s)
      if ( h.to_s.split('.')[1] == 'br' ) and ( confType != 'merbrocIngest' )
        other_op5_api_client = Op5ApiClient.new(self, 'merbrocIngest', logger)
        other_op5_api_client.disable_service("Feedgen", h.to_s)
      end
    end

    logger.info "Disabling of monitoring for Feedgen finished"
end

SiriusServicesCompass.each do |service|
  task "#{service}_isolate".to_sym do
    find_and_execute_task("#{confType}_#{service}")
    puts "nulling out sirius.cluster.config"
    run "echo '' > /opt/ds/jetty-#{service}/config/sirius.cluster.config"
  end

  task "#{service}_mesh".to_sym do
    find_and_execute_task("#{confType}_#{service}")
    puts "meshing sirius nodes"
    run_serially_in_batches(:find_server_opts => {:roles => service.to_sym}) do |server_options|
      upload(StringIO.new(get_sirius_config_str),"/var/tmp/sirius.cluster.tmp", :via => :scp, :mode => 0664)
      run "sudo mv /var/tmp/sirius.cluster.tmp /opt/ds/jetty-#{service}/config/sirius.cluster.config"
    end
  end

  task "#{service}_make_bootstrap".to_sym do
    bootstrap_sirius_log_dir = "/opt/ds/sirius"
    sirius_log_file = exists?(:backup) ? "#{backup}_#{service}.tar.gz" : "#{service}.tar.gz"
    find_and_execute_task("#{confType}_#{service}")
    
    # only work on one host
    host_with_sirius_log_file = hiera(hiera_svc, :priority, "nodes/#{hiera_env}").first
    ENV['HOSTS'] = host_with_sirius_log_file
    set :hiera_host, host_with_sirius_log_file
    logger.important "making bootstrap sirius log file at #{host_with_sirius_log_file}:#{bootstrap_sirius_log_dir}/#{sirius_log_file}"

    if exists?(:backup)
      # isolate before stopping
      find_and_execute_task("#{service}_isolate")
      # stop service so the sirius log dir stops being written to
      run "sudo service #{service} stop"
    end

    run "cd #{bootstrap_sirius_log_dir}/#{service} && tar -zcf ../#{sirius_log_file} ./*"

    if exists?(:backup)
      # rewrite sirius.cluster.config
      upload(StringIO.new(get_sirius_config_str),"#{basedir}/jetty-#{service}/config/sirius.cluster.config", :via => :scp, :mode => 0664)
      # start service
      run "sudo service #{service} start"
    end

    # download and remove backup?
    if exists?(:download_then_delete)
      download("#{bootstrap_sirius_log_dir}/#{sirius_log_file}", "/var/tmp/#{sirius_log_file}")
      run "rm #{bootstrap_sirius_log_dir}/#{sirius_log_file}"
    end

    logger.important "sirius log file completed!"
  end

  task "#{service}_begin_distributing_bootstrap".to_sym do
    find_and_execute_task("#{confType}_#{service}")

    if hiera('local_grid_environments')
      envs_to_dist_to = [ confType ] + hiera('local_grid_environments')
    else
      envs_to_dist_to = [ confType ] + hiera('dependant_environments')
    end

    hosts = all_hosts_from_all_environments_with_role( service, envs_to_dist_to )

    # where the boostrap file was made
    bootstrap_sirius_log_dir = "/opt/ds/sirius"
    sirius_log_file = "#{service}.tar.gz"

    if hiera('dependant_environments')
      first_host = hosts.delete_at(0)
      # copy to /tmp on first host
      run("cp #{bootstrap_sirius_log_dir}/#{sirius_log_file} /var/tmp/#{sirius_log_file}", { :hosts => first_host })
      logger.info "To take sirius_log_file from #{first_host} and distribute to #{hosts.count} hosts"
      download("#{bootstrap_sirius_log_dir}/#{sirius_log_file}", "/var/tmp/#{sirius_log_file}", { :hosts => first_host, :via => :scp })
    end
    run("mkdir -p #{sirius_log_dir}", { :hosts => hosts })

    if( exists?(:using) && using == "scp" )
      hosts.each do |host|
        system("rsync -e 'ssh -q -o StrictHostKeyChecking=no' /var/tmp/#{sirius_log_file} #{user}@#{host}:#{sirius_log_dir}/#{sirius_log_file} &")
      end
    elsif( exists?(:using) && using == "http")
      cap_host = `hostname`.chomp
      run("wget -q -N --no-proxy http://#{cap_host}:8080/#{sirius_log_file} -O #{sirius_log_dir}/#{sirius_log_file}", { :hosts => hosts })
    else # using == "murder"
      # XXX . . .
      raise ":using is not set correctly"
    end
  end

  task "#{service}_check_bootstrap_distribution".to_sym do
    find_and_execute_task("#{confType}_#{service}")

    if hiera('local_grid_environments')
      envs_to_dist_to = [ confType ] + hiera('local_grid_environments')
    else
      envs_to_dist_to = [ confType ] + hiera('dependant_environments')
    end

    hosts = all_hosts_from_all_environments_with_role( service, envs_to_dist_to )

    logger.info "To check #{hosts.count} hosts for the presence of bootstrap file"

    sirius_log_file="#{service}.tar.gz"

    first_host = hosts.delete_at(0)
    begin
      run("ls -l #{sirius_log_dir}/#{sirius_log_file}", { :hosts => first_host })
    rescue
    end

    begin
      run("ls -l #{sirius_log_dir}/#{sirius_log_file}", { :hosts => hosts })
    rescue
    end
  end
end

[ "personaIngestWebService", "imageWebService", "consistencyWebService" ].each do |service|
  task "sequence_reset_#{service}" do
    set :app, service
    find_and_execute_task("#{confType}_#{app}")
    stop_jetty
    jobDSUrl = "http://#{dsMerlinIngestVip}:#{hiera('jobDataService_web_port')}/jobDataService/data/ServiceState?schema=1.3.0&form=cjson&pretty=true&byService=#{app}&token=#{getToken}"
    logger.info "deleteing sequences from jobDS"
    response = RestClient.delete jobDSUrl
    puts response
    start_jetty
  end
end


# SHOW COMMANDS
#
# A series of commands that will scan the properties files and return
# information about what it matches in an env
#

set :serviceShellProperties, 'config/DS_Configuration.properties'

def grepPropertiesFile(service,type)
  begin
    logger.info "Scanning #{service}"
    find_and_execute_task("#{confType}_#{service}")
    set :app, "#{service}"
    case
    when type.match('user')
      run "grep -e db\.username /opt/ds/jetty-#{app}/#{serviceShellProperties} "
    when type.match('jdbc')
      run "grep -e jdbc /opt/ds/jetty-#{app}/#{serviceShellProperties} "
    when type.match('httpUrl')
      run "grep -e http /opt/ds/jetty-#{app}/#{serviceShellProperties} | grep -v bean | grep -e auth -e ccp || true "
    else
      logger.info "You didn't specify a type."
    end
    roles.clear
  rescue Capistrano::Error
    logger.info "error grepping properties file."
    exit 1
  end
end

task "showDbUser".to_sym do
  OrchestrationDataServicesCompass.each do |e|
    grepPropertiesFile(e,'user')
  end
end

task "showDbConnection".to_sym do
  OrchestrationDataServicesCompass.each do |e|
    grepPropertiesFile(e,'jdbc')
  end
end

task "showHttpUrl".to_sym do
  OrchestrationDataServicesCompass.each do |e|
    grepPropertiesFile(e,'httpUrl')
  end
  OrchestrationWebServicesCompass.each do |e|
    grepPropertiesFile(e,'httpUrl')
  end
end

#
# END SHOW Commands
#

task "fullDSRestart".to_sym do
  OrchestrationDataServicesCompass.each do |e|
    if find_task("#{confType}_#{e}")
      logger.info "restarting #{e}..."
      set :app, "#{e}"
      find_and_execute_task("#{confType}_#{e}")
      restart_jetty
    end
    roles.clear
  end
end

task "checkRO".to_sym do
  DataAndWebServices.each do |e|
    if find_task("#{confType}_#{e}")
      logger.info "checking #{e}..."
      set :app, "#{e}"
      find_and_execute_task("#{confType}_#{e}")
      run "/usr/lib64/nagios/plugins/check_ro"
    end
    roles.clear
  end
end

task "fullDSLogbackReconfig".to_sym do
  DataAndWebServices.each do |e|
    if find_task("#{confType}_#{e}")
      logger.info "recreating logging configs #{e}..."
      if ! `#{get_cap_cmd_str(confType, e)} updateLoggingConfigAndPersist_#{e}_#{confType} -S nobom`
        puts "error running updateLoggingConfigAndPersist_#{e}_#{confType}"
        exit 1
      end
    end
  end

end



task "siriusServicesMakeBootstrapAndAdvise".to_sym do
  STDOUT.sync = true
  logdir = "./working/siriusServicesBootstrapAndDeploy-#{Time.now.to_i}"
  `mkdir -p #{logdir}`
  pids = Hash.new
  SiriusServicesCompass.each do |service|
    if find_and_execute_task("#{confType}_#{service}")
      logger.info "deploying #{service}..."
      hiera('dependant_environments').each do |dep_env|
        pids[dep_env] = fork
        exec("#{get_cap_cmd_str(dep_env, service)} #{service}_isolate -S nobom -S user=#{user} &> #{logdir}/#{service}_isolate_#{dep_env}.log") if pids[dep_env].nil?
      end

      pids_statuses = Process.waitall

      error_pids = pids_statuses.select { |p| not p.last.success? }
      error_pids.each do |e|
        dep_env_name = pids.index(e.first)
        logger.important "isolate of #{dep_env_name} finished with exit code #{e.last.exitstatus}, see #{logdir}/#{service}_isolate_#{dep_env_name}.log"
        # don't exit b/c it's hard to isolate when disks are full
        # exit 1
      end
      logger.info "isolate of #{pids.count} dependant environment(s) finished successfully" if error_pids.empty?

      run "if [ -s /etc/init.d/#{service} ]; then #{sudo} service #{service} stop; fi"

      # Not saving a copy of previous copy now

      logger.info "executing sirius_bulkLoadMode deploy of #{service} to #{confType}, this step may take up to 90 min."

      set :cleanServer, true
      set :cleanGridWebService, true
      set :force, true
      set :sirius_bulkLoadMode, true
      find_and_execute_task("deploy_#{service}_#{confType}")

      # Assuming application came up and alive check just succeeded, shutting down immediately
      run("if [ -s /etc/init.d/#{service} ]; then #{sudo} service #{service} stop; fi", { :once => true })

      find_and_execute_task("#{service}_make_bootstrap")

      logger.important "Then, distribute the bootstrap file to all local environments (must be run on datacenter-local cap-admin servers)"
      logger.important "\`#{get_cap_cmd_str(confType, service)} #{service}_begin_distributing_bootstrap -S bom=#{bom} -S bamaBOM=true -S using=http\`"

      logger.important "...checking the status by using the following command:"
      logger.important "\`#{get_cap_cmd_str(confType, service)} #{service}_check_bootstrap_distribution -S bom=#{bom} -S bamaBOM=true\`"

      logger.important "After distribution is complete, deploy to peer instances and dependant environments using the following command (replacing ... for each environment):"
      logger.important %Q|\`#{get_cap_cmd_str(confType, service)}... deploy_#{service}_... -S force=true -S bom=#{bom} -S bamaBOM=true -S cleanServer=true -S cleanGridWebService -S bootstrap=true|

      logger.important "To install to another data-center..."
      logger.important "\`ssh user_name@ccpcap-br-c002-p.br.ccp.cable.comcast.com\`"
      logger.important "\`sudo su - xdeploy\`"
      cap_host = `hostname`.chomp
      logger.important "\`wget -q -N --no-proxy http://#{cap_host}:8080/#{service}.tar.gz -O #{sirius_log_dir}/#{service}.tar.gz\`"
      logger.important "...then follow the steps above."
    end
  end

  exec "cd #{logdir} ; pwd"
end

# service: camel-case string, e.g. "gridWebService"
# envs: array of string, e.g. [ "merch2cIngest", "ch2c" ]
def all_hosts_from_all_environments_with_role(service, envs)
  envs.collect { |e|
    hiera(service, :priority, "nodes/#{e}")
  }.flatten.reject { |h|
    h.nil?
  }
end

def getToken
  mpxUser = case env
  when /mciGbenv/
    "capistrano_devf@ccp.com"
  when /ccpcicap/
    "capistrano_devf@ccp.com"
  when /merdevl/
    "capistrano_devf@ccp.com"
  when /cmpstk/
    "capistrano_merqa@ccp.com"
  when /merqaTest104/
    "capistrano_merqa@ccp.com"
  when /poc/
    "capistrano_poc@ccp.com"
  when /ch2/
    "clover_server_stage@ccp.com"
  when /broc/
    "capistrano_poc@ccp.com"
  when /dev_bo_po/
    "caretaker_service_gracenote_dev@ccp.com"
  when /ap/
    "capistrano_poc@ccp.com"
  when /chaz2Ingest/
    "capistrano_poc@ccp.com"
  end
  mpxPassword = "C0mcast!!!"
  if confType.include?("br")
    signInResponse = RestClient.get "https://identity.auth.br.ccp.cable.comcast.com/idm/web/Authentication/signIn", :Host => "identity.auth.po.ccp.cable.comcast.com", :params => {:form => 'json', :schema => '1.0', :username => mpxUser, :password => mpxPassword}
  else
    signInResponse = RestClient.get "#{hiera('mpx_identity_url')}web/Authentication/signIn?form=json&schema=1.0&username=" + mpxUser + '&password=' + mpxPassword
  end
  signInJSON = JSON.parse(signInResponse)
  token = signInJSON["signInResponse"]["token"]
  if token
  	logger.debug "Using token #{token}"
  else
      puts "Unable to get auth token."
      exit 1
  end
  token
end

task "BulkOnTheSide".to_sym do
  service=svc
  STDOUT.sync = true
  logdir = "./working/BulkOnTheSide-#{Time.now.to_i}"
  `mkdir -p #{logdir}`
   find_and_execute_task("#{confType}_#{service}")
   run "if [ -s /etc/init.d/#{service} ]; then #{sudo} service #{service} stop; fi"

      logger.info "executing sirius_bulkLoadMode deploy of #{service} to #{confType}, this step may take up to 90 min."

      set :cleanServer, true
      set :cleanGridWebService, true
      set :force, true
      set :sirius_bulkLoadMode, true
      find_and_execute_task("deploy_#{service}_#{confType}")

      # Assuming application came up and alive check just succeeded, shutting down immediately
      run("if [ -s /etc/init.d/#{service} ]; then #{sudo} service #{service} stop; fi", { :once => true })
#      find_and_execute_task("#{service}_make_bootstrap")

  exec "cd #{logdir} ; pwd"
end
