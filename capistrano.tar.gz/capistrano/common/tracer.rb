# load this file in capistrano to see what tasks are isseud by what user, and to log the timing if :timetasks is set to true
# - logs failed commands and the timing
# - could be helpful when there is an error in a big task

desc "allows a command to be run on localhost"
def run_local cmd
puts %[ * executing locally "#{cmd}"]
`#{cmd}`
end

# this runs id locally and saves the username to user_id for accounting purposes
set :user_id, run_local("id -nu")

#get rid of the \n
user_id.chomp!

MAX_LOGGER_LENGTH = 950

# add before and after hooks for a task for maintaining trace_array and temp_hash
# trace_array holds all the tasks w/ their levels
# - will be used for printing out/logging after everything is done: 
# - example = [ 
#       [task_0 name, level, start time, duration, success?], 
#       [task_0.1 name, level, start time, duration, success?],
#       [task_1 name, level, start time, duration, success?] 
#   ] 
#
# temp_hash is used to keep track of what gets called
# - before a task is run, the task name, current time and info are put into temp_hash
# - after a task is run
#     - the duration is calculated
#     - take out task from temp_hash
#     - put info in trace_array in the right spot
# - example = {
#     task_0 name: [trace_array index, level, start time]
#     task_0.1 name: [trace_array index, level, start time]
#   }
#
def trace_task(taskname)
  before taskname.to_sym do
    temp_hash[taskname] = [trace_array_index, trace_level, Time.now]
    set :trace_array_index, trace_array_index + 1 
    set :trace_level, trace_level + 1
  end
  
  after taskname.to_sym do 
    this_index, this_level, this_start_time = temp_hash.delete(taskname)
    trace_array[this_index] = [taskname, this_level, this_start_time, Time.now - this_start_time, true]
    set :trace_level, trace_level - 1
  end
end

# get tasks called on the command line
def get_cli_tasks
  cli = Capistrano::CLI.new(ARGV)
  cli.parse_options!
  cli.options[:actions]
end

# return array of all tasks, except for ones w/ the tracer namespace set to true
def get_tracer_tasks
  all_tasks = Array.new
  task_list(true).each do |t| 
    all_tasks << t.fully_qualified_name unless(["tracer"].include? "#{t.namespace.name}")
  end
  all_tasks
end

###########Begin Code for generate bama json post##########

def bama_task(task_name)
  before task_name.to_sym do
    bama_temp_hash[task_name] = [bama_array_index,  Time.now]
    set :bama_array_index, bama_array_index + 1 
  end
  
  after task_name.to_sym do 
    bama_this_index, bama_this_start_time = bama_temp_hash.delete(task_name)
    bama_array[bama_this_index] = [task_name, bama_this_start_time, Time.now - bama_this_start_time, true]
  end
end

# return array of all tasks, except for ones w/ the BAMA namespace set to true
def get_bama_tasks
  bama_all_tasks = Array.new
  task_list(true).each do |t| 
    bama_all_tasks << t.fully_qualified_name if "#{t.fully_qualified_name}".index("deploy_")==0 || "#{t.fully_qualified_name}".index("sandbox_deploy_")==0
  end
  bama_all_tasks
end

###################End###################################


# what to do when there is an error
def handle_on_rollback
  logger.info "*** Error running #{current_cli_task} ***"
  
  # put all the tasks left in temp_hash into trace_array, marking them as failures
  temp_hash.each do |k, v|
    this_index, this_level, this_start_time = v
    trace_array[this_index] = [k, this_level, this_start_time, Time.now - this_start_time, false]
  end
  print_and_log_trace_array  
  if bamatasks
    bama_temp_hash.each do |k, v|
      bama_this_index, bama_this_start_time = v
      if k.index("deploy_")==0 || k.index("sandbox_deploy_")==0
        bama_array[bama_this_index] = [k,bama_this_start_time, Time.now - bama_this_start_time, false]
      end
    end
    post_bama_json
  end
  
  # print out Cap facts
  if exists?(:collect_cap_facts) && collect_cap_facts.to_s == "true"
    find_and_execute_task "cap_facts:write"
  end
  
end

# print / log trace array - get the indices for where sub-arrays of CLI tasks begin and end, call print_and_log_trace_subarray
def print_and_log_trace_array
  cli_tasks_begin_indices = Array.new
  trace_array.each_with_index do |piece, i|        
    if piece[1] == 0
      cli_tasks_begin_indices << i
    end
  end
  cli_tasks_end_indices = cli_tasks_begin_indices.collect {|x| x - 1}
  cli_tasks_end_indices.shift
  cli_tasks_end_indices << trace_array.size - 1
  
  cli_tasks_begin_indices.each_with_index do |cli_task_begin_index, i|
    cli_task_end_index = cli_tasks_end_indices[i]
    print_and_log_trace_subarray(trace_array[cli_task_begin_index..cli_task_end_index])
  end
end

# print / log the tasks subarray in trace array
def print_and_log_trace_subarray(trace_subarray)
  # print to stdout
  trace_subarray.each_with_index do |piece, i|
    taskname, level, start_time, duration, success = piece
    line = "+"
    1.upto(level) { line += '--' }
    line += "#{taskname} (#{success}, #{duration})"
    logger.info(line)
  end
  
  # log unless '-S noLog=true'
  unless(exists?(:noLog) && noLog.to_s == "true")
    begin
      run get_logger_command(trace_subarray), :once => true
    rescue StandardError => e
      logger.info "Error trying to log: #{e.message}"
    end
  end
end

##### building logger command #####
# get string of command to run
# 1. log a summary message (message id, user, total time...)
# 2. log the timing of the tasks (from timing_array)
#    - make sure logger string does not exceed MAX_LOGGER_LENGTH
#    - round to three decimal places to save space
def get_logger_command(trace_subarray)
  message_id = Time.now.to_i.to_s + "_" + rand(100000).to_s
  get_logger_command_summary(message_id, trace_subarray) + get_logger_command_timing(message_id, trace_subarray)
end


def get_logger_command_summary(message_id, trace_subarray)
  taskname, level, start_time, duration, success = trace_subarray.first
  
  if(exists?(:nobom) or exists?(:noBom))
    bom_str = "nobom"
  elsif(exists?(:bom))
    bom_str = "#{bom}"
  else
    bom_str = "NOT_SET"
  end
  
  logger_summary_message = "m_id=#{message_id} summary user=#{source_user} start_time=#{start_time.to_i} task=#{taskname} total_time=#{'%.3f' % duration} success=#{success} confType=#{confType} bom=\"#{bom_str}\""
  
  if(exists?(:message))
    escaped_message = message.gsub(/['"]/, '')
    logger_summary_message += " message=\"#{escaped_message}\"" 
  end
  
  desc = find_task(taskname).desc
  if desc != nil
    # just take out single and double quotes that may mess up logger command
    escaped_desc = desc.gsub(/['"]/, '')
    logger_summary_message += " desc=\"#{escaped_desc}\""
  end
  
  raise "The summary message for logging is too long" if logger_summary_message.length > MAX_LOGGER_LENGTH
  "logger -t capistrano_timing -p user.notice '#{logger_summary_message}';"
end


def get_logger_command_timing(message_id, trace_subarray)
  timing_str = ""
  trace_subarray.each {|x| timing_str += " #{x[0]}=#{'%.3f' % x[3]}"}
  # get length of a sample header
  header_length = get_logger_command_timing_header(message_id, 1000).length;
  timing_str_parts = split_string_on_spaces(timing_str, MAX_LOGGER_LENGTH - header_length)
  
  logger_command_timing = ""
  timing_str_parts.each_with_index {|part, i| logger_command_timing += "logger -t capistrano_timing -p user.notice '#{get_logger_command_timing_header(message_id, i) + part}';"}
  logger_command_timing
end

# split string into array of strings less than given length, split at a space
def split_string_on_spaces(str, max_length)
  if str.length <= max_length
    return [str]
  else
    space_index = str[0, max_length].rindex(' ')
    raise "String has part that is too long to be split into parts of #{max_length}" if space_index == nil
    return [str[0, space_index+1]] + split_string_on_spaces(str[space_index+1, str.length], max_length)
  end
end

# get header string for the logger message, given a message id and message part
def get_logger_command_timing_header(message_id, message_part)
  "m_id=#{message_id} m_part=#{message_part} ---"
end
#####################################

# before running a CLI command, add tracing hooks to all tasks and run command line tasks 
# until handle_on_rollback is called or all command line tasks are run successfully
on :start do
  logger.info "Loading for tracer.rb..."
  raise "Please specify confType" unless exists?(:confType)
  set :temp_hash, Hash.new
  set :trace_array, Array.new
  set :trace_array_index, 0
  set :trace_level, 0
  if bamatasks
    set :bama_temp_hash, Hash.new
    set :bama_array, Array.new
    set :bama_array_index, 0
  end
   
  get_tracer_tasks.each {|t| 
    trace_task(t)  
  }
  #puts "bamatasks=#{bamatasks}" 
  if bamatasks 
    get_bama_tasks.each{|t|
      if exists?(:bom)
          bama_task(t)
      end
    }
  end
  
  find_and_execute_task("tracer:run_cli_tasks")
  # we reach here only when there are no errors
  print_and_log_trace_array
  if bamatasks
    post_bama_json
  end
  
  # print out Cap facts
  if exists?(:collect_cap_facts) && collect_cap_facts.to_s == "true"
    find_and_execute_task "cap_facts:write"
  end
  
  exit
end

########## tasks for running command line tasks while catching errors ######################
namespace :tracer do
  desc "tracer task: use -S trace=true to use. bama json task: use -S bama_json=true to use"
  task :run_cli_task do
    on_rollback { handle_on_rollback }
    find_and_execute_task("#{current_cli_task}")
  end

  task :run_cli_tasks do
    desc "tracer task: use -S trace=true to use. bama json task: use -S bama_json=true to use"
    get_cli_tasks.each do |cli_task|
      # puts "current task: #{cli_task}"
      set :current_cli_task, "#{cli_task}"
      transaction do
        run_cli_task
      end
    end
  end
end


###########Code to generate bama json post##########


# generate the bama json message and post to bama server
def post_bama_json
  env=`hostname | cut -d '-' -f 2`.chomp.strip
  set :bama_json_url, "http://bamaprod.chalybs.net/json/" if !exists?(:bama_json_url)
  set :bama_json_url, "http://69.241.25.244:8087/json/" if (defined?env and !env.empty? and (env.eql?("po") || env.eql?("br"))) || exists?(:bama_json_url)
  set :bama_json_url, "#{bama_json_url}/" if "#{bama_json_url}".rindex('/')!="#{bama_json_url}".length-1 #Check to see if it is ending with '/'. If not, append it. 
  emails = { "dillera" => "Andrew_Diller@Comcast.com","sbollepalli" => "Srinivasarao_Bollepalli@cable.comcast.com","bama-errors" => "xcal-ds-bama-errors@lists.chalybs.net", "joew3" => "joe_wilcoxson@cable.comcast.com", "ksin200" => "Kevin_Sin@cable.comcast.com" }
  mail_from=emails[`id -nu`.chomp]
  if mail_from.nil? || mail_from.empty?
    mail_from=`id -nu`.chomp<<"@"<<`hostname`.chomp
  end
  mail_to=emails["bama-errors"]
  if bama_array.length ==1 && defined? package && (!package.empty?) && defined? artifact_file && (!artifact_file.empty?)
    logger.info "Running post_bama_json...."
    bama_task_name, bama_start_time, bama_duration, bama_success = bama_array[0] 
    if (bama_task_name.index("deploy_")==0 || bama_task_name.index("sandbox_deploy_")==0) 
      bama_urls=Array.new
      if defined?env and !env.empty? and (env.eql?("po") || env.eql?("br"))
        bama_urls=[bama_json_url]     
      else
        set :bamastage_json_url, "http://corvus.chalybs.net/json/"
        set :bamadev_json_url, "http://vega.chalybs.net/json/"
        bama_urls=[bama_json_url,bamastage_json_url,bamadev_json_url]
      end
      bama_urls.each{ |json_url|
          begin
            #Get the BAMA post secret
             logger.info "Getting secret from #{json_url}..........................."
             http_proxy=ENV['http_proxy']
             if http_proxy.nil? || http_proxy.empty?
                 http_proxy="http://proxy:3128"
             end
             begin
                RestClient.proxy = http_proxy
                getResponse=RestClient::Request.execute(:method => :get, :url => "#{json_url}secret" ) 
             rescue Exception => get_secret_proxy
                RestClient.proxy = ""
                getResponse=RestClient::Request.execute(:method => :get, :url => "#{json_url}secret" )
             end
             #RestClient.get "#{bama_json_url}secret" 
             getResponseJSON=JSON.parse getResponse
             secret=getResponseJSON["secret"]
             json_post= <<-JSON_STR
             {
               "secret":"#{secret}",
               "bom":"#{bom}",
               "environment":"#{confType}",
               "user":"#{source_user}",
               "task":{          
                 "name":"#{bama_task_name}",
                 "start":"#{bama_start_time}",
                 "duration":"#{bama_duration}",
                 "success":"#{bama_success}",
                 "artifact_file":"#{artifact_file}",
                 "artifact_url":"#{package}"
               }     
             }
             JSON_STR
             logger.info json_post
             #Validate the JSON request format before to send it out
             begin  
                JSON.parse(json_post)  
              rescue Exception => e  
                print e.backtrace.join("\n")  
                raise "Cannot post JSON to bama because the json post: #{json_post} \n has format issue."
              end
             if ! File.directory?("working/bama_json")
               Dir.mkdir("working/bama_json")
             end
             begin
                   logger.info "Posting to #{json_url}deploy....."
                   postResponse = RestClient.post "#{json_url}deploy", json_post, :content_type => 'application/json'
                   if postResponse.code==200
                     puts "Bama Deploy JSON post successful: #{postResponse.code}"  
                   else
                     if json_url.eql?(bama_json_url)
                       puts "BAMA DEPLOY JSON POSTING FAILED!  Error: #{postResponse.code} on post deploy json message for  #{bama_task_name} in #{confType} with bom #{bom} to #{json_url}. \n #{postResponse}. \n #{json_post.inspect}"
                     end
                     case 
                     when 400
                        puts "Bad Request:400:#{postResponse}" 
                     when 403
                        puts "Forbidden:403:#{postResponse}"
                     when 406
                        puts "Already posted:406:#{postResponse}"
                     when 422
                        puts "Unprocessable Entity:422:#{postResponse}"
                     when 424
                        puts "Failed Dependency:424:#{postResponse}"
                     else
                        puts "Unknow Error:#{postResponse}"
                     end     
                   end
               rescue Exception => postEx
                   if json_url.eql?(bama_json_url)
                     puts "BAMA DEPLOY JSON POSTING FAILED!  Error: #{postEx} on post deploy json message for #{bama_task_name} in #{confType} with bom #{bom} to #{json_url}.  \n #{json_post.inspect}"
                   end
                   puts "Cannot post JSON message to BAMA: #{json_url}deploy . Error=#{postEx}"
               end         
          rescue  Exception => getSecretEx
               puts "Cannot get BAMA JSON post secret:Error=#{getSecretEx}"
               json_post= <<-JSON_STR
                {
                  "bom":"#{bom}",
                  "environment":"#{confType}",
                  "user":"#{source_user}",
                  "task":{          
                    "name":"#{bama_task_name}",
                    "start":"#{bama_start_time}",
                    "duration":"#{bama_duration}",
                    "success":"#{bama_success}",
                    "artifact_file":"#{artifact_file}",
                    "artifact_file":"#{package}"
                  }     
                }
                JSON_STR
                logger.info json_post
                #Validatte the JSON request format before to send it out
                begin  
                   JSON.parse(json_post)  
                 rescue Exception => e  
                   print e.backtrace.join("\n")  
                   raise "Cannot post JSON to bama because the json post: #{json_post} \n has format issue."
                 end
                if ! File.directory?("working/bama_json")
                  Dir.mkdir("working/bama_json")
                end
          end
      }
      
    end 
  end
end

def issue_exists_in_jira?(issuekey_str)
  success = false

  url = URI.parse jira_auth_url
  options = { :username => jira_auth_user, :password => jira_auth_password, :site => url.scheme + "://" + url.host, :context_path => url.path, :auth_type => :basic}
  jira_client = JIRA::Client.new(options)

  if issuekey_str.empty?
    success = true
  else
    begin
      issue = jira_client.Issue.find(issuekey_str)
      success = true
    rescue StandardError => e
      logger.info "Error when finding #{issuekey_str}: #{e}"
    end
  end

  success
end

def post_comment_to_jira( the_text, issuekey_str, attachment = nil )
  url = URI.parse jira_auth_url
  options = { :username => jira_auth_user, :password => jira_auth_password, :site => url.scheme + "://" + url.host, :context_path => url.path, :auth_type => :basic}
  jira_client = JIRA::Client.new(options)

  issue = jira_client.Issue.find(issuekey_str)

  comment = issue.comments.build
  comment.save!(:body => the_text)

  if attachment
    # soon, soon... see https://github.com/sumoheavy/jira-ruby/pull/28
    # file = File.open attachment
    # date = file.mtime
    # date_str = date.strftime('%Y%m%d-%H%M%S%z')
    #
    # filename_with_date = File.basename attachment
    # extname = File.extname attachment
    #
    # filename_with_date.gsub!(/#{extname}$/, "-#{date_str}.#{extname}")
    #
    # attachment = issue.attachments.build
    # attachment.save({
    #     'filename' => filename_with_date,
    #     'content' => attachment,
    #     # Suspect... should detect
    #     'type' => 'text/plain'
    # })
    logger.info "Attaching files not implemented just yet"
  end
end
