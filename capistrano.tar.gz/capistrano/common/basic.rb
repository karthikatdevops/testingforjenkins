task :get_ver do
 get_version("#{app}", "#{jmx_port}")
end

# Writes the deployment history file
def get_version ( service, jmx_port )
    servlet_container = hiera('servlet_container')
    run "if [ -e #{basedir}/history/#{servlet_container}-#{app} ]; then echo 'dir #{basedir}/history/#{servlet_container}-#{app} exists'; else mkdir -p #{basedir}/history/#{servlet_container}-#{app} ; fi"
    logger.info "Making history in file: #{basedir}/history/#{servlet_container}-#{app}/deploy_history.txt"
    run "touch #{basedir}/history/#{servlet_container}-#{app}/deploy_history.txt"
    run "date +%F-%H%M%S >> #{basedir}/history/#{servlet_container}-#{app}/deploy_history.txt"
    run "echo Version: `/usr/java/latest/bin/java -jar /opt/xcal/bin/jmxsh-R5.jar -h localhost -p #{jmx_port}  <( echo \"puts [ jmx_invoke -m thePlatform:application=#{app},name=serviceStatus getSoftwareVersion ] \")` | tee -a #{basedir}/history/#{servlet_container}-#{app}/deploy_history.txt "
    if exists?(:url)
    	tgz_url_ver=url.scan(/\/(\d+.\d+.\d+).[a-z]\/pl-*./)
    	if !(tgz_url_ver.empty?)
    		run "cd #{basedir}/tmp/#{app} ; hasDBUpdates=`ls -R * | grep #{tgz_url_ver} | grep .sql` ; if [ -n \"$hasDBUpdates\" ] && [ $? -eq 0 ] ; then echo -e \"**=======================\\n**=======================\\nNEW DB UPDATE FOUND\\nYou are deploying version #{tgz_url_ver}\\nDB update ${hasDBUpdates} may need to be applied.\\n**=======================\\n**=======================\" ; fi"
    	end
    end
end

#Check required ruby version
def check_ruby_version (version)
  ruby_version=`ruby --version`.scan(/ruby\ [1-9]+\.[0-9]+\.[0-9]+/)[0].scan(/[1-9]+\.[0-9]+\.[0-9]+/)[0]
  if (ruby_version <=> version) != -1
    logger.info "You have ruby version #{ruby_version} which is equal to or greater than the required version #{version}.You are fine."
    return true
  else
    logger.info "You have ruby version #{ruby_version}."
    return false
  end
end


#### CHECK ALIVE

task :alive do
  logger.info "TASK: just entered alive (check) in basic.rb for #{app}"
  logger.info "VARS:  app:#{app} / web_port:#{web_port} / alive_path:#{alive_path}"
  if !exists?(:isStart) or exists?(:isStart) && isStart
    logger.info "isStart is set for this app in basic.rb for #{app}"
    sleep 5
    timeout = case app
    when "gridWebService"
      if ( exists? :sirius_bulkLoadMode ) && ( sirius_bulkLoadMode == true )
        36000    # 10 hours 
      else
#        1800     # 30 minutes
        2700     # 90 minutes
      end
    when "feedgenWebService", "searchUpdaterWebService2"
      600     # 10 minutes
    when "sportsDataService", "axon", "availabilityResolutionService"
      1200   # 20 minutes 
    else
      300     # 5 min
    end
    if exists?(:strictAlive)
      strict_alive_check("#{web_port}", "#{alive_path}", timeout)
    else
      logger.info "About to call alive_check in basic.rb with: web_port:#{web_port} / alive_path:#{alive_path} / #{timeout}"
      alive_check("#{web_port}", "#{alive_path}", timeout)
    end
  end
end

# Performs a check of the alive status page using
def alive_check ( web_port, alive_path, timeout )
  sleep 5
         run <<-CMD
a=0 ;  while [ $a -le #{timeout} ] ; do  sleep 5; let a=a+5 ; wget --no-proxy -S --delete-after http://$HOSTNAME:#{web_port}/#{alive_path} 2>&1 | egrep "200 OK|500" ; if [ $? -eq 0 ] ; then echo "#{app} up on $HOSTNAME" ;exit 0; else echo "I've waited $a seconds without a healthy response" ; fi  ; if [ $a -eq #{timeout} ] ; then echo "#{app} startup FAILED after waiting a while" ; exit 1 ; fi  ; done ;
        CMD
    logger.info "Completed alive check: #{app} on " + ENV['HOSTS'] + " is up"
  sleep 5
end

def strict_alive_check ( web_port, alive_path, timeout )
  sleep 5
         run <<-CMD
a=0 ;  while [ $a -le #{timeout} ] ; do  sleep 5; let a=a+5 ; wget --no-proxy -S --delete-after http://$HOSTNAME:#{web_port}/#{alive_path} 2>&1 | egrep "200 OK" ; if [ $? -eq 0 ] ; then echo "#{app} up on $HOSTNAME" ;exit 0; else echo "I've waited $a seconds without a healthy response" ; fi  ; if [ $a -eq #{timeout} ] ; then echo "#{app} startup FAILED after waiting a while" ; exit 1 ; fi  ; done ;
        CMD
    logger.info "Completed alive check: #{app} on " + ENV['HOSTS'] + " is up"
  sleep 5
end

#################################### START/STOP  ###################################### #:nodoc:
task :migrate_bootstrap do
  run "sudo /sbin/service #{app} start" if !exists?(:isStart) or exists?(:isStart) && isStart
  # op5 api - enable monitoring if one host is specified
  op5_api_client.enable_service(app, ENV['HOSTS'].split(',')) if (ENV['HOSTS'] && use_op5_api?)
end

task :migrate_up do
  run "sudo /sbin/service #{app} start" if !exists?(:isStart) or exists?(:isStart) && isStart
  # op5 api - enable monitoring if one host is specified
  op5_api_client.enable_service(app, ENV['HOSTS'].split(',')) if (ENV['HOSTS'] && use_op5_api?)
end


#################################### START/STOP  ###################################### #:nodoc:
task :stop_jetty do
  # op5 api - disable monitoring if one host is specified
  op5_api_client.disable_service(app, ENV['HOSTS'].split(',')) if (ENV['HOSTS'] && use_op5_api?)
  # Force true all of the time, so that failure (due to missing init scripts) does not impede the deploy
  run "sudo /sbin/service #{app} stop ; true"
  run "pkill -9 -f [j]etty-#{app}/; exit 0;"
end

task :start_jetty do
  run "sudo /sbin/service #{app} start" if !exists?(:isStart) or exists?(:isStart) && isStart
  # op5 api - enable monitoring if one host is specified
  op5_api_client.enable_service(app, ENV['HOSTS'].split(',')) if (ENV['HOSTS'] && use_op5_api?)
end

task :restart_jetty do
  run "sudo /sbin/service #{app} restart"
end

##########################
# XML Configuration functions
##########################

def xml_SearchReplaceContent(document, searchTerm, thisvalue)
  @collection = document.search("#{searchTerm}")
  @collection.each do |myelement|
    myelement.content = "#{thisvalue}"
  end
end

def xml_SetTrue(document, searchTerm)
  xml_SearchReplaceContent(document, searchTerm, "true")
end

def xml_SetFalse(document, searchTerm)
  xml_SearchReplaceContent(document, searchTerm, "false")
end

def xml_SearchReplaceAttribute(document, searchTerm, attributeName, thisvalue)
  @collection = document.search("#{searchTerm}")
  @collection.each do |myelement|
    myelement["#{attributeName}"] = "#{thisvalue}"
  end
end

def xml_SearchAndRemove(document, searchTerm)
  @collection = document.search("#{searchTerm}")
  @collection.each do |myelement|
    myelement.remove
  end
end

# Avoid these addresses per Zheng
# 224.0.0.0/24 (255 IPs)
# 225.0.0.1/32 ( 1 IPs)
# 226.0.0.1/32 ( 1 IPs)
# 227.0.0.1/32 ( 1 IPs)
# 228.0.0.1/32 ( 1 IPs)
# 229.0.0.1/32 ( 1 IPs)
# 230.0.0.1/32 ( 1 IPs)
# 231.0.0.1/32 ( 1 IPs)
# 232.0.0.1/32 ( 1 IPs)
# 233.0.0.1/32 ( 1 IPs)
# 234.0.0.1/32 ( 1 IPs)
# 235.0.0.1/32 ( 1 IPs)
# 236.0.0.1/32 ( 1 IPs)
# 237.0.0.1/32 ( 1 IPs)
# 238.0.0.1/32 ( 1 IPs)
# 239.0.0.1/32 ( 1 IPs)

# DS is using 231 and reusing the webport as the cluster port

def generate_cluster_port(cluster_name)
        return Digest::MD5.hexdigest(cluster_name).hex%54000+11000
end

def generate_cluster_address(service_type, cluster_name)
  if service_type.to_s != "ds"
        puts "you've passed generate_cluster_address a service_type that it is unaware of"
      exit 1
  else
    #this should give 1-100 in the second octet to DS
    cluster_octet_2 = Digest::MD5.hexdigest(cluster_name).hex%100
    cluster_octet_2 += 1
    cluster_octet_3 = Digest::MD5.hexdigest(cluster_name).hex%252
    cluster_octet_3 += 1
    cluster_octet_4 = Digest::MD5.hexdigest(cluster_name).hex%251
  	# the 4th octet can't be a 1 due to a HP networking bug for multicast
    cluster_octet_4 += 2

    return "239" + "." + cluster_octet_2.to_s + "." + cluster_octet_3.to_s + "." + cluster_octet_4.to_s
  end
end

##########################
# Replacing text in files
##########################
def file_exists?(file)
  begin
    run "[[ -f #{file} ]]"
    return true
  rescue
    return false
  end
end

def perl_escape_str(str)
  str.gsub(/([\.\?\,\/\@\$])/, '\\\\\1')
end

def perl_update_properties_file(props, props_file)
  #####################
  # SUBSTITUTION MAGIC
  #####################
  # Start with a blank regex string
  regex=""

  props.each do |key, value|
    escaped_key, escaped_value = escape(key), escape(value.to_s)
    regex = regex + "s/^\s*#{escaped_key}=.*/#CAPIFIED\n#{escaped_key}=#{escaped_value}/g ; "
  end

  # Perform the substitution
  run "perl -pi -e '#{regex}' #{props_file}"
end

def perl_replace_tokens_in_file(tokens, template_file)
  raise "Template file #{template_file} does not exist" unless file_exists?(template_file)
  logger.info "Rewriting tokens in #{template_file} using perl..."

  regex = ''
  tokens.each do |key, value|
    escaped_key = perl_escape_str(key)
    escaped_value = perl_escape_str(value)
    regex += "s/#{escaped_key}/#{escaped_value}/g ; "
  end

  run "perl -pi -e '#{regex}' #{template_file}"
end

def add_host_entry_via_puppet(hostname, ip, host_aliases = nil)
  apply_host_change_via_puppet(hostname, ip, "present", host_aliases)
end

def remove_host_entry_via_puppet(hostname, host_aliases = nil)
  apply_host_change_via_puppet(hostname, nil, "absent", host_aliases)
end

def apply_host_change_via_puppet(hostname, ip, ens, host_aliases = nil)
  #logger.level = Capistrano::Logger::DEBUG
  begin
    if ens != "absent" && ens != "present"
      ens = "absent"
      logger.info "'Ensure' property set badly when " +
          "apply_host_change_via_puppet called, reset to #{ens}"
    end

    raise "Hostname must not be empty when making host file changes " +
        "via puppet" if hostname == nil

    # ip may be empty for changes with ensure => absent
    if ip == nil && ens == "present"
      raise "IP must not be empty when making host file changes " +
          "via puppet with ensure => present"
    elsif ip == nil # && ens == "absent"
      logger.trace %Q!host { "#{hostname}": ensure => #{ens} }!
      apply_change_via_puppet(%Q!host { "#{hostname}": ensure => #{ens} }!)
    elsif ( ip == nil ) && ( ! host_aliases.nil? ) # && ens == "absent"
      logger.trace %Q!host { "#{hostname}": ensure => #{ens}, host_aliases => #{host_aliases.inspect} }!
      apply_change_via_puppet(%Q!host { "#{hostname}": ensure => #{ens}, host_aliases => #{host_aliases.inspect} }!)
    elsif ! host_aliases.nil? # ip != nil
      logger.trace %Q!host { "#{hostname}": ip => "#{ip}", ensure => #{ens}, host_aliases => #{host_aliases.inspect} }!
      apply_change_via_puppet(%Q!host { "#{hostname}": ip => "#{ip}", ensure => #{ens}, host_aliases => #{host_aliases.inspect} }!)
    else # ip != nil
      apply_change_via_puppet(%Q!host { "#{hostname}": ip => "#{ip}", ensure => #{ens} }!)
    end

  rescue Error => e
    logger.important "Error in apply_host_change_via_puppet: #{e.message}"

    raise
  end
end

# Use this function for defining or removing an entire resource.
# Otherwise, for one-off changes of a few resource parameters, use
# set_puppet_resource(...).
def apply_change_via_puppet(manifest_str)
  #logger.level = Capistrano::Logger::DEBUG
  begin
    raise "Manifest must not be empty when making changes via " +
        "puppet" if manifest_str.empty?
    logger.trace "Manifest data: #{manifest_str}"

    manifest = Tempfile.new('cap-puppet-')
    logger.debug "Using #{manifest.path} as Tempfile"
    manifest.write(manifest_str)
    manifest.close

    uname_results = Hash.new
    # determine remote operating system
    run("uname -s") { |channel, stream, data|
      if stream == :out
        uname_results[channel[:host]] = data.chomp
        logger.debug "uname result from #{channel[:host]}: " +
            uname_results[channel[:host]].to_s
      end
    }

    uname_results.each { |host, uname_result|
      if uname_result != "Linux"
        raise "Hostfile change requested for Host #{host} running " +
            "#{uname_result}, but only able to upload temporary " +
            "manifests to Linux hosts"
      end
    }

    remote_manifest_path = File.join('/tmp', File.basename(manifest.path))
    upload(manifest.path, remote_manifest_path, :via => :scp)
    if exists?(:puppet_prefix)
      run "sudo #{puppet_prefix}/puppet apply #{remote_manifest_path}"
    else
      run "sudo puppet apply #{remote_manifest_path}"
    end

    run "rm #{remote_manifest_path}" # deletes the remote temp file
    manifest.unlink           # deletes the local temp file (run second,
                              # otherwise filename info will be lost).

  rescue Error => e
    logger.important "Error in apply_change_via_puppet (remote " +
        "manifest file may not have been deleted): #{e.message}"
    if ( defined? manifest ) && ( manifest.is_a? File )
      manifest.close
      manifest.unlink
    end

    raise
  end
end

# See http://docs.puppetlabs.com/learning/ral.html#sync-read-check-write
def get_puppet_resource(res, name)
  raise "A resource to query against puppet must be specified" if
      res.empty?

  set_puppet_resource(res, name, nil)
end

# See http://docs.puppetlabs.com/learning/ral.html#sync-read-check-write
# Modify the resource by sending in { key => value } pairs e.g.
# { :ip => "127.0.0.1" }.  Use this function for one-off changes of a
# few resource parameters.  Otherwise, for defining or removing an
# entire resource, use apply_change_via_puppet(...).
def set_puppet_resource(res, name, opts)
  #logger.level = Capistrano::Logger::DEBUG
  raise "A resource to query against puppet must be specified" if
      res.empty?

  raise "A specifically named resource to modify must be specified" if
      !opts.nil? && name.empty?

  opts_str = ""
  if !opts.nil?
    opts_a = []
    opts.each_pair { |key, value| opts_a << %Q|#{key}="#{value}"| }
    opts_str = opts_a.join(" ")
  end

  logger.info "Running command: sudo puppet resource #{res} #{name} " +
      "#{opts_str}"
  run "sudo puppet resource #{res} #{name} #{opts_str}"
end

# AUTO-849
# - run in batches
# - give a block to this
def run_serially_in_batches(opts={}, &block)
  logger.info "* run_serially_in_batches called"

  # keep track of what env variable was
  old_env_hosts = ENV['HOSTS']
  old_hiera_host = hiera_host

  # set options for find_servers to defaults unless given
  find_server_opts = opts[:find_server_opts] || {}
  run_on_first_host = opts[:run_on_first_host] || false

  set :batch_size, hiera('batch_size') unless exists?(:batch_size)

  # get servers
  servers = find_servers(find_server_opts)
  if run_on_first_host && ! servers.empty?
    servers = [servers.first]
  end

  # group by server options
  servers_by_options = servers.group_by {|s| s.options}
  servers_by_options.sort_by { |server_options, srvrs|
    # deploy to producers first
    server_options.values.include?("producer") ? 0 : 1
  }.each { |server_options, srvrs|
    logger.info "** working on servers w/ the server options: #{server_options.inspect}"
    srvrs.each_slice(batch_size) { |s|
      # set the HOSTS env var
      slice_hosts = s.collect {|x| x.host}.join(",")
      logger.info "*** working on #{slice_hosts.inspect}"
      ENV['HOSTS'] = slice_hosts

      # set :hiera_host to first host so host-specific settings will work
      set :hiera_host, s.first.host

      # yield to block w/ server options
      yield server_options
    }
  }
  logger.info "* run_serially_in_batches done"
ensure
  # reset env variable
  ENV['HOSTS'] = old_env_hosts
  set :hiera_host, old_hiera_host
end


def get_string_from_erb(template_filename, this_binding)
  conf_template = ERB.new(File.read([template_filename, ".erb"].join))
  conf_template.result(this_binding)
end

def escape(string)
  string = string.gsub(/\./, "\\.")
  string = string.gsub(/\-/, "\\-")
  string = string.gsub(/\,/, "\\,")
  string = string.gsub(/\//, "\\/")
  string = string.gsub(/\@/, "\\@")
  string = string.gsub(/\$/, "\\$")
  string
end

# vim:set et ts=2 sts=2 sw=2 ai:
