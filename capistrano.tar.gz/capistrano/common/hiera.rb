# provide methods for getting data from hiera

# require Capfile to be used so env and svc are specified
set :hiera_env, env
set :hiera_svc, svc
set :hiera_host, ''
set :debug_hiera, exists?(:debug_hiera)

# set hiera config
set :hiera_config_file, '../mopsCompassHiera/capistrano.yaml' unless exists?(:hiera_config_file)

# standard hiera lookup
# default to nil
# resolution_type can be :priority, :hash, or :array
def hiera(key_name, resolution_type=:priority, lookup_path=nil)
  scope = {'hiera_env' => hiera_env, 'hiera_svc' => hiera_svc, 'hiera_host' => hiera_host}
  logger.info ["Hiera scope: ", scope.inspect].join if debug_hiera
  hiera_obj = Hiera.new(:config => hiera_config_file)
  val = hiera_obj.lookup(key_name, nil, scope, lookup_path, resolution_type)
  logger.info ["Hiera val: ", val.inspect].join if debug_hiera
  val
end

# look up hiera hash "server_options"
def get_server_options(server_name)
  old_hiera_host = hiera_host
  set :hiera_host, server_name
  res = hiera('server_options', :hash)
  set :hiera_host, old_hiera_host
  res
end

# set roles w/ server options
def assign_roles
  nodes = hiera(hiera_svc, :priority, "nodes/#{hiera_env}")
  puts [nodes, ' = ', nodes.inspect]
  raise "no nodes found" unless(nodes && nodes.is_a?(Array))
  nodes.each { |n|
    server_options = get_server_options(n)
    if server_options
      role hiera_svc.to_sym, n, server_options
    else
      role hiera_svc.to_sym, n
    end
  }
end
task :get_roles do
  assign_roles
end
# pass in array of strings
def set_vars_from_hiera(arr)
  arr.each { |k|
    set k.to_sym, hiera(k)
  }
end

def check_hiera_branch_is_the_same
  cap_branch = `git branch | grep '*'`.chomp.split(' ').last
  hiera_branch = hiera('hiera_branch')
  raise "Branches do not match: cap=#{cap_branch.inspect}, hiera_branch=#{hiera_branch.inspect} use -S no_hiera_branch_check=true to override" unless cap_branch == hiera_branch
end

# test hiera is set up correctly
raise "check hiera setup" unless hiera('test_hiera_key') == 'test_hiera_val'

# check hiera is on the same branch as cap
check_hiera_branch_is_the_same unless exists?(:no_hiera_branch_check)
