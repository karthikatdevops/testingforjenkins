# These are various system checks that you can perform to see if your hosts are ready for deployment.
# The checks are performed in the application context, for example
#
# usage:
# cap check_mem HOSTS=<hostname>,<hostname>

task :check_mem do
 run "free -m |grep cache: |awk '{print $4}'" do |channel, stream, data|
  if data.to_i >= 1500
    logger.info "Good, total memory free for " + channel[:host].upcase + " is: " + data
  else
    run "free -m |grep Mem: |awk '{print $2}'" do |channel2, stream2, data2|
     logger.info "WARNING: You do not have enough memory to run this application. You need at least 1.5G free memory to safely run this application. \n\tTotal memory for " + channel2[:host].upcase + " is: " + data2  + "\tFree memory for " + channel2[:host].upcase + " is: " + data
     logger.info "WARNING: But I'm going to go ahead and install anyways. Fix this."
    end
  end
 end
end

task :check_space do
 run "df -h |egrep \"\ \/$\" |awk '{print $4}'" do |channel, stream, data|
  if data >= "1.0G"
    logger.info "Good, used space in #{basedir} for " + channel[:host].upcase + " is: " + data 
  elsif data < "1.0G"
    logger.info "You should have at least 1.0GB free in /#{basedir} before this application is installed"
  end    
 end
end

def seed_post_present?()
 seed_post_exists = false
 run "ls #{basedir}/tmp/#{app}/db/seed_posts || true" do |channel, stream, data|
   seed_post_exists = data.include?("json")
 end
 seed_post_exists
end

task :check_versions do
logger.info "TASK: check_versions in depcheck.rb......"


  depends = hiera('depends')

  # reset user to deployUser (in common.yaml) - this gets defined as 'unu' user for udb installs
  # because of the RPM builds...
  set :user, hiera("deployUser")
  depends.each do |dep|
    logger.info "---------> Starting dependancy checks"
    task "#{dep[0]}_installed?".to_sym do
      logger.info "----> #{dep[0]} check"
      begin
        logger.info "--> About to run dep check....."
        logger.info "---CMD---> #{dep[2]} #{dep[1]}"
        run "#{dep[2]}#{dep[1]}"
        logger.info "completed dep check"
        logger.info "#{dep[0].upcase} dependency satisfied"
      rescue
        puts "ERROR, #{dep[0].upcase} (#{dep[1]}) is not installed correctly."
        find_and_execute_task ("install_#{dep[0]}")
      end
    end
  end
 depends.each do |dep|
    eval("#{dep.first}_installed?")
  end
end

task :check_curl do
  run "if [ -e /usr/bin/curl ]; then echo installed; else echo \"not installed\"; fi" do |channel, stream, data|
   if data =~ /installed/
    logger.info "Good, Curl is installed"
   elsif data =~ /not installed/
    logger.info "Curl is not installed"
  end
 end
end

task :check do
 check_versions
 check_mem
 check_space
 check_curl
end
