require 'open-uri'
require 'json'

name="cmd"


services_ignore=["jmxtrans","gdash","nginx","cmd","haproxy","nagios","qamParityReport","jiraSprintReport","oracle","oracle2","rabbitMQ","rabbitMGT","imageRabbitMQ"]

def insertValues(cmd)
   cmd_str=cmd
   vars=cmd.scan(/\#\{(?:(?!\#).)+\}/)
   vars.each{|var|
      val=eval("\"#{var}\"")
      cmd_str.gsub!(Regexp.new(var),val)
   }
   return cmd_str
end

def udbServiceVersion(host,port)
  request_uri = "http://#{host}:#{port}"
  request_query = '/healthCheckWithVersion'
  url = "#{request_uri}#{request_query}"
  begin
    buffer = open(url, "Accept" => "application/json").read
  rescue
    version = "N/A"
  else
    result = JSON.parse(buffer)
    begin
      version = result["version"]
    rescue
      version = "Bad Version Check"
    end
  end
  version
end #udbServiceVersion

def dataServiceShellVersion(host,port,service_name)
  request_uri = "http://#{host}:#{port}"
  request_query = "/#{service_name}/management/status/build"
  url = "#{request_uri}#{request_query}"

  begin
    buffer = open(url).read
  rescue
    version = "N/A"
  else
    result = JSON.parse(buffer)
    begin
      version = result["STATUS"]["serviceBuildInfo"]["version"]
    rescue
      version = "Bad Version Check"
    end
  end
  version
end #dataServiceShellVersion

def dataServiceShellVersionHostCheck()
  get_service_version_from_node
end #dataServiceShellVersionHostCheck

    desc "used to list hosts per service for the #{env} configuration and report versions vs bom versions"
    #cap list_servicehost -S env=cmpstkMerlinIngest -S svc=sportsDataService -S cleanServer=true -S bom=CMP_14_13.18P0 -S bamaBOM=true
     task "list_servicehost".to_sym do
        File.delete("working/#{env}-list_of_services.txt") if File.exist?("working/#{env}-list_of_services.txt")
        output = File.open("working/#{env}-list_of_services.txt", 'w')
        output << "Service to Node Mapping for #{env} using BOM = #{bom}\n"
        output << "--------------------------------------------------------------------\n\n"

        # Setup our hash, it will hold the name of the service as the key
        #  and a dictionary of the nodes as it's value, for each service in this
        #  environment
        service_listing = Hash.new{|h,k| h[k] = []}

        self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each{|tsk|
           service_name=tsk.fully_qualified_name.split("_")[1]
            if services_ignore.include?(service_name)
              next
            end
            set :app, service_name
            set :hiera_svc, service_name
            # don't bother printing out, we are using sorted hash now for output at the end
            # puts "#{service_name}:"
            read_bom
            output << "#{service_name} - #{service_version}: \n"
           #logger.info "Found task #{tsk.fully_qualified_name}"
           begin
              set :web_port, hiera("#{service_name}_web_port")
           rescue
             logger.info "#{service_name}_web_port is not defined."
             next
           end
           find_and_execute_task ("#{tsk.name}")

           find_servers_for_task(tsk,:roles => service_name.to_sym).each do |svr|
            # logger.info "server===#{svr.host}"
             s_host = "#{svr.host}"
             set :current_host_check, s_host
             if hiera("svc_user") == "unu"
               version = udbServiceVersion(s_host,web_port)
             else
               version = dataServiceShellVersionHostCheck
               #version = dataServiceShellVersion(s_host,web_port,service_name)
             end

             output << "    #{s_host}:#{web_port} - #{version}\n"
            # Add the current node into our hashmap, multimap, whatever you want to call this... 
             service_listing["#{service_name}"] << "#{s_host}:#{web_port}"
           end
      }
      output.close
      logger.info "Wrote out file for you: working/#{env}-list_of_services.txt"

      # Need to run Ruby 1.9.3 to sort KEYS!!!
      # please run this using at least 1.9.3 to see sorted keys
      # using 1.8.7 will just result in unsorted output...
      service_listing.keys.sort
      # find the longest service name to setup our column width
      longest_key = service_listing.keys.max { |a, b| a.length <=> b.length }
      # print out our services, with the nodes (multiples of they have them)
      service_listing.each_pair  do |key, val|
        printf "%-#{longest_key.length}s %s \n", "#{key}", "#{val.join(' and ')}" 
    end
     end # this task


     desc "used to deploy multiple the services to #{env}"
      task "deployAll".to_sym do
        if exists?(:services) && ! services.empty?
           service_a=services.split(",")
        end  
        self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each{|tsk|
           service_name=tsk.fully_qualified_name.split("_")[1]
           if services_ignore.include?(service_name)
             next
           end
            
           if exists?(:service) && !service_name.eql?(service)
             next
           end

           if exists?(:services) && ! services.empty? && !service_a.nil? && !service_a.empty? && !service_a.include?(service_name)
               next
           end  
                     
           puts "Calling task deploy_#{service_name}_#{env}..........."
           find_and_execute_task ("deploy_#{service_name}_#{env}")
           ENV['HOSTS']=""
           roles.clear         
        }
      end

     desc "used to list services per host for the #{env} configuration"
      task "list_hostservice".to_sym do
         host_services=Hash.new
          self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each{|tsk|
             service_name=tsk.fully_qualified_name.split("_")[1]
             if services_ignore.include?(service_name)
               next
             end
             find_and_execute_task ("#{tsk.name}")
             find_servers(:roles => service_name).each do |svr|
                 host_name=svr.host.strip
                 if host_services.include?(host_name)
                   service_a=host_services[host_name]
                 else
                   service_a=Array.new
                   host_services[host_name]=service_a
                 end
                 service_a << service_name
             end
          }
          puts "#{PP.pp(host_services,$>,20)}"
      end

   desc "Used to cleanup #{env} to make sure there is no service running which is not allowed"
   task "cleanup_#{env}".to_sym do
      `if [ -d "working/#{name}" ]; then rm -fr working/#{name}; fi; mkdir -p working/#{name};`
      host_services=Hash.new
      self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each{|tsk|
         service_name=tsk.fully_qualified_name.split("_")[1]
         logger.info "service_name=====#{service_name}"
         if services_ignore.include?(service_name)
           next
         end
         find_and_execute_task ("#{tsk.name}")
         find_servers(:roles => service_name).each do |svr|
             if service_name.eql?("gridWebService") and (env.eql?("cmpstkMerlinIngest") && svr.options[:client].eql?("true") or env.eql?("merqaClient") && svr.options[:client].eql?("false"))
                  next
             end
             host_name=svr.host.strip
             if host_services.include?(host_name)
               service_a=host_services[host_name]
             else
               service_a=Array.new
               host_services[host_name]=service_a
             end
             service_a << service_name
         end
      }
      logger.info "#{PP.pp(host_services,$>,20)}"
      if exists?(:deploy) && deploy
        isdeploy = deploy
      else
        isdeploy = false
      end
      host_services.each{ |h,s|
        svs_str=s.join("\\\\|")
        cleanup = <<-CLEANUP_STR
#!/usr/bin/env ruby
          deploy=#{isdeploy}
          LOG_FILE="/tmp/cleanup.log"
          p_lines= %x(ps auxww | grep java | grep -v '/opt/ds/\\\\(jetty\\\\-\\\\)\\\\?\\\\(#{svs_str}\\\\)[/\\\\| ]' | grep '/opt/ds' | grep -v grep).strip
          log_str="Starting cleanup on #{h}...\\n"
          p_lines.each{|p_line|
            pid=p_line.split(" ")[1]
            pdir=p_line[/\\/opt\\/ds\\/[^\\/]*[\\/| ]/]
            if !pdir.nil? && !pdir.empty?
              sname=""
              sname_str=pdir.gsub(/\\/opt\\/ds\\//,'').gsub(/\\//,'')
              if sname_str.index("jetty-") == 0
                  sname=sname_str.gsub(/jetty-/,'')
              else
                  sname=sname_str.strip
              end
              log_str << "Found \#{sname} does not belong to #{h}.\\n"
              #Try to stop the service
              log_str <<"Try to run /etc/init.d/\#{sname} stop to stop the service\\n"
              if deploy
                init_stop=`sudo /etc/init.d/\#{sname} 2>&1 | tee /dev/stderr`
                log_str << "\#{init_stop}\\n"
                sleep 5
                log_str << `sudo chkconfig \#{sname} off`<<"\\n"
                log_str << `sudo rm -f /etc/init.d/\#{sname}`<<"\\n"
              end
              is_running=`ps -aef | grep \#{pid} | grep -v grep`
              if ! is_running.nil? || ! is_running.empty?
                log_str << "Init.d script did not stop the service. Found:\\n \#{is_running}Will kill -9 \#{pid}\\n"
                if deploy
                  kill9=`kill -9 \#{pid}`
                  log_str << "\#{kill9}\\n"
                end
              end
              
              #Try to remove the /opt/ds/\#{pdir}
              log_str << "Remove /opt/ds/\#{pdir}\\n"
              if deploy
                cleanup_optds_dir=%x(cd /opt/ds; find . -type l | grep '[-\\\\|/]\#{sname}$' | grep -v grep | xargs unlink)
                log_str << "\#{cleanup_optds_dir}\\n"
                sudo_rm=`sudo rm -fr \#{pdir}`
                log_str << "\#{sudo_rm}\\n"
              end
            end
          }
          dir_lines= %x(find /opt/ds -type l | grep -v '/opt/ds/\\\\(jetty\\\\-\\\\)\\\\?\\\\(#{svs_str}\\\\)[/\\\\| ]' | grep '/opt/ds' | grep -v grep).strip
          dir_lines.each { |dir_line| 
            if deploy
               jetty_dir=%x(ls -l \#{dir_line} | cut -d '>' -f2).strip
               log_str << "Unlink \#{dir_line}"
               unlink_log=`sudo unlink \#{dir_line}`
               log_str << "\#{unlink_log}\\n" 
               log_str << "Remove \#{jetty_dir}"
               rm_log=`sudo rm -fr \#{jetty_dir}`
               log_str << "\#{rm_log}\\n"
             end
          }
          
          log_str << "Finished cleanup\\n"
          File.open(LOG_FILE,'w+'){|f| f.puts log_str;}
        CLEANUP_STR
        File.open("working/#{name}/cleanup_#{h}.rb",'w+'){|f| f.puts cleanup;}
        upload("working/#{name}/cleanup_#{h}.rb","/tmp/cleanup.rb", :via => :scp,:hosts => "#{h}")
        run "sudo chmod 755 /tmp/cleanup.rb; sudo /tmp/cleanup.rb; cat /tmp/cleanup.log; exit 0", {:hosts => "#{h}"}
        #run "lines=\`ps -aef | grep java | grep -v '/opt/ds/\(jetty\-\)\?\(#{svs_str}\)[/\| ]' | grep '/opt/ds' | grep -v grep\`;  a=\($lines\); echo \$\{a[0]\};true", {:hosts => "#{h}"}
      }
   end

   desc "used to run_cmd_#{env} for the #{env}"
    task "run_cmd_#{env}".to_sym do
       if exists?(:cmd)  && !cmd.empty? && cmd.eql?("destroy") and (!exists?(:service) || service.empty? and !exists?(:services) || services.empty? )
           logger.info "You must specify which services you want to destroy.Ex: -S service=jobDataService for single service or \"-S services=jobDataService,linearDataService\" for multiple services."
           exit
       end
       if exists?(:services) && ! services.empty?
          service_a=services.split(",")
       end
       self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each{|tsk|
          service_name=tsk.fully_qualified_name.split("_")[1]
          if services_ignore.include?(service_name)
            next
          end

          if exists?(:service) && !service_name.eql?(service)
            next
          end

          if exists?(:services) && ! services.empty? && !service_a.nil? && !service_a.empty? && !service_a.include?(service_name)
              next
          end       
          
          find_and_execute_task ("#{tsk.name}")
          
          find_servers_for_task(tsk,:roles => "#{service_name}".to_sym).each do |svr|
            if service_name.eql?("gridWebService") and (env.eql?("merdevl") && svr.options[:client].eql?("true") or env.eql?("cmpstkMerlinIngest") && svr.options[:client].eql?("true") or env.eql?("merqaClient") && svr.options[:client].eql?("false"))
                   next
            end
            if exists?(:cmd)  && !cmd.empty?
              case cmd
              when "start", "stop","restart"
                 logger.info "sudo /etc/init.d/#{service_name} #{cmd} "
                 run "if [ -f /etc/init.d/#{service_name} ]; then sudo /etc/init.d/#{service_name} #{cmd}; fi",{:hosts => "#{svr.host}"}
                 if cmd.eql?("stop")
                   run "pid=`ps -aef | grep java | grep -e '/opt/ds/\\(jetty\\-\\)\\?#{service_name}[/\\| ]' | grep -v grep | awk '{print $2}'`; if [ -n \"$pid\" ]; then sudo kill -9 $pid; ret=$?; if [ \"$ret\" != 0 ]; then echo \"Cannot stop #{service_name}:$ret. Please ssh in and stop it manuallly.\";fi;fi",{:hosts => "#{svr.host}"}
                 end
              when "destroy"
                logger.info "Destroy service #{service_name}....."
                run "if [ -f /etc/init.d/#{service_name} ]; then sudo /etc/init.d/#{service_name} stop; sleep 5s; sudo chkconfig #{service_name} off; sudo rm /etc/init.d/#{service_name}; fi",{:hosts => "#{svr.host}"}
                run "pid=`ps -aef | grep java | grep -e '/opt/ds/\\(jetty\\-\\)\\?#{service_name}[/\\| ]' | grep -v grep | awk '{print $2}'`; if [ -n \"$pid\" ]; then sudo kill -9 $pid; ret=$?; if [ \"$ret\" != 0 ]; then echo \"Cannot stop #{service_name}:$ret. Please ssh in and stop it manuallly.\";fi;fi",{:hosts => "#{svr.host}"}
                run "cd /opt/ds; find . -type l | grep '[-\\|/]#{service_name}$' | grep -v grep | xargs unlink; ls -l | grep '^d' | grep -v backup- | grep -e ' \\(jetty\\-\\)\\?#{service_name}\\(\\-[0-9].[0-9].[0-9]\\+\\)\\?$' | grep -v grep | awk '{print $9}' | xargs rm -fr",{:hosts => "#{svr.host}"}
              else
                 cmd_str=cmd
                  vars=cmd.scan(/\#\{(?:(?!\#).)+\}/)
                  vars.each{|var|
                      val=eval("\"#{var}\"")
                      cmd_str=cmd_str.gsub(Regexp.new(Regexp.escape(var)),val)
                  }
                  logger.info "Run \"#{cmd_str}\" for service #{service_name}"
                  run cmd_str,{:hosts => "#{svr.host}"}
              end
            end
          end        
          roles.clear
     }
    end
