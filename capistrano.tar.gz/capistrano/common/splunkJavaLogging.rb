#build logback.xml
#	place it in JETTY_HOME/config
#
#build logback-access.xml
#	place it in JETTY_HOME/etc
#
#build jetty-logging.xml
#	place it in JETTY_HOME/etc
#		
#find replace settings in etc/jetty.xml (include realm)
#
#get logback jars -> JETTY_HOME/lib/ext
set :splunkHost, "localhost"
set :splunkUser, "logback"
set :splunkPassword, "logback"
set :splunkIndex, "logback"

task :createLogback do
	create_logback_xml
	create_logging_properties
	disable_jetty_logging_xml
	modify_jetty_xml
  fetch_logging_jars
  set_logback_level
end

task :createLogback_jetty8 do
	create_logback_xml
#	create_logging_properties
	disable_jetty_logging_xml
#	modify_jetty_xml
if app == "commerceDataService"
  modify_jetty8_xml
end  
  fetch_logging_jars
  set_logback_level
end

task :createLogback_solr do
	create_logback_xml
	create_logging_properties
	disable_jetty_logging_xml
	modify_jetty_xml
	fetch_logging_jars
  set_logback_level
end

task :createLogback_clover do
	create_logback_xml
	create_logging_properties
	disable_jetty_logging_xml
	modify_jetty_xml
	fetch_logging_jars
  set_logback_level
end

task :create_logback_xml do
  logger.info "TASK: Entered create_logback_xml in splunkJavaLogging.rb"
logback_string = <<-logbackString1
<?xml version="1.0" encoding="UTF-8"?>
<!-- MANAGED BY CAPISTRANO -->
<configuration>
  <jmxConfigurator/>
  #{'<contextListener class="ch.qos.logback.classic.jul.LevelChangePropagator"/>' if app == "ingestWebService"}

  <appender name="tcpRootAppender" class="com.dtdsoftware.splunk.logging.logback.appender.SplunkRawTCPAppender">
#{'    <filter class="ch.qos.logback.core.filter.EvaluatorFilter">
      <evaluator>
        <expression>com.theplatform.data.api.exception.ObjectNotFoundException.class.isInstance(throwable)</expression>
      </evaluator>
      <onMatch>DENY</onMatch>
    </filter>' if app == "entityDataService" || app == "entityIngest" || app == "linearDataService" || app == "linearIngest" || app == "jobDataService" || app == "offerDataService" || app == "offerIngest" || app == "locationDataService" || app == "locationIngest" || app == "idDataService" || app == "menuDataService" || app == "ingestStagingWebService" }
    <port>#{splunkTcpPort}</port>
    <host>#{splunkHost}</host>
    <maxQueueSize>5000KB</maxQueueSize>
    <dropEventsOnQueueFull>true</dropEventsOnQueueFull>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <pattern>%d %-5p s=#{app}-root_out env="#{confType}" [%t] %c: %m%n</pattern>
    </layout>
  </appender>
  <appender name="asynctcpRootAppender" class="ch.qos.logback.classic.AsyncAppender">
    <appender-ref ref="tcpRootAppender" />
  </appender>
  <appender name="tcp#{app}WebAppender" class="com.dtdsoftware.splunk.logging.logback.appender.SplunkRawTCPAppender">
    <port>#{splunkTcpPort}</port>
    <host>#{splunkHost}</host>
    <maxQueueSize>5000KB</maxQueueSize>
    <dropEventsOnQueueFull>true</dropEventsOnQueueFull>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <pattern>%d %-5p s=#{app}-web env="#{confType}" RequestBodyLogger: %m%n</pattern>
    </layout>
  </appender>
  <appender name="asynctcp#{app}WebAppender" class="ch.qos.logback.classic.AsyncAppender">
    <appender-ref ref="tcp#{app}WebAppender" />
  </appender>
  <appender name="#{app}tcpNotificationsWebAppender" class="com.dtdsoftware.splunk.logging.logback.appender.SplunkRawTCPAppender">
    <port>#{splunkTcpPort}</port>
    <host>#{splunkHost}</host>
    <maxQueueSize>5000KB</maxQueueSize>
    <dropEventsOnQueueFull>true</dropEventsOnQueueFull>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <pattern>%d %-5p s=#{app}-notif env="#{confType}" notifications: %m%n</pattern>
    </layout>
  </appender>
  <appender name="async#{app}tcpNotificationsWebAppender" class="ch.qos.logback.classic.AsyncAppender">
    <appender-ref ref="#{app}tcpNotificationsWebAppender" />
  </appender>
  <appender name="tcp#{app}SearchAppender" class="com.dtdsoftware.splunk.logging.logback.appender.SplunkRawTCPAppender">
    <port>#{splunkTcpPort}</port>
    <host>#{splunkHost}</host>
    <maxQueueSize>5000KB</maxQueueSize>
    <dropEventsOnQueueFull>true</dropEventsOnQueueFull>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <pattern>%d %-5p s=#{app}-search env="#{confType}" search: %m%n</pattern>
    </layout>
  </appender>
  <appender name="asynctcp#{app}SearchAppender" class="ch.qos.logback.classic.AsyncAppender">
    <appender-ref ref="tcp#{app}SearchAppender" />
  </appender>
  <appender name="tcpDebugAppender" class="com.dtdsoftware.splunk.logging.logback.appender.SplunkRawTCPAppender">
    <port>#{splunkTcpPort}</port>
    <host>#{splunkHost}</host>
    <maxQueueSize>5000KB</maxQueueSize>
    <dropEventsOnQueueFull>true</dropEventsOnQueueFull>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <pattern>%d INFO s=#{app}-debug env="#{confType}" [%t] %c: %m%n</pattern>
    </layout>
  </appender>
  <appender name="asynctcpDebugAppender" class="ch.qos.logback.classic.AsyncAppender">
    <appender-ref ref="tcpDebugAppender" />
  </appender>


  <!-- Logger for web logging. -->
  <logger name="com.theplatform.module.requestlogger.RequestBodyLogger.logger" level="DEBUG" additivity="false">
    <appender-ref ref="asynctcp#{app}WebAppender"/>
  </logger>
  <!-- Logger for notifications web logging. -->
  <logger name="com.theplatform.module.requestlogger.RequestBodyLogger.logger.notifications" level="DEBUG" additivity="false">
    <appender-ref ref="async#{app}tcpNotificationsWebAppender"/>
  </logger>
  <!-- Logger for search logging. -->
  <logger name="com.theplatform.module.requestlogger.RequestLogger.logger.search" level="DEBUG" additivity="false">
    <appender-ref ref="asynctcp#{app}SearchAppender"/>
  </logger>
  <logger name="com.theplatform.jdbc.log.LoggingStatement" level="#{custom_JDBC_logging_level}" additivity="true">
    <appender-ref ref="asynctcpDebugAppender"/>
  </logger>
#{'<logger name="com.theplatform.contrib.jdbc.log.LoggingStatement" level="DEBUG" additivity="true">
    <appender-ref ref="asynctcpDebugAppender"/>
  </logger>' if (confType == "chaz2Ingest" || confType == "dev_bo_po") && (app == "idDataService" || app == "linearDataService" || app == "entityDataService" || app == "offerDataService" || app == "locationDataService")}
  <logger name="com.theplatform.data.persistence.logging.ConsoleSqlLoggingContext" level="WARN" additivity="false">
    <appender-ref ref="asynctcpDebugAppender"/>
  </logger>

  <logger name="com.theplatform.data.api" level="INFO" additivity="false">
    <appender-ref ref="asynctcpRootAppender"/>
  </logger>
  <logger name="com.theplatform.web.api" level="INFO" additivity="false">
    <appender-ref ref="asynctcpRootAppender"/>
  </logger>
  <logger name="com.theplatform.web.tv.gws.service.common.debug.DebugHelper" level="ERROR" additivity="false">
    <appender-ref ref="asynctcpRootAppender"/>
  </logger>

  <logger name="org.springframework" level="WARN" />
  <logger name="org.hibernate" level="WARN" />
  <logger name="requestLog" level="OFF"/>
  <logger name="org.mortbay" level="OFF"/>
  <logger name="org.apache" level="ERROR"/>
  <logger name="com.mchange.v2.async.ThreadPoolAsynchronousRunner" level="HARDCODED_ERROR" />
  <logger name="com.theplatform.web.tv.combine.impl.CombineServiceImpl" level="ERROR" />
  <logger name="com.theplatform.web.tv.combine.impl.combiner.IdFieldTranslator" level="ERROR" />

logbackString1

  hiera('logger_overrides').each_pair do |name,level|
    if level == "DEBUG" or level == "HARDCODED_DEBUG" 
      logback_string << %Q|  <logger name="#{name}" level="#{level}">\n|
      logback_string << %Q|    <appender-ref ref="asynctcpDebugAppender"/>\n|
      logback_string << %Q|  </logger>\n|
    else
      logback_string << %Q|  <logger name="#{name}" level="#{level}" />\n|
    end
  end

logback_string << <<-logbackString1

  <root level="INFO">
    <appender-ref ref="asynctcpRootAppender"/>
  </root>

</configuration>
logbackString1


  #added for directing logs to files and splunk for dev_bo_po only...
  logback_string_sportsIngestWS = <<-sportsIngestWS
<?xml version="1.0" encoding="UTF-8"?>
<!-- MANAGED BY CAPISTRANO -->
<configuration>
  <jmxConfigurator/>
  <property name="ARCDIR" value="archived_logs"/>
  <appender name="rootOutAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
  <param name="File" value="logs/root_out.log"/>
    <filter class="com.theplatform.module.logging.extension.logback.filter.LevelMatchFilter"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/root_out.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p s=sportsIngestWebService-root_out  env="dev_bo_po" [%t] %c: %m%n</Pattern>
    </layout>
  </appender>
  <appender name="sportsIngestWebServiceWebAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="logs/sportsIngestWebService-web.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/sportsIngestWebService-web.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p s=sportsIngestWebService-web  env="dev_bo_po" [%t] %c: %m%n</Pattern>
    </layout>
  </appender>
  <appender name="sampleNotificationsWebAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="logs/Notifications-web.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/Notifications-web.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p s=sportsIngestWebService-notifications  env="dev_bo_po" [%t] %c: %m%n</Pattern>
    </layout>
  </appender>
  <appender name="sportsIngestWebServiceSearchAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="logs/sportsIngestWebService-search.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/sportsIngestWebService-search.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p s=sportsIngestWebService-search  env="dev_bo_po" [%t] %c: %m%n</Pattern>
    </layout>
  </appender>
  <appender name="sportsIngestWebServicerlstatAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="logs/sportsIngestWebService-rlstat.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/sportsIngestWebService-rlstat.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p s=sportsIngestWebService-rlstat  env="dev_bo_po" [%t] %c: %m%n</Pattern>
    </layout>
  </appender>

  <appender name="DebugAppender" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <param name="File" value="logs/customJDBC.log"/>
    <rollingPolicy class="ch.qos.logback.core.rolling.FixedWindowRollingPolicy">
      <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/customJDBC.log.%i</FileNamePattern>
      <minIndex>1</minIndex>
      <maxIndex>3</maxIndex>
    </rollingPolicy>
    <triggeringPolicy class="ch.qos.logback.core.rolling.SizeBasedTriggeringPolicy">
      <maxFileSize>500MB</maxFileSize>
    </triggeringPolicy>
    <layout class="ch.qos.logback.classic.PatternLayout">
      <Pattern>%d %-5p s=sportsIngestWebService-customJDBC  env="dev_bo_po" [%t] %c: %m%n</Pattern>
    </layout>
  </appender>
  <appender name="asyncRootOutAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="rootOutAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncsportsIngestWebServiceRequestAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="sportsIngestWebServiceRequestAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncsportsIngestWebServicePersistenceAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="sportsIngestWebServicePersistenceAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncsportsIngestWebServiceWebAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="sportsIngestWebServiceWebAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
    </appender>
  <appender name="asyncSampleNotificationsWebAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="sampleNotificationsWebAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncsportsIngestWebServiceSearchAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="sportsIngestWebServiceSearchAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncsportsIngestWebServiceAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="sportsIngestWebServiceAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncsportsIngestWebServicerlstatAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="sportsIngestWebServicerlstatAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncSqlAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="SqlAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>
  <appender name="asyncDebugAppender" class="com.theplatform.module.logging.extension.logback.appender.AsyncAppender">
    <appender-ref ref="DebugAppender" />
    <bufferSize>5000</bufferSize>
    <queueCapacity>5000</queueCapacity>
    <blocking>false</blocking>
  </appender>

  <logger name="com.theplatform.module.logging.extension.logback.appender.AsyncAppender" level="WARN" additivity="false">
    <appender-ref ref="asyncsportsIngestWebServiceAppender"/>
  </logger>
  <logger name="com.theplatform.data.persistence.logging" level="WARN" additivity="false">
    <appender-ref ref="asyncsportsIngestWebServiceAppender"/>
  </logger>
  <!-- Logger for sql logging. -->
  <logger name="com.theplatform.data.persistence.logging.ConsoleSqlLoggingContext" level="WARN" additivity="false">
    <appender-ref ref="asyncSqlAppender"/>
  </logger>
  <!-- Logger for request logging. -->
  <logger name="com.theplatform.data.endpoint.DataServiceEndpoint" level="DEBUG" additivity="false">
    <appender-ref ref="asyncsportsIngestWebServiceRequestAppender"/>
  </logger>
  <!-- Logger for persistence logging. -->
  <logger name="com.theplatform.data.persistence.logging.PersistenceEventLogger.logger" level="WARN" additivity="false">
    <appender-ref ref="asyncsportsIngestWebServicePersistenceAppender"/>
  </logger>
  <!-- Logger for web logging. -->
  <logger name="com.theplatform.module.requestlogger.RequestBodyLogger.logger" level="DEBUG" additivity="false">
    <appender-ref ref="asyncsportsIngestWebServiceWebAppender"/>
  </logger>
  <!-- Logger for notifications web logging. -->
  <logger name="com.theplatform.module.requestlogger.RequestBodyLogger.logger.notifications" level="DEBUG" additivity="false">
    <appender-ref ref="asyncSampleNotificationsWebAppender"/>
  </logger>
  <!-- Logger for search logging. -->
  <logger name="com.theplatform.module.requestlogger.RequestLogger.logger.search" level="DEBUG" additivity="false">
    <appender-ref ref="asyncsportsIngestWebServiceSearchAppender"/>
  </logger>
  <!-- Logger for rlstat logging. -->
  <logger name="requestLog" level="DEBUG" additivity="false">
    <appender-ref ref="asyncsportsIngestWebServicerlstatAppender"/>
  </logger>
  <logger name="org.mortbay" level="DEBUG"/>
  <logger name="org.apache" level="DEBUG"/>
  <logger name="com.mchange.v2.async.ThreadPoolAsynchronousRunner" level="ERROR" />
  <logger name="com.theplatform.data.api" level="DEBUG" additivity="false">
    <appender-ref ref="asyncRootOutAppender"/>
  </logger>
  <logger name="com.theplatform.web.api" level="DEBUG" additivity="false">
    <appender-ref ref="asyncRootOutAppender"/>
  </logger>
  <logger name="com.theplatform.jdbc.log.LoggingStatement" level="DEBUG" additivity="true">
    <appender-ref ref="asyncDebugAppender"/>
  </logger><!-- no longer needed in 2.5 DSS
  <logger name="org.hibernate.jdbc.AbstractBatcher" level="DEBUG" additivity="false">
    <appender-ref ref="asyncDebugAppender"/>
  </logger>-->
  <root level="INFO">
    <appender-ref ref="asyncRootOutAppender"/>
  </root>


  <appender name="sportsIngestWebServiceXmlInputLog" class="ch.qos.logback.core.rolling.RollingFileAppender">
      <param name="File" value="logs/SportsIngest-feeds.log"/>
      <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
        <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/SportsIngest-feeds.log.%d{yyyy-MM-dd}</FileNamePattern>
        <MaxHistory>5</MaxHistory>
      </rollingPolicy>
        <layout class="ch.qos.logback.classic.PatternLayout">
        <!-- pattern is just: Message
        -->
        <Pattern>%d %-5p s=sportsIngestWebService-SportsIngest  env="dev_bo_po" [%t] %c: %m%n</Pattern>
        </layout>
  </appender>
  <appender name="nascarServiceLog" class="ch.qos.logback.core.rolling.RollingFileAppender">
      <param name="File" value="logs/NascarServiceLog.log"/>
      <filter class="com.theplatform.module.logging.extension.logback.filter.LevelMatchFilter"/>
      <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
        <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/NascarServiceLog.log.%d{yyyy-MM-dd}</FileNamePattern>
        <MaxHistory>7</MaxHistory>
      </rollingPolicy>
      <layout class="ch.qos.logback.classic.PatternLayout">
         <Pattern>%d %-5p s=sportsIngestWebService-NascarServiceLog  env="dev_bo_po" [%t] %c: %m%n</Pattern>
      </layout>
  </appender>
  <appender name="nascarLiveFeedLog" class="ch.qos.logback.core.rolling.RollingFileAppender">
      <param name="File" value="logs/NascarLiveFeed.log"/>
      <filter class="com.theplatform.module.logging.extension.logback.filter.LevelMatchFilter"/>
      <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
        <FileNamePattern>${theplatform.log.dir}/${ARCDIR}/NascarLiveFeed.log.%d{yyyy-MM-dd}</FileNamePattern>
        <MaxHistory>7</MaxHistory>
      </rollingPolicy>
      <layout class="ch.qos.logback.classic.PatternLayout">
         <Pattern>%d %-5p s=sportsIngestWebService-NascarLiveFeed  env="dev_bo_po" [%t] %c: %m%n</Pattern>
      </layout>
  </appender>
  <logger name="XmlInputLogger" level="DEBUG" additivity="false" >
      <appender-ref ref="sportsIngestWebServiceXmlInputLog"/>
  </logger>
      <!-- Loggers for NASCAR -->
  <logger name="com.theplatform.web.tv.sportsingest.impl.nascar" level="DEBUG" additivity="true">
      <appender-ref ref="nascarServiceLog" />
  </logger>
  <logger name="com.theplatform.web.tv.sportsingest.impl.nascar.NascarLiveJson" level="DEBUG" additivity="false">
      <appender-ref ref="nascarLiveFeedLog" />
  </logger>
</configuration>

  sportsIngestWS

  #override for sportsIngestWS in dev_bo_po only
  if "#{app}" == "sportsIngestWebService" && "#{confType}" == "dev_bo_po"
    logback_string = logback_string_sportsIngestWS
  end


upload(StringIO.new(logback_string),"#{basedir}/jetty-#{app}/config/logback.xml", :via => :scp, :mode => 0770)

end # end of create_logback_xml task


task :create_logging_properties do
  logger.info "TASK: Entered create_logging_properties in logback.rb"
  logprop_string = <<-logpropString     
############################################################
# MANAGED BY CAPISTRANO 
############################################################
.level = WARNING
java.util.logging.FileHandler.pattern = /tmp/dataservices.log
java.util.logging.FileHandler.limit = 50000
java.util.logging.FileHandler.count = 1
java.util.logging.FileHandler.formatter = java.util.logging.SimpleFormatter
logpropString

  upload(StringIO.new(logprop_string),"#{basedir}/jetty-#{app}/config/logging.properties", :via => :scp, :mode => 0770)

end # end of create_logging_properties task


task :modify_jetty8_xml do
jetty8_xml = <<-here
<?xml version="1.0"?>
<!DOCTYPE Configure PUBLIC "-//Jetty//Configure//EN" "http://www.eclipse.org/jetty/configure.dtd">
<Configure id="Server" class="org.eclipse.jetty.server.Server">

    <!-- =========================================================== -->
    <!-- Server Thread Pool                                          -->
    <!-- =========================================================== -->
    <Set name="ThreadPool">
      <!-- Default queued blocking threadpool -->
      <New class="org.eclipse.jetty.util.thread.QueuedThreadPool">
        <Set name="minThreads">10</Set>
        <Set name="maxThreads">200</Set>
        <Set name="detailedDump">false</Set>
      </New>
    </Set>

    <!-- =========================================================== -->
    <!-- Set connectors                                              -->
    <!-- =========================================================== -->

    <Call name="addConnector">
      <Arg>
          <New class="org.eclipse.jetty.server.nio.SelectChannelConnector">
            <Set name="host"><Property name="jetty.host" /></Set>
            <Set name="port"><Property name="jetty.port" default="8080"/></Set>
            <Set name="maxIdleTime">300000</Set>
            <Set name="Acceptors">2</Set>
            <Set name="statsOn">false</Set>
            <Set name="confidentialPort">8443</Set>
            <Set name="lowResourcesConnections">20000</Set>
            <Set name="lowResourcesMaxIdleTime">5000</Set>
            <Set name="requestHeaderSize">#{jetty_http_headerbuffersize}</Set>
          </New>
      </Arg>
    </Call>
    <!-- =========================================================== -->
      <!-- Set handler Collection Structure                            -->
      <!-- =========================================================== -->
      <Set name="handler">
        <New id="Handlers" class="org.eclipse.jetty.server.handler.HandlerCollection">
          <Set name="handlers">
           <Array type="org.eclipse.jetty.server.Handler">
             <Item>
               <New id="Contexts" class="org.eclipse.jetty.server.handler.ContextHandlerCollection"/>
             </Item>
           </Array>
          </Set>
        </New>
      </Set>

      <!-- =========================================================== -->
      <!-- extra options                                               -->
      <!-- =========================================================== -->
      <Set name="stopAtShutdown">true</Set>
      <Set name="sendServerVersion">false</Set>
      <Set name="sendDateHeader">true</Set>
      <Set name="gracefulShutdown">1000</Set>
      <Set name="dumpAfterStart">false</Set>
      <Set name="dumpBeforeStop">false</Set>

  </Configure>
  here
upload(StringIO.new(jetty8_xml),"#{basedir}/jetty-#{app}/etc/jetty.xml", :via => :scp)
end # end of modify_jetty8_xml task


task :modify_jetty_xml do

jetty_xml = <<-here
<?xml version="1.0"?>

<Configure id="Server" class="org.mortbay.jetty.Server">
    <Set name="ThreadPool">

      <New class="org.mortbay.thread.QueuedThreadPool">
        <Set name="minThreads">10</Set>
        <Set name="maxThreads">200</Set>
        <Set name="lowThreads">20</Set>
        <Set name="SpawnOrShrinkAt">2</Set>
      </New>

    </Set>

    <Call name="addConnector">
      <Arg>
          <New class="org.mortbay.jetty.nio.SelectChannelConnector">
            <Set name="host"><SystemProperty name="jetty.host"/></Set>
            <Set name="port"><SystemProperty name="jetty.port" default="8080"/></Set>
            <Set name="maxIdleTime">#{jetty_maxIdleTime}</Set>
            <Set name="Acceptors">2</Set>
            <Set name="statsOn">false</Set>
            <Set name="confidentialPort">8443</Set>
	          <Set name="lowResourcesConnections">5000</Set>
	          <Set name="lowResourcesMaxIdleTime">5000</Set>
	          <Set name="headerBufferSize">#{jetty_http_headerbuffersize}</Set>
	          <Set name="requestBufferSize">#{jetty_requestBufferSize}</Set>
	          <Set name="responseBufferSize">#{jetty_responseBufferSize}</Set>
          </New>
      </Arg>
    </Call>

    <Set name="handler">
      <New id="Handlers" class="org.mortbay.jetty.handler.HandlerCollection">
        <Set name="handlers">
         <Array type="org.mortbay.jetty.Handler">
           <Item>
             <New id="Contexts" class="org.mortbay.jetty.handler.ContextHandlerCollection"/>
           </Item>
           <Item>
             <New id="DefaultHandler" class="org.mortbay.jetty.handler.DefaultHandler"/>
           </Item>
           <Item>
             <New id="RequestLog" class="org.mortbay.jetty.handler.RequestLogHandler"/>
           </Item>
         </Array>
        </Set>
      </New>
    </Set>

    <Call name="addLifeCycle">
      <Arg>
        <New class="org.mortbay.jetty.deployer.ContextDeployer">
          <Set name="contexts"><Ref id="Contexts"/></Set>
          <Set name="configurationDir"><SystemProperty name="jetty.home" default="."/>/contexts</Set>
          <Set name="scanInterval">5</Set>
        </New>
      </Arg>
    </Call>

    <Call name="addLifeCycle">
      <Arg>
        <New class="org.mortbay.jetty.deployer.WebAppDeployer">
          <Set name="contexts"><Ref id="Contexts"/></Set>
          <Set name="webAppDir"><SystemProperty name="jetty.home" default="."/>/webapps</Set>
	  <Set name="parentLoaderPriority">false</Set>
	  <Set name="extract">true</Set>
	  <Set name="allowDuplicates">false</Set>
          <Set name="defaultsDescriptor"><SystemProperty name="jetty.home" default="."/>/etc/webdefault.xml</Set>
        </New>
      </Arg>
    </Call>

    <Set name="UserRealms">
      <Array type="org.mortbay.jetty.security.UserRealm">
        <Item>
          <New class="org.mortbay.jetty.security.HashUserRealm">
            <Set name="name">thePlatform</Set>
            <Set name="config"><SystemProperty name="jetty.home" default="."/>/etc/realm.properties</Set>
            <Set name="refreshInterval">0</Set>
          </New>
        </Item>
      </Array>
    </Set>

    <Set name="stopAtShutdown">true</Set>
    <Set name="sendServerVersion">true</Set>
    <Set name="sendDateHeader">true</Set>
    <Set name="gracefulShutdown">1000</Set>
</Configure>
here

upload(StringIO.new(jetty_xml),"#{basedir}/jetty-#{app}/etc/jetty.xml", :via => :scp)
end # end of modify_jetty_xml task

task :fetch_logging_jars do
  logger.info "TASK: fetching_logging_jars in splunkJavaLogging.rb"

    begin
      logger.info "TASK: Entered SLF4J--- fetching_logging_jars in splunkJavaLogging.rb"
      run "cd #{basedir}/jetty-#{app}/lib/ext && wget #{wget_params}  #{repo}/splunkJavaLogging/0.3.0/splunk.jar" unless app.include?("triageWebService") || app.include?("ingestStagingWebService")
      run "cd #{basedir}/jetty-#{app}/lib/ext && wget #{wget_params}  #{repo}/splunkJavaLogging/0.3.0/splunklogging.jar"
      run "cd #{basedir}/jetty-#{app}/lib/ext && wget #{wget_params}  #{repo}/splunkJavaLogging/0.3.0/splunk-sdk.jar"

    rescue
      logger.info "failing back to a local wget and scp up to the server, this will take a bit more time..."
      `wget #{wget_params} #{repo}/splunkJavaLogging/0.3.0/splunk.jar -O working/splunk.jar`
      `wget #{wget_params} #{repo}/splunkJavaLogging/0.3.0/splunklogging.jar -O working/splunklogging.jar`
      `wget #{wget_params} #{repo}/splunkJavaLogging/0.3.0/splunk-sdk.jar -O working/splunk-sdk.jar`

      upload("working/splunk.jar","#{basedir}/jetty-#{app}/lib/ext", :via => :scp) unless app.include?("triageWebService") || app.include?("ingestStagingWebService")
      upload("working/splunklogging.jar","#{basedir}/jetty-#{app}/lib/ext", :via => :scp)
      upload("working/splunk-sdk.jar","#{basedir}/jetty-#{app}/lib/ext", :via => :scp)
    end

end # end of fetch_logging_jars task


task :disable_jetty_logging_xml do
  run "perl -pi -e 's#\\$\\{JETTY_HOME\\}/etc/jetty-logging.xml##' #{basedir}/jetty-#{app}/bin/jetty.sh"
  run "if [ -e #{basedir}/jetty-#{app}/etc/jetty.conf ]; then perl -pi -e 's#etc/jetty-logging.xml##' #{basedir}/jetty-#{app}/etc/jetty.conf; fi"
end # end of disable_jetty_logging_xml task


task  :set_logback_level do
   run  " sed -i_back -e 's,level=\"ERROR\",level=\"#{logback_level_error}\",g' -e 's,level=\"INFO\",level=\"#{logback_level_info}\",g' -e 's,level=\"WARN\",level=\"#{logback_level_warn}\",g'  -e 's,level=\"DEBUG\",level=\"#{logback_level_debug}\",g' #{basedir}/jetty-#{app}/config/logback.xml " 
   run  " sed -i_back -e 's,HARDCODED_,,g' #{basedir}/jetty-#{app}/config/logback.xml "
   if exists?(:logback_root_level)
     run  " sed -i_back -e 's,<root level=\".*\">,<root level=\"#{logback_root_level}\">,g' #{basedir}/jetty-#{app}/config/logback.xml "
   end
end # end of set_logback_level


desc "hopefully a more straightforward logback.xml creation"
task :create_splunk_logback do
  set :logback_config, {
    :loggers => {
      "com.comcast.netty.http.AccessLogHandler" => {
        :level => "info",
        :appender_ref => "async_tcp_access_appender",
      },
      "org.springframework" => {
        :level => "warn",
        :appender_ref => "async_tcp_web_appender",
      },
      "org.jboss.netty.channel.socket.nio.NioServerSocketPipelineSink" => {
        :level => "warn",
        :appender_ref => "async_tcp_web_appender",
      },
      "com.comcast" => {
        :level => "info",
        :appender_ref => "async_tcp_web_appender",
      },
      "com.theplatform" => {
        :level => "info",
        :appender_ref => "async_tcp_web_appender",
      },
      "com.theplatform.web.tv.menu.server" => {
        :level => "info",
        :appender_ref => "async_tcp_web_appender",
      },
    },
    :appenders => [
      "web",
      "root-out",
      "access",
      "debug",
    ],
    :root => {
      :level => "warn",
      :appender_ref => "async_tcp_root-out_appender",
    },
    :svc => app,
    :env => confType,
  }

  # possibly override / add
  if exists?(:logback_config_overrides)
    logback_config.merge!(logback_config_overrides)
  end

  # get string from template and write xml file
  splunk_logback_xml = get_string_from_erb("templates/logback/splunk_logback.xml", binding)
  upload(StringIO.new(splunk_logback_xml), "#{install_path}/conf/logback.xml", :via => :scp)
end

desc "fetch splunk logging jars into lib"
task :fetch_splunk_logging_jars do
  run "cd #{install_path}/lib && wget #{wget_params} #{repo}/splunkJavaLogging/0.3.0/splunk.jar"
  run "cd #{install_path}/lib && wget #{wget_params} #{repo}/splunkJavaLogging/0.3.0/splunklogging.jar"
end

logger.info ">>>>> loaded splunkJavaLogging"