# Create YAML files for use in nagios-ansible project
#  This will output yml files to be used to configure nagios servers
#  so that updated hosts and services are automatically added to Nagios
#  when they change in capistrano and hiera
#
#  Andrew_Diller@comcast.com
#  Dec 2015
#  Modifed from the old nagioscap.rb
#
##############################################################################
logger.level = Capistrano::Logger::INFO

services_ignore=["jiraSprintReport","udbMockService","miceGWTService","programIndex2","cloverServer","entityIndex","entityIndexer","jmxtrans","gdash","nginx","rabbitMQ","rabbitMGT","coatGWTService","entityIndexer","locationIndexer","linearIndexer","haproxy","oracle","imageRabbitMQ","imageRabbitMGT","alfred","commerceDataService","unuServer","tim","merlinSolr","imageIndex","imageWebService","imageDataService","imageIngest","imageEventWebService","imageManagementWebService","imageBackOfficeReportingWebService","searchUpdaterWebService2","mongoDB","nagios","ppvGapReport","qamParityReport","imageIngestWebService"]

# yes, keep this
name="nagios"

# Main Task to Generate files
#
#   sample call
#   $ bundle exec cap -S env=merdevlBo2 -S svc=none -S nobom generate_nagios_yaml
#
#  to generate multiple env files use the bash script genNagiosYaml.sh


desc "used to update_#{name}_#{env} configuration file"
task "generate_nagios_yaml" do
  logger.info ".... Just entered into task: generate_nagios_yaml.."
  hosts=Array.new
  hostGroups=Array.new
  serviceGroups=Array.new

  set :app, "#{name}"
  set :install_path, "working/#{name}"
  logger.info "....Set install_path=#{install_path}, set app to #{name}"
  logger.info ".................................................................."
 
    self.task_list(:all).select {|t| t.fully_qualified_name =~ /^#{env}_\w+/}.each{|tsk|
    service_name=tsk.fully_qualified_name.split("_")[1]
    set :hiera_svc, service_name
    if exists?(:service) && !service_name.eql?(service)
      next
    end
    if services_ignore.include?(service_name)
      logger.info "Skipping #{service_name}, in the ignore group"
      next
    end
    logger.info " "
    logger.info " "
    logger.info ">>> Found task #{tsk.fully_qualified_name}"
    begin
       set :web_port, hiera("#{service_name}_web_port")
    rescue
      logger.info "#{service_name}_web_port is not defined."
      next
    end

# Find the hostnames that correspond to this service
    find_and_execute_task ("#{tsk.name}")


#
# Main Loop
#
# Once we've found all our services, we are going to find each server (via roles) that hosts that service.
# There is a main loop to go over all the servers found in roles for all the serivces in the env.
# In this loop we'll start to keep track of each server to create a host line for it - the hosts array
# We do this for ever server/host regardless of service.
# Then, depending on env type we also need to start keeping track of the services - for checks - the hostGroups array.
# The Ansible/Nagios config will use hostGroups to define any checks for the services.
# We need one per serivce since our services all use different ports, we need to know the exact port for each service to check
# to construct a URL for check_http.
# 
# Below is the expected output of the yaml file for a server/node/host:
#
#        - {name: 'entityDataSerivce17', address: 'mer-arch-bo-17d.compass.comcast.com', entityDataSerivce: true, merdevlBO: true}


# Start the loop
      find_servers_for_task(tsk,:roles => "#{service_name}".to_sym).each do |svr|
#        logger.info " ++++++++ Staring Loop for adding hosts for service #{service_name} " 
        hostalias=svr.host
        hostName = hostalias.split(/\s|\./) # get just the hostname from the FQDN for the Nagios Name
        logger.info " ++++++++++ This server===#{svr.host}"

# Update the hosts array, this is written out to host.yaml at the bottom of this task
# Need perfect indentation for Yaml Parsing, so don't mess up HERE STRING spacing.
# We are using name-env here to match the groups below- nagios can't have Host Group names
# that match, and so we use the env to create unique names for things that are in multiple envs.

        host = <<-HOST_STR
    - { name: '#{hostName.first}', address: '#{svr.host}', #{service_name}-#{env}: true, #{env}: true }
        HOST_STR
        hosts << host

# now we need to build service checks for each service, and write it out to the hostGroups file
# when we write it we'll uniq the array so that only one check is written for each service even
# if there are multiple hosts that will trigger this more than one time

        if (env == "a2gdev") && (service_name != "availabilityResolutionService" && service_name != "digitalRightsLocker") 
          hostGroup = <<-HOSTGROUP_STRING
    - name: '#{service_name}-#{env}'
      alias: '#{service_name}'
      checks:
        - {command: 'check_alive!#{web_port}!/#{service_name}/healthCheck!OK', description: 'UDB Alive Check' }
          HOSTGROUP_STRING
          hostGroups << hostGroup
 
        elsif env == "a2gdev" && service_name == "availabilityResolutionService"
          hostGroup = <<-HOSTGROUP_STRING
    - name: '#{service_name}-#{env}'
      alias: '#{service_name}'
      checks:
        - {command: 'check_alive!#{web_port}!/healthCheck!OK', description: 'UDB Alive Check' }
          HOSTGROUP_STRING
          hostGroups << hostGroup

        elsif env == "a2gdev" && service_name == "digitalRightsLocker"
          hostGroup = <<-HOSTGROUP_STRING
    - name: '#{service_name}-#{env}'
      alias: '#{service_name}'
      checks:
        - {command: 'check_alive!#{web_port}!/locker/healthCheck!OK', description: 'UDB Alive Check' }
          HOSTGROUP_STRING
          hostGroups << hostGroup

        else 
# setup our host_groups Yaml File for regular DSS alive checks
# Need perfect indentation for Yaml Parsing!
        hostGroup = <<-HOSTGROUP_STRING
    - name: '#{service_name}-#{env}'
      alias: '#{service_name} in #{env}'
      checks:
        - { command: 'check_alive!#{web_port}!/#{service_name}/management/alive!Ok', description: 'DSS Alive Check' }
        HOSTGROUP_STRING
        hostGroups << hostGroup
        end # if
      end # find_servers_for_task
    } # close self.task_list(:all).select 

      # Write out the body of the yaml file
      File.open("working/#{name}/#{env}_hosts.yml",'w+'){|f| f.puts hosts.uniq;}
      File.open("working/#{name}/#{env}_host_groups.yml",'w+'){|f| f.puts hostGroups.uniq;}
      roles.clear

end # Task


desc "used to combine yaml source configuration files into one file for ansible vars"
task "combine_nagios_files" do
  logger.info ".... Just entered into task: combine_env_files_into_yaml"
  contents=''
  combined_yaml=''
 
  yaml_start_hosts = <<-YAML1_STRING
---
  nagios_hosts:
YAML1_STRING

  yaml_start_hostGroups = <<-YAML2_STRING
---
  nagios_host_groups:
YAML2_STRING

# Gather all the hosts files we've created and squash them into
# one file that ansible will expect
    Dir["working/#{name}/*_hosts.yml"].each do |file_name|
      logger.info " About to read: #{file_name}"
      contents = File.open("#{file_name}", "rb") { |f| f.read }
      combined_yaml << contents
    end

    File.open("working/#{name}/compass_combined_hosts.yml",'w+'){|f| f.puts yaml_start_hosts;}
    File.open("working/#{name}/compass_combined_hosts.yml",'a'){|f| f.puts combined_yaml;}

    combined_yaml=''

# Gather all the hostGroup files we've created and squash them into
# one file that ansible will expect
    Dir["working/#{name}/*_host_groups.yml"].each do |file_name|
      logger.info " About to read: #{file_name}"
      contents = File.open("#{file_name}", "rb") { |f| f.read }
      combined_yaml << contents
    end

    File.open("working/#{name}/compass_combined_hostGroups.yml",'w+'){|f| f.puts yaml_start_hostGroups;}
    File.open("working/#{name}/compass_combined_hostGroups.yml",'a'){|f| f.puts combined_yaml;}
end


# EOF
