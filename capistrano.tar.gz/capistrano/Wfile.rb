class Wfile
  @work_template=String.new
  def initialize(jdbc,uname,passcode,idx_tbs,tbl_tbs,changelog)

 @work_template=<<-EOF
time_zone=GMT+0:00
driver=oracle.jdbc.OracleDriver
url=jdbc:oracle:thin:@#{jdbc}
username=#{uname.downcase} 
password=#{passcode} 
idx_initran=40
tbl_initran=100
idx_tbs=#{idx_tbs} 
tbl_tbs=#{tbl_tbs} 
changelog=#{changelog}
auto_commit=false
delimiter=/
full_line_delimiter=true
send_full_script=false

EOF
end
   def fill_template
    @work_template
end
end
