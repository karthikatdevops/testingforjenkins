package com.theplatform.data.tv.entity.api.data;

import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import com.theplatform.data.tv.entity.api.fields.RelatedProgramField;

import java.net.URI;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class RelatedProgramTest extends AbstractMerlinDataServiceUnitTest<RelatedProgram, RelatedProgramField> {

    protected Class<RelatedProgram> getGenericClass() {
        return RelatedProgram.class;
    }

    protected RelatedProgramField[] getFieldEnumValues() {
        Set<RelatedProgramField> fieldSet = new HashSet<>();
        fieldSet.addAll(Arrays.asList(RelatedProgramField.values()));
        fieldSet.remove(RelatedProgramField._all);
        return fieldSet.toArray(new RelatedProgramField[0]);
    }

    protected boolean isExempt(String methodName) {
        if ("getTitle".equals(methodName)) {
            return true;
        }
        return super.isExempt(methodName);
    }

    protected void verifyServiceListMarshalAndUnmarshal() throws Exception {
    }

    protected String getVersion() {
        return "1.5.7";
    }

    protected RelatedProgram createServiceObject() throws Exception {
        RelatedProgram entity = new RelatedProgram();
        entity.setSourceProgramId(new URI("1"));
        entity.setType("testdata");
        entity.setTargetProgramId(new URI("2"));
        entity.setJustification("testdata");
        entity.setRank(7);
        entity.setScore(3.25f);
        return entity;
    }

    protected void assertServiceObjectsEqual(RelatedProgram entity1, RelatedProgram entity2) {
        assertThat(entity1.getSourceProgramId(), is(entity2.getSourceProgramId()));
        assertThat(entity1.getType(), is(entity2.getType()));
        assertThat(entity1.getTargetProgramId(), is(entity2.getTargetProgramId()));
        assertThat(entity1.getJustification(), is(entity2.getJustification()));
        assertThat(entity1.getRank(), is(entity2.getRank()));
        assertThat(entity1.getScore(), is(entity2.getScore()));
    }
}
