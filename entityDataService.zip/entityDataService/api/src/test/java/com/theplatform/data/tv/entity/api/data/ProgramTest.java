package com.theplatform.data.tv.entity.api.data;

import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;

import java.net.URI;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class ProgramTest extends AbstractMerlinDataServiceUnitTest<Program, ProgramField> {

    @Override
    protected Program createServiceObject() throws Exception {
        Program program = new Program();
        program.setId(new URI("1"));
        program.setTitle("LOST");
        program.setOwnerId(new URI("123456"));
        program.setUpdated(new Date());
        program.setAdded(new Date());
        program.setFirstAirDate(new DateOnly(2004, 9, 22));
        program.setDescription("Plane crash survivors live on a mysterious island.");
        program.setType(ProgramType.SeriesMaster);
        return program;
    }

    @Override
    protected Class<Program> getGenericClass() {
        return Program.class;
    }

    @Override
    protected String getVersion() {
        return "1.0";
    }

    @Override
    protected void assertServiceObjectsEqual(Program p1, Program p2) {
        assertThat(p1.getId(), is(p2.getId()));
        assertThat(p1.getTitle(), is(p2.getTitle()));
        assertThat(p1.getOwnerId(), is(p2.getOwnerId()));
        assertDatesEqual(p1.getUpdated(), p2.getUpdated());
        assertDatesEqual(p1.getAdded(), p2.getAdded());
        assertThat(p1.getFirstAirDate(), is(p2.getFirstAirDate()));
        assertThat(p1.getDescription(), is(p2.getDescription()));
        assertThat(p1.getType(), is(p2.getType()));
    }

    @Override
    protected ProgramField[] getFieldEnumValues() {
        Set<ProgramField> fieldSet = new HashSet<>();
        fieldSet.addAll(Arrays.asList(ProgramField.values()));
        fieldSet.remove(ProgramField._all);
        return fieldSet.toArray(new ProgramField[0]);
    }

}
