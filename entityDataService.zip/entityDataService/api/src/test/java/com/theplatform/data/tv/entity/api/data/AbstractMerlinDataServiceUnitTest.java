package com.theplatform.data.tv.entity.api.data;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.marshalling.AbstractIdentifiedDataServiceUnitTest;
import com.theplatform.data.api.objects.DataObject;
import org.testng.annotations.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public abstract class AbstractMerlinDataServiceUnitTest<E extends DataObject, F extends Enum>
        extends AbstractIdentifiedDataServiceUnitTest<E, F> {

    protected ManagedMerlinDataObjectField[] getCommonFieldEnumValues() {
        Set<ManagedMerlinDataObjectField> fieldSet = new HashSet<>();
        fieldSet.addAll(Arrays.asList(ManagedMerlinDataObjectField.values()));
        fieldSet.remove(ManagedMerlinDataObjectField._all);
        return fieldSet.toArray(new ManagedMerlinDataObjectField[0]);
    }

    @Test
    public void testEnumFields() {
        Set<String> fieldSet = new HashSet<>();
        Class currentClass = getGenericFieldsClass();
        while (currentClass != null) {
            for (Field field : currentClass.getDeclaredFields()) {
                fieldSet.add(field.getName());
            }
            currentClass = currentClass.getSuperclass();
        }

        for (Enum myEnum : getFieldEnumValues()) {
            assertThat(
                    myEnum + " is not a field in " + getGenericFieldsClass().getSimpleName(),
                    fieldSet.contains(myEnum.name()) || "_all".equals(myEnum.name()), is(true));
        }

        // verify that for each accessor, there is a corresponding field enum
        Method[] methods = getGenericFieldsClass().getMethods();
        for (Method method : methods) {
            if (method.getName().startsWith("get") &&
                    Modifier.isPublic(method.getModifiers()) &&
                    method.getDeclaringClass().equals(getGenericFieldsClass()) &&
                    !isExempt(method.getName())) {
                String expectedFieldEnumName = method.getName().replaceFirst("get", "").toLowerCase();
                boolean matchFound = false;
                for (Enum e : getFieldEnumValues()) {
                    if (e.name().toLowerCase().equals(expectedFieldEnumName))
                        matchFound = true;
                }
                for (Enum e : getCommonFieldEnumValues()) {
                    if (e.name().toLowerCase().equals(expectedFieldEnumName))
                        matchFound = true;
                }
                assertThat(
                        "Class " + getGenericFieldsClass().getSimpleName() + " had method " + method.getName() +
                                " but there was no corresponding field enum",
                        matchFound, is(true));
            }
        }
    }
}
