package com.theplatform.data.tv.entity.api.resources;

import com.theplatform.data.api.marshalling.DefaultMarshallerFactory;
import com.theplatform.data.api.marshalling.MarshallerFactory;
import org.testng.annotations.Test;

/**
 * Many odd errors can occur if the extesion.xml file is not correct or if it refers
 * to fields that don't exist on objects, etc. This simple test loads the marshallers
 * to see that all is legit.
 * <p>
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 11/28/14
 */
public class ExtensionTest {
    @Test
    public void extensionFileShouldLoadOk() {
        MarshallerFactory marshallerFactory = new DefaultMarshallerFactory();
    }
}
