package com.theplatform.data.tv.entity.api.data;

import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.fields.CreditField;

import java.net.URI;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class CreditTest extends AbstractMerlinDataServiceUnitTest<Credit, CreditField> {

    @Override
    protected Credit createServiceObject() throws Exception {
        Credit credit = new Credit();
        credit.setId(new URI("1"));
        credit.setOwnerId(new URI("123456"));
        credit.setUpdated(new Date());
        credit.setAdded(new Date());
        credit.setProgramId(new URI("2"));
        credit.setPersonId(new URI("3"));
        credit.setPartName("Kate Austin");
        credit.setRank(2);
        credit.setType("Actor");
        return credit;
    }

    @Override
    protected Class<Credit> getGenericClass() {
        return Credit.class;
    }

    @Override
    protected String getVersion() {
        return "1.0";
    }

    @Override
    protected void assertServiceObjectsEqual(Credit p1, Credit p2) {
        assertThat(p1.getId(), is(p2.getId()));
        assertThat(p1.getOwnerId(), is(p2.getOwnerId()));
        assertDatesEqual(p1.getUpdated(), p2.getUpdated());
        assertDatesEqual(p1.getAdded(), p2.getAdded());
        assertThat(p1.getProgramId(), is(p2.getProgramId()));
        assertThat(p1.getPersonId(), is(p2.getPersonId()));
        assertThat(p1.getRank(), is(p2.getRank()));
        assertThat(p1.getType(), is(p2.getType()));
        assertThat(p1.getPartName(), is(p2.getPartName()));
    }

    @Override
    protected CreditField[] getFieldEnumValues() {
        Set<CreditField> fieldSet = new HashSet<>();
        fieldSet.addAll(Arrays.asList(CreditField.values()));
        fieldSet.remove(CreditField._all);
        return fieldSet.toArray(new CreditField[0]);
    }

}
