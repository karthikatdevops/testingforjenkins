package com.theplatform.data.tv.entity.api.data;

import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.fields.PersonField;

import java.net.URI;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class PersonTest extends AbstractMerlinDataServiceUnitTest<Person, PersonField> {

    @Override
    protected Person createServiceObject() throws Exception {
        Person person = new Person();
        person.setId(new URI("1"));
        person.setOwnerId(new URI("123456"));
        person.setUpdated(new Date());
        person.setAdded(new Date());
        person.setName("Evangeline Lilly");
        person.setLongBio("Evangeline Lilly was born a native Canadian (and is fluent in French). Her father is a home economics teacher, and her mother worked as a cosmetician and ran a daycare center. She has two sisters.");
        person.setBirth(new DateOnly(1979, 8, 3));
        person.setMediumBio("Evangeline Lilly was born a native Canadian (and is fluent in French).");
        person.setShortBio("Evangeline Lilly was born a native Canadian.");
        return person;
    }

    @Override
    protected Class<Person> getGenericClass() {
        return Person.class;
    }

    @Override
    protected String getVersion() {
        return "1.0";
    }

    @Override
    protected void assertServiceObjectsEqual(Person p1, Person p2) {
        assertThat(p1.getId(), is(p2.getId()));
        assertThat(p1.getOwnerId(), is(p2.getOwnerId()));
        assertDatesEqual(p1.getUpdated(), p2.getUpdated());
        assertDatesEqual(p1.getAdded(), p2.getAdded());
        assertThat(p1.getName(), is(p2.getName()));
        assertThat(p1.getLongBio(), is(p2.getLongBio()));
        assertThat(p1.getMediumBio(), is(p2.getMediumBio()));
        assertThat(p1.getShortBio(), is(p2.getShortBio()));
        assertThat(p1.getBirth(), is(p2.getBirth()));
    }

    @Override
    protected PersonField[] getFieldEnumValues() {
        Set<PersonField> fieldSet = new HashSet<>();
        fieldSet.addAll(Arrays.asList(PersonField.values()));
        fieldSet.remove(PersonField._all);
        return fieldSet.toArray(new PersonField[0]);
    }

}
