package com.theplatform.data.tv.entity.api.fields;

import org.testng.annotations.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

public class RelatedProgramFieldTest {

    @Test
    public void testToString() {
        String prefix = RelatedProgramField.NAMESPACE + ":";
        for (RelatedProgramField value : RelatedProgramField.values()) {
            switch (value) {
                case _all:
                    assertThat(value.getNamespace(), is(RelatedProgramField.NAMESPACE));
                    assertThat(value.getQualifiedName(), is(prefix));
                    assertThat(value.getLocalName(), is(nullValue()));
                    assertThat(value.toString(), is(prefix));
                    break;
                default:
                    assertThat(value.getNamespace(), is(RelatedProgramField.NAMESPACE));
                    assertThat(value.getQualifiedName(), is(prefix + value.name()));
                    assertThat(value.name(), is(value.getLocalName()));
                    assertThat(value.toString(), is(prefix + value.name()));
            }
        }
    }

}
