package com.theplatform.data.tv.entity.api.data;

import com.theplatform.data.tv.entity.api.data.objects.TvSeason;
import com.theplatform.data.tv.entity.api.fields.TvSeasonField;

import java.net.URI;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class TvSeasonTest extends AbstractMerlinDataServiceUnitTest<TvSeason, TvSeasonField> {

    @Override
    protected TvSeason createServiceObject() throws Exception {
        TvSeason season = new TvSeason();
        season.setId(new URI("1"));
        season.setOwnerId(new URI("123456"));
        season.setUpdated(new Date());
        season.setAdded(new Date());
        season.setDescription("LOST Season 6");
        season.setStartYear(2010);
        season.setSeriesId(new URI("2"));
        season.setEndYear(2010);
        season.setTvSeasonNumber(6);
        return season;
    }

    @Override
    protected Class<TvSeason> getGenericClass() {
        return TvSeason.class;
    }

    @Override
    protected String getVersion() {
        return "1.0";
    }

    @Override
    protected void assertServiceObjectsEqual(TvSeason p1, TvSeason p2) {
        assertThat(p1.getId(), is(p2.getId()));
        assertThat(p1.getOwnerId(), is(p2.getOwnerId()));
        assertDatesEqual(p1.getUpdated(), p2.getUpdated());
        assertDatesEqual(p1.getAdded(), p2.getAdded());
        assertThat(p1.getDescription(), is(p2.getDescription()));
        assertThat(p1.getStartYear(), is(p2.getStartYear()));
        assertThat(p1.getSeriesId(), is(p2.getSeriesId()));
        assertThat(p1.getEndYear(), is(p2.getEndYear()));
        assertThat(p1.getTvSeasonNumber(), is(p2.getTvSeasonNumber()));
    }

    @Override
    protected TvSeasonField[] getFieldEnumValues() {
        Set<TvSeasonField> fieldSet = new HashSet<>();
        fieldSet.addAll(Arrays.asList(TvSeasonField.values()));
        fieldSet.remove(TvSeasonField._all);
        return fieldSet.toArray(new TvSeasonField[0]);
    }

}
