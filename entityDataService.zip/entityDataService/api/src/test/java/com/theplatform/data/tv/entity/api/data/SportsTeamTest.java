package com.theplatform.data.tv.entity.api.data;

import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import com.theplatform.data.tv.entity.api.fields.SportsTeamField;

import java.net.URI;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class SportsTeamTest extends AbstractMerlinDataServiceUnitTest<SportsTeam, SportsTeamField> {

    @Override
    protected SportsTeam createServiceObject() throws Exception {
        SportsTeam sportsTeam = new SportsTeam();
        sportsTeam.setId(new URI("1"));
        sportsTeam.setOwnerId(new URI("123456"));
        sportsTeam.setUpdated(new Date());
        sportsTeam.setAdded(new Date());
        sportsTeam.setCoachPersonId(new URI("2"));
        sportsTeam.setLeagueId(new URI("3"));
        sportsTeam.setRepresentingName("Bull");
        sportsTeam.setGender("Male");
        sportsTeam.setSportType("Basketball");
        sportsTeam.setShortBio("short bio information");
        sportsTeam.setMediumBio("medium bio information");
        sportsTeam.setLongBio("loooooooong bio information");
        return sportsTeam;
    }

    @Override
    protected Class<SportsTeam> getGenericClass() {
        return SportsTeam.class;
    }

    @Override
    protected String getVersion() {
        return "1.5.36";
    }

    @Override
    protected void assertServiceObjectsEqual(SportsTeam p1, SportsTeam p2) {
        assertThat(p1.getId(), is(p2.getId()));
        assertThat(p1.getOwnerId(), is(p2.getOwnerId()));
        assertDatesEqual(p1.getUpdated(), p2.getUpdated());
        assertDatesEqual(p1.getAdded(), p2.getAdded());
        assertThat(p1.getCoachPersonId(), is(p2.getCoachPersonId()));
        assertThat(p1.getLeagueId(), is(p2.getLeagueId()));
        assertThat(p1.getRepresentingName(), is(p2.getRepresentingName()));
        assertThat(p1.getGender(), is(p2.getGender()));
        assertThat(p1.getSportType(), is(p2.getSportType()));
        assertThat(p1.getShortBio(), is(p2.getShortBio()));
        assertThat(p1.getMediumBio(), is(p2.getMediumBio()));
        assertThat(p1.getLongBio(), is(p2.getLongBio()));
    }

    @Override
    protected SportsTeamField[] getFieldEnumValues() {
        Set<SportsTeamField> fieldSet = new HashSet<>();
        fieldSet.addAll(Arrays.asList(SportsTeamField.values()));
        fieldSet.remove(CreditField._all);
        return fieldSet.toArray(new SportsTeamField[0]);
    }


}
