package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URI;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

public class ProgramTypeSpecificUtilsTest {

    // Base constants
    public static final URI BASE_ID = URI.create("data/Program/1");
    public static final String BASE_TITLE = "The title";
    public static final Integer BASE_YEAR = 1865;

    // Movie constants
    public static final DateOnly MOVIE_RELEASE_DATE = new DateOnly(2009, 10, 19);

    // Episode constants
    public static final URI EPISODE_SERIES_ID = URI.create("data/Program/2");
    public static final URI EPISODE_TVSEASON_ID = URI.create("data/TvSeason/1");
    public static final Integer EPISODE_TVSEASON_EPISODE_NUM = 5;
    public static final Integer EPISODE_SERIES_EPISODE_NUM = 11;
    public static final Integer EPISODE_TVSEASON_NUM = 2;
    public static final String EPISODE_TITLE = "Charity";

    // SportsSubtitle constants
    public static final DateOnly SERIES_FIRST_AIRDATE = new DateOnly(2001, 6, 9);
    public static final DateOnly SERIES_LAST_AIRDATE = new DateOnly(2007, 11, 27);

    /*
     * SportsSubtitle Constant; for instance, sportsSubtitle is a field that is
     * settable for the following types: <pre> * SeriesMaster * Episode *
     * SportsEvent * Other </pre>
     *
     * Typically, we would expect that because sportsSubtitle is listed as a
     * SeriesMaster-field (as well as the others), we would expect that it would
     * get nulled out for all other types. In addition, for Programs of type
     * SeriesMaster it would also get nulled out because there are other
     * sub-types that have it.
     */
    public static final String SPORTS_SUBTITLE = "someSportsSubtitle";

    @Test
    public void testNoProgramType() {
        Program program = getBaseProgram();
        program.setType(null);
        try {
            ProgramTypeSpecificUtils.nullOutInconsistentTypeSpecificFields(program);
            Assert.fail("Should have thrown an IllegalArgumentException when passing in a program having a null type");
        } catch (IllegalArgumentException eae) {
            // expected
        }
    }

    /*
     * Verify that if no inconsistent fields, object is unmodified
     */
    @Test
    public void testNoInconsistentFields() {
        Program program = null;

        // Movie
        program = getBaseProgram();
        program.setType(ProgramType.Movie);
        setMovieFields(program);
        ProgramTypeSpecificUtils.nullOutInconsistentTypeSpecificFields(program);
        assertBaseFields(program);
        assertMovieFields(program);

        // Episode
        program = getBaseProgram();
        program.setType(ProgramType.Episode);
        setEpisodeFields(program);
        setSportsSubtitleField(program);
        ProgramTypeSpecificUtils.nullOutInconsistentTypeSpecificFields(program);
        assertBaseFields(program);
        assertEpisodeFields(program);
        assertSportsSubtitleField(program);

        // SeriesMaster
        program = getBaseProgram();
        program.setType(ProgramType.SeriesMaster);
        setSeriesMasterFields(program);
        setSportsSubtitleField(program);
        ProgramTypeSpecificUtils.nullOutInconsistentTypeSpecificFields(program);
        assertBaseFields(program);
        assertSeriesMasterFields(program);
        assertSportsSubtitleField(program);
    }

    /*
     * Verify that if inconsistent type fields are set, they are nulled out. We
     * create an object of each.
     */
    @Test
    public void testInconsistentFields() {
        Program program = null;

        // Other; Movie/Episode/SeriesMaster fields should null out, but SportsSubtitle should not
        program = getBaseProgram();
        program.setType(ProgramType.Other);
        setMovieFields(program);
        setEpisodeFields(program);
        setSeriesMasterFields(program);
        setSportsSubtitleField(program);
        ProgramTypeSpecificUtils.nullOutInconsistentTypeSpecificFields(program);
        assertBaseFields(program);
        assertNullMovieFields(program);
        assertNullEpisodeFields(program);
        assertNullSeriesMasterFields(program);
        assertSportsSubtitleField(program);

        // Movie; Episode/SeriesMaster/SportsSubtitle fields should null out
        program = getBaseProgram();
        program.setType(ProgramType.Movie);
        setMovieFields(program);
        setEpisodeFields(program);
        setSeriesMasterFields(program);
        setSportsSubtitleField(program);
        ProgramTypeSpecificUtils.nullOutInconsistentTypeSpecificFields(program);
        assertBaseFields(program);
        assertMovieFields(program);
        assertNullEpisodeFields(program);
        assertNullSeriesMasterFields(program);
        assertNullSportsSubtitleField(program);

        // Episode; Movie/SeriesMaster fields should null out, but SportsSubtitle should not
        program = getBaseProgram();
        program.setType(ProgramType.Episode);
        setEpisodeFields(program);
        setMovieFields(program);
        setSeriesMasterFields(program);
        setSportsSubtitleField(program);
        ProgramTypeSpecificUtils.nullOutInconsistentTypeSpecificFields(program);
        assertBaseFields(program);
        assertEpisodeFields(program);
        assertNullMovieFields(program);
        assertNullSeriesMasterFields(program);
        assertSportsSubtitleField(program);

        // SeriesMaster; Movie/Episode fields should null out, but SportsSubtitle should not
        program = getBaseProgram();
        program.setType(ProgramType.SeriesMaster);
        setSeriesMasterFields(program);
        setMovieFields(program);
        setEpisodeFields(program);
        setSportsSubtitleField(program);
        ProgramTypeSpecificUtils.nullOutInconsistentTypeSpecificFields(program);
        assertBaseFields(program);
        assertSeriesMasterFields(program);
        assertNullMovieFields(program);
        assertNullEpisodeFields(program);
        assertSportsSubtitleField(program);
    }

    // Base helper methods
    protected Program getBaseProgram() {
        Program program = new Program();
        program.setId(BASE_ID);
        program.setTitle(BASE_TITLE);
        program.setYear(BASE_YEAR);
        return program;
    }

    protected void assertBaseFields(Program program) {
        assertThat(program.getId(), is(BASE_ID));
        assertThat(program.getTitle(), is(BASE_TITLE));
        assertThat(program.getYear(), is(BASE_YEAR));
    }

    // Movie helper methods
    protected void setMovieFields(Program program) {
        program.setReleaseDate(MOVIE_RELEASE_DATE);
    }

    protected void assertMovieFields(Program program) {
        assertThat(program.getReleaseDate(), is(MOVIE_RELEASE_DATE));
    }

    protected void assertNullMovieFields(Program program) {
        assertThat(program.getReleaseDate(), is(nullValue()));
    }

    // Episode helper methods
    protected void setEpisodeFields(Program program) {
        program.setSeriesId(EPISODE_SERIES_ID);
        program.setTvSeasonId(EPISODE_TVSEASON_ID);
        program.setTvSeasonEpisodeNumber(EPISODE_TVSEASON_EPISODE_NUM);
        program.setSeriesEpisodeNumber(EPISODE_SERIES_EPISODE_NUM);
        program.setTvSeasonNumber(EPISODE_TVSEASON_NUM);
        program.setEpisodeTitle(EPISODE_TITLE);
    }

    protected void assertEpisodeFields(Program program) {
        assertThat(program.getSeriesId(), is(EPISODE_SERIES_ID));
        assertThat(program.getTvSeasonId(), is(EPISODE_TVSEASON_ID));
        assertThat(program.getTvSeasonEpisodeNumber(), is(EPISODE_TVSEASON_EPISODE_NUM));
        assertThat(program.getSeriesEpisodeNumber(), is(EPISODE_SERIES_EPISODE_NUM));
        assertThat(program.getTvSeasonNumber(), is(EPISODE_TVSEASON_NUM));
        assertThat(program.getEpisodeTitle(), is(EPISODE_TITLE));
    }

    protected void assertNullEpisodeFields(Program program) {
        assertThat(program.getSeriesId(), is(nullValue()));
        assertThat(program.getTvSeasonId(), is(nullValue()));
        assertThat(program.getTvSeasonEpisodeNumber(), is(nullValue()));
        assertThat(program.getSeriesEpisodeNumber(), is(nullValue()));
        assertThat(program.getTvSeasonNumber(), is(nullValue()));
        assertThat(program.getEpisodeTitle(), is(nullValue()));
    }

    // SeriesMaster helper methods
    protected void setSeriesMasterFields(Program program) {
        program.setFirstAirDate(new DateOnly(2001, 6, 9));
        program.setLastAirDate(new DateOnly(2007, 11, 27));
    }

    protected void assertSeriesMasterFields(Program program) {
        assertThat(program.getFirstAirDate(), is(SERIES_FIRST_AIRDATE));
        assertThat(program.getLastAirDate(), is(SERIES_LAST_AIRDATE));
    }

    protected void assertNullSeriesMasterFields(Program program) {
        assertThat(program.getFirstAirDate(), is(nullValue()));
        assertThat(program.getLastAirDate(), is(nullValue()));
    }

    // SportsSubtitle helper methods
    protected void setSportsSubtitleField(Program program) {
        program.setSportsSubtitle(SPORTS_SUBTITLE);
    }

    protected void assertSportsSubtitleField(Program program) {
        assertThat(program.getSportsSubtitle(), is(SPORTS_SUBTITLE));
    }

    protected void assertNullSportsSubtitleField(Program program) {
        assertThat(program.getSportsSubtitle(), is(nullValue()));
    }

}
