package com.theplatform.data.tv.entity.api.client.query.person;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Person by personType query.
 */
public class ByPersonType extends OrQuery<String> {

    public final static String QUERY_NAME = "personType";

    /**
     * Construct a ByPersonType query with the given value.
     *
     * @param personType the person type
     */
    public ByPersonType(String personType) {
        this(Collections.singletonList(personType));

        if (personType == null) {
            throw new IllegalArgumentException("personType cannot be null.");
        }
    }

    /**
     * Construct a ByPersonType query with the given list of values.
     * The list must not be empty.
     *
     * @param personTypes the list of creditsType values
     */
    public ByPersonType(List<String> personTypes) {
        super(QUERY_NAME, personTypes);
    }

}
