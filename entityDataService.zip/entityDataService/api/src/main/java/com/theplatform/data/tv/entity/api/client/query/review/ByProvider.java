package com.theplatform.data.tv.entity.api.client.query.review;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByProvider extends OrQuery<String> {

    public final static String QUERY_NAME = "provider";

    public ByProvider(String provider) {
        this(Collections.singletonList(provider));

        if (provider == null) {
            throw new IllegalArgumentException("provider cannot be null.");
        }
    }

    public ByProvider(List<String> providers) {
        super(QUERY_NAME, providers);
    }
}
