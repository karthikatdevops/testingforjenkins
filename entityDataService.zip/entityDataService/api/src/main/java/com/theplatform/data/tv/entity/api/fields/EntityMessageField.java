package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.data.api.NamespacedField;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/22/15
 */
public enum EntityMessageField implements NamespacedField {

    entityId,
    freeText,
    type,
    priority,
    merlinResourceType,
    _all {
        @Override
        public String getQualifiedName() {
            return NAMESPACE + ":";
        }

        @Override
        public String getLocalName() {
            return null;
        }
    };

    public static final String NAMESPACE = "http://xml.theplatform.com/data/tv/entity/EntityMessage";

    /**
     * {@inheritDoc}
     */
    public String getNamespace() {
        return NAMESPACE;
    }

    /**
     * {@inheritDoc}
     */
    public String getQualifiedName() {
        return new StringBuilder(getNamespace()).append(':').append(getLocalName()).toString();
    }

    /**
     * {@inheritDoc}
     */
    public String getLocalName() {
        return name();
    }

    @Override
    public String toString() {
        return getQualifiedName();
    }

}
