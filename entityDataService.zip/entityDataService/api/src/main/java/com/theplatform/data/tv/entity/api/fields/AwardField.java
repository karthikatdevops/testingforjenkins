package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.data.api.NamespacedField;

public enum AwardField implements NamespacedField {
    rank,
    merlinResourceType,
    _all {
        @Override
        public String getQualifiedName() {
            return NAMESPACE + ":";
        }

        @Override
        public String getLocalName() {
            return null;
        }
    };

    /**
     * The namespace for all <code>Award</code> fields.
     */
    public static final String NAMESPACE = "http://xml.theplatform.com/data/tv/entity/Award";

    /**
     * {@inheritDoc}
     */
    public String getNamespace() {
        return NAMESPACE;
    }

    /**
     * {@inheritDoc}
     */
    public String getQualifiedName() {
        return new StringBuilder(getNamespace()).append(':').append(getLocalName()).toString();
    }

    /**
     * {@inheritDoc}
     */
    public String getLocalName() {
        return name();
    }

    @Override
    public String toString() {
        return getQualifiedName();
    }


}
