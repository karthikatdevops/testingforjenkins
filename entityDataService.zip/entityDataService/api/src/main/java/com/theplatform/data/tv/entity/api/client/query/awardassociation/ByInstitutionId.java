package com.theplatform.data.tv.entity.api.client.query.awardassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * AwardAssociation ByInstitutionId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByInstitutionId extends OrQuery<Object> {

    public final static String QUERY_NAME = "institutionId";

    /**
     * Construct a ByInstitutionId query with the given value.
     *
     * @param institutionId the numeric id for a person
     */
    public ByInstitutionId(Long institutionId) {
        this(Collections.singletonList(institutionId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param institutionId the CURN or Comcast URL id to find
     */
    public ByInstitutionId(URI institutionId) {
        this(Collections.singletonList(institutionId));
    }

    /**
     * Construct a ByPersonId query with the given list of values.
     * The list must not be empty.
     *
     * @param institutionIds the list of numeric personId values
     */
    public ByInstitutionId(List<?> institutionIds) {
        super(QUERY_NAME, institutionIds);
    }


}
