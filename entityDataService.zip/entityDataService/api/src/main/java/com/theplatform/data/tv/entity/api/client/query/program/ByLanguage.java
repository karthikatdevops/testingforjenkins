package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByLanguage extends OrQuery<String> {

    public final static String QUERY_NAME = "language";

    public ByLanguage(String language) {
        this(Collections.singletonList(language));

    }

    public ByLanguage(List<String> languages) {
        super(QUERY_NAME, languages);
    }

}
