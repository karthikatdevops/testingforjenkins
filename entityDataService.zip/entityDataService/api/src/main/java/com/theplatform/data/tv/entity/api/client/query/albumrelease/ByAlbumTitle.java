package com.theplatform.data.tv.entity.api.client.query.albumrelease;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * @author mdore
 */
public class ByAlbumTitle extends OrQuery<String> {

    private final static String QUERY_NAME = "albumTitle";

    /**
     * Construct a ByAlbumTitle query with the given value.
     *
     * @param albumTitle the title of the album
     */
    public ByAlbumTitle(String albumTitle) {
        this(Collections.singletonList(albumTitle));
    }

    /**
     * Construct a ByAlbumTitle query with the given list of values.
     * The list must not be empty.
     *
     * @param albumTitles the list of album titles
     */
    public ByAlbumTitle(List<String> albumTitles) {
        super(QUERY_NAME, albumTitles);
    }
}
