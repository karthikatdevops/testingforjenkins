package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByCreditsType extends OrQuery<String> {

    public final static String QUERY_NAME = "credits.type";

    public ByCreditsType(String creditType) {
        this(Collections.singletonList(creditType));

        if (creditType == null) {
            throw new IllegalArgumentException("credits.type cannot be null.");
        }
    }

    public ByCreditsType(List<String> creditTypes) {
        super(QUERY_NAME, creditTypes);
    }

}
