package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * ProgramMediaAssociation by case-insensitive providerId query.
 */
public class ByProviderId extends OrQuery<String> {

    public final static String QUERY_NAME = "providerId";

    /**
     * Construct a case-insensitive ByProviderId query with the given value.
     *
     * @param providerId the ProviderId
     */
    public ByProviderId(String providerId) {
        this(Collections.singletonList(providerId));

        if (providerId == null) {
            throw new IllegalArgumentException("providerId cannot be null.");
        }
    }

    /**
     * Construct a case-insensitive ByProviderId query with the given list of values.
     * The list must not be empty.
     *
     * @param providerIds the list of ProviderIds
     */
    public ByProviderId(List<String> providerIds) {
        super(QUERY_NAME, providerIds);
    }

}
