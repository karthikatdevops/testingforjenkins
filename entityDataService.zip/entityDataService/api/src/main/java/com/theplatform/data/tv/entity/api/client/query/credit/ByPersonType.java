package com.theplatform.data.tv.entity.api.client.query.credit;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByPersonType extends OrQuery<String> {
    public final static String QUERY_NAME = "person.personType";

    public ByPersonType(String personType) {
        this(Collections.singletonList(personType));

        if (personType == null) {
            throw new IllegalArgumentException("personType cannot be null.");
        }
    }

    public ByPersonType(List<String> personTypes) {
        super(QUERY_NAME, personTypes);
    }
}
