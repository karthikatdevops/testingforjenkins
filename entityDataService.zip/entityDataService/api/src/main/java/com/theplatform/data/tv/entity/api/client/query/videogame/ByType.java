package com.theplatform.data.tv.entity.api.client.query.videogame;

import com.theplatform.data.api.client.query.ValueQuery;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 12/2/14
 */
public class ByType extends ValueQuery<String> {

    public final static String QUERY_NAME = "type";

    public ByType(String type) {
        super(QUERY_NAME, type);
    }

}
