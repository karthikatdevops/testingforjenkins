package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.contrib.service.ReflectionHelper;
import com.theplatform.data.api.NamespacedField;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Enumeration of <code>Program</code> fields.
 * <p>
 * The <code>toString()</code> method has been overridden to return
 * the namespace-qualified name for each field.
 * <p>
 * The <code>_all</code> value should be used to refer to all fields.
 * The <code>toString()</code> method for this value has been overridden
 * to return the <code>Station</code> namespace followed by a single colon
 * character (:).
 */
public enum ProgramField implements NamespacedField {
    // Non-collection Program-scoped fields
    year,
    longSynopsis,
    mediumSynopsis,
    shortSynopsis,
    runtime,
    type,
    language,
    @Deprecated
    contentRating,
    contentRatings,
    shortTitle,
    mediumTitle,
    longTitle,
    partNumber,
    totalParts,
    starRating,
    category,
    originalAirDate,
    firstRunCompanyId,
    sortTitle,
    adult,
    local,
    merlinResourceType,
    listByTitle,
    // Movie-scoped fields
    releaseDate {
        @Override
        public String getNamespace() {
            return "http://xml.theplatform.com/data/tv/entity/Program/Movie";
        }
    },
    // Episode-scoped fields
    seriesId {
        @Override
        public String getNamespace() {
            return "http://xml.theplatform.com/data/tv/entity/Program/Episode";
        }
    },
    tvSeasonId {
        @Override
        public String getNamespace() {
            return "http://xml.theplatform.com/data/tv/entity/Program/Episode";
        }
    },
    tvSeasonNumber {
        @Override
        public String getNamespace() {
            return "http://xml.theplatform.com/data/tv/entity/Program/Episode";
        }
    },
    tvSeasonEpisodeNumber {
        @Override
        public String getNamespace() {
            return "http://xml.theplatform.com/data/tv/entity/Program/Episode";
        }
    },
    seriesEpisodeNumber {
        @Override
        public String getNamespace() {
            return "http://xml.theplatform.com/data/tv/entity/Program/Episode";
        }
    },
    episodeTitle {
        @Override
        public String getNamespace() {
            return "http://xml.theplatform.com/data/tv/entity/Program/Episode";
        }
    },
    productionEpisodeNumber,
    // SeriesMaster-scoped fields
    firstAirDate {
        @Override
        public String getNamespace() {
            return "http://xml.theplatform.com/data/tv/entity/Program/SeriesMaster";
        }
    },
    lastAirDate {
        @Override
        public String getNamespace() {
            return "http://xml.theplatform.com/data/tv/entity/Program/SeriesMaster";
        }
    },
    sportsSubtitle,
    // Collection Program-scoped fields
    credits,
    @Deprecated
    imageIds,
    tags,
    tagIds,
    @Deprecated
    mainImages,
    selectedImages,
    _all {
        @Override
        public String getQualifiedName() {
            return NAMESPACE + ":";
        }

        @Override
        public String getLocalName() {
            return null;
        }
    };

    public static final String NAMESPACE = "http://xml.theplatform.com/data/tv/entity/Program";

    /**
     * Unmodifiable map of Program.type ==> set of ProgramFields
     */
    protected static final Map<ProgramType, Set<ProgramField>> programTypeSpecificFieldsMap;
    protected static final Set<ProgramField> allSpecificFieldsSet;

    static {
        // This temporary map is mutable; we'll later generate an unmutable one from this.
        HashMap<ProgramType, Set<ProgramField>> temporaryMap = new HashMap<>();
        Set<ProgramField> allTempSpecials = new HashSet<>();

		/*
         * Create a temporary, mutable set of movie fields, and then create an
		 * unmutable version to be put into the map.
		 */
        Set<ProgramField> tempMovieFields = new HashSet<>();
        tempMovieFields.add(ProgramField.releaseDate);
        Set<ProgramField> movieFields = Collections.unmodifiableSet(tempMovieFields);
        allTempSpecials.addAll(tempMovieFields);
        temporaryMap.put(ProgramType.Movie, movieFields);

		/*
		 * Create a temporary, mutable set of series fields, and then create an
		 * unmutable version to be put into the map.
		 */
        Set<ProgramField> tempSeriesFields = new HashSet<>();
        tempSeriesFields.add(ProgramField.firstAirDate);
        tempSeriesFields.add(ProgramField.lastAirDate);
        tempSeriesFields.add(ProgramField.sportsSubtitle);
        Set<ProgramField> seriesFields = Collections.unmodifiableSet(tempSeriesFields);
        allTempSpecials.addAll(tempSeriesFields);
        temporaryMap.put(ProgramType.SeriesMaster, seriesFields);

		/*
		 * Create a temporary, mutable set of episode fields, and then create an
		 * unmutable version to be put into the map.
		 */
        Set<ProgramField> tempEpisodefields = new HashSet<>();
        tempEpisodefields.add(ProgramField.seriesId);
        tempEpisodefields.add(ProgramField.tvSeasonId);
        tempEpisodefields.add(ProgramField.tvSeasonEpisodeNumber);
        tempEpisodefields.add(ProgramField.seriesEpisodeNumber);
        tempEpisodefields.add(ProgramField.tvSeasonNumber);
        tempEpisodefields.add(ProgramField.episodeTitle);
        tempEpisodefields.add(ProgramField.sportsSubtitle);
        tempEpisodefields.add(ProgramField.productionEpisodeNumber);
        Set<ProgramField> episodefields = Collections.unmodifiableSet(tempEpisodefields);
        allTempSpecials.addAll(tempEpisodefields);
        temporaryMap.put(ProgramType.Episode, episodefields);

        Set<ProgramField> tempSportsfields = new HashSet<>();
        tempSportsfields.add(ProgramField.sportsSubtitle);
        Set<ProgramField> sportsfields = Collections.unmodifiableSet(tempSportsfields);
        allTempSpecials.addAll(tempSportsfields);
        temporaryMap.put(ProgramType.SportingEvent, sportsfields);

        Set<ProgramField> tempOtherfields = new HashSet<>();
        tempOtherfields.add(ProgramField.sportsSubtitle);
        Set<ProgramField> otherfields = Collections.unmodifiableSet(tempOtherfields);
        allTempSpecials.addAll(tempOtherfields);
        temporaryMap.put(ProgramType.Other, otherfields);

        programTypeSpecificFieldsMap = Collections.unmodifiableMap(temporaryMap);
        allSpecificFieldsSet = Collections.unmodifiableSet(allTempSpecials);
    }

    protected static Set<ProgramField> getTypeSpecificFields(ProgramType programType) {
        return programTypeSpecificFieldsMap.get(programType);
    }

    protected static Set<ProgramField> getTypeSpecificExclusiveFields(ProgramType programType) {
        Set<ProgramField> includeSet = programTypeSpecificFieldsMap.get(programType);

        Set<ProgramField> exclusiveSet = new HashSet<>();
        exclusiveSet.addAll(allSpecificFieldsSet);
        if (includeSet != null)
            exclusiveSet.removeAll(includeSet);

        return exclusiveSet;
    }

    protected static void nullOutInconsistentTypeSpecificFields(Program program) throws IllegalArgumentException {
        ProgramType actualProgramType = program.getType();

        if (actualProgramType == null) throw new IllegalArgumentException();
		
		/*
		 * The set of type-specific fields for the given program's type. This
		 * may be null, in which case there are no type-specific fields. If
		 * there are any type-specific fields shared between this type and a
		 * different type, then it should NOT be nulled.
		 */
        Set<ProgramField> actualTypeSpecificFields = programTypeSpecificFieldsMap.get(actualProgramType);

        for (ProgramType pt : programTypeSpecificFieldsMap.keySet()) {
            if (pt == actualProgramType) {
                continue;
            }

            for (ProgramField programField : programTypeSpecificFieldsMap.get(pt)) {
				/*
				 * If the program's type has no type specific fields or its set
				 * does not include the field in question, then we should null
				 * it out.
				 */
                if (actualTypeSpecificFields == null || (!actualTypeSpecificFields.contains(programField))) {
                    ReflectionHelper.setProperty(program, programField.getLocalName(), null);
                }
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    public String getNamespace() {
        return NAMESPACE;
    }

    /**
     * {@inheritDoc}
     */
    public String getQualifiedName() {
        return new StringBuilder(getNamespace()).append(':').append(getLocalName()).toString();
    }

    /**
     * {@inheritDoc}
     */
    public String getLocalName() {
        return name();
    }

    @Override
    public String toString() {
        return getQualifiedName();
    }

}
