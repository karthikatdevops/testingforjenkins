package com.theplatform.data.tv.entity.api.client.query.ratingsmapping;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Created by lemuri200 on 6/1/15.
 */
public class BySourceRatingSystem extends OrQuery<String> {
    public static final String QUERY_NAME = "sourceRatingSystem";

    public BySourceRatingSystem(String ratingsSystemType) {
        this(Collections.singletonList(ratingsSystemType));
    }

    public BySourceRatingSystem(List<String> ratingsSystemTypes) {
        super(QUERY_NAME, ratingsSystemTypes);
    }
}
