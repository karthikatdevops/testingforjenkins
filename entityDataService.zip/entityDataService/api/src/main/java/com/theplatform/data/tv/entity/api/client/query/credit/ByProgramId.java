package com.theplatform.data.tv.entity.api.client.query.credit;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * Credit by programId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByProgramId extends OrQuery<Object> {

    public final static String QUERY_NAME = "programId";

    /**
     * Construct a ByProgramId query with the given value.
     *
     * @param programId the numeric id for a program
     */
    public ByProgramId(Long programId) {
        this(Collections.singletonList(programId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param programId the CURN or Comcast URL id
     */
    public ByProgramId(URI programId) {
        this(Collections.singletonList(programId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The programIds must be Longs and/or URI (CURN and/or Comcast URL)
     * The list must not be empty.
     *
     * @param programIds the list of numeric programId values
     */
    public ByProgramId(List<?> programIds) {
        super(QUERY_NAME, programIds);
    }

}
