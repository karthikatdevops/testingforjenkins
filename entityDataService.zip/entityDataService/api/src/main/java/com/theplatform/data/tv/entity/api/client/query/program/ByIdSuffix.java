package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByIdSuffix extends OrQuery<Integer> {

    public final static String QUERY_NAME = "idSuffix";

    public ByIdSuffix(int idSuffix) {
        this(Collections.singletonList(idSuffix));
    }

    public ByIdSuffix(List<Integer> idSuffixes) {
        super(QUERY_NAME, idSuffixes);
    }

}
