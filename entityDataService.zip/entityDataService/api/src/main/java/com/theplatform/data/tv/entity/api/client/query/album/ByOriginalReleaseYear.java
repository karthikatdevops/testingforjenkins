package com.theplatform.data.tv.entity.api.client.query.album;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Album by originalReleaseYear query.
 */
public class ByOriginalReleaseYear extends OrQuery<Integer> {

    public final static String QUERY_NAME = "originalReleaseYear";

    /**
     * Construct a ByOriginalReleaseYear query with the given value.
     *
     * @param originalReleaseYear the original release year
     */
    public ByOriginalReleaseYear(int originalReleaseYear) {
        this(Collections.singletonList(originalReleaseYear));
    }

    /**
     * Construct a ByOriginalReleaseYear query with the given list of values.
     * The list must not be empty.
     *
     * @param originalReleaseYears the list of numeric originalReleaseYear values
     */
    public ByOriginalReleaseYear(List<Integer> originalReleaseYears) {
        super(QUERY_NAME, originalReleaseYears);
    }

}
