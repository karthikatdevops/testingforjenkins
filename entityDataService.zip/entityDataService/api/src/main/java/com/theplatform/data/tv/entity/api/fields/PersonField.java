package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.data.api.NamespacedField;

/**
 * Enumeration of <code>Person</code> fields.
 * <p>
 * The <code>toString()</code> method has been overridden to return
 * the namespace-qualified name for each field.
 * <p>
 * The <code>_all</code> value should be used to refer to all fields.
 * The <code>toString()</code> method for this value has been overridden
 * to return the <code>Person</code> namespace followed by a single colon
 * character (:).
 */
public enum PersonField implements NamespacedField {
    name,
    birthName,
    sortName,
    birth,
    death,
    shortBio,
    mediumBio,
    longBio,
    birthplace,
    personType,
    knownFor,
    aliases,
    credits,
    @Deprecated imageIds,
    @Deprecated
    mainImages,
    selectedImages,
    merlinResourceType,
    _all {
        @Override
        public String getQualifiedName() {
            return NAMESPACE + ":";
        }

        @Override
        public String getLocalName() {
            return null;
        }
    };

    /**
     * The namespace for all <code>Person</code> fields.
     */
    public static final String NAMESPACE = "http://xml.theplatform.com/data/tv/entity/Person";

    /**
     * {@inheritDoc}
     */
    public String getNamespace() {
        return NAMESPACE;
    }

    /**
     * {@inheritDoc}
     */
    public String getQualifiedName() {
        return new StringBuilder(getNamespace()).append(':').append(getLocalName()).toString();
    }

    /**
     * {@inheritDoc}
     */
    public String getLocalName() {
        return name();
    }

    @Override
    public String toString() {
        return getQualifiedName();
    }

}
