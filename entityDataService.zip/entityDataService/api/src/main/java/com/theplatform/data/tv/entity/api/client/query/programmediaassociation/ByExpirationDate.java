package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 7/6/12
 * Time: 4:45 PM
 * To change this template use File | Settings | File Templates.
 */

import com.theplatform.data.api.client.query.RangeQuery;

import java.util.Date;

/**
 * Listing by expirationDate query.
 */
public class ByExpirationDate extends RangeQuery<Date> {

    private final static String QUERY_NAME = "expirationDate";

    /**
     * Construct a ByExpirationDate query with the given expirationDate value.
     *
     * @param expirationDate the expirationDate
     */
    public ByExpirationDate(Date expirationDate) {
        super(QUERY_NAME, expirationDate);
    }

    /**
     * Construct a ByExpirationDate query with the given expirationDate range.
     *
     * @param expirationDateMin the start of the expirationDate range, or null for an unbounded start
     * @param expirationDateMax the end of the expirationDate range, or null for an unbounded end
     */
    public ByExpirationDate(Date expirationDateMin, Date expirationDateMax) {
        super(QUERY_NAME, expirationDateMin, expirationDateMax);
    }

}