package com.theplatform.data.tv.entity.api.client.query.programrank;

import com.theplatform.data.api.client.query.OrQuery;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;

import java.util.Collections;
import java.util.List;

public class ByProgramType extends OrQuery<ProgramType> {

    public final static String QUERY_NAME = "program.type";

    /**
     * Construct a ByProgramType query with the given value.
     *
     * @param programType the program type
     */
    public ByProgramType(ProgramType programType) {
        this(Collections.singletonList(programType));

        if (programType == null) {
            throw new IllegalArgumentException("programType cannot be null.");
        }
    }

    /**
     * Construct a ByProgramType query with the given list of values.
     * The list must not be empty.
     *
     * @param programTypes the list of programs types
     */
    public ByProgramType(List<ProgramType> programTypes) {
        super(QUERY_NAME, programTypes);
    }


}
