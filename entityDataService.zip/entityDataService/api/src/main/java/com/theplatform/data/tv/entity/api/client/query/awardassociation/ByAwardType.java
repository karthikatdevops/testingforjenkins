package com.theplatform.data.tv.entity.api.client.query.awardassociation;

import com.theplatform.data.api.client.query.ValueQuery;
import com.theplatform.data.tv.entity.api.data.objects.AwardType;

public class ByAwardType extends ValueQuery<AwardType> {

    public static final String QUERY_NAME = "awardType";

    public ByAwardType(AwardType awardType) {
        super(QUERY_NAME, awardType);
    }

}
