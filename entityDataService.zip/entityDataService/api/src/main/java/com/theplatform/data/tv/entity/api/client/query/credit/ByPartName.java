package com.theplatform.data.tv.entity.api.client.query.credit;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Credit by partName query.
 */
public class ByPartName extends OrQuery<String> {

    public final static String QUERY_NAME = "partName";

    /**
     * Construct a ByPartName query with the given value.
     *
     * @param partName the partName for a credit
     */
    public ByPartName(String partName) {
        this(Collections.singletonList(partName));

        if (partName == null) {
            throw new IllegalArgumentException("partName cannot be null.");
        }
    }

    /**
     * Construct a ByPartName query with the given list of values.
     * The list must not be empty.
     *
     * @param partNames the list of credit partNames
     */
    public ByPartName(List<String> partNames) {
        super(QUERY_NAME, partNames);
    }

}
