package com.theplatform.data.tv.entity.api.client.query.videogame;

import com.theplatform.data.api.client.query.ValueQuery;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 12/2/14
 */
public class BySinglePlayer extends ValueQuery<Boolean> {

    private final static String QUERY_NAME = "singlePlayer";

    /**
     * Construct a BySinglePlayer query with the given value.
     *
     * @param singlePlayer the boolean value
     */
    public BySinglePlayer(boolean singlePlayer) {
        super(QUERY_NAME, singlePlayer);
    }
}