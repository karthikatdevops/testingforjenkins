package com.theplatform.data.tv.entity.api.client.query.personteamassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * PersonTeamAssociation BySportsTeamId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByPersonId extends OrQuery<Object> {

    public final static String QUERY_NAME = "personId";

    /**
     * Construct a query using a numeric id
     *
     * @param personId the numeric id to find
     */
    public ByPersonId(Long personId) {
        this(Collections.singletonList(personId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param personId the CURN or Comcast URL id to find
     */
    public ByPersonId(URI personId) {
        this(Collections.singletonList(personId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param personIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public ByPersonId(List<?> personIds) {
        super(QUERY_NAME, personIds);
    }

}
