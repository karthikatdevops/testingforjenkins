package com.theplatform.data.tv.entity.api.client.query.song;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByIsrc extends OrQuery<String> {

    public final static String QUERY_NAME = "isrc";

    /**
     * Construct a ByIsrc query with the given value.
     *
     * @param isrc
     */
    public ByIsrc(String isrc) {
        this(Collections.singletonList(isrc));

        if (isrc == null) {
            throw new IllegalArgumentException("isrc cannot be null.");
        }
    }

    /**
     * Construct a ByIsrc query with the given list of values.
     * The list must not be empty.
     *
     * @param isrc
     */
    public ByIsrc(List<String> isrc) {
        super(QUERY_NAME, isrc);
    }


}

