package com.theplatform.data.tv.entity.api.client.query.relatedperson;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * RelatedPerson ByTargetPersonId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByTargetPersonId extends OrQuery<Object> {

    public final static String QUERY_NAME = "targetPersonId";

    /**
     * Construct a query using a numeric id
     *
     * @param targetPersonId the numeric id
     */
    public ByTargetPersonId(Long targetPersonId) {
        this(Collections.singletonList(targetPersonId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param targetPersonId the CURN or Comcast URL id
     */
    public ByTargetPersonId(URI targetPersonId) {
        this(Collections.singletonList(targetPersonId));
    }


    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param targetPersonIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public ByTargetPersonId(List<?> targetPersonIds) {
        super(QUERY_NAME, targetPersonIds);
    }

}
