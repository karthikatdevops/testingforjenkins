package com.theplatform.data.tv.entity.api.client.query.albumrelease;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * AlbumRelease by releaseYear query.
 */
public class ByReleaseYear extends OrQuery<Integer> {

    public final static String QUERY_NAME = "releaseYear";

    /**
     * Construct a ByReleaseYear query with the given value.
     *
     * @param releaseYear the release year
     */
    public ByReleaseYear(int releaseYear) {
        this(Collections.singletonList(releaseYear));
    }

    /**
     * Construct a ByReleaseYear query with the given list of values.
     * The list must not be empty.
     *
     * @param releaseYears the list of numeric releaseYear values
     */
    public ByReleaseYear(List<Integer> releaseYears) {
        super(QUERY_NAME, releaseYears);
    }

}
