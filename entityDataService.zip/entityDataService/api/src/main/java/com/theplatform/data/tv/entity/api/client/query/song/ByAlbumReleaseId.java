package com.theplatform.data.tv.entity.api.client.query.song;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Song by albumReleaseId query.
 */
public class ByAlbumReleaseId extends OrQuery<Long> {

    public final static String QUERY_NAME = "albumReleaseId";

    /**
     * Construct a ByAlbumReleaseId query with the given value.
     *
     * @param albumReleaseId the numeric id for an albumRelease
     */
    public ByAlbumReleaseId(long albumReleaseId) {
        this(Collections.singletonList(albumReleaseId));
    }

    /**
     * Construct a ByAlbumReleaseId query with the given list of values.
     * The list must not be empty.
     *
     * @param albumReleaseIds the list of numeric albumReleaseId values
     */
    public ByAlbumReleaseId(List<Long> albumReleaseIds) {
        super(QUERY_NAME, albumReleaseIds);
    }

}
