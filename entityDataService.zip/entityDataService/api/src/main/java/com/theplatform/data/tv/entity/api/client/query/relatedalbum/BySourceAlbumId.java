package com.theplatform.data.tv.entity.api.client.query.relatedalbum;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * RelatedAlbum BySourceAlbumId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class BySourceAlbumId extends OrQuery<Object> {

    public final static String QUERY_NAME = "sourceAlbumId";

    /**
     * Construct a query using a numeric id
     *
     * @param sourceAlbumId the numeric id
     */
    public BySourceAlbumId(Long sourceAlbumId) {
        this(Collections.singletonList(sourceAlbumId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param sourceAlbumId the CURN or Comcast URL id
     */
    public BySourceAlbumId(URI sourceAlbumId) {
        this(Collections.singletonList(sourceAlbumId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param sourceAlbumIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public BySourceAlbumId(List<?> sourceAlbumIds) {
        super(QUERY_NAME, sourceAlbumIds);
    }

}
