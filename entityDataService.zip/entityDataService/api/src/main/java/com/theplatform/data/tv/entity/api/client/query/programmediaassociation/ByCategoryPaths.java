package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: jdoto200
 * Date: 7/30/13
 * Time: 3:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class ByCategoryPaths extends OrQuery<String> {

    public final static String QUERY_NAME = "categoryPaths";

    public ByCategoryPaths(String category) {
        this(Collections.singletonList(CategoryPathUtils.normalizePathAndToLowerCase(category)));
    }

    public ByCategoryPaths(List<String> categories) {
        super(QUERY_NAME, CategoryPathUtils.normalizePathsAndConvertToLowerCase(categories));
    }
}