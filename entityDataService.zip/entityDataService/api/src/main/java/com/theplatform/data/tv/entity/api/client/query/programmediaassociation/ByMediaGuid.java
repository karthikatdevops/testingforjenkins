package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * ProgramMediaAssociation by case-insensitive mediaGuid query.
 *
 * @deprecated Use {@link com.theplatform.contrib.data.api.client.query.ByMediaIdMediaGuid} instead.
 */
@Deprecated
public class ByMediaGuid extends OrQuery<String> {

    public final static String QUERY_NAME = "mediaGuid";

    /**
     * Construct a case-insensitive ByMediaGuid query with the given value.
     *
     * @param mediaGuid the guid for a media
     */
    public ByMediaGuid(String mediaGuid) {
        this(Collections.singletonList(mediaGuid));

        if (mediaGuid == null) {
            throw new IllegalArgumentException("type cannot be null.");
        }
    }

    /**
     * Construct a case-insensitive ByMediaGuid query with the given list of values.
     * The list must not be empty.
     *
     * @param mediaGuids the list of media guids
     */
    public ByMediaGuid(List<String> mediaGuids) {
        super(QUERY_NAME, mediaGuids);
    }

}
