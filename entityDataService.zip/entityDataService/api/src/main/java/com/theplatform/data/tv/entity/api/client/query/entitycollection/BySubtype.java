package com.theplatform.data.tv.entity.api.client.query.entitycollection;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class BySubtype extends OrQuery<String> {

    public final static String QUERY_NAME = "subtype";

    public BySubtype(String subtype) {
        this(Collections.singletonList(subtype));

        if (subtype == null) {
            throw new IllegalArgumentException("subtype cannot be null.");
        }
    }

    public BySubtype(List<String> subtypes) {
        super(QUERY_NAME, subtypes);
    }

}
