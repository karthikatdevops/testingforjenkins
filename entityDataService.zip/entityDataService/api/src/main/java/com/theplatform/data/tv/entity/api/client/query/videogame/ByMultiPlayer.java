package com.theplatform.data.tv.entity.api.client.query.videogame;

import com.theplatform.data.api.client.query.ValueQuery;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 12/2/14
 */
public class ByMultiPlayer extends ValueQuery<Boolean> {

    private final static String QUERY_NAME = "multiPlayer";

    /**
     * Construct a ByMultiPlayer query with the given value.
     *
     * @param multiPlayer the boolean value
     */
    public ByMultiPlayer(boolean multiPlayer) {
        super(QUERY_NAME, multiPlayer);
    }
}