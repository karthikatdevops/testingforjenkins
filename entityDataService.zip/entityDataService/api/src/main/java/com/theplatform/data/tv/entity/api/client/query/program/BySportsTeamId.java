package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.contrib.data.api.client.query.AndOrQuery;
import com.theplatform.contrib.data.api.client.query.QueryType;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * This query allows you to query by sportsTeamId using a Long, Comcast URN, or Comcast URL
 */
public class BySportsTeamId extends AndOrQuery<Object> {
    private final static String QUERY_NAME = "sportsTeamId";

    /**
     * Construct a query using a numeric id. Default query type is OR
     *
     * @param sportsTeamId the numeric id to find
     */
    public BySportsTeamId(Long sportsTeamId) {
        this(Collections.singletonList(sportsTeamId), QueryType.OR);

        if (sportsTeamId == null) {
            throw new IllegalArgumentException("sportsTeamId cannot be null.");
        }

    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param sportsTeamId the CURN or Comcast URL id to find
     */
    public BySportsTeamId(URI sportsTeamId) {
        this(Collections.singletonList(sportsTeamId), QueryType.OR);

        if (sportsTeamId == null) {
            throw new IllegalArgumentException("sportsTeamId cannot be null.");
        }

    }

    /**
     * Construct a query using a numeric id.
     *
     * @param sportsTeamId the numeric id to find
     * @param queryType    the query type to use
     */
    public BySportsTeamId(Long sportsTeamId, QueryType queryType) {
        this(Collections.singletonList(sportsTeamId), queryType);

        if (sportsTeamId == null) {
            throw new IllegalArgumentException("sportsTeamId cannot be null.");
        }

    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param sportsTeamId the CURN or Comcast URL id to find
     * @param queryType    the query type to use
     */
    public BySportsTeamId(URI sportsTeamId, QueryType queryType) {
        this(Collections.singletonList(sportsTeamId), queryType);

        if (sportsTeamId == null) {
            throw new IllegalArgumentException("sportsTeamId cannot be null.");
        }

    }

    /**
     * Construct a query. The sportsTeamId must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param sportsTeamId a list of Long and/or URI (CURNS or Comcast URL ids). The list must not be empty or null.
     * @param queryType    the query type to use
     */
    public BySportsTeamId(List<?> sportsTeamId, QueryType queryType) {
        super(QUERY_NAME, sportsTeamId, queryType);
    }

}
