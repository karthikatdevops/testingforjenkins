package com.theplatform.data.tv.entity.api.client.query.awardassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByYear extends OrQuery<Integer> {

    public final static String QUERY_NAME = "year";

    public ByYear(int year) {
        this(Collections.singletonList(year));
    }

    public ByYear(List<Integer> years) {
        super(QUERY_NAME, years);
    }

}
