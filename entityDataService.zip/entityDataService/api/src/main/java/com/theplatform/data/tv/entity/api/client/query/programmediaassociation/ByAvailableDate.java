package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 7/6/12
 * Time: 4:43 PM
 * To change this template use File | Settings | File Templates.
 */

import com.theplatform.data.api.client.query.RangeQuery;

import java.util.Date;

/**
 * Listing by availableDate query.
 */
public class ByAvailableDate extends RangeQuery<Date> {

    private final static String QUERY_NAME = "availableDate";

    /**
     * Construct a ByAvailableDate query with the given availableDate value.
     *
     * @param availableDate the availableDate
     */
    public ByAvailableDate(Date availableDate) {
        super(QUERY_NAME, availableDate);
    }

    /**
     * Construct a ByAvailableDate query with the given availableDate range.
     *
     * @param availableDateMin the start of the availableDate range, or null for an unbounded start
     * @param availableDateMax the end of the availableDate range, or null for an unbounded end
     */
    public ByAvailableDate(Date availableDateMin, Date availableDateMax) {
        super(QUERY_NAME, availableDateMin, availableDateMax);
    }

}