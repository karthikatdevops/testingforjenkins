package com.theplatform.data.tv.entity.api.client.query.relatedperson;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * RelatedPerson BySourcePersonId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class BySourcePersonId extends OrQuery<Object> {

    public final static String QUERY_NAME = "sourcePersonId";

    /**
     * Construct a query using a numeric id
     *
     * @param sourcePersonId the numeric id
     */
    public BySourcePersonId(Long sourcePersonId) {
        this(Collections.singletonList(sourcePersonId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param sourcePersonId the CURN or Comcast URL id
     */
    public BySourcePersonId(URI sourcePersonId) {
        this(Collections.singletonList(sourcePersonId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param sourcePersonIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public BySourcePersonId(List<?> sourcePersonIds) {
        super(QUERY_NAME, sourcePersonIds);
    }

}
