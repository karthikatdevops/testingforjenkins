package com.theplatform.data.tv.entity.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.data.api.client.HeaderStuffingDataServiceClient;
import com.theplatform.data.api.client.ClientConfiguration;
import com.theplatform.data.tv.entity.api.data.objects.PersonTeamAssociation;

import java.net.UnknownHostException;

/**
 * Client for ProgramTeamAssociation objects.
 */
public class PersonTeamAssociationClient extends HeaderStuffingDataServiceClient<PersonTeamAssociation> {

    /**
     * Constructor.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @throws UnknownHostException
     */
    public PersonTeamAssociationClient(String baseUrl, AuthorizationHeaderFactory authorization) throws UnknownHostException {
        super(baseUrl, authorization);
    }

    /**
     * Constructor that takes a ClientConfiguration.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @param configuration the client configuration
     * @throws UnknownHostException
     */
    public PersonTeamAssociationClient(String baseUrl, AuthorizationHeaderFactory authorization, ClientConfiguration configuration) throws UnknownHostException {
        super(baseUrl, authorization, configuration);
    }

    /**
     * Gets the ProgramTeamAssociation class.
     *
     * @return the ProgramTeamAssociation class
     */
    protected Class<PersonTeamAssociation> getGenericClass() {
        return PersonTeamAssociation.class;
    }

}
