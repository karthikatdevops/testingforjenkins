package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;

import java.util.Collections;
import java.util.List;

public class ByProgramResourceType extends OrQuery<MerlinResourceType> {

    private final static String QUERY_NAME = "programResourceType";

    /**
     * Construct a ByProgramResourceType query with the given value.
     *
     * @param merlinResourceType the programResourceType
     */
    public ByProgramResourceType(MerlinResourceType programResourceType) {
        this(Collections.singletonList(programResourceType));

        if (programResourceType == null) {
            throw new IllegalArgumentException("merlinResourceType cannot be null.");
        }
    }

    /**
     * Construct a ByProgramResourceType query with the given list of values.
     * The list must not be empty.
     *
     * @param programResourceTypes the list of programResourceTypes
     */
    public ByProgramResourceType(List<MerlinResourceType> programResourceTypes) {
        super(QUERY_NAME, programResourceTypes);
    }


}
