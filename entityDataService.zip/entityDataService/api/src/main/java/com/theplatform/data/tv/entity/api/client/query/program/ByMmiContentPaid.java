package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByMmiContentPaid extends OrQuery<String> {

    public final static String QUERY_NAME = "mmiContentPaid";

    public ByMmiContentPaid(String title) {
        this(Collections.singletonList(title));

        if (title == null) {
            throw new IllegalArgumentException("mmiContentPaid cannot be null.");
        }
    }

    public ByMmiContentPaid(List<String> titles) {
        super(QUERY_NAME, titles);
    }

}
