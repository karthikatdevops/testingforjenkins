package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: jdoto200
 * Date: 8/5/13
 * Time: 4:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class CategoryPathUtils {

    public static List<String> normalizePathsAndConvertToLowerCase(List<String> categoryPaths) {
        List<String> normalizeLowerCasedCategoryPaths = new ArrayList<>();

        for (String categoryPath : categoryPaths) {
            normalizeLowerCasedCategoryPaths.add(normalizePathAndToLowerCase(categoryPath));
        }

        return normalizeLowerCasedCategoryPaths;
    }

    public static String normalizePathAndToLowerCase(String input) {
        return input.replace("[~@#^*_;:.,?<> ]", "").replaceAll("\\s+", "").toLowerCase();
    }
}
