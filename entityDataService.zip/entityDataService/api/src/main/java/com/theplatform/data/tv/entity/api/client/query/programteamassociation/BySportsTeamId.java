package com.theplatform.data.tv.entity.api.client.query.programteamassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * ProgramTeamAssociation BySportsTeamId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class BySportsTeamId extends OrQuery<Object> {

    public final static String QUERY_NAME = "sportsTeamId";

    /**
     * Construct a query using a numeric id
     *
     * @param sportsTeamId the numeric id to find
     */
    public BySportsTeamId(Long sportsTeamId) {
        this(Collections.singletonList(sportsTeamId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param sportsTeamId the CURN or Comcast URL id to find
     */
    public BySportsTeamId(URI sportsTeamId) {
        this(Collections.singletonList(sportsTeamId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param sportsTeamIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public BySportsTeamId(List<?> sportsTeamIds) {
        super(QUERY_NAME, sportsTeamIds);
    }

}
