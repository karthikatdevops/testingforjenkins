package com.theplatform.data.tv.entity.api.client.query.albumreleasesongassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * AlbumReleaseSongAssociation by albumReleaseId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByAlbumReleaseId extends OrQuery<Object> {

    public final static String QUERY_NAME = "albumReleaseId";

    /**
     * Construct a ByAlbumReleaseId query with the given value.
     *
     * @param albumReleaseId the numeric id for a release
     */
    public ByAlbumReleaseId(Long albumReleaseId) {
        this(Collections.singletonList(albumReleaseId));
    }

    /**
     * Construct a ByAlbumReleaseId query with the given value.
     *
     * @param albumReleaseId the CURN or Comcast URL id for a release
     */
    public ByAlbumReleaseId(URI albumReleaseId) {
        this(Collections.singletonList(albumReleaseId));
    }

    /**
     * Construct a ByAlbumReleaseId query with the given list of values.
     * The list must not be empty.
     *
     * @param albumReleaseIds the list of numeric, CURN, or Comcast URL releaseId values
     */
    public ByAlbumReleaseId(List<?> albumReleaseIds) {
        super(QUERY_NAME, albumReleaseIds);
    }

}
