package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.NonPrefixedQuery;
import com.theplatform.data.api.client.query.ValueQuery;

public class MaxCredits extends ValueQuery<Integer> implements NonPrefixedQuery {

    public final static String QUERY_NAME = "maxCredits";

    public MaxCredits(int maxCredits) {
        super(QUERY_NAME, maxCredits);
    }

}
