package com.theplatform.data.tv.entity.api.client.query.awardassociation;

import com.theplatform.data.api.client.query.ValueQuery;
import com.theplatform.data.tv.entity.api.data.objects.AwardStatus;

public class ByAwardStatus extends ValueQuery<AwardStatus> {

    public static final String QUERY_NAME = "awardStatus";

    public ByAwardStatus(AwardStatus AwardStatus) {
        super(QUERY_NAME, AwardStatus);
    }


}
