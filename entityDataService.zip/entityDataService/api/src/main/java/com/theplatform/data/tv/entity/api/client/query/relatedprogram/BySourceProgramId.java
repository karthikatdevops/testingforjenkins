package com.theplatform.data.tv.entity.api.client.query.relatedprogram;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * RelatedProgram BySourceProgramId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class BySourceProgramId extends OrQuery<Object> {

    public final static String QUERY_NAME = "sourceProgramId";

    /**
     * Construct a query using a numeric id
     *
     * @param sourceProgramId the numeric id to find
     */
    public BySourceProgramId(Long sourceProgramId) {
        this(Collections.singletonList(sourceProgramId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param sourceProgramId the CURN or Comcast URL id to find
     */
    public BySourceProgramId(URI sourceProgramId) {
        this(Collections.singletonList(sourceProgramId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param sourceProgramIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public BySourceProgramId(List<?> sourceProgramIds) {
        super(QUERY_NAME, sourceProgramIds);
    }
}
