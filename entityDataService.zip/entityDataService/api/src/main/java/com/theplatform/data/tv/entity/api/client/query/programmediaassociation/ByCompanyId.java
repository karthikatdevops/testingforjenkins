package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * RelatedProgram ByProgramId query. Can use a Long, Comcast URN, or Comcast URL
 * User: kgaitt200
 * Date: 7/5/12
 * Time: 5:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class ByCompanyId extends OrQuery<Object> {
    public final static String QUERY_NAME = "companyId";

    /**
     * Construct a query using a numeric id
     *
     * @param companyId the numeric id to find
     */
    public ByCompanyId(Long companyId) {
        this(Collections.singletonList(companyId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param companyId the CURN or Comcast URL id to find
     */
    public ByCompanyId(URI companyId) {
        this(Collections.singletonList(companyId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param companyIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public ByCompanyId(List<?> companyIds) {
        super(QUERY_NAME, companyIds);
    }

}

