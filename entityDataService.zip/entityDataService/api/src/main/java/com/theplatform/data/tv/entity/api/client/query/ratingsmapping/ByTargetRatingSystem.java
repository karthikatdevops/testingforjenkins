package com.theplatform.data.tv.entity.api.client.query.ratingsmapping;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Created by lemuri200 on 6/1/15.
 */
public class ByTargetRatingSystem extends OrQuery<String> {
    public static final String QUERY_NAME = "targetRatingSystem";

    public ByTargetRatingSystem(String ratingsSystemType) {
        this(Collections.singletonList(ratingsSystemType));
    }

    public ByTargetRatingSystem(List<String> ratingsSystemTypes) {
        super(QUERY_NAME, ratingsSystemTypes);
    }
}
