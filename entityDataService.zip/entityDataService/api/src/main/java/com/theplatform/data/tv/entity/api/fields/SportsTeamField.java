package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.data.api.NamespacedField;

public enum SportsTeamField implements NamespacedField {
    representingName,
    nickName,
    city,
    state,
    country,
    conference,
    division,
    sportType,
    type,
    gender,
    coach,
    coachPersonId,
    venue,
    leagueId,
    parentSportsTeamId,
    @Deprecated imageIds,
    @Deprecated mainImages,
    selectedImages,
    merlinResourceType,
    abbreviation,
    shortBio,
    mediumBio,
    longBio,
    tagIds,
    tags,
    _all {
        @Override
        public String getQualifiedName() {
            return NAMESPACE + ":";
        }

        @Override
        public String getLocalName() {
            return null;
        }
    };

    public static final String NAMESPACE = "http://xml.theplatform.com/data/tv/entity/SportsTeam";

    /**
     * {@inheritDoc}
     */
    public String getNamespace() {
        return NAMESPACE;
    }

    /**
     * {@inheritDoc}
     */
    public String getQualifiedName() {
        return new StringBuilder(getNamespace()).append(':').append(getLocalName()).toString();
    }

    /**
     * {@inheritDoc}
     */
    public String getLocalName() {
        return name();
    }

    @Override
    public String toString() {
        return getQualifiedName();
    }

}
