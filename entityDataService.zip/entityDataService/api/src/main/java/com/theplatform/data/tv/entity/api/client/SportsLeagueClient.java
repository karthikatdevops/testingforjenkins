package com.theplatform.data.tv.entity.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.data.api.client.HeaderStuffingDataServiceClient;
import com.theplatform.data.api.client.ClientConfiguration;
import com.theplatform.data.tv.entity.api.data.objects.SportsLeague;

import java.net.UnknownHostException;

/**
 * Client for SportsLeague objects.
 */
public class SportsLeagueClient extends HeaderStuffingDataServiceClient<SportsLeague> {

    /**
     * Constructor.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @throws UnknownHostException
     */
    public SportsLeagueClient(String baseUrl, AuthorizationHeaderFactory authorization) throws UnknownHostException {
        super(baseUrl, authorization);
    }

    /**
     * Constructor that takes a ClientConfiguration.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @param configuration the client configuration
     * @throws UnknownHostException
     */
    public SportsLeagueClient(String baseUrl, AuthorizationHeaderFactory authorization, ClientConfiguration configuration) throws UnknownHostException {
        super(baseUrl, authorization, configuration);
    }

    /**
     * Gets the SportsLeague class.
     *
     * @return the SportsLeague class
     */
    protected Class<SportsLeague> getGenericClass() {
        return SportsLeague.class;
    }

}
