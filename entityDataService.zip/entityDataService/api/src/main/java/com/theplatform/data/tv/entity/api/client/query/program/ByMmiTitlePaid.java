package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByMmiTitlePaid extends OrQuery<String> {

    public final static String QUERY_NAME = "mmiTitlePaid";

    public ByMmiTitlePaid(String titlePaid) {
        this(Collections.singletonList(titlePaid));

        if (titlePaid == null) {
            throw new IllegalArgumentException("mmiTitlePaid cannot be null.");
        }
    }

    public ByMmiTitlePaid(List<String> titlePaids) {
        super(QUERY_NAME, titlePaids);
    }

}
