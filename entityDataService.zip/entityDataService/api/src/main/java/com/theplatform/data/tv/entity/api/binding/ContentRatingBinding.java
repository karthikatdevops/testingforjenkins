package com.theplatform.data.tv.entity.api.binding;

import com.theplatform.data.api.marshalling.FullyQualifiedName;
import com.theplatform.data.api.marshalling.PayloadForm;
import com.theplatform.data.api.marshalling.convert.Converter;
import com.theplatform.data.api.marshalling.convert.ConverterRegistry;
import com.theplatform.data.api.marshalling.extension.OverridableName;
import com.theplatform.data.api.marshalling.extension.binding.FieldBinding;
import com.theplatform.data.api.marshalling.extension.binding.NeverNullBinding;
import com.theplatform.data.api.marshalling.extension.binding.SimpleValueBinding;
import com.theplatform.data.api.marshalling.extension.handler.json.JsonCollectionHandler;
import com.theplatform.data.api.marshalling.extension.handler.json.JsonSimpleValueHandler;
import com.theplatform.data.api.marshalling.extension.handler.json.JsonStructureHandler;
import com.theplatform.data.api.marshalling.json.stream.JsonStreamReader;
import com.theplatform.data.api.marshalling.json.stream.JsonStreamWriter;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.media.api.data.objects.Rating;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * This custom binding will hide any contentRating fields that would otherwise be null.
 * <p>
 * User: mmattozzi
 * Date: 1/31/12
 * Time: 4:54 PM
 */
public class ContentRatingBinding extends NeverNullBinding<JsonStreamReader, JsonStreamWriter> {

    private static Logger logger = LoggerFactory.getLogger(ContentRatingBinding.class);

    protected static Map<FullyQualifiedName, FieldBinding> MEMBER_BINDINGS = new HashMap<>();

    protected static final Converter stringConverter =
            ConverterRegistry.getInstance(PayloadForm.JSON).getConverter(String.class);

    protected static JsonCollectionHandler jsonCollectionHander;

    static {
        MEMBER_BINDINGS.put(new FullyQualifiedName(ProgramField.NAMESPACE, "scheme"),
                new SimpleValueBinding<>(
                        ProgramField.NAMESPACE, "scheme",
                        new JsonSimpleValueHandler(
                                ProgramField.NAMESPACE, new OverridableName("scheme"), stringConverter)));

        MEMBER_BINDINGS.put(new FullyQualifiedName(ProgramField.NAMESPACE, "rating"),
                new SimpleValueBinding<>(
                        ProgramField.NAMESPACE, "rating",
                        new JsonSimpleValueHandler(
                                ProgramField.NAMESPACE, new OverridableName("rating"), stringConverter)));

        jsonCollectionHander = new JsonCollectionHandler(ProgramField.NAMESPACE,
                new OverridableName("subRatings"), String[].class,
                new JsonSimpleValueHandler(null, new OverridableName("subRatings"), stringConverter));

        MEMBER_BINDINGS.put(new FullyQualifiedName(ProgramField.NAMESPACE, "subRatings"),
                new SimpleValueBinding<>(
                        ProgramField.NAMESPACE, "subRatings",
                        jsonCollectionHander));
    }

    public ContentRatingBinding() {
        super(ProgramField.NAMESPACE, "contentRating",
                new JsonStructureHandler(ProgramField.NAMESPACE, new OverridableName("contentRating"), Rating.class, MEMBER_BINDINGS));
    }
}
