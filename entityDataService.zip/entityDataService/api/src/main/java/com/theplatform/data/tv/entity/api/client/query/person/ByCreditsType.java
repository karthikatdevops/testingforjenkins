package com.theplatform.data.tv.entity.api.client.query.person;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Person by creditsType query.
 */
public class ByCreditsType extends OrQuery<String> {

    public final static String QUERY_NAME = "credits.type";

    /**
     * Construct a ByCreditsType query with the given value.
     *
     * @param creditsType the credits type
     */
    public ByCreditsType(String creditsType) {
        this(Collections.singletonList(creditsType));

        if (creditsType == null) {
            throw new IllegalArgumentException("credits.type cannot be null.");
        }
    }

    /**
     * Construct a ByCreditsType query with the given list of values.
     * The list must not be empty.
     *
     * @param creditsTypes the list of creditsType values
     */
    public ByCreditsType(List<String> creditsTypes) {
        super(QUERY_NAME, creditsTypes);
    }

}
