package com.theplatform.data.tv.entity.api.client.query.songcollection;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * SongCollection by primarySongId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByPrimarySongId extends OrQuery<Object> {

    public final static String QUERY_NAME = "primarySongId";

    /**
     * Construct a ByPrimarySongId query with the given value.
     *
     * @param primarySongId the numeric id for a person
     */
    public ByPrimarySongId(Long primarySongId) {
        this(Collections.singletonList(primarySongId));
    }

    /**
     * Construct a ByPrimarySongId query with the given value.
     *
     * @param primarySongId the CURN or Comcast URL id for a person
     */
    public ByPrimarySongId(URI primarySongId) {
        this(Collections.singletonList(primarySongId));
    }

    /**
     * Construct a ByPrimarySongId query with the given list of values.
     * The list must not be empty.
     *
     * @param primarySongIds the list of numeric primarySongId values
     */
    public ByPrimarySongId(List<?> primarySongIds) {
        super(QUERY_NAME, primarySongIds);
    }

}
