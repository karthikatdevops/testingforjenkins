package com.theplatform.data.tv.entity.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.data.api.client.HeaderStuffingDataServiceClient;
import com.theplatform.data.api.client.ClientConfiguration;
import com.theplatform.data.tv.entity.api.data.objects.RatingsMapping;

import java.net.UnknownHostException;

/**
 * Created by lemuri200 on 6/1/15.
 */
public class RatingsMappingClient extends HeaderStuffingDataServiceClient<RatingsMapping> {
    /**
     * Constructor.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @throws java.net.UnknownHostException
     */
    public RatingsMappingClient(String baseUrl, AuthorizationHeaderFactory authorization) throws UnknownHostException {
        super(baseUrl, authorization);
    }

    /**
     * Constructor that takes a ClientConfiguration.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @param configuration the client configuration
     * @throws UnknownHostException
     */
    public RatingsMappingClient(String baseUrl, AuthorizationHeaderFactory authorization, ClientConfiguration configuration) throws UnknownHostException {
        super(baseUrl, authorization, configuration);
    }

    /**
     * Gets the RatingsMapping class.
     *
     * @return the RatingsMapping class
     */
    protected Class<RatingsMapping> getGenericClass() {
        return RatingsMapping.class;
    }
}
