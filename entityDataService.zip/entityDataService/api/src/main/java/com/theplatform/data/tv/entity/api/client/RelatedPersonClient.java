package com.theplatform.data.tv.entity.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.data.api.client.HeaderStuffingDataServiceClient;
import com.theplatform.data.api.client.ClientConfiguration;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPerson;

import java.net.UnknownHostException;

public class RelatedPersonClient extends HeaderStuffingDataServiceClient<RelatedPerson> {

    /**
     * Constructor.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @throws UnknownHostException
     */
    public RelatedPersonClient(String baseUrl, AuthorizationHeaderFactory authorization) throws UnknownHostException {
        super(baseUrl, authorization);
    }

    /**
     * Constructor that takes a ClientConfiguration.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @param configuration the client configuration
     * @throws UnknownHostException
     */
    public RelatedPersonClient(String baseUrl, AuthorizationHeaderFactory authorization, ClientConfiguration configuration) throws UnknownHostException {
        super(baseUrl, authorization, configuration);
    }

    /**
     * Gets the RelatedPerson class.
     *
     * @return the RelatedPerson class
     */
    protected Class<RelatedPerson> getGenericClass() {
        return RelatedPerson.class;
    }

}
