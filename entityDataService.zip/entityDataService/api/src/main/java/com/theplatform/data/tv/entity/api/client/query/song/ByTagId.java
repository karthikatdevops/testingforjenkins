package com.theplatform.data.tv.entity.api.client.query.song;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * Song by tagId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByTagId extends OrQuery<Object> {

    public final static String QUERY_NAME = "tagId";

    /**
     * Construct a ByTagId query with the given value.
     *
     * @param tagId the numeric id for a tag
     */
    public ByTagId(Long tagId) {
        this(Collections.singletonList(tagId));
    }

    /**
     * Construct a ByTagId query with the given value.
     *
     * @param tagId the CURN or Comcast URL id for a tag
     */
    public ByTagId(URI tagId) {
        this(Collections.singletonList(tagId));
    }

    /**
     * Construct a ByTagId query with the given list of values.
     * The list must not be empty.
     *
     * @param tagIds the list of numeric, CURN, or Comcast URL tag id values
     */
    public ByTagId(List<?> tagIds) {
        super(QUERY_NAME, tagIds);
    }

}