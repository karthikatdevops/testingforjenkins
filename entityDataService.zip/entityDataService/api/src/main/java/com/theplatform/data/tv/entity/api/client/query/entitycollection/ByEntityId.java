package com.theplatform.data.tv.entity.api.client.query.entitycollection;

import com.theplatform.contrib.data.api.client.query.AndOrQuery;
import com.theplatform.contrib.data.api.client.query.QueryType;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * This query allows you to query by productContextId using a Long, Comcast URN, or Comcast URL
 */
public class ByEntityId extends AndOrQuery<Object> {
    private final static String QUERY_NAME = "entityId";

    /**
     * Constructor.
     *
     * @param entityId, single entityId, default query type is OR query
     */
    public ByEntityId(Long entityId) {
        this(Collections.singletonList(entityId), QueryType.OR);

        if (entityId == null) {
            throw new IllegalArgumentException("entityId cannot be null.");
        }

    }

    /**
     * Constructor.
     *
     * @param entityId, single entityId
     * @param queryType the query type to use
     */
    public ByEntityId(Long entityId, QueryType queryType) {
        this(Collections.singletonList(entityId), queryType);

        if (entityId == null) {
            throw new IllegalArgumentException("entityId cannot be null.");
        }

    }

    /**
     * Construct an OR query using a CURN or Comcast URL id
     *
     * @param entityId the CURN or Comcast URL id to find
     */
    public ByEntityId(URI entityId) {
        this(Collections.singletonList(entityId), QueryType.OR);

        if (entityId == null) {
            throw new IllegalArgumentException("entityId cannot be null.");
        }

    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param entityId  the CURN or Comcast URL id to find
     * @param queryType the type of query to use
     */
    public ByEntityId(URI entityId, QueryType queryType) {
        this(Collections.singletonList(entityId), queryType);

        if (entityId == null) {
            throw new IllegalArgumentException("entityId cannot be null.");
        }

    }

    /**
     * This is an OR query.
     * The list must not be empty.
     *
     * @param entityIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public ByEntityId(List<?> entityIds) {
        this(entityIds, QueryType.OR);
    }

    /**
     * Construct a query using a list of numeric ids, CURNs, or Comcast URL ids
     *
     * @param entityIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     * @param queryType the query type to use
     */
    public ByEntityId(List<?> entityIds, QueryType queryType) {
        super(QUERY_NAME, entityIds, queryType);
    }

}
