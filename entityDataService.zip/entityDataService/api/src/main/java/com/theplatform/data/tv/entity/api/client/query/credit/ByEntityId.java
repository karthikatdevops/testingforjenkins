package com.theplatform.data.tv.entity.api.client.query.credit;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * Credit by entityId query. Can use  a Long, Comcast URN, or Comcast URL
 * Deprecated, please use ByProgramId instead
 */
@Deprecated
public class ByEntityId extends OrQuery<Object> {

    public final static String QUERY_NAME = "entityId";

    /**
     * Construct a ByProgramId query with the given value.
     *
     * @param entityId the numeric id for an entity
     */
    public ByEntityId(Long entityId) {
        this(Collections.singletonList(entityId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param entityId the CURN or Comcast URL id to find
     */
    public ByEntityId(URI entityId) {
        this(Collections.singletonList(entityId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     * The list must not be empty.
     *
     * @param entityIds the list of numeric entityId values
     */
    public ByEntityId(List<?> entityIds) {
        super(QUERY_NAME, entityIds);
    }

}
