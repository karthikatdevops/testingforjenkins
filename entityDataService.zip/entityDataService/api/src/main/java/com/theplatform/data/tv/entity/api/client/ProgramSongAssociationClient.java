package com.theplatform.data.tv.entity.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.data.api.client.HeaderStuffingDataServiceClient;
import com.theplatform.data.api.client.ClientConfiguration;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociation;

import java.net.UnknownHostException;

/**
 * Client for ProgramSongAssociation objects.
 */
public class ProgramSongAssociationClient extends HeaderStuffingDataServiceClient<ProgramSongAssociation> {

    /**
     * Constructor.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @throws UnknownHostException
     */
    public ProgramSongAssociationClient(String baseUrl, AuthorizationHeaderFactory authorization) throws UnknownHostException {
        super(baseUrl, authorization);
    }

    /**
     * Constructor that takes a ClientConfiguration.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @param configuration the client configuration
     * @throws UnknownHostException
     */
    public ProgramSongAssociationClient(String baseUrl, AuthorizationHeaderFactory authorization, ClientConfiguration configuration) throws UnknownHostException {
        super(baseUrl, authorization, configuration);
    }

    /**
     * Gets the ProgramSongAssociation class.
     *
     * @return the ProgramSongAssociation class
     */
    protected Class<ProgramSongAssociation> getGenericClass() {
        return ProgramSongAssociation.class;
    }

}
