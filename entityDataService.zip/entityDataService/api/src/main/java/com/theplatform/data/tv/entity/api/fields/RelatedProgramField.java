package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.data.api.NamespacedField;

/**
 * Enumeration of <code>RelatedProgram</code> fields.
 * <p>
 * The <code>toString()</code> method has been overridden to return
 * the namespace-qualified name for each field.
 * <p>
 * The <code>_all</code> value should be used to refer to all fields.
 * The <code>toString()</code> method for this value has been overridden
 * to return the <code>RelatedProgram</code> namespace followed by a single colon
 * character (:).
 */
public enum RelatedProgramField implements NamespacedField {
    sourceProgramId,
    sourceProgram,
    type,
    targetProgramId,
    targetProgram,
    justification,
    rank,
    score,
    merlinResourceType,
    _all {
        @Override
        public String getQualifiedName() {
            return NAMESPACE + ":";
        }

        @Override
        public String getLocalName() {
            return null;
        }
    };

    /**
     * The namespace for all <code>RelatedProgram</code> fields.
     */
    public static final String NAMESPACE = "http://xml.theplatform.com/data/tv/entity/RelatedProgram";

    /**
     * {@inheritDoc}
     */
    public String getNamespace() {
        return NAMESPACE;
    }

    /**
     * {@inheritDoc}
     */
    public String getQualifiedName() {
        return new StringBuilder(getNamespace()).append(':').append(getLocalName()).toString();
    }

    /**
     * {@inheritDoc}
     */
    public String getLocalName() {
        return name();
    }

    @Override
    public String toString() {
        return getQualifiedName();
    }

}
