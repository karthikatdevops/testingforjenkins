package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * Episode Programs by tvSeasonId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByTvSeasonId extends OrQuery<Object> {

    public final static String QUERY_NAME = "tvSeasonId";

    /**
     * Construct a ByTvSeasonId query with the given value.
     *
     * @param tvSeasonId the numeric id for a tvSeason
     */
    public ByTvSeasonId(Long tvSeasonId) {
        this(Collections.singletonList(tvSeasonId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param tvSeasonId the CURN or Comcast URL id to find
     */
    public ByTvSeasonId(URI tvSeasonId) {
        this(Collections.singletonList(tvSeasonId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param tvSeasonIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public ByTvSeasonId(List<?> tvSeasonIds) {
        super(QUERY_NAME, tvSeasonIds);
    }

}
