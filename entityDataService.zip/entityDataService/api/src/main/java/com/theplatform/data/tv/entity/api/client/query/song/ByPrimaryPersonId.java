package com.theplatform.data.tv.entity.api.client.query.song;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * Song by primaryPersonId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByPrimaryPersonId extends OrQuery<Object> {

    public final static String QUERY_NAME = "primaryPersonId";

    /**
     * Construct a ByPrimaryPersonId query with the given value.
     *
     * @param primaryPersonId the numeric id for a person
     */
    public ByPrimaryPersonId(Long primaryPersonId) {
        this(Collections.singletonList(primaryPersonId));
    }


    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param primaryPersonId the CURN or Comcast URL
     */
    public ByPrimaryPersonId(URI primaryPersonId) {
        this(Collections.singletonList(primaryPersonId));
    }

    /**
     * Construct a ByPrimaryPersonId query with the given list of values.
     * The list must not be empty.
     *
     * @param primaryPersonIds the list of numeric, Comcast URN, or Comcast URL person id values
     */
    public ByPrimaryPersonId(List<?> primaryPersonIds) {
        super(QUERY_NAME, primaryPersonIds);
    }

}