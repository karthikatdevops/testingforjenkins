package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;


import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 7/5/12
 * Time: 5:08 PM
 * To change this template use File | Settings | File Templates.
 */

/**
 * ProgramMediaAssociation by case-insensitive providerId query.
 */
public class ByProvider extends OrQuery<String> {

    public final static String QUERY_NAME = "provider";

    /**
     * Construct a case-insensitive ByProvider query with the given value.
     *
     * @param provider the ProviderId
     */
    public ByProvider(String provider) {
        this(Collections.singletonList(provider));

        if (provider == null) {
            throw new IllegalArgumentException("provider cannot be null.");
        }
    }

    /**
     * Construct a case-insensitive ByProvider query with the given list of values.
     * The list must not be empty.
     *
     * @param providers the list of Providers
     */
    public ByProvider(List<String> providers) {
        super(QUERY_NAME, providers);
    }

}