package com.theplatform.data.tv.entity.api.client.query.songcollection;

import com.theplatform.contrib.data.api.client.query.AndOrQuery;
import com.theplatform.contrib.data.api.client.query.QueryType;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * SongCollection by songId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class BySongId extends AndOrQuery<Object> {
    private final static String QUERY_NAME = "songId";

    /**
     * Constructor.
     *
     * @param songId, single songId, default query type is OR query
     */
    public BySongId(Long songId) {
        this(Collections.singletonList(songId), QueryType.OR);

        if (songId == null) {
            throw new IllegalArgumentException("songId cannot be null.");
        }

    }

    /**
     * Constructor. Default query type is OR query
     *
     * @param songId, single songId as a CURN or Comcast URL
     */
    public BySongId(URI songId) {
        this(Collections.singletonList(songId), QueryType.OR);

        if (songId == null) {
            throw new IllegalArgumentException("songId cannot be null.");
        }

    }


    /**
     * Constructor.
     *
     * @param songId,   single songId
     * @param queryType the query type to use
     */
    public BySongId(Long songId, QueryType queryType) {
        this(Collections.singletonList(songId), queryType);

        if (songId == null) {
            throw new IllegalArgumentException("songId cannot be null.");
        }

    }

    /**
     * Constructor.
     *
     * @param songId,   single songId as a CURN or Comcast URL
     * @param queryType the query type to use
     */
    public BySongId(URI songId, QueryType queryType) {
        this(Collections.singletonList(songId), queryType);

        if (songId == null) {
            throw new IllegalArgumentException("songId cannot be null.");
        }

    }

    /**
     * Constructor
     *
     * @param parameters list of songIds as Long, CURN, or Comcast URL
     * @param queryType  the type of query
     */
    public BySongId(List<?> parameters, QueryType queryType) {
        super(QUERY_NAME, parameters, queryType);
    }


}
