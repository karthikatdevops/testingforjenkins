package com.theplatform.data.tv.entity.api.client.query.song;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * Song by albumId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByAlbumId extends OrQuery<Object> {

    public final static String QUERY_NAME = "albumId";

    /**
     * Construct a ByAlbumId query with the given value.
     *
     * @param albumReleaseId the numeric id for a release
     */
    public ByAlbumId(Long albumReleaseId) {
        this(Collections.singletonList(albumReleaseId));
    }

    /**
     * Construct a ByAlbumId query with the given value.
     *
     * @param albumReleaseId the CURN or Comcast URL id for a release
     */
    public ByAlbumId(URI albumReleaseId) {
        this(Collections.singletonList(albumReleaseId));
    }

    /**
     * Construct a ByAlbumId query with the given list of values.
     * The list must not be empty.
     *
     * @param albumReleaseIds the list of numeric, CURN, or Comcast URL releaseId values
     */
    public ByAlbumId(List<?> albumReleaseIds) {
        super(QUERY_NAME, albumReleaseIds);
    }

}
