package com.theplatform.data.tv.entity.api.client.query.albumrelease;

import com.theplatform.data.api.client.query.ValueQuery;

public class ByMainRelease extends ValueQuery<Boolean> {

    private final static String QUERY_NAME = "mainRelease";

    /**
     * Construct a ByMainRelease query with the given value.
     *
     * @param mainRelease the boolean value for AlbumRelease
     */
    public ByMainRelease(boolean mainRelease) {
        super(QUERY_NAME, mainRelease);
    }

}
