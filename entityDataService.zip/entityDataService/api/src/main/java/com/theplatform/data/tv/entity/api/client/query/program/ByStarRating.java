package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByStarRating extends OrQuery<Integer> {

    public final static String QUERY_NAME = "starRating";

    public ByStarRating(int starRating) {
        this(Collections.singletonList(starRating));
    }

    public ByStarRating(List<Integer> starRatings) {
        super(QUERY_NAME, starRatings);
    }

}
