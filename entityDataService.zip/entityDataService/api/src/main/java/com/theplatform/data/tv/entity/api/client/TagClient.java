package com.theplatform.data.tv.entity.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.data.api.client.HeaderStuffingDataServiceClient;
import com.theplatform.data.api.client.ClientConfiguration;
import com.theplatform.data.tv.entity.api.data.objects.Tag;

import java.net.UnknownHostException;

/**
 * Client for Tag objects.
 */
public class TagClient extends HeaderStuffingDataServiceClient<Tag> {

    /**
     * Constructor.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @throws UnknownHostException
     */
    public TagClient(String baseUrl, AuthorizationHeaderFactory authorization) throws UnknownHostException {
        super(baseUrl, authorization);
    }

    /**
     * Constructor that takes a ClientConfiguration.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @param configuration the client configuration
     * @throws UnknownHostException
     */
    public TagClient(String baseUrl, AuthorizationHeaderFactory authorization, ClientConfiguration configuration) throws UnknownHostException {
        super(baseUrl, authorization, configuration);
    }

    /**
     * Gets the Tag class.
     *
     * @return the Tag class
     */
    protected Class<Tag> getGenericClass() {
        return Tag.class;
    }

}
