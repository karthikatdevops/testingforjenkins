package com.theplatform.data.tv.entity.api.client.query.songcredit;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * SongCredit by personId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByPersonId extends OrQuery<Object> {

    public final static String QUERY_NAME = "personId";

    /**
     * Construct a ByPersonId query with the given value.
     *
     * @param personId the numeric id for a person
     */
    public ByPersonId(Long personId) {
        this(Collections.singletonList(personId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param personId the CURN or Comcast URL id
     */
    public ByPersonId(URI personId) {
        this(Collections.singletonList(personId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     * The list must not be empty.
     *
     * @param personIds the list of numeric personId values
     */
    public ByPersonId(List<?> personIds) {
        super(QUERY_NAME, personIds);
    }

}
