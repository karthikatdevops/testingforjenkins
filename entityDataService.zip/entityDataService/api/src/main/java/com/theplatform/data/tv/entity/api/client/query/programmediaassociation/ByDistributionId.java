package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * Credit by programId query.   Can use a Long, Comcast URN, or Comcast URL
 */
public class ByDistributionId extends OrQuery<Object> {

    public final static String QUERY_NAME = "distributionId";

    /**
     * Construct a ByDistributionId query with the given value.
     *
     * @param distributionId the numeric merlin id
     */
    public ByDistributionId(Long distributionId) {
        this(Collections.singletonList(distributionId));
    }


    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param distributionId the merlin CURN or Comcast URL id to find
     */
    public ByDistributionId(URI distributionId) {
        this(Collections.singletonList(distributionId));
    }

    /**
     * Construct a ByDistributionId query with the given list of values.
     * The list must not be empty.
     *
     * @param distributionIds the list of numeric or CURN or Comcast URL merlinId values
     */
    public ByDistributionId(List<?> distributionIds) {
        super(QUERY_NAME, distributionIds);
    }

}
