package com.theplatform.data.tv.entity.api.client.query.songcredit;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * SongCredit by songId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class BySongId extends OrQuery<Object> {

    public final static String QUERY_NAME = "songId";

    /**
     * Construct a BySongId query with the given value.
     *
     * @param songId the numeric id for a song
     */
    public BySongId(Long songId) {
        this(Collections.singletonList(songId));
    }

    /**
     * Construct a BySongId query with the given value.
     *
     * @param songId the CURN or Comcast URL id for a song
     */
    public BySongId(URI songId) {
        this(Collections.singletonList(songId));
    }

    /**
     * Construct a BySongId query with the given list of values.
     * The list must not be empty.
     *
     * @param songIds the list of numeric songId values
     */
    public BySongId(List<?> songIds) {
        super(QUERY_NAME, songIds);
    }

}
