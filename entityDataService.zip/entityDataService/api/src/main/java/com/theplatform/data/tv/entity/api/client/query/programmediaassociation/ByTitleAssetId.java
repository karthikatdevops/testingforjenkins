package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * ProgramMediaAssociation by case-insensitive titleAssetId query.
 */
public class ByTitleAssetId extends OrQuery<String> {

    public final static String QUERY_NAME = "titleAssetId";

    /**
     * Construct a case-insensitive ByTitleAssetId query with the given value.
     *
     * @param titleAssetId the titleAssetId
     */
    public ByTitleAssetId(String titleAssetId) {
        this(Collections.singletonList(titleAssetId));

        if (titleAssetId == null) {
            throw new IllegalArgumentException("type cannot be null.");
        }
    }

    /**
     * Construct a case-insensitive ByTitleAssetId query with the given list of values.
     * The list must not be empty.
     *
     * @param titleAssetIds the list of titleAssetIds
     */
    public ByTitleAssetId(List<String> titleAssetIds) {
        super(QUERY_NAME, titleAssetIds);
    }

}
