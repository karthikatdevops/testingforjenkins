package com.theplatform.data.tv.entity.api.client.query.albumrelease;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByProductForm extends OrQuery<String> {

    public final static String QUERY_NAME = "productForm";

    /**
     * Construct a ByProductForm query with the given value.
     *
     * @param productForm the name of a person
     */

    public ByProductForm(String productForm) {
        this(Collections.singletonList(productForm));

        if (productForm == null) {
            throw new IllegalArgumentException("productForm cannot be null.");
        }
    }

    /**
     * Construct a ByProductForm query with the given list of values.
     * The list must not be empty.
     *
     * @param productForms the list of product forms
     */
    public ByProductForm(List<String> productForms) {
        super(QUERY_NAME, productForms);
    }
}
