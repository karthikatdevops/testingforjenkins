package com.theplatform.data.tv.entity.api.client.query.relatedprogram;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByMmiSourceProgramGuid extends OrQuery<String> {

    public final static String QUERY_NAME = "mmiSourceProgramGuid";

    public ByMmiSourceProgramGuid(String sourceProgramGuid) {
        this(Collections.singletonList(sourceProgramGuid));
        if (sourceProgramGuid == null) {
            throw new IllegalArgumentException("sourceProgramGuid cannot be null.");
        }
    }

    public ByMmiSourceProgramGuid(List<String> titlePaids) {
        super(QUERY_NAME, titlePaids);
    }

}
