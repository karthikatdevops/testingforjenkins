package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;

import java.util.Collections;
import java.util.List;

public class ByProgramType extends OrQuery<ProgramType> {

    private final static String QUERY_NAME = "programType";

    /**
     * Construct a ByProgramType query with the given value.
     *
     * @param programType the programType
     */
    public ByProgramType(ProgramType programType) {
        this(Collections.singletonList(programType));

        if (programType == null) {
            throw new IllegalArgumentException("merlinResourceType cannot be null.");
        }
    }

    /**
     * Construct a ByProgramType query with the given list of values.
     * The list must not be empty.
     *
     * @param programTypes the list of programTypes
     */
    public ByProgramType(List<ProgramType> programTypes) {
        super(QUERY_NAME, programTypes);
    }


}
