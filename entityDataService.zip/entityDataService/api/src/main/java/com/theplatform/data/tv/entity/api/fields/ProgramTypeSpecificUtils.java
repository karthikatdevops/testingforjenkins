package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;

import java.util.Set;

public class ProgramTypeSpecificUtils {

    /**
     * Returns an unmodifiable set of ProgramFields that are specific to the
     * given Program.type. If there are no type-specific fields, a null set is returned.
     *
     * @param programType the Program.type in question.
     * @return an unmodifiable set of ProgramFields that are specific to the given Program.type or null if none exist.
     */
    public static Set<ProgramField> getTypeSpecificFields(ProgramType programType) {
        return ProgramField.getTypeSpecificFields(programType);
    }

    /**
     * Returns an unmodifiable set of ProgramFields that are specifically exclusive to the
     * given Program.type.
     *
     * @param programType the Program.type in question.
     * @return an unmodifiable set of ProgramFields that are specific to the given Program.type
     */
    public static Set<ProgramField> getTypeSpecificExclusiveFields(ProgramType programType) {
        return ProgramField.getTypeSpecificExclusiveFields(programType);
    }

    /**
     * Null out all type-specific fields that are inconsistent with the
     * program's type. For instance, if the program argument is a movie, then
     * all type-specific fields that are not scoped to movies will be nulled out
     * on the input argument.
     *
     * @param program the program
     * @throws IllegalArgumentException if the given program has a null type
     */
    public static void nullOutInconsistentTypeSpecificFields(Program program) throws IllegalArgumentException {
        ProgramField.nullOutInconsistentTypeSpecificFields(program);
    }

}
