package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * This query allows you to query by seriesId using a Long, Comcast URN, or Comcast URL
 */
public class BySeriesId extends OrQuery<Object> {

    public final static String QUERY_NAME = "seriesId";

    /**
     * Construct a query using a numeric id
     *
     * @param seriesId the numeric id to find
     */
    public BySeriesId(Long seriesId) {
        this(Collections.singletonList(seriesId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param seriesId the CURN or Comcast URL id to find
     */
    public BySeriesId(URI seriesId) {
        this(Collections.singletonList(seriesId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param seriesIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public BySeriesId(List<?> seriesIds) {
        super(QUERY_NAME, seriesIds);
    }

}
