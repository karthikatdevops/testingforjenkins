package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;

import java.util.Collections;
import java.util.List;

public class ByType extends OrQuery<ProgramType> {

    public static final String QUERY_NAME = "type";

    public ByType(ProgramType programType) {
        this(Collections.singletonList(programType));
    }

    public ByType(List<ProgramType> programTypes) {
        super(QUERY_NAME, programTypes);
    }
}
