package com.theplatform.data.tv.entity.api.client.query.sportsevent;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * SportsEvent ByProgramId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByProgramId extends OrQuery<Object> {

    public final static String QUERY_NAME = "programId";

    /**
     * Construct a query using a numeric id
     *
     * @param programId the numeric id to find
     */
    public ByProgramId(Long programId) {
        this(Collections.singletonList(programId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param programId the CURN or Comcast URL id to find
     */
    public ByProgramId(URI programId) {
        this(Collections.singletonList(programId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param programIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public ByProgramId(List<?> programIds) {
        super(QUERY_NAME, programIds);
    }

}
