package com.theplatform.data.tv.entity.api.client.query.awardassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * AwardAssociation by awardId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByAwardId extends OrQuery<Object> {

    public final static String QUERY_NAME = "awardId";

    /**
     * Construct a ByAwardId query with the given value.
     *
     * @param awardId the numeric id for a award
     */
    public ByAwardId(Long awardId) {
        this(Collections.singletonList(awardId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param awardId the CURN or Comcast URL id to find
     */
    public ByAwardId(URI awardId) {
        this(Collections.singletonList(awardId));
    }

    /**
     * Construct a ByAwardId query with the given list of values.
     * The list must not be empty.
     *
     * @param awardIds the list of numeric awardId values
     */
    public ByAwardId(List<?> awardIds) {
        super(QUERY_NAME, awardIds);
    }

}
