package com.theplatform.data.tv.entity.api.client.query.relatedsong;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * RelatedSong BySourceSongId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class BySourceSongId extends OrQuery<Object> {

    public final static String QUERY_NAME = "sourceSongId";

    /**
     * Construct a query using a numeric id
     *
     * @param sourceSongId the numeric id
     */
    public BySourceSongId(Long sourceSongId) {
        this(Collections.singletonList(sourceSongId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param sourceSongId the CURN or Comcast URL id
     */
    public BySourceSongId(URI sourceSongId) {
        this(Collections.singletonList(sourceSongId));
    }


    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param sourceSongIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public BySourceSongId(List<?> sourceSongIds) {
        super(QUERY_NAME, sourceSongIds);
    }

}
