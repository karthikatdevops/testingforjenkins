package com.theplatform.data.tv.entity.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.data.api.client.HeaderStuffingDataServiceClient;
import com.theplatform.data.api.client.ClientConfiguration;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;

import java.net.UnknownHostException;

public class SongCreditClient extends HeaderStuffingDataServiceClient<SongCredit> {

    /**
     * Constructor.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @throws UnknownHostException
     */
    public SongCreditClient(String baseUrl, AuthorizationHeaderFactory authorization) throws UnknownHostException {
        super(baseUrl, authorization);
    }

    /**
     * Constructor that takes a ClientConfiguration.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @param configuration the client configuration
     * @throws UnknownHostException
     */
    public SongCreditClient(String baseUrl, AuthorizationHeaderFactory authorization, ClientConfiguration configuration) throws UnknownHostException {
        super(baseUrl, authorization, configuration);
    }

    /**
     * Gets the SongCredit class.
     *
     * @return the SongCredit class
     */
    protected Class<SongCredit> getGenericClass() {
        return SongCredit.class;
    }

}
