package com.theplatform.data.tv.entity.api.client.query.albumcredit;

import com.theplatform.data.api.client.query.ValueQuery;

public class ByActive extends ValueQuery<Boolean> {

    private final static String QUERY_NAME = "active";

    /**
     * Construct a ByActive query with the given value.
     *
     * @param active the active boolean value
     */
    public ByActive(boolean active) {
        super(QUERY_NAME, active);
    }
}
