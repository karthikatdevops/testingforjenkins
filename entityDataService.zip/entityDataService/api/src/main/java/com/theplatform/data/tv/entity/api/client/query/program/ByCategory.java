package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByCategory extends OrQuery<String> {

    public final static String QUERY_NAME = "category";

    public ByCategory(String category) {
        this(Collections.singletonList(category));
    }

    public ByCategory(List<String> categories) {
        super(QUERY_NAME, categories);
    }

}
