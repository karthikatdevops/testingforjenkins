package com.theplatform.data.tv.entity.api.client.query.songcredit;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * SongCredit by type query.
 */
public class ByType extends OrQuery<String> {

    public final static String QUERY_NAME = "type";

    /**
     * Construct a ByType query with the given value.
     *
     * @param type the type for a credit
     */
    public ByType(String type) {
        this(Collections.singletonList(type));

        if (type == null) {
            throw new IllegalArgumentException("type cannot be null.");
        }
    }

    /**
     * Construct a ByType query with the given list of values.
     * The list must not be empty.
     *
     * @param types the list of credit types
     */
    public ByType(List<String> types) {
        super(QUERY_NAME, types);
    }

}
