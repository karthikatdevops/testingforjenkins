package com.theplatform.data.tv.entity.api.client.query.sportsteam;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;


/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 7/2/12
 * Time: 4:09 PM
 * To change this template use File | Settings | File Templates.
 */

public class ByNickName extends OrQuery<String> {

    public final static String QUERY_NAME = "nickName";

    public ByNickName(String nickName) {
        this(Collections.singletonList(nickName));

        if (nickName == null) {
            throw new IllegalArgumentException("nickName cannot be null.");
        }

    }

    public ByNickName(List<String> nickNames) {
        super(QUERY_NAME, nickNames);
    }

}