package com.theplatform.data.tv.entity.api.client.query.sportsteam;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * SportsTeam ByAbbreviation query. Query by ICC country code
 */
public class ByAbbreviation extends OrQuery<Object> {

    public final static String QUERY_NAME = "abbreviation";

    /**
     * Construct a query using a ICC country code
     *
     * @param countryICC the numeric id to find
     */
    public ByAbbreviation(String countryICC) {
        this(Collections.singletonList(countryICC));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be String - ICC country codeL)
     *
     * @param countryICC a list of String to logically OR. The list must not be empty or null.
     */
    public ByAbbreviation(List<?> countryICC) {
        super(QUERY_NAME, countryICC);
    }

}
