package com.theplatform.data.tv.entity.api.client;

import com.theplatform.authentication.token.api.AuthorizationHeaderFactory;
import com.theplatform.contrib.data.api.client.HeaderStuffingDataServiceClient;
import com.theplatform.data.api.client.ClientConfiguration;
import com.theplatform.data.tv.entity.api.data.objects.RelatedSong;

import java.net.UnknownHostException;

public class RelatedSongClient extends HeaderStuffingDataServiceClient<RelatedSong> {

    /**
     * Constructor.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @throws UnknownHostException
     */
    public RelatedSongClient(String baseUrl, AuthorizationHeaderFactory authorization) throws UnknownHostException {
        super(baseUrl, authorization);
    }

    /**
     * Constructor that takes a ClientConfiguration.
     *
     * @param baseUrl       the data service base URL
     * @param authorization the authorization header factory
     * @param configuration the client configuration
     * @throws UnknownHostException
     */
    public RelatedSongClient(String baseUrl, AuthorizationHeaderFactory authorization, ClientConfiguration configuration) throws UnknownHostException {
        super(baseUrl, authorization, configuration);
    }

    /**
     * Gets the RelatedSong class.
     *
     * @return the RelatedSong class
     */
    protected Class<RelatedSong> getGenericClass() {
        return RelatedSong.class;
    }

}
