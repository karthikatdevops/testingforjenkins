package com.theplatform.data.tv.entity.api.client.query.tagassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * User: mmattozzi
 * Date: 10/10/11
 * Time: 3:17 PM
 */
public class ByTagType extends OrQuery<String> {

    public final static String QUERY_NAME = "tagType";

    public ByTagType(String type) {
        this(Collections.singletonList(type));

        if (type == null) {
            throw new IllegalArgumentException("tag type cannot be null.");
        }
    }

    public ByTagType(List<String> types) {
        super(QUERY_NAME, types);
    }

}
