package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;
import com.theplatform.data.api.objects.type.DateOnly;

import java.util.Collections;
import java.util.List;

/**
 * Listing by originalAirDate query.
 */
public class ByOriginalAirDate extends OrQuery<DateOnly> {

    private final static String QUERY_NAME = "originalAirDate";

    public ByOriginalAirDate(DateOnly originalAirDate) {
        this(Collections.singletonList(originalAirDate));

        if (originalAirDate == null) {
            throw new IllegalArgumentException("originalAirDate cannot be null.");
        }
    }

    public ByOriginalAirDate(List<DateOnly> originalAirDates) {
        super(QUERY_NAME, originalAirDates);
    }

}