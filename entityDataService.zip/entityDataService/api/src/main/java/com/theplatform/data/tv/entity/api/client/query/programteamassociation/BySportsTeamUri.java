package com.theplatform.data.tv.entity.api.client.query.programteamassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * BySportsTeamUri
 * Created by: Seth Kelly
 * Date: 1/28/14
 */
public class BySportsTeamUri extends OrQuery<URI> {
    public final static String QUERY_NAME = "sportsTeamId";

    public BySportsTeamUri(URI sportsTeamId) {
        this(Collections.singletonList(sportsTeamId));
    }

    public BySportsTeamUri(List<URI> sportsTeamIds) {
        super(QUERY_NAME, sportsTeamIds);
    }
}
