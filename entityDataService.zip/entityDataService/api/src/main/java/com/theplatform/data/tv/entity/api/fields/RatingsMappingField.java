package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.data.api.NamespacedField;

/**
 * Created by lemuri200 on 6/1/15.
 */

/**
 * Enumeration of <code>RatingsMapping</code> fields.
 * <p>
 * The <code>toString()</code> method has been overridden to return
 * the namespace-qualified name for each field.
 * <p>
 * The <code>_all</code> value should be used to refer to all fields.
 * The <code>toString()</code> method for this value has been overridden
 * to return the <code>RatingsMapping</code> namespace followed by a single colon
 * character (:).
 */
public enum RatingsMappingField implements NamespacedField {
    sourceRatingSystem,
    targetRatingSystem,
    ratingsMap,
    merlinResourceType,
    _all {
        @Override
        public String getQualifiedName() {
            return NAMESPACE + ":";
        }

        @Override
        public String getLocalName() {
            return null;
        }
    };

    /**
     * The namespace for all <code>RatingsMapping</code> fields.
     */
    public static final String NAMESPACE = "http://xml.theplatform.com/data/tv/entity/RatingsMapping";

    /**
     * {@inheritDoc}
     */
    public String getNamespace() {
        return NAMESPACE;
    }

    /**
     * {@inheritDoc}
     */
    public String getQualifiedName() {
        return new StringBuilder(getNamespace()).append(':').append(getLocalName()).toString();
    }

    /**
     * {@inheritDoc}
     */
    public String getLocalName() {
        return name();
    }

    @Override
    public String toString() {
        return getQualifiedName();
    }

}


