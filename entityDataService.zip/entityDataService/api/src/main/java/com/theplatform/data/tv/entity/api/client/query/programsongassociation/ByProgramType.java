package com.theplatform.data.tv.entity.api.client.query.programsongassociation;

import com.theplatform.data.api.client.query.OrQuery;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;

import java.util.Collections;
import java.util.List;

public class ByProgramType extends OrQuery<ProgramType> {

    public static final String QUERY_NAME = "programType";

    public ByProgramType(ProgramType programType) {
        this(Collections.singletonList(programType));
        if (programType == null) {
            throw new IllegalArgumentException("programType cannot be null.");
        }
    }

    public ByProgramType(List<ProgramType> programTypes) {
        super(QUERY_NAME, programTypes);
    }
}
