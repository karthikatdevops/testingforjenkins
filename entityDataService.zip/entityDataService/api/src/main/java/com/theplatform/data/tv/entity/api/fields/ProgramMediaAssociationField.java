package com.theplatform.data.tv.entity.api.fields;

import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.data.api.NamespacedField;

public enum ProgramMediaAssociationField implements NamespacedField {
    programId,
    mediaGuid,
    distributionId,
    contentAssetId,
    titlePaid,
    titleAssetId,
    providerId,
    programType,
    merlinResourceType,
    provider,
    companyId,
    availableDate,
    expirationDate,
    mediaId {
        @Override
        public String getNamespace() {
            return MediaId.NAMESPACE;
        }
    },
    mezzanineMediaId {
        @Override
        public String getNamespace() {
            return MediaId.NAMESPACE;
        }
    },
    _all {
        @Override
        public String getQualifiedName() {
            return NAMESPACE + ":";
        }

        @Override
        public String getLocalName() {
            return null;
        }
    },
    categoryPaths,
    companies;

    /**
     * The namespace for all <code>ProgramMediaAssociation</code> fields.
     */
    public static final String NAMESPACE = "http://xml.theplatform.com/data/tv/entity/ProgramMediaAssociation";

    /**
     * {@inheritDoc}
     */
    public String getNamespace() {
        return NAMESPACE;
    }

    /**
     * {@inheritDoc}
     */
    public String getQualifiedName() {
        return new StringBuilder(getNamespace()).append(':').append(getLocalName()).toString();
    }

    /**
     * {@inheritDoc}
     */
    public String getLocalName() {
        return name();
    }

    @Override
    public String toString() {
        return getQualifiedName();
    }


}
