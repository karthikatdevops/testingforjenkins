package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * ProgramMediaAssociation by case-insensitive titlePaid query.
 */
public class ByTitlePaid extends OrQuery<String> {

    public final static String QUERY_NAME = "titlePaid";

    /**
     * Construct a case-insensitive ByTitlePaid query with the given value.
     *
     * @param titlePaid the titlePaid
     */
    public ByTitlePaid(String titlePaid) {
        this(Collections.singletonList(titlePaid));

        if (titlePaid == null) {
            throw new IllegalArgumentException("titlePaid cannot be null.");
        }
    }

    /**
     * Construct a case-insensitive ByTitlePaid query with the given list of values.
     * The list must not be empty.
     *
     * @param titlePaids the list of titlePaids
     */
    public ByTitlePaid(List<String> titlePaids) {
        super(QUERY_NAME, titlePaids);
    }

}
