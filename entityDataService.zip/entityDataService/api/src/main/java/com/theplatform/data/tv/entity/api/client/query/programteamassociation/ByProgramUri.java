package com.theplatform.data.tv.entity.api.client.query.programteamassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * ByProgramUri
 * Created by: Seth Kelly
 * Date: 1/28/14
 */
public class ByProgramUri extends OrQuery<URI> {

    public final static String QUERY_NAME = "programId";

    public ByProgramUri(URI programId) {
        this(Collections.singletonList(programId));
    }

    public ByProgramUri(List<URI> programIds) {
        super(QUERY_NAME, programIds);
    }
}
