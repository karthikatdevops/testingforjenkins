package com.theplatform.data.tv.entity.api.client.query.entitymessage;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/23/15
 */
public class ByEntityId extends OrQuery<Object> {

    public final static String QUERY_NAME = "entityId";

    /**
     * Construct a query using a numeric id
     *
     * @param entityId the numeric id to find
     */
    public ByEntityId(Long entityId) {
        this(Collections.singletonList(entityId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param entityId the CURN or Comcast URL id to find
     */
    public ByEntityId(URI entityId) {
        this(Collections.singletonList(entityId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param entityIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public ByEntityId(List<?> entityIds) {
        super(QUERY_NAME, entityIds);
    }

}
