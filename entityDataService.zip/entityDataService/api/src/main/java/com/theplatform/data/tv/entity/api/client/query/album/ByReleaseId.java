package com.theplatform.data.tv.entity.api.client.query.album;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * Album by releaseId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByReleaseId extends OrQuery<Object> {

    public final static String QUERY_NAME = "releaseId";

    /**
     * Construct a ByReleaseId query with the given value.
     *
     * @param releaseId the numeric id for a release
     */
    public ByReleaseId(Long releaseId) {
        this(Collections.singletonList(releaseId));
    }

    /**
     * Construct a ByReleaseId query with the given value.
     *
     * @param releaseId the CURN or Comcast URL id for a release
     */
    public ByReleaseId(URI releaseId) {
        this(Collections.singletonList(releaseId));
    }

    /**
     * Construct a ByReleaseId query with the given list of values.
     * The list must not be empty.
     *
     * @param releaseIds the list of numeric, CURN, or Comcast URL releaseId values
     */
    public ByReleaseId(List<?> releaseIds) {
        super(QUERY_NAME, releaseIds);
    }

}
