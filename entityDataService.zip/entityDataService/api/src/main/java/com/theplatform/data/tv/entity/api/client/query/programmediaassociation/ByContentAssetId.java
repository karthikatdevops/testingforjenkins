package com.theplatform.data.tv.entity.api.client.query.programmediaassociation;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * ProgramMediaAssociation by case-insensitive contentAssetId query.
 */
public class ByContentAssetId extends OrQuery<String> {

    public final static String QUERY_NAME = "contentAssetId";

    /**
     * Construct a case-insensitive ByContentAssetId query with the given value.
     *
     * @param contentAssetId the contentAssetId
     */
    public ByContentAssetId(String contentAssetId) {
        this(Collections.singletonList(contentAssetId));

        if (contentAssetId == null) {
            throw new IllegalArgumentException("contentAssetId cannot be null.");
        }
    }

    /**
     * Construct a case-insensitive ByContentAssetId query with the given list of values.
     * The list must not be empty.
     *
     * @param contentAssetIds the list of contentAssetIds
     */
    public ByContentAssetId(List<String> contentAssetIds) {
        super(QUERY_NAME, contentAssetIds);
    }

}
