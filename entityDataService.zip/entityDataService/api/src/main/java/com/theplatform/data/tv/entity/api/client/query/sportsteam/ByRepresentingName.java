package com.theplatform.data.tv.entity.api.client.query.sportsteam;


import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;


/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 7/2/12
 * Time: 4:09 PM
 * To change this template use File | Settings | File Templates.
 */

public class ByRepresentingName extends OrQuery<String> {

    public final static String QUERY_NAME = "representingName";

    public ByRepresentingName(String representingName) {
        this(Collections.singletonList(representingName));

        if (representingName == null) {
            throw new IllegalArgumentException("representingName cannot be null.");
        }
    }

    public ByRepresentingName(List<String> representingNames) {
        super(QUERY_NAME, representingNames);
    }

}