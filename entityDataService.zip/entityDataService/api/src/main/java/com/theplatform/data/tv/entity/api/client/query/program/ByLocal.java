package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.ValueQuery;

public class ByLocal extends ValueQuery<Boolean> {

    private final static String QUERY_NAME = "local";

    /**
     * Construct a ByLocal query with the given value.
     *
     * @param local the local boolean value
     */
    public ByLocal(boolean local) {
        super(QUERY_NAME, local);
    }
}
