package com.theplatform.data.tv.entity.api.client.query.sportsevent;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class BySportType extends OrQuery<String> {

    public final static String QUERY_NAME = "sportType";

    public BySportType(String sportType) {
        this(Collections.singletonList(sportType));
    }

    public BySportType(List<String> sportTypes) {
        super(QUERY_NAME, sportTypes);
    }

}
