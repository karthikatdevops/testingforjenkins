package com.theplatform.data.tv.entity.api.client.query.program;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByEpisodeTitle extends OrQuery<String> {

    public final static String QUERY_NAME = "episodeTitle";

    public ByEpisodeTitle(String episodeTitle) {
        this(Collections.singletonList(episodeTitle));

        if (episodeTitle == null) {
            throw new IllegalArgumentException("episodeTitle cannot be null.");
        }
    }

    public ByEpisodeTitle(List<String> episodeTitles) {
        super(QUERY_NAME, episodeTitles);
    }

}
