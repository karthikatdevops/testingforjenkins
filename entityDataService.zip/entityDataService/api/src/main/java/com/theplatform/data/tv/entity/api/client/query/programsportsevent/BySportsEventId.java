package com.theplatform.data.tv.entity.api.client.query.programsportsevent;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * ProgramSportsEvent BySportsEventId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class BySportsEventId extends OrQuery<Object> {

    public final static String QUERY_NAME = "sportsEventId";

    /**
     * Construct a query using a numeric id
     *
     * @param sportsEventId the numeric id to find
     */
    public BySportsEventId(Long sportsEventId) {
        this(Collections.singletonList(sportsEventId));
    }


    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param sportsEventId the CURN or Comcast URL id to find
     */
    public BySportsEventId(URI sportsEventId) {
        this(Collections.singletonList(sportsEventId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param sportsEventIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public BySportsEventId(List<?> sportsEventIds) {
        super(QUERY_NAME, sportsEventIds);
    }

}
