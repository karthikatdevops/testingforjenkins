package com.theplatform.data.tv.entity.api.client.query.relatedsong;

import com.theplatform.data.api.client.query.OrQuery;

import java.net.URI;
import java.util.Collections;
import java.util.List;

/**
 * RelatedSong ByTargetSongId query. Can use a Long, Comcast URN, or Comcast URL
 */
public class ByTargetSongId extends OrQuery<Object> {

    public final static String QUERY_NAME = "targetSongId";

    /**
     * Construct a query using a numeric id
     *
     * @param targetSongId the numeric id
     */
    public ByTargetSongId(Long targetSongId) {
        this(Collections.singletonList(targetSongId));
    }

    /**
     * Construct a query using a CURN or Comcast URL id
     *
     * @param targetSongId the CURN or Comcast URL id
     */
    public ByTargetSongId(URI targetSongId) {
        this(Collections.singletonList(targetSongId));
    }

    /**
     * Construct an OrQuery with the specified name and OR parameters. The parameters must be Longs and/or URI (CURN and/or Comcast URL)
     *
     * @param targetSongIds a list of Long and/or URI (CURNS or Comcast URL ids) to logically OR. The list must not be empty or null.
     */
    public ByTargetSongId(List<?> targetSongIds) {
        super(QUERY_NAME, targetSongIds);
    }

}
