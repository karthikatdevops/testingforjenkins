package com.theplatform.data.tv.entity.api.client.query.tag;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * @deprecated use com.theplatform.data.api.client.query.ByTitle
 */
@Deprecated
public class ByName extends OrQuery<String> {

    public final static String QUERY_NAME = "name";

    public ByName(String name) {
        this(Collections.singletonList(name));

        if (name == null) {
            throw new IllegalArgumentException("name cannot be null.");
        }
    }

    public ByName(List<String> names) {
        super(QUERY_NAME, names);
    }

}
