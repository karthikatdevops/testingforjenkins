package com.theplatform.data.tv.entity.api.client.query.sportsteam;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

public class ByGender extends OrQuery<String> {

    public final static String QUERY_NAME = "gender";

    public ByGender(String gender) {
        this(Collections.singletonList(gender));

    }

    public ByGender(List<String> genders) {
        super(QUERY_NAME, genders);
    }

}
