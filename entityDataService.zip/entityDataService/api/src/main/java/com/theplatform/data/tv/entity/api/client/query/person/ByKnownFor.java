package com.theplatform.data.tv.entity.api.client.query.person;

import com.theplatform.data.api.client.query.OrQuery;

import java.util.Collections;
import java.util.List;

/**
 * Person by knownFor query.
 */
public class ByKnownFor extends OrQuery<String> {

    public final static String QUERY_NAME = "knownFor";

    /**
     * Construct a ByKnownFor query with the given value.
     *
     * @param knownFor the knownFor value
     */
    public ByKnownFor(String knownFor) {
        this(Collections.singletonList(knownFor));

        if (knownFor == null) {
            throw new IllegalArgumentException("personType cannot be null.");
        }
    }

    /**
     * Construct a ByKnownFor query with the given list of values.
     * The list must not be empty.
     *
     * @param knownFors the list of knownFor values
     */
    public ByKnownFor(List<String> knownFors) {
        super(QUERY_NAME, knownFors);
    }

}
