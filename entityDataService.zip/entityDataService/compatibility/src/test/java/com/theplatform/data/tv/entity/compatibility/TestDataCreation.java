package com.theplatform.data.tv.entity.compatibility;

public class TestDataCreation extends com.theplatform.data.tv.test.backwardcompatibility.TestDataCreationParameterized {

}
