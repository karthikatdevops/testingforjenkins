package com.theplatform.data.tv.entity.compatibility;

public class DataRemoval extends com.theplatform.data.tv.test.backwardcompatibility.DataRemoval {

}
