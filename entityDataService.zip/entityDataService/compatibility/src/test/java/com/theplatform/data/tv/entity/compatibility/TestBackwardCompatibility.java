package com.theplatform.data.tv.entity.compatibility;

public class TestBackwardCompatibility extends
		com.theplatform.data.tv.test.backwardcompatibility.TestBackwardsCompatibilityParameterized {

}
