
-- create_dss_framework.sql 

create table SEQUENCE
(
        name   varchar2(32)     not null,
        count  number(19)       not null,
        constraint PK_SEQUENCE primary key (name)
)
/

insert into SEQUENCE (name, count) values ('default', 2)
/

create table URI_PATH
(
        id   number(19)         not null,
        path varchar2(4000)     not null,
        constraint PK_URI_PATH primary key (id),
        constraint UX_URI_PATH_PATH unique (path)
)
/

insert into URI_PATH values(0, 'urn:theplatform:auth:any')
/
insert into URI_PATH values(1, 'urn:theplatform:auth:alivecheck')
/

-- sequence will be used by Hibernate to generate NOTIFICATION primary key values
create sequence NOTIFICATION_SEQUENCE start with 1 increment by 1
/

create table NOTIFICATION
(
        id                      number(19)        not null,
        external_id             number(19)        default 0,
        owner_id                number(19)        not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(255)     not null,
        object_id               number(19)        not null,
        object_type             number(10)        not null,
        method                  number(19)        not null,
        updated                 date              not null,
        fields                  nclob             null,
        old_fields              nclob             null
)
PARTITION BY RANGE
  (id)
  INTERVAL ( 500000 )
   (
      PARTITION notificationt_83000000 VALUES LESS THAN (83000000)
) INITRANS 40
/
create index IX_NOTIFICATION_OBJECT_ID on NOTIFICATION (object_id)
/
create index IX_NOTIFICATION_EXTERNAL_ID on NOTIFICATION (external_id)
/
create index IX_NOTIFICATION_OWNER_ID on NOTIFICATION (owner_id)
/
CREATE UNIQUE INDEX PK_NOTIFICATION  ON NOTIFICATION (id)
   GLOBAL PARTITION BY RANGE (id)    (
    PARTITION NOTIFICATIONiid_83000000 VALUES LESS THAN (83000000),
    PARTITION NOTIFICATIONiid_83500000       VALUES LESS THAN (83500000),
    PARTITION NOTIFICATIONiid_84000000       VALUES LESS THAN (84000000),
    PARTITION NOTIFICATIONiid_84500000       VALUES LESS THAN (84500000),
    PARTITION NOTIFICATIONiid_85000000       VALUES LESS THAN (85000000),
    PARTITION NOTIFICATIONiid_maxvalue       values less than (maxvalue)
   ) INITRANS 40
/
ALTER TABLE NOTIFICATION ADD (  CONSTRAINT PK_NOTIFICATION  PRIMARY KEY  (ID)
  USING INDEX PK_NOTIFICATION  ENABLE VALIDATE)
/

create table NOTIFICATION_ALLOWED_ACCOUNTS
(
        notification_id      number(19)        not null,
        account_id           number(19)        default 0
)
PARTITION BY RANGE
  (NOTIFICATION_ID)
  INTERVAL ( 500000 )
   (
      PARTITION notif_allow_tnid_83000000 VALUES LESS THAN (83000000)
) INITRANS 40
/
create unique index PK_NOTIF_ALLOWED_ACCOUNTS on NOTIFICATION_ALLOWED_ACCOUNTS(NOTIFICATION_ID, ACCOUNT_ID)
   GLOBAL PARTITION BY RANGE (notification_id)  (
    PARTITION notifallow_inid_83000000 VALUES LESS THAN (83000000),
    PARTITION notifallow_inid_83500000       VALUES LESS THAN (83500000),
    PARTITION notifallow_inid_84000000       VALUES LESS THAN (84000000),
    PARTITION notifallow_inid_84500000       VALUES LESS THAN (84500000),
    PARTITION notifallow_inid_85000000       VALUES LESS THAN (85000000),
    PARTITION notifallow_inid_maxvalue       values less than (maxvalue)
   ) INITRANS 40
/
ALTER TABLE NOTIFICATION_ALLOWED_ACCOUNTS ADD (CONSTRAINT PK_NOTIF_ALLOWED_ACCOUNTS  PRIMARY KEY  (NOTIFICATION_ID, ACCOUNT_ID)
USING INDEX  PK_NOTIF_ALLOWED_ACCOUNTS ENABLE VALIDATE)
/
ALTER TABLE NOTIFICATION_ALLOWED_ACCOUNTS ADD (CONSTRAINT FK_NOTIF_ALLOWED_ACCOUNTS FOREIGN KEY (NOTIFICATION_ID)
  REFERENCES NOTIFICATION (ID) ON DELETE CASCADE )
/
CREATE INDEX IX_NOTIFICATION_ID_OBJECT_TYPE ON NOTIFICATION
(ID, OBJECT_TYPE)
/
create table logs
(
  msg_dt   date,
  process  varchar2(512 byte),
  message  varchar2(2000 byte))
/

  create or replace procedure writelogs (p_proc varchar2, p_message varchar2)is pragma autonomous_transaction;
begin insert into logs (msg_dt, process, message)values (sysdate, p_proc, p_message); commit;   end;
/

create table NOTIFICATION_LOCK ( dummy number(1) )
/

create or replace procedure p_rebuild_notif_extendididx
is
   v_done   boolean := false;
   v_m      number := 0;
   v_err    varchar2 (200);
begin
   for i
      in (select    'alter index '
                 || index_name
                 || ' rebuild  tablespace '
                 || tablespace_name
                 || ' compute statistics'
                    stmt
            from user_indexes
           where    table_name = 'NOTIFICATION'
                 and index_name like '%EXTERNAL_ID')
   loop
      begin
         execute immediate i.stmt;

         v_done := true;
      exception
         when others
         then
            v_err := substr (sqlerrm, 1, 200);
            writelogs ('rebuild_notif_extididx',
                      'FAILED:' || i.stmt || ':' || v_err);
            v_m := v_m + 1;
      end;
   end loop;
end;
/

create or replace procedure gather_schema_stats_wrapper (
   schema_name varchar2)
as
begin
   dbms_stats.gather_schema_stats (
      ownname            => schema_name,
      cascade            => true,
      estimate_percent   => null,
      degree             => 4,
      no_invalidate      => DBMS_STATS.AUTO_INVALIDATE,
      granularity        => 'AUTO',
      method_opt         => 'FOR ALL COLUMNS SIZE AUTO',
      options            => 'GATHER');
      commit;
      p_rebuild_notif_extendididx;
end;
/


-- create_Target_Entity_IDs.sql 

CREATE TABLE TARGET_ENTITY_IDS(
       id number(19) not null,
       entity_type varchar2(25) not null
)
/
create unique index PK_TARGET_ENTITY_IDS on TARGET_ENTITY_IDS (id, entity_type)
/
alter table TARGET_ENTITY_IDS add constraint PK_TARGET_ENTITY_IDS primary key (id, entity_type) using index PK_TARGET_ENTITY_IDS
/


-- create_Award.sql 

create table AWARD (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
	merlin_resource_type	number(1)  	  not null,
	title			varchar2(256),
	description		varchar2(4000),
	rank			number(10),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_AWARD primary key (id),
        constraint UX_AWARD_GUID unique (guid, owner_id),
	constraint cond_award_title_null check (title is not null or (title is null and merlin_resource_type in (1,3)))
)
/
create index IDX_AWARD_OWNER_ID on AWARD (owner_id)
/
create index IDX_AWARD_UPDATED on AWARD (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_AWARD_ID_VERSION on AWARD (id, version)
/
create index IDX_AWARD_TITLE on AWARD (title)
/


-- create_Institution.sql 

create table INSTITUTION (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
	merlin_resource_type	number(1)  	  not null,
	title			varchar2(256),
	description		varchar2(4000),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_INSTITUTION primary key (id),
        constraint UX_INSTITUTION_GUID unique (guid, owner_id),
	constraint cond_inst_title_null check (title is not null or merlin_resource_type in (1,3))
)
/
create index IDX_INSTITUTION_OWNER_ID on INSTITUTION (owner_id)
/
create index IDX_INSTITUTION_UPDATED on INSTITUTION (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_INSTITUTION_ID_VERSION on INSTITUTION (id, version)
/
create index IDX_INSTITUTION_TITLE on INSTITUTION (title)
/


-- create_Program.sql 

CREATE TABLE PROGRAM (
  id number(19) not null,
  guid varchar2(2000) not null,
  added date not null,
  updated date not null,
  owner_id                number(19)        not null,
  added_by_uri_path_id number(19) not null,
  added_by_uri_ref varchar2(4000) not null,
  updated_by_uri_path_id number(19) not null,
  updated_by_uri_ref varchar2(4000) not null,
  version number(19) not null,
  locked number(1) not null,
  merlin_resource_type number(1) not null,
  title varchar2(256),
  short_title varchar2(64),
  medium_title varchar2(128),
  long_title varchar2(256),
  sports_subtitle varchar2(256),
  program_year number(19) default null,
  short_synopsis varchar2(4000) default null,
  medium_synopsis varchar2(4000) default null,
  long_synopsis varchar2(4000) default null,
  runtime number(19) default null,
  type number(4) default null,
  language varchar2(256) default null,
  category varchar2(32) default null,
  first_run_company number(19) default null,
  adult number(1) default null,
  local number(1),
  is_primary number(1),
  list_by_title number(1),
  part_number number(19) default null,
  total_parts number(19) default null,
  sort_title varchar2(256) default null,
  movie_release_date number(8) default null,
  movie_star_rating number(10) default null,
  episode_series_id number(19) default null,
  episode_tvseason_id number(19) default null,
  episode_original_air_date number(19) default null,
  episode_tvseason_number number(19) default null,
  episode_tvseason_episode_num number(19) default null,
  episode_series_episode_number number(19) default null,
  episode_title varchar2(256) default null,
  production_episode_number varchar(40) default null,
  series_first_air_date number(8) default null,
  series_last_air_date number(8) default null,
  last_cascade_updated    date              default null,
  mmi_null_overrides      varchar2(4000),
  mmi_ed_object_id        number(19),
  mmi_ed_object_state     number(1),
  mmi_ed_object_mrt       number(1),
  mmi_content_paid varchar2(128),
  mmi_title_paid varchar2(128),
  constraint PK_PROGRAM primary key (id),
  constraint program_cond_local_null check (local is not null or merlin_resource_type in (1,3)),
  constraint program_cond_l_by_t_null check (list_by_title is not null or merlin_resource_type in (1,3)),
  constraint UX_PROGRAM_GUID unique (guid, owner_id)
  -- the below foreign key constraint is added in the create_post_foreign_keys.sql file since we can't create a fk to the non-existent tvseason table yet
  -- constraint FK_PROGRAM_TVSEASON foreign key (episode_tvseason_id) references TVSEASON (id)
)
/
create index IDX_PROGRAM_OWNER_ID on PROGRAM (owner_id)
/
create index IDX_PROGRAM_UPDATED on PROGRAM (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_PROGRAM_ID_VERSION on PROGRAM (id, version)
/
create index IDX_PROGRAM_TVSEASON_ID on PROGRAM (episode_tvseason_id)
/
create index IDX_PROGRAM_SERIES_ID on PROGRAM (episode_series_id)
/
-- the index below is to improve performance for Program?byType&MaxCredits
create index IDX_PROGRAM_TYPE_ID on PROGRAM (type, id)
/
-- speed up query by titlePrefix through test page (BD's request)
create index IDX_PROGRAM_TITLE_TYPE_UPD_ID on PROGRAM(lower(title), type, updated, id)
/
-- to speed up query by title and type
create index IDX_PROGRAM_TITLE_TYPE on PROGRAM(title, type)
/
alter table PROGRAM add constraint cond_prog_category_null check (category is not null or merlin_resource_type in (1,3))
/

-- BITTS-287: Slow queries optimization: round 2
create unique index UIX_PROGRAM_UPDT_ID on PROGRAM (updated desc, id desc) compute statistics
/
create unique index UIX_PROGRAM_UPDT_ID_MTYPE on PROGRAM (updated asc, id desc, merlin_resource_type) compute statistics
/
create unique index UIX_PRG_ADDED_ID_MTYPE_UREF on PROGRAM (added desc, id desc, merlin_resource_type, owner_id) compute statistics
/

create table PROGRAMCONTENTRATING (
	program_id number(19) not null,
	rating_scheme varchar2(32) not null,
	rating_rating varchar2(32) not null,
	rating_subratings varchar2(32),
	constraint FK_PROGRAM_RATING foreign key (program_id) references PROGRAM (id)
)
/
create index IDX_PROGRAMCONCEN_PRGID on PROGRAMCONTENTRATING (PROGRAM_ID)
/

alter table PROGRAMCONTENTRATING add constraint UX_PCRATING unique (program_id, rating_scheme, rating_rating)
/

--MERLIN-6894 synchronize TARGET_ENTITY_IDS
create or replace trigger PROGRAM_INSERT_TRIGGER after insert on PROGRAM for each row
begin
        INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
        VALUES(:new.id, 'Program');
end;
/

create or replace trigger PROGRAM_DELETE_TRIGGER before delete on PROGRAM  for each row
begin
        DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'Program';
end;
/


-- create_TvSeason.sql 

create table TVSEASON (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    series_id number(19) default NULL,  
    tvseason_number number(4) default NULL,
    start_year number(5) default NULL,  
    end_year number(5) default NULL,  
    description varchar2(4000) default NULL, 
    last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
    constraint PK_TVSEASON primary key (id),
    constraint UX_TVSEASON_GUID unique (guid, owner_id),
    constraint FK_TVSEASON_PROGRAM foreign key (series_id) references PROGRAM (id),
    constraint conditional_series_null check (series_id is not null or merlin_resource_type in (1,3))
)
/
create index IDX_TVSEASON_OWNER_ID on TVSEASON (owner_id)
/
create index IDX_TVSEASON_UPDATED on TVSEASON (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_TVSEASON_ID_VERSION on TVSEASON (id, version)
/
create index IDX_TVSEASON_SERIES_ID on TVSEASON (series_id)
/


-- create_RelatedProgram.sql 

create table RELATEDPROGRAM (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    explicit_mrt            number(1)         default null,
    source_program_id number(19) default NULL,  
    type varchar2(128) default NULL,
    target_program_id number(19) default NULL,  
    justification clob default NULL,
    rank number(10),
    score float,
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
	mmi_source_program_guid varchar2(2000),
	mmi_target_program_guid varchar2(2000),
    constraint PK_RELPROGRAM primary key (id),
    constraint UX_RELPROGRAM_GUID unique (guid, owner_id),
    constraint FK_RELPROGRAM_SOURCE_ID foreign key (source_program_id) references PROGRAM (id),
    constraint FK_RELPROGRAM_TARGET_ID foreign key (target_program_id) references PROGRAM (id)
)
/
create index IDX_RELPROGRAM_OWNER_ID on RELATEDPROGRAM (owner_id)
/
create index IDX_RELPROGRAM_UPDATED on RELATEDPROGRAM (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_RELPROGRAM_ID_VERSION on RELATEDPROGRAM (id, version)
/
create index IDX_RELPROGRAM_SOURCE_ID on RELATEDPROGRAM (source_program_id)
/
create index IDX_RELPROGRAM_TARGET_ID on RELATEDPROGRAM (target_program_id)
/
create index IDX_RELPROGRAM_SOURCE_GUID on RELATEDPROGRAM (mmi_source_program_guid)
/
create index IDX_RELPROGRAM_TARGET_GUID on RELATEDPROGRAM (mmi_target_program_guid)
/


-- create_Person.sql 

create table PERSON (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    name varchar2(1000) default NULL,  
    birth_name varchar2(1000) default NULL,  
    sort_name varchar2(1000) default NULL,  
    birth number(8) default NULL,  
    death number(8) default NULL,
    short_bio clob default NULL,  
    medium_bio clob default NULL,  
    long_bio clob default NULL, 
    birthplace varchar2(256),
    person_type varchar2(12),
    merlin_resource_type number(1) not null,
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
    constraint PK_PERSON primary key (id),
    constraint UX_PERSON_GUID unique (guid, owner_id),
    constraint cond_person_type check (person_type is not null or merlin_resource_type in (1,3))
)
/
create index IDX_PERSON_OWNER_ID on PERSON (owner_id)
/
create index IDX_PERSON_UPDATED on PERSON (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_PERSON_ID_VERSION on PERSON (id, version)
/

-- BITTS-286: Slow queries optimization: round 1
create unique index UIX_PERSON_UPDT_ID on PERSON (updated desc, id desc) compute statistics
/

create table PERSON_ALIAS (
    person_id  number(19) not null,
    alias varchar2(1000) not null,
    constraint FK_PERSONALIAS_PERSON foreign key (person_id) references PERSON (id)
)
/
create index IX_PERSON_ALIAS on PERSON_ALIAS (person_id)
/

create table PERSONKNOWNFOR (
	id number(19) not null,
	person_id number(19) not null,
	known_for varchar2(12) not null,
	constraint PK_PERSONKNOWNFOR primary key (id),
	constraint FK_PERSON_PSN_KNOWNFOR foreign key (person_id) references PERSON (id)
)
/
CREATE SEQUENCE PERSON_KNOWNFOR_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE
/
create index IX_PERSONKNOWNFOR_PERSON_ID on PERSONKNOWNFOR (person_id)
/

create or replace trigger PERSON_INSERT_TRIGGER after insert on PERSON for each row
begin
        INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
        VALUES(:new.id, 'Person');
end;
/

create or replace trigger PERSON_DELETE_TRIGGER before delete on PERSON for each row
begin
        DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'Person';
end;
/


-- create_Credit.sql 

create table CREDIT (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    type varchar2(1000) default NULL,  
    part_name varchar2(1000) default NULL,  
    rank number default NULL, 
    cameo number(1), 
    active number(1),
    program_id number(19),
    person_id number(19),
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
    constraint PK_CREDIT primary key (id),
    constraint UX_CREDIT_GUID unique (guid, owner_id),
    constraint FK_CREDIT_PERSON foreign key (person_id) references PERSON (id),
    constraint FK_CREDIT_PROGRAM foreign key (program_id) references PROGRAM (id),
    constraint credit_cond_active_null check (active is not null or merlin_resource_type in (1,3)),
    constraint credit_cond_cameo_null check (cameo is not null or merlin_resource_type in (1,3)),
    constraint conditional_program_null check (program_id is not null or merlin_resource_type in (1,3)),
    constraint conditional_person_null check (person_id is not null or merlin_resource_type in (1,3))
)
/
create index IDX_CREDIT_OWNER_ID on CREDIT (owner_id)
/
create index IDX_CREDIT_UPDATED on CREDIT (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_CREDIT_ID_VERSION on CREDIT (id, version)
/
create index IDX_CREDIT_PROGRAM_ID on CREDIT (program_id)
/
create index IDX_CREDIT_PERSON_ID on CREDIT (person_id)
/


-- create_Tag.sql 

create table TAG (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        merlin_resource_type    number(1)         not null,
        name                    varchar2(256),
        type                    varchar2(32),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_TAG primary key (id),
        constraint UX_TAG_GUID unique (guid, owner_id),
        constraint conditional_tag_name_null check (name is not null or merlin_resource_type in (1,3)),
        constraint conditional_tag_type_null check (type is not null or merlin_resource_type in (1,3))
)
/
create index IDX_TAG_OWNER_ID on TAG (owner_id)
/
create index IDX_TAG_UPDATED on TAG (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_TAG_ID_VERSION on TAG (id, version)
/
create index IDX_TAG_NAME on TAG (name)
/
create index IDX_TAG_TYPE on TAG (type)
/


-- create_TagAssociation.sql 

create table TAG_ASSOCIATION (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        merlin_resource_type    number(1)         not null,
        explicit_mrt            number(1)         default null,
        entity_id               number(19),
        entity_type             varchar2(25),
        tag_id                  number(19),
        is_primary              number(1),
        rank                    number(10),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
		mmi_entity_id			varchar2(4000),
		mmi_tag_id				varchar2(4000),
        constraint PK_TAG_ASSOCIATION primary key (id),
        constraint FK_TAG_ASSO_TAG_ID foreign key (tag_id) references TAG (id),
        constraint FK_TAG_ASSO_ENTITY_ID foreign key (entity_id, entity_type) references TARGET_ENTITY_IDS (id, entity_type),
        constraint UX_TAG_ASSOC_GUID unique (guid, owner_id),
        constraint cond_tag_entity_id_null check (entity_id is not null or merlin_resource_type in (1,3)),
        constraint cond_tag_entity_type_null check (entity_type is not null or merlin_resource_type in (1,3)),
        constraint cond_tag_primary_null check (is_primary is not null or merlin_resource_type in (1,3)),
        constraint cond_tag_tag_id_null check (tag_id is not null or merlin_resource_type in (1,3)) 
)
/
create index IDX_TAG_ASSOC_OWNER_ID on TAG_ASSOCIATION (owner_id)
/
create index IDX_TAG_ASSOC_UPDATED on TAG_ASSOCIATION (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_TAG_ASSOC_ID_VERSION on TAG_ASSOCIATION (id, version)
/
create index IDX_TAG_ASSOC_ENTITY_ID on TAG_ASSOCIATION (entity_id)
/
create index IDX_TAG_ASSOC_MMI_ENTITY_ID on TAG_ASSOCIATION (mmi_entity_id)
/
create index IDX_TAG_ASSOC_TAG_ID on TAG_ASSOCIATION (tag_id)
/
create index IDX_TAG_ASSOC_MMI_TAG_ID on TAG_ASSOCIATION (mmi_tag_id)
/
-- conditionally-required unique constraint (only applies for non-editorial entities)
create unique index UIDX_COND_TAG_ASSOC ON TAG_ASSOCIATION (
  case when merlin_resource_type not in (1,3) then entity_type else null end, 
  case when merlin_resource_type not in (1,3) then entity_id else null end, 
  case when merlin_resource_type not in (1,3) then tag_id else null end,
  case when merlin_resource_type not in (1,3) then owner_id else null end
)
/
CREATE INDEX IDX_TAG_ASSOC_MERLINRESTYPE ON TAG_ASSOCIATION (merlin_resource_type) compute statistics
/

-- BITTS-286: Slow queries optimization: round 1
create unique index UIX_TAGSSOC_UPDT_ID on TAG_ASSOCIATION (updated desc, id desc) compute statistics
/
-- BITTS-287: Slow queries optimization: round 2
create unique index UIX_TAGSSOC_UPDT_ID_MTYPE  on TAG_ASSOCIATION (updated asc, id desc, merlin_resource_type) compute statistics
/

create sequence TAGASSOC_ID_STORE_SEQ start with 1 increment by 1 nocache
/

-- BITT-5053
create index IDX_TG_AS_EID_TID_RES_TYP_OID on TAG_ASSOCIATION(ENTITY_ID,TAG_ID,MERLIN_RESOURCE_TYPE,OWNER_ID) 
/


-- create_MainImageTypeGroup.sql 


create table MAINIMAGETYPEGROUP (
        id                      number(19),
        guid                    varchar2(2000),
        added                   date,
        updated                 date,
        owner_id                number(19),
        added_by_uri_path_id    number(19),
        added_by_uri_ref        varchar2(4000),
        updated_by_uri_path_id  number(19),
        updated_by_uri_ref      varchar2(4000),
        version                 number(19),
        locked                  number(1),
        title                   varchar2(256),
        merlin_resource_type    number(1),
        last_cascade_updated    date default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_MAINIMAGETYPEGROUP primary key (id),
        constraint UX_MAINIMAGETYPEGROUP_GUID unique (guid, owner_id),
        constraint NN_MITG_ID check (id is not null),
        constraint NN_MITG_GUID check (guid is not null),
        constraint NN_MITG_ADDED check (added is not null),
        constraint NN_MITG_UPDATED check (updated is not null),
        constraint NN_MITG_OWNER_ID check (owner_id is not null),
        constraint NN_MITG_ADDURIID check (added_by_uri_path_id is not null),
        constraint NN_MITG_ADDURIRF check (added_by_uri_ref is not null),
        constraint NN_MITG_UPDURIID check (updated_by_uri_path_id is not null),
        constraint NN_MITG_UPDURIRF check (updated_by_uri_ref is not null),
        constraint NN_MITG_VERSION check (version is not null),
        constraint NN_MITG_LOCKED check (locked is not null),
        constraint NN_MITG_TITLE check (title is not null or merlin_resource_type in (1,3)),
        constraint NN_MITG_MRT check (merlin_resource_type is not null)
)
/

create index IDX_MAINIMGTYPEGRP_OWNER_ID on MAINIMAGETYPEGROUP (owner_id)
/
create index IDX_MAINIMGTYPEGRP_UPDATED on MAINIMAGETYPEGROUP (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_MAINIMGTYPEGRP_ID_VERSION on MAINIMAGETYPEGROUP (id, version)
/


-- create_MainImageType.sql 


create table MAINIMAGETYPE (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        title                   varchar2(256),
        entity_type             varchar2(20),
        entity_query            varchar2(2000)    default null,
	description             varchar2(4000)    default null,
        alias                   varchar2(256),
        merlin_resource_type    number(1)         not null,
        last_cascade_updated    date              default null,
	child_entity_query	varchar2(2000),
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_MAINIMAGETYPE primary key (id),
        constraint UX_MAINIMAGETYPE_GUID unique (guid, owner_id),
        constraint NN_MAINIMAGETYPE_TITLE check (title is not null or merlin_resource_type in (1,3)),
        constraint NN_MAINIMAGETYPE_ALIAS check (alias is not null or merlin_resource_type in (1,3)),
        constraint NN_MAINIMAGETYPE_ET check (entity_type is not null or merlin_resource_type in (1,3))
)
/

create index IDX_MAINIMAGETYPE_OWNER_ID on MAINIMAGETYPE (owner_id)
/
create index IDX_MAINIMAGETYPE_UPDATED on MAINIMAGETYPE (updated)
/
create index IDX_MAINIMAGETYPE_ID_VERSION on MAINIMAGETYPE (id, version)
/

create table IMAGE_CRITERIA (
        mainimagetype_id            number(19)        not null,
        require_exclusive           number(1)         not null,
        exclusive_by_type           number(1)         not null,
        allow_images_from_parent    number(1)         default null,
        allow_images_from_credits   number(1)         not null,
        media_query                 varchar2(2000)    default null,
        content_query               varchar2(2000)    default null,
        media_file_query               varchar2(2000)    default null,
        priority                    number(10)        not null,
        ia_relationship_query       varchar2(2000),
        constraint FK_IMAGE_CRITERIA_MIT_ID foreign key (mainimagetype_id) references MAINIMAGETYPE (id)
)
/

create table DEFAULT_IMAGE_CRITERIA (
        mainimagetype_id            number(19),
        service_guid			    varchar2(2000),
        account_guid			    varchar2(2000),
        media_guid				    varchar2(2000),
        media_file_query            varchar2(2000)    default null,
        entity_query                varchar2(2000)    default null,
        must_nothave_tag_ids        varchar2(2000)    default null,
        must_have_tag_ids           varchar2(2000)    default null,
        priority                    number(10)
)
/

alter table DEFAULT_IMAGE_CRITERIA add constraint NN_DIC_MITID check (mainimagetype_id IS NOT NULL)
/
alter table DEFAULT_IMAGE_CRITERIA add constraint NN_DIC_MEDS check (service_guid IS NOT NULL)
/
alter table DEFAULT_IMAGE_CRITERIA add constraint NN_DIC_MEDA check (account_guid IS NOT NULL)
/
alter table DEFAULT_IMAGE_CRITERIA add constraint NN_DIC_MEDM check (media_guid IS NOT NULL)
/
alter table DEFAULT_IMAGE_CRITERIA add constraint NN_DIC_PRIOR check (priority IS NOT NULL)
/
alter table DEFAULT_IMAGE_CRITERIA add constraint FK_DEF_IMG_CRITERIA_MIT_ID foreign key (mainimagetype_id) references MAINIMAGETYPE (id)
/

create table MAINIMAGETYPEGROUPID (
    id number(19),
    main_image_type_group_id number(19) not null,
    main_image_type_id number(19) not null,
    constraint PK_MAINIMAGETYPEGROUPID primary key (id),
    constraint FK_MAINIMAGETYPEGROUPID_MITGID foreign key (main_image_type_group_id) references MAINIMAGETYPEGROUP (id),
    constraint FK_MAINIMAGETYPEGROUPID_MITID foreign key (main_image_type_id) references MAINIMAGETYPE (id)
)
/
create index IDX_MNIMGTYPEGROUPID_MITGID on MAINIMAGETYPEGROUPID (main_image_type_group_id)
/
create index IDX_MNIMGTYPEGROUPID_ETTID on MAINIMAGETYPEGROUPID (main_image_type_id)
/
create sequence MAINIMAGETYPEGROUPID_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE
/



-- create_MainImageFile.sql 

create table MAIN_IMAGE_FILE (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        entity_id               number(19)        not null,
        entity_type             varchar2(25)      not null,
        main_image_type_id      number(19)        not null,
        image_id                number(19),
        image_file_id           number(19),
        service_guid			varchar2(2000),
        account_guid			varchar2(2000),
        media_guid				varchar2(2000),
        media_file_guid			varchar2(2000),
        url                     varchar2(4000)    not null,
        width                   number(10)        not null,
        height                  number(10)        not null,        
        is_3d                   number(1),
        image_size              number(10),
        format                  varchar2(32),
        requires_attribution    number(1),
        photographer            varchar2(256),
        distributor             varchar2(256),
	is_default		number(1),
        merlin_resource_type    number(1)         not null,
        explicit_mrt            number(1)         default null,
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_MAINIMGFILE primary key (id),
        constraint UX_MAINIMGFILE_GUID unique (guid, owner_id),
        constraint mif_cond_req_attr_null check (requires_attribution is not null or merlin_resource_type in (1,3)),
        constraint FK_MAINIMGFILE_MAINIMGTYPE foreign key (main_image_type_id) references MAINIMAGETYPE (id)
)
/
create index IDX_MAINIMGFILE_OWNER_ID on MAIN_IMAGE_FILE (owner_id)
/
create index IDX_MAINIMGFILE_UPDATED on MAIN_IMAGE_FILE (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_MAINIMGFILE_ID_VERSION on MAIN_IMAGE_FILE (id, version)
/
create index IDX_MAINIMGFILE_ENTITY_ID on MAIN_IMAGE_FILE (entity_id)
/
create index IDX_MAINIMGFILE_ENTITY_TYPE on MAIN_IMAGE_FILE (entity_type)
/
create index IDX_MAINIMGFILE_MAIN_IMG_TYPE on MAIN_IMAGE_FILE (main_image_type_id)
/
create unique index UX_MAINIMGFILE_EID_MITID on MAIN_IMAGE_FILE(entity_id, main_image_type_id, owner_id)
/

create sequence MAIN_IMAGE_ID_STORE_SEQ start with 1 increment by 1 nocache
/



-- create_ImageAssociation.sql 

create table IMAGE_ASSOCIATION (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        merlin_resource_type    number(1)         not null,
        explicit_mrt            number(1)         default null,
        entity_id               number(19),
        entity_type             varchar2(25),
        image_id                number(19),
        service_guid			varchar2(2000),
        account_guid			varchar2(2000),
        media_guid				varchar2(2000),
        priority_index          number(10),
        is_default              number(1),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
		mmi_entity_id			varchar2(4000),
        constraint PK_IMAGE_ASSOCIATION primary key (id),
        constraint UX_IMAGE_ASSOC_GUID unique (guid, owner_id),
        constraint cond_image_entity_id_null check (entity_id is not null or merlin_resource_type in (1,3)),
        constraint cond_image_entity_type_null check (entity_type is not null or merlin_resource_type in (1,3)),
        constraint cond_image_default_null check (is_default is not null or merlin_resource_type in (1,3)),
        constraint cond_image_media_guid_null check (media_guid is not null or merlin_resource_type in (1,3)),
        constraint cond_image_account_guid_null check (account_guid is not null or merlin_resource_type in (1,3)),
        constraint cond_image_service_guid_null check (service_guid is not null or merlin_resource_type in (1,3))
)
/
create index idx_image_asso_mrt_mmieid_uoid on image_association(merlin_resource_type,mmi_entity_id,id,updated,owner_id)
/
create index IDX_IMAGE_ASSOC_OWNER_ID on IMAGE_ASSOCIATION (owner_id)
/
create index IDX_IMAGE_ASSOC_UPDATED on IMAGE_ASSOCIATION (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_IMAGE_ASSOC_ID_VERSION on IMAGE_ASSOCIATION (id, version)
/
create index IDX_IMAGE_ASSOC_ENTITY_ID on IMAGE_ASSOCIATION (entity_id)
/
-- conditionally-required unique constraint (only applies for non-editorial entities) 
create unique index UIDX_COND_IMAGE_ASSOC ON IMAGE_ASSOCIATION (
  case when merlin_resource_type not in (1,3) then entity_type else null end, 
  case when merlin_resource_type not in (1,3) then entity_id else null end, 
  case when merlin_resource_type not in (1,3) then service_guid else null end,
  case when merlin_resource_type not in (1,3) then account_guid else null end,
  case when merlin_resource_type not in (1,3) then media_guid else null end,
  case when merlin_resource_type not in (1,3) then owner_id else null end
)
/

create table PREFER_MAINIMAGETYPE (
        id number(19) not null,
        image_association_id number(19) not null,
        prefer_image_type_id number (19) not null,
        constraint PK_PREFER_MIT_ID primary key (id),
        constraint FK_IMAGE_ASSO_ID foreign key (image_association_id) references IMAGE_ASSOCIATION (id),
	constraint FK_IA_IMAGE_TYPE_ID foreign key (prefer_image_type_id) references MAINIMAGETYPE (id)
)
/

create sequence IMAGE_ASSOC_ID_STORE_SEQ start with 1 increment by 1 nocache
/

CREATE SEQUENCE PREFER_MAINIMAGETYPE_SEQ
    MINVALUE 1
    START WITH 1
    INCREMENT BY 1
    NOCACHE
/

create or replace trigger IMAGEASSOC_DEFAULT_TRIGGER before insert or update of is_default on IMAGE_ASSOCIATION for each row 
declare
        PRAGMA AUTONOMOUS_TRANSACTION;
        d_count number := 0;
begin
	if :new.is_default = 1 and :new.merlin_resource_type not in (1,3) then
		if INSERTING then
			select count(*)
			into d_count
			from IMAGE_ASSOCIATION ia
			where
				ia.entity_id = :new.entity_id and
				ia.entity_type = :new.entity_type and
				ia.is_default = 1 and
				ia.merlin_resource_type not in (1,3);

			if d_count > 0 then
				raise_application_error(-20001, 'Only one default MainImage can be set to this entity');
			end if;
		else
			select count(*)
			into d_count
			from IMAGE_ASSOCIATION ia
			where
				ia.entity_id = :new.entity_id and
				ia.entity_type = :new.entity_type and
				ia.is_default = 1 and
				ia.id <> :new.id and
				ia.merlin_resource_type not in (1,3);

			if d_count > 0 then
				raise_application_error(-20001, 'Only one default MainImage can be set to this entity');
			end if;
		end if;
	
	end if;
end;
/


-- create_SportsTeam.sql 

create table SPORTSTEAM (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        parent_sports_team_id   number(19),
        representing_name       varchar2(255),
        nick_name               varchar2(50),
        league_id               number(19),
        city                    varchar2(255),
        state                   varchar2(50),
        country                 varchar2(255),
        conference              varchar2(255),
        division                varchar2(255),
        sport_type              varchar2(255),
        type                    varchar2(255),
        gender                  varchar2(50),
        coach                   varchar2(128),
        coach_person_id         number(19),
        venue                   varchar2(50),
        merlin_resource_type    number(1)         not null,
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_SPORTSTEAM primary key (id),
        constraint UX_SPORTSTEAM_GUID unique (guid, owner_id)
)
/
create index IDX_SPORTSTEAM_OWNER_ID on SPORTSTEAM (owner_id)
/
create index IDX_SPORTSTEAM_UPDATED on SPORTSTEAM (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_SPORTSTEAM_ID_VERSION on SPORTSTEAM (id, version)
/
create index IDX_SPORTSTEAM_SPORTTYPE on SPORTSTEAM (sport_type)
/


-- create_SportsEvent.sql 

create table SPORTSEVENT (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        title                   varchar2(256),
        locked                  number(1)         not null,
        league_id               number(19),
        city                    varchar2(255),
        state                   varchar2(50),
        country                 varchar2(255),
        conference              varchar2(255),
        division                varchar2(255),
        sport_type              varchar2(255),
        venue                   varchar2(50),
        merlin_resource_type    number(1)         not null,
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_SPORTSEVENT primary key (id),
        constraint UX_SPORTSEVENT_GUID unique (guid, owner_id)
)
/
create index IDX_SPORTSEVENT_OWNER_ID on SPORTSEVENT (owner_id)
/
create index IDX_SPORTSEVENT_UPDATED on SPORTSEVENT (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_SPORTSEVENT_ID_VERSION on SPORTSEVENT (id, version)
/
create index IDX_SPORTSEVENT_SPORTTYPE on SPORTSEVENT (sport_type)
/


-- create_ProgramTeamAssociation.sql 

create table PROGRAMTEAMASSOCIATION (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        title                   varchar2(256),
        locked                  number(1)         not null,
        program_id              number(19),
        sports_team_id          number(19),
        home_away               varchar2(10),
        competition             number(1),
        merlin_resource_type    number(1)         not null,
        explicit_mrt            number(1)         default null,
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_PROGRAMTEAMASSOCIATION primary key (id),
        constraint UX_PROGRAMTEAMASSOCIATION_GUID unique (guid, owner_id),
		constraint FK_PTA_PROGRAM foreign key (program_id) references PROGRAM(id),
        constraint FK_PTA_SPORTSTEAM foreign key (sports_team_id) references SPORTSTEAM(id),
		constraint cond_pta_program_id_null check (program_id is not null or merlin_resource_type in (1,3)),
        constraint cond_pta_sports_team_id_null check (sports_team_id is not null or merlin_resource_type in (1,3))
)
/
create index IDX_PTA_OWNER_ID on PROGRAMTEAMASSOCIATION (owner_id)
/
create index IDX_PTA_UPDATED on PROGRAMTEAMASSOCIATION (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_PTA_ID_VERSION on PROGRAMTEAMASSOCIATION (id, version)
/
create index idx_programteamassopid_mrt_oid on programteamassociation(program_id,merlin_resource_type,owner_id)
/


-- create_SportsLeague.sql 

create table SPORTSLEAGUE (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        title                   varchar2(255),
        locked                  number(1)         not null,
        description             varchar2(1000),
        merlin_resource_type    number(1)         not null,
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_SPORTSLEAGUE primary key (id),
        constraint UX_SPORTSLEAGUE_GUID unique (guid, owner_id)
)
/
create index IDX_SPORTSLEAGUE_OWNER_ID on SPORTSLEAGUE (owner_id)
/
create index IDX_SPORTSLEAGUE_UPDATED on SPORTSLEAGUE (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_SPORTSLEAGUE_ID_VERSION on SPORTSLEAGUE (id, version)
/


-- create_ProgramSportsEvent.sql 

create table PROGRAMSPORTSEVENT (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        program_id		        number(19),
        sports_event_id         number(19),
        merlin_resource_type    number(1)         not null,
        explicit_mrt            number(1)         default null,
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_PROGRAMSPORTSEVENT primary key (id),
        constraint UX_PROGRAMSPORTSEVENT_GUID unique (guid, owner_id),
        constraint FK_PSE_PROGRAM foreign key (program_id) references PROGRAM (id),
        constraint FK_PSE_SPORTSEVENT foreign key (sports_event_id) references SPORTSEVENT(id),        
        constraint cond_pse_program_id_null check (program_id is not null or merlin_resource_type in (1,3)),
        constraint cond_pse_sports_event_id_null check (sports_event_id is not null or merlin_resource_type in (1,3))
)
/
create index IDX_PSE_OWNER_ID on PROGRAMSPORTSEVENT (owner_id)
/
create index IDX_PSE_UPDATED on PROGRAMSPORTSEVENT (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_PSE_ID_VERSION on PROGRAMSPORTSEVENT (id, version)
/
create index IDX_PSE_PID on PROGRAMSPORTSEVENT (program_id)
/
create index IDX_PSE_SEID on PROGRAMSPORTSEVENT (sports_event_id)
/


-- create_ProgramRank.sql 

create table PROGRAMRANK (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    programrank_type varchar2(32),
    valid_as_of number(8),
    rank float, 
    program_id number(19),
    merlin_resource_type number(1) default 0,
    explicit_mrt            number(1)         default null,
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
    constraint PK_PROGRAMRANK primary key (id),
    constraint UX_PROGRAMRANK_GUID unique (guid, owner_id),
    constraint cond_progranktype_null check (programrank_type is not null or merlin_resource_type in (1,3)),
    constraint cond_rank_null check (rank is not null or merlin_resource_type in (1,3)),
    constraint cond_programid_null check (program_id is not null or merlin_resource_type in (1,3))
)
/
create index IDX_PROGRAMRANK_OWNER_ID on PROGRAMRANK (owner_id)
/
create index IDX_PROGRAMRANK_UPDATED on PROGRAMRANK (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_PROGRAMRANK_ID_VERSION on PROGRAMRANK (id, version)
/
create index IDX_PROGRAMRANK_PROGRAM_ID on PROGRAMRANK (program_id)
/
create index IDX_PROGRAMRANK_RANK on PROGRAMRANK (rank)
/
create sequence PROGRAM_RANK_ID_STORE_SEQ start with 1 increment by 1 nocache
/
create unique index UIDX_COND_PROGRANK_PID_TYPE ON PROGRAMRANK (
  case when merlin_resource_type not in (1,3) then programrank_type else null end, 
  case when merlin_resource_type not in (1,3) then program_id else null end,
  case when merlin_resource_type not in (1,3) then owner_id else null end
)
/


-- create_AwardAssociation.sql 

create table AWARDASSOCIATION (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
	merlin_resource_type	number(1)  	  not null,
	explicit_mrt            number(1)         default null,
	description		varchar2(4000),
	year			number(4),
	award_status		varchar2(32),
	award_type		varchar2(32),
	award_id		number(19),
	institution_id		number(19),
	program_id		number(19),
	person_id		number(19),
	award_show_id		number(19),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_AWARDASSOCIATION primary key (id),
        constraint UX_AWARDASSOCIATION_GUID unique (guid, owner_id),
        constraint FK_ASSOCIATION_AWARD_ID foreign key (award_id) references AWARD (id),
        constraint FK_AWARDASSO_INSTITUTION_ID foreign key (institution_id) references INSTITUTION (id),
        constraint FK_AWARDASSO_PROGRAM_ID foreign key (program_id) references PROGRAM (id),
        constraint FK_AWARDASSO_PERSON_ID foreign key (person_id) references PERSON (id),
        constraint conditional_year_null check (year is not null or (year is null and merlin_resource_type in (1,3))),
        constraint conditional_award_st_null check (award_status is not null or merlin_resource_type in (1,3)),
        constraint conditional_award_type_null check (award_type is not null or merlin_resource_type in (1,3)),
        constraint conditional_award_id_null check (award_id is not null or merlin_resource_type in (1,3)),
        constraint conditional_inst_id_null check (institution_id is not null or merlin_resource_type in (1,3))
)
/
create index IDX_AWARDASSOC_OWNER_ID on AWARDASSOCIATION (owner_id)
/
create index IDX_AWARDASSOCIATION_UPDATED on AWARDASSOCIATION (updated)
/
create index IX_AWARD_ASSN_PERSON_ID on AWARDASSOCIATION (person_id)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_AWARDASSO_ID_VERSION on AWARDASSOCIATION (id, version)
/
create index idx_awardass_pid_mrtoid_id on awardassociation(program_id,merlin_resource_type,owner_id,id)
/

create unique index UIDX_COND_AWARD_ASSOC ON AWARDASSOCIATION (
  case when merlin_resource_type not in (1,3) then institution_id else null end,
  case when merlin_resource_type not in (1,3) then year else null end,
  case when merlin_resource_type not in (1,3) then award_id else null end,
  case when merlin_resource_type not in (1,3) then program_id else null end,
  case when merlin_resource_type not in (1,3) then person_id else null end,
  case when merlin_resource_type not in (1,3) then owner_id else null end
)
/


-- create_ProgramMediaAssociation.sql 

create table PROGRAMMEDIAASSOCIATION (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        program_id              number(19),
        media_guid              varchar2(2000),
        distribution_id         number(19),
        content_asset_id        varchar2(256),
        title_paid              varchar2(128),
        title_asset_id          varchar2(128),
        provider_id             varchar2(128),
        program_resource_type	number(1),
        merlin_resource_type    number(1)         not null,
        explicit_mrt            number(1)         default null,
        program_type            number(4),
	provider		varchar2(128),
	company_id		number(19),
	available_date		date,
	expiration_date		date,
        last_cascade_updated    date              default null,
	service_guid 		varchar2(2000),
	account_guid 		varchar2(2000),
	mezzanine_media_guid	varchar2(2000)    default null,
	mezzanine_account_guid	varchar2(2000)    default null,
	mezzanine_service_guid  varchar2(2000)	  default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_PGRMMEDIAASSO primary key (id),
        constraint UX_PGRMMEDIAASSO_GUID unique (guid, owner_id),
	constraint cond_program_id_null check (program_id is not null or merlin_resource_type in (1,3)),
	constraint cond_media_guid_null check (media_guid is not null or merlin_resource_type in (1,3)),
	    constraint cond_account_guid_null check (account_guid is not null or merlin_resource_type in (1,3)),
        constraint cond_service_guid_null check (service_guid is not null or merlin_resource_type in (1,3))
)
/
create index IDX_PGRMMEDIAASSO_OWNER_ID on PROGRAMMEDIAASSOCIATION (owner_id)
/
create index IDX_PGRMMEDIAASSO_UPDATED on PROGRAMMEDIAASSOCIATION (updated)
/
create index IDX_PGRMMEDIAASSO_ID_VERSION on PROGRAMMEDIAASSOCIATION (id, version)
/
create index IDX_PGRMMEDIAASSO_PROVIDER on PROGRAMMEDIAASSOCIATION (provider)
/
create sequence PMA_ID_STORE_SEQ start with 1 increment by 1 nocache
/
---BITT ticket BITT-2190
create index IDX_PGRMMEDIAASSO_TP_MRT
 on PROGRAMMEDIAASSOCIATION ( lower(title_paid),merlin_resource_type) 
/
 
alter table PROGRAMMEDIAASSOCIATION add constraint FK_PMA_PROGRAM_ID foreign key (program_id) references PROGRAM (id)
/

--MERLIN-10327 Adjusting index to not include program_id
create unique index UIDX_COND_PMA_MEDIA_ID ON PROGRAMMEDIAASSOCIATION ( 
  	case when merlin_resource_type not in (1,3) then service_guid else null end,
  	case when merlin_resource_type not in (1,3) then account_guid else null end,
  	case when merlin_resource_type not in (1,3) then media_guid else null end, 
    case when merlin_resource_type not in (1,3) then owner_id else null end
)compute statistics
/

--US4256: Add categoryPaths field to PMA...
CREATE TABLE MEDIA_CATEGORY_PATHS (
  id            NUMBER(19),
  pma_id        NUMBER(19),
  category_path VARCHAR2(4000)
)
/

ALTER TABLE MEDIA_CATEGORY_PATHS ADD CONSTRAINT PK_MEDIA_CATEGORY_PATHS PRIMARY KEY (id)
/
ALTER TABLE MEDIA_CATEGORY_PATHS ADD CONSTRAINT FK_CAT_PATH_PMAID FOREIGN KEY (pma_id) REFERENCES programmediaassociation (id)
/
ALTER TABLE MEDIA_CATEGORY_PATHS ADD CONSTRAINT NN_CAT_PATH_PMA_ID CHECK (pma_id IS NOT null)
/
ALTER TABLE MEDIA_CATEGORY_PATHS ADD CONSTRAINT NN_CAT_PATH_CAT_PATH CHECK (category_path IS NOT null)
/
CREATE INDEX IX_CAT_PATH_PMA_ID ON MEDIA_CATEGORY_PATHS (pma_id)
/
CREATE INDEX IX_CAT_PATH_PATH ON MEDIA_CATEGORY_PATHS (category_path)
/
CREATE SEQUENCE CAT_PATH_ID_STORE_SEQ START WITH 1 INCREMENT BY 1 CACHE 10
/
create index idx_prgmmediaasso_pid_mrs on programmediaassociation(program_id, merlin_resource_type)
/



-- create_EntityCollection.sql 

create table ENTITYCOLLECTION (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    title varchar2(1000),  
    description clob default NULL,  
    type varchar2(1000),
    subtype varchar2(32),
    entity_id number(19),
    entity_type varchar2(25),
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
    constraint PK_ENTITYCOLLECTION primary key (id),
    constraint UX_ENTITYCOLLECTION_GUID unique (guid, owner_id),
    constraint cond_ec_title_null check (title is not null or merlin_resource_type in (1,3)),
    constraint cond_ec_type_null check (type is not null or merlin_resource_type in (1,3))
)
/
create index IDX_ENTITYCOLL_OWNER_ID on ENTITYCOLLECTION (owner_id)
/
create index IDX_ENTITYCOLLECTION_UPDATED on ENTITYCOLLECTION (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_ENTITYCOLLECTION_ID_VRSON on ENTITYCOLLECTION (id, version)
/

create table ENTITYCOLLECTIONID (
    id number(19),
    entity_collection_id number(19) not null,
    entity_id number(19) not null,
    entity_type varchar2(56) not null,
    constraint PK_ENTITYCOLLECTIONID primary key (id),
    constraint FK_ENTITYCOLLECTIONID_ECLID foreign key (entity_collection_id) references ENTITYCOLLECTION (id)
)
/
create index IDX_ENTITYCOLLECTIONID_COLID on ENTITYCOLLECTIONID (entity_collection_id)
/
create index IDX_ENTITYCOLLECTIONID_ETTID on ENTITYCOLLECTIONID (entity_id)
/
create sequence ENTITYCOLLECTION_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE
/

create table PRIMARYENTITY (
    id number(19),
    entity_collection_id number(19) not null,
    primary_type varchar2(64) not null,
    entity_id number(19) not null,
    entity_type varchar2(56) not null,
    constraint PK_PRIMARYENTITY primary key (id),
    constraint FK_PRIMARYENTITY_EC foreign key (entity_collection_id) references ENTITYCOLLECTION (id),
    constraint UX_PRMENTY_EC_ID unique (entity_collection_id, primary_type)
)
/
create index IDX_PRIMARYENTITY_COLID on PRIMARYENTITY (entity_collection_id)
/
create index IDX_PRIMARYENTITY_ETTID on PRIMARYENTITY (entity_id)
/
create sequence PRIMARY_ENTITY_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE
/

create table ENTITYCOLLECTION_MMIADDREM (
	id number(19),
	MMI_ENTITY_ID number(19),
	COLLECTION_FIELD varchar2(255),
	COLLECTION_OPERATION number(1),
	COLLECTION_VALUE varchar2(4000),
	constraint PK_EC_MMIADDREM primary key (id),
	constraint FK_EC_MMIADDREM_EC foreign key (MMI_ENTITY_ID) references ENTITYCOLLECTION (id)
)
/

create table ECMERGEFIELD (
    entity_collection_id number(19) not null,
    operation number(4) not null,
    field number(4) not null,
    key varchar2(64) default null,
    entity_id number(19) default null,
    constraint FK_ECMERGEFIELD_ECLID foreign key (entity_collection_id) references ENTITYCOLLECTION (id)
)
/
create index IDX_ECMERGEFIELD_COLID on ECMERGEFIELD (entity_collection_id)
/


-- create_Review.sql 

create table REVIEW (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        merlin_resource_type    number(1)         not null,
        last_cascade_updated    date              default null,
	program_id		number(19),
	provider		varchar2(256),
	summary			varchar2(1000),
	description		varchar2(4000),
	review			varchar2(4000),
	recommendation		varchar2(4000),
	star_rating		number(10),
	source			clob,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_REVIEW primary key (id),
        constraint UX_REVIEW_GUID unique (guid, owner_id),
        constraint cond_review_prgmid_null check (program_id is not null or merlin_resource_type in (1,3)),
        constraint cond_review_provider_null check (provider is not null or merlin_resource_type in (1,3))
)
/
create index IDX_REVIEW_OWNER_ID on REVIEW (owner_id)
/
create index IDX_REVIEW_UPDATED on REVIEW (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_REVIEW_ID_VERSION on REVIEW (id, version)
/
create index IDX_REVIEW_PGMID on REVIEW (program_id)
/
create index IDX_REVIEW_PROVD on REVIEW (provider)
/

create table REVIEW_RATING (
	review_id	number(19)		not null,
	rating_scheme  varchar2(32),
	rating_rating  varchar2(256),
	rating_subratings  varchar2(32),
	constraint FK_REVIEW_RATING foreign key (review_id) references REVIEW (id)
)
/



-- create_Album.sql 

create table ALBUM (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
	merlin_resource_type	number(1)  	  not null,
	title			varchar2(256),
	description		varchar2(4000),
	sort_title		varchar2(256),
	language		varchar2(32),
	country			varchar2(64),
	original_release_date	number(10),
	original_release_year	number(4),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_ALBUM primary key (id),
        constraint UX_ALBUM_GUID unique (guid, owner_id)
)
/
create index IDX_ALBUM_OWNER_ID on ALBUM (owner_id)
/
create index IDX_ALBUM_UPDATED on ALBUM (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_ALBUM_ID_VERSION on ALBUM (id, version)
/
create index IDX_ALBUM_TITLE on ALBUM (title)
/
create index IDX_ALBUM_SORTTITLE on ALBUM (sort_title)
/

--add triggers to keep ENTITY_TARGET_IDS in sync with ALBUM
create or replace trigger ALBUM_INSERT_TRIGGER after insert on ALBUM for each row
begin
        INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
        VALUES(:new.id, 'Album');
end;
/

create or replace trigger ALBUM_DELETE_TRIGGER before delete on ALBUM  for each row
begin
        DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'Album';
end;
/



-- create_Song.sql 

create table SONG (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
	merlin_resource_type	number(1)  	  not null,
	title			varchar2(512 char),
	description		varchar2(4000),
	sort_title		varchar2(512 char),
	isrc			varchar2(12 char),
	duration		number(10),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint UX_SONG_GUID unique (guid, owner_id),
        constraint PK_SONG primary key (id)
)
/
create index IDX_SONG_OWNER_ID on SONG (owner_id)
/
create index IDX_SONG_UPDATED on SONG (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_SONG_ID_VERSION on SONG (id, version)
/
create index IDX_SONG_TITLE on SONG (title)
/
create index IDX_SONG_SORTTITLE on SONG (sort_title)
/
--=BITT-3876
create index idx_song_id_mrt on song(id,merlin_resource_type)
/

--add triggers to keep ENTITY_TARGET_IDS in sync with SONG
create or replace trigger SONG_INSERT_TRIGGER after insert on SONG for each row
begin
        INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
        VALUES(:new.id, 'Song');
end;
/

create or replace trigger SONG_DELETE_TRIGGER before delete on SONG  for each row
begin
        DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'Song';
end;
/



-- create_AlbumRelease.sql 

create table ALBUMRELEASE (
    id                      number(19)        not null,
    guid                    varchar2(2000)    not null,
    added                   date              not null,
    updated                 date              not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id    number(19)        not null,
    added_by_uri_ref        varchar2(4000)    not null,
    updated_by_uri_path_id  number(19)        not null,
    updated_by_uri_ref      varchar2(4000)    not null,
    version                 number(19)        not null,
    locked                  number(1)         not null,
    merlin_resource_type    number(1)         not null,
    title                   varchar2(256),
    sort_title         	      varchar2(265),
    description             varchar2(4000),
    copyright_info          varchar2(4000),
    product_form            varchar2(32),
    sound_type              varchar2(32),
    domestic_import         varchar2(16),
    duration                number(10),
    release_date            number(10),
    release_year            number(4),
    distribution_date       number(10),
    discontinue_date        number(10),
    album_id                number(19),
    label_company_id        number(19),
    distributor_company_id  number(19),
    main_release            number(1),
    original_release_date   number(19),
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
    constraint PK_ABMRLS primary key (id),
    constraint FK_ABMRLS_ALBUM foreign key (album_id) references ALBUM (id),
    constraint UX_ABMRLS_GUID unique (guid, owner_id),
    constraint cond_albumrel_mainrel_null check (main_release is not null or merlin_resource_type in (1,3)),
    constraint cond_albumrel_albumid_null check (album_id is not null or merlin_resource_type in (1,3))
)
/
create index IDX_ABMRLS_OWNER_ID on ALBUMRELEASE (owner_id)
/
create index IDX_ABMRLS_UPDATED on ALBUMRELEASE (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_ABMRLS_ID_VERSION on ALBUMRELEASE (id, version)
/
create index IDX_ABMRLS_TITLE on ALBUMRELEASE (title)
/
create index IDX_ABMRLS_ALBUM on ALBUMRELEASE (album_id)
/

--contentRatings
create table ALBUMRELEASECONTENTRATING (
	album_release_id	number(19) not null,
	rating_scheme varchar2(32) not null,
	rating_rating varchar2(32) not null,
	rating_subratings varchar2(32),
	constraint FK_ABMRLS_RATING foreign key (album_release_id) references ALBUMRELEASE (id)
)
/
create index IDX_ABMRLS_RATING_ID on ALBUMRELEASECONTENTRATING (album_release_id)
/

--add triggers to keep ENTITY_TARGET_IDS in sync with ALBUMRELEASE
create or replace trigger ALBUMRELEASE_INSERT_TRIGGER after insert on ALBUMRELEASE for each row
begin
        INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
        VALUES(:new.id, 'AlbumRelease');
end;
/

create or replace trigger ALBUMRELEASE_DELETE_TRIGGER before delete on ALBUMRELEASE  for each row
begin
        DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'AlbumRelease';
end;
/



-- create_AlbumCredit.sql 

create table ALBUMCREDIT (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    type varchar2(1000) default NULL,  
    rank number default NULL, 
    active number(1),
    album_id number(19),
    person_id number(19),
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
    constraint PK_ALBUMCREDIT primary key (id),
    constraint UX_ALBUMCREDIT_GUID unique (guid, owner_id),
    constraint FK_ALBUMCREDIT_PERSON foreign key (person_id) references PERSON (id),
    constraint FK_ALBUMCREDIT_ALBUM_ID foreign key (album_id) references ALBUM (id),
    constraint cond_albumcredit_albumid_null check (album_id is not null or merlin_resource_type in (1,3)),
    constraint cond_albumcredit_person_null check (person_id is not null or merlin_resource_type in (1,3)),
    constraint cond_albumcredit_active_null check (active is not null or merlin_resource_type in (1,3))
)
/
create index IDX_ALBUMCREDIT_OWNER_ID on ALBUMCREDIT (owner_id)
/
create index IDX_ALBUMCREDIT_UPDATED on ALBUMCREDIT (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_ALBUMCREDIT_ID_VERSION on ALBUMCREDIT (id, version)
/
create index IDX_ALBUMCREDIT_ALBUM_ID on ALBUMCREDIT (album_id)
/
create index IDX_ALBUMCREDIT_PERSON_ID on ALBUMCREDIT (person_id)
/
create index IDX_ALBUMCREDIT_ALL on ALBUMCREDIT (album_id, person_id, active, rank)
/



-- create_SongCredit.sql 

create table SONGCREDIT (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    type varchar2(1000) default NULL,  
    rank number default NULL, 
    active number(1),
    song_id number(19),
    person_id number(19),
    last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
    constraint PK_SONGCREDIT primary key (id),
    constraint UX_SONGCREDIT_GUID unique (guid, owner_id),
    constraint FK_SONGCREDIT_PERSON foreign key (person_id) references PERSON (id),
    constraint FK_SONGCREDIT_SONG_ID foreign key (song_id) references SONG (id),
    constraint cond_songcredit_songid_null check (song_id is not null or merlin_resource_type in (1,3)),
    constraint cond_songcredit_person_null check (person_id is not null or merlin_resource_type in (1,3)),
    constraint cond_songcredit_active_null check (active is not null or merlin_resource_type in (1,3))
)
/
create index IDX_SONGCREDIT_OWNER_ID on SONGCREDIT (owner_id)
/
create index IDX_SONGCREDIT_UPDATED on SONGCREDIT (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_SONGCREDIT_ID_VERSION on SONGCREDIT (id, version)
/
create index IDX_SONGCREDIT_SONG_ID on SONGCREDIT (song_id)
/
create index IDX_SONGCREDIT_PERSON_ID on SONGCREDIT (person_id)
/
create index IDX_SONGCREDIT_ALL on SONGCREDIT (song_id, person_id, active, rank)
/


-- create_AlbumReleaseSongAssociation.sql 

create table ALBUMRELEASESONG (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
	merlin_resource_type	number(1)  	  not null,
	album_release_id	number(19),
	song_id			number(19),
	track_number		number(10),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_ALBUMRELEASESONG primary key (id),
        constraint FK_ABMRLSSONG_ARLS foreign key (album_release_id) references ALBUMRELEASE (id),
        constraint FK_ABMRLSSONG_SONG foreign key (song_id) references SONG (id),
        constraint UX_ALBUMRELEASESONG_GUID unique (guid, owner_id)
)
/
create index IDX_ABMRLSSONG_OWNER_ID on ALBUMRELEASESONG (owner_id)
/
create index IDX_ABMRLSSONG_UPDATED on ALBUMRELEASESONG (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_ABMRLSSONG_ID_VERSION on ALBUMRELEASESONG (id, version)
/
create index IDX_ABMRLSSONG_AR on ALBUMRELEASESONG (album_release_id)
/
create index IDX_ABMRLSSONG_SONG on ALBUMRELEASESONG (song_id)
/


-- create_RelatedPerson.sql 

create table RELATEDPERSON (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    source_person_id number(19),  
    target_person_id number(19),  
    start_date date,
    end_date date,
    rank number(10),
    related_person_type varchar2(128),
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
    constraint PK_RELPERSON primary key (id),
    constraint UX_RELPERSON_GUID unique (guid, owner_id),
    constraint FK_RELPERSON_SOURCE_ID foreign key (source_person_id) references PERSON (id),
    constraint FK_RELPERSON_TARGET_ID foreign key (target_person_id) references PERSON (id),
    constraint cond_relperson_spid_null check (source_person_id is not null or merlin_resource_type in (1,3)),
    constraint cond_relperson_tpid_null check (target_person_id is not null or merlin_resource_type in (1,3)),
    constraint cond_relperson_type_null check (related_person_type is not null or merlin_resource_type in (1,3))
)
/
create index IDX_RELPERSON_OWNER_ID on RELATEDPERSON (owner_id)
/
create index IDX_RELPERSON_UPDATED on RELATEDPERSON (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_RELPERSON_ID_VERSION on RELATEDPERSON (id, version)
/
create index IDX_RELPERSON_SOURCE_ID on RELATEDPERSON (source_person_id)
/
create index IDX_RELPERSON_TARGET_ID on RELATEDPERSON (target_person_id)
/
create index IDX_RELPERSON_STARTDATE on RELATEDPERSON (start_date)
/
create index IDX_RELPERSON_ENDDATE on RELATEDPERSON (end_date)
/
create index IDX_RELPERSON_TYPE on RELATEDPERSON (related_person_type)
/


-- create_RelatedAlbum.sql 

create table RELATEDALBUM (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    source_album_id number(19),  
    target_album_id number(19),  
    rank number(10),
    related_album_type varchar2(128),
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
    constraint PK_RELALBUM primary key (id),
    constraint UX_RELALBUM_GUID unique (guid, owner_id),
    constraint FK_RELALBUM_SOURCE_ID foreign key (source_album_id) references ALBUM (id),
    constraint FK_RELALBUM_TARGET_ID foreign key (target_album_id) references ALBUM (id),
    constraint cond_relalbum_spid_null check (source_album_id is not null or merlin_resource_type in (1,3)),
    constraint cond_relalbum_tpid_null check (target_album_id is not null or merlin_resource_type in (1,3)),
    constraint cond_relalbum_type_null check (related_album_type is not null or merlin_resource_type in (1,3))
)
/
create index IDX_RELALBUM_OWNER_ID on RELATEDALBUM (owner_id)
/
create index IDX_RELALBUM_UPDATED on RELATEDALBUM (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_RELALBUM_ID_VERSION on RELATEDALBUM (id, version)
/
create index IDX_RELALBUM_SOURCE_ID on RELATEDALBUM (source_album_id)
/
create index IDX_RELALBUM_TARGET_ID on RELATEDALBUM (target_album_id)
/
create index IDX_RELALBUM_TYPE on RELATEDALBUM (related_album_type)
/


-- create_RelatedSong.sql 

create table RELATEDSONG (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    source_song_id number(19),  
    target_song_id number(19),  
    rank number(10),
    related_song_type varchar2(128),
    last_cascade_updated    date              default null,
	mmi_null_overrides      varchar2(4000),
	mmi_ed_object_id        number(19),
	mmi_ed_object_state     number(1),
	mmi_ed_object_mrt       number(1),
    constraint PK_RELSONG primary key (id),
    constraint UX_RELSONG_GUID unique (guid, owner_id),
    constraint FK_RELSONG_SOURCE_ID foreign key (source_song_id) references SONG (id),
    constraint FK_RELSONG_TARGET_ID foreign key (target_song_id) references SONG (id),
    constraint cond_relsong_spid_null check (source_song_id is not null or merlin_resource_type in (1,3)),
    constraint cond_relsong_tpid_null check (target_song_id is not null or merlin_resource_type in (1,3)),
    constraint cond_relsong_type_null check (related_song_type is not null or merlin_resource_type in (1,3))
)
/
create index IDX_RELSONG_OWNER_ID on RELATEDSONG (owner_id)
/
create index IDX_RELSONG_UPDATED on RELATEDSONG (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_RELSONG_ID_VERSION on RELATEDSONG (id, version)
/
create index IDX_RELSONG_SOURCE_ID on RELATEDSONG (source_song_id)
/
create index IDX_RELSONG_TARGET_ID on RELATEDSONG (target_song_id)
/
create index IDX_RELSONG_TYPE on RELATEDSONG (related_song_type)
/


-- create_ProgramSongAssociation.sql 

create table PROGRAMSONGASSOCIATION (
        id                      number(19)        not null,
        guid                    varchar2(2000)    not null,
        added                   date              not null,
        updated                 date              not null,
        owner_id                number(19)        not null,
        added_by_uri_path_id    number(19)        not null,
        added_by_uri_ref        varchar2(4000)    not null,
        updated_by_uri_path_id  number(19)        not null,
        updated_by_uri_ref      varchar2(4000)    not null,
        version                 number(19)        not null,
        locked                  number(1)         not null,
        merlin_resource_type    number(1)         not null,
        program_id              number(19),
        song_id			number(19),
        prgm_song_asso_type	varchar2(20),
        last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
        constraint PK_PGRMSONGASSO primary key (id),
        constraint FK_PGRMSONGASSO_PRGM foreign key (program_id) references PROGRAM (id),
        constraint FK_PGRMSONGASSO_SONG foreign key (song_id) references SONG (id),
		constraint NN_PGRMSONGASSO_PROGRAM check (program_id is not null or merlin_resource_type in (1,3)),
    	constraint NN_PGRMSONGASSO_SONG check (song_id is not null or merlin_resource_type in (1,3)),
    	constraint NN_PGRMSONGASSO_ID_TYPE check (prgm_song_asso_type is not null or merlin_resource_type in (1,3)),
        constraint UX_PGRMSONGASSO_GUID unique (guid, owner_id)
)
/
create index IDX_PGRMSONGASSO_OWNER_ID on PROGRAMSONGASSOCIATION (owner_id)
/
create index IDX_PGRMSONGASSO_UPDATED on PROGRAMSONGASSOCIATION (updated)
/
create index IDX_PGRMSONGASSO_ID_VERSION on PROGRAMSONGASSOCIATION (id, version)
/
create index IDX_PGRMSONGASSO_PRGM on PROGRAMSONGASSOCIATION (program_id)
/
create index IDX_PGRMSONGASSO_SONG on PROGRAMSONGASSOCIATION (song_id)
/


-- create_SongCollection.sql 

create table SONGCOLLECTION (
    id number(19) not null,
    guid varchar2(2000) not null,
    added date not null,
    updated date not null,
    owner_id                number(19)        not null,
    added_by_uri_path_id number(19) not null,
    added_by_uri_ref varchar2(4000) not null,
    updated_by_uri_path_id number(19) not null,
    updated_by_uri_ref varchar2(4000) not null,
    version number(19) not null,
    locked number(1) not null,
    merlin_resource_type number(1) not null,
    title varchar2(1000),  
    description clob default NULL,  
    song_collection_type varchar2(1000),
    subtype varchar2(32),
    primary_song_id number(19),
    last_cascade_updated    date              default null,
		mmi_null_overrides      varchar2(4000),
		mmi_ed_object_id        number(19),
		mmi_ed_object_state     number(1),
		mmi_ed_object_mrt       number(1),
    constraint PK_SONGCOLLECTION primary key (id),
    constraint UX_SONGCOLLECTION_GUID unique (guid, owner_id),
    constraint cond_sc_title_null check (title is not null or merlin_resource_type in (1,3)),
    constraint cond_sc_type_null check (song_collection_type is not null or merlin_resource_type in (1,3))
)
/
create index IDX_SONGCOLL_OWNER_ID on SONGCOLLECTION (owner_id)
/
create index IDX_SONGCOLLECTION_UPDATED on SONGCOLLECTION (updated)
/
-- the below index is because Oracle was resorting to full table scans with all version-related inserts/updates
create index IDX_SONGCOLLECTION_ID_VRSON on SONGCOLLECTION (id, version)
/
create index IDX_SONGCOLLECTION_TITLE on SONGCOLLECTION (title)
/
create index IDX_SONGCOLLECTION_TYPE on SONGCOLLECTION (song_collection_type)
/

create table SONGCOLLECTIONID (
    id number(19),
    song_collection_id number(19) not null,
    song_id number(19) not null,
    constraint PK_SONGCOLLECTIONID primary key (id),
    constraint FK_SONGCOLLECTIONID_SONGID foreign key (song_id) references SONG (id),
    constraint FK_SONGCOLLECTIONID_ECLID foreign key (song_collection_id) references SONGCOLLECTION (id)
)
/
create index IDX_SONGCOLLECTIONID_COLID on SONGCOLLECTIONID (song_collection_id)
/
create index IDX_SONGCOLLECTIONID_ETTID on SONGCOLLECTIONID (song_id)
/
create sequence SONGCOLLECTION_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 NOCACHE
/



-- create_post_foreign_keys.sql 

-- do to circular foreign key references (table A has FK to table B which has a FK to table A),
-- not all foreign keys can be included in table create statements. In these cases, we should add the
-- foreign key definition in this file and also include a commented out statement in the table create
-- with a note. See create_Program.sql for an example of this.

alter table PROGRAM add constraint FK_PROGRAM_TVSEASON foreign key (episode_tvseason_id) references TVSEASON (id)
/


-- create_SocialMediaAssociation.sql 

create table SOCIALMEDIAASSOCIATION (
   id                      number(19),
   guid                    varchar2(2000),
   type                    varchar2(256),
   identifier              varchar2(1000),
   entity_id               number(19) default null,
   entity_type			   varchar2(25) default null,
   primary                 number(1) default null,
   owner_id                number(19),
   added                   date,
   updated                 date,
   added_by_uri_path_id    number(19),
   added_by_uri_ref        varchar2(4000),
   updated_by_uri_path_id  number(19),
   updated_by_uri_ref      varchar2(4000),
   version                 number(19),
   locked                  number(1) default 0,
   merlin_resource_type	   number(1),
   explicit_mrt            number(1),
   last_cascade_updated    date default null,
   mmi_null_overrides      varchar2(4000) default null,
   mmi_ed_object_id        number(19) default null,
   mmi_ed_object_state     number(1) default null,
   mmi_ed_object_mrt       number(1) default null,
   mmi_entity_id		   varchar2(4000) default null,
   mmi_tag_id			   varchar2(4000) default null
)
/

alter table SOCIALMEDIAASSOCIATION add constraint PK_SOCIALMEDIAASSOCIATION primary key (id)
/

alter table SOCIALMEDIAASSOCIATION add constraint UX_SMA_GUID unique (guid, owner_id)
/

-- All type/identifier/entity_id combos need to be unique (unless we are editorial)
create unique index UIDX_COND_SMA ON SOCIALMEDIAASSOCIATION (
  case when merlin_resource_type not in (1,3) then type else null end,
  case when merlin_resource_type not in (1,3) then identifier else null end,
  case when merlin_resource_type not in (1,3) then entity_id else null end
)
/

-- At most one SMA can be marked as primary per type/entity_id combination (unless we are editorial)
create unique index UIDX_COND_SMA_PRIMARY ON SOCIALMEDIAASSOCIATION (
    case when merlin_resource_type not in (1,3) and primary = 1 then primary else null end,
    case when merlin_resource_type not in (1,3) and primary = 1 then type else null end,
    case when merlin_resource_type not in (1,3) and primary = 1 then entity_id else null end
)
/

alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_OWNERID check (owner_id is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_ADDED check (added is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_UPDATED check (updated is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_ADDURIID check (added_by_uri_path_id is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_ADDURIRF check (added_by_uri_ref is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_UPDURIID check (updated_by_uri_path_id is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_UPDURIRF check (updated_by_uri_ref is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_VERSION check (version is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_LOCKED check (locked is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_GUID check (guid is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_MRT check (merlin_resource_type is not null)
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_TYPE check (type is not null or merlin_resource_type in (1,3))
/
alter table SOCIALMEDIAASSOCIATION add constraint NN_SMA_IDENT check (identifier is not null or merlin_resource_type in (1,3))
/

create index IDX_SMA_UPDATED on SOCIALMEDIAASSOCIATION (updated)
/


-- index-entityDataService_only.sql 

-- This file contains indexes that pertain to the MWS schema but not
-- the Ingest schema.  Indexes that apply to both schemas SHOULD NOT
-- be put in here; rather they should go in the individual create_
-- script.

CREATE INDEX IDX_PROGRAM_MRTP_OWNID_UPD
   ON PROGRAM (MERLIN_RESOURCE_TYPE,
               OWNER_ID,
               UPDATED)
/

CREATE INDEX IDX_PROGRAM_ownid_mrtupd_id
   ON PROGRAM (OWNER_ID,
               MERLIN_RESOURCE_TYPE,
               UPDATED,
               ID)
/

CREATE INDEX IDX_PERSON_NM_RTP_OWNID
   ON PERSON (NAME,
              MERLIN_RESOURCE_TYPE,
              OWNER_ID)
/

CREATE INDEX IDPROGRAM_LAN_MRT
   ON PROGRAM (LANGUAGE,
               MERLIN_RESOURCE_TYPE)
/
--- BITT-2615
CREATE INDEX IDX_NOT_OBTYPE_MTHD_EID ON NOTIFICATION (OBJECT_TYPE, METHOD, EXTERNAL_ID)
/
--- BITT-3801
drop index idx_tag_assoc_merlinrestype
/
create bitmap index idx_tag_assoc_merlinrestype on tag_association(merlin_resource_type)
/
-- BITT-2887 - tuning indexes form POA/and POC retor to dev and MERQA
create index  IDX_PROGRAM_MEOI_MRT_2 on PROGRAM(MMI_ED_OBJECT_ID,MERLIN_RESOURCE_TYPE,MMI_ED_OBJECT_MRT,OWNER_ID)
/

--MERLIN-9111: Addign foreign key to the program_id column in the programrank table
-- THIS SCRIPT MUST BE RUN IN ON THE ENTITY MWS SCHEMA ONLY -- NOT THE INGEST SCHEMA
delete from programrank where program_id not in (select id from program)
/
alter table programrank add constraint FK_PROGRAMRANK_PROGRAM foreign key (program_id) references PROGRAM (id)
/
---BITT-4902 backport MRT to feedgen
create index IDX_PROGRAM_ID_MRT on PROGRAM(merlin_resource_type,id)
/
create index IDX_TAGASO_ID_MRT on TAG_ASSOCIATION(merlin_resource_type,id)
/
create index IDX_ALBUMRELEASESONG_ID_MRT on ALBUMRELEASESONG(merlin_resource_type,id)
/
create index IDX_SONGCREDIT_ID_MRT on SONGCREDIT(merlin_resource_type,id)
/
create index IDX_CREDIT_ID_MRT on CREDIT(merlin_resource_type,id)
/
create index IDX_RELATEDPROGRAM_ID_MRT on RELATEDPROGRAM(merlin_resource_type,id)
/
create index IDX_PERSON_ID_MRT on PERSON(merlin_resource_type,id)
/



-- create_store_proc-entityDataService_only.sql 

--- procedure to maintain notification and notification_allowed partitions

CREATE OR REPLACE FUNCTION LONG_TO_CHAR (P_TABLE IN VARCHAR2, P_PART IN VARCHAR2)RETURN VARCHAR2
    IS
      HV VARCHAR2(32767);
    BEGIN
      SELECT HIGH_VALUE INTO HV 
      FROM USER_TAB_PARTITIONS 
      WHERE TABLE_NAME = P_TABLE
       AND PARTITION_NAME = P_PART;
     RETURN HV;
   end;
/
   
CREATE OR REPLACE FUNCTION  LONG_TO_CHAR_IDX
      (P_TABLE IN VARCHAR2, P_INDEX IN VARCHAR2,P_IPART IN VARCHAR2)
    RETURN VARCHAR2
    IS
      HV VARCHAR2(32767);
    BEGIN
      SELECT HIGH_VALUE INTO HV 
      FROM USER_PART_INDEXES UPI, USER_IND_PARTITIONS UIP
       WHERE     UPI.TABLE_NAME = P_TABLE
             AND UIP.INDEX_NAME = UPI.INDEX_NAME
             AND UIP.INDEX_NAME = P_INDEX
             AND UIP.PARTITION_NAME=P_IPART;
     RETURN HV;
   end;
/

CREATE OR REPLACE PROCEDURE p_part_work (
   p_tname         VARCHAR2 DEFAULT 'NOTIFICATION',
   p_index_name    VARCHAR2 DEFAULT 'PK_NOTIFICATION',
   p_exec          BOOLEAN DEFAULT FALSE,
   p_DROPTBPART    BOOLEAN DEFAULT FALSE)
IS
   vi_hv               VARCHAR2 (2000);
   vi_pname            VARCHAR2 (200);
   vi_nrows            NUMBER;
   vi_indname          VARCHAR2 (200);
   vi_tblname          VARCHAR2 (200);
   vt_table_name       VARCHAR2 (200);
   vt_high_value       VARCHAR2 (2000);
   vt_partition_name   VARCHAR2 (200);
   vt_NUM_ROWS         NUMBER;
   V_userid            VARCHAR2 (200);
   v_stmt              VARCHAR2 (2000);
   v_keepgoing          BOOLEAN;

   CURSOR c1
   IS
      SELECT uip.index_name,
             uip.partition_name,
             uip.num_rows,
             UPI.TABLE_NAME,
             uip.high_value
        FROM user_part_indexes upi, user_ind_partitions uip
       WHERE     upi.table_name = p_tname
             AND UIP.INDEX_NAME = UPI.INDEX_NAME
             AND uip.INDEX_NAME = p_index_name
             order by   uip.partition_name,long_to_char_IDX( p_tname, p_index_name, uip.partition_name),uip.num_rows  ;

   PROCEDURE writelogs (p_proc VARCHAR2, p_message VARCHAR2)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      INSERT INTO LOGS (MSG_DT, PROCESS, MESSAGE)
           VALUES (SYSDATE, p_proc, p_message);

      COMMIT;
   END;
PROCEDURE DROP_TABLE_PART(p_pexec boolean default false)
IS
v_tmp number;
TYPE CURSOR_TYPE IS REF CURSOR;
v_cntr CURSOR_TYPE;
vv_cntr NUMBER;
v_skip_first number :=0;
BEGIN
      writelogs ('P_PART_WORK', 'STARTED');
 SELECT count(*) into v_tmp
                         FROM user_tab_partitions utp
                        WHERE utp.table_name = p_tname
                     ;
  DBMS_OUTPUT.PUT_LINE ('**************************************');                 
  DBMS_OUTPUT.PUT_LINE ('***START WORK ON TABLE PARTITIONS*****');
 if v_tmp > 1 then
   FOR i IN (SELECT table_name,
                    high_value,
                    partition_name,
                    NUM_ROWS
               FROM (  SELECT utp.table_name,
                              utp.high_value,
                              utp.partition_name,
                              UTP.NUM_ROWS
                         FROM user_tab_partitions utp
                        WHERE utp.table_name = p_tname
			---BITT-4092
                        --- ORDER BY utp.partition_name, UTP.NUM_ROWS ASC))
			 ORDER BY to_number(LONG_TO_CHAR (utp.table_name, utp.partition_name)),UTP.NUM_ROWS  ASC))
   LOOP
    DBMS_OUTPUT.PUT_LINE ('**************************************');
    DBMS_OUTPUT.PUT_LINE ('TABLE PARTITION '|| i.partition_name||' for table '||
          v_userid|| '.'|| i.table_name ||' has '||TO_CHAR(vv_cntr)||' rows');
          
     IF v_skip_first = 0 THEN
      --- skip first partition
      v_skip_first :=1;
        DBMS_OUTPUT.PUT_LINE ('Skip first partition');
     ELSE
          --- VERIFY IT IS EMPTY
        v_stmt :=
            'select count(*) cntr  from  '
            || v_userid|| '.'|| i.table_name
            ||' partition ('|| i.partition_name||')';
        OPEN v_cntr FOR v_stmt;
        FETCH v_cntr INTO vv_cntr;
        CLOSE v_cntr;
        DBMS_OUTPUT.PUT_LINE ('PARTITION '|| i.partition_name||' for table '||
          v_userid|| '.'|| i.table_name ||' has '||TO_CHAR(vv_cntr)||' rows');
      IF i.NUM_ROWS = 0 AND vv_cntr = 0
      THEN
         v_stmt := 'ALTER TABLE ' || v_userid|| '.'|| i.table_name
            || ' DROP PARTITION '|| i.partition_name||' UPDATE GLOBAL INDEXES  PARALLEL 3';
         DBMS_OUTPUT.PUT_LINE (v_stmt);
         IF p_pexec
         THEN
            BEGIN
               EXECUTE IMMEDIATE v_stmt;
            EXCEPTION
               WHEN OTHERS
               THEN
                  writelogs (
                     'P_PART_WORK',
                     'DROP TABLE PART FAILED:' || i.partition_name || ':' || SQLERRM);
                  DBMS_OUTPUT.PUT_LINE (SQLERRM);
            END;
         else
         DBMS_OUTPUT.PUT_LINE('NOEXEC IT IS FALSE , just show v_stmt >>'||v_stmt);
         END IF;
            DBMS_OUTPUT.PUT_LINE (CHR (13));
      ELSE
      DBMS_OUTPUT.PUT_LINE ('PARTITION'||i.partition_name||' i.NUM_ROWS= '|| to_char(i.NUM_ROWS)||
             ' vv_cntr '||to_char(vv_cntr) ||' >>>>>>NO NEED TO SCAN FURTHER');
        EXIT;
      END IF;
     END IF;
   END LOOP;
 end if;
END;
   
BEGIN
   -- get max partition on table
   SELECT SYS_CONTEXT ('USERENV', 'CURRENT_SCHEMA') INTO v_userid FROM DUAL;
   --
   SELECT table_name,
          high_value,
          partition_name,
          NUM_ROWS
     INTO vt_table_name,
          vt_high_value,
          vt_partition_name,
          vt_NUM_ROWS
     FROM (  SELECT utp.table_name,
                    utp.high_value,
                    utp.partition_name,
                    UTP.NUM_ROWS
               FROM user_tab_partitions utp
              WHERE utp.table_name = p_tname
              --- BITT-4042 
              ---  ORDER BY utp.partition_name DESC)
               ORDER BY to_number(long_to_char(utp.table_name, utp.partition_name)) desc )
    WHERE ROWNUM = 1;

   OPEN c1;
   v_keepgoing :=TRUE;
   LOOP
      FETCH c1
      INTO vi_indname, vi_pname, vi_nrows, vi_tblname, vi_hv;
      DBMS_OUTPUT.PUT_LINE ('******************************************************');
      DBMS_OUTPUT.put_line ('INDEX  PARTITION'|| v_userid|| '.'|| vi_indname || ' PARTITION '||
                         vi_pname||', vi_nrows'||to_char(vi_nrows)||',vi_hv='||to_char(vi_hv));
       DBMS_OUTPUT.put_line ('TABLE MAX number rows PARTITION'|| vt_partition_name
                         ||',  vt_NUM_ROWS='||to_char( vt_NUM_ROWS)||',vt_high_value='||to_char(vt_high_value));                   
      EXIT WHEN c1%NOTFOUND OR v_keepgoing = FALSE;
      DBMS_OUTPUT.PUT_LINE (CHR (13));
       DBMS_OUTPUT.PUT_LINE ('******************************************************');

      IF vi_hv != 'MAXVALUE'
      THEN

         IF TO_NUMBER (vi_hv) < TO_NUMBER (vt_high_value)
         THEN
            ---
           -- check if it should be dropped otherwise do nothing
           if vi_nrows = 0 then
             DBMS_OUTPUT.put_line ('INDEX '|| v_userid|| '.'|| vi_indname || ' PARTITION '
             ||vi_pname||' IS EMPTY ,NEEDS TO BE DROPPED');
             v_stmt := 'ALTER INDEX '|| v_userid|| '.'|| vi_indname || '  DROP PARTITION '||vi_pname;
             DBMS_OUTPUT.PUT_LINE (v_stmt);
             if p_exec THEN
               BEGIN
               EXECUTE IMMEDIATE v_stmt;
                EXCEPTION
               WHEN OTHERS
               THEN
                  writelogs ('P_PART_WORK', 'DROP PART FAILED:'|| vi_pname||':'||SQLERRM);
                  DBMS_OUTPUT.PUT_LINE (SQLERRM);
               END;
             END IF;
           end if;
            DBMS_OUTPUT.put_line (
                  'to_number(vi_hv) <to_number(vt_high_value)NOSPLIT: vi_hv='
               || vi_hv|| ',vt_high_value='|| vt_high_value);
         ELSE                   ---to_number(vi_hv) >=to_number(vt_high_value)
            --- split  index at the point  of table partititon
            DBMS_OUTPUT.put_line (
                  'to_number(vi_hv) =>to_number(vt_high_value)NOSPLIT SINCE INDEX => THEN TABLE: vi_hv='
               || vi_hv|| ',vt_high_value='|| vt_high_value);
            DBMS_OUTPUT.put_line ('NO NEED TO SCAN FURTHER');
            v_keepgoing := FALSE;
         END IF;
      ELSE
         DBMS_OUTPUT.put_line (
               'INDEX ON MAXVALUE SPLIT:vi_hv='|| vi_hv  || ',vt_high_value='|| vt_high_value);
         DBMS_OUTPUT.PUT_LINE (CHR (13));
         v_stmt := 'ALTER INDEX '|| v_userid|| '.'
            || vi_indname || ' SPLIT PARTITION '
            || vi_pname || ' AT (' || vt_high_value|| ') INTO (PARTITION '
            || SUBSTR (vi_pname, 1, INSTR (vi_pname, '_MAX') - 1)
            || '_'|| vt_high_value|| ',PARTITION '|| vi_pname|| ')';
         DBMS_OUTPUT.PUT_LINE (v_stmt);

         IF p_exec
         THEN
            BEGIN
               EXECUTE IMMEDIATE v_stmt;
            EXCEPTION
               WHEN OTHERS
               THEN
                  writelogs ('P_PART_WORK', 'SPLIT PARTITION FAILED:'|| vi_pname||':'||SQLERRM);
                  DBMS_OUTPUT.PUT_LINE (SQLERRM);
            END;
         END IF;
      END IF;

      DBMS_OUTPUT.put_line (vi_indname|| ','|| vi_pname|| ','|| TO_CHAR (vi_nrows)
         || ','|| vi_tblname|| ','|| vi_hv);
   END LOOP;

   CLOSE c1;

   ---- WORK ON  EMPTY TABLE partitions
   if p_DROPTBPART then
        DROP_TABLE_PART(p_exec);
   end if;

   DBMS_OUTPUT.PUT_LINE ('------------------------');
      writelogs ('P_PART_WORK', 'COMPLETED');
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (SQLERRM);
      writelogs ('P_PART_WORK', SQLERRM);
END p_part_work;
/


 -- One last necessary item

alter sequence notification_sequence nocache
/
