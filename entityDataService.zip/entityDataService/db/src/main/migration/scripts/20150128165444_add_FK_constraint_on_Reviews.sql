--// add FK constraint on Reviews
-- Migration SQL that makes the change goes here.

DELETE FROM review_rating
WHERE review_id IN (
  SELECT id FROM review
  WHERE program_id NOT IN (SELECT id FROM program)
)
/

DELETE FROM review WHERE program_id NOT IN (SELECT id FROM program)
/

ALTER TABLE review ADD CONSTRAINT fk_review_prg_id FOREIGN KEY (program_id) REFERENCES program (id)
/

--//@UNDO
-- SQL to undo the change goes here.

ALTER TABLE review DROP CONSTRAINT fk_review_prg_id
/
