-- // US27612 - forgot to update the check constraint that ensures the TA type id columns are not null

create table MMI_A_PROGRAMCONTENTRATING (
	program_id number(19) ,
	rating_scheme varchar2(32) ,
	rating_rating varchar2(32) ,
	rating_subratings varchar2(32)
) initrans ${tbl_initran} tablespace ${tbl_tbs}
/
alter table MMI_A_PROGRAMCONTENTRATING add constraint  NN_PID_MMI_A_PRCR   check (program_id is not null)
/
alter table MMI_A_PROGRAMCONTENTRATING add  constraint  NN_RSCH_MMI_A_PRCR   check (rating_scheme is not null)
/
alter table MMI_A_PROGRAMCONTENTRATING add constraint  NN_RTNG_RTNG_MMI_A_PRCR   check (rating_rating is not null)
/
alter table MMI_A_PROGRAMCONTENTRATING add constraint FK_MMI_A_PROGRAM_RATING foreign key (program_id) references PROGRAM (id)
/
create unique index UX_MMI_A_PCRATING   on MMI_A_PROGRAMCONTENTRATING (program_id, rating_scheme, rating_rating) initrans ${idx_initran} tablespace ${idx_tbs}
/

create table MMI_R_PROGRAMCONTENTRATING (
	program_id number(19) ,
	rating_scheme varchar2(32)
) initrans ${tbl_initran} tablespace ${tbl_tbs}
/
alter table MMI_R_PROGRAMCONTENTRATING add constraint  NN_PID_MMI_R_PRCR   check (program_id is not null)
/
alter table MMI_R_PROGRAMCONTENTRATING add constraint  NN_RSCH_MMI_R_PRCR   check (rating_scheme is not null)
/
alter table MMI_R_PROGRAMCONTENTRATING  add constraint FK_MMI_R_PROGRAM_RATING foreign key (program_id) references PROGRAM (id)
/
create unique index UX_MMI_R_PCRATING on MMI_R_PROGRAMCONTENTRATING (program_id, rating_scheme) initrans ${idx_initran} tablespace ${idx_tbs}
/

--//@UNDO

DROP table MMI_A_PROGRAMCONTENTRATING
/

DROP table MMI_R_PROGRAMCONTENTRATING
/
