--// US26728_DSS_UP_Notification
alter table NOTIFICATION add trace_to varchar(255) default null
/
alter table NOTIFICATION add cid varchar(255) default null
/

--//@UNDO
alter table NOTIFICATION drop column  trace_to
/
alter table NOTIFICATION drop column      cid
/