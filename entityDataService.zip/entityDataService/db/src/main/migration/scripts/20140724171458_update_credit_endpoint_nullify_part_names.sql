--// update_credit_endpoint_nullify_part_names
--Migration SQL that makes the change goes here.

UPDATE CREDIT SET PART_NAME = null WHERE TYPE NOT IN ('Actor', 'Voice', 'Reality Cast Member', 'Performer', 'Host', 'Narrator', 'Animal Actor', 'Appearing', 'Guest')
/
COMMIT
/


--//@UNDO
--SQL to undo the change goes here.


