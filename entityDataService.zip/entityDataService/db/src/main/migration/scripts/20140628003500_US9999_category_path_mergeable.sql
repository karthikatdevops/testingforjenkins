--US9999 make categoryPaths editorializable via adds/removes

create table PMAMERGEFIELD (
    pma_id number(19) not null,
    operation number(4) not null,
    field number(4) not null,
    category_path varchar2(4000) not null,
    constraint FK_PMAMERGEFIELD_PMAID foreign key (pma_id) references PROGRAMMEDIAASSOCIATION (id)
)
/
create index IDX_PMAMERGEFIELD_COLID on PMAMERGEFIELD (pma_id)
/


--//@UNDO
DROP TABLE PMAMERGEFIELD
/