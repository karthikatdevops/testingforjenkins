--// add index on Review
-- Migration SQL that makes the change goes here.

create index IDX_REVIEW_MMID on REVIEW(MMI_ED_OBJECT_ID) INITRANS ${tbl_initran} TABLESPACE ${tbl_tbs}
/

--//@UNDO
-- SQL to undo the change goes here.

drop index idx_review_mmid
/
