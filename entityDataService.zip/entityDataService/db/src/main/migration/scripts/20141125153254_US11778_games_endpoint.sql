-- // US11778_games_endpoint
CREATE TABLE VIDEOGAME
(
  id                     NUMBER(19),
  owner_id               NUMBER(19),
  added                  DATE,
  updated                DATE,
  added_by_uri_path_id   NUMBER(19),
  added_by_uri_ref       VARCHAR2(4000),
  updated_by_uri_path_id NUMBER(19),
  updated_by_uri_ref     VARCHAR2(4000),
  version                NUMBER(19),
  locked                 NUMBER(1) DEFAULT 0,
  guid                   VARCHAR2(2000),
  title                  VARCHAR2(256),

  short_title            VARCHAR2(64) DEFAULT NULL,
  medium_title           VARCHAR2(128) DEFAULT NULL,
  long_title             VARCHAR2(256) DEFAULT NULL,
  short_synopsis         VARCHAR2(4000) DEFAULT NULL,
  medium_synopsis        VARCHAR2(4000) DEFAULT NULL,
  long_synopsis          VARCHAR2(4000) DEFAULT NULL,
  type                   VARCHAR(128),
  native_id              VARCHAR(4000) DEFAULT NULL,
  release_date           NUMBER(19) DEFAULT NULL,
  attribution_string     VARCHAR2(256) DEFAULT NULL,
  single_player          NUMBER(1) DEFAULT NULL,
  multi_player           NUMBER(1) DEFAULT NULL,
  min_players            NUMBER DEFAULT NULL,
  max_players            NUMBER DEFAULT NULL,
  languages              VARCHAR2(200),

  last_cascade_updated   DATE,
  merlin_resource_type   NUMBER(1),
  explicit_mrt           NUMBER(1),
  mmi_null_overrides     VARCHAR2(4000),
  mmi_ed_object_id       NUMBER(19),
  mmi_ed_object_state    NUMBER(1),
  mmi_ed_object_mrt      NUMBER(1)
) TABLESPACE ${tbl_tbs} INITRANS ${tbl_initran}
/

CREATE UNIQUE INDEX IDX_VIDEOGAME_ID ON VIDEOGAME (id) INITRANS ${idx_initran} TABLESPACE ${idx_tbs}
/
CREATE INDEX IDX_VIDEOGAME_UPDATED ON VIDEOGAME (updated) INITRANS ${idx_initran} TABLESPACE ${idx_tbs}
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT PK_VIDEOGAME PRIMARY KEY (id) USING INDEX IDX_VIDEOGAME_ID
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT UX_VIDEOGAME_GUID UNIQUE (guid, owner_id)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_OWNERID CHECK (owner_id IS NOT NULL)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_ADDED CHECK (added IS NOT NULL)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_UPDATED CHECK (updated IS NOT NULL)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_ADDURIID CHECK (added_by_uri_path_id IS NOT NULL)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_ADDURIRF CHECK (added_by_uri_ref IS NOT NULL)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_UPDURIID CHECK (updated_by_uri_path_id IS NOT NULL)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_UPDURIRF CHECK (updated_by_uri_ref IS NOT NULL)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_VERSION CHECK (version IS NOT NULL)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_LOCKED CHECK (locked IS NOT NULL)
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT NN_VIDEOGAME_GUID CHECK (guid IS NOT NULL)
/

ALTER TABLE VIDEOGAME ADD CONSTRAINT CNC_VIDEOGAME_NATIVE_ID CHECK (native_id IS NOT NULL OR merlin_resource_type IN (1, 3))
/
ALTER TABLE VIDEOGAME ADD CONSTRAINT CNC_VIDEOGAME_TYPE CHECK (type IS NOT NULL OR merlin_resource_type IN (1, 3))
/

-- update TAG_ASS table

ALTER TABLE TAG_ASSOCIATION ADD videogame_id NUMBER(19, 0)
/
CREATE INDEX IDX_TA_VIDEOGAME_ID ON TAG_ASSOCIATION (videogame_id) INITRANS ${idx_initran} TABLESPACE ${idx_tbs}
/
ALTER TABLE TAG_ASSOCIATION ADD CONSTRAINT FK_TAG_ASSO_GAME_ID FOREIGN KEY (videogame_id) REFERENCES VIDEOGAME (id) NOVALIDATE
/
CREATE OR REPLACE TRIGGER TAG_ASSOC_INS_UPD_TRIGGER BEFORE INSERT OR UPDATE ON TAG_ASSOCIATION FOR EACH ROW
  BEGIN
    CASE :new.entity_type
      WHEN 'Program'
      THEN :new.program_id := :new.entity_id;
      WHEN 'Person'
      THEN :new.person_id := :new.entity_id;
      WHEN 'Song'
      THEN :new.song_id := :new.entity_id;
      WHEN 'Album'
      THEN :new.album_id := :new.entity_id;
      WHEN 'AlbumRelease'
      THEN :new.album_release_id := :new.entity_id;
      WHEN 'Videogame'
      THEN :new.videogame_id := :new.entity_id;
    ELSE NULL;
    END CASE;
    IF UPDATING AND :old.entity_type != :new.entity_type
    THEN
      CASE :old.entity_type
        WHEN 'Program'
        THEN :new.program_id := NULL;
        WHEN 'Person'
        THEN :new.person_id := NULL;
        WHEN 'Song'
        THEN :new.song_id := NULL;
        WHEN 'Album'
        THEN :new.album_id := NULL;
        WHEN 'AlbumRelease'
        THEN :new.album_release_id := NULL;
        WHEN 'Videogame'
        THEN :new.videogame_id := NULL;
      ELSE NULL;
      END CASE;
    END IF;
  END;
/

-- the join table for content rating

CREATE TABLE VIDEOGAME_RATING (
  videogame_id              NUMBER(19)   NOT NULL,
  rating_scheme        VARCHAR2(32) NOT NULL,
  rating_rating        VARCHAR2(50) NOT NULL,
  rating_subratings    VARCHAR2(500),
  rating_interElements VARCHAR2(150)
)
/
ALTER TABLE VIDEOGAME_RATING ADD CONSTRAINT FK_VIDEOGAME_RATING FOREIGN KEY (videogame_id) REFERENCES VIDEOGAME (id)
/
CREATE INDEX IDX_VGAMECONTENTRATING_GID ON VIDEOGAME_RATING (videogame_id) INITRANS ${idx_initran} TABLESPACE ${idx_tbs}
/
ALTER TABLE VIDEOGAME_RATING ADD CONSTRAINT UX_VGRATING UNIQUE (videogame_id, rating_scheme, rating_rating)
/

--//@UNDO

DROP TABLE VIDEOGAME_RATING
/
ALTER TABLE TAG_ASSOCIATION DROP COLUMN videogame_id
/
CREATE OR REPLACE TRIGGER TAG_ASSOC_INS_UPD_TRIGGER BEFORE INSERT OR UPDATE ON TAG_ASSOCIATION FOR EACH ROW
  BEGIN
    CASE :new.entity_type
      WHEN 'Program'
      THEN :new.program_id := :new.entity_id;
      WHEN 'Person'
      THEN :new.person_id := :new.entity_id;
      WHEN 'Song'
      THEN :new.song_id := :new.entity_id;
      WHEN 'Album'
      THEN :new.album_id := :new.entity_id;
      WHEN 'AlbumRelease'
      THEN :new.album_release_id := :new.entity_id;
    ELSE NULL;
    END CASE;
    IF UPDATING AND :old.entity_type != :new.entity_type
    THEN
      CASE :old.entity_type
        WHEN 'Program'
        THEN :new.program_id := NULL;
        WHEN 'Person'
        THEN :new.person_id := NULL;
        WHEN 'Song'
        THEN :new.song_id := NULL;
        WHEN 'Album'
        THEN :new.album_id := NULL;
        WHEN 'AlbumRelease'
        THEN :new.album_release_id := NULL;
      ELSE NULL;
      END CASE;
    END IF;
  END;
/
DROP TABLE VIDEOGAME
/


