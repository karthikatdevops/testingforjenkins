--// revert FK constraint on Reviews
-- Migration SQL that makes the change goes here.

update person set birth = null where birth = 21130
/

--//@UNDO
-- SQL to undo the change goes here.

-- unable to undo this dml change

