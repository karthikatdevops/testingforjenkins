--DE6899 fix EntityCollection mergeable fields (4 should be 2 and 8 should be 6)

update ECMERGEFIELD set field = 2 where field = 4
/
update ECMERGEFIELD set field = 6 where field = 8
/


--//@UNDO

