-- // missing_indexes
-- Migration SQL that makes the change goes here.

declare
  v_user varchar2(50);
  v_stmt varchar2(256);
  v_storage varchar2(128);
  t1 NUMBER;
  begin 
    select ' initrans ${idx_initran} tablespace ${idx_tbs} ' into v_storage from dual;
    SELECT SYS_CONTEXT ('USERENV', 'SESSION_USER')  into v_user FROM DUAL;
    
    select count(index_name) into t1  from user_indexes where index_name='TAG_ASSOC_MRT_OID_MMID' and table_name='TAG_ASSOCIATION';  
    if t1  = 0 then
    v_stmt := 'create index '||v_user||'.TAG_ASSOC_MRT_OID_MMID ON  '||v_user||'.TAG_ASSOCIATION(MERLIN_RESOURCE_TYPE, OWNER_ID, MMI_ENTITY_ID) '||v_storage;
      execute immediate  v_stmt;
    end if;
    
    select count(index_name) into t1  from user_indexes where index_name='IDX_TAG_ASSO_ET_EID' and table_name='TAG_ASSOCIATION';  
    if t1  = 0 then
    v_stmt :='create index '||v_user||'.IDX_TAG_ASSO_ET_EID  on '||v_user||'.TAG_ASSOCIATION(ENTITY_TYPE, ENTITY_ID) '||v_storage;
      execute immediate v_stmt;
    end if;
  end;
  /

-- //@UNDO
-- SQL to undo the change goes here.


