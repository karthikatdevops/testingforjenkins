--//US31032 Add editorialObjectId indexes on PMA, RP, and Credit
create index IDX_PGRMMEDIAASSO_EDOBJID_MRT
 on PROGRAMMEDIAASSOCIATION ( mmi_ed_object_id, merlin_resource_type) INITRANS ${idx_initran} TABLESPACE ${idx_tbs}
/

create index IDX_RELPROGRAM_EDOBJID_MRT on RELATEDPROGRAM (mmi_ed_object_id, merlin_resource_type) INITRANS ${idx_initran} TABLESPACE ${idx_tbs}
/

create index IDX_CREDIT_EDOBJID_MRT on CREDIT (mmi_ed_object_id, merlin_resource_type) INITRANS ${idx_initran} TABLESPACE ${idx_tbs}
/

--//@UNDO
DROP index IDX_PGRMMEDIAASSO_EDOBJID_MRT
/

DROP index IDX_RELPROGRAM_EDOBJID_MRT
/

DROP index IDX_CREDIT_EDOBJID_MRT
/
