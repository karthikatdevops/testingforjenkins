--// US26146 update program_content_ratings canadian ratings
UPDATE PROGRAMCONTENTRATING pcr
SET pcr.RATING_SCHEME   = 'urn:www.ccnr.ca'
WHERE pcr.RATING_SCHEME = 'urn:agvot'
/

UPDATE PROGRAMCONTENTRATING pcr
SET pcr.RATING_SCHEME   = 'urn:www.cmpda.ca'
WHERE pcr.RATING_SCHEME = 'urn:ofrb'
/


--//@UNDO
UPDATE PROGRAMCONTENTRATING pcr
SET pcr.RATING_SCHEME   = 'urn:agvot'
WHERE pcr.RATING_SCHEME = 'urn:www.ccnr.ca'
/

UPDATE PROGRAMCONTENTRATING pcr
SET pcr.RATING_SCHEME   = 'urn:ofrb'
WHERE pcr.RATING_SCHEME = 'urn:www.cmpda.ca'
/