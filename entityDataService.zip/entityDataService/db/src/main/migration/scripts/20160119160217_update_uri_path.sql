--// update uri path
-- Migration SQL that makes the change goes here.

alter table URI_PATH drop constraint UX_URI_PATH_PATH
/

declare
  t1 number;
  begin
    select count(*) into t1 from user_indexes where index_name='UX_URI_PATH_PATH';
    if t1 > 0 then
      execute immediate 'drop index UX_URI_PATH_PATH';
    end if;
  end;
/

-- this update should create duplicates; we expect that each group by path will have at most 2 elements
update URI_PATH set path=REGEXP_REPLACE(path,'^http://(.*/data/User$)', 'https://\1')
/

--//@UNDO
-- SQL to undo the change goes here.

-- we expect that each group by path will have at most 2 elements
update uri_path set path=REGEXP_REPLACE(path,'^https://(.*/data/User$)', 'http://\1') where id in (select min(id) from uri_path group by path)
/

-- delete all duplicates
delete from URI_PATH where id not in (select min(id) as id from URI_PATH group by path)
/

alter table URI_PATH add constraint UX_URI_PATH_PATH unique (path)
/
