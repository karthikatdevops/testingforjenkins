--// US11747_SportsTeam_abbreviation
ALTER TABLE SPORTSTEAM ADD abbreviation varchar2(10)
/

--//@UNDO
ALTER TABLE SPORTSTEAM DROP COLUMN abbreviation
/