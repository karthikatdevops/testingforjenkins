-- // US27612 - Adding tag association sql changes to support tags on sports teams

-- update TAG_ASS table

ALTER TABLE TAG_ASSOCIATION ADD sportsTeam_id NUMBER(19, 0)
/
CREATE INDEX IDX_TA_SPORTSTEAM_ID ON TAG_ASSOCIATION (sportsTeam_id) INITRANS ${idx_initran} TABLESPACE ${idx_tbs}
/
ALTER TABLE TAG_ASSOCIATION ADD CONSTRAINT FK_TAG_ASSO_SPORTSTEAM_ID FOREIGN KEY (sportsTeam_id) REFERENCES SPORTSTEAM (id) NOVALIDATE
/
CREATE OR REPLACE TRIGGER TAG_ASSOC_INS_UPD_TRIGGER BEFORE INSERT OR UPDATE ON TAG_ASSOCIATION FOR EACH ROW
  BEGIN
    CASE :new.entity_type
      WHEN 'Program'
      THEN :new.program_id := :new.entity_id;
      WHEN 'Person'
      THEN :new.person_id := :new.entity_id;
      WHEN 'Song'
      THEN :new.song_id := :new.entity_id;
      WHEN 'Album'
      THEN :new.album_id := :new.entity_id;
      WHEN 'AlbumRelease'
      THEN :new.album_release_id := :new.entity_id;
      WHEN 'Videogame'
      THEN :new.videogame_id := :new.entity_id;
      WHEN 'SportsTeam'
      THEN :new.sportsTeam_id := :new.entity_id;
    ELSE NULL;
    END CASE;
    IF UPDATING AND :old.entity_type != :new.entity_type
    THEN
      CASE :old.entity_type
        WHEN 'Program'
        THEN :new.program_id := NULL;
        WHEN 'Person'
        THEN :new.person_id := NULL;
        WHEN 'Song'
        THEN :new.song_id := NULL;
        WHEN 'Album'
        THEN :new.album_id := NULL;
        WHEN 'AlbumRelease'
        THEN :new.album_release_id := NULL;
        WHEN 'Videogame'
        THEN :new.videogame_id := NULL;
        WHEN 'SportsTeam'
        THEN :new.sportsTeam_id := NULL;
      ELSE NULL;
      END CASE;
    END IF;
  END;
/

--//@UNDO

ALTER TABLE TAG_ASSOCIATION DROP COLUMN sportsTeam_id
/
CREATE OR REPLACE TRIGGER TAG_ASSOC_INS_UPD_TRIGGER BEFORE INSERT OR UPDATE ON TAG_ASSOCIATION FOR EACH ROW
  BEGIN
    CASE :new.entity_type
      WHEN 'Program'
      THEN :new.program_id := :new.entity_id;
      WHEN 'Person'
      THEN :new.person_id := :new.entity_id;
      WHEN 'Song'
      THEN :new.song_id := :new.entity_id;
      WHEN 'Album'
      THEN :new.album_id := :new.entity_id;
      WHEN 'AlbumRelease'
      THEN :new.album_release_id := :new.entity_id;
      WHEN 'Videogame'
      THEN :new.videogame_id := :new.entity_id;
    ELSE NULL;
    END CASE;
    IF UPDATING AND :old.entity_type != :new.entity_type
    THEN
      CASE :old.entity_type
        WHEN 'Program'
        THEN :new.program_id := NULL;
        WHEN 'Person'
        THEN :new.person_id := NULL;
        WHEN 'Song'
        THEN :new.song_id := NULL;
        WHEN 'Album'
        THEN :new.album_id := NULL;
        WHEN 'AlbumRelease'
        THEN :new.album_release_id := NULL;
        WHEN 'Videogame'
        THEN :new.videogame_id := NULL;
      ELSE NULL;
      END CASE;
    END IF;
  END;
/


