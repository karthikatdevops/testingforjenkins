--// extend venue name length
-- Migration SQL that makes the change goes here.
ALTER TABLE sportsteam MODIFY (
  venue VARCHAR2(75)
)
/

--//@UNDO
-- SQL to undo the change goes here.
ALTER TABLE sportsteam MODIFY (
  venue VARCHAR2(50)
)
/
