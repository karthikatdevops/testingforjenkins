--// US10986 FK on tag_association
--Migration SQL that makes the change goes here.
alter session force parallel ddl parallel 3
/
alter session force parallel query parallel 5
/
alter session force parallel dml parallel 5
/
create table tag_association_bk as (select * from tag_association)
/

alter table
   tag_association
add
   (
   program_id NUMBER(19,0),
   person_id NUMBER(19,0),
   song_id NUMBER(19,0),
   album_id NUMBER(19,0),
   album_release_id NUMBER(19,0)
   )
/
alter table
   tag_association
add constraint
FK_TAG_ASSO_PROGRAM_ID FOREIGN KEY (program_id) references program(id)  DISABLE  NOVALIDATE
/
alter table
   tag_association
add constraint
FK_TAG_ASSO_PERSON_ID FOREIGN KEY (person_id) references person(id) DISABLE  NOVALIDATE
/
alter table
   tag_association
add constraint
FK_TAG_ASSO_SONG_ID FOREIGN KEY (song_id) references song(id) DISABLE  NOVALIDATE
/
alter table
   tag_association
add constraint
FK_TAG_ASSO_ALBUM_ID FOREIGN KEY (album_id) references album(id) DISABLE  NOVALIDATE
/
alter table
tag_association
add constraint
  FK_TAG_ASSO_ALBUM_RELEASE_ID FOREIGN KEY (album_release_id) references albumrelease(id) DISABLE  NOVALIDATE
/

CREATE INDEX IDX_TA_PROGRAM_ID ON TAG_ASSOCIATION (PROGRAM_ID) initrans ${idx_initran} tablespace ${idx_tbs}
/
CREATE INDEX IDX_TA_PERSON_ID ON TAG_ASSOCIATION (PERSON_ID) initrans ${idx_initran} tablespace ${idx_tbs}
/
CREATE INDEX IDX_TA_SONG_ID ON TAG_ASSOCIATION (SONG_ID) initrans ${idx_initran} tablespace ${idx_tbs}
/
CREATE INDEX IDX_TA_ALBUM_ID ON TAG_ASSOCIATION (ALBUM_ID) initrans ${idx_initran} tablespace ${idx_tbs}
/
CREATE INDEX IDX_TA_ALBUM_RELEASE_ID ON TAG_ASSOCIATION (ALBUM_RELEASE_ID) initrans ${idx_initran} tablespace ${idx_tbs}
/


update tag_association set program_id = entity_id where entity_type = 'Program'
/
commit
/
update tag_association set person_id = entity_id where entity_type = 'Person'
/
commit
/
update tag_association set song_id = entity_id where entity_type = 'Song'
/
commit
/
update tag_association set album_id = entity_id where entity_type = 'Album'
/
commit
/
update tag_association set album_release_id = entity_id where entity_type = 'AlbumRelease'
/
commit
/
ALTER TABLE TAG_ASSOCIATION  MODIFY CONSTRAINT FK_TAG_ASSO_PROGRAM_ID  ENABLE NOVALIDATE
/
ALTER TABLE TAG_ASSOCIATION  MODIFY CONSTRAINT FK_TAG_ASSO_PERSON_ID  ENABLE NOVALIDATE
/
ALTER TABLE TAG_ASSOCIATION  MODIFY CONSTRAINT FK_TAG_ASSO_SONG_ID  ENABLE NOVALIDATE
/
ALTER TABLE TAG_ASSOCIATION  MODIFY CONSTRAINT FK_TAG_ASSO_ALBUM_ID  ENABLE NOVALIDATE
/
ALTER TABLE TAG_ASSOCIATION  MODIFY CONSTRAINT FK_TAG_ASSO_ALBUM_RELEASE_ID  ENABLE NOVALIDATE
/

create or replace trigger TAG_ASSOC_INS_UPD_TRIGGER before insert or update on TAG_ASSOCIATION for each row
  begin
    CASE :new.entity_type
      WHEN 'Program' THEN :new.program_id := :new.entity_id;
      WHEN 'Person' THEN :new.person_id := :new.entity_id;
      WHEN 'Song' THEN :new.song_id := :new.entity_id;
      WHEN 'Album' THEN :new.album_id := :new.entity_id;
      WHEN 'AlbumRelease' THEN :new.album_release_id := :new.entity_id;
    ELSE NULL;
    END CASE;
    IF UPDATING AND :old.entity_type != :new.entity_type THEN
      CASE :old.entity_type
        WHEN 'Program' THEN :new.program_id := null;
        WHEN 'Person' THEN :new.person_id := null;
        WHEN 'Song' THEN :new.song_id := null;
        WHEN 'Album' THEN :new.album_id := null;
        WHEN 'AlbumRelease' THEN :new.album_release_id := null;
      ELSE NULL;
      END CASE;
    END IF;
  END;
/

alter table
   tag_association
add constraint
COND_ONE_FK_NOT_NULL
CHECK (program_id is not null or person_id is not null or song_id is not null or album_id is not null or album_release_id is not null or (entity_id is null and entity_type is null))
/

alter table tag_association drop constraint FK_TAG_ASSO_ENTITY_ID
/

--
-- TARGET ENTITY CLEANUP
--
drop trigger program_insert_trigger
/
drop trigger program_delete_trigger
/
drop trigger person_insert_trigger
/
drop trigger person_delete_trigger
/
drop trigger song_insert_trigger
/
drop trigger song_delete_trigger
/
drop trigger album_insert_trigger
/
drop trigger album_delete_trigger
/
drop trigger albumrelease_insert_trigger
/
drop trigger albumrelease_delete_trigger
/


drop table target_entity_ids
/

drop table tag_association_bk
/

ALTER SESSION DISABLE PARALLEL ddl
/
ALTER SESSION DISABLE PARALLEL query
/
ALTER SESSION DISABLE PARALLEL dml
/

commit
/
--//@UNDO
--SQL to undo the change goes here.

alter session force parallel ddl parallel 3
/
alter session force parallel query parallel 5
/
alter session force parallel dml parallel 5
/

CREATE TABLE TARGET_ENTITY_IDS(
  id number(19) not null,
  entity_type varchar2(25) not null
)
/
create unique index PK_TARGET_ENTITY_IDS on TARGET_ENTITY_IDS (id, entity_type) initrans ${idx_initran} tablespace ${idx_tbs}
/
alter table TARGET_ENTITY_IDS add constraint PK_TARGET_ENTITY_IDS primary key (id, entity_type) using index PK_TARGET_ENTITY_IDS
/
--
-- Repopulate target_entity_ids
--
INSERT INTO TARGET_ENTITY_IDS (id, entity_type)
    select id as id, 'Program' as entity_type from PROGRAM
/
commit
/
INSERT INTO TARGET_ENTITY_IDS (id, entity_type)
  select id as id, 'Person' as entity_type from PERSON
/
commit
/
INSERT INTO TARGET_ENTITY_IDS (id, entity_type)
  select id as id, 'Song' as entity_type from SONG
/
commit
/
INSERT INTO TARGET_ENTITY_IDS (id, entity_type)
  select id as id, 'Album' as entity_type from ALBUM
/
commit
/
INSERT INTO TARGET_ENTITY_IDS (id, entity_type)
  select id as id, 'AlbumRelease' as entity_type from ALBUMRELEASE
/
commit
/
INSERT INTO TARGET_ENTITY_IDS (id, entity_type)
  select id as id, 'SportsTeam' as entity_type from SPORTSTEAM
/
commit
/

DROP INDEX IDX_TA_PROGRAM_ID
/
DROP INDEX IDX_TA_PERSON_ID
/
DROP INDEX IDX_TA_SONG_ID
/
DROP INDEX IDX_TA_ALBUM_ID
/
DROP INDEX IDX_TA_ALBUM_RELEASE_ID
/

DROP TRIGGER TAG_ASSOC_INS_UPD_TRIGGER
/

alter table tag_association drop constraint FK_TAG_ASSO_PROGRAM_ID
/
alter table tag_association drop constraint FK_TAG_ASSO_PERSON_ID
/
alter table tag_association drop constraint FK_TAG_ASSO_SONG_ID
/
alter table tag_association drop constraint FK_TAG_ASSO_ALBUM_ID
/
alter table tag_association drop constraint FK_TAG_ASSO_ALBUM_RELEASE_ID
/

alter table tag_association drop constraint COND_ONE_FK_NOT_NULL
/

create or replace trigger PROGRAM_INSERT_TRIGGER after insert on PROGRAM for each row
  begin
    INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
      VALUES(:new.id, 'Program');
  end;
/

create or replace trigger PROGRAM_DELETE_TRIGGER before delete on PROGRAM  for each row
  begin
    DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'Program';
  end;
/

create or replace trigger PERSON_INSERT_TRIGGER after insert on PERSON for each row
  begin
    INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
      VALUES(:new.id, 'Person');
  end;
/

create or replace trigger PERSON_DELETE_TRIGGER before delete on PERSON for each row
  begin
    DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'Person';
  end;
/

create or replace trigger SONG_INSERT_TRIGGER after insert on SONG for each row
  begin
    INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
      VALUES(:new.id, 'Song');
  end;
/

create or replace trigger SONG_DELETE_TRIGGER before delete on SONG  for each row
  begin
    DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'Song';
  end;
/

create or replace trigger ALBUM_INSERT_TRIGGER after insert on ALBUM for each row
  begin
    INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
      VALUES(:new.id, 'Album');
  end;
/

create or replace trigger ALBUM_DELETE_TRIGGER before delete on ALBUM  for each row
  begin
    DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'Album';
  end;
/
create or replace trigger ALBUMRELEASE_INSERT_TRIGGER after insert on ALBUMRELEASE for each row
  begin
    INSERT INTO TARGET_ENTITY_IDS(id, entity_type)
      VALUES(:new.id, 'AlbumRelease');
  end;
/

create or replace trigger ALBUMRELEASE_DELETE_TRIGGER before delete on ALBUMRELEASE  for each row
  begin
    DELETE FROM TARGET_ENTITY_IDS WHERE id = :old.id and entity_type = 'AlbumRelease';
  end;
/


alter table tag_association
add constraint FK_TAG_ASSO_ENTITY_ID foreign key (entity_id, entity_type) references TARGET_ENTITY_IDS (id, entity_type)
/

alter table tag_association
drop (program_id, person_id, song_id, album_id, album_release_id)
/

commit
/

ALTER SESSION DISABLE PARALLEL ddl
/
ALTER SESSION DISABLE PARALLEL query
/
ALTER SESSION DISABLE PARALLEL dml
/
COMMIT
/