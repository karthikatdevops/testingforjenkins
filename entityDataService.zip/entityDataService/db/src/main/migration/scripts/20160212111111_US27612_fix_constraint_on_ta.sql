-- // US27612 - forgot to update the check constraint that ensures the TA type id columns are not null

alter table tag_association drop constraint COND_ONE_FK_NOT_NULL
/
alter table
   tag_association
add constraint
COND_ONE_FK_NOT_NULL
CHECK (sportsTeam_id is not null or program_id is not null or person_id is not null or song_id is not null or album_id is not null or album_release_id is not null or (entity_id is null and entity_type is null)) enable novalidate
/

--//@UNDO

alter table tag_association drop constraint COND_ONE_FK_NOT_NULL
/
alter table
   tag_association
add constraint
COND_ONE_FK_NOT_NULL
CHECK (program_id is not null or person_id is not null or song_id is not null or album_id is not null or album_release_id is not null or (entity_id is null and entity_type is null)) enable novalidate
/

