package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.AlbumField;

public class AlbumAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(DataObjectField.title, Relationship.Owned, Access.ReadWrite);
        addAccessMap(DataObjectField.title, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumField.sortTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumField.sortTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumField.language, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumField.language, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumField.country, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumField.country, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumField.originalReleaseDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumField.originalReleaseDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumField.primaryPersonIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(AlbumField.primaryPersonIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(AlbumField.imageIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(AlbumField.imageIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(AlbumField.tagIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(AlbumField.tagIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(AlbumField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
