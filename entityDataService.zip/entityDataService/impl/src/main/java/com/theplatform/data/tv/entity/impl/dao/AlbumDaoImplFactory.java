package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class AlbumDaoImplFactory extends BaseDataServiceDaoFactory<AlbumDaoImpl> {

	/** @return a new {@link AlbumDaoImpl} instance. */
	protected AlbumDaoImpl createInstance() {
		return new AlbumDaoImpl();
	}

}
