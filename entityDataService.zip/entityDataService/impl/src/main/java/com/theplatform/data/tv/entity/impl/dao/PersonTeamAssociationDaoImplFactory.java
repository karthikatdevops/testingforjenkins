package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

/**
 * Created by Rama Sudalayandi on 12/9/15.
 */
public class PersonTeamAssociationDaoImplFactory extends BaseDataServiceDaoFactory<PersonTeamAssociationDaoImpl> {

    /**
     * @return a new {@link PersonTeamAssociationDaoImpl} instance.
     */
    protected PersonTeamAssociationDaoImpl createInstance() {
        return new PersonTeamAssociationDaoImpl();
    }

}
