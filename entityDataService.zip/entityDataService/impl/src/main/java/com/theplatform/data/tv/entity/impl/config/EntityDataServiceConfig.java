package com.theplatform.data.tv.entity.impl.config;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource
public class EntityDataServiceConfig implements InitializingBean {

	private String entityServiceBaseUrl;
	private String entityServiceDataUrl;
	private String linearServiceBaseUrl;
	private String linearServiceDataUrl;
	private String idServiceBaseUrl;
	private String idServiceDataUrl;
	private String mediaServiceBaseUrl;
	private String mediaServiceDataUrl;
	
	private Boolean cascadingUpdatesEnabled;

	@Override
	public void afterPropertiesSet() throws Exception {
		if (this.entityServiceBaseUrl == null || 
				this.entityServiceBaseUrl.trim().equals("") ||
				this.entityServiceBaseUrl.trim().equals("[entityServiceBaseUrl]")) {
			throw new IllegalStateException("entityServiceBaseUrl cannot be null");
		}
		if (this.entityServiceDataUrl == null || 
				this.entityServiceDataUrl.trim().equals("") ||
				this.entityServiceDataUrl.trim().equals("[entityServiceDataUrl]")) {
			throw new IllegalStateException("entityServiceDataUrl cannot be null");
		}
		if (this.linearServiceBaseUrl == null || 
				this.linearServiceBaseUrl.trim().equals("") ||
				this.linearServiceBaseUrl.trim().equals("[linearServiceBaseUrl]")) {
			throw new IllegalStateException("linearServiceBaseUrl cannot be null");
		}
		if (this.linearServiceDataUrl == null || 
				this.linearServiceDataUrl.trim().equals("") ||
				this.linearServiceDataUrl.trim().equals("[linearServiceDataUrl]")) {
			throw new IllegalStateException("linearServiceDataUrl cannot be null");
		}
		if (this.idServiceBaseUrl == null || 
				this.idServiceBaseUrl.trim().equals("") ||
				this.idServiceBaseUrl.trim().equals("[idServiceBaseUrl]")) {
			throw new IllegalStateException("idServiceBaseUrl cannot be null");
		}
		if (this.idServiceDataUrl == null || 
				this.idServiceDataUrl.trim().equals("") ||
				this.idServiceDataUrl.trim().equals("[idServiceDataUrl]")) {
			throw new IllegalStateException("idServiceDataUrl cannot be null");
		}
		if (this.mediaServiceBaseUrl == null || 
				this.mediaServiceBaseUrl.trim().equals("") ||
				this.mediaServiceBaseUrl.trim().equals("[mediaServiceBaseUrl]")) {
			throw new IllegalStateException("mediaServiceBaseUrl cannot be null");
		}
		if (this.mediaServiceDataUrl == null || 
				this.mediaServiceDataUrl.trim().equals("") ||
				this.mediaServiceDataUrl.trim().equals("[mediaServiceDataUrl]")) {
			throw new IllegalStateException("mediaServiceDataUrl cannot be null");
		}
		if (this.cascadingUpdatesEnabled == null) {
			throw new IllegalStateException("cascadingUpdatesEnabled cannot be null");
		}
		
	}
	
	@ManagedAttribute(description = "Url to Entity Data Service for obtaining entity resources")
	public String getEntityServiceBaseUrl() {
		return entityServiceBaseUrl;
	}

	public void setEntityServiceBaseUrl(String entityServiceBaseUrl) {
		this.entityServiceBaseUrl = entityServiceBaseUrl;
	}

	@ManagedAttribute(description = "Url to Entity Data Service data subcontext")
	public String getEntityServiceDataUrl() {
		return entityServiceDataUrl;
	}

	public void setEntityServiceDataUrl(String entityServiceDataUrl) {
		this.entityServiceDataUrl = entityServiceDataUrl;
	}

	@ManagedAttribute(description = "Url to Linear Data Service for obtaining linear resources")
	public String getLinearServiceBaseUrl() {
		return linearServiceBaseUrl;
	}

	public void setLinearServiceBaseUrl(String linearServiceBaseUrl) {
		this.linearServiceBaseUrl = linearServiceBaseUrl;
	}

	@ManagedAttribute(description = "Url to Linear Data Service data subcontext")
	public String getLinearServiceDataUrl() {
		return linearServiceDataUrl;
	}

	public void setLinearServiceDataUrl(String linearServiceDataUrl) {
		this.linearServiceDataUrl = linearServiceDataUrl;
	}

	@ManagedAttribute(description = "Url to ID Data Service for obtaining id resources")
	public String getIdServiceBaseUrl() {
		return idServiceBaseUrl;
	}

	public void setIdServiceBaseUrl(String idServiceBaseUrl) {
		this.idServiceBaseUrl = idServiceBaseUrl;
	}

	@ManagedAttribute(description = "Url to ID Data Service data subcontext")
	public String getIdServiceDataUrl() {
		return idServiceDataUrl;
	}

	public void setIdServiceDataUrl(String idServiceDataUrl) {
		this.idServiceDataUrl = idServiceDataUrl;
	}

	@ManagedAttribute(description = "Url to Media Data Service data resources")
	public String getMediaServiceBaseUrl() {
		return mediaServiceBaseUrl;
	}

	public void setMediaServiceBaseUrl(String mediaServiceBaseUrl) {
		this.mediaServiceBaseUrl = mediaServiceBaseUrl;
	}

	@ManagedAttribute(description = "Url to Media Data Service data subcontext")
	public String getMediaServiceDataUrl() {
		return mediaServiceDataUrl;
	}

	public void setMediaServiceDataUrl(String mediaServiceDataUrl) {
		this.mediaServiceDataUrl = mediaServiceDataUrl;
	}

	public Boolean getCascadingUpdatesEnabled() {
		return cascadingUpdatesEnabled;
	}

	public void setCascadingUpdatesEnabled(Boolean cascadingUpdatesEnabled) {
		this.cascadingUpdatesEnabled = cascadingUpdatesEnabled;
	}
}
