package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseSongAssociationField;

public class AlbumReleaseSongAssociationAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(AlbumReleaseSongAssociationField.albumReleaseId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseSongAssociationField.albumReleaseId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseSongAssociationField.songId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseSongAssociationField.songId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseSongAssociationField.trackNumber, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseSongAssociationField.trackNumber, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseSongAssociationField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseSongAssociationField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
