package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.ProgramSongAssociationField;

public class ProgramSongAssociationAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(ProgramSongAssociationField.programId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramSongAssociationField.programId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramSongAssociationField.songId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramSongAssociationField.songId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramSongAssociationField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramSongAssociationField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramSongAssociationField.programType, Relationship.Owned, Access.ReadOnly);
        addAccessMap(ProgramSongAssociationField.programType, Relationship.Other, Access.ReadOnly);

        addAccessMap(ProgramSongAssociationField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramSongAssociationField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
