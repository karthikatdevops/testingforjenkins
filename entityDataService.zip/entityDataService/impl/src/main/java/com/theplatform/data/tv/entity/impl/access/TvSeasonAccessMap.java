package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.TvSeasonField;

public class TvSeasonAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(TvSeasonField.seriesId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(TvSeasonField.seriesId, Relationship.Other, Access.ReadWrite);

        addAccessMap(TvSeasonField.tvSeasonNumber, Relationship.Owned, Access.ReadWrite);
        addAccessMap(TvSeasonField.tvSeasonNumber, Relationship.Other, Access.ReadWrite);

        addAccessMap(TvSeasonField.startYear, Relationship.Owned, Access.ReadWrite);
        addAccessMap(TvSeasonField.startYear, Relationship.Other, Access.ReadWrite);

        addAccessMap(TvSeasonField.endYear, Relationship.Owned, Access.ReadWrite);
        addAccessMap(TvSeasonField.endYear, Relationship.Other, Access.ReadWrite);

        addAccessMap(TvSeasonField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(TvSeasonField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
