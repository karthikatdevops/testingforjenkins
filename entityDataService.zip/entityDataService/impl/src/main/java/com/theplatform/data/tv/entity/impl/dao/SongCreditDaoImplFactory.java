package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class SongCreditDaoImplFactory extends BaseDataServiceDaoFactory<SongCreditDaoImpl> {

	/** @return a new {@link SongCreditDaoImpl} instance. */
	protected SongCreditDaoImpl createInstance() {
		return new SongCreditDaoImpl();
	}

}
