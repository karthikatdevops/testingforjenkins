package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/22/15
 */
public class EntityMessageDaoImplFactory extends BaseDataServiceDaoFactory<EntityMessageDaoImpl> {

    @Override
    protected EntityMessageDaoImpl createInstance() {
        return new EntityMessageDaoImpl();
    }
}
