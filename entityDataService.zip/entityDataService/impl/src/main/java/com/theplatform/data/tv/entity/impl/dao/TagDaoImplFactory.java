package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class TagDaoImplFactory extends BaseDataServiceDaoFactory<TagDaoImpl> {

	/** @return a new {@link TagDaoImpl} instance. */
	protected TagDaoImpl createInstance() {
		return new TagDaoImpl();
	}

}
