package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.SportsEventField;

public class SportsEventAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(SportsEventField.city, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsEventField.city, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsEventField.conference, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsEventField.conference, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsEventField.country, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsEventField.country, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsEventField.division, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsEventField.division, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsEventField.programIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SportsEventField.programIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(SportsEventField.imageIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SportsEventField.imageIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(SportsEventField.mainImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SportsEventField.mainImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(SportsEventField.selectedImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SportsEventField.selectedImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(SportsEventField.leagueId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsEventField.leagueId, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsEventField.sportType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsEventField.sportType, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsEventField.state, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsEventField.state, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsEventField.venue, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsEventField.venue, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsEventField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsEventField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
