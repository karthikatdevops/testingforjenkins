package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.ProgramRankField;

public class ProgramRankAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(ProgramRankField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramRankField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramRankField.rank, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramRankField.rank, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramRankField.programId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramRankField.programId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramRankField.program, Relationship.Owned, Access.ReadOnly);
        addAccessMap(ProgramRankField.program, Relationship.Other, Access.ReadOnly);

        addAccessMap(ProgramRankField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramRankField.merlinResourceType, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramRankField.validAsOf, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramRankField.validAsOf, Relationship.Other, Access.ReadWrite);
    }

}
