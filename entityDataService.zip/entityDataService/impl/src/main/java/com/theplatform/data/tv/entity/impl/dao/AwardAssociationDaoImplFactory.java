package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class AwardAssociationDaoImplFactory extends BaseDataServiceDaoFactory<AwardAssociationDaoImpl> {

	/** @return a new {@link AwardAssociationDaoImpl} instance. */
	protected AwardAssociationDaoImpl createInstance() {
		return new AwardAssociationDaoImpl();
	}

}
