package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.VideogameField;

public class VideogameAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {
        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(DataObjectField.title, Relationship.Owned, Access.ReadWrite);
        addAccessMap(DataObjectField.title, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.shortTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.shortTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.mediumTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.mediumTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.longTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.longTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.shortSynopsis, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.shortSynopsis, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.mediumSynopsis, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.mediumSynopsis, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.longSynopsis, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.longSynopsis, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.nativeId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.nativeId, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.releaseDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.releaseDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.attributionString, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.attributionString, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.singlePlayer, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.singlePlayer, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.multiPlayer, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.multiPlayer, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.minPlayers, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.minPlayers, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.maxPlayers, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.maxPlayers, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.languages, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.languages, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.contentRatings, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.contentRatings, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(VideogameField.merlinResourceType, Relationship.Other, Access.ReadWrite);

        addAccessMap(VideogameField.tagIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(VideogameField.tagIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(VideogameField.selectedImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(VideogameField.selectedImages, Relationship.Other, Access.ReadOnly);
    }

}
