package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.CreditField;

public class CreditAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(CreditField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(CreditField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(CreditField.partName, Relationship.Owned, Access.ReadWrite);
        addAccessMap(CreditField.partName, Relationship.Other, Access.ReadWrite);

        addAccessMap(CreditField.rank, Relationship.Owned, Access.ReadWrite);
        addAccessMap(CreditField.rank, Relationship.Other, Access.ReadWrite);

        addAccessMap(CreditField.cameo, Relationship.Owned, Access.ReadWrite);
        addAccessMap(CreditField.cameo, Relationship.Other, Access.ReadWrite);

        addAccessMap(CreditField.active, Relationship.Owned, Access.ReadWrite);
        addAccessMap(CreditField.active, Relationship.Other, Access.ReadWrite);

        addAccessMap(CreditField.entityId, Relationship.Owned, Access.ReadOnly);
        addAccessMap(CreditField.entityId, Relationship.Other, Access.ReadOnly);

        // Link to Program
        addAccessMap(CreditField.programId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(CreditField.programId, Relationship.Other, Access.ReadWrite);

        addAccessMap(CreditField.program, Relationship.Owned, Access.ReadOnly);
        addAccessMap(CreditField.program, Relationship.Other, Access.ReadOnly);

        // Link to Person
        addAccessMap(CreditField.personId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(CreditField.personId, Relationship.Other, Access.ReadWrite);

        addAccessMap(CreditField.person, Relationship.Owned, Access.ReadOnly);
        addAccessMap(CreditField.person, Relationship.Other, Access.ReadOnly);

        addAccessMap(CreditField.imageIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(CreditField.imageIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(CreditField.mainImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(CreditField.mainImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(CreditField.selectedImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(CreditField.selectedImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(CreditField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(CreditField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
