package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseField;

public class AlbumReleaseAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(AlbumReleaseField.sortTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.sortTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.copyrightInfo, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.copyrightInfo, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.productForm, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.productForm, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.soundType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.soundType, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.domesticImport, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.domesticImport, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.duration, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.duration, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.releaseDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.releaseDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.distributionDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.distributionDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.discontinuedDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.discontinuedDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.albumId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.albumId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.labelCompanyId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.labelCompanyId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.distributorCompanyId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.distributorCompanyId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.mainRelease, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.mainRelease, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.contentRatings, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.contentRatings, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumReleaseField.imageIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(AlbumReleaseField.imageIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(AlbumReleaseField.tagIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(AlbumReleaseField.tagIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(AlbumReleaseField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumReleaseField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
