package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class RelatedAlbumDaoImplFactory extends BaseDataServiceDaoFactory<RelatedAlbumDaoImpl> {

	/** @return a new {@link RelatedAlbumDaoImpl} instance. */
	protected RelatedAlbumDaoImpl createInstance() {
		return new RelatedAlbumDaoImpl();
	}

}
