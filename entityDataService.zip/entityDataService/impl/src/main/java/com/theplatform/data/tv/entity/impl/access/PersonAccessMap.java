package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.PersonField;

public class PersonAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(PersonField.name, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.name, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.birthName, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.birthName, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.sortName, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.sortName, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.birth, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.birth, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.death, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.death, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.shortBio, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.shortBio, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.mediumBio, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.mediumBio, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.longBio, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.longBio, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.birthplace, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.birthplace, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.personType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.personType, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.knownFor, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.knownFor, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.aliases, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.aliases, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonField.credits, Relationship.Owned, Access.ReadOnly);
        addAccessMap(PersonField.credits, Relationship.Other, Access.ReadOnly);

        addAccessMap(PersonField.imageIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(PersonField.imageIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(PersonField.mainImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(PersonField.mainImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(PersonField.selectedImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(PersonField.selectedImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(PersonField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
