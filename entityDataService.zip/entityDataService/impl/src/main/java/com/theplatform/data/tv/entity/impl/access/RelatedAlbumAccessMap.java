package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.RelatedAlbumField;

public class RelatedAlbumAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(RelatedAlbumField.sourceAlbumId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedAlbumField.sourceAlbumId, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedAlbumField.targetAlbumId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedAlbumField.targetAlbumId, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedAlbumField.rank, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedAlbumField.rank, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedAlbumField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedAlbumField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedAlbumField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedAlbumField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
