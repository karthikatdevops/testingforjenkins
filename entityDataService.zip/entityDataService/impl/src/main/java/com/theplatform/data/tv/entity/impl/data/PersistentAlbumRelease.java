package com.theplatform.data.tv.entity.impl.data;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Where;

import com.theplatform.contrib.data.persistence.api.PersistentDefaultManagedMerlinDataObject;
import com.theplatform.contrib.service.data.PersistentRating;
import com.theplatform.data.tv.image.impl.data.PersistentImageAssociation;

@Entity
@org.hibernate.annotations.Entity(dynamicUpdate = true)
@Table(name = "ALBUMRELEASE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class PersistentAlbumRelease extends PersistentDefaultManagedMerlinDataObject {
	
    private String sortTitle;
    private String copyrightInfo;
    private String productForm;
    private String soundType;
    private String domesticImport;
    private Integer duration;
    private Integer releaseDate;
    private Integer releaseYear;  //this field is used for byReleaseYear
    private Integer distributionDate;
    private Integer discontinuedDate;
    private Long albumId;
    private Long labelCompanyId;
    private Long distributorCompanyId;
    private Boolean mainRelease;
    
    private List<PersistentRating> contentRatings = new ArrayList<>();
    
    private List<PersistentEntityTagAssociation> tagAssociations;
    
    private List<PersistentAlbumReleaseSongAssociation> albumReleaseSongAssociations;
    
    @Override
    @Column(name = "title")
    public String getTitle() {
    	return super.getTitle();
    }
    
    @Override
    @Column(name = "description")
    public String getDescription() {
    	return super.getDescription();
    }
    
    @Column(name = "sort_title")
    public String getSortTitle() {
		return sortTitle;
	}

	public void setSortTitle(String sortTitle) {
		this.sortTitle = sortTitle;
	}

	@Column(name = "copyright_info")
	public String getCopyrightInfo() {
		return copyrightInfo;
	}

	public void setCopyrightInfo(String copyrightInfo) {
		this.copyrightInfo = copyrightInfo;
	}

	@Column(name = "product_form")
	public String getProductForm() {
		return productForm;
	}

	public void setProductForm(String productForm) {
		this.productForm = productForm;
	}

	@Column(name = "sound_type")
	public String getSoundType() {
		return soundType;
	}

	public void setSoundType(String soundType) {
		this.soundType = soundType;
	}

	@Column(name = "domestic_import")
	public String getDomesticImport() {
		return domesticImport;
	}

	public void setDomesticImport(String domesticImport) {
		this.domesticImport = domesticImport;
	}

	@Column(name = "duration")
	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	@Column(name = "release_date")
	public Integer getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Integer releaseDate) {
		this.releaseDate = releaseDate;
	}

	@Column(name = "release_year")
	public Integer getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(Integer releaseYear) {
		this.releaseYear = releaseYear;
	}

	@Column(name = "distribution_date")
	public Integer getDistributionDate() {
		return distributionDate;
	}

	public void setDistributionDate(Integer distributionDate) {
		this.distributionDate = distributionDate;
	}

	@Column(name = "discontinue_date")
	public Integer getDiscontinuedDate() {
		return discontinuedDate;
	}

	public void setDiscontinuedDate(Integer discontinuedDate) {
		this.discontinuedDate = discontinuedDate;
	}

	@Column(name = "album_id")
	public Long getAlbumId() {
		return albumId;
	}

	public void setAlbumId(Long albumId) {
		this.albumId = albumId;
	}

	@Column(name = "label_company_id")
	public Long getLabelCompanyId() {
		return labelCompanyId;
	}

	public void setLabelCompanyId(Long labelCompanyId) {
		this.labelCompanyId = labelCompanyId;
	}

	@Column(name = "distributor_company_id")
	public Long getDistributorCompanyId() {
		return distributorCompanyId;
	}

	public void setDistributorCompanyId(Long distributorCompanyId) {
		this.distributorCompanyId = distributorCompanyId;
	}

	@Column(name = "main_release")
	public Boolean getMainRelease() {
		return mainRelease;
	}

	public void setMainRelease(Boolean mainRelease) {
		this.mainRelease = mainRelease;
	}

	@ElementCollection(fetch = FetchType.LAZY)
	@JoinTable(name = "ALBUMRELEASECONTENTRATING", joinColumns=@JoinColumn(name = "album_release_id", nullable = false))
	@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
	public List<PersistentRating> getContentRatings() {
		return contentRatings;
	}

	public void setContentRatings(List<PersistentRating> contentRatings) {
		this.contentRatings = contentRatings;
	}

	@OneToMany(targetEntity = PersistentEntityTagAssociation.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "entity_id", insertable = false, updatable = false)
	@Where(clause = "entity_type = 'AlbumRelease' and merlin_resource_type = 0")
	@org.hibernate.annotations.BatchSize(size = 50)
    public List<PersistentEntityTagAssociation> getTagAssociations() {
		return tagAssociations;
	}

	public void setTagAssociations(
			List<PersistentEntityTagAssociation> tagAssociations) {
		this.tagAssociations = tagAssociations;
	}

    @OneToMany(targetEntity = PersistentAlbumReleaseSongAssociation.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "album_release_id", insertable = false, updatable = false)
    @Where(clause = "merlin_resource_type = 0")
	public List<PersistentAlbumReleaseSongAssociation> getAlbumReleaseSongAssociations() {
		return albumReleaseSongAssociations;
	}

	public void setAlbumReleaseSongAssociations(
			List<PersistentAlbumReleaseSongAssociation> albumReleaseSongAssociations) {
		this.albumReleaseSongAssociations = albumReleaseSongAssociations;
	}

	@Override
    public String toString() {
        return String.format("Persistent AlbumRelease");
    }
}
