package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;
import com.theplatform.data.tv.entity.impl.data.PersistentEntityMessage;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/22/15
 */
public interface EntityMessageDao<Q extends Query, S extends Sort> extends DataServiceDao<PersistentEntityMessage, Long, Q, S> {
}

