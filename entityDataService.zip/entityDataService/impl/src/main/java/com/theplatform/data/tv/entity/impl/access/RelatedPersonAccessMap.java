package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.RelatedPersonField;

public class RelatedPersonAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(RelatedPersonField.sourcePersonId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedPersonField.sourcePersonId, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedPersonField.targetPersonId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedPersonField.targetPersonId, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedPersonField.startDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedPersonField.startDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedPersonField.endDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedPersonField.endDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedPersonField.rank, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedPersonField.rank, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedPersonField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedPersonField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedPersonField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedPersonField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
