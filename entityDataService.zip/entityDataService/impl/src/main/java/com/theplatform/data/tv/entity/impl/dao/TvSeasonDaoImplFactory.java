package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class TvSeasonDaoImplFactory extends BaseDataServiceDaoFactory<TvSeasonDaoImpl> {

	/** @return a new {@link TvSeasonDaoImpl} instance. */
	protected TvSeasonDaoImpl createInstance() {
		return new TvSeasonDaoImpl();
	}

}
