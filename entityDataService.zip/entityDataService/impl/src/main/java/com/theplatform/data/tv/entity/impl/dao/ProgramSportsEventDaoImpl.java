package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.data.persistence.dao.DbHintDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentProgramSportsEvent;

public class ProgramSportsEventDaoImpl extends DbHintDao<PersistentProgramSportsEvent,Long> implements ProgramSportsEventDao<HibernateCriteriaQuery,HibernateSort> {

}
