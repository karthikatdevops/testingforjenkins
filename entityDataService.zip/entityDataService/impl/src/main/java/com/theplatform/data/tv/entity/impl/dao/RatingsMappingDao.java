package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;
import com.theplatform.data.tv.entity.impl.data.PersistentRatingsMapping;

/**
 * Created by lemuri200 on 5/29/15.
 */
public interface RatingsMappingDao<Q extends Query, S extends Sort> extends DataServiceDao<PersistentRatingsMapping, Long, Q, S> {}

