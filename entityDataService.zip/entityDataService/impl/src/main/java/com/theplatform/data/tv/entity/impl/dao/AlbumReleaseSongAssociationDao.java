package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;
import com.theplatform.data.tv.entity.impl.data.PersistentAlbumReleaseSongAssociation;

public interface AlbumReleaseSongAssociationDao<Q extends Query, S extends Sort>
	extends DataServiceDao<PersistentAlbumReleaseSongAssociation, Long, Q, S> {}
