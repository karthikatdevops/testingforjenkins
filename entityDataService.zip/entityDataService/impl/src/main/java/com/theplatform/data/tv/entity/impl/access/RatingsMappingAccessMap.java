package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.RatingsMappingField;

/**
 * Created by lemuri200 on 6/1/15.
 */
public class RatingsMappingAccessMap extends ManagedMerlinDataObjectAccessMap {
    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(RatingsMappingField.sourceRatingSystem, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RatingsMappingField.sourceRatingSystem, Relationship.Other, Access.ReadWrite);

        addAccessMap(RatingsMappingField.targetRatingSystem, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RatingsMappingField.targetRatingSystem, Relationship.Other, Access.ReadWrite);

        addAccessMap(RatingsMappingField.ratingsMap, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RatingsMappingField.ratingsMap, Relationship.Other, Access.ReadWrite);

        addAccessMap(RatingsMappingField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RatingsMappingField.merlinResourceType, Relationship.Other, Access.ReadWrite);

    }
}
