package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.tv.entity.impl.data.PersistentSong;
import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;

public interface SongDao<Q extends Query, S extends Sort>
	extends DataServiceDao<PersistentSong, Long, Q, S> {}
