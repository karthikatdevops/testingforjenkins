package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class ProgramSongAssociationDaoImplFactory extends BaseDataServiceDaoFactory<ProgramSongAssociationDaoImpl> {

	/** @return a new {@link ProgramSongAssociationDaoImpl} instance. */
	protected ProgramSongAssociationDaoImpl createInstance() {
		return new ProgramSongAssociationDaoImpl();
	}

}
