package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class ProgramDaoImplFactory extends BaseDataServiceDaoFactory<ProgramDaoImpl> {

	/** @return a new {@link ProgramDaoImpl} instance. */
	protected ProgramDaoImpl createInstance() {
		return new ProgramDaoImpl();
	}

}
