package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.data.persistence.dao.DbHintDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentRelatedProgram;

public class RelatedProgramDaoImpl extends DbHintDao<PersistentRelatedProgram,Long> implements RelatedProgramDao<HibernateCriteriaQuery,HibernateSort> {

}
