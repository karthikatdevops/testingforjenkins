package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.tv.entity.impl.data.PersistentProgram;
import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;

public interface ProgramDao <Q extends Query, S extends Sort>
	extends DataServiceDao<PersistentProgram, Long, Q, S> {}
