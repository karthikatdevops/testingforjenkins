package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.service.FilterableBaseDataServiceDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentRatingsMapping;

/**
 * Created by lemuri200 on 5/29/15.
 */

public class RatingsMappingDaoImpl extends FilterableBaseDataServiceDao<PersistentRatingsMapping, Long>
        implements RatingsMappingDao<HibernateCriteriaQuery, HibernateSort> {
}
