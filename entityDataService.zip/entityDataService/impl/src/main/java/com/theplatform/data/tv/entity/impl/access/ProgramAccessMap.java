package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.ProgramField;

public class ProgramAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(DataObjectField.title, Relationship.Owned, Access.ReadWrite);
        addAccessMap(DataObjectField.title, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.year, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.year, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.longSynopsis, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.longSynopsis, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.shortSynopsis, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.shortSynopsis, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.mediumSynopsis, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.mediumSynopsis, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.runtime, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.runtime, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.language, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.language, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.contentRating, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.contentRating, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.contentRatings, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.contentRatings, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.shortTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.shortTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.mediumTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.mediumTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.longTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.longTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.local, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.local, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.partNumber, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.partNumber, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.totalParts, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.totalParts, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.sortTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.sortTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.starRating, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.starRating, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.category, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.category, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.firstRunCompanyId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.firstRunCompanyId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.adult, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.adult, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.merlinResourceType, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.listByTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.listByTitle, Relationship.Other, Access.ReadWrite);

        // Collections
        addAccessMap(ProgramField.imageIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(ProgramField.imageIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(ProgramField.tagIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(ProgramField.tagIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(ProgramField.tags, Relationship.Owned, Access.ReadOnly);
        addAccessMap(ProgramField.tags, Relationship.Other, Access.ReadOnly);

        addAccessMap(ProgramField.credits, Relationship.Owned, Access.ReadOnly);
        addAccessMap(ProgramField.credits, Relationship.Other, Access.ReadOnly);

        addAccessMap(ProgramField.mainImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(ProgramField.mainImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(ProgramField.selectedImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(ProgramField.selectedImages, Relationship.Other, Access.ReadOnly);

        // Movie fields
        addAccessMap(ProgramField.releaseDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.releaseDate, Relationship.Other, Access.ReadWrite);

        // Episode fields
        addAccessMap(ProgramField.seriesId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.seriesId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.tvSeasonId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.tvSeasonId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.originalAirDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.originalAirDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.tvSeasonNumber, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.tvSeasonNumber, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.tvSeasonEpisodeNumber, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.tvSeasonEpisodeNumber, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.seriesEpisodeNumber, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.seriesEpisodeNumber, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.episodeTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.episodeTitle, Relationship.Other, Access.ReadWrite);

        // Series fields
        addAccessMap(ProgramField.firstAirDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.firstAirDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramField.lastAirDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.lastAirDate, Relationship.Other, Access.ReadWrite);

        //SportingEvent field
        addAccessMap(ProgramField.sportsSubtitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.sportsSubtitle, Relationship.Other, Access.ReadWrite);

        //productionEpisodeNumber field
        addAccessMap(ProgramField.productionEpisodeNumber, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramField.productionEpisodeNumber, Relationship.Other, Access.ReadWrite);

    }

}
