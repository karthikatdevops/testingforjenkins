package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class AwardDaoImplFactory extends BaseDataServiceDaoFactory<AwardDaoImpl> {

	/** @return a new {@link AwardDaoImpl} instance. */
	protected AwardDaoImpl createInstance() {
		return new AwardDaoImpl();
	}

}
