package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

/**
 * Created by lemuri200 on 5/29/15.
 */
public class RatingsMappingDaoImplFactory extends BaseDataServiceDaoFactory<RatingsMappingDaoImpl> {

    /**
     * @return a new {@link RatingsMappingDaoImpl} instance.
     */
    protected RatingsMappingDaoImpl createInstance() {
        return new RatingsMappingDaoImpl();
    }

}