package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.tv.entity.impl.data.PersistentCredit;
import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;

public interface CreditDao<Q extends Query, S extends Sort>
	extends DataServiceDao<PersistentCredit, Long, Q, S> {}
