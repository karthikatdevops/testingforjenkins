package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.service.FilterableBaseDataServiceDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentSportsTeam;

public class SportsTeamDaoImpl extends FilterableBaseDataServiceDao<PersistentSportsTeam, Long>
        implements SportsTeamDao<HibernateCriteriaQuery, HibernateSort> {
}
