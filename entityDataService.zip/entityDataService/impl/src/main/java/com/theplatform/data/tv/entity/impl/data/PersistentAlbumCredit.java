package com.theplatform.data.tv.entity.impl.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.theplatform.contrib.data.persistence.api.PersistentDefaultManagedMerlinDataObject;

@Entity
@org.hibernate.annotations.Entity(dynamicUpdate = true)
@Table(name = "ALBUMCREDIT")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class PersistentAlbumCredit extends PersistentDefaultManagedMerlinDataObject {

    private String type;
    private Integer rank;
    private Boolean active;
    private Long personId;
    private Long albumId;


    @Column(name = "person_id")
    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

	@Column(name = "type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Column(name = "rank")
    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    @Column(name = "active")
    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    @Column(name = "album_id")
    public Long getAlbumId() {
		return albumId;
	}

	public void setAlbumId(Long albumId) {
		this.albumId = albumId;
	}

	@Override
    public String toString() {
        return String.format("Persistent AlbumCredit");
    }
}
