package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.data.persistence.dao.DbHintDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentSportsLeague;

public class SportsLeagueDaoImpl extends DbHintDao<PersistentSportsLeague,Long> implements SportsLeagueDao<HibernateCriteriaQuery,HibernateSort> {

}
