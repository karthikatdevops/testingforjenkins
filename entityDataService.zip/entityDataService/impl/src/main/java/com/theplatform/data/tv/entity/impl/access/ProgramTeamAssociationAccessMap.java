package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.ProgramTeamAssociationField;

public class ProgramTeamAssociationAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(ProgramTeamAssociationField.programId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramTeamAssociationField.programId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramTeamAssociationField.sportsTeamId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramTeamAssociationField.sportsTeamId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramTeamAssociationField.homeAway, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramTeamAssociationField.homeAway, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramTeamAssociationField.competition, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramTeamAssociationField.competition, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramTeamAssociationField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramTeamAssociationField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
