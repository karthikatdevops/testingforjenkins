package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.SongCollectionField;

public class SongCollectionAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(SongCollectionField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCollectionField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongCollectionField.subtype, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCollectionField.subtype, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongCollectionField.songIds, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCollectionField.songIds, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongCollectionField.primarySongId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCollectionField.primarySongId, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongCollectionField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCollectionField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
