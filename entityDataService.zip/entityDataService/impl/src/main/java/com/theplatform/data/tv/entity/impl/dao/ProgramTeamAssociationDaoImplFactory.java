package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class ProgramTeamAssociationDaoImplFactory extends BaseDataServiceDaoFactory<ProgramTeamAssociationDaoImpl> {

	/** @return a new {@link ProgramTeamAssociationDaoImpl} instance. */
	protected ProgramTeamAssociationDaoImpl createInstance() {
		return new ProgramTeamAssociationDaoImpl();
	}


}
