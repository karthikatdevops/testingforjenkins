package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.TagField;

public class TagAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(TagField.name, Relationship.Owned, Access.ReadOnly);
        addAccessMap(TagField.name, Relationship.Other, Access.ReadOnly);

        addAccessMap(TagField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(TagField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(TagField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(TagField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
