package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class EntityCollectionDaoImplFactory extends BaseDataServiceDaoFactory<EntityCollectionDaoImpl> {

	/** @return a new {@link EntityCollectionDaoImpl} instance. */
	protected EntityCollectionDaoImpl createInstance() {
		return new EntityCollectionDaoImpl();
	}

}
