package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.service.FilterableBaseDataServiceDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentEntityCollection;

public class EntityCollectionDaoImpl extends FilterableBaseDataServiceDao<PersistentEntityCollection, Long>
        implements EntityCollectionDao<HibernateCriteriaQuery, HibernateSort> {
}
