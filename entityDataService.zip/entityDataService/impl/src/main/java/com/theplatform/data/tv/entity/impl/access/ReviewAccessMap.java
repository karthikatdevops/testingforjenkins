package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.ReviewField;

public class ReviewAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(ReviewField.contentRatings, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ReviewField.contentRatings, Relationship.Other, Access.ReadWrite);

        addAccessMap(ReviewField.programId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ReviewField.programId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ReviewField.provider, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ReviewField.provider, Relationship.Other, Access.ReadWrite);

        addAccessMap(ReviewField.recommendation, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ReviewField.recommendation, Relationship.Other, Access.ReadWrite);

        addAccessMap(ReviewField.review, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ReviewField.review, Relationship.Other, Access.ReadWrite);

        addAccessMap(ReviewField.source, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ReviewField.source, Relationship.Other, Access.ReadWrite);

        addAccessMap(ReviewField.starRating, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ReviewField.starRating, Relationship.Other, Access.ReadWrite);

        addAccessMap(ReviewField.summary, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ReviewField.summary, Relationship.Other, Access.ReadWrite);

        addAccessMap(ReviewField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ReviewField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
