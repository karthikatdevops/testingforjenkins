package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.SongCreditField;

public class SongCreditAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(SongCreditField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCreditField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongCreditField.rank, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCreditField.rank, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongCreditField.active, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCreditField.active, Relationship.Other, Access.ReadWrite);

        // Link to Song
        addAccessMap(SongCreditField.songId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCreditField.songId, Relationship.Other, Access.ReadWrite);

        // Link to Person
        addAccessMap(SongCreditField.personId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCreditField.personId, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongCreditField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongCreditField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
