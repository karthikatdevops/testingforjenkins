package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;
import com.theplatform.data.tv.entity.impl.data.PersistentProgramSportsEvent;

public interface ProgramSportsEventDao <Q extends Query, S extends Sort>
		extends DataServiceDao<PersistentProgramSportsEvent, Long, Q, S> {

}
