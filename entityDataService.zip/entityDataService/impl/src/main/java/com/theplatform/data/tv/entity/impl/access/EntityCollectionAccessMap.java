package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.EntityCollectionField;

public class EntityCollectionAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(EntityCollectionField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityCollectionField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(EntityCollectionField.subtype, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityCollectionField.subtype, Relationship.Other, Access.ReadWrite);

        addAccessMap(EntityCollectionField.primaryEntities, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityCollectionField.primaryEntities, Relationship.Other, Access.ReadWrite);

        addAccessMap(EntityCollectionField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityCollectionField.merlinResourceType, Relationship.Other, Access.ReadWrite);

        addAccessMap(EntityCollectionField.entityIds, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityCollectionField.entityIds, Relationship.Other, Access.ReadWrite);

        addAccessMap(EntityCollectionField.imageIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(EntityCollectionField.imageIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(EntityCollectionField.mainImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(EntityCollectionField.mainImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(EntityCollectionField.selectedImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(EntityCollectionField.selectedImages, Relationship.Other, Access.ReadOnly);

    }

}
