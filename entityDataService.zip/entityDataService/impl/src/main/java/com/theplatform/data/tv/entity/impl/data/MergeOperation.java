package com.theplatform.data.tv.entity.impl.data;

public enum MergeOperation {
	Append,
	Remove
}