package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class SongCollectionDaoImplFactory extends BaseDataServiceDaoFactory<SongCollectionDaoImpl> {

	/** @return a new {@link SongCollectionDaoImpl} instance. */
	protected SongCollectionDaoImpl createInstance() {
		return new SongCollectionDaoImpl();
	}

}
