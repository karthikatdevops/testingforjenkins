package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class InstitutionDaoImplFactory extends BaseDataServiceDaoFactory<InstitutionDaoImpl> {

	/** @return a new {@link InstitutionDaoImpl} instance. */
	protected InstitutionDaoImpl createInstance() {
		return new InstitutionDaoImpl();
	}

}
