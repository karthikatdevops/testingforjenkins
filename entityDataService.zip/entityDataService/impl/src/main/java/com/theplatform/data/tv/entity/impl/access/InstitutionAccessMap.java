package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.InstitutionField;

public class InstitutionAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(InstitutionField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(InstitutionField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
