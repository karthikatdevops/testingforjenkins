package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class RelatedProgramDaoImplFactory extends BaseDataServiceDaoFactory<RelatedProgramDaoImpl> {

	/** @return a new {@link RelatedProgramDaoImpl} instance. */
	protected RelatedProgramDaoImpl createInstance() {
		return new RelatedProgramDaoImpl();
	}

}
