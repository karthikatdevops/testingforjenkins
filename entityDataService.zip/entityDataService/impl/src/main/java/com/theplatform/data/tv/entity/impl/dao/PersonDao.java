package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.tv.entity.impl.data.PersistentPerson;
import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;

public interface PersonDao<Q extends Query, S extends Sort>
	extends DataServiceDao<PersistentPerson, Long, Q, S> {}
