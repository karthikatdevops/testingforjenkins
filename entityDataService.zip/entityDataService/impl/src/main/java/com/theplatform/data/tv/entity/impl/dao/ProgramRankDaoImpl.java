package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.data.persistence.dao.DbHintDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentProgramRank;

public class ProgramRankDaoImpl extends DbHintDao<PersistentProgramRank,Long> implements ProgramRankDao<HibernateCriteriaQuery,HibernateSort> {

}
