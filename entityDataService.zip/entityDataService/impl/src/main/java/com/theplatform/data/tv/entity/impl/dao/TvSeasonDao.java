package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.tv.entity.impl.data.PersistentTvSeason;
import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;

public interface TvSeasonDao<Q extends Query, S extends Sort>
	extends DataServiceDao<PersistentTvSeason, Long, Q, S> {}
