package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.PersonTeamAssociationField;

/**
 * Created by Rama Sudalayandi on 12/10/15.
 */
public class PersonTeamAssociationAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(PersonTeamAssociationField.personId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonTeamAssociationField.personId, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonTeamAssociationField.sportsTeamId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonTeamAssociationField.sportsTeamId, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonTeamAssociationField.nativeId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonTeamAssociationField.nativeId, Relationship.Other, Access.ReadWrite);

        addAccessMap(PersonTeamAssociationField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(PersonTeamAssociationField.merlinResourceType, Relationship.Other, Access.ReadWrite);

    }

}
