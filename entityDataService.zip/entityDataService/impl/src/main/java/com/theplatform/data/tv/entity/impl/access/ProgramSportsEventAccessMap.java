package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.ProgramSportsEventField;

public class ProgramSportsEventAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(ProgramSportsEventField.programId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramSportsEventField.programId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramSportsEventField.sportsEventId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramSportsEventField.sportsEventId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramSportsEventField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramSportsEventField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
