package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class SportsEventDaoImplFactory extends BaseDataServiceDaoFactory<SportsEventDaoImpl> {

	/** @return a new {@link SportsEventDaoImpl} instance. */
	protected SportsEventDaoImpl createInstance() {
		return new SportsEventDaoImpl();
	}

}
