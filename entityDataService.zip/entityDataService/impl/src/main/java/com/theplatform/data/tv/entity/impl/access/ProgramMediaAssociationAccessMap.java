package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.ProgramMediaAssociationField;

public class ProgramMediaAssociationAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(ProgramMediaAssociationField.programId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.programId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.mediaGuid, Relationship.Owned, Access.ReadOnly);
        addAccessMap(ProgramMediaAssociationField.mediaGuid, Relationship.Other, Access.ReadOnly);

        addAccessMap(ProgramMediaAssociationField.distributionId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.distributionId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.contentAssetId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.contentAssetId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.titlePaid, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.titlePaid, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.titleAssetId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.titleAssetId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.providerId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.providerId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.programType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.programType, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.merlinResourceType, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.provider, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.provider, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.companyId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.companyId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.companies, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.companies, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.availableDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.availableDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.expirationDate, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.expirationDate, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.mediaId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.mediaId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.mezzanineMediaId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.mezzanineMediaId, Relationship.Other, Access.ReadWrite);

        addAccessMap(ProgramMediaAssociationField.categoryPaths, Relationship.Owned, Access.ReadWrite);
        addAccessMap(ProgramMediaAssociationField.categoryPaths, Relationship.Other, Access.ReadWrite);
    }

}
