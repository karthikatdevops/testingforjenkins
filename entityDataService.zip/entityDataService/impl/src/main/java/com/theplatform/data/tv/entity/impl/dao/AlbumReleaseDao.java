package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;
import com.theplatform.data.tv.entity.impl.data.PersistentAlbumRelease;

public interface AlbumReleaseDao<Q extends Query, S extends Sort>
	extends DataServiceDao<PersistentAlbumRelease, Long, Q, S> {}
