package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class CreditDaoImplFactory extends BaseDataServiceDaoFactory<CreditDaoImpl> {
	
	/** @return a new {@link CreditDaoImpl} instance. */
	protected CreditDaoImpl createInstance() {
		return new CreditDaoImpl();
	}

}
