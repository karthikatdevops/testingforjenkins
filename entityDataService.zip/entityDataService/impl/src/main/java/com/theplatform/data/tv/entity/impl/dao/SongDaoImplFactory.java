package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class SongDaoImplFactory extends BaseDataServiceDaoFactory<SongDaoImpl> {
	
	/** @return a new {@link SongDaoImpl} instance. */
	protected SongDaoImpl createInstance() {
		return new SongDaoImpl();
	}

}
