package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.SportsTeamField;

public class SportsTeamAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(SportsTeamField.city, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.city, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.coach, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.coach, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.coachPersonId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.coachPersonId, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.conference, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.conference, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.country, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.country, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.division, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.division, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.gender, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.gender, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.imageIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SportsTeamField.imageIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(SportsTeamField.mainImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SportsTeamField.mainImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(SportsTeamField.selectedImages, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SportsTeamField.selectedImages, Relationship.Other, Access.ReadOnly);

        addAccessMap(SportsTeamField.leagueId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.leagueId, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.parentSportsTeamId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.parentSportsTeamId, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.nickName, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.nickName, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.representingName, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.representingName, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.sportType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.sportType, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.state, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.state, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.venue, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.venue, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.merlinResourceType, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.abbreviation, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.abbreviation, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.shortBio, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.shortBio, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.mediumBio, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.mediumBio, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.longBio, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SportsTeamField.longBio, Relationship.Other, Access.ReadWrite);

        addAccessMap(SportsTeamField.tagIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SportsTeamField.tagIds, Relationship.Other, Access.ReadOnly);
    }

}
