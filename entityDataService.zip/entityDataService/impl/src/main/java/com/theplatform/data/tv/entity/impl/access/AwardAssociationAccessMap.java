package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.AwardAssociationField;

public class AwardAssociationAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(AwardAssociationField.year, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AwardAssociationField.year, Relationship.Other, Access.ReadWrite);

        addAccessMap(AwardAssociationField.awardStatus, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AwardAssociationField.awardStatus, Relationship.Other, Access.ReadWrite);

        addAccessMap(AwardAssociationField.awardType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AwardAssociationField.awardType, Relationship.Other, Access.ReadWrite);

        addAccessMap(AwardAssociationField.awardId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AwardAssociationField.awardId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AwardAssociationField.institutionId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AwardAssociationField.institutionId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AwardAssociationField.programId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AwardAssociationField.programId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AwardAssociationField.personId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AwardAssociationField.personId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AwardAssociationField.awardShowId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AwardAssociationField.awardShowId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AwardAssociationField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AwardAssociationField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
