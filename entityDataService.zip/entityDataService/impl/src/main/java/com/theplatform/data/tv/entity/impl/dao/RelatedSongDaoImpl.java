package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.data.persistence.dao.DbHintDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentRelatedSong;

public class RelatedSongDaoImpl extends DbHintDao<PersistentRelatedSong, Long>
		implements RelatedSongDao<HibernateCriteriaQuery, HibernateSort>{

}
