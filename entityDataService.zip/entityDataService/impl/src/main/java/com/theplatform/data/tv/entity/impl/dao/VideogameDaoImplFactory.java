package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class VideogameDaoImplFactory extends BaseDataServiceDaoFactory<VideogameDaoImpl> {

    /**
     * @return a new {@link VideogameDaoImpl} instance.
     */
    protected VideogameDaoImpl createInstance() {
        return new VideogameDaoImpl();
    }

}
