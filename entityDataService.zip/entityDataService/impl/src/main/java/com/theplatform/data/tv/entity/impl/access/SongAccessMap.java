package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.SongField;

public class SongAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(DataObjectField.title, Relationship.Owned, Access.ReadWrite);
        addAccessMap(DataObjectField.title, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongField.sortTitle, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongField.sortTitle, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongField.isrc, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongField.isrc, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongField.duration, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongField.duration, Relationship.Other, Access.ReadWrite);

        addAccessMap(SongField.primaryPersonIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SongField.primaryPersonIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(SongField.imageIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SongField.imageIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(SongField.tagIds, Relationship.Owned, Access.ReadOnly);
        addAccessMap(SongField.tagIds, Relationship.Other, Access.ReadOnly);

        addAccessMap(SongField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(SongField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
