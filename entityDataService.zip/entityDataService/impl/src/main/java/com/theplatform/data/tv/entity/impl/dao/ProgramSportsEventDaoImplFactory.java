package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class ProgramSportsEventDaoImplFactory extends BaseDataServiceDaoFactory<ProgramSportsEventDaoImpl> {

	/** @return a new {@link ProgramSportsEventDaoImpl} instance. */
	protected ProgramSportsEventDaoImpl createInstance() {
		return new ProgramSportsEventDaoImpl();
	}

}
