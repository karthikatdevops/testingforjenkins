package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.service.FilterableBaseDataServiceDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentEntityMessage;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/22/15
 */
public class EntityMessageDaoImpl extends FilterableBaseDataServiceDao<PersistentEntityMessage, Long>
        implements EntityMessageDao<HibernateCriteriaQuery, HibernateSort> {
}