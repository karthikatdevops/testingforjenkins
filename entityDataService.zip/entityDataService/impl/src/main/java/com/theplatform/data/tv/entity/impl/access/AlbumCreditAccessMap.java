package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.AlbumCreditField;

public class AlbumCreditAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(AlbumCreditField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumCreditField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumCreditField.rank, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumCreditField.rank, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumCreditField.active, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumCreditField.active, Relationship.Other, Access.ReadWrite);

        // Link to Album
        addAccessMap(AlbumCreditField.albumId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumCreditField.albumId, Relationship.Other, Access.ReadWrite);

        // Link to Person
        addAccessMap(AlbumCreditField.personId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumCreditField.personId, Relationship.Other, Access.ReadWrite);

        addAccessMap(AlbumCreditField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(AlbumCreditField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
