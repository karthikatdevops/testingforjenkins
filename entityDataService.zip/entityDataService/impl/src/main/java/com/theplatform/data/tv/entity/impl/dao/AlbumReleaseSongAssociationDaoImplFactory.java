package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class AlbumReleaseSongAssociationDaoImplFactory extends BaseDataServiceDaoFactory<AlbumReleaseSongAssociationDaoImpl> {

	/** @return a new {@link AlbumReleaseSongAssociationDaoImpl} instance. */
	protected AlbumReleaseSongAssociationDaoImpl createInstance() {
		return new AlbumReleaseSongAssociationDaoImpl();
	}

}
