package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class ProgramMediaAssociationDaoImplFactory extends BaseDataServiceDaoFactory<ProgramMediaAssociationDaoImpl> {

	/** @return a new {@link ProgramMediaAssociationDaoImpl} instance. */
	protected ProgramMediaAssociationDaoImpl createInstance() {
		return new ProgramMediaAssociationDaoImpl();
	}

}
