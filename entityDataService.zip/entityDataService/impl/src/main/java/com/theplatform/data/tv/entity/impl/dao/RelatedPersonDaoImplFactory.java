package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class RelatedPersonDaoImplFactory extends BaseDataServiceDaoFactory<RelatedPersonDaoImpl> {

	/** @return a new {@link RelatedPersonDaoImpl} instance. */
	protected RelatedPersonDaoImpl createInstance() {
		return new RelatedPersonDaoImpl();
	}

}
