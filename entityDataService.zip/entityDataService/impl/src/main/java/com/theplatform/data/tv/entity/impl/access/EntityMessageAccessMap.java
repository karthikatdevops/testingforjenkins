package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.EntityMessageField;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/22/15
 */
public class EntityMessageAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(EntityMessageField.entityId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityMessageField.entityId, Relationship.Other, Access.ReadWrite);

        addAccessMap(EntityMessageField.freeText, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityMessageField.freeText, Relationship.Other, Access.ReadWrite);

        addAccessMap(EntityMessageField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityMessageField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(EntityMessageField.priority, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityMessageField.priority, Relationship.Other, Access.ReadWrite);

        addAccessMap(EntityMessageField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(EntityMessageField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }
}