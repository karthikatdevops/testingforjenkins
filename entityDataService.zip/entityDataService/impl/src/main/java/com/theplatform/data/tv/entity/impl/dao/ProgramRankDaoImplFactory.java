package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class ProgramRankDaoImplFactory extends BaseDataServiceDaoFactory<ProgramRankDaoImpl> {

	/** @return a new {@link ProgramRankDaoImpl} instance. */
	protected ProgramRankDaoImpl createInstance() {
		return new ProgramRankDaoImpl();
	}

}
