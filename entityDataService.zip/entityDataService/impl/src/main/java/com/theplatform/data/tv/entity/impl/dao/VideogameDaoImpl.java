package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.service.FilterableBaseDataServiceDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentVideogame;

public class VideogameDaoImpl extends FilterableBaseDataServiceDao<PersistentVideogame, Long>
        implements VideogameDao<HibernateCriteriaQuery, HibernateSort> {
}
