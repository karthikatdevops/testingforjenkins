package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class RelatedSongDaoImplFactory extends BaseDataServiceDaoFactory<RelatedSongDaoImpl> {

	/** @return a new {@link RelatedSongDaoImpl} instance. */
	protected RelatedSongDaoImpl createInstance() {
		return new RelatedSongDaoImpl();
	}

}
