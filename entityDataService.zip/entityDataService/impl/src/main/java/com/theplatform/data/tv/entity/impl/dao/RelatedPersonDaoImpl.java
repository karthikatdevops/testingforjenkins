package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.data.persistence.dao.DbHintDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentRelatedPerson;

public class RelatedPersonDaoImpl extends DbHintDao<PersistentRelatedPerson, Long>
		implements RelatedPersonDao<HibernateCriteriaQuery, HibernateSort>{

}
