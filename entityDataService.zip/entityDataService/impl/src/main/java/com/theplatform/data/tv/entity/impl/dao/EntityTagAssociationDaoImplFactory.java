package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class EntityTagAssociationDaoImplFactory extends BaseDataServiceDaoFactory<EntityTagAssociationDaoImpl> {

	@Override
	protected EntityTagAssociationDaoImpl createInstance() {
		return new EntityTagAssociationDaoImpl();
	}

}