package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class SportsLeagueDaoImplFactory extends BaseDataServiceDaoFactory<SportsLeagueDaoImpl> {

	/** @return a new {@link SportsLeagueDaoImpl} instance. */
	protected SportsLeagueDaoImpl createInstance() {
		return new SportsLeagueDaoImpl();
	}

}
