package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.contrib.data.persistence.dao.DbHintDao;
import com.theplatform.data.persistence.query.criteria.HibernateCriteriaQuery;
import com.theplatform.data.persistence.sort.HibernateSort;
import com.theplatform.data.tv.entity.impl.data.PersistentEntityTagAssociation;

public class EntityTagAssociationDaoImpl extends DbHintDao<PersistentEntityTagAssociation, Long>
	implements EntityTagAssociationDao<HibernateCriteriaQuery, HibernateSort> {

}
