package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.DataServiceDao;
import com.theplatform.data.persistence.query.Query;
import com.theplatform.data.persistence.sort.Sort;
import com.theplatform.data.tv.entity.impl.data.PersistentSongCollection;

public interface SongCollectionDao<Q extends Query, S extends Sort>
	extends DataServiceDao<PersistentSongCollection, Long, Q, S> {}
