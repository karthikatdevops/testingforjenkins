package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class AlbumReleaseDaoImplFactory extends BaseDataServiceDaoFactory<AlbumReleaseDaoImpl> {

	/** @return a new {@link AlbumReleaseDaoImpl} instance. */
	protected AlbumReleaseDaoImpl createInstance() {
		return new AlbumReleaseDaoImpl();
	}

}
