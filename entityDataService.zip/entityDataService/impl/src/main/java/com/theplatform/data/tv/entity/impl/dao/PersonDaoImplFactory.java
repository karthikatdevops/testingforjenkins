package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class PersonDaoImplFactory extends BaseDataServiceDaoFactory<PersonDaoImpl> {
	
	/** @return a new {@link PersonDaoImpl} instance. */
	protected PersonDaoImpl createInstance() {
		return new PersonDaoImpl();
	}

}
