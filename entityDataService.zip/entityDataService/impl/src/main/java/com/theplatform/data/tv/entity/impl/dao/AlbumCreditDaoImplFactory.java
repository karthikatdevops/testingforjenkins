package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class AlbumCreditDaoImplFactory extends BaseDataServiceDaoFactory<AlbumCreditDaoImpl> {

	/** @return a new {@link AlbumCreditDaoImpl} instance. */
	protected AlbumCreditDaoImpl createInstance() {
		return new AlbumCreditDaoImpl();
	}

}
