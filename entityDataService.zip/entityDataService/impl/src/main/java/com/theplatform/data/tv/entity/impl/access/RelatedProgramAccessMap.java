package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.RelatedProgramField;

public class RelatedProgramAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(RelatedProgramField.sourceProgramId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedProgramField.sourceProgramId, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedProgramField.sourceProgram, Relationship.Owned, Access.ReadOnly);
        addAccessMap(RelatedProgramField.sourceProgram, Relationship.Other, Access.ReadOnly);

        addAccessMap(RelatedProgramField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedProgramField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedProgramField.targetProgramId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedProgramField.targetProgramId, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedProgramField.targetProgram, Relationship.Owned, Access.ReadOnly);
        addAccessMap(RelatedProgramField.targetProgram, Relationship.Other, Access.ReadOnly);

        addAccessMap(RelatedProgramField.justification, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedProgramField.justification, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedProgramField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedProgramField.merlinResourceType, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedProgramField.rank, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedProgramField.rank, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedProgramField.score, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedProgramField.score, Relationship.Other, Access.ReadWrite);
    }

}
