package com.theplatform.data.tv.entity.impl.access;

import com.theplatform.contrib.data.impl.access.ManagedMerlinDataObjectAccessMap;
import com.theplatform.data.persistence.access.Access;
import com.theplatform.data.persistence.api.Relationship;
import com.theplatform.data.tv.entity.api.fields.RelatedSongField;

public class RelatedSongAccessMap extends ManagedMerlinDataObjectAccessMap {

    @Override
    public void initializeMap() {

        // add field relationship -> access maps for superclass properties
        super.initializeMap();

        addAccessMap(RelatedSongField.sourceSongId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedSongField.sourceSongId, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedSongField.targetSongId, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedSongField.targetSongId, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedSongField.rank, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedSongField.rank, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedSongField.type, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedSongField.type, Relationship.Other, Access.ReadWrite);

        addAccessMap(RelatedSongField.merlinResourceType, Relationship.Owned, Access.ReadWrite);
        addAccessMap(RelatedSongField.merlinResourceType, Relationship.Other, Access.ReadWrite);
    }

}
