package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class ReviewDaoImplFactory extends BaseDataServiceDaoFactory<ReviewDaoImpl> {

	/** @return a new {@link ReviewDaoImpl} instance. */
	protected ReviewDaoImpl createInstance() {
		return new ReviewDaoImpl();
	}

}
