package com.theplatform.data.tv.entity.impl.data;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Where;

import com.theplatform.contrib.data.persistence.api.PersistentDefaultManagedMerlinDataObject;
import com.theplatform.data.tv.image.impl.data.PersistentImageAssociation;

@Entity
@org.hibernate.annotations.Entity(dynamicUpdate = true)
@Table(name = "ALBUM")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class PersistentAlbum extends PersistentDefaultManagedMerlinDataObject {

	private String sortTitle;
	
	private String language;
	
	private String country;
	
	private Integer originalReleaseDate;
	
	//this field is extracted from originalReleaseDate, the Year part
	//it is used for byOriginalReleaseYear query
	private Integer originalReleaseYear;
	
	private List<PersistentAlbumCredit> primaryPersonIds;
	
	//this is added for byReleaseId
	private List<PersistentAlbumRelease> albumReleases;
	
	private List<PersistentEntityTagAssociation> tagAssociations;
	
    @Override
    @Column(name = "title")
    public String getTitle() {
        return super.getTitle();
    }

    @Override
    @Column(name = "description")
    public String getDescription() {
        return super.getDescription();
    }

    @Column(name = "sort_title")
	public String getSortTitle() {
		return sortTitle;
	}

	public void setSortTitle(String sortTitle) {
		this.sortTitle = sortTitle;
	}

	@Column(name = "language")
	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	@Column(name = "country")
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Column(name = "original_release_date")
	public Integer getOriginalReleaseDate() {
		return originalReleaseDate;
	}

	public void setOriginalReleaseDate(Integer originalReleaseDate) {
		this.originalReleaseDate = originalReleaseDate;
	}

	@Column(name = "original_release_year")
	public Integer getOriginalReleaseYear() {
		return originalReleaseYear;
	}
	
	public void setOriginalReleaseYear(Integer originalReleaseYear) {
		this.originalReleaseYear = originalReleaseYear;
	}
	
	@OneToMany(targetEntity = PersistentAlbumCredit.class)
	@JoinColumn(name = "album_id", insertable = false, updatable = false)
	@OrderBy(value = "rank")
	@Where(clause = "type='PrimaryArtist' and merlin_resource_type = 0")
	public List<PersistentAlbumCredit> getPrimaryPersonIds() {
		return primaryPersonIds;
	}

	public void setPrimaryPersonIds(List<PersistentAlbumCredit> primaryPersonIds) {
		this.primaryPersonIds = primaryPersonIds;
	}

	@OneToMany(targetEntity = PersistentAlbumRelease.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "album_id", insertable = false, updatable = false)
    @Where(clause = "merlin_resource_type = 0")
	public List<PersistentAlbumRelease> getAlbumReleases() {
		return albumReleases;
	}
	
	public void setAlbumReleases(List<PersistentAlbumRelease> albumReleases) {
		this.albumReleases = albumReleases;
	}
	
	@OneToMany(targetEntity = PersistentEntityTagAssociation.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "entity_id", insertable = false, updatable = false)
	@Where(clause = "entity_type = 'Album' and merlin_resource_type = 0")
	@org.hibernate.annotations.BatchSize(size = 50)
	public List<PersistentEntityTagAssociation> getTagAssociations() {
		return tagAssociations;
	}

	public void setTagAssociations(List<PersistentEntityTagAssociation> tagAssociations) {
		this.tagAssociations = tagAssociations;
	}
}
