package com.theplatform.data.tv.entity.impl.dao;

import com.theplatform.data.persistence.dao.BaseDataServiceDaoFactory;

public class SportsTeamDaoImplFactory extends BaseDataServiceDaoFactory<SportsTeamDaoImpl> {

	/** @return a new {@link SportsTeamDaoImpl} instance. */
	protected SportsTeamDaoImpl createInstance() {
		return new SportsTeamDaoImpl();
	}


}
