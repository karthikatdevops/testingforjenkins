<p><img src="https://github.comcast.com/compass/roxy/blob/master/doc/img/roxy-logo-2.png"></p>  

# Table of Contents
- [Pull roxy image from compass docker hub](#pull-roxy-image-from-compass-docker-hub)  
- [Set up external dependencies](#set-up-external-dependencies)  
    - [consul server](#run-consul-server-docker)
    - [rules](#write-rules)
    - [memcached](#run-memcached-docker)
    - [.env file]()
- [Naming services](#naming-services)  
- [Known issues](#known-issues)  

## pull roxy image from compass docker hub
 + in docker preferences, add insecure repo
<p><img src="https://github.comcast.com/compass/roxy/blob/master/doc/img/adding-docker-hub/add-insecure-repo.png"></p>  
 + login to `maven.compass.chalybs.net` with NT login...  
<p><img src="https://github.comcast.com/compass/roxy/blob/master/doc/img/adding-docker-hub/docker-login.png"></p>  
 + and a `config.json` file should appear in the `~/.docker` directory  
<p><img src="https://github.comcast.com/compass/roxy/blob/master/doc/img/adding-docker-hub/config-json-file-appears.png"></p>  
Now you should be able to `docker pull maven.compass.chalybs.net/dev-roxy:1` image or just run `docker-compose up` from the cloned roxy directory and the image will get pulled.

## set up external dependencies  
### run consul server docker  
```  
sudo docker run -itd \
-h roxy-consul-server \
--name roxy-consul-server \
-p 8300:8300 \
-p 8301:8301 \
-p 8302:8302 \
-p 8400:8400 \
-p 8500:8500 \
-p 8301:8301/udp \
-p 8302:8302/udp \
-p 53:53/udp \
gliderlabs/consul-server \
-bootstrap -advertise replace-this-with-consul-server-host-ip -client 0.0.0.0  
```  
### register services  
For simplicity of the demo, python servers are used here, but they should be replaced with any backed service groups, i.e. instances of ars. 
+ start python servers ("services") 
    + default 
    + one-server-group 
    + two-server-group 

+ register services and their `/healthCheck` using postman  
    + note: services that must be grouped into the same server group have the same names, i.e. both services from `two-server-group` have the `name` attribute set to *"two-server-group"*.  More on that [over here](#naming-services).

### write rules  
See sample rules in [`roxy/test/rules`](https://github.comcast.com/compass/roxy/tree/master/test/rules).  

### run memcached docker
+ run the official `memcached` docker image:
```
docker run --name roxy-memcached -p 11211:11211 -d memcached
```  
+ add memcached key-value pairs to support rules  
    + run script from `roxy/test/memcached/populate-memcache.sh`  

### configure `.env` file  
+ set required environment variables  
+ override nginx defaults, if necessary  

### docker compose  
To start roxy docker container, run:  
```
docker-compose up
```  

## naming services  
What's in a name? A lot, actually.  
+ When a service is registered with consul server, it must be registered with a name:
+ <p><img src="https://github.comcast.com/compass/roxy/blob/master/doc/img/server-group-name/register-service-with-name.png"></p>  
    + Once registered, in consul ui the service will show up like this:  
    <p><img src="https://github.comcast.com/compass/roxy/blob/master/doc/img/server-group-name/service-appears-in-consul.png"></p>  
    + There may need to be multiple services in the same group. In other words, given the same request, these services will return the same response, so they can be in the same `upstream` block in `nginx.conf` file, and nginx can balance the load between them.  To achieve this, these services must be registered with the same name.  Note how the services are being registered with different ids (ids must be unique) but the same name:
    <p><img src="https://github.comcast.com/compass/roxy/blob/master/doc/img/server-group-name/first-service-with-name.png"></p>  
    <p><img src="https://github.comcast.com/compass/roxy/blob/master/doc/img/server-group-name/second-service-with-name.png"></p>  
  * note that consul server groups them by name:
      <p><img src="https://github.comcast.com/compass/roxy/blob/master/doc/img/server-group-name/consul-groups-services.png"></p>  
  * consul-template  
    * sample snippet from the `nginx.conf.ctmpl` file, the consul-template template for `nginx.conf`:
    ```
    {{range services}}
      {{if .Name | regexMatch "^demo-."}}
        {{if service .Name "passing"}}
          upstream {{.Name}} {
            {{range service .Name}}
                server {{.Address}}:{{.Port}};
            {{end}}
          }
        {{end}}
      {{end}}
    {{end}}
    ```
    This will iterate through all services available from consul server, and for each group of those whose name starts with `demo-`, it will create an `upstream` block in the `nginx.conf` file.  In our case, that will result in:  
    ```
    upstream demo-default {      
      server 10.251.17.150:1111;
    }
          
    upstream demo-one-server-group {      
      server 10.251.17.150:2222;
    }

    upstream demo-two-server-group {      
      server 10.251.17.150:3333;
      server 10.251.17.150:4444;
    }
    ```
    consul-template constantly watches the changes in services and if a service becomes unavailable (i.e. its healthcheck goes into a status other than `passing`), it regenerates the `nginx.conf` file and roxy restarts with the new config, thus taking the failing service out of rotation.  Similarly, if a new `passing` service is added, it is added in the same fashion.  
  * memcached
    * when key-value pairs are stored in memcached to support existing rules, the `value` should be the `destination` for the request, and it has to match the upstream / server-group name so that when nginx tries to proxy to the url `proxy_pass        http://$url;` the value of the $url matches with one of the existing `upstream` groups.

## known issues  
### ARP table caching problem  
For background on this issue, read the `Issue with quickly restarting a node using the same IP` section [here](https://hub.docker.com/r/progrium/consul/).  To clear the connection table, run:  
```
docker run --net=host --privileged --rm cap10morgan/conntrack -F
```

