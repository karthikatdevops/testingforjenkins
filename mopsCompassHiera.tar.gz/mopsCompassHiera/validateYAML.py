#!/usr/bin/env python

# Morgan Wallace
# 2016

import os, sys
import yaml, json

d = {}
d['blanks'] = []
d['badYAML'] = []
d['badPath'] = []
d['badKeys'] = []
for root, dirs, files in os.walk('.'):
    for item in files:
        path = os.path.join(root,item)
        if ".yaml" in path:
            try:
                #print path
                fin = open (path, 'r')
                yamlDict = yaml.load(fin)
                fin.close() 
                for key in yamlDict:
                    if "." in key:
                        d['badKeys'].append({path: key})
                    value = yamlDict[key] #Try and use data inside dict
            except TypeError:
                d['blanks'].append(path)
            except yaml.scanner.ScannerError:
                d['badYAML'].append(path)
            except IOError:
                d['badPath'].append(path)

print (json.dumps(d, indent=2, sort_keys=True))

if len(d['badYAML']) != 0:
    print "Failing due to at least one bad YAML file"
    sys.exit(1)
else:
    sys.exit(0)