#! /bin/bash
. ../environ
mvn pre-integration-test jetty:run
