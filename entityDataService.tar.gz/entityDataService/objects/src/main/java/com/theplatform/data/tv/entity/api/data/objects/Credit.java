package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.List;
import java.util.Map;

/**
 * Representation of a Credit.
 */
public final class Credit extends DefaultManagedMerlinDataObject {

    /**
     * Auto-generated serialVersionUID
     */
    private static final long serialVersionUID = 1L;
    private String type;
    private String partName;
    private Integer rank;
    private Boolean cameo;
    private URI personId;
    private PersonAssociation person;
    private URI programId;
    private ProgramAssociation program;
    private Boolean active;
    private List<MainImageInfo> selectedImages;

    @Deprecated
    private URI entityId;
    @Deprecated
    private List<URI> imageIds;
    @Deprecated
    private Map<String, MediaFile> mainImages;

    public URI getPersonId() {
        return personId;
    }

    public void setPersonId(URI personId) {
        this.personId = personId;
    }

    public PersonAssociation getPerson() {
        return person;
    }

    public void setPerson(PersonAssociation person) {
        this.person = person;
    }

    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    public ProgramAssociation getProgram() {
        return program;
    }

    public void setProgram(ProgramAssociation program) {
        this.program = program;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Boolean getCameo() {
        return cameo;
    }

    public void setCameo(Boolean cameo) {
        this.cameo = cameo;
    }

    public List<MainImageInfo> getSelectedImages() {
        return selectedImages;
    }

    public void setSelectedImages(List<MainImageInfo> selectedImages) {
        this.selectedImages = selectedImages;
    }

    @Override
    public String toString() {
        return String.format("%s: %s [%s]", this.getType(), this.getPartName(), this.getId());
    }

    @Deprecated
    public URI getEntityId() {
        return entityId;
    }

    @Deprecated
    public void setEntityId(URI entityId) {
        this.entityId = entityId;
    }

    @Deprecated
    public List<URI> getImageIds() {
        return imageIds;
    }

    @Deprecated
    public void setImageIds(List<URI> imageIds) {
        this.imageIds = imageIds;
    }

    @Deprecated
    public Map<String, MediaFile> getMainImages() {
        return mainImages;
    }

    @Deprecated
    public void setMainImages(Map<String, MediaFile> mainImages) {
        this.mainImages = mainImages;
    }
}
