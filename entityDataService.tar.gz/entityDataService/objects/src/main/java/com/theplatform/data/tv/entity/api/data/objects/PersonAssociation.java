package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.data.api.objects.type.DateOnly;

import java.io.Serializable;
import java.net.URI;

public class PersonAssociation implements Serializable {

    private static final long serialVersionUID = -4764839793527556554L;

    private String name;
    private DateOnly birth;
    private URI personId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DateOnly getBirth() {
        return birth;
    }

    public void setBirth(DateOnly birth) {
        this.birth = birth;
    }

    public URI getPersonId() {
        return personId;
    }

    public void setPersonId(URI personId) {
        this.personId = personId;
    }

    @Override
    public String toString() {
        return String.format("%s [%s]", this.getName(), this.getPersonId());
    }

}
