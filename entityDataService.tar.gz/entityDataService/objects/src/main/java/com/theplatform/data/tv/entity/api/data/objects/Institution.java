package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

public class Institution extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = 1217044119391229070L;

    @Override
    public String toString() {
        return this.getTitle() + "\n" + super.getDescription();
    }

}
