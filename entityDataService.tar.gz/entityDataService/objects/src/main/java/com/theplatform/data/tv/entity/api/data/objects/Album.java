package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.api.objects.type.DateOnly;

import java.net.URI;
import java.util.List;

public class Album extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = -7977453167013514704L;

    private String sortTitle;

    private String language;

    private String country;

    private DateOnly originalReleaseDate;

    private List<URI> primaryPersonIds;

    @Deprecated
    private List<URI> imageIds;

    private List<URI> tagIds;

    public String getSortTitle() {
        return sortTitle;
    }

    public void setSortTitle(String sortTitle) {
        this.sortTitle = sortTitle;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public DateOnly getOriginalReleaseDate() {
        return originalReleaseDate;
    }

    public void setOriginalReleaseDate(DateOnly originalReleaseDate) {
        this.originalReleaseDate = originalReleaseDate;
    }

    public List<URI> getPrimaryPersonIds() {
        return primaryPersonIds;
    }

    public void setPrimaryPersonIds(List<URI> primaryPersonIds) {
        this.primaryPersonIds = primaryPersonIds;
    }

    @Deprecated
    public List<URI> getImageIds() {
        return imageIds;
    }

    @Deprecated
    public void setImageIds(List<URI> imageIds) {
        this.imageIds = imageIds;
    }

    public List<URI> getTagIds() {
        return tagIds;
    }

    public void setTagIds(List<URI> tagIds) {
        this.tagIds = tagIds;
    }


}
