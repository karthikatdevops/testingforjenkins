package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.contrib.data.api.objects.EsrbRating;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.net.URI;
import java.util.List;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 11/26/14
 */
public class Videogame extends DefaultManagedMerlinDataObject {

    private String shortTitle;
    private String mediumTitle;
    private String longTitle;
    private String shortSynopsis;
    private String mediumSynopsis;
    private String longSynopsis;
    private String type;
    private String nativeId;
    private DateOnly releaseDate;
    private String attributionString;
    private Boolean singlePlayer;
    private Boolean multiPlayer;
    private Integer minPlayers;
    private Integer maxPlayers;

    // Collections
    private List<String> languages;
    private List<EsrbRating> contentRatings;
    private List<URI> tagIds;
    private List<MainImageInfo> selectedImages;

    public Videogame() {
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        Videogame rhs = (Videogame) obj;
        return new EqualsBuilder()
                .appendSuper(super.equals(obj))
                .append(shortTitle, rhs.shortTitle)
                .append(mediumTitle, rhs.mediumTitle)
                .append(longTitle, rhs.longTitle)
                .append(shortSynopsis, rhs.shortSynopsis)
                .append(mediumSynopsis, rhs.mediumSynopsis)
                .append(longSynopsis, rhs.longSynopsis)
                .append(type, rhs.type)
                .append(languages, rhs.languages)
                .append(nativeId, rhs.nativeId)
                .append(releaseDate, rhs.releaseDate)
                .append(attributionString, rhs.attributionString)
                .append(singlePlayer, rhs.singlePlayer)
                .append(multiPlayer, rhs.multiPlayer)
                .append(minPlayers, rhs.minPlayers)
                .append(maxPlayers, rhs.maxPlayers)
                .append(contentRatings, rhs.contentRatings)
                .append(tagIds, rhs.tagIds)
                .append(selectedImages, rhs.selectedImages)
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder(83, 47).
                appendSuper(super.hashCode()).
                append(shortTitle).
                append(mediumTitle).
                append(longTitle).
                append(shortSynopsis).
                append(mediumSynopsis).
                append(longSynopsis).
                append(type).
                append(languages).
                append(nativeId).
                append(releaseDate).
                append(attributionString).
                append(singlePlayer).
                append(multiPlayer).
                append(minPlayers).
                append(maxPlayers).
                append(contentRatings).
                append(tagIds).
                append(selectedImages).
                toHashCode();
    }

    public String toString() {
        return new ToStringBuilder(this).
                append("title", getTitle()).
                append("type", type).
                toString();
    }

    public String getShortTitle() {
        return shortTitle;
    }

    public void setShortTitle(String shortTitle) {
        this.shortTitle = shortTitle;
    }

    public String getMediumTitle() {
        return mediumTitle;
    }

    public void setMediumTitle(String mediumTitle) {
        this.mediumTitle = mediumTitle;
    }

    public String getLongTitle() {
        return longTitle;
    }

    public void setLongTitle(String longTitle) {
        this.longTitle = longTitle;
    }

    public String getShortSynopsis() {
        return shortSynopsis;
    }

    public void setShortSynopsis(String shortSynopsis) {
        this.shortSynopsis = shortSynopsis;
    }

    public String getMediumSynopsis() {
        return mediumSynopsis;
    }

    public void setMediumSynopsis(String mediumSynopsis) {
        this.mediumSynopsis = mediumSynopsis;
    }

    public String getLongSynopsis() {
        return longSynopsis;
    }

    public void setLongSynopsis(String longSynopsis) {
        this.longSynopsis = longSynopsis;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getLanguages() {
        return languages;
    }

    public void setLanguages(List<String> languages) {
        this.languages = languages;
    }

    public String getNativeId() {
        return nativeId;
    }

    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }

    public DateOnly getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(DateOnly releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getAttributionString() {
        return attributionString;
    }

    public void setAttributionString(String attributionString) {
        this.attributionString = attributionString;
    }

    public Boolean getSinglePlayer() {
        return singlePlayer;
    }

    public void setSinglePlayer(Boolean singlePlayer) {
        this.singlePlayer = singlePlayer;
    }

    public Boolean getMultiPlayer() {
        return multiPlayer;
    }

    public void setMultiPlayer(Boolean multiPlayer) {
        this.multiPlayer = multiPlayer;
    }

    public Integer getMinPlayers() {
        return minPlayers;
    }

    public void setMinPlayers(Integer minPlayers) {
        this.minPlayers = minPlayers;
    }

    public Integer getMaxPlayers() {
        return maxPlayers;
    }

    public void setMaxPlayers(Integer maxPlayers) {
        this.maxPlayers = maxPlayers;
    }

    public List<EsrbRating> getContentRatings() {
        return contentRatings;
    }

    public void setContentRatings(List<EsrbRating> contentRatings) {
        this.contentRatings = contentRatings;
    }

    public List<URI> getTagIds() {
        return tagIds;
    }

    public void setTagIds(List<URI> tagIds) {
        this.tagIds = tagIds;
    }

    public List<MainImageInfo> getSelectedImages() {
        return selectedImages;
    }

    public void setSelectedImages(List<MainImageInfo> selectedImages) {
        this.selectedImages = selectedImages;
    }
}
