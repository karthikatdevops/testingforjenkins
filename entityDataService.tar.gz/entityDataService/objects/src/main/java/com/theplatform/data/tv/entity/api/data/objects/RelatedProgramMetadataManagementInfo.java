package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;

public class RelatedProgramMetadataManagementInfo extends MetadataManagementInfo {

    private static final long serialVersionUID = -969253257480178620L;

    private String sourceProgramGuid;
    private String targetProgramGuid;

    public String getSourceProgramGuid() {
        return sourceProgramGuid;
    }

    public void setSourceProgramGuid(String sourceProgramGuid) {
        this.sourceProgramGuid = sourceProgramGuid;
    }

    public String getTargetProgramGuid() {
        return targetProgramGuid;
    }

    public void setTargetProgramGuid(String targetProgramGuid) {
        this.targetProgramGuid = targetProgramGuid;
    }

}
