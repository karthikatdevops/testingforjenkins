package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

import java.net.URI;
import java.util.List;

/**
 * Representation of a SongCollection.
 */
public final class SongCollection extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = 6697487955185570436L;

    private String type;
    private String subtype;
    private URI primarySongId;
    private List<URI> songIds;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public String getSubtype() {
        return subtype;
    }

    public void setSubtype(String subtype) {
        this.subtype = subtype;
    }


    public URI getPrimarySongId() {
        return primarySongId;
    }

    public void setPrimarySongId(URI primarySongId) {
        this.primarySongId = primarySongId;
    }

    public List<URI> getSongIds() {
        return songIds;
    }

    public void setSongIds(List<URI> songIds) {
        this.songIds = songIds;
    }

    @Override
    public String toString() {
        return String.format("SongCollection");
    }

}
