package com.theplatform.data.tv.entity.api.data.objects;


public enum SongCollectionType {
    Variant("Variant");

    private String friendlyName;

    private SongCollectionType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static SongCollectionType getByFriendlyName(String fName) {
        SongCollectionType foundType = null;
        for (SongCollectionType type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        SongCollectionType[] songCollectionTypes = SongCollectionType.values();
        String[] friendlyNames = new String[songCollectionTypes.length];
        for (int index = 0; index < songCollectionTypes.length; index++) {
            friendlyNames[index] = songCollectionTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
