package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.List;
import java.util.Map;

/**
 * Representation of a Person.
 */
public final class Person extends DefaultManagedMerlinDataObject {

    /**
     * Auto-generated serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    private String name;
    private String birthName;
    private String sortName;
    private DateOnly birth;
    private DateOnly death;
    private String shortBio;
    private String mediumBio;
    private String longBio;
    private String birthplace;
    private String personType;
    private List<String> knownFor;
    private List<String> aliases;
    private List<CreditAssociation> credits;
    @Deprecated
    private List<URI> imageIds;
    @Deprecated
    private Map<String, MediaFile> mainImages;
    private List<MainImageInfo> selectedImages;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthName() {
        return birthName;
    }

    public void setBirthName(String birthName) {
        this.birthName = birthName;
    }

    public String getSortName() {
        return sortName;
    }

    public void setSortName(String sortName) {
        this.sortName = sortName;
    }

    public DateOnly getBirth() {
        return birth;
    }

    public void setBirth(DateOnly birth) {
        this.birth = birth;
    }

    public DateOnly getDeath() {
        return death;
    }

    public void setDeath(DateOnly death) {
        this.death = death;
    }

    public String getShortBio() {
        return shortBio;
    }

    public void setShortBio(String shortBio) {
        this.shortBio = shortBio;
    }

    public String getMediumBio() {
        return mediumBio;
    }

    public void setMediumBio(String mediumBio) {
        this.mediumBio = mediumBio;
    }

    public String getLongBio() {
        return longBio;
    }

    public void setLongBio(String longBio) {
        this.longBio = longBio;
    }

    public String getBirthplace() {
        return birthplace;
    }

    public void setBirthplace(String birthplace) {
        this.birthplace = birthplace;
    }

    public List<String> getAliases() {
        return aliases;
    }

    public void setAliases(List<String> aliases) {
        this.aliases = aliases;
    }

    public List<CreditAssociation> getCredits() {
        return credits;
    }

    public void setCredits(List<CreditAssociation> credits) {
        this.credits = credits;
    }

    @Deprecated
    public void setImageIds(List<URI> imageIds) {
        this.imageIds = imageIds;
    }

    @Deprecated
    public List<URI> getImageIds() {
        return imageIds;
    }

    @Deprecated
    public Map<String, MediaFile> getMainImages() {
        return mainImages;
    }

    @Deprecated
    public void setMainImages(Map<String, MediaFile> mainImages) {
        this.mainImages = mainImages;
    }

    public List<MainImageInfo> getSelectedImages() {
        return selectedImages;
    }

    public void setSelectedImages(List<MainImageInfo> selectedImages) {
        this.selectedImages = selectedImages;
    }

    @Override
    public String toString() {
        return String.format("%s [%s]", this.getName(), this.getId());
    }

    public String getPersonType() {
        return personType;
    }

    public void setPersonType(String personType) {
        this.personType = personType;
    }

    public List<String> getKnownFor() {
        return knownFor;
    }

    public void setKnownFor(List<String> knownFor) {
        this.knownFor = knownFor;
    }

}
