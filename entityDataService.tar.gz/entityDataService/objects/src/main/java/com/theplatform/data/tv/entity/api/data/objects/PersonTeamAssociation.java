package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;

import java.net.URI;

/**
 * Created by Rama Sudalayandi on 12/10/15.
 */
public class PersonTeamAssociation extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = -9008247211797384440L;

    private URI personId;
    private URI sportsTeamId;
    private String nativeId;

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getPersonId() {
        return personId;
    }

    public void setPersonId(URI personId) {
        this.personId = personId;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getSportsTeamId() {
        return sportsTeamId;
    }

    public void setSportsTeamId(URI sportsTeamId) {
        this.sportsTeamId = sportsTeamId;
    }

    public String getNativeId() {
        return nativeId;
    }

    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }
}
