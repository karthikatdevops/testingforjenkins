package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.api.objects.type.DateOnly;

import java.net.URI;

public class ProgramRank extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = 6240038893961181321L;

    private Float rank;
    private String type;
    private URI programId;
    private Program program;
    private DateOnly validAsOf;

    public Float getRank() {
        return rank;
    }

    public void setRank(Float rank) {
        this.rank = rank;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public DateOnly getValidAsOf() {
        return validAsOf;
    }

    public void setValidAsOf(DateOnly validAsOf) {
        this.validAsOf = validAsOf;
    }
}
