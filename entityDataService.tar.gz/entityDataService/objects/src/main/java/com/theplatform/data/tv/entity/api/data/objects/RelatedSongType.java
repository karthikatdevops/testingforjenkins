package com.theplatform.data.tv.entity.api.data.objects;


public enum RelatedSongType {
    IsSimilar("IsSimilar");

    private String friendlyName;

    private RelatedSongType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static RelatedSongType getByFriendlyName(String fName) {
        RelatedSongType foundType = null;
        for (RelatedSongType type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        RelatedSongType[] awardTypes = RelatedSongType.values();
        String[] friendlyNames = new String[awardTypes.length];
        for (int index = 0; index < awardTypes.length; index++) {
            friendlyNames[index] = awardTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
