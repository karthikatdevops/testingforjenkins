package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.media.api.data.objects.Rating;

import java.net.URI;
import java.util.List;

public class AlbumRelease extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = -6559669843906303675L;

    private String sortTitle;

    private String copyrightInfo;

    private String productForm;

    private String soundType;

    private String domesticImport;

    private Integer duration;

    private DateOnly releaseDate;

    private DateOnly distributionDate;

    private DateOnly discontinuedDate;

    private URI albumId;

    private URI primaryPersonId;

    private URI labelCompanyId;

    private URI distributorCompanyId;

    private Boolean mainRelease;

    private List<Rating> contentRatings;

    @Deprecated
    private List<URI> imageIds;

    private List<URI> tagIds;

    public String getSortTitle() {
        return sortTitle;
    }

    public void setSortTitle(String sortTitle) {
        this.sortTitle = sortTitle;
    }

    public URI getPrimaryPersonId() {
        return primaryPersonId;
    }

    public void setPrimaryPersonId(URI primaryPersonId) {
        this.primaryPersonId = primaryPersonId;
    }

    @Deprecated
    public List<URI> getImageIds() {
        return imageIds;
    }

    @Deprecated
    public void setImageIds(List<URI> imageIds) {
        this.imageIds = imageIds;
    }

    public List<URI> getTagIds() {
        return tagIds;
    }

    public void setTagIds(List<URI> tagIds) {
        this.tagIds = tagIds;
    }

    public String getCopyrightInfo() {
        return copyrightInfo;
    }

    public void setCopyrightInfo(String copyrightInfo) {
        this.copyrightInfo = copyrightInfo;
    }

    public String getProductForm() {
        return productForm;
    }

    public void setProductForm(String productForm) {
        this.productForm = productForm;
    }

    public String getSoundType() {
        return soundType;
    }

    public void setSoundType(String soundType) {
        this.soundType = soundType;
    }

    public String getDomesticImport() {
        return domesticImport;
    }

    public void setDomesticImport(String domesticImport) {
        this.domesticImport = domesticImport;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public DateOnly getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(DateOnly releaseDate) {
        this.releaseDate = releaseDate;
    }

    public DateOnly getDistributionDate() {
        return distributionDate;
    }

    public void setDistributionDate(DateOnly distributionDate) {
        this.distributionDate = distributionDate;
    }

    public DateOnly getDiscontinuedDate() {
        return discontinuedDate;
    }

    public void setDiscontinuedDate(DateOnly discontinuedDate) {
        this.discontinuedDate = discontinuedDate;
    }

    public URI getAlbumId() {
        return albumId;
    }

    public void setAlbumId(URI albumId) {
        this.albumId = albumId;
    }

    public URI getLabelCompanyId() {
        return labelCompanyId;
    }

    public void setLabelCompanyId(URI labelCompanyId) {
        this.labelCompanyId = labelCompanyId;
    }

    public URI getDistributorCompanyId() {
        return distributorCompanyId;
    }

    public void setDistributorCompanyId(URI distributorCompanyId) {
        this.distributorCompanyId = distributorCompanyId;
    }

    public Boolean getMainRelease() {
        return mainRelease;
    }

    public void setMainRelease(Boolean mainRelease) {
        this.mainRelease = mainRelease;
    }

    public List<Rating> getContentRatings() {
        return contentRatings;
    }

    public void setContentRatings(List<Rating> contentRatings) {
        this.contentRatings = contentRatings;
    }


}
