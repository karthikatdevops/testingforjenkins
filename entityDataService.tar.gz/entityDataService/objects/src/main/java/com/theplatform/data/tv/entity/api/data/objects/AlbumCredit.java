package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

import java.net.URI;

/**
 * Representation of a AlbumCredit.
 */
public final class AlbumCredit extends DefaultManagedMerlinDataObject {


    /**
     *
     */
    private static final long serialVersionUID = -1746454532224518302L;

    private String type;
    private Integer rank;
    private URI personId;
    private URI albumId;
    private Boolean active;

    public URI getPersonId() {
        return personId;
    }

    public void setPersonId(URI personId) {
        this.personId = personId;
    }

    public URI getAlbumId() {
        return albumId;
    }

    public void setAlbumId(URI albumId) {
        this.albumId = albumId;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    @Override
    public String toString() {
        return String.format("%s: %s [%s]", this.getType(), this.getPersonId() + "-" + this.getAlbumId(), this.getId());
    }

}
