package com.theplatform.data.tv.entity.api.data.objects;

public enum ProgramCategory {

    Other("Other"),
    Movie("Movie"),
    Children("Children\'s"),
    News("News"),
    Music("Music"),
    Lifestyle("Lifestyle"),
    Sports("Sports");

    private String friendlyName;

    private ProgramCategory(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return this.friendlyName;
    }

    public static ProgramCategory getByFriendlyName(String friendlyName) {
        ProgramCategory foundType = null;
        for (ProgramCategory type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        ProgramCategory[] programCategories = ProgramCategory.values();
        String[] friendlyNames = new String[programCategories.length];
        for (int index = 0; index < programCategories.length; index++) {
            friendlyNames[index] = programCategories[index].getFriendlyName();
        }
        return friendlyNames;
    }

    @Override
    public String toString() {
        return friendlyName;
    }

}
