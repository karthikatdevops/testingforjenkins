package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

public class Award extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = -1212113469613942749L;

    private Integer rank;

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    @Override
    public String toString() {
        return this.getTitle() + " " + rank + "\n" + super.getDescription();
    }
}
