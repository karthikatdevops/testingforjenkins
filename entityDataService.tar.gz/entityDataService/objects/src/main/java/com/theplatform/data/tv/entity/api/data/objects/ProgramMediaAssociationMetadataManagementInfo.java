package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 6/27/14
 * Time: 6:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProgramMediaAssociationMetadataManagementInfo extends MetadataManagementInfo {

    private List<String> appendCategoryPaths;
    private List<String> removeCategoryPaths;

    public List<String> getAppendCategoryPaths() {
        return appendCategoryPaths;
    }

    public void setAppendCategoryPaths(List<String> appendCategoryPaths) {
        this.appendCategoryPaths = appendCategoryPaths;
    }

    public List<String> getRemoveCategoryPaths() {
        return removeCategoryPaths;
    }

    public void setRemoveCategoryPaths(List<String> removeCategoryPaths) {
        this.removeCategoryPaths = removeCategoryPaths;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((appendCategoryPaths == null) ? 0 : appendCategoryPaths.hashCode());
        result = prime * result + ((removeCategoryPaths == null) ? 0 : removeCategoryPaths.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProgramMediaAssociationMetadataManagementInfo other = (ProgramMediaAssociationMetadataManagementInfo) obj;
        if (appendCategoryPaths == null) {
            if (other.appendCategoryPaths != null)
                return false;
        } else if (!appendCategoryPaths.equals(other.appendCategoryPaths))
            return false;

        if (removeCategoryPaths == null) {
            if (other.removeCategoryPaths != null)
                return false;
        } else if (!removeCategoryPaths.equals(other.removeCategoryPaths))
            return false;

        return true;
    }

    @Override
    public String toString() {
        return super.toString() + "\nProgramMediaAssociationMetadataManagementInfo [appendCategoryPaths=" +
                appendCategoryPaths + ", removeCategoryPaths=" + removeCategoryPaths + "]";
    }
}
