package com.theplatform.data.tv.entity.api.data.objects;

import java.io.Serializable;
import java.net.URI;

public class TagInfo implements Serializable {
    private static final long serialVersionUID = 4000428297303000846L;

    private URI tagId;
    private String name;
    private String type;

    public TagInfo() {

    }

    public TagInfo(URI tagId, String name) {
        this.tagId = tagId;
        this.name = name;
    }

    public TagInfo(URI tagId, String name, String type) {
        this.tagId = tagId;
        this.name = name;
        this.type = type;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof TagInfo)) {
            return false;
        }
        TagInfo ti = (TagInfo) o;

        if (name != null ? !name.equals(ti.name) : ti.name != null) return false;
        if (type != null ? !type.equals(ti.type) : ti.type != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = 31;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        return result;
    }

    public URI getTagId() {
        return tagId;
    }

    public void setTagId(URI tagId) {
        this.tagId = tagId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
