package com.theplatform.data.tv.entity.api.data.objects;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RottenTomatoesRating {
    private final int criticSummaryScore;
    private final int criticSummaryCount;
    private final boolean criticSummaryCertified;
    private final boolean criticSummaryRotten;
    private final int fanSummaryScore;
    private final int fanSummaryCount;

    private static final Pattern PATTERN = Pattern.compile("criticSummaryScore=(-?\\d+),criticSummaryCount=(\\d+),criticSummaryCertified=(false|true),criticSummaryRotten=(false|true),fanSummaryScore=(\\d+),fanSummaryCount=(\\d+)");

    public RottenTomatoesRating(int criticSummaryScore, int criticSummaryCount, boolean criticSummaryCertified, boolean criticSummaryRotten, int fanSummaryScore, int fanSummaryCount) {
        this.criticSummaryScore = criticSummaryScore;
        this.criticSummaryCount = criticSummaryCount;
        this.criticSummaryCertified = criticSummaryCertified;
        this.criticSummaryRotten = criticSummaryRotten;
        this.fanSummaryScore = fanSummaryScore;
        this.fanSummaryCount = fanSummaryCount;
    }

    public static RottenTomatoesRating fromString(String s) {
        Matcher matcher = PATTERN.matcher(s);

        if (!matcher.matches()) {
            throw new IllegalArgumentException("Invalid rating string: " + s);
        }

        int criticSummaryScore = Integer.valueOf(matcher.group(1));
        int criticSummaryCount = Integer.valueOf(matcher.group(2));
        boolean criticSummaryCertified = Boolean.valueOf(matcher.group(3));
        boolean criticSummaryRotten = Boolean.valueOf(matcher.group(4));
        int fanSummaryScore = Integer.valueOf(matcher.group(5));
        int fanSummaryCount = Integer.valueOf(matcher.group(6));

        return new RottenTomatoesRating(criticSummaryScore, criticSummaryCount, criticSummaryCertified,
                criticSummaryRotten, fanSummaryScore, fanSummaryCount);
    }

    @Override
    public String toString() {
        return String.format("criticSummaryScore=%s,criticSummaryCount=%s,criticSummaryCertified=%s,criticSummaryRotten=%s,fanSummaryScore=%s,fanSummaryCount=%s",
                criticSummaryScore, criticSummaryCount, criticSummaryCertified, criticSummaryRotten, fanSummaryScore, fanSummaryCount);
    }

    public int getCriticSummaryScore() {
        return criticSummaryScore;
    }

    public int getCriticSummaryCount() {
        return criticSummaryCount;
    }

    public boolean isCriticSummaryCertified() {
        return criticSummaryCertified;
    }

    public boolean isCriticSummaryRotten() {
        return criticSummaryRotten;
    }

    public int getFanSummaryScore() {
        return fanSummaryScore;
    }

    public int getFanSummaryCount() {
        return fanSummaryCount;
    }
}
