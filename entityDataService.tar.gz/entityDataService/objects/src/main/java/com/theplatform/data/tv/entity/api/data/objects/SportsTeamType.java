package com.theplatform.data.tv.entity.api.data.objects;

public enum SportsTeamType {

    Organization("Organization"),
    Team("Team");

    private String friendlyName;

    private SportsTeamType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static SportsTeamType getByFriendlyName(String friendlyName) {
        SportsTeamType foundType = null;
        for (SportsTeamType type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        SportsTeamType[] sportTypes = SportsTeamType.values();
        String[] friendlyNames = new String[sportTypes.length];
        for (int index = 0; index < sportTypes.length; index++) {
            friendlyNames[index] = sportTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
