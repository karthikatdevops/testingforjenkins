package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

import java.net.URI;
import java.util.Date;

/**
 * Representation of a RelatedPerson.
 */
public final class RelatedPerson extends DefaultManagedMerlinDataObject {


    /**
     *
     */
    private static final long serialVersionUID = 1377690257680163317L;

    private URI sourcePersonId;
    private URI targetPersonId;
    private Date startDate;
    private Date endDate;
    private Integer rank;
    private String type;

    public URI getSourcePersonId() {
        return sourcePersonId;
    }

    public void setSourcePersonId(URI sourcePersonId) {
        this.sourcePersonId = sourcePersonId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public URI getTargetPersonId() {
        return targetPersonId;
    }

    public void setTargetPersonId(URI targetPersonId) {
        this.targetPersonId = targetPersonId;
    }

    @Override
    public String toString() {
        return String.format("RelatedPerson");
    }

}
