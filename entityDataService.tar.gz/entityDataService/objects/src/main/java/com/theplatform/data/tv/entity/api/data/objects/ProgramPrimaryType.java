package com.theplatform.data.tv.entity.api.data.objects;


public enum ProgramPrimaryType {
    Original("Original"),
    English("English"),
    Spanish("Spanish");

    private String friendlyName;

    private ProgramPrimaryType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static ProgramPrimaryType getByFriendlyName(String fName) {
        ProgramPrimaryType foundType = null;
        for (ProgramPrimaryType type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        ProgramPrimaryType[] primaryTypes = ProgramPrimaryType.values();
        String[] friendlyNames = new String[primaryTypes.length];
        for (int index = 0; index < primaryTypes.length; index++) {
            friendlyNames[index] = primaryTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
