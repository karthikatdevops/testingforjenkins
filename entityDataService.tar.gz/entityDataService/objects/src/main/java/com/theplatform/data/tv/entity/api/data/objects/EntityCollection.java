package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.ManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.List;
import java.util.Map;

/**
 * Representation of a EntityCollection.
 */
public final class EntityCollection extends ManagedMerlinDataObject<EntityCollectionMetadataManagementInfo> {

    /**
     * auto-generated UID
     */
    private static final long serialVersionUID = -7151161552747300050L;

    private String type;
    private String subtype;
    private Map<String, URI> primaryEntities;
    private List<URI> entityIds;
    @Deprecated
    private List<URI> imageIds;
    @Deprecated
    private Map<String, MediaFile> mainImages;
    private List<MainImageInfo> selectedImages;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubtype() {
        return subtype;
    }

    public void setSubtype(String subtype) {
        this.subtype = subtype;
    }

    public Map<String, URI> getPrimaryEntities() {
        return primaryEntities;
    }

    public void setPrimaryEntities(Map<String, URI> primaryEntities) {
        this.primaryEntities = primaryEntities;
    }

    @NotificationField(notifyChanges = true, notifyDelete = true)
    public List<URI> getEntityIds() {
        return entityIds;
    }

    public void setEntityIds(List<URI> entityIds) {
        this.entityIds = entityIds;
    }

    @Deprecated
    public List<URI> getImageIds() {
        return imageIds;
    }

    @Deprecated
    public void setImageIds(List<URI> imageIds) {
        this.imageIds = imageIds;
    }

    @Deprecated
    public Map<String, MediaFile> getMainImages() {
        return mainImages;
    }

    @Deprecated
    public void setMainImages(Map<String, MediaFile> mainImages) {
        this.mainImages = mainImages;
    }

    public List<MainImageInfo> getSelectedImages() {
        return selectedImages;
    }

    public void setSelectedImages(List<MainImageInfo> selectedImages) {
        this.selectedImages = selectedImages;
    }

    @Override
    public String toString() {
        return String.format("EntityCollection");
    }

    @Override
    public EntityCollectionMetadataManagementInfo createMetadataManagementInfo() {
        return new EntityCollectionMetadataManagementInfo();
    }

}
