package com.theplatform.data.tv.entity.api.data.objects;

public enum PersonType {

    Person("Person"),
    Band("Band"),
    Organization("Organization");

    private String friendlyName;

    private PersonType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static PersonType getByFriendlyName(String friendlyName) {
        PersonType foundType = null;
        for (PersonType type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
                break;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        PersonType[] personType = PersonType.values();
        String[] friendlyNames = new String[personType.length];
        for (int index = 0; index < personType.length; index++) {
            friendlyNames[index] = personType[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
