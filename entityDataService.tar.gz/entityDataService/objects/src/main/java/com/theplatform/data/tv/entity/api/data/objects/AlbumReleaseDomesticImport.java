package com.theplatform.data.tv.entity.api.data.objects;

public enum AlbumReleaseDomesticImport {

    Domestic("Domestic"),
    Import("Import");

    private String friendlyName;

    private AlbumReleaseDomesticImport(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static AlbumReleaseDomesticImport getByFriendlyName(String friendlyName) {
        AlbumReleaseDomesticImport foundType = null;
        for (AlbumReleaseDomesticImport type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
                break;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        AlbumReleaseDomesticImport[] domesticImport = AlbumReleaseDomesticImport.values();
        String[] friendlyNames = new String[domesticImport.length];
        for (int index = 0; index < domesticImport.length; index++) {
            friendlyNames[index] = domesticImport[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
