package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.ManagedMerlinDataObject;
import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;

import java.net.URI;
import java.util.Date;
import java.util.Set;

public class ProgramMediaAssociation extends ManagedMerlinDataObject<ProgramMediaAssociationMetadataManagementInfo> {

    private static final long serialVersionUID = 1050498738547108715L;

    private URI programId;
    /**
     * Legacy mediaGuid field, replaced by MediaId object field.
     *
     * @deprecated use {@link com.theplatform.contrib.data.api.objects.MediaId} instead.
     */
    @Deprecated //MERLIN-9318: Remove Media Ids from data model for VIDEOS
    private String mediaGuid;
    private URI distributionId;
    private String contentAssetId;
    private String titlePaid;
    private String titleAssetId;
    private String providerId;
    private String provider;
    private URI companyId;
    private Date availableDate;
    private Date expirationDate;
    private MediaId mediaId;
    private MediaId mezzanineMediaId;
    private Set<String> categoryPaths;
    private Set<CompanyInfo> companies;

    private ProgramType programType;

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    @Deprecated
    public String getMediaGuid() {
        return mediaGuid;
    }

    @Deprecated
    public void setMediaGuid(String mediaGuid) {
        this.mediaGuid = mediaGuid;
    }

    public URI getDistributionId() {
        return distributionId;
    }

    public void setDistributionId(URI distributionId) {
        this.distributionId = distributionId;
    }

    public String getContentAssetId() {
        return contentAssetId;
    }

    public void setContentAssetId(String contentAssetId) {
        this.contentAssetId = contentAssetId;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public String getTitlePaid() {
        return titlePaid;
    }

    public void setTitlePaid(String titlePaid) {
        this.titlePaid = titlePaid;
    }

    public String getTitleAssetId() {
        return titleAssetId;
    }

    public void setTitleAssetId(String titleAssetId) {
        this.titleAssetId = titleAssetId;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public ProgramType getProgramType() {
        return programType;
    }

    public void setProgramType(ProgramType programType) {
        this.programType = programType;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public URI getCompanyId() {
        return companyId;
    }

    public void setCompanyId(URI companyId) {
        this.companyId = companyId;
    }

    public Date getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(Date availableDate) {
        this.availableDate = availableDate;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public MediaId getMediaId() {
        return mediaId;
    }

    public void setMediaId(MediaId mediaId) {
        this.mediaId = mediaId;
    }

    public MediaId getMezzanineMediaId() {
        return mezzanineMediaId;
    }

    public void setMezzanineMediaId(MediaId mezzanineMediaId) {
        this.mezzanineMediaId = mezzanineMediaId;
    }

    public Set<String> getCategoryPaths() {
        return categoryPaths;
    }

    public void setCategoryPaths(Set<String> categoryPaths) {
        this.categoryPaths = categoryPaths;
    }

    public Set<CompanyInfo> getCompanies() {
        return companies;
    }

    public void addCompany(CompanyInfo company) {
        this.companies.add(company);
    }

    public void setCompanies(Set<CompanyInfo> companies) {
        this.companies = companies;
    }

    @Override
    public ProgramMediaAssociationMetadataManagementInfo createMetadataManagementInfo() {
        return new ProgramMediaAssociationMetadataManagementInfo();
    }

    @Override
    public String toString() {
        return "ProgramMediaAssociation{" +
                "programId=" + programId +
                ", mediaId=" + mediaId +
                '}';
    }
}
