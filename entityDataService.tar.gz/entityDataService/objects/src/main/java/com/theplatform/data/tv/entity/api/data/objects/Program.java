package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.ManagedMerlinDataObject;
import com.theplatform.contrib.data.api.objects.Rated;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;
import com.theplatform.media.api.data.objects.Rating;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Program extends ManagedMerlinDataObject<ProgramMetadataManagementInfo> implements Rated {

    /**
     * Auto-generated serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    private Integer year;
    private String shortSynopsis;
    private String mediumSynopsis;
    private String longSynopsis;
    private Integer runtime;
    private ProgramType type;
    private String language;
    private Integer partNumber;
    private Integer totalParts;
    private String sortTitle;
    private Integer starRating;
    private String category;
    private DateOnly originalAirDate;
    private URI firstRunCompanyId;
    private Boolean adult;
    private String shortTitle;
    private String mediumTitle;
    private String longTitle;
    private Boolean local;
    private Boolean listByTitle;

    @Deprecated
    private Rating contentRating;

    // Movie-only fields
    private DateOnly releaseDate;

    // Episode-only fields
    private URI seriesId;
    private URI tvSeasonId;
    private Integer tvSeasonNumber;
    private Integer tvSeasonEpisodeNumber;
    private Integer seriesEpisodeNumber;
    private String episodeTitle;
    private String productionEpisodeNumber;

    // Series Master-only fields
    private DateOnly firstAirDate;
    private DateOnly lastAirDate;

    //SportingEvent field
    private String sportsSubtitle;

    // Collections
    private List<Rating> contentRatings;
    private List<CreditAssociation> credits;
    private Set<TagInfo> tags;
    private List<URI> tagIds;
    private List<MainImageInfo> selectedImages;

    @Deprecated
    private List<URI> imageIds;
    @Deprecated
    private Map<String, MediaFile> mainImages;

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getShortSynopsis() {
        return shortSynopsis;
    }

    public void setShortSynopsis(String shortSynopsis) {
        this.shortSynopsis = shortSynopsis;
    }

    public String getMediumSynopsis() {
        return mediumSynopsis;
    }

    public void setMediumSynopsis(String mediumSynopsis) {
        this.mediumSynopsis = mediumSynopsis;
    }

    public String getLongSynopsis() {
        return longSynopsis;
    }

    public void setLongSynopsis(String longSynopsis) {
        this.longSynopsis = longSynopsis;
    }

    public Integer getRuntime() {
        return runtime;
    }

    public void setRuntime(Integer runtime) {
        this.runtime = runtime;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true)
    public ProgramType getType() {
        return type;
    }

    public void setType(ProgramType type) {
        this.type = type;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }


    public Integer getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(Integer partNumber) {
        this.partNumber = partNumber;
    }

    public Integer getTotalParts() {
        return totalParts;
    }

    public void setTotalParts(Integer totalParts) {
        this.totalParts = totalParts;
    }

    public DateOnly getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(DateOnly releaseDate) {
        this.releaseDate = releaseDate;
    }

    public Integer getStarRating() {
        return starRating;
    }

    public void setStarRating(Integer starRating) {
        this.starRating = starRating;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCategory() {
        return category;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getSeriesId() {
        return seriesId;
    }

    public void setSeriesId(URI seriesId) {
        this.seriesId = seriesId;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getTvSeasonId() {
        return tvSeasonId;
    }

    public void setTvSeasonId(URI tvSeasonId) {
        this.tvSeasonId = tvSeasonId;
    }

    public DateOnly getOriginalAirDate() {
        return originalAirDate;
    }

    public void setOriginalAirDate(DateOnly originalAirDate) {
        this.originalAirDate = originalAirDate;
    }

    @NotificationField(notifyChanges = true)
    public void setFirstRunCompanyId(URI firstRunCompanyId) {
        this.firstRunCompanyId = firstRunCompanyId;
    }

    public URI getFirstRunCompanyId() {
        return firstRunCompanyId;
    }

    public Boolean getAdult() {
        return adult;
    }

    public void setAdult(Boolean adult) {
        this.adult = adult;
    }

    @Deprecated
    public Rating getContentRating() {
        return contentRating;
    }

    @Deprecated
    public void setContentRating(Rating contentRating) {
        this.contentRating = contentRating;
    }

    public List<Rating> getContentRatings() {
        return contentRatings;
    }

    public void setContentRatings(List<Rating> contentRatings) {
        this.contentRatings = contentRatings;
    }

    public String getShortTitle() {
        return shortTitle;
    }

    public void setShortTitle(String shortTitle) {
        this.shortTitle = shortTitle;
    }

    public String getMediumTitle() {
        return mediumTitle;
    }

    public void setMediumTitle(String mediumTitle) {
        this.mediumTitle = mediumTitle;
    }

    public String getLongTitle() {
        return longTitle;
    }

    public void setLongTitle(String longTitle) {
        this.longTitle = longTitle;
    }

    public Boolean getLocal() {
        return local;
    }

    public void setLocal(Boolean local) {
        this.local = local;
    }

    public Boolean getListByTitle() {
        return listByTitle;
    }

    public void setListByTitle(Boolean listByTitle) {
        this.listByTitle = listByTitle;
    }

    public Integer getTvSeasonNumber() {
        return tvSeasonNumber;
    }

    public void setTvSeasonNumber(Integer tvSeasonNumber) {
        this.tvSeasonNumber = tvSeasonNumber;
    }

    public Integer getTvSeasonEpisodeNumber() {
        return tvSeasonEpisodeNumber;
    }

    public void setTvSeasonEpisodeNumber(Integer tvSeasonEpisodeNumber) {
        this.tvSeasonEpisodeNumber = tvSeasonEpisodeNumber;
    }

    public Integer getSeriesEpisodeNumber() {
        return seriesEpisodeNumber;
    }

    public void setSeriesEpisodeNumber(Integer seriesEpisodeNumber) {
        this.seriesEpisodeNumber = seriesEpisodeNumber;
    }

    public String getEpisodeTitle() {
        return episodeTitle;
    }

    public void setEpisodeTitle(String episodeTitle) {
        this.episodeTitle = episodeTitle;
    }

    public String getProductionEpisodeNumber() {
        return productionEpisodeNumber;
    }

    public void setProductionEpisodeNumber(String productionEpisodeNumber) {
        this.productionEpisodeNumber = productionEpisodeNumber;
    }

    public DateOnly getFirstAirDate() {
        return firstAirDate;
    }

    public void setFirstAirDate(DateOnly firstAirDate) {
        this.firstAirDate = firstAirDate;
    }

    public DateOnly getLastAirDate() {
        return lastAirDate;
    }

    public void setLastAirDate(DateOnly lastAirDate) {
        this.lastAirDate = lastAirDate;
    }

    public String getSportsSubtitle() {
        return sportsSubtitle;
    }

    public void setSportsSubtitle(String sportsSubtitle) {
        this.sportsSubtitle = sportsSubtitle;
    }

    public String getSortTitle() {
        return sortTitle;
    }

    public void setSortTitle(String sortTitle) {
        this.sortTitle = sortTitle;
    }

    public List<CreditAssociation> getCredits() {
        return credits;
    }

    public void setCredits(List<CreditAssociation> credits) {
        this.credits = credits;
    }

    @Deprecated
    public void setImageIds(List<URI> imageIds) {
        this.imageIds = imageIds;
    }

    @Deprecated
    public List<URI> getImageIds() {
        return imageIds;
    }

    public void setTagIds(List<URI> tagIds) {
        this.tagIds = tagIds;
    }

    public List<URI> getTagIds() {
        return tagIds;
    }

    @Deprecated
    public Map<String, MediaFile> getMainImages() {
        return mainImages;
    }

    @Deprecated
    public void setMainImages(Map<String, MediaFile> mainImages) {
        this.mainImages = mainImages;
    }

    public List<MainImageInfo> getSelectedImages() {
        return selectedImages;
    }

    public void setSelectedImages(List<MainImageInfo> selectedImages) {
        this.selectedImages = selectedImages;
    }

    public void addSelectedImage(MainImageInfo selectedImage) {
        this.selectedImages.add(selectedImage);
    }

    public Set<TagInfo> getTags() {
        return tags;
    }

    public void setTags(Set<TagInfo> tags) {
        this.tags = tags;
    }

    public void addTag(TagInfo tag) {
        this.tags.add(tag);
    }

    @Override
    public String toString() {
        return String.format("%s (%s) [%s]", this.getTitle(), this.getYear(), this.getId());
    }

    @Override
    public ProgramMetadataManagementInfo createMetadataManagementInfo() {
        return new ProgramMetadataManagementInfo();
    }
}
