package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

import java.net.URI;

/**
 * Representation of a RelatedSong.
 */
public final class RelatedSong extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = 5805889121849041934L;

    private URI sourceSongId;
    private URI targetSongId;
    private Integer rank;
    private String type;

    public URI getSourceSongId() {
        return sourceSongId;
    }

    public void setSourceSongId(URI sourceSongId) {
        this.sourceSongId = sourceSongId;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public URI getTargetSongId() {
        return targetSongId;
    }

    public void setTargetSongId(URI targetSongId) {
        this.targetSongId = targetSongId;
    }

    @Override
    public String toString() {
        return String.format("RelatedSong");
    }

}
