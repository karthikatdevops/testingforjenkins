package com.theplatform.data.tv.entity.api.data.objects;


public enum RelatedAlbumType {
    IsSimilar("IsSimilar");

    private String friendlyName;

    private RelatedAlbumType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static RelatedAlbumType getByFriendlyName(String fName) {
        RelatedAlbumType foundType = null;
        for (RelatedAlbumType type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        RelatedAlbumType[] awardTypes = RelatedAlbumType.values();
        String[] friendlyNames = new String[awardTypes.length];
        for (int index = 0; index < awardTypes.length; index++) {
            friendlyNames[index] = awardTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
