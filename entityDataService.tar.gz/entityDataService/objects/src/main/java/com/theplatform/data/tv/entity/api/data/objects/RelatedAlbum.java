package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

import java.net.URI;

/**
 * Representation of a RelatedAlbum.
 */
public final class RelatedAlbum extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = 3225514886968772033L;

    private URI sourceAlbumId;
    private URI targetAlbumId;
    private Integer rank;
    private String type;

    public URI getSourceAlbumId() {
        return sourceAlbumId;
    }

    public void setSourceAlbumId(URI sourceAlbumId) {
        this.sourceAlbumId = sourceAlbumId;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public URI getTargetAlbumId() {
        return targetAlbumId;
    }

    public void setTargetAlbumId(URI targetAlbumId) {
        this.targetAlbumId = targetAlbumId;
    }

    @Override
    public String toString() {
        return String.format("RelatedAlbum");
    }

}
