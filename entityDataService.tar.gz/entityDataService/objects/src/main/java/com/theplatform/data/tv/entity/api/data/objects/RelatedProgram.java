package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.ManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;

import java.net.URI;

/**
 * Representation of a RelatedProgram.
 */
public final class RelatedProgram extends ManagedMerlinDataObject<RelatedProgramMetadataManagementInfo> {

    /**
     * Auto-generated serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    private URI sourceProgramId;
    private Program sourceProgram;
    private String type;
    private URI targetProgramId;
    private Program targetProgram;
    private String justification;
    private Integer rank;
    private Float score;

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getSourceProgramId() {
        return sourceProgramId;
    }

    public void setSourceProgramId(URI sourceProgramId) {
        this.sourceProgramId = sourceProgramId;
    }

    public Program getSourceProgram() {
        return sourceProgram;
    }

    public void setSourceProgram(Program sourceProgram) {
        this.sourceProgram = sourceProgram;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getTargetProgramId() {
        return targetProgramId;
    }

    public void setTargetProgramId(URI targetProgramId) {
        this.targetProgramId = targetProgramId;
    }

    public Program getTargetProgram() {
        return targetProgram;
    }

    public void setTargetProgram(Program targetProgram) {
        this.targetProgram = targetProgram;
    }

    public String getJustification() {
        return justification;
    }

    public void setJustification(String justification) {
        this.justification = justification;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Float getScore() {
        return score;
    }

    public void setScore(Float score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return String.format("RelatedProgram");
    }

    @Override
    public RelatedProgramMetadataManagementInfo createMetadataManagementInfo() {
        return new RelatedProgramMetadataManagementInfo();
    }

}
