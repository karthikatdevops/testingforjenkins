package com.theplatform.data.tv.entity.api.data.objects;

public enum ProgramType {

    /*
     * Note, the order of these matter; you CANNOT re-order these without
     * updating the data in the database. If you want to add a new type, add it
     * to the end and you should be fine
     */
    Movie("Movie"),
    Episode("Episode"),
    SeriesMaster("SeriesMaster"),
    Concert("Concert"),
    SportingEvent("SportingEvent"),
    Other("Other"),
    Preview("Preview"),
    Advertisement("Advertisement"),
    MusicVideo("MusicVideo"),
    Minisode("Minisode"),
    Extra("Extra");

    private String friendlyName;

    private ProgramType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static ProgramType getByFriendlyName(String friendlyName) {
        ProgramType foundType = null;
        for (ProgramType type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
                break;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        ProgramType[] programType = ProgramType.values();
        String[] friendlyNames = new String[programType.length];
        for (int index = 0; index < programType.length; index++) {
            friendlyNames[index] = programType[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
