package com.theplatform.data.tv.entity.api.data.objects;

/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 5/27/15
 * Time: 7:15 PM
 * To change this template use File | Settings | File Templates.
 */

public enum CompanyRole {

    /*
     * Note, the order of these matter; you CANNOT re-order these without
	 * updating the data in the database. If you want to add a new type, add it
	 * to the end and you should be fine
	 */


    Provider("Provider"),
    Distributor("Distributor");

    private String friendlyName;

    private CompanyRole(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static CompanyRole getByFriendlyName(String friendlyName) {
        CompanyRole foundType = null;
        for (CompanyRole type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
                break;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        CompanyRole[] companyRoles = CompanyRole.values();
        String[] friendlyNames = new String[companyRoles.length];
        for (int index = 0; index < companyRoles.length; index++) {
            friendlyNames[index] = companyRoles[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
