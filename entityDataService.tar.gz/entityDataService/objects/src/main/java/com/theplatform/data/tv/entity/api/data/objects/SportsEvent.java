package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.List;
import java.util.Map;

public class SportsEvent extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = -4945241679460321957L;

    private String city;
    private String state;
    private String country;
    private String conference;
    private String division;
    private String sportType;
    private String venue;
    private URI leagueId;

    private List<URI> programIds = null;
    @Deprecated
    private List<URI> imageIds;
    @Deprecated
    private Map<String, MediaFile> mainImages = null;
    private List<MainImageInfo> selectedImages;

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getConference() {
        return conference;
    }

    public void setConference(String conference) {
        this.conference = conference;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getSportType() {
        return sportType;
    }

    public void setSportType(String sportType) {
        this.sportType = sportType;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public URI getLeagueId() {
        return leagueId;
    }

    public void setLeagueId(URI leagueId) {
        this.leagueId = leagueId;
    }

    public List<URI> getProgramIds() {
        return programIds;
    }

    public void setProgramIds(List<URI> programIds) {
        this.programIds = programIds;
    }

    @Deprecated
    public List<URI> getImageIds() {
        return imageIds;
    }

    @Deprecated
    public void setImageIds(List<URI> imageIds) {
        this.imageIds = imageIds;
    }

    @Deprecated
    public Map<String, MediaFile> getMainImages() {
        return mainImages;
    }

    public List<MainImageInfo> getSelectedImages() {
        return selectedImages;
    }

    public void setSelectedImages(List<MainImageInfo> selectedImages) {
        this.selectedImages = selectedImages;
    }

    @Deprecated
    public void setMainImages(Map<String, MediaFile> mainImages) {
        this.mainImages = mainImages;
    }

}
