package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;

import java.net.URI;

/**
 * Representation of a TvSeason.
 */
public final class TvSeason extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = 1L;

    private URI seriesId;
    private Integer tvSeasonNumber;
    private Integer startYear;
    private Integer endYear;

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getSeriesId() {
        return seriesId;
    }

    public void setSeriesId(URI seriesId) {
        this.seriesId = seriesId;
    }

    public Integer getTvSeasonNumber() {
        return tvSeasonNumber;
    }

    public void setTvSeasonNumber(Integer tvSeasonNumber) {
        this.tvSeasonNumber = tvSeasonNumber;
    }

    public Integer getStartYear() {
        return startYear;
    }

    public void setStartYear(Integer startYear) {
        this.startYear = startYear;
    }

    public Integer getEndYear() {
        return endYear;
    }

    public void setEndYear(Integer endYear) {
        this.endYear = endYear;
    }

    @Override
    public String toString() {
        return String.format("%s (%s) [%s]", this.getDescription(), this.getStartYear(), this.getId());
    }

}
