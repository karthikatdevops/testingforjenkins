package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

import java.net.URI;

public class ProgramSportsEvent extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = -749504838400724201L;

    private URI programId;
    private URI sportsEventId;

    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    public URI getSportsEventId() {
        return sportsEventId;
    }

    public void setSportsEventId(URI sportsEventId) {
        this.sportsEventId = sportsEventId;
    }

}
