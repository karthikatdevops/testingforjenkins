package com.theplatform.data.tv.entity.api.data.objects;

public enum RelatedProgramType {

    HasTrailer("HasTrailer"),
    HasMakingOf("HasMakingOf"),
    HasSpinoff("HasSpinoff"),
    HasDerivation("HasDerivation"),
    IsSpoof("IsSpoof"),
    HasSimilarTheme("HasSimilarTheme"),
    HasSimilarFeel("HasSimilarFeel"),
    IsSimilar("IsSimilar"),
    IsRemake("IsRemake"),
    IsSequel("IsSequel"),
    IsFeatured("IsFeatured"),
    SharesCast("SharesCast"),
    IsRelated("IsRelated"),
    IsInfluenced("IsInfluenced"),
    HasMinisode("HasMinisode"),
    HasExtra("HasExtra"),
    IsFranchise("IsFranchise"),
    IsSeriesSpecial("IsSeriesSpecial"),
    IsCrossover("IsCrossover"),
    IsAudioVersion("IsAudioVersion"),
    HasAlternateAudio("HasAlternateAudio");

    private String friendlyName;

    private RelatedProgramType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static RelatedProgramType getByFriendlyName(String friendlyName) {
        RelatedProgramType foundType = null;
        for (RelatedProgramType type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        RelatedProgramType[] relatedProgramTypes = RelatedProgramType.values();
        String[] friendlyNames = new String[relatedProgramTypes.length];
        for (int index = 0; index < relatedProgramTypes.length; index++) {
            friendlyNames[index] = relatedProgramTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
