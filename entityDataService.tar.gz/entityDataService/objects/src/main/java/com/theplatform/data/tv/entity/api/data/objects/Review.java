package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;
import com.theplatform.media.api.data.objects.Rating;

import java.net.URI;
import java.util.List;

public class Review extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = 5599085407568508329L;

    private URI programId;

    private String provider;

    private String summary;

    private String review;

    private String recommendation;

    private Integer starRating;


    private String source;

    private List<Rating> contentRatings;

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public Integer getStarRating() {
        return starRating;
    }

    public void setStarRating(Integer starRating) {
        this.starRating = starRating;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public List<Rating> getContentRatings() {
        return contentRatings;
    }

    public void setContentRatings(List<Rating> contentRatings) {
        this.contentRatings = contentRatings;
    }
}
