package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

import java.net.URI;
import java.util.List;

public class Song extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = -5413618403089814143L;

    private String sortTitle;

    private String isrc;

    private Integer duration;

    private List<URI> primaryPersonIds;

    @Deprecated
    private List<URI> imageIds;

    private List<URI> tagIds;

    public String getSortTitle() {
        return sortTitle;
    }

    public void setSortTitle(String sortTitle) {
        this.sortTitle = sortTitle;
    }

    public String getIsrc() {
        return isrc;
    }

    public void setIsrc(String isrc) {
        this.isrc = isrc;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public List<URI> getPrimaryPersonIds() {
        return primaryPersonIds;
    }

    public void setPrimaryPersonIds(List<URI> primaryPersonIds) {
        this.primaryPersonIds = primaryPersonIds;
    }

    @Deprecated
    public List<URI> getImageIds() {
        return imageIds;
    }

    @Deprecated
    public void setImageIds(List<URI> imageIds) {
        this.imageIds = imageIds;
    }

    public List<URI> getTagIds() {
        return tagIds;
    }

    public void setTagIds(List<URI> tagIds) {
        this.tagIds = tagIds;
    }


}
