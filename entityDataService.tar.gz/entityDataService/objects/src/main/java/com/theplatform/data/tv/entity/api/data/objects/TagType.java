package com.theplatform.data.tv.entity.api.data.objects;

public enum TagType {

    Keyword("Keyword"),
    ArtisticStyle("ArtisticStyle"),
    Country("Country"),
    Location("Location"),
    Genre("Genre"),
    Theme("Theme"),
    Type("Type"),
    RatingFlag("RatingFlag"),
    Tone("Tone"),
    Period("Period"),
    Category("Category"),
    ITheme("ITheme"),
    Company("Company"),
    NativeITheme("NativeITheme"),
    Music("Music"),
    KidsTheme("KidsTheme"),
    MusicalGenre("MusicalGenre"),
    Decade("Decade"),
    Instrumentation("Instrumentation"),
    MusicalMood("MusicalMood"),
    MusicalDecade("MusicalDecade"),
    TimePeriod("TimePeriod"),
    HotList("HotList"),
    Station("Station"),
    // The following are added for US21959
    Universe("Universe"),
    Character("Character"),
    General ("General"),
    Setting ("Setting"),
    Subject ("Subject");

    private String friendlyName;

    private TagType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static TagType getByFriendlyName(String friendlyName) {
        TagType foundType = null;
        for (TagType type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        TagType[] tagTypes = TagType.values();
        String[] friendlyNames = new String[tagTypes.length];
        for (int index = 0; index < tagTypes.length; index++) {
            friendlyNames[index] = tagTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
