package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;

import java.net.URI;
import java.util.List;
import java.util.Map;

public class EntityCollectionMetadataManagementInfo extends MetadataManagementInfo {

    private static final long serialVersionUID = 2046573240273440082L;

    private List<URI> appendEntityIds;
    private List<URI> removeEntityIds;
    private Map<String, URI> appendPrimaryEntities;
    private List<String> removePrimaryEntities;

    public List<URI> getAppendEntityIds() {
        return appendEntityIds;
    }

    public void setAppendEntityIds(List<URI> appendEntityIds) {
        this.appendEntityIds = appendEntityIds;
    }

    public List<URI> getRemoveEntityIds() {
        return removeEntityIds;
    }

    public void setRemoveEntityIds(List<URI> removeEntityIds) {
        this.removeEntityIds = removeEntityIds;
    }

    public Map<String, URI> getAppendPrimaryEntities() {
        return appendPrimaryEntities;
    }

    public void setAppendPrimaryEntities(Map<String, URI> appendPrimaryEntities) {
        this.appendPrimaryEntities = appendPrimaryEntities;
    }

    public List<String> getRemovePrimaryEntities() {
        return removePrimaryEntities;
    }

    public void setRemovePrimaryEntities(List<String> removePrimaryEntities) {
        this.removePrimaryEntities = removePrimaryEntities;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((appendEntityIds == null) ? 0 : appendEntityIds.hashCode());
        result = prime * result + ((appendPrimaryEntities == null) ? 0 : appendPrimaryEntities.hashCode());
        result = prime * result + ((removeEntityIds == null) ? 0 : removeEntityIds.hashCode());
        result = prime * result + ((removePrimaryEntities == null) ? 0 : removePrimaryEntities.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        EntityCollectionMetadataManagementInfo other = (EntityCollectionMetadataManagementInfo) obj;
        if (appendEntityIds == null) {
            if (other.appendEntityIds != null)
                return false;
        } else if (!appendEntityIds.equals(other.appendEntityIds))
            return false;
        if (appendPrimaryEntities == null) {
            if (other.appendPrimaryEntities != null)
                return false;
        } else if (!appendPrimaryEntities.equals(other.appendPrimaryEntities))
            return false;
        if (removeEntityIds == null) {
            if (other.removeEntityIds != null)
                return false;
        } else if (!removeEntityIds.equals(other.removeEntityIds))
            return false;
        if (removePrimaryEntities == null) {
            if (other.removePrimaryEntities != null)
                return false;
        } else if (!removePrimaryEntities.equals(other.removePrimaryEntities))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return super.toString() + "\nEntityCollectionMetadataManagementInfo [appendEntityIds=" + appendEntityIds + ", removeEntityIds="
                + removeEntityIds + ", appendPrimaryEntities=" + appendPrimaryEntities + ", removePrimaryEntities="
                + removePrimaryEntities + "]";
    }
}
