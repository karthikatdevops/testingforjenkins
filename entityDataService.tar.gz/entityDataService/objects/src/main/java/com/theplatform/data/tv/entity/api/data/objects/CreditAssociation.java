package com.theplatform.data.tv.entity.api.data.objects;

import java.io.Serializable;
import java.net.URI;

public class CreditAssociation implements Serializable {

    private static final long serialVersionUID = -4317308584199201193L;

    private String type;
    private String partName;
    private Integer rank;
    private Boolean cameo;
    private URI personId;
    private URI programId;
    private URI creditId;
    private String personName;
    private String programTitle;
    private Integer programYear;

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof CreditAssociation)) {
            return false;
        }
        CreditAssociation ca = (CreditAssociation) o;

        if (personId != null ? !personId.equals(ca.personId) : ca.personId != null) return false;
        if (programId != null ? !programId.equals(ca.programId) : ca.programId != null) return false;

        if (type != null) {
            if (!type.equals(ca.type)) {
                if (!("".equals(type) && "".equals(ca.type))) {
                    return false;
                }
            }
        } else if (ca.type != null) {
            return false;
        }
        if (partName != null ? !partName.equals(ca.partName) : ca.partName != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = 31;
        result = 31 * result + (personId != null ? personId.hashCode() : 0);
        result = 31 * result + (programId != null ? programId.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (partName != null ? partName.hashCode() : 0);
        return result;
    }

    public Integer getProgramYear() {
        return programYear;
    }

    public void setProgramYear(Integer programYear) {
        this.programYear = programYear;
    }

    public URI getCreditId() {
        return creditId;
    }

    public void setCreditId(URI creditId) {
        this.creditId = creditId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Boolean getCameo() {
        return cameo;
    }

    public void setCameo(Boolean cameo) {
        this.cameo = cameo;
    }

    public URI getPersonId() {
        return personId;
    }

    public void setPersonId(URI personId) {
        this.personId = personId;
    }

    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getProgramTitle() {
        return programTitle;
    }

    public void setProgramTitle(String programTitle) {
        this.programTitle = programTitle;
    }

    @Override
    public String toString() {
        return String.format("%s, %s, %s [%s]", this.getPartName(), this.getProgramTitle(), this.getPersonName(), this.getCreditId());
    }

}
