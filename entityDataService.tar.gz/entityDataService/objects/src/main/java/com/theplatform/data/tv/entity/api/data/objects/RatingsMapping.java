package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Map;

/**
 * Created by lemuri200 on 5/29/15.
 */
public class RatingsMapping extends DefaultManagedMerlinDataObject {

    private String sourceRatingSystem;
    private String targetRatingSystem;

    private Map<String, String> ratingsMap;

    public String getSourceRatingSystem() {
        return sourceRatingSystem;
    }

    public void setSourceRatingSystem(String sourceRatingSystem) {
        this.sourceRatingSystem = sourceRatingSystem;
    }

    public String getTargetRatingSystem() {
        return targetRatingSystem;
    }

    public void setTargetRatingSystem(String targetRatingSystem) {
        this.targetRatingSystem = targetRatingSystem;
    }

    public Map<String, String> getRatingsMap() {
        return ratingsMap;
    }

    public void setRatingsMap(Map<String, String> ratingsMap) {
        this.ratingsMap = ratingsMap;
    }

    public String toString() {
        return new ToStringBuilder(this).
                append("sourceRatingSystem", getSourceRatingSystem()).
                append("targetRatingSystem", getTargetRatingSystem()).
                toString();
    }
}
