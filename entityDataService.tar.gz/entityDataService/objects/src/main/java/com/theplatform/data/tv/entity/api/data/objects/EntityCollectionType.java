package com.theplatform.data.tv.entity.api.data.objects;


public enum EntityCollectionType {
    ADIPackage("ADIPackage"),
    MovieFranchise("MovieFranchise"),
    Variant("Variant");

    private String friendlyName;

    private EntityCollectionType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static EntityCollectionType getByFriendlyName(String fName) {
        EntityCollectionType foundType = null;
        for (EntityCollectionType type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        EntityCollectionType[] awardTypes = EntityCollectionType.values();
        String[] friendlyNames = new String[awardTypes.length];
        for (int index = 0; index < awardTypes.length; index++) {
            friendlyNames[index] = awardTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
