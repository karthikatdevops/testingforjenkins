package com.theplatform.data.tv.entity.api.data.objects;

public enum PersonKnownForType {

    Music("Music"),
    Video("Video");

    private String friendlyName;

    private PersonKnownForType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static PersonKnownForType getByFriendlyName(String friendlyName) {
        PersonKnownForType foundType = null;
        for (PersonKnownForType type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
                break;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        PersonKnownForType[] personKnownForType = PersonKnownForType.values();
        String[] friendlyNames = new String[personKnownForType.length];
        for (int index = 0; index < personKnownForType.length; index++) {
            friendlyNames[index] = personKnownForType[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
