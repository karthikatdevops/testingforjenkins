package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;

import java.net.URI;

/**
 * Representation of a SongCredit.
 */
public final class SongCredit extends DefaultManagedMerlinDataObject {


    /**
     *
     */
    private static final long serialVersionUID = -6002550204027234331L;

    private String type;
    private Integer rank;
    private URI personId;
    private URI songId;
    private Boolean active;

    @NotificationField(notifyAlways = true)
    public URI getPersonId() {
        return personId;
    }

    public void setPersonId(URI personId) {
        this.personId = personId;
    }

    @NotificationField(notifyAlways = true)
    public URI getSongId() {
        return songId;
    }

    public void setSongId(URI songId) {
        this.songId = songId;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    @Override
    public String toString() {
        return String.format("%s: %s [%s]", this.getType(), this.getPersonId() + "-" + this.getSongId(), this.getId());
    }

}
