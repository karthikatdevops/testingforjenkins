package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

import java.net.URI;

public class AwardAssociation extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = -4471397511152574483L;

    private Integer year;

    private String awardStatus;

    private String awardType;

    private URI awardId;

    private URI institutionId;

    private URI programId;

    private URI personId;

    private URI awardShowId;

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getAwardStatus() {
        return awardStatus;
    }

    public void setAwardStatus(String awardStatus) {
        this.awardStatus = awardStatus;
    }

    public String getAwardType() {
        return awardType;
    }

    public void setAwardType(String awardType) {
        this.awardType = awardType;
    }

    public URI getAwardId() {
        return awardId;
    }

    public void setAwardId(URI awardId) {
        this.awardId = awardId;
    }

    public URI getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(URI institutionId) {
        this.institutionId = institutionId;
    }

    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    public URI getPersonId() {
        return personId;
    }

    public void setPersonId(URI personId) {
        this.personId = personId;
    }

    public URI getAwardShowId() {
        return awardShowId;
    }

    public void setAwardShowId(URI awardShowId) {
        this.awardShowId = awardShowId;
    }
}
