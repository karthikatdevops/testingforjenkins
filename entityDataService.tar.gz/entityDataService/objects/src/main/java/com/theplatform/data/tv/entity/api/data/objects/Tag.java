package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

public class Tag extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = -3638414555083313696L;

    /**
     * @deprecated use Tag.title
     */
    @Deprecated
    private String name;
    private String type;

    /**
     * @deprecated use Tag.getTitle()
     */
    @Deprecated
    public String getName() {
        return name;
    }

    /**
     * @deprecated use Tag.setTitle(String)
     */
    @Deprecated
    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
