package com.theplatform.data.tv.entity.api.data.objects;


public enum RelatedPersonType {
    memberOf("memberOf"),
    hasSimilarMusic("hasSimilarMusic"),
    collaboratorWith("collaboratorWith"),
    followedMusic("followedMusic"),
    influencedMusic("influencedMusic");

    private String friendlyName;

    private RelatedPersonType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static RelatedPersonType getByFriendlyName(String fName) {
        RelatedPersonType foundType = null;
        for (RelatedPersonType type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        RelatedPersonType[] awardTypes = RelatedPersonType.values();
        String[] friendlyNames = new String[awardTypes.length];
        for (int index = 0; index < awardTypes.length; index++) {
            friendlyNames[index] = awardTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
