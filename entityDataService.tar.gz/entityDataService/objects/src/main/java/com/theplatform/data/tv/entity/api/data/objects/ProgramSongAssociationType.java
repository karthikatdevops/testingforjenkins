package com.theplatform.data.tv.entity.api.data.objects;


public enum ProgramSongAssociationType {
    MusicVideo("MusicVideo"),
    FeaturedIn("FeaturedIn");

    private String friendlyName;

    private ProgramSongAssociationType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static ProgramSongAssociationType getByFriendlyName(String fName) {
        ProgramSongAssociationType foundType = null;
        for (ProgramSongAssociationType type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        ProgramSongAssociationType[] associationTypes = ProgramSongAssociationType.values();
        String[] friendlyNames = new String[associationTypes.length];
        for (int index = 0; index < associationTypes.length; index++) {
            friendlyNames[index] = associationTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
