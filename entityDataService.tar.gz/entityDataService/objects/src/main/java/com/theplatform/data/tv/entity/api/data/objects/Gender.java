package com.theplatform.data.tv.entity.api.data.objects;

public enum Gender {

    Male("Male"),
    Female("Female"),
    CoEd("Co-Ed"),
    Unknown("Unknown");

    private String friendlyName;

    private Gender(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static Gender getByFriendlyName(String friendlyName) {
        Gender foundType = null;
        for (Gender type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        Gender[] genders = Gender.values();
        String[] friendlyNames = new String[genders.length];
        for (int index = 0; index < genders.length; index++) {
            friendlyNames[index] = genders[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
