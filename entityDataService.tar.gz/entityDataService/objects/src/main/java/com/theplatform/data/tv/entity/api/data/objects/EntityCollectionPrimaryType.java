package com.theplatform.data.tv.entity.api.data.objects;


public enum EntityCollectionPrimaryType {
    Primary("Primary"),
    English("English"),
    Spanish("Spanish");

    private String friendlyName;

    private EntityCollectionPrimaryType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static EntityCollectionPrimaryType getByFriendlyName(String fName) {
        EntityCollectionPrimaryType foundType = null;
        for (EntityCollectionPrimaryType type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        EntityCollectionPrimaryType[] awardTypes = EntityCollectionPrimaryType.values();
        String[] friendlyNames = new String[awardTypes.length];
        for (int index = 0; index < awardTypes.length; index++) {
            friendlyNames[index] = awardTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
