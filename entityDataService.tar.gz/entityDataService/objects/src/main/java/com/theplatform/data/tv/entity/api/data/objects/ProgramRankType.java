package com.theplatform.data.tv.entity.api.data.objects;


public enum ProgramRankType {
    Algorithmic("Algorithmic"),
    Gross("Gross"),
    Cumulative("Cumulative"),
    Browse("Browse"),
    NielsenWeekly("NielsenWeekly"),
    NielsenQuarterly("NielsenQuarterly");
    private String friendlyName;

    private ProgramRankType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static ProgramRankType getByFriendlyName(String fName) {
        ProgramRankType rankType = null;
        for (ProgramRankType type : values()) {
            if (type.friendlyName.equals(fName)) {
                rankType = type;
            }
        }
        return rankType;
    }

    public static String[] getFriendlyNameValues() {
        ProgramRankType[] rankTypes = ProgramRankType.values();
        String[] friendlyNames = new String[rankTypes.length];
        for (int index = 0; index < rankTypes.length; index++) {
            friendlyNames[index] = rankTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
