package com.theplatform.data.tv.entity.api.data.objects;

import java.net.URI;

/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 5/27/15
 * Time: 7:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyInfo {
    private URI companyId;
    private CompanyRole role;

    public URI getCompanyId() {
        return companyId;
    }

    public void setCompanyId(URI companyId) {
        this.companyId = companyId;
    }

    public CompanyRole getRole() {
        return role;
    }

    public void setRole(CompanyRole role) {
        this.role = role;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof CompanyInfo)) {
            return false;
        }
        CompanyInfo ci = (CompanyInfo) o;

        if (companyId != null ? !companyId.equals(ci.companyId) : ci.companyId != null) return false;
        if (role != null ? !role.equals(ci.role) : ci.role != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = 31;
        result = 31 * result + (companyId != null ? companyId.hashCode() : 0);
        result = 31 * result + (role != null ? role.hashCode() : 0);
        return result;
    }
}
