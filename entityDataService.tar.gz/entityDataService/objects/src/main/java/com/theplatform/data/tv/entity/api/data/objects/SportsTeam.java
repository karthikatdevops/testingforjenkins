package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SportsTeam extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = -4206465259278074713L;

    private String representingName;
    private String nickName;
    private String city;
    private String state;
    private String country;
    private String conference;
    private String division;
    private String sportType;
    private String type;
    private String gender;
    private String coach;
    private URI coachPersonId;
    private String venue;
    private URI leagueId;
    private URI parentSportsTeamId;
    private String abbreviation;
    private String shortBio;
    private String mediumBio;
    private String longBio;

    // Collections
    @Deprecated
    private List<URI> imageIds;
    @Deprecated
    private Map<String, MediaFile> mainImages = null;
    private List<MainImageInfo> selectedImages;

    private Set<TagInfo> tags;
    private List<URI> tagIds;

    public String getRepresentingName() {
        return representingName;
    }

    public void setRepresentingName(String representingName) {
        this.representingName = representingName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getConference() {
        return conference;
    }

    public void setConference(String conference) {
        this.conference = conference;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getSportType() {
        return sportType;
    }

    public void setSportType(String sportType) {
        this.sportType = sportType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCoach() {
        return coach;
    }

    public void setCoach(String coach) {
        this.coach = coach;
    }

    public URI getCoachPersonId() {
        return coachPersonId;
    }

    public void setCoachPersonId(URI coachPersonId) {
        this.coachPersonId = coachPersonId;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public URI getLeagueId() {
        return leagueId;
    }

    public void setLeagueId(URI leagueId) {
        this.leagueId = leagueId;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getParentSportsTeamId() {
        return parentSportsTeamId;
    }

    public void setParentSportsTeamId(URI parentSportsTeamId) {
        this.parentSportsTeamId = parentSportsTeamId;
    }

    @Deprecated
    public List<URI> getImageIds() {
        return imageIds;
    }

    @Deprecated
    public void setImageIds(List<URI> imageIds) {
        this.imageIds = imageIds;
    }

    @Deprecated
    public Map<String, MediaFile> getMainImages() {
        return mainImages;
    }

    @Deprecated
    public void setMainImages(Map<String, MediaFile> mainImages) {
        this.mainImages = mainImages;
    }

    public List<MainImageInfo> getSelectedImages() {
        return selectedImages;
    }

    public void setSelectedImages(List<MainImageInfo> selectedImages) {
        this.selectedImages = selectedImages;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getShortBio() {
        return shortBio;
    }

    public void setShortBio(String shortBio) {
        this.shortBio = shortBio;
    }

    public String getMediumBio() {
        return mediumBio;
    }

    public void setMediumBio(String mediumBio) {
        this.mediumBio = mediumBio;
    }

    public String getLongBio() {
        return longBio;
    }

    public void setLongBio(String longBio) {
        this.longBio = longBio;
    }

    @Override
    public String toString() {
        return String.format("%s [%s]", this.representingName, this.getId());
    }

    public List<URI> getTagIds() {
        return tagIds;
    }

    public void setTagIds(List<URI> tagIds) {
        this.tagIds = tagIds;
    }

    public Set<TagInfo> getTags() {
        return tags;
    }

    public void setTags(Set<TagInfo> tags) {
        this.tags = tags;
    }
}
