package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

public class SportsLeague extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = 4304492048049917507L;

}
