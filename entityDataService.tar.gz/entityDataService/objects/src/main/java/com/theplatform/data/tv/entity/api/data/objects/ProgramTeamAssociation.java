package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;

import java.net.URI;

public class ProgramTeamAssociation extends DefaultManagedMerlinDataObject {

    private static final long serialVersionUID = -9008247201797384440L;

    private URI programId;
    private URI sportsTeamId;
    private String homeAway;
    private Boolean competition;

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    @NotificationField(notifyAlways = true, notifyChanges = true, notifyDelete = true)
    public URI getSportsTeamId() {
        return sportsTeamId;
    }

    public void setSportsTeamId(URI sportsTeamId) {
        this.sportsTeamId = sportsTeamId;
    }

    public String getHomeAway() {
        return homeAway;
    }

    public void setHomeAway(String homeAway) {
        this.homeAway = homeAway;
    }

    public Boolean getCompetition() {
        return competition;
    }

    public void setCompetition(Boolean competition) {
        this.competition = competition;
    }

}
