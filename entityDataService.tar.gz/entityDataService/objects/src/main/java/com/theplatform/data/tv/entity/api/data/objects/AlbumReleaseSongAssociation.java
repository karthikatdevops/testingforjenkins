package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;

import java.net.URI;

public class AlbumReleaseSongAssociation extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = 2553598894733626846L;

    private URI albumReleaseId;

    private URI songId;

    private Integer trackNumber;

    @NotificationField(notifyAlways = true)
    public URI getAlbumReleaseId() {
        return albumReleaseId;
    }


    public void setAlbumReleaseId(URI albumReleaseId) {
        this.albumReleaseId = albumReleaseId;
    }

    @NotificationField(notifyAlways = true)
    public URI getSongId() {
        return songId;
    }


    public void setSongId(URI songId) {
        this.songId = songId;
    }


    public Integer getTrackNumber() {
        return trackNumber;
    }


    public void setTrackNumber(Integer trackNumber) {
        this.trackNumber = trackNumber;
    }


    @Override
    public String toString() {
        return albumReleaseId + " " + songId + "\n" + trackNumber;
    }
}
