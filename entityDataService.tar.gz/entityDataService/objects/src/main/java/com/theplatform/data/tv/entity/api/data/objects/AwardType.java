package com.theplatform.data.tv.entity.api.data.objects;


public enum AwardType {
    Program("Program"),
    Person("Person");

    private String friendlyName;

    private AwardType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static AwardType getByFriendlyName(String fName) {
        AwardType foundType = null;
        for (AwardType type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        AwardType[] awardTypes = AwardType.values();
        String[] friendlyNames = new String[awardTypes.length];
        for (int index = 0; index < awardTypes.length; index++) {
            friendlyNames[index] = awardTypes[index].getFriendlyName();
        }
        return friendlyNames;
    }
}
