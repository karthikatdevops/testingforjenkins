package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.RatingScheme;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.media.api.data.objects.Rating;

import java.util.List;

public class ProgramMetadataManagementInfo extends MetadataManagementInfo {

    private static final long serialVersionUID = -4323894045707459418L;

    private String titlePaid;
    private String contentPaid;

    private List<Rating> appendContentRatings;
    private List<String> removeContentRatingSchemes;

    public String getTitlePaid() {
        return titlePaid;
    }

    public void setTitlePaid(String titlePaid) {
        this.titlePaid = titlePaid;
    }

    public String getContentPaid() {
        return contentPaid;
    }

    public void setContentPaid(String contentPaid) {
        this.contentPaid = contentPaid;
    }

    public List<Rating> getAppendContentRatings() {
        return appendContentRatings;
    }

    public void setAppendContentRatings(List<Rating> appendContentRatings) {
        this.appendContentRatings = appendContentRatings;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((titlePaid == null) ? 0 : titlePaid.hashCode());
        result = prime * result + ((contentPaid == null) ? 0 : contentPaid.hashCode());
        result = prime * result + ((appendContentRatings == null) ? 0 : appendContentRatings.hashCode());
        result = prime * result + ((removeContentRatingSchemes == null) ? 0 : removeContentRatingSchemes.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProgramMetadataManagementInfo other = (ProgramMetadataManagementInfo) obj;

        if (titlePaid == null) {
            if (other.titlePaid != null)
                return false;
        } else if (!titlePaid.equals(other.titlePaid))
            return false;

        if (contentPaid == null) {
            if (other.contentPaid != null)
                return false;
        } else if (!contentPaid.equals(other.contentPaid))
            return false;


        if (appendContentRatings == null) {
            if (other.appendContentRatings != null)
                return false;
        } else if (!appendContentRatings.equals(other.appendContentRatings))
            return false;

        if (removeContentRatingSchemes == null) {
            if (other.removeContentRatingSchemes != null)
                return false;
        } else if (!removeContentRatingSchemes.equals(other.removeContentRatingSchemes))
            return false;

        return true;
    }

    @Override
    public String toString() {
        return super.toString() + "\nProgramMetadataManagementInfo [appendContentRatings=" +
                appendContentRatings + ", removeContentRatingSchemes=" + removeContentRatingSchemes + "]";
    }

    public List<String> getRemoveContentRatingSchemes() {
        return removeContentRatingSchemes;
    }

    public void setRemoveContentRatingSchemes(List<String> removeContentRatingSchemes) {
        this.removeContentRatingSchemes = removeContentRatingSchemes;
    }
}
