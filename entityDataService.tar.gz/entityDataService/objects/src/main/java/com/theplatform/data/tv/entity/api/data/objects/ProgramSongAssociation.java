package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;
import com.theplatform.data.notification.api.objects.annotation.NotificationField;

import java.net.URI;

public class ProgramSongAssociation extends DefaultManagedMerlinDataObject {

    /**
     *
     */
    private static final long serialVersionUID = -6587424618468045794L;

    private URI programId;
    private URI songId;
    private String type;
    private ProgramType programType;

    @NotificationField(notifyAlways = true)
    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    @NotificationField(notifyAlways = true)
    public URI getSongId() {
        return songId;
    }

    public void setSongId(URI songId) {
        this.songId = songId;
    }

    @NotificationField(notifyAlways = true)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ProgramType getProgramType() {
        return programType;
    }

    public void setProgramType(ProgramType programType) {
        this.programType = programType;
    }


}
