package com.theplatform.data.tv.entity.api.data.objects;

import java.io.Serializable;
import java.net.URI;

public class ProgramAssociation implements Serializable {

    private static final long serialVersionUID = -3263488122948903858L;

    private String title;
    private Integer year;
    private URI programId;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public URI getProgramId() {
        return programId;
    }

    public void setProgramId(URI programId) {
        this.programId = programId;
    }

    @Override
    public String toString() {
        return String.format("%s (%s) [%s]", this.getTitle(), this.getYear(), this.getProgramId());
    }

}
