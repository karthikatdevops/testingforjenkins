package com.theplatform.data.tv.entity.api.data.objects;

public enum AwardStatus {

    Nominee("Nominee"),
    Winner("Winner"),
    FestivalScreening("FestivalScreening");

    private String friendlyName;

    private AwardStatus(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static AwardStatus getByFriendlyName(String fName) {
        AwardStatus foundType = null;
        for (AwardStatus type : values()) {
            if (type.friendlyName.equals(fName)) {
                foundType = type;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        AwardStatus[] awardStatus = AwardStatus.values();
        String[] friendlyNames = new String[awardStatus.length];
        for (int index = 0; index < awardStatus.length; index++) {
            friendlyNames[index] = awardStatus[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
