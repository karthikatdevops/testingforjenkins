package com.theplatform.data.tv.entity.api.data.objects;

public enum AlbumReleaseSoundType {

    Remastered("Remastered"),
    Mixed("Mixed"),
    Stereo("Stereo"),
    Mono("Mono"),
    Unknown("Unknown"),
    Multichannel("Multichannel");

    private String friendlyName;

    private AlbumReleaseSoundType(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static AlbumReleaseSoundType getByFriendlyName(String friendlyName) {
        AlbumReleaseSoundType foundType = null;
        for (AlbumReleaseSoundType type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
                break;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        AlbumReleaseSoundType[] soundType = AlbumReleaseSoundType.values();
        String[] friendlyNames = new String[soundType.length];
        for (int index = 0; index < soundType.length; index++) {
            friendlyNames[index] = soundType[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
