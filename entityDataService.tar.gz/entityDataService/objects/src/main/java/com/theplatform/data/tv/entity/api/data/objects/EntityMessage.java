package com.theplatform.data.tv.entity.api.data.objects;

import com.theplatform.contrib.data.api.objects.DefaultManagedMerlinDataObject;

import java.net.URI;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/22/15
 */
public class EntityMessage extends DefaultManagedMerlinDataObject {

    /**
     * Auto-generated serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    private URI entityId;
    private String freeText;
    private String type;
    private Integer priority;

    public URI getEntityId() {
        return entityId;
    }

    public void setEntityId(URI entityId) {
        this.entityId = entityId;
    }

    public String getFreeText() {
        return freeText;
    }

    public void setFreeText(String freeText) {
        this.freeText = freeText;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    @Override
    public String toString() {
        return String.format("EntityMessage [%s]", this.getId());
    }
}
