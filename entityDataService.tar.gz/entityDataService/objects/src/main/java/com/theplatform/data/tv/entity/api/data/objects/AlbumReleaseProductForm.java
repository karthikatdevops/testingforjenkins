package com.theplatform.data.tv.entity.api.data.objects;

public enum AlbumReleaseProductForm {

    Single("Single"),
    EP("EP"),
    MaxiSingle("Maxi-Single"),
    Album("Album"),
    Ringle("Ringle");

    private String friendlyName;

    private AlbumReleaseProductForm(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public static AlbumReleaseProductForm getByFriendlyName(String friendlyName) {
        AlbumReleaseProductForm foundType = null;
        for (AlbumReleaseProductForm type : values()) {
            if (type.friendlyName.equals(friendlyName)) {
                foundType = type;
                break;
            }
        }
        return foundType;
    }

    public static String[] getFriendlyNameValues() {
        AlbumReleaseProductForm[] productFormType = AlbumReleaseProductForm.values();
        String[] friendlyNames = new String[productFormType.length];
        for (int index = 0; index < productFormType.length; index++) {
            friendlyNames[index] = productFormType[index].getFriendlyName();
        }
        return friendlyNames;
    }

}
