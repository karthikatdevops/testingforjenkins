package com.theplatform.data.tv.entity.api.data.objects;


import org.testng.Assert;
import org.testng.annotations.Test;

public class RottenTomatoesRatingTest {

    @Test
    public void testRoundTrip() {
        String ratingString = "criticSummaryScore=44,criticSummaryCount=9,criticSummaryCertified=false,criticSummaryRotten=true,fanSummaryScore=75,fanSummaryCount=145";
        RottenTomatoesRating rating = RottenTomatoesRating.fromString(ratingString);
        Assert.assertEquals(rating.toString(), ratingString);
    }

    @Test
    public void testRoundTripNegativeScore() {
        String ratingString = "criticSummaryScore=-1,criticSummaryCount=0,criticSummaryCertified=false,criticSummaryRotten=false,fanSummaryScore=31,fanSummaryCount=13";
        RottenTomatoesRating rating = RottenTomatoesRating.fromString(ratingString);
        Assert.assertEquals(rating.toString(), ratingString);
    }
}
