Entity Data Service
===================

Metadata source for real world entertainment entities like Programs, People, Albums, and Songs.

Full API specification is located on the TeamCompass wiki: http://teamcompass.cable.comcast.com/display/merlin/Entity+Data+Service+Specifications.

Client Support
==============

If you're a client of Merlin APIs and wish to use our Java client, you are interested in the *api* and *objects* modules. 
This can be included in your Java project by adding the following repository:

```
<repositories>
    <repository>
        <id>compass-maven-repo</id>
        <name>Compass Maven repo</name>
        <url>http://maven.compass.chalybs.net:8081/artifactory/compass-all-repos</url>
    </repository>
</repositories>
```  
  
Then add the following dependency:

```
  <dependency>
    <groupId>com.theplatform.data.tv.entity</groupId>
    <artifactId>pl-data-tv-entity-dependency-client</artifactId>
    <version>${entity-version}</version>
    <type>pom</type>
  </dependency>
```
The _entity-version_ can be typically set to the most recently released tag, which will be one patch version lower than the current snapshot with a letter tag applied. For example, if the current master version of entity is 1.5.35-SNAPSHOT, then the latest released tag will be 1.5.34-a. The list of released tags can also be found in artifactory: http://maven.compass.chalybs.net:8081/artifactory/compass-all-repos/com/theplatform/data/tv/entity/pl-data-tv-entity-dependency-client/. 

Testing
==============

Now new and improved with a handy "test" bash script at the root. This script is equivalent to running:

```
mvn -Plocal-int-test clean install
```

The *local-int-test* maven profile does the following:

1. Generate a dynamic DB schema/user name using the venerable JSnik's dynprop-maven-plugin. ie DS_ENTITY_TEST_1234
2. Create the Oracle DB user and grant it the necessary privs.
3. Bootstrap the DB schema and bring it up to the latest version using the *maven-migration-plugin*.
4. Starts the service using the [jetty-maven-plugin](http://eclipse.org/jetty/documentation/current/jetty-maven-plugin.html) configured with the generated DB and pointed at authProxy (ready to test).
5. Runs the integration tests (aka "Green Build" tests).
6. Tear down the DB schema by running all UNDO migrations using the *maven-migration-plugin*.
7. Drop the Oracle DB user.

If you want a service stood up for local testing with this dynamically generated DB then do the following:

```
./test -Dmaven.failsafe.debug
```

or

```
mvn -Plocal-int-test -Dmaven.failsafe.debug clean install
```

This will cause the build to halt before running the tests (just after step 4 above) and wait for a remote debugger to attach.
