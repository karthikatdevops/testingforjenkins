package com.theplatform.data.tv.entity.integration.test.endpoint.person;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.test.PersonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.module.exception.BadParameterException;

/**
 * 
 * Basic Sort tests for Person
 * 
 * @since 4/7/2011
 */
@Test(groups = { "person", "sort" })
public class PersonSortIT extends EntityTestBase {



	private static final int PERSONS_TO_CREATE = 4;
	private List<Person> persons;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		this.persons = personFactory.create(PERSONS_TO_CREATE);
		this.personClient.create(persons);

	}


	@Test(groups = TestGroup.testBug)
	public void testSortAscendingPersonByOwnerId() throws UnknownHostException {
		// UPDATE VALUES
		this.persons.get(3).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/123"));
		this.persons.get(0).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/222"));
		this.persons.get(2).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/1311"));
		this.persons.get(1).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/1531"));

		this.personClient.update(this.persons);

		// SORT EXPECTED
		List<Person> expectedSortedPersons = new ArrayList<>(persons.size());
		expectedSortedPersons.add(this.persons.get(3));
		expectedSortedPersons.add(this.persons.get(0));
		expectedSortedPersons.add(this.persons.get(2));
		expectedSortedPersons.add(this.persons.get(1));

		// RETRIVE WHITH SORTING
		String sortFiedld = "ownerId";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<Person> retrievedPersons = this.personClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		PersonComparator.assertEquals(retrievedPersons, expectedSortedPersons);
	}

	@Test
	public void testSortAscendingPersonByBirthName() throws UnknownHostException {

		// UPDATE VALUES
		this.persons.get(0).setBirthName("BBBB");
		this.persons.get(1).setBirthName("AAAA");
		this.persons.get(2).setBirthName("ZZZBB");
		this.persons.get(3).setBirthName("ABBBB");
		for (Person person : persons) {
			person.setCredits(null);
			person.setImageIds(null);
			person.setSelectedImages(null);
		}
		this.personClient.update(this.persons);
		for (Person person : persons) {
			person.setImageIds(new ArrayList<URI>());
			person.setSelectedImages(new ArrayList<MainImageInfo>());
			person.setCredits(new ArrayList<CreditAssociation>());
		}

		// SORT EXPECTED PERSONS
		List<Person> expectedSortedPersons = new ArrayList<>(this.persons.size());
		expectedSortedPersons.add(this.persons.get(1));
		expectedSortedPersons.add(this.persons.get(3));
		expectedSortedPersons.add(this.persons.get(0));
		expectedSortedPersons.add(this.persons.get(2));

		// RETRIVE WHITH SORTING
		String sortFiedld = "birthName";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<Person> retrievedPersons = this.personClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		PersonComparator.assertEquals(retrievedPersons, expectedSortedPersons);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableFieldSortBio() throws UnknownHostException {
		// RETRIVE WHITH SORTING
		String sortField = "shortBio";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortField, sortDescending);
		this.personClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
	}
}
