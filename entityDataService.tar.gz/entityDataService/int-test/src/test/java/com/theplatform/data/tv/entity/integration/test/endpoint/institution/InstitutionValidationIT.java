package com.theplatform.data.tv.entity.integration.test.endpoint.institution;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * GreenBuild test for validation of Institution including verification of
 * various invalid creations
 * 
 * @author clai200
 * 
 */
public class InstitutionValidationIT extends EntityTestBase {

	/**
	 * Test of creation of an Institution instance with null title, non-null
	 * description. Creation should fail due to null title which is required for
	 * Institution
	 */
	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testCreationWithNullTitle() {
		Institution input = this.institutionFactory.create();

		input.setTitle(null);
		input.setDescription("test description");

		this.institutionClient.create(input);
	}

	/**
	 * Test of creation of an Institution instance with empty title, non-null
	 * description. Creation should fail due to empty title which is required
	 * for Institution
	 */
	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testCreationWithEmptyTitle() {
		Institution input = this.institutionFactory.create();

		input.setTitle("");
		input.setDescription("test description");

		this.institutionClient.create(input);
	}

	/**
	 * Test of creation of an Institution instance with over max length title,
	 * non-null description. Creation should fail due to over long title which
	 * is required for Institution
	 */
	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testCreationWithOverMaxTitleLength() {
		Institution input = this.institutionFactory.create();

		// each line is 50 charactor long
		input.setTitle("abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde");
		input.setDescription("test description");

		this.institutionClient.create(input);
	}

	/**
	 * Test of creation of an Institution instance with valid title, null
	 * description. Creation should succeed because Description should be
	 * optional.
	 */
	@Test(enabled = false)
	public void testCreationWithNullDescription() {
		// TODO to be implements
	}

}
