package com.theplatform.data.tv.entity.integration.test.endpoint.programteamassociation;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */
@Test(groups = { "programTeamAssociation", "sort", "other" })
public class ProgramTeamAssociationSortIT extends EntityTestBase {

	private List<ProgramTeamAssociation> programTeamAssociations;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		this.programTeamAssociationClient.create(programTeamAssociations);

	}


	public void testSortBySortFields() throws UnknownHostException {
		List<Sort> supportedSorts = new ArrayList<>();
		boolean sortDescending = false;
		supportedSorts.add(new Sort("id", sortDescending));
		supportedSorts.add(new Sort("programId", sortDescending));
		supportedSorts.add(new Sort("sportsTeamId", sortDescending));
		supportedSorts.add(new Sort("homeAway", sortDescending));
		supportedSorts.add(new Sort("competition", sortDescending));
		for (int i = 0; i < 5; i++) {
			Feed<ProgramTeamAssociation> sortedProgramTeamAssociation = this.programTeamAssociationClient.getOwned(new String[] {}, new Query[] {},
					new Sort[] { supportedSorts.get(i) }, null, false);
			// TODO: verify equality
			// comparator.assertProgramTeamAssociationsEqual(sortedProgramTeamAssociation
			// , programTeamAssociations);
		}
	}
}
