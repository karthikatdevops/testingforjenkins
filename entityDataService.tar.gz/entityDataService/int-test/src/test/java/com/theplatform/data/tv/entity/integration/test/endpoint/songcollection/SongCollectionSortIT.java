package com.theplatform.data.tv.entity.integration.test.endpoint.songcollection;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SongCollection;
import com.theplatform.data.tv.entity.api.test.SongCollectionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "songCollection", "sort" })
public class SongCollectionSortIT extends EntityTestBase {

	public void testSongCollectionSortByGuid() {
		List<SongCollection> songCollections = songCollectionFactory.create(4);
		songCollections.get(0).setGuid("1");
		songCollections.get(3).setGuid("2");
		songCollections.get(1).setGuid("3");
		songCollections.get(2).setGuid("4");

		this.songCollectionClient.create(songCollections);

		List<SongCollection> expectedSortedSongCollections = new ArrayList<>(songCollections.size());
		expectedSortedSongCollections.add(songCollections.get(0));
		expectedSortedSongCollections.add(songCollections.get(3));
		expectedSortedSongCollections.add(songCollections.get(1));
		expectedSortedSongCollections.add(songCollections.get(2));

		Feed<SongCollection> retrievedSongCollections = this.songCollectionClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort("guid", false) }, null, false);

		SongCollectionComparator.assertEquals(retrievedSongCollections, expectedSortedSongCollections);
	}

	public void testSongCollectionSortByTitle() {
		List<SongCollection> songCollections = songCollectionFactory.create(4);
		songCollections.get(0).setTitle("A");
		songCollections.get(2).setTitle("B");
		songCollections.get(3).setTitle("C");
		songCollections.get(1).setTitle("D");

		this.songCollectionClient.create(songCollections);

		List<SongCollection> expectedSortedSongCollections = new ArrayList<>(songCollections.size());
		expectedSortedSongCollections.add(songCollections.get(0));
		expectedSortedSongCollections.add(songCollections.get(2));
		expectedSortedSongCollections.add(songCollections.get(3));
		expectedSortedSongCollections.add(songCollections.get(1));

		Feed<SongCollection> retrievedSongCollections = this.songCollectionClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("title",
				false) }, null, false);

		SongCollectionComparator.assertEquals(retrievedSongCollections, expectedSortedSongCollections);
	}
	
	//only one valid type so no sorting by type
	
	public void testSongCollectionSortBySubtype() {
		List<SongCollection> songCollections = songCollectionFactory.create(2);
		songCollections.get(0).setSubtype("Language");
		songCollections.get(1).setSubtype("Content");

		this.songCollectionClient.create(songCollections);

		List<SongCollection> expectedSortedSongCollections = new ArrayList<>(songCollections.size());
		expectedSortedSongCollections.add(songCollections.get(1));
		expectedSortedSongCollections.add(songCollections.get(0));

		Feed<SongCollection> retrievedSongCollections = this.songCollectionClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("subtype",
				false) }, null, false);

		SongCollectionComparator.assertEquals(retrievedSongCollections, expectedSortedSongCollections);
	}
}
