package com.theplatform.data.tv.entity.integration.test.filter;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.field.NamespacedFieldInfo;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.MerlinTestReflectionUtil;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.client.RequestParameters;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import com.theplatform.data.tv.entity.api.fields.EntityCollectionField;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.SportsEventField;
import com.theplatform.data.tv.entity.api.fields.SportsTeamField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.image.api.data.objects.MainImageTypeGroup;
import com.theplatform.data.tv.image.api.fields.MainImageFileField;
import com.theplatform.data.tv.image.api.fields.MainImageInfoField;
import com.theplatform.data.tv.image.api.fields.MainImageTypeField;
import com.theplatform.data.tv.image.api.test.MainImageInfoComparator;
import com.theplatform.data.tv.image.api.test.MainImageInfoUtils;

@Test(groups = { "fieldFilter", TestGroup.gbTest })
public class FieldFilterSelectedImagesIT extends EntityTestBase {

	private static NamespacedFieldInfo[] ALL_MAINIMAGEINFO_FIELDINFOS = { 
		new NamespacedFieldInfo(MainImageInfoField.mainImageTypeId,"mainImageTypeId"),
		new NamespacedFieldInfo(MainImageInfoField.url,"url"), 
		new NamespacedFieldInfo(MainImageInfoField.width,"width"),
		new NamespacedFieldInfo(MainImageInfoField.height, "height"),
		new NamespacedFieldInfo(MainImageInfoField.alias,"alias"),
		//TODO MERLIN-8987 need to figure out how to set a value to imageCredit
//		new NamespacedFieldInfo(MainImageInfoField.imageCredit,"imageCredit"),
		new NamespacedFieldInfo(MainImageInfoField.requiresAttribution,"requiresAttribution")
		};

	public void testGetFullSelectedImagesFromProgram() {
		Program expected = this.programFactory.create();

		Program actual = this.programClient.create(expected);

		MainImageTypeGroup mainImageTypeGroup = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create());
		MainImageType mainImageType = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(mainImageTypeGroup.getId()))),
				new String[] {});
		Assert.assertNotNull(mainImageType.getMainImageTypeGroupIds());

		MainImageFile mainImageFile = this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, actual.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageType.getId()));
		mainImageFile.setUrl("mainImageFile url");
		mainImageFile.setWidth(100);
		mainImageFile.setHeight(200);
		mainImageFile.setRequiresAttribution(false);

		mainImageFile = this.mainImageFileClient.create(mainImageFile, new String[] {});

		MainImageInfo selectedImage = MainImageInfoUtils.getMainImageInfo(mainImageFile, mainImageType);
		
		for (NamespacedFieldInfo fieldInfo: ALL_MAINIMAGEINFO_FIELDINFOS)
			Assert.assertNotNull(MerlinTestReflectionUtil.get(selectedImage, fieldInfo.getFieldName()));

		expected.setSelectedImages(Arrays.asList(selectedImage));

		Assert.assertNotNull(mainImageType.getMainImageTypeGroupIds());
		Assert.assertEquals(mainImageType.getMainImageTypeGroupIds().size(), 1);
		Assert.assertNotNull(mainImageType.getMainImageTypeGroupIds().get(0));
		Long mainImageTypeGroupId = URIUtils.getIdValue(mainImageType.getMainImageTypeGroupIds().get(0));

		RequestParameters requestParameters = new RequestParameters();
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("bySelectedImages.mainImageTypeGroupId", "" + mainImageTypeGroupId);

		requestParameters.setParameters(parameterMap);

		actual = this.programClient.get(actual.getId(), new String[] {}, requestParameters);
		actual.getSelectedImages().get(0).setGroupIds(expected.getSelectedImages().get(0).getGroupIds());

		MainImageInfoComparator.assertEquals(actual.getSelectedImages(), expected.getSelectedImages());
	}

	@DataProvider
	private Object[][] dataObjectsAndClients() {
		return new Object[][] { { this.programFactory.create(), this.programClient }, { this.personFactory.create(), this.personClient },
				{ this.entityCollectionFactory.create(), this.entityCollectionClient }, { this.creditFactory.create(), this.creditClient },
				{ this.sportsEventFactory.create(), this.sportsEventClient }, { this.sportsTeamFactory.create(), this.sportsTeamClient }, };
	}

	@DataProvider
	private Object[][] dataObjectsAndClientsAndFullyQualifiedSelectedImages() {
		return new Object[][] { { this.programFactory.create(), this.programClient, ProgramField.selectedImages.getQualifiedName() },
				{ this.personFactory.create(), this.personClient, PersonField.selectedImages.getQualifiedName() },
				{ this.entityCollectionFactory.create(), this.entityCollectionClient, EntityCollectionField.selectedImages.getQualifiedName() },
				{ this.creditFactory.create(), this.creditClient, CreditField.selectedImages.getQualifiedName() },
				{ this.sportsEventFactory.create(), this.sportsEventClient, SportsEventField.selectedImages.getQualifiedName() },
				{ this.sportsTeamFactory.create(), this.sportsTeamClient, SportsTeamField.selectedImages.getQualifiedName() }, };
	}

	@Test(dataProvider = "dataObjectsAndClients")
	@SuppressWarnings({ "rawtypes" })
	public void testGetDataObjectNoParameter(DataObject inputEntity, DataServiceClient client) {
		MainImageInfoPair result = this.createActualAndExpectedSelectedImagesDataObject(inputEntity, client);
		MainImageInfoComparator.assertEquals(result.getActual(), result.getExpected());

	}

	@Test(dataProvider = "dataObjectsAndClients")
	@SuppressWarnings({ "rawtypes" })
	public void testGetDataObjectWithSelectedImages(DataObject inputEntity, DataServiceClient client) {

		MainImageInfoPair result = this.createActualAndExpectedSelectedImagesDataObject(inputEntity, client, "selectedImages");
		MainImageInfoComparator.assertEquals(result.getActual(), result.getExpected());
	}

	@Test(dataProvider = "dataObjectsAndClientsAndFullyQualifiedSelectedImages")
	@SuppressWarnings({ "rawtypes" })
	public void testGetDataObjectWithFullyQualifiedSelectedImages(DataObject inputEntity, DataServiceClient client, String fullyQualifiedSelectedImages) {

		MainImageInfoPair result = this.createActualAndExpectedSelectedImagesDataObject(inputEntity, client, fullyQualifiedSelectedImages);
		MainImageInfoComparator.assertEquals(result.getActual(), result.getExpected());
	}

	@Test(dataProvider = "dataObjectsAndClients")
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void testGetDataObjectWithSelectedImagesSingleField(DataObject inputEntity, DataServiceClient client) {

		DataObject entity = client.create(inputEntity);

		MainImageTypeGroup mainImageTypeGroup = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create());
		MainImageType mainImageType = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(mainImageTypeGroup.getId()))),
				new String[] {});

		MainImageFile mainImageFile = this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entity.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageType.getId()));
		mainImageFile.setUrl("mainImageFile url");
		mainImageFile.setWidth(100);
		mainImageFile.setHeight(200);
		mainImageFile.setRequiresAttribution(false);

		mainImageFile = this.mainImageFileClient.create(mainImageFile, new String[] {});

		MainImageInfo selectedImage = MainImageInfoUtils.getMainImageInfo(mainImageFile, mainImageType);
		for (NamespacedFieldInfo fieldInfo: ALL_MAINIMAGEINFO_FIELDINFOS)
			Assert.assertNotNull(MerlinTestReflectionUtil.get(selectedImage, fieldInfo.getFieldName()));

		Assert.assertNotNull(mainImageType.getMainImageTypeGroupIds());
		Assert.assertEquals(mainImageType.getMainImageTypeGroupIds().size(), 1);
		Assert.assertNotNull(mainImageType.getMainImageTypeGroupIds().get(0));
		Long mainImageTypeGroupId = URIUtils.getIdValue(mainImageType.getMainImageTypeGroupIds().get(0));
		MerlinTestReflectionUtil.set(inputEntity, "selectedImages", Arrays.asList(selectedImage));
		RequestParameters requestParameters = new RequestParameters();
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("bySelectedImages.mainImageTypeGroupId", "" + mainImageTypeGroupId);

		requestParameters.setParameters(parameterMap);
		
		final URI entityId = entity.getId();
		
		for (NamespacedFieldInfo fieldInfo : ALL_MAINIMAGEINFO_FIELDINFOS) {
			entity = client.get(entityId, new String[] { "selectedImages",
					"selectedImage.".concat(fieldInfo.getField().getLocalName()) }, requestParameters);

			List<MainImageInfo> actualSelectedImages = (List<MainImageInfo>) MerlinTestReflectionUtil.get(entity, "selectedImages");
			Assert.assertEquals(actualSelectedImages.size(), 1);
			Assert.assertNotNull(actualSelectedImages.get(0));
			Assert.assertEquals(MerlinTestReflectionUtil.get(actualSelectedImages.get(0), fieldInfo.getFieldName()),
					MerlinTestReflectionUtil.get(selectedImage, fieldInfo.getFieldName()));

			entity = client.get(entityId, new String[] { "selectedImages",
					"selectedImage.".concat(fieldInfo.getField().getQualifiedName()) }, requestParameters);

			actualSelectedImages = (List<MainImageInfo>) MerlinTestReflectionUtil.get(entity, "selectedImages");
			Assert.assertEquals(actualSelectedImages.size(), 1);
			Assert.assertNotNull(actualSelectedImages.get(0));
			Assert.assertEquals(MerlinTestReflectionUtil.get(actualSelectedImages.get(0), fieldInfo.getFieldName()),
					MerlinTestReflectionUtil.get(selectedImage, fieldInfo.getFieldName()));
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private MainImageInfoPair createActualAndExpectedSelectedImagesDataObject(DataObject inputEntity, DataServiceClient client, String... fields) {

		DataObject entity = client.create(inputEntity);

		MainImageTypeGroup mainImageTypeGroup = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create());
		MainImageType mainImageType = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(mainImageTypeGroup.getId()))),
				new String[] {});

		MainImageFile mainImageFile = this.mainImageFileClient.create(mainImageFileFactory.create(
				new DataServiceField(MainImageFileField.entityId, entity.getId()),
				new DataServiceField(MainImageFileField.mainImageTypeId, mainImageType.getId())), new String[] {});

		MainImageInfo selectedImage = MainImageInfoUtils.getMainImageInfo(mainImageFile, mainImageType);

		Assert.assertNotNull(mainImageType.getMainImageTypeGroupIds());
		Assert.assertEquals(mainImageType.getMainImageTypeGroupIds().size(), 1);
		Assert.assertNotNull(mainImageType.getMainImageTypeGroupIds().get(0));
		Long mainImageTypeGroupId = URIUtils.getIdValue(mainImageType.getMainImageTypeGroupIds().get(0));
		MerlinTestReflectionUtil.set(inputEntity, "selectedImages", Arrays.asList(selectedImage));

		List<String> getParameters = fields == null ? new ArrayList<String>() : Arrays.asList(fields);

		RequestParameters requestParameters = new RequestParameters();
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("bySelectedImages.mainImageTypeGroupId", "" + mainImageTypeGroupId);

		requestParameters.setParameters(parameterMap);
		
		entity = client.get(entity.getId(), getParameters.toArray(new String[] {}), requestParameters);

		List<MainImageInfo> actualSelectedImages = (List<MainImageInfo>) MerlinTestReflectionUtil.get(entity, "selectedImages");
		Assert.assertEquals(actualSelectedImages.size(), 1);
		Assert.assertNotNull(actualSelectedImages.get(0));

		MainImageInfoPair result = new MainImageInfoPair();

		result.setActual(actualSelectedImages.get(0));
		result.setExpected(selectedImage);
		return result;
	}

	private class MainImageInfoPair {
		private MainImageInfo actual;
		private MainImageInfo expected;

		public MainImageInfo getActual() {
			return actual;
		}

		public void setActual(MainImageInfo actual) {
			this.actual = actual;
		}

		public MainImageInfo getExpected() {
			return expected;
		}

		public void setExpected(MainImageInfo expected) {
			this.expected = expected;
		}
	}

}
