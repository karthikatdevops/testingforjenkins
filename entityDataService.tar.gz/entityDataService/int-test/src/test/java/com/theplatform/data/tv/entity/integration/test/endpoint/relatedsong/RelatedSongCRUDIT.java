package com.theplatform.data.tv.entity.integration.test.endpoint.relatedsong;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.RelatedSong;
import com.theplatform.data.tv.entity.api.fields.RelatedSongField;
import com.theplatform.data.tv.entity.api.test.RelatedSongComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "relatedSong", "crud" })
public class RelatedSongCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testSingleRelatedSongCrud() {
		RelatedSong entity = this.relatedSongFactory.create();

		// CREATE
		RelatedSong persistedEntity = this.relatedSongClient.create(entity, new String[] {});
		RelatedSongComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		RelatedSong retrievedEntity = this.relatedSongClient.get(entity.getId(), new String[] {});
		RelatedSongComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setSourceSongId(this.songClient.create(this.songFactory.create()).getId());
		entity.setTargetSongId(this.songClient.create(this.songFactory.create()).getId());
		// there is only one RelatedSongType for now
		// entity.setType(entity.getType() != null && entity.getType() !=
		// RelatedSongType.IsSimilar.getFriendlyName() ?
		// RelatedSongType.IsSimilar
		// .getFriendlyName() : RelatedSongType.IsSimilar.getFriendlyName());
		entity.setRank(entity.getRank() != null ? entity.getRank() + 1 : 1);

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		this.relatedSongClient.update(entity);

		RelatedSong retrievedAfterUpdate = this.relatedSongClient.get(entity.getId(), new String[] {});
		RelatedSongComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = this.relatedSongClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.relatedSongClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("RelatedSong should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testRelatedSongFeedCrud() throws UnknownHostException {
		List<RelatedSong> entities = this.relatedSongFactory.create(5);

		// CREATE
		Feed<RelatedSong> persistedEntities = this.relatedSongClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			RelatedSongComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i));

		URI[] entityIds = new URI[entities.size()];
		for (int i = 0; i < entityIds.length; i++)
			entityIds[i] = entities.get(i).getId();

		// RETRIEVE
		Feed<RelatedSong> retrievedEntities = this.relatedSongClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			RelatedSongComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i));

		// DELETE
		long deletedEntities = this.relatedSongClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (RelatedSong entity : entities) {
			try {
				this.relatedSongClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedSongDefaultFieldValues() {
		RelatedSong entity = this.relatedSongFactory.create();

		entity.setRank(null);
		entity.setMerlinResourceType(null);
		RelatedSong actual = this.relatedSongClient.create(entity, new String[] {});

		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		RelatedSongComparator.assertEquals(actual, entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(RelatedSongField.rank, null),
			new DataServiceField(RelatedSongField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedSongCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(relatedSongClient, relatedSongFactory.create(), RelatedSongComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedSongCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(relatedSongClient, relatedSongFactory.create(), RelatedSongComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedSongUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(RelatedSongField.rank, 1));
		createValues.add(new DataServiceField(RelatedSongField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(relatedSongClient, relatedSongFactory.create(), RelatedSongComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testRelatedSongUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(RelatedSongField.rank, 1));
		createValues.add(new DataServiceField(RelatedSongField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(relatedSongClient, relatedSongFactory.create(), RelatedSongComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}
}
