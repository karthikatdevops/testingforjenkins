package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;

import com.theplatform.contrib.util.MerlinUriUtil;
import com.theplatform.data.api.client.RequestParameters;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;

/**
 * @since 4/7/2011
 * @author jethrolai
 * 
 * 
 *         FIXME there is latency after updating TagAssociation
 */
@Test(groups = { "program" })
public class ProgramTagsCRUDIT extends EntityTestBase {

	/**
	 * 1 ) Create program 2 ) Get program; validate that doesn't have any tags 3
	 * ) Create Tag 4 ) Create Tag Association which link to tag & program 5 )
	 * Update program 6 ) Get program; validate that it has correct Tag
	 * Association 7 ) Update tag 8 ) Update tag association 9 ) Update program
	 * 10) Get program; validate that it has updated Tag Association 11) Delete
	 * Tag Association 12) Update program 13) Get program; validate that doesn't
	 * have any Tag Association
	 * 
	 * @throws UnknownHostException
	 *             Exception
	 */
	@Test(groups = { TestGroup.gbTest })
	public void crudSingleTag() throws UnknownHostException {
		// Create Program
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// RETRIEVE
		Program retrievedProgramOnce = this.programClient.get(inputProgram.getId(), new String[] { ProgramField.tagIds.getLocalName() });
		Assert.assertEquals(retrievedProgramOnce.getTagIds().size(), 0);
		// Create Association
		Tag tag = this.tagFactory.create();
		this.tagClient.create(tag);
		TagAssociation inputTagAssociation = this.tagAssociationFactory.create();
		inputTagAssociation.setEntityId(inputProgram.getId());
		inputTagAssociation.setTagId(tag.getId());
		this.tagAssociationClient.create(inputTagAssociation);
		// RETRIEVE
		inputProgram.setYear(1980);
		this.programClient.update(inputProgram);
		Program retrievedProgramAgain = this.programClient.get(inputProgram.getId(), new String[] { ProgramField.tagIds.getLocalName() });
		Assert.assertEquals(retrievedProgramAgain.getTagIds().size(), 1);
		Assert.assertEquals(tag.getId(), retrievedProgramAgain.getTagIds().get(0));

		// UPDATE tag association & program both and retrieve program
		tag = this.tagFactory.create();
		this.tagClient.create(tag);
		inputTagAssociation.setTagId(tag.getId());
		this.tagAssociationClient.update(inputTagAssociation);
		inputProgram.setYear(1999);
		this.programClient.update(inputProgram);
		Program retrieveAfterUpdateOnce = this.programClient.get(inputProgram.getId(), new String[] { ProgramField.tagIds.getLocalName() });
		Assert.assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 1, "Updated Program has one Tag");
		Assert.assertEquals(tag.getId(), retrieveAfterUpdateOnce.getTagIds().get(0));

		// DELETE tag, update program & retrieve program
		this.tagAssociationClient.delete(inputTagAssociation.getId());
		inputProgram.setYear(2000);
		this.programClient.update(inputProgram);
		Program retrieveAfterUpdateAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		Assert.assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0, "Updated Program has no Tag");

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		Assert.assertEquals(1, deletedObjects);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		Assert.fail("Program should not be found after deleting it");
	}

	/**
	 * 1 ) Create program 2 ) Get program; validate that doesn't have any tags 3
	 * ) Create Tag 4 ) Create Tag Association which link to tag & program 5 )
	 * Get program; validate that it has correct Tag Association 6 ) Update tag
	 * 7 ) Update tag association 8 ) Get program; validate that it has updated
	 * Tag Association 9 ) Delete Tag Association 10) Get program; validate that
	 * doesn't have any Tag Association
	 * 
	 * @throws UnknownHostException
	 *             Exception
	 */
	@Test(groups = { TestGroup.gbTest })
	public void crudSingleCachingTag() throws UnknownHostException {
		// Create Program
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// RETRIEVE
		Program retrievedProgramOnce = this.programClient.get(inputProgram.getId(), new String[] { ProgramField.tagIds.getLocalName() });
		Assert.assertEquals(retrievedProgramOnce.getTagIds().size(), 0);
		// Create Association
		Tag tag = this.tagFactory.create();
		this.tagClient.create(tag);
		TagAssociation inputTagAssociation = this.tagAssociationFactory.create();
		inputTagAssociation.setEntityId(inputProgram.getId());
		inputTagAssociation.setTagId(tag.getId());
		this.tagAssociationClient.create(inputTagAssociation);

		inputProgram.setYear(1981);
		programClient.update(inputProgram);
		// RETRIEVE
		Program retrievedProgramAgain = this.programClient.get(inputProgram.getId(), new String[] { ProgramField.tagIds.getLocalName() });
		Assert.assertEquals(retrievedProgramAgain.getTagIds().size(), 1);
		Assert.assertEquals(tag.getId(), retrievedProgramAgain.getTagIds().get(0));

		// UPDATE tag association & program both and retrieve program
		tag = this.tagFactory.create();
		this.tagClient.create(tag);
		inputTagAssociation.setTagId(tag.getId());
		this.tagAssociationClient.update(inputTagAssociation);
		inputProgram.setYear(1980);
		programClient.update(inputProgram);
		Program retrieveAfterUpdateOnce = this.programClient.get(inputProgram.getId(), new String[] { ProgramField.tagIds.getLocalName() });
		Assert.assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 1);
		Assert.assertEquals(tag.getId(), retrieveAfterUpdateOnce.getTagIds().get(0));

		// DELETE tag, update program & retrieve program
		this.tagAssociationClient.delete(inputTagAssociation.getId());
		inputProgram.setYear(1981);
		programClient.update(inputProgram);
		Program retrieveAfterUpdateAgain = this.programClient.get(inputProgram.getId(), new String[] { ProgramField.tagIds.getLocalName() });
		Assert.assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0);

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		Assert.assertEquals(1, deletedObjects);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		Assert.fail("Program should not be found after deleting it");
	}

	/**
	 * 1 ) Create program 2 ) Get program; validate that doesn't have any tags 3
	 * ) Create Tag Association which link to program 4 ) Get program; validate
	 * that it has correct Tag Association 5 ) Update Tag Association 6 ) Get
	 * program; validate that it has updated Tag Association 7 ) Delete Tag
	 * Association 8 ) Get program; validate that doesn't have any Tag
	 * Association
	 * 
	 * @throws UnknownHostException
	 *             Exception
	 */
	@Test(groups = TestGroup.testBug)
	public void crudSingleCacheInvalidationTag() throws UnknownHostException {
		// Create Program
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// RETRIEVE
		Program retrievedProgramOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgramOnce.getTagIds().size(), 0, "Program has no Tag");
		assertEquals(retrievedProgramOnce.getVersion(), new Long("0"), "Before creating tags link to Program then version should be zero");

		// Create Association
		TagAssociation inputTagAssociation = this.tagAssociationFactory.create();
		inputTagAssociation.setEntityId(inputProgram.getId());
		this.tagAssociationClient.create(inputTagAssociation);
		// RETRIEVE
		Program retrievedProgramAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgramAgain.getTagIds().size(), 1, "Created Program has one Tag");
		assertEquals(inputTagAssociation.getTagId(), retrievedProgramAgain.getTagIds().get(0));
		assertEquals(retrievedProgramAgain.getVersion(), new Long("1"), "After created tags link to Program then version should be one");
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramOnce.getUpdated().before(retrievedProgramAgain.getUpdated())
		// );

		// UPDATE association & program both and retrieve program
		inputTagAssociation.setTagId(this.tagFactory.create().getId());
		this.tagAssociationClient.update(inputTagAssociation);
		Program retrieveAfterUpdateOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 1, "Updated Program has one Tag");
		assertEquals(inputTagAssociation.getTagId(), retrieveAfterUpdateOnce.getTagIds().get(0));
		assertEquals(retrieveAfterUpdateOnce.getVersion(), new Long("2"), "After updating tags which link to Program then version should be two");
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramOnce.getUpdated().before(retrieveAfterUpdateOnce.getUpdated())
		// );
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramAgain.getUpdated().before(retrieveAfterUpdateOnce.getUpdated())
		// );

		// DELETE association & retrieve program
		this.tagAssociationClient.delete(inputTagAssociation.getId());
		Program retrieveAfterUpdateAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0, "Updated Program has no Tag");
		assertEquals(retrieveAfterUpdateOnce.getVersion(), new Long("3"), "After deleting tags which link to Program then version should be three");
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramOnce.getUpdated().before(retrieveAfterUpdateAgain.getUpdated())
		// );
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramAgain.getUpdated().before(retrieveAfterUpdateAgain.getUpdated())
		// );
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrieveAfterUpdateOnce.getUpdated().before(retrieveAfterUpdateAgain.getUpdated())
		// );

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		assertEquals(1, deletedObjects);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
			fail("Program should not be found after deleting it");
		} catch (ObjectNotFoundException e) {
			// ok
		}
	}

	@Test(groups = TestGroup.testBug)
	public void crudCollectionOfTags() throws UnknownHostException {
		// Create Program
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// RETRIEVE
		Program retrievedProgramOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgramOnce.getTagIds().size(), 0, "Program has no Tag");
		// Create Association
		List<Tag> inputTags = this.tagFactory.create(5);
		this.tagClient.create(inputTags);
		List<TagAssociation> inputTagAssociations = this.tagAssociationFactory.create(5);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
		for (int i = 0; i < 5; i++) {
			inputTagAssociations.get(i).setEntityId(inputProgram.getId());
			inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());
		}
		this.tagAssociationClient.create(inputTagAssociations);
		// RETRIEVE
		inputProgram.setYear(1998);
		this.programClient.update(inputProgram);
		Program retrievedProgramAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgramAgain.getTagIds().size(), 5, "Created Program has five Tags");
		for (int i = 0; i < 5; i++) {
			assertEquals(inputTags.get(i).getId(), retrievedProgramAgain.getTagIds().get(i));
		}

		// UPDATE tag association & program both and retrieve program
		inputTags = this.tagFactory.create(5);
		this.tagClient.create(inputTags);
		for (int i = 0; i < 5; i++) {
			inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());
		}
		this.tagAssociationClient.update(inputTagAssociations);
		inputProgram.setYear(1999);
		this.programClient.update(inputProgram);
		Program retrieveAfterUpdateOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 5, "Updated Program has five Tag");
		for (int i = 0; i < 5; i++) {
			assertEquals(inputTags.get(i).getId(), retrieveAfterUpdateOnce.getTagIds().get(i));
		}

		// DELETE tag, update program & retrieve program
		this.tagAssociationClient.delete(tagAssociationIds);
		inputProgram.setYear(2000);
		this.programClient.update(inputProgram);
		Program retrieveAfterUpdateAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0, "Updated Program has no Tag");

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		assertEquals(1, deletedObjects);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		fail("Program should not be found after deleting it");
	}

	public void crudCollectionOfTagsCaching() throws UnknownHostException, InterruptedException {
		// Create Program
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// RETRIEVE
		Program retrievedProgramOnce = this.programClient.get(inputProgram.getId(), new String[] { ProgramField.tagIds.getLocalName() });
		Assert.assertEquals(retrievedProgramOnce.getTagIds().size(), 0);

		inputProgram.setYear(1984);
		programClient.update(inputProgram);
		// Create Association
		List<Tag> inputTags = this.tagFactory.create(5);
		this.tagClient.create(inputTags);
		List<TagAssociation> inputTagAssociations = this.tagAssociationFactory.create(5);
		@SuppressWarnings({ "unchecked" })
		URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
		for (int i = 0; i < 5; i++) {
			inputTagAssociations.get(i).setEntityId(inputProgram.getId());
			inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());
		}
		this.tagAssociationClient.create(inputTagAssociations);

		inputProgram.setYear(1984);
		programClient.update(inputProgram);
		// RETRIEVE
		Program retrievedProgramAgain = this.programClient.get(inputProgram.getId(), new String[] { ProgramField.tagIds.getLocalName() });
		Assert.assertEquals(retrievedProgramAgain.getTagIds().size(), 5);
		for (int i = 0; i < 5; i++)
			Assert.assertEquals(inputTags.get(i).getId(), retrievedProgramAgain.getTagIds().get(i));

		// UPDATE tag association & program both and retrieve program
		inputTags = this.tagFactory.create(5);
		this.tagClient.create(inputTags);
		for (int i = 0; i < 5; i++)
			inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());

		this.tagAssociationClient.update(inputTagAssociations);
		inputProgram.setYear(1984);
		programClient.update(inputProgram);

		Program retrieveAfterUpdateOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		Assert.assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 5);
		inputProgram.setYear(1985);
		programClient.update(inputProgram);
		for (int i = 0; i < 5; i++)
			Assert.assertEquals(inputTags.get(i).getId(), retrieveAfterUpdateOnce.getTagIds().get(i));

		// DELETE tag, update program & retrieve program
		this.tagAssociationClient.delete(tagAssociationIds);

		Program retrieveAfterUpdateAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		Assert.assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0);

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		Assert.assertEquals(1, deletedObjects);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		Assert.fail("Program should not be found after deleting it");
	}

	@Test(groups = TestGroup.testBug)
	public void crudCollectionOfCacheInvalidationTags() throws UnknownHostException {
		// Create Program
		List<Program> inputPrograms = this.programFactory.create(3);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
		this.programClient.create(inputPrograms);
		// RETRIEVE
		Feed<Program> retrievedProgramOnce = this.programClient.get(programIds, new String[] {});
		for (Program program : retrievedProgramOnce.getEntries()) {
			assertEquals(program.getTagIds().size(), 0, "Program has no Tag");
			assertEquals(program.getVersion(), new Long("0"), "Before creating tags link to Program, version should be zero");
		}

		// Create Association
		List<TagAssociation> inputTagAssociations = this.tagAssociationFactory.create(3);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		inputTagAssociations.get(0).setEntityId(inputPrograms.get(0).getId());
		inputTagAssociations.get(1).setEntityId(inputPrograms.get(1).getId());
		inputTagAssociations.get(2).setEntityId(inputPrograms.get(1).getId());
		this.tagAssociationClient.create(inputTagAssociations);
		// RETRIEVE
		Feed<Program> retrievedProgramAgain = this.programClient.get(programIds, new String[] {});
		for (Program program : retrievedProgramAgain.getEntries()) {
			if (inputPrograms.get(0).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("1"), "After create Program version should be one");
				assertEquals(program.getTagIds().size(), 1, "This program has one tag");
				assertEquals(program.getTagIds().get(0), inputTagAssociations.get(0).getId(), "is program has right tag ?");
			} else if (inputPrograms.get(1).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("1"), "After create Program version should be one");
				assertEquals(program.getTagIds().size(), 2, "This program has two tags");
				assertEquals(program.getTagIds().get(0), inputTagAssociations.get(2).getId(), "is program has right tag ?");
				assertEquals(program.getTagIds().get(1), inputTagAssociations.get(1).getId(), "is program has right tag ?");
			} else {
				assertEquals(program.getVersion(), new Long("0"), "After create Program version should be one");
				assertEquals(program.getTagIds().size(), 0, "This program has no tag");
			}
		}

		// UPDATE association & program both and retrieve program
		List<Tag> inputTags = this.tagFactory.create(3);
		for (int i = 0; i < 3; i++)
			inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());

		this.tagAssociationClient.update(inputTagAssociations);
		Feed<Program> retrieveAfterUpdateOnce = this.programClient.get(programIds, new String[] {});
		for (Program program : retrieveAfterUpdateOnce.getEntries()) {
			if (inputPrograms.get(0).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("2"), "After create Program version should be one");
				assertEquals(program.getTagIds().size(), 1, "This program has one tag");
				assertEquals(program.getTagIds().get(0), inputTagAssociations.get(0).getId(), "is program has right tag ?");
			} else if (inputPrograms.get(1).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("2"), "After create Program version should be one");
				assertEquals(program.getTagIds().size(), 2, "This program has two tags");
				assertEquals(program.getTagIds().get(0), inputTagAssociations.get(2).getId(), "is program has right tag ?");
				assertEquals(program.getTagIds().get(1), inputTagAssociations.get(1).getId(), "is program has right tag ?");
			} else {
				assertEquals(program.getVersion(), new Long("0"), "After create Program version should be one");
				assertEquals(program.getTagIds().size(), 0, "This program has no tag");
			}
		}

		// DELETE association, update program & retrieve program
		this.tagAssociationClient.delete(tagAssociationIds);
		Feed<Program> retrieveAfterUpdateAgain = this.programClient.get(programIds, new String[] {});
		for (Program program : retrieveAfterUpdateAgain.getEntries()) {
			if (inputPrograms.get(0).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("3"), "After create Program version should be one");
				assertEquals(program.getTagIds().size(), 0, "This program has one tag");
			} else if (inputPrograms.get(1).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("3"), "After create Program version should be one");
				assertEquals(program.getTagIds().size(), 0, "This program has two tags");
			} else {
				assertEquals(program.getVersion(), new Long("0"), "After create Program version should be one");
				assertEquals(program.getTagIds().size(), 0, "This program has no tag");
			}
		}

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(programIds);
		assertEquals(3, deletedObjects);
		for (Program program : inputPrograms) {
			try {
				this.programClient.get(program.getId(), new String[] {});
				fail("Program should not be found after deleting it");
			} catch (ObjectNotFoundException e) {
				// ok
			}
		}
	}

    @Test(groups = TestGroup.testBug)
    public void crudTagIdsFilterTest() throws UnknownHostException {
        // Create Program
        Program inputProgram = this.programFactory.create();
        this.programClient.create(inputProgram);
        // Create Association
        List<Tag> inputTags = this.tagFactory.create(5);
        this.tagClient.create(inputTags);
        List<TagAssociation> inputTagAssociations = this.tagAssociationFactory.create(5);
        @SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
        URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations,
                                    TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
        for (int i = 0; i < 5; i++) {
            inputTagAssociations.get(i).setEntityId(inputProgram.getId());
            inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());
        }
        this.tagAssociationClient.create(inputTagAssociations);
        // RETRIEVE
        inputProgram.setYear(1998);
        this.programClient.update(inputProgram);
        Program retrievedProgramAgain = this.programClient.get(inputProgram.getId(), new String[] {});
        assertEquals(retrievedProgramAgain.getTagIds().size(), 5, "Created Program has five Tags");

        // Retrieve program with tagIdsFilter parameter and make sure only the selected tags are returned:
        RequestParameters requestParameters = new RequestParameters();
        HashMap<String, String> parameters = new HashMap<>();
        parameters.put("tagIdsFilter", MerlinUriUtil.getIdValue(inputTags.get(1).getId()) + "|" + MerlinUriUtil.getIdValue(inputTags.get(3).getId()));
        requestParameters.setParameters(parameters);
        retrievedProgramAgain = this.programClient.get(inputProgram.getId(), new String[] {}, requestParameters);
        assertEquals(retrievedProgramAgain.getTagIds().size(), 2, "Filtered Program has two Tags");

        // Not sure what order the two tags will be in, so check both possibilities:
        assertTrue(retrievedProgramAgain.getTagIds().get(0).equals(inputTags.get(1).getId()) ||
                   retrievedProgramAgain.getTagIds().get(0).equals(inputTags.get(3).getId()));
        if (retrievedProgramAgain.getTagIds().get(0).equals(inputTags.get(1).getId())) {
            assertEquals(retrievedProgramAgain.getTagIds().get(1), inputTags.get(3).getId());
        }
        else {
            assertEquals(retrievedProgramAgain.getTagIds().get(1), inputTags.get(1).getId());
        }

        // DELETE Program (It's part of cleaning up database at the end of each test case)
        long deletedObjects = this.programClient.delete(inputProgram.getId());
        assertEquals(1, deletedObjects);
        try {
            this.programClient.get(inputProgram.getId(), new String[] {});
        } catch (ObjectNotFoundException e) {
            // ok
            return;
        }
        fail("Program should not be found after deleting it");
    }
}
