package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.client.query.ValueQuery;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.program.ByLanguage;
import com.theplatform.data.tv.entity.api.client.query.program.ByStarRating;
import com.theplatform.data.tv.entity.api.client.query.program.ByType;
import com.theplatform.data.tv.entity.api.client.query.program.ByYear;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;

/**
 * 
 * @author clai200
 * @since 4/7/2011
 */
@Test(groups = { "program", TestGroup.testBug })
public class ProgramMerlinEditorialIT extends EntityTestBase {

	private static final Sort SORT_BY_ID_ASC[] = new Sort[] { new Sort("id", false) };
	
	private List<Program> inputPrograms;
	private List<Program> editorialPrograms;
	private List<Program> nonEditorialPrograms;
	public static final int NUM_PROGRAMS = 7;
	public static final int NUM_EDITORIAL_PROGRAMS = 3;
	public static final int NUM_AUDIENCE_AVAIL_PROGRAMS = NUM_PROGRAMS - NUM_EDITORIAL_PROGRAMS;

	
	/**
	 * FIXME com.theplatform.module.exception.AuthorizationException: You do not have permission to update 'http://xml.theplatform.com/data/tv/entity/Program:credits'.
	 * @throws UnknownHostException
	 */
	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {

		// nothing now
		inputPrograms = new ArrayList<Program>();
		inputPrograms.add(this.programFactory.create(ProgramType.Advertisement));
		inputPrograms.add(this.programFactory.create(ProgramType.Concert));
		inputPrograms.add(this.programFactory.create(ProgramType.Movie));
		inputPrograms.add(this.programFactory.create(ProgramType.MusicVideo));
		inputPrograms.add(this.programFactory.create(ProgramType.Other));
		inputPrograms.add(this.programFactory.create(ProgramType.Preview));
		inputPrograms.add(this.programFactory.create(ProgramType.SeriesMaster));

		/*
		 * Make 3 of the programs editorial, and of those, make 2 of them have a
		 * null merlinResourceType so we can later verify that the returned
		 * Programs are all marked Editorial
		 */
		inputPrograms.get(4).setId(URI.create(this.getBaseUrl() + "/data/Program/" + "6536839374452227500"));
		inputPrograms.get(4).setMerlinResourceType(null);
		inputPrograms.get(5).setId(URI.create(this.getBaseUrl() + "/data/Program/" + "6536839374452227501"));
		inputPrograms.get(5).setMerlinResourceType(MerlinResourceType.Editorial);
		inputPrograms.get(6).setId(URI.create(this.getBaseUrl() + "/data/Program/" + "6536839374452227502"));
		inputPrograms.get(6).setMerlinResourceType(null);

		nonEditorialPrograms = new ArrayList<Program>();
		nonEditorialPrograms.add(inputPrograms.get(0));
		nonEditorialPrograms.add(inputPrograms.get(1));
		nonEditorialPrograms.add(inputPrograms.get(2));
		nonEditorialPrograms.add(inputPrograms.get(3));

		editorialPrograms = new ArrayList<Program>();
		editorialPrograms.add(inputPrograms.get(4));
		editorialPrograms.add(inputPrograms.get(5));
		editorialPrograms.add(inputPrograms.get(6));

		for (int i = 0; i < inputPrograms.size(); i++) {
			inputPrograms.get(i).setTitle(inputPrograms.get(i).getTitle() + " " + i);
		}

		this.programClient.create(inputPrograms);

		/*
		 * After creating, set expectations that all in editorial id range are
		 * marked as Editorial, even the ones that were null to begin with
		 */
		inputPrograms.get(4).setMerlinResourceType(MerlinResourceType.Editorial);
		inputPrograms.get(5).setMerlinResourceType(MerlinResourceType.Editorial);
		inputPrograms.get(6).setMerlinResourceType(MerlinResourceType.Editorial);
	}
	

	@Test(groups = { "other" })
	public void testQueryEditorialProgramByMerlinResourceType() throws UnknownHostException {
		// query
		Query queries[] = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.getAll(null, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_EDITORIAL_PROGRAMS,
				"Not get all Programs using query ByMerlinResourceType=Editorial");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_EDITORIAL_PROGRAMS,
				"Not get Programs entry count using query ByMerlinResourceType=Editorial");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_EDITORIAL_PROGRAMS,
				"Not get Programs total entry count using query ByMerlinResourceType=Editorial");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, editorialPrograms);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testQueryAudienceProgramByMerlinResourceType() {
		// query
		Query queries[] = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.getAll(null, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get all Programs using query ByMerlinResourceType=AudienceAvailable");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs entry count using query ByMerlinResourceType=AudienceAvailable");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs total entry count using query ByMerlinResourceType=AudienceAvailable");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);
	}

	@Test(groups = { "other" })
	public void testQueryAllProgramByMerlinResourceType() {
		// query
		Query queries[] = new Query[] { new ByMerlinResourceType(Arrays.asList(new MerlinResourceType[] {
				MerlinResourceType.Editorial, MerlinResourceType.AudienceAvailable })) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.getAll(null, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_PROGRAMS,
				"Not get all Programs using query ByMerlinResourceType=AudienceAvailable & Editorial");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_PROGRAMS,
				"Not get Programs entry count using query ByMerlinResourceType=AudienceAvailable & Editorial");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_PROGRAMS,
				"Not get Programs total entry count using query ByMerlinResourceType=AudienceAvailable & Editorial");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, inputPrograms);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testGetProgramsByIdsAndNullQueries() {
		@SuppressWarnings({ "unchecked" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId"))
				.toArray(new URI[] {});
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.get(programIds, new String[] {}, null, sorts, null);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get all Programs with out using ByMerlinResourceType i.e. get byIds & query null");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. get byIds & query null");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testGetProgramsByIdsAndByTitles() {
		@SuppressWarnings({ "unchecked" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId"))
				.toArray(new URI[] {});
		List<String> titles = new ArrayList<String>();
		for (Program program : inputPrograms) {
			titles.add(program.getTitle());
		}
		// query
		Query queries[] = new Query[] { new ByTitle(titles) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.get(programIds, new String[] {}, queries, sorts, null);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get all Programs with out using ByMerlinResourceType i.e. get byIds & byTitle");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. get byIds & byTitle");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);
	}

	@Test(groups = { "other" })
	public void testGetProgramsByIds() {
		@SuppressWarnings({ "unchecked" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId"))
				.toArray(new URI[] {});
		Feed<Program> retrievedPrograms = this.programClient.get(programIds, new String[] {});
		assertEquals(retrievedPrograms.getEntries().size(), NUM_PROGRAMS,
				"Not get all Programs with out using ByMerlinResourceType i.e. get byIds & byTitle");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_PROGRAMS,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. get byIds & byTitle");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, inputPrograms);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testGetProgramsById() {
		Program retrievedProgram = this.programClient.get(inputPrograms.get(6).getId(), new String[] {});
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedProgram, inputPrograms.get(6));
	}

	@Test(groups = { TestGroup.gbTest })
	public void testGetProgramsByTitle() {
		List<String> titles = new ArrayList<String>();
		for (Program program : inputPrograms) {
			titles.add(program.getTitle());
		}
		// query
		Query queries[] = new Query[] { new ByTitle(titles) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.getAll(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get all Programs with out using ByMerlinResourceType i.e. getAll ByTitle");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. getAll ByTitle");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs total results with out using ByMerlinResourceType i.e. getAll ByTitle");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);

		retrievedPrograms = this.programClient.getOwned(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get all Programs with out using ByMerlinResourceType i.e. getOwned ByTitle");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. getOwned ByTitle");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs total results with out using ByMerlinResourceType i.e. getOwned ByTitle");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testGetProgramsByYear() {
		List<Integer> years = new ArrayList<Integer>();
		for (Program program : inputPrograms) {
			years.add(program.getYear());
		}
		// query
		Query queries[] = new Query[] { new ByYear(years) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.getAll(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get all Programs with out using ByMerlinResourceType i.e. getAll byYear ");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. getAll byYear ");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs total results with out using ByMerlinResourceType i.e. getAll byYear ");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);

		retrievedPrograms = this.programClient.getOwned(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get all Programs with out using ByMerlinResourceType i.e. getOwned byYear ");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. getOwned byYear ");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs total results with out using ByMerlinResourceType i.e. getOwned byYear ");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testGetProgramsByStarRating() {
		List<Integer> starRating = new ArrayList<Integer>();
		for (Program program : inputPrograms) {
			starRating.add(program.getStarRating());
		}
		// query
		Query queries[] = new Query[] { new ByStarRating(starRating) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.getAll(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get all Programs with out using ByMerlinResourceType i.e. getAll ByStarRating ");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. getAll ByStarRating ");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs total results with out using ByMerlinResourceType i.e. getAll ByStarRating ");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);

		retrievedPrograms = this.programClient.getOwned(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get all Programs with out using ByMerlinResourceType i.e. getOwned ByStarRating ");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. getOwned ByStarRating ");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"Not get Programs total results with out using ByMerlinResourceType i.e. getOwned ByStarRating ");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testGetProgramsByType() {
		// query
		Query queries[] = new Query[] { new ByType(ProgramType.SeriesMaster) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.getAll(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), 0,
				"Not get all Programs with out using ByMerlinResourceType i.e. getAll byType ");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), 0,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. getAll byType ");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), 0,
				"Not get Programs total results with out using ByMerlinResourceType i.e. getAll byType ");

		retrievedPrograms = this.programClient.getOwned(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), 0,
				"Not get all Programs with out using ByMerlinResourceType i.e. getOwned byType ");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), 0,
				"Not get Programs entry count with out using ByMerlinResourceType i.e. getOwned byType ");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), 0,
				"Not get Programs total results with out using ByMerlinResourceType i.e. getOwned byType ");
	}

	@Test(groups = { "other" })
	public void testGetProgramsByTypeUsingWrongType() {
		// query
		Query queries[] = new Query[] { new ValueQuery<String>("type", "!)") };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };

		try {
			this.programClient.getAll(new String[] {}, queries, sorts, null, true);
			fail("Query byType should fail when an invalid type is used");
		} catch (BadParameterException e) {

		}

	}


	@Test(groups = { "other" })
	public void testDeleteProgramsById() {
		URI programId = inputPrograms.get(6).getId();
		long count = this.programClient.delete(programId);
		assertEquals(count, 1, "Not delete Program using program id");
	}

	@Test(groups = { "other" })
	public void testDeleteProgramsByIds() {
		URI[] programIds = new URI[3];
		programIds[0] = inputPrograms.get(0).getId();
		programIds[1] = inputPrograms.get(1).getId();
		programIds[2] = inputPrograms.get(4).getId();

		long count = this.programClient.delete(programIds);
		assertEquals(count, 3, "Not deleted all Programs using byIds");
	}

	@Test(groups = { "other" })
	public void testDeleteProgramsByTitle() {
		List<String> titles = new ArrayList<String>();
		titles.add(inputPrograms.get(2).getTitle());
		titles.add(inputPrograms.get(3).getTitle());
		titles.add(inputPrograms.get(5).getTitle());
		// query
		Query queries[] = new Query[] { new ByTitle(titles) };
		long count = this.programClient.delete(queries);
		assertEquals(count, 2, "Not delete Program using byTitle query");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testGetProgramsByListsOfLanguage() {
		List<String> languages = new ArrayList<String>();
		for (Program program : inputPrograms) {
			languages.add(program.getLanguage());
		}
		// query
		Query queries[] = new Query[] { new ByLanguage(languages) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"All non-editorial Programs entry size byLanguage");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"All non-editorial Programs entry count byLanguage");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"All non-editorial Programs total results byLanguage");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testGetProgramsBySingleLanguage() {
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] { new ByLanguage(
				inputPrograms.get(0).getLanguage()) }, sorts, null, true);
		assertEquals(retrievedPrograms.getEntries().size(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"All non-editorial Programs entry size byLanguage");
		assertEquals(retrievedPrograms.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"All non-editorial Programs entry count byLanguage");
		assertEquals(retrievedPrograms.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_PROGRAMS,
				"All non-editorial Programs total results byLanguage");
		// to make comparison for all fields
		ProgramComparator.assertEquals(retrievedPrograms, nonEditorialPrograms);
	}

}
