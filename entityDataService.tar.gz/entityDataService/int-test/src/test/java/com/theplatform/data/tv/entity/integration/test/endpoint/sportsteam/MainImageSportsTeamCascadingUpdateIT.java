package com.theplatform.data.tv.entity.integration.test.endpoint.sportsteam;

import java.lang.reflect.InvocationTargetException;
import java.net.UnknownHostException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;

/**
 * Created by IntelliJ IDEA. User: Vinay Date: Jan 21, 2011 Time: 2:06:16 PM To
 * change this template use File | Settings | File Templates.
 * 
 * @since 4/8/2011
 */
@SuppressWarnings("deprecation")
@Test(groups = { "sportsTeam", "other" })
public class MainImageSportsTeamCascadingUpdateIT extends EntityTestBase {

	/**
	 * 1. Create SportsTeam 2. Verify SportsTeam.version = 0 3. Verify
	 * SportsTeam has no Main Image 4. Create MainImageFile 1 linking to Sports
	 * Team 5. Verify Sports Team.version = 1 6. Verify Sports Team has 1 main
	 * Image 7. Create MainImageFile 2 linking to Sports Team 8. Verify
	 * SportsTeam.version = 2 9. Verify Sports Team has 2 main Images 7. Delete
	 * MainImageFile 1 8. Verify Sports Team.version = 3 9. Verify Sports Team
	 * has 1 main Images 10. Update Main Image 2 11. Verify Sports Team has
	 * version =4
	 * 
	 * @throws UnknownHostException
	 *             Exception
	 * @throws InterruptedException
	 *             Exception
	 * @throws NoSuchFieldException
	 * @throws NoSuchMethodException
	 * @throws InstantiationException
	 * @throws ClassNotFoundException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 */
	@Test(groups = TestGroup.testBug)
	public void testSportsTeamSelectedImagesCascadingUpdateValidationTest() throws UnknownHostException, InterruptedException, IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		SportsTeam sportsTeam = this.sportsTeamClient.create(this.sportsTeamFactory.create(), new String[] {});
		Assert.assertEquals(sportsTeam.getVersion(), new Long(0));
		Assert.assertEquals(sportsTeam.getSelectedImages().size(), 0);

		MainImageFile mainImageFile1 = mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField("entityId", sportsTeam.getId())),
				new String[] {});
		sportsTeam = this.sportsTeamClient.get(sportsTeam.getId(), new String[] {});
		Assert.assertEquals(sportsTeam.getVersion(), new Long(1));
		Assert.assertEquals(sportsTeam.getSelectedImages().size(), 1);

		MainImageFile mainImageFile2 = mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField("entityId", sportsTeam.getId())),
				new String[] {});

		sportsTeam.setDescription(sportsTeam.getDescription() == null ? "description" : sportsTeam.getDescription().concat(" updated"));
		sportsTeamClient.update(sportsTeam);

		sportsTeam = this.sportsTeamClient.get(sportsTeam.getId(), new String[] {});
		Assert.assertEquals(sportsTeam.getVersion(), new Long(2));
		Assert.assertEquals(sportsTeam.getSelectedImages().size(), 2);

		mainImageFileClient.delete(mainImageFile1.getId());

		sportsTeam.setDescription(sportsTeam.getDescription() == null ? "description" : sportsTeam.getDescription().concat(" updated"));
		sportsTeamClient.update(sportsTeam);

		sportsTeam = this.sportsTeamClient.get(sportsTeam.getId(), new String[] {});
		Assert.assertEquals(sportsTeam.getVersion(), new Long(3));
		Assert.assertEquals(sportsTeam.getSelectedImages().size(), 1);

		mainImageFile2.setHeight(mainImageFile2.getHeight() == null ? 10 : mainImageFile2.getHeight() + 1);

		sportsTeam.setDescription(sportsTeam.getDescription() == null ? "description" : sportsTeam.getDescription().concat(" updated"));
		sportsTeamClient.update(sportsTeam);

		sportsTeam = this.sportsTeamClient.get(sportsTeam.getId(), new String[] {});
		Assert.assertEquals(sportsTeam.getVersion(), new Long(3));

	}

}
