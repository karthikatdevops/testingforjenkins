package com.theplatform.data.tv.entity.integration.test.endpoint.institution;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.fields.InstitutionField;
import com.theplatform.data.tv.entity.api.test.InstitutionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * GreenBuild test for CRUD operations of Institution
 * 
 * @author clai200
 * @since 4/7/2011
 * 
 */
@Test(groups = { "institution", "crud" })
public class InstitutionCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void crudSingleInstitution() throws UnknownHostException {
		Institution entity = this.institutionFactory.create();

		// CREATE
		Institution persistedEntity = institutionClient.create(entity);
		assertEquals(persistedEntity.getId(), entity.getId(), "Institution ids should match after creation");

		// RETRIEVE
		Institution retrievedEntity = this.institutionClient.get(entity.getId(), new String[] {});
		InstitutionComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setDescription("new description");
		this.institutionClient.update(entity);

		Institution retrievedAfterUpdate = this.institutionClient.get(entity.getId(), new String[] {});
		InstitutionComparator.assertEquals(retrievedAfterUpdate, entity);
		assertFalse(retrievedEntity.getDescription().equals(retrievedAfterUpdate.getDescription()));

		// DELETE
		long deletedObjects = this.institutionClient.delete(entity.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.institutionClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("Institution should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudInstitutionFeed() throws UnknownHostException {
		List<Institution> entities = this.institutionFactory.create(5);
		@SuppressWarnings({ "unchecked" })
		URI[] entityIds = (URI[]) CollectionUtils.collect(entities, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		// Feed<Institution> persistedEntities =
		this.institutionClient.create(entities);

		Feed<Institution> persistedEntities = this.institutionClient.create(entities);

		ComparatorUtils.assertIdsAreEqual(entities, persistedEntities);

		// RETRIEVE
		Feed<Institution> retrievedEntities = this.institutionClient.get(entityIds, new String[] {});
		InstitutionComparator.assertEquals(retrievedEntities, entities);

		// DELETE
		long deletedEntities = this.institutionClient.delete(entityIds);
		assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (Institution entity : entities) {
			try {
				this.institutionClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(DataObjectField.description, null),
			// If not set on create defaults to 'AudienceAvailable', or
			// 'Editorial' if
			// ID has editorial suffix
			new DataServiceField(InstitutionField.merlinResourceType, MerlinResourceType.AudienceAvailable), };

	@Test(groups = { TestGroup.gbTest })
	public void testInstitutionCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(institutionClient, institutionFactory.create(), InstitutionComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testInstitutionCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(institutionClient, institutionFactory.create(), InstitutionComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testInstitutionUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "institution description"));
		createValues.add(new DataServiceField(InstitutionField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(institutionClient, institutionFactory.create(), InstitutionComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testInstitutionUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "institution description"));
		createValues.add(new DataServiceField(InstitutionField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(institutionClient, institutionFactory.create(), InstitutionComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

}
