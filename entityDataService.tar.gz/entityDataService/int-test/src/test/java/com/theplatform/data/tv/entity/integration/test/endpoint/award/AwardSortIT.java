package com.theplatform.data.tv.entity.integration.test.endpoint.award;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.test.AwardComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;

/**
 * GreenBuild test for sorting of Award
 * 
 * @author clai200
 * 
 */

@Test(groups = { TestGroup.gbTest, "award", "sort" })
public class AwardSortIT extends EntityTestBase {



	private static final int TEST_LIST_SIZE = 4;

	private List<Award> awards;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		awards = this.awardFactory.create(TEST_LIST_SIZE);
		this.awardClient.create(awards);

	}


	public void testAwardSortByTitleAlphabetically() {
		awards.get(3).setTitle("A");
		awards.get(0).setTitle("B");
		awards.get(1).setTitle("C");
		awards.get(2).setTitle("D");

		this.awardClient.update(awards);

		// SORT EXPECTED
		List<Award> expectedSortedAwards = new ArrayList<>(awards.size());
		expectedSortedAwards.add(awards.get(3));
		expectedSortedAwards.add(awards.get(0));
		expectedSortedAwards.add(awards.get(1));
		expectedSortedAwards.add(awards.get(2));

		// RETRIVE WHITH SORTING
		String sortFiedld = "title";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<Award> retrievedAwards = this.awardClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		AwardComparator.assertEquals(retrievedAwards, expectedSortedAwards);
	}

	public void testAwardSortByRankingAscendingly() {
		awards.get(3).setRank(1);
		awards.get(0).setRank(2);
		awards.get(1).setRank(3);
		awards.get(2).setRank(4);

		this.awardClient.update(awards);

		// SORT EXPECTED
		List<Award> expectedSortedAwards = new ArrayList<>(awards.size());
		expectedSortedAwards.add(awards.get(3));
		expectedSortedAwards.add(awards.get(0));
		expectedSortedAwards.add(awards.get(1));
		expectedSortedAwards.add(awards.get(2));

		// RETRIVE WHITH SORTING
		String sortFiedld = "rank";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<Award> retrievedAwards = this.awardClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		AwardComparator.assertEquals(retrievedAwards, expectedSortedAwards);
	}

	@Test(expectedExceptions = BadParameterException.class, dataProvider = "invalidSortFields")
	public void testAwardSortByInvalidFields(String invalidSortField) {
		this.awardClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(invalidSortField, false) }, null, false);
	}

	@DataProvider
	public Object[][] invalidSortFields() {
		return new Object[][] { new Object[] { "merlinResourceType" }, new Object[] { "description" } };
	}
}
