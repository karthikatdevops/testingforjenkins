package com.theplatform.data.tv.entity.integration.test.endpoint.ratingsmapping;

import com.theplatform.contrib.data.api.objects.RatingScheme;
import com.theplatform.contrib.testing.comparator.DataObjectComparator;
import com.theplatform.contrib.testing.crud.CrudTestBase;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.contrib.testing.provider.GBTestIdProvider;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.NamespacedField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.RatingsMappingClient;
import com.theplatform.data.tv.entity.api.data.objects.RatingsMapping;
import com.theplatform.data.tv.entity.api.fields.RatingsMappingField;
import com.theplatform.data.tv.entity.api.test.RatingsMappingComparator;
import com.theplatform.data.tv.entity.test.api.data.factory.RatingsMappingFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/*
 * Created by lemuri200 on 6/2/15.
 */
public class RatingsMappingCRUDIT extends CrudTestBase<RatingsMapping> {
    @Autowired
    @Qualifier("baseEntityUrl")
    private String baseEntityUrl;

    @Resource
    protected RatingsMappingClient ratingsMappingClient;

    @Resource
    protected RatingsMappingFactory ratingsMappingFactory;

    @Resource
    protected RatingsMappingComparator ratingsMappingComparator;

    @Resource
    protected GBTestIdProvider objectIdProvider;

    @Override
    protected ValueProvider<Long> getValueProvider() { return objectIdProvider; }

    @Override
    protected DataServiceClient<RatingsMapping> getClient() {
        return ratingsMappingClient;
    }

    @Override
    protected DataObjectComparator<RatingsMapping> getComparator() {
        return ratingsMappingComparator;
    }

    @Override
    protected DataObjectFactory<RatingsMapping, RatingsMappingClient> getDataObjectFactory() {
        return ratingsMappingFactory;
    }

    @Override
    protected Map<NamespacedField, Object> getUpdateValues(RatingsMapping originalObject) {
        Map<NamespacedField, Object> updateValues = new HashMap<>();
        updateValues.put(RatingsMappingField.sourceRatingSystem, RatingScheme.AGVOT.getScheme());
        updateValues.put(RatingsMappingField.targetRatingSystem, RatingScheme.MPAA.getScheme());

        Map<String, String> ratingsMap = new HashMap<>();
        ratingsMap.put("18+", "R");

        updateValues.put(RatingsMappingField.ratingsMap, ratingsMap);
        updateValues.put(RatingsMappingField.merlinResourceType, MerlinResourceType.AudienceAvailable);
        return updateValues;
    }

    @Override
    protected void populateDependencies(RatingsMapping rawObject) {
    }

    @Override
    protected Set<NamespacedField> getRequiredFields() {
        Set<NamespacedField> required = new HashSet<>();

        required.add(RatingsMappingField.sourceRatingSystem);
        required.add(RatingsMappingField.targetRatingSystem);
        return required;
    }

    @Override
    protected Set<NamespacedField> getNullableFields() {
        Set<NamespacedField> nullable = new HashSet<>();

        nullable.add(DataObjectField.title);
        nullable.add(RatingsMappingField.ratingsMap);

        return nullable;
    }
}
