package com.theplatform.data.tv.entity.integration.test.endpoint.programrank;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ExcludeField;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.entity.api.fields.ProgramRankField;
import com.theplatform.data.tv.entity.api.test.ProgramRankComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "programRank", "crud" })
// TODO ProgramRank.program is loosely denormalized
public class ProgramRankCRUDIT extends EntityTestBase {

	private static DataServiceField[] nonRequiredFields = new DataServiceField[] { new DataServiceField(ProgramRankField.merlinResourceType,
			MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	// Using PUT or client.update has error, so use create instead
	public void crudSingleProgramRank() throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		ProgramRank entity = this.programRankFactory.create();

		// CREATE
		ProgramRank persistedEntity = this.programRankClient.create(entity, new String[] {});
		entity.setId(persistedEntity.getId());
		entity.setGuid(persistedEntity.getGuid());
		programRankComparator.assertEquals(persistedEntity, entity, new ExcludeField("program"));

		// RETRIEVE
		ProgramRank retrievedEntity = this.programRankClient.get(persistedEntity.getId(), new String[] {});
		programRankComparator.assertEquals(retrievedEntity, entity, new ExcludeField("program"));

		// UPDATE
		entity.setRank(entity.getRank() != null ? entity.getRank() + 1.5f : 3.5f);
		Program program = programClient.create(programFactory.create(), new String[] {});
		entity.setProgramId(program.getId());

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);

		entity.setId(null);
		entity.setProgram(null);
		entity.setVersion(null);
		this.programRankClient.create(entity);
		entity.setProgram(program);

		ProgramRank retrievedAfterUpdate = this.programRankClient.get(persistedEntity.getId(), new String[] {});
		programRankComparator.assertEquals(retrievedAfterUpdate, entity, new ExcludeField("program"), new ExcludeField("id"));

		// DELETE
		long deletedObjects = this.programRankClient.delete(persistedEntity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.programRankClient.get(persistedEntity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("ProgramRank should not be found after deleting it");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramRankFeedCrud() throws UnknownHostException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		List<ProgramRank> entities = this.programRankFactory.create(5);

		// CREATE
		Feed<ProgramRank> persistedEntities = this.programRankClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			programRankComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i), new ExcludeField("program"), new ExcludeField("id"),
					new ExcludeField("guid"));

		URI[] entityIds = new URI[persistedEntities.getEntries().size()];
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			entityIds[i] = persistedEntities.getEntries().get(i).getId();

		// RETRIEVE
		Feed<ProgramRank> retrievedEntities = this.programRankClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			programRankComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i), new ExcludeField("program"), new ExcludeField("id"),
					new ExcludeField("guid"));

		// DELETE
		long deletedEntities = this.programRankClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (ProgramRank entity : persistedEntities.getEntries()) {
			try {
				this.programRankClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramRankCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		ProgramRank expected = this.programRankFactory.create();
		expected.setMerlinResourceType(null);

		ProgramRank actual = programRankClient.create(expected, new String[] {});

		expected.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		programRankComparator.assertEquals(actual, expected, new ExcludeField("program"), new ExcludeField("id"), new ExcludeField("guid"));
	}

	@Test(groups = { TestGroup.testBug })
	public void testProgramRankCreateWithAllNullNonRequiredFieldsGeneric() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		// FIXME can't use this because ProgramRank.program is loosely
		// denormalized, need to update comparator to only compare those fields.
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(programRankClient, programRankFactory.create(), ProgramRankComparator.class,
				nonRequiredFields, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramRankCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		ProgramRank expected = this.programRankFactory.create();
		expected.setNull(ProgramRankField.merlinResourceType);

		ProgramRank actual = programRankClient.create(expected, new String[] {});

		expected.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		programRankComparator.assertEquals(actual, expected, new ExcludeField("program"), new ExcludeField("id"), new ExcludeField("guid"));
	}

	@Test(groups = { TestGroup.testBug })
	public void testProgramRankUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		ProgramRank expected = this.programRankFactory.create();
		expected.setMerlinResourceType(MerlinResourceType.Temporary);

		ProgramRank actual = programRankClient.create(expected, new String[] {});
		expected.setMerlinResourceType(null);

		expected.setGuid(actual.getGuid());
		expected.setId(null);
		expected.setProgram(null);
		expected.setVersion(null);
		actual = programRankClient.create(expected, new String[] {});

		expected.setMerlinResourceType(MerlinResourceType.Temporary);
		programRankComparator.assertEquals(actual, expected, new ExcludeField("program"), new ExcludeField("id"), new ExcludeField("guid"));
	}

	@Test(groups = { TestGroup.testBug })
	public void testProgramRankUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		ProgramRank expected = this.programRankFactory.create();
		expected.setMerlinResourceType(MerlinResourceType.Temporary);

		ProgramRank actual = programRankClient.create(expected, new String[] {});
		expected.setNull(ProgramRankField.merlinResourceType);

		expected.setGuid(actual.getGuid());
		expected.setId(null);
		expected.setProgram(null);
		expected.setVersion(null);
		// this is actually update
		actual = programRankClient.create(expected, new String[] {});

		expected.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		programRankComparator.assertEquals(actual, expected, new ExcludeField("program"), new ExcludeField("id"), new ExcludeField("guid"));
	}


}
