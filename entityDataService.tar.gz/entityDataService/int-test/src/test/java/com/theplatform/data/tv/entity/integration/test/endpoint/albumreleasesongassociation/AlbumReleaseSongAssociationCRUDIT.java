package com.theplatform.data.tv.entity.integration.test.endpoint.albumreleasesongassociation;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseSongAssociationField;
import com.theplatform.data.tv.entity.api.test.AlbumReleaseSongAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "albumReleaseSongAssociation", "crud" })
public class AlbumReleaseSongAssociationCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testSingleAlbumReleaseSongAssociationCrud() {
		AlbumReleaseSongAssociation entity = albumReleaseSongAssociationFactory.create();

		// CREATE
		AlbumReleaseSongAssociation persistedEntity = albumReleaseSongAssociationClient.create(entity, new String[] {});
		AlbumReleaseSongAssociationComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		AlbumReleaseSongAssociation retrievedEntity = albumReleaseSongAssociationClient.get(entity.getId(), new String[] {});
		AlbumReleaseSongAssociationComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setAlbumReleaseId(albumReleaseClient.create(albumReleaseFactory.create()).getId());
		entity.setSongId(songClient.create(songFactory.create()).getId());

		entity.setTrackNumber(entity.getTrackNumber() != null ? entity.getTrackNumber() + 1 : 1);

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		albumReleaseSongAssociationClient.update(entity);

		AlbumReleaseSongAssociation retrievedAfterUpdate = albumReleaseSongAssociationClient.get(entity.getId(), new String[] {});
		AlbumReleaseSongAssociationComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = albumReleaseSongAssociationClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			albumReleaseSongAssociationClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("AlbumReleaseSongAssociation should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testAlbumReleaseSongAssociationFeedCrud() throws UnknownHostException {
		List<AlbumReleaseSongAssociation> entities = albumReleaseSongAssociationFactory.create(5);

		// CREATE
		Feed<AlbumReleaseSongAssociation> persistedEntities = albumReleaseSongAssociationClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			AlbumReleaseSongAssociationComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i));

		URI[] entityIds = new URI[entities.size()];
		for (int i = 0; i < entityIds.length; i++)
			entityIds[i] = entities.get(i).getId();

		// RETRIEVE
		Feed<AlbumReleaseSongAssociation> retrievedEntities = albumReleaseSongAssociationClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			AlbumReleaseSongAssociationComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i));

		// DELETE
		long deletedEntities = albumReleaseSongAssociationClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (AlbumReleaseSongAssociation entity : entities) {
			try {
				albumReleaseSongAssociationClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumReleaseSongAssociationDefaultFieldValues() {
		AlbumReleaseSongAssociation entity = albumReleaseSongAssociationFactory.create();

		entity.setAlbumReleaseId(null);
		entity.setSongId(null);
		entity.setTrackNumber(null);
		entity.setMerlinResourceType(null);
		AlbumReleaseSongAssociation actual = albumReleaseSongAssociationClient.create(entity, new String[] {});

		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		AlbumReleaseSongAssociationComparator.assertEquals(actual, entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, null),
			new DataServiceField(AlbumReleaseSongAssociationField.songId, null), new DataServiceField(AlbumReleaseSongAssociationField.trackNumber, null),
			new DataServiceField(AlbumReleaseSongAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumReleaseSongAssociationCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(albumReleaseSongAssociationClient, albumReleaseSongAssociationFactory.create(),
				AlbumReleaseSongAssociationComparator.class, defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumReleaseSongAssociationCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(albumReleaseSongAssociationClient, albumReleaseSongAssociationFactory.create(),
				AlbumReleaseSongAssociationComparator.class, defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumReleaseSongAssociationUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues
				.add(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient.create(albumReleaseFactory.create()).getId()));
		createValues.add(new DataServiceField(AlbumReleaseSongAssociationField.songId, songClient.create(songFactory.create()).getId()));
		createValues.add(new DataServiceField(AlbumReleaseSongAssociationField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(albumReleaseSongAssociationClient, albumReleaseSongAssociationFactory.create(),
				AlbumReleaseSongAssociationComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testAlbumReleaseSongAssociationUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues
				.add(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient.create(albumReleaseFactory.create()).getId()));
		createValues.add(new DataServiceField(AlbumReleaseSongAssociationField.songId, songClient.create(songFactory.create()).getId()));
		createValues.add(new DataServiceField(AlbumReleaseSongAssociationField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(albumReleaseSongAssociationClient, albumReleaseSongAssociationFactory.create(),
				AlbumReleaseSongAssociationComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}
}
