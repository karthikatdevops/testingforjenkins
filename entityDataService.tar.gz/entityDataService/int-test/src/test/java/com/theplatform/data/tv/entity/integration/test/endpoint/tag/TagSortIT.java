package com.theplatform.data.tv.entity.integration.test.endpoint.tag;

import static org.testng.Assert.assertEquals;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.service.ServiceUtils;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.test.TagComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;

/**
 * User: gservente
 * 
 * Basic Sort tests for Tag
 * 
 * @since 4/8/2011
 */
@Test(groups = { "other" })
public class TagSortIT extends EntityTestBase {

	private static final int TAGS_TO_CREATE = 4;
	private List<Tag> tags;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {

		// make sure no record exist in database before running test
		ServiceUtils.deleteOwnedObjectsInClient(this.tagClient);
		Feed<Tag> retrievedTags = this.tagClient.getAll(new String[] {}, new Query[] {}, new Sort[] {}, null, false);
		assertEquals(retrievedTags.getEntries().size(), 0, "Tags are in database before running GBTestTagSort test cases");

		// CREATE
		tags = this.tagFactory.create(TAGS_TO_CREATE);
		this.tagClient.create(tags);

	}


	@Test(groups = TestGroup.testBug)
	public void testSortAscendingTagByOwnerId() throws UnknownHostException {
		// UPDATE VALUES
		tags.get(3).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/123"));
		tags.get(0).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/222"));
		tags.get(2).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/1311"));
		tags.get(1).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/1531"));

		this.tagClient.update(tags);

		// SORT EXPECTED
		List<Tag> expectedSortedImageAssociations = new ArrayList<>(tags.size());
		expectedSortedImageAssociations.add(tags.get(3));
		expectedSortedImageAssociations.add(tags.get(0));
		expectedSortedImageAssociations.add(tags.get(2));
		expectedSortedImageAssociations.add(tags.get(1));

		// RETRIVE WHITH SORTING
		String sortFiedld = "ownerId";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<Tag> retrievedImageAssociations = this.tagClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		TagComparator.assertEquals(retrievedImageAssociations, expectedSortedImageAssociations);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableField() throws UnknownHostException {
		// RETRIVE WHITH SORTING
		String sortField = "name";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortField, sortDescending);
		this.tagClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
	}
}
