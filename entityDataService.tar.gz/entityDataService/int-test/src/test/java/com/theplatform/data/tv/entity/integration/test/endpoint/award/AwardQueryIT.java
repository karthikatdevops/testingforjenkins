package com.theplatform.data.tv.entity.integration.test.endpoint.award;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.ByTitlePrefix;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.test.AwardComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static org.testng.Assert.assertEquals;

/**
 * GreenBuild test of query of Award
 *
 * @author clai200
 * @since 4/5/2011
 */
@Test(groups = {TestGroup.gbTest, "award", "query"})
public class AwardQueryIT extends EntityTestBase {

    // byTitle
    public void testAwardQueryByTitleNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
        awardClient.create(awardFactory.create(new DataServiceField(DataObjectField.title, "award title")));
        Query queries[] = new Query[]{new ByTitle("award title updated" + new Random().nextInt())};
        Feed<Award> retrievedAwards = awardClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(retrievedAwards.getEntries().size(), 0, "No record found using query byTitle");
    }

    public void testQueryAwardByTitleSingleMatch() {
        List<Award> localAwards = awardFactory.create(3);
        localAwards.get(1).setTitle("Title1");
        awardClient.create(localAwards);
        Query queries[] = new Query[]{new ByTitle(localAwards.get(1).getTitle())};
        Feed<Award> retrievedAwards = awardClient.getAll(null, queries, null, null, null);
        assertEquals(retrievedAwards.getEntries().size(), 1, "Only one record should be found using query byTitle");
        AwardComparator.assertEquals(retrievedAwards.getEntries().get(0), localAwards.get(1));
    }

    public void testAwardQueryByTitleMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        final String expectedTitle = "award title" + new Random().nextInt();

        Award award1 = awardClient.create(awardFactory.create(new DataServiceField(DataObjectField.title, expectedTitle)), new String[]{});
        Award award2 = awardClient.create(awardFactory.create(new DataServiceField(DataObjectField.title, expectedTitle)), new String[]{});
        awardClient.create(awardFactory.create(2));
        Query queries[] = new Query[]{new ByTitle(expectedTitle)};
        Feed<Award> retrievedAwards = awardClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(retrievedAwards.getEntries().size(), 2, "Only 2 records should be found using query byTitle");

        Map<URI, Award> resultMap = new HashMap<>();
        for (Award award : retrievedAwards.getEntries())
            resultMap.put(award.getId(), award);

        AwardComparator.assertEquals(resultMap.get(award1.getId()), award1);
        AwardComparator.assertEquals(resultMap.get(award2.getId()), award2);
    }

    public void queryAwardByTitleShouldReturnOneResultWhenOnlyOneTitleHasThePrefix() {
        List<Award> localAwards = awardFactory.create(3);
        localAwards.get(0).setTitle("otherTitle");
        localAwards.get(1).setTitle("Title1");
        localAwards.get(2).setTitle("YetAnotherTitle");

        awardClient.create(localAwards);
        Query queries[] = new Query[]{new ByTitlePrefix("Titl")};
        Feed<Award> retrievedAwards = awardClient.getAll(null, queries, null, null, null);
        assertEquals(retrievedAwards.getEntries().size(), 1, "No record found using query byTitlePrefix");
        AwardComparator.assertEquals(retrievedAwards.getEntries().get(0), localAwards.get(1));
    }

    public void testQueryAwardByTitlePrefixSingleMatch() {
        // TODO to be implemented

    }

    public void testQueryAwardByTitlePrefixMultipleMatches() {
        // TODO to be implemented
    }

}
