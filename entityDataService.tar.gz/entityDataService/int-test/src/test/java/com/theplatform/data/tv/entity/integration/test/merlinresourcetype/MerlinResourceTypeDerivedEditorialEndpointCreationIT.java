package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;

/**
 * Tests of merlinResourceType fields of derived editorial endpoints(editorial
 * endpoints with parent(s)) during creation.
 * 
 * @author jethrolai
 * @since 9/16/2011
 * 
 */

@Test(groups = { "merlinResourceType", TestGroup.gbTest })
public class MerlinResourceTypeDerivedEditorialEndpointCreationIT extends EntityTestBase {

	private static final MerlinResourceType parentType1 = MerlinResourceType.Inactive;
	private static final MerlinResourceType parentType2 = MerlinResourceType.Temporary;
	private static final MerlinResourceType childType = MerlinResourceType.AudienceAvailable;

	// this can be removed and used MerlinResourceType.values() instead if the
	// order of visibility is the same with the order they are declared
	private final static Map<MerlinResourceType, Integer> typeMap;
	static {
		typeMap = new HashMap<>();
		typeMap.put(MerlinResourceType.AudienceAvailable, 0);
		typeMap.put(MerlinResourceType.Temporary, 1);
		typeMap.put(MerlinResourceType.Editorial, 2);
		typeMap.put(MerlinResourceType.Inactive, 3);

	}

	/***********************************
	 * ProgramMediaAssociation
	 ***********************************/

	public void testMerlinResourceTypeProgramMediaAssociationCreateParentOverride() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Program parent = this.programFactory.create();
		parent.setMerlinResourceType(parentType1);
		parent = this.programClient.create(parent, new String[] {});
		Assert.assertEquals(parent.getMerlinResourceType(), parentType1);

		ProgramMediaAssociation child = this.programMediaAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent.getId());
		child = this.programMediaAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, childType));
	}

	public void testMerlinResourceTypeProgramMediaAssociationUpdateParentOverride() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Program parent = this.programFactory.create();
		parent.setMerlinResourceType(childType);
		Program parentCreated = this.programClient.create(parent, new String[] {});
		Assert.assertEquals(parentCreated.getMerlinResourceType(), childType);

		ProgramMediaAssociation child = this.programMediaAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent.getId());
		ProgramMediaAssociation childCreated = this.programMediaAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent.setMerlinResourceType(parentType1);
		Program parentUpdated = this.programClient.update(parent, new String[] {});
		Assert.assertEquals(parentUpdated.getMerlinResourceType(), parentType1);

		ProgramMediaAssociation childUpdated = this.programMediaAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, childType));
	}

	public void testMerlinResourceTypeRelatedProgramCreateParentOverrideBySourceProgram() {

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(parentType1);
		parent1 = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);

		Program parent2 = this.programFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.programClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		RelatedProgram child = this.relatedProgramFactory.create();
		child.setMerlinResourceType(childType);
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		child.setSourceProgramId(parent1.getId());
		child.setTargetProgramId(parent2.getId());
		child = this.relatedProgramClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeRelatedProgramUpdateParentOverrideBySourceProgram() {

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(childType);
		Program parent1Created = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		Program parent2 = this.programFactory.create();
		parent2.setMerlinResourceType(childType);
		Program parent2Created = this.programClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		RelatedProgram child = this.relatedProgramFactory.create();
		child.setMerlinResourceType(childType);
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		child.setSourceProgramId(parent1.getId());
		child.setTargetProgramId(parent2.getId());
		RelatedProgram childCreated = this.relatedProgramClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType1);
		Program parent1Updated = this.programClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType1);

		parent2.setMerlinResourceType(parentType2);
		Program parent2Updated = this.programClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		RelatedProgram childUpdated = this.relatedProgramClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeRelatedProgramCreateParentOverrideByTargetProgram() {

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(parentType1);
		parent1 = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);

		Program parent2 = this.programFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.programClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		RelatedProgram child = this.relatedProgramFactory.create();
		child.setMerlinResourceType(childType);
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		child.setSourceProgramId(parent2.getId());
		child.setTargetProgramId(parent1.getId());
		child = this.relatedProgramClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeRelatedProgramUpdateParentOverrideByTargetProgram() {

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(childType);
		Program parent1Created = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		Program parent2 = this.programFactory.create();
		parent2.setMerlinResourceType(childType);
		Program parent2Created = this.programClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		RelatedProgram child = this.relatedProgramFactory.create();
		child.setMerlinResourceType(childType);
		child.setTargetProgramId(parent1.getId());
		child.setSourceProgramId(parent2.getId());
		RelatedProgram childCreated = this.relatedProgramClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		parent1.setMerlinResourceType(parentType1);
		Program parent1Updated = this.programClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType1);

		parent2.setMerlinResourceType(parentType2);
		Program parent2Updated = this.programClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		RelatedProgram childUpdated = this.relatedProgramClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeTagAssociationCreateParentOverrideByProgram() {

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(parentType1);
		parent1 = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);

		Tag parent2 = this.tagFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.tagClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		TagAssociation child = this.tagAssociationFactory.create();
		child.setMerlinResourceType(childType);
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		child.setEntityId(parent1.getId());
		child.setTagId(parent2.getId());
		child = this.tagAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeTagAssociationUpdateParentOverrideByProgram() {

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(childType);
		Program parent1Created = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		Tag parent2 = this.tagFactory.create();
		parent2.setMerlinResourceType(childType);
		Tag parent2Created = this.tagClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		TagAssociation child = this.tagAssociationFactory.create();
		child.setMerlinResourceType(childType);
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		child.setEntityId(parent1.getId());
		child.setTagId(parent2.getId());
		TagAssociation childCreated = this.tagAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType1);
		Program parent1Updated = this.programClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType1);

		parent2.setMerlinResourceType(parentType2);
		Tag parent2Updated = this.tagClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		TagAssociation childUpdated = this.tagAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeTagAssociationCreateParentOverrideByTag() {

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(parentType2);
		parent1 = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType2);

		Tag parent2 = this.tagFactory.create();
		parent2.setMerlinResourceType(parentType1);
		parent2 = this.tagClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType1);

		TagAssociation child = this.tagAssociationFactory.create();
		child.setMerlinResourceType(childType);
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		child.setTagId(parent2.getId());
		child.setEntityId(parent1.getId());
		child = this.tagAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeTagAssociationUpdateParentOverrideByTag() {

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(childType);
		Program parent1Created = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		Tag parent2 = this.tagFactory.create();
		parent2.setMerlinResourceType(childType);
		Tag parent2Created = this.tagClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		TagAssociation child = this.tagAssociationFactory.create();
		child.setMerlinResourceType(childType);
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		child.setTagId(parent2.getId());
		child.setEntityId(parent1.getId());
		TagAssociation childCreated = this.tagAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType2);
		Program parent1Updated = this.programClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType2);

		parent2.setMerlinResourceType(parentType1);
		Tag parent2Updated = this.tagClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType1);

		TagAssociation childUpdated = this.tagAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeProgramTeamAssociationCreateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(parentType1);
		parent1 = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);

		SportsTeam parent2 = this.sportsTeamFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.sportsTeamClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		ProgramTeamAssociation child = this.programTeamAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent1.getId());
		child.setSportsTeamId(parent2.getId());
		child = this.programTeamAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeProgramTeamAssociationUpdateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(childType);
		Program parent1Created = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		SportsTeam parent2 = this.sportsTeamFactory.create();
		parent2.setMerlinResourceType(childType);
		SportsTeam parent2Created = this.sportsTeamClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		ProgramTeamAssociation child = this.programTeamAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent1.getId());
		child.setSportsTeamId(parent2.getId());
		ProgramTeamAssociation childCreated = this.programTeamAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType1);
		Program parent1Updated = this.programClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType1);

		parent2.setMerlinResourceType(parentType2);
		SportsTeam parent2Updated = this.sportsTeamClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		ProgramTeamAssociation childUpdated = this.programTeamAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeProgramTeamAssociationCreateParentOverrideBySportsTeam() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(parentType2);
		parent1 = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType2);

		SportsTeam parent2 = this.sportsTeamFactory.create();
		parent2.setMerlinResourceType(parentType1);
		parent2 = this.sportsTeamClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType1);

		ProgramTeamAssociation child = this.programTeamAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent1.getId());
		child.setSportsTeamId(parent2.getId());
		child = this.programTeamAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeProgramTeamAssociationUpdateParentOverrideBySportsTeam() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(childType);
		Program parent1Created = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		SportsTeam parent2 = this.sportsTeamFactory.create();
		parent2.setMerlinResourceType(childType);
		SportsTeam parent2Created = this.sportsTeamClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		ProgramTeamAssociation child = this.programTeamAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent1.getId());
		child.setSportsTeamId(parent2.getId());
		ProgramTeamAssociation childCreated = this.programTeamAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType2);
		Program parent1Updated = this.programClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType2);

		parent2.setMerlinResourceType(parentType1);
		SportsTeam parent2Updated = this.sportsTeamClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType1);

		ProgramTeamAssociation childUpdated = this.programTeamAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	/****************************
	 * ProgramSportsEvent
	 ****************************/

	public void testMerlinResourceTypeProgramSportsEventCreateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(parentType1);
		parent1 = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);

		SportsEvent parent2 = this.sportsEventFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.sportsEventClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		ProgramSportsEvent child = this.programSportsEventFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent1.getId());
		child.setSportsEventId(parent2.getId());
		child = this.programSportsEventClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeProgramSportsEventUpdateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(childType);
		Program parent1Created = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		SportsEvent parent2 = this.sportsEventFactory.create();
		parent2.setMerlinResourceType(childType);
		SportsEvent parent2Created = this.sportsEventClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		ProgramSportsEvent child = this.programSportsEventFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent1.getId());
		child.setSportsEventId(parent2.getId());
		ProgramSportsEvent childCreated = this.programSportsEventClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType1);
		Program parent1Updated = this.programClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType1);

		parent2.setMerlinResourceType(parentType2);
		SportsEvent parent2Updated = this.sportsEventClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		ProgramSportsEvent childUpdated = this.programSportsEventClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeProgramSportsEventCreateParentOverrideBySportsEvent() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(parentType2);
		parent1 = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType2);

		SportsEvent parent2 = this.sportsEventFactory.create();
		parent2.setMerlinResourceType(parentType1);
		parent2 = this.sportsEventClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType1);

		ProgramSportsEvent child = this.programSportsEventFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent1.getId());
		child.setSportsEventId(parent2.getId());
		child = this.programSportsEventClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeProgramSportsEventUpdateParentOverrideBySportsEvent() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(childType);
		Program parent1Created = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		SportsEvent parent2 = this.sportsEventFactory.create();
		parent2.setMerlinResourceType(childType);
		SportsEvent parent2Created = this.sportsEventClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		ProgramSportsEvent child = this.programSportsEventFactory.create();
		child.setMerlinResourceType(childType);
		child.setProgramId(parent1.getId());
		child.setSportsEventId(parent2.getId());
		ProgramSportsEvent childCreated = this.programSportsEventClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType2);
		Program parent1Updated = this.programClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType2);

		parent2.setMerlinResourceType(parentType1);
		SportsEvent parent2Updated = this.sportsEventClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType1);

		ProgramSportsEvent childUpdated = this.programSportsEventClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	/****************************
	 * AwardAssociation
	 ****************************/

	public void testMerlinResourceTypeAwardAssociationCreateParentOverrideByAward() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Award parent1 = this.awardFactory.create();
		parent1.setMerlinResourceType(parentType1);
		parent1 = this.awardClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);

		Institution parent2 = this.institutionFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.institutionClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		Program parent3 = this.programFactory.create();
		parent3.setMerlinResourceType(parentType2);
		parent3 = this.programClient.create(parent3, new String[] {});
		Assert.assertEquals(parent3.getMerlinResourceType(), parentType2);

		Person parent4 = this.personFactory.create();
		parent4.setMerlinResourceType(parentType2);
		parent4 = this.personClient.create(parent4, new String[] {});
		Assert.assertEquals(parent4.getMerlinResourceType(), parentType2);

		AwardAssociation child = this.awardAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setAwardId(parent1.getId());
		child.setInstitutionId(parent2.getId());
		child.setProgramId(parent3.getId());
		child.setPersonId(parent4.getId());
		child = this.awardAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeAwardAssociationUpdateParentOverrideByAward() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Award parent1 = this.awardFactory.create();
		parent1.setMerlinResourceType(childType);
		Award parent1Created = this.awardClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		Institution parent2 = this.institutionFactory.create();
		parent2.setMerlinResourceType(childType);
		Institution parent2Created = this.institutionClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		Program parent3 = this.programFactory.create();
		parent3.setMerlinResourceType(childType);
		Program parent3Created = this.programClient.create(parent3, new String[] {});
		Assert.assertEquals(parent3Created.getMerlinResourceType(), childType);

		Person parent4 = this.personFactory.create();
		parent4.setMerlinResourceType(childType);
		Person parent4Created = this.personClient.create(parent4, new String[] {});
		Assert.assertEquals(parent4Created.getMerlinResourceType(), childType);

		AwardAssociation child = this.awardAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setAwardId(parent1.getId());
		child.setInstitutionId(parent2.getId());
		child.setProgramId(parent3.getId());
		child.setPersonId(parent4.getId());
		AwardAssociation childCreated = this.awardAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType1);
		Award parent1Updated = this.awardClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType1);

		parent2.setMerlinResourceType(parentType2);
		Institution parent2Updated = this.institutionClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		parent3.setMerlinResourceType(parentType2);
		Program parent3Updated = this.programClient.update(parent3, new String[] {});
		Assert.assertEquals(parent3Updated.getMerlinResourceType(), parentType2);

		parent4.setMerlinResourceType(parentType2);
		Person parent4Updated = this.personClient.update(parent4, new String[] {});
		Assert.assertEquals(parent4Updated.getMerlinResourceType(), parentType2);

		AwardAssociation childUpdated = this.awardAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeAwardAssociationCreateParentOverrideByInstitution() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Award parent1 = this.awardFactory.create();
		parent1.setMerlinResourceType(parentType2);
		parent1 = this.awardClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType2);

		Institution parent2 = this.institutionFactory.create();
		parent2.setMerlinResourceType(parentType1);
		parent2 = this.institutionClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType1);

		Program parent3 = this.programFactory.create();
		parent3.setMerlinResourceType(parentType2);
		parent3 = this.programClient.create(parent3, new String[] {});
		Assert.assertEquals(parent3.getMerlinResourceType(), parentType2);

		Person parent4 = this.personFactory.create();
		parent4.setMerlinResourceType(parentType2);
		parent4 = this.personClient.create(parent4, new String[] {});
		Assert.assertEquals(parent4.getMerlinResourceType(), parentType2);

		AwardAssociation child = this.awardAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setAwardId(parent1.getId());
		child.setInstitutionId(parent2.getId());
		child.setProgramId(parent3.getId());
		child.setPersonId(parent4.getId());
		child = this.awardAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeAwardAssociationUpdateParentOverrideByInstitution() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Award parent1 = this.awardFactory.create();
		parent1.setMerlinResourceType(childType);
		Award parent1Created = this.awardClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		Institution parent2 = this.institutionFactory.create();
		parent2.setMerlinResourceType(childType);
		Institution parent2Created = this.institutionClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		Program parent3 = this.programFactory.create();
		parent3.setMerlinResourceType(childType);
		Program parent3Created = this.programClient.create(parent3, new String[] {});
		Assert.assertEquals(parent3Created.getMerlinResourceType(), childType);

		Person parent4 = this.personFactory.create();
		parent4.setMerlinResourceType(childType);
		Person parent4Created = this.personClient.create(parent4, new String[] {});
		Assert.assertEquals(parent4Created.getMerlinResourceType(), childType);

		AwardAssociation child = this.awardAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setAwardId(parent1.getId());
		child.setInstitutionId(parent2.getId());
		child.setProgramId(parent3.getId());
		child.setPersonId(parent4.getId());
		AwardAssociation childCreated = this.awardAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType2);
		Award parent1Updated = this.awardClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType2);

		parent2.setMerlinResourceType(parentType1);
		Institution parent2Updated = this.institutionClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType1);

		parent3.setMerlinResourceType(parentType2);
		Program parent3Updated = this.programClient.update(parent3, new String[] {});
		Assert.assertEquals(parent3Updated.getMerlinResourceType(), parentType2);

		parent4.setMerlinResourceType(parentType2);
		Person parent4Updated = this.personClient.update(parent4, new String[] {});
		Assert.assertEquals(parent4Updated.getMerlinResourceType(), parentType2);

		AwardAssociation childUpdated = this.awardAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeAwardAssociationCreateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Award parent1 = this.awardFactory.create();
		parent1.setMerlinResourceType(parentType2);
		parent1 = this.awardClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType2);

		Institution parent2 = this.institutionFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.institutionClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		Program parent3 = this.programFactory.create();
		parent3.setMerlinResourceType(parentType1);
		parent3 = this.programClient.create(parent3, new String[] {});
		Assert.assertEquals(parent3.getMerlinResourceType(), parentType1);

		Person parent4 = this.personFactory.create();
		parent4.setMerlinResourceType(parentType2);
		parent4 = this.personClient.create(parent4, new String[] {});
		Assert.assertEquals(parent4.getMerlinResourceType(), parentType2);

		AwardAssociation child = this.awardAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setAwardId(parent1.getId());
		child.setInstitutionId(parent2.getId());
		child.setProgramId(parent3.getId());
		child.setPersonId(parent4.getId());
		child = this.awardAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeAwardAssociationUpdateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Award parent1 = this.awardFactory.create();
		parent1.setMerlinResourceType(childType);
		Award parent1Created = this.awardClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		Institution parent2 = this.institutionFactory.create();
		parent2.setMerlinResourceType(childType);
		Institution parent2Created = this.institutionClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		Program parent3 = this.programFactory.create();
		parent3.setMerlinResourceType(childType);
		Program parent3Created = this.programClient.create(parent3, new String[] {});
		Assert.assertEquals(parent3Created.getMerlinResourceType(), childType);

		Person parent4 = this.personFactory.create();
		parent4.setMerlinResourceType(childType);
		Person parent4Created = this.personClient.create(parent4, new String[] {});
		Assert.assertEquals(parent4Created.getMerlinResourceType(), childType);

		AwardAssociation child = this.awardAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setAwardId(parent1.getId());
		child.setInstitutionId(parent2.getId());
		child.setProgramId(parent3.getId());
		child.setPersonId(parent4.getId());
		AwardAssociation childCreated = this.awardAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType2);
		Award parent1Updated = this.awardClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType2);

		parent2.setMerlinResourceType(parentType2);
		Institution parent2Updated = this.institutionClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		parent3.setMerlinResourceType(parentType1);
		Program parent3Updated = this.programClient.update(parent3, new String[] {});
		Assert.assertEquals(parent3Updated.getMerlinResourceType(), parentType1);

		parent4.setMerlinResourceType(parentType2);
		Person parent4Updated = this.personClient.update(parent4, new String[] {});
		Assert.assertEquals(parent4Updated.getMerlinResourceType(), parentType2);

		AwardAssociation childUpdated = this.awardAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeAwardAssociationCreateParentOverrideByPerson() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Award parent1 = this.awardFactory.create();
		parent1.setMerlinResourceType(parentType2);
		parent1 = this.awardClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType2);

		Institution parent2 = this.institutionFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.institutionClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		Program parent3 = this.programFactory.create();
		parent3.setMerlinResourceType(parentType2);
		parent3 = this.programClient.create(parent3, new String[] {});
		Assert.assertEquals(parent3.getMerlinResourceType(), parentType2);

		Person parent4 = this.personFactory.create();
		parent4.setMerlinResourceType(parentType1);
		parent4 = this.personClient.create(parent4, new String[] {});
		Assert.assertEquals(parent4.getMerlinResourceType(), parentType1);

		AwardAssociation child = this.awardAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setAwardId(parent1.getId());
		child.setInstitutionId(parent2.getId());
		child.setProgramId(parent3.getId());
		child.setPersonId(parent4.getId());
		child = this.awardAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeAwardAssociationUpdateParentOverrideByPerson() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));
		Award parent1 = this.awardFactory.create();
		parent1.setMerlinResourceType(childType);
		Award parent1Created = this.awardClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		Institution parent2 = this.institutionFactory.create();
		parent2.setMerlinResourceType(childType);
		Institution parent2Created = this.institutionClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		Program parent3 = this.programFactory.create();
		parent3.setMerlinResourceType(childType);
		Program parent3Created = this.programClient.create(parent3, new String[] {});
		Assert.assertEquals(parent3Created.getMerlinResourceType(), childType);

		Person parent4 = this.personFactory.create();
		parent4.setMerlinResourceType(childType);
		Person parent4Created = this.personClient.create(parent4, new String[] {});
		Assert.assertEquals(parent4Created.getMerlinResourceType(), childType);

		AwardAssociation child = this.awardAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setAwardId(parent1.getId());
		child.setInstitutionId(parent2.getId());
		child.setProgramId(parent3.getId());
		child.setPersonId(parent4.getId());
		AwardAssociation childCreated = this.awardAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType2);
		Award parent1Updated = this.awardClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType2);

		parent2.setMerlinResourceType(parentType2);
		Institution parent2Updated = this.institutionClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		parent3.setMerlinResourceType(parentType2);
		Program parent3Updated = this.programClient.update(parent3, new String[] {});
		Assert.assertEquals(parent3Updated.getMerlinResourceType(), parentType2);

		parent4.setMerlinResourceType(parentType1);
		Person parent4Updated = this.personClient.update(parent4, new String[] {});
		Assert.assertEquals(parent4Updated.getMerlinResourceType(), parentType1);

		AwardAssociation childUpdated = this.awardAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	/***************************************
	 * ImageAssociation
	 ***************************************/
	public void testMerlinResourceTypeImageAssociationCreateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Program parent = this.programFactory.create();
		parent.setMerlinResourceType(parentType1);
		parent = this.programClient.create(parent, new String[] {});
		Assert.assertEquals(parent.getMerlinResourceType(), parentType1);

		ImageAssociation child = this.imageAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent.getId());
		child = this.imageAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, childType));
	}

	public void testMerlinResourceTypeImageAssociationUpdateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Program parent = this.programFactory.create();
		parent.setMerlinResourceType(childType);
		Program parentCreated = this.programClient.create(parent, new String[] {});
		Assert.assertEquals(parentCreated.getMerlinResourceType(), childType);

		ImageAssociation child = this.imageAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent.getId());
		ImageAssociation childCreated = this.imageAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent.setMerlinResourceType(parentType1);
		Program parentUpdated = this.programClient.update(parent, new String[] {});
		Assert.assertEquals(parentUpdated.getMerlinResourceType(), parentType1);

		ImageAssociation childUpdated = this.imageAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, childType));
	}

	public void testMerlinResourceTypeImageAssociationCreateParentOverrideByPerson() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Person parent = this.personFactory.create();
		parent.setMerlinResourceType(parentType1);
		parent = this.personClient.create(parent, new String[] {});
		Assert.assertEquals(parent.getMerlinResourceType(), parentType1);

		ImageAssociation child = this.imageAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent.getId());
		child = this.imageAssociationClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, childType));
	}

	public void testMerlinResourceTypeImageAssociationUpdateParentOverrideByPerson() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Person parent = this.personFactory.create();
		parent.setMerlinResourceType(childType);
		Person parentCreated = this.personClient.create(parent, new String[] {});
		Assert.assertEquals(parentCreated.getMerlinResourceType(), childType);

		ImageAssociation child = this.imageAssociationFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent.getId());
		ImageAssociation childCreated = this.imageAssociationClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent.setMerlinResourceType(parentType1);
		Person parentUpdated = this.personClient.update(parent, new String[] {});
		Assert.assertEquals(parentUpdated.getMerlinResourceType(), parentType1);

		ImageAssociation childUpdated = this.imageAssociationClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, childType));
	}

	/**********************************************************
	 * MainImageFile
	 **********************************************************/

	public void testMerlinResourceTypeMainImageFileCreateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(parentType1);
		parent1 = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);

		MainImageType parent2 = this.mainImageTypeFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.mainImageTypeClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		MainImageFile child = this.mainImageFileFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent1.getId());
		child.setMainImageTypeId(parent2.getId());
		child = this.mainImageFileClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeMainImageFileUpdateParentOverrideByProgram() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Program parent1 = this.programFactory.create();
		parent1.setMerlinResourceType(childType);
		Program parent1Created = this.programClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		MainImageType parent2 = this.mainImageTypeFactory.create();
		parent2.setMerlinResourceType(childType);
		MainImageType parent2Created = this.mainImageTypeClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		MainImageFile child = this.mainImageFileFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent1.getId());
		child.setMainImageTypeId(parent2.getId());
		MainImageFile childCreated = this.mainImageFileClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType1);
		Program parent1Updated = this.programClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType1);

		parent2.setMerlinResourceType(parentType2);
		MainImageType parent2Updated = this.mainImageTypeClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		MainImageFile childUpdated = this.mainImageFileClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeMainImageFileCreateParentOverrideByPerson() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Person parent1 = this.personFactory.create();
		parent1.setMerlinResourceType(parentType1);
		parent1 = this.personClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);

		MainImageType parent2 = this.mainImageTypeFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.mainImageTypeClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		MainImageFile child = this.mainImageFileFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent1.getId());
		child.setMainImageTypeId(parent2.getId());
		child = this.mainImageFileClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeMainImageFileUpdateParentOverrideByPerson() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		Person parent1 = this.personFactory.create();
		parent1.setMerlinResourceType(childType);
		Person parent1Created = this.personClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		MainImageType parent2 = this.mainImageTypeFactory.create();
		parent2.setMerlinResourceType(childType);
		MainImageType parent2Created = this.mainImageTypeClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		MainImageFile child = this.mainImageFileFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent1.getId());
		child.setMainImageTypeId(parent2.getId());
		MainImageFile childCreated = this.mainImageFileClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType1);
		Person parent1Updated = this.personClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType1);

		parent2.setMerlinResourceType(parentType2);
		MainImageType parent2Updated = this.mainImageTypeClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		MainImageFile childUpdated = this.mainImageFileClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	public void testMerlinResourceTypeMainImageFileCreateParentOverrideBySportsTeam() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		SportsTeam parent1 = this.sportsTeamFactory.create();
		parent1.setMerlinResourceType(parentType1);
		parent1 = this.sportsTeamClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);

		MainImageType parent2 = this.mainImageTypeFactory.create();
		parent2.setMerlinResourceType(parentType2);
		parent2 = this.mainImageTypeClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		MainImageFile child = this.mainImageFileFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent1.getId());
		child.setMainImageTypeId(parent2.getId());
		child = this.mainImageFileClient.create(child, new String[] {});

		Assert.assertEquals(child.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));

	}

	public void testMerlinResourceTypeMainImageFileUpdateParentOverrideBySportsTeam() {
		Assert.assertTrue(typeMap.get(parentType1) >= typeMap.get(parentType2));

		SportsTeam parent1 = this.sportsTeamFactory.create();
		parent1.setMerlinResourceType(childType);
		SportsTeam parent1Created = this.sportsTeamClient.create(parent1, new String[] {});
		Assert.assertEquals(parent1Created.getMerlinResourceType(), childType);

		MainImageType parent2 = this.mainImageTypeFactory.create();
		parent2.setMerlinResourceType(childType);
		MainImageType parent2Created = this.mainImageTypeClient.create(parent2, new String[] {});
		Assert.assertEquals(parent2Created.getMerlinResourceType(), childType);

		MainImageFile child = this.mainImageFileFactory.create();
		child.setMerlinResourceType(childType);
		child.setEntityId(parent1.getId());
		child.setMainImageTypeId(parent2.getId());
		MainImageFile childCreated = this.mainImageFileClient.create(child, new String[] {});
		Assert.assertEquals(childCreated.getMerlinResourceType(), childType);

		parent1.setMerlinResourceType(parentType1);
		SportsTeam parent1Updated = this.sportsTeamClient.update(parent1, new String[] {});
		Assert.assertEquals(parent1Updated.getMerlinResourceType(), parentType1);

		parent2.setMerlinResourceType(parentType2);
		MainImageType parent2Updated = this.mainImageTypeClient.update(parent2, new String[] {});
		Assert.assertEquals(parent2Updated.getMerlinResourceType(), parentType2);

		MainImageFile childUpdated = this.mainImageFileClient.get(childCreated.getId(), new String[] {});
		Assert.assertEquals(childUpdated.getMerlinResourceType(), this.getExpectedType(parentType1, parentType2, childType));
	}

	private MerlinResourceType getExpectedType(MerlinResourceType... types) {
		MerlinResourceType expected = MerlinResourceType.AudienceAvailable;
		for (MerlinResourceType type : types) {
			if (typeMap.get(type) > typeMap.get(expected))
				expected = type;
		}
		return expected;
	}

}
