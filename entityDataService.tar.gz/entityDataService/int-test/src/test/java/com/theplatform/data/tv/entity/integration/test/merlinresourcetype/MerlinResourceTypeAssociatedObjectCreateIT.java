package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import java.lang.reflect.InvocationTargetException;

import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.TagField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;

@Test(groups = { "merlinResourceType" })
public class MerlinResourceTypeAssociatedObjectCreateIT extends EntityTestBase {	
	//Associated endpoint with 2 parents
	
	@Test(groups = { "disabled" })//TODO to be implemented
	public void testMerlinResourceTypeTagAssociationCreateWithNullType() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		Program program = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.Temporary)), new String[] {});

		Tag tag = this.tagClient.create(tagFactory.create(new DataServiceField(TagField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {});
		
		TagAssociation tagAssociation = this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.merlinResourceType, null),
				new DataServiceField(TagAssociationField.entityId, program.getId()), new DataServiceField(TagAssociationField.tagId, tag.getId())), new String[] {});

		Assert.assertEquals(tagAssociation.getMerlinResourceType(), MerlinResourceType.Temporary);

		tagAssociation.setMerlinResourceType(MerlinResourceType.Inactive);

		tagAssociationClient.update(tagAssociation);

		Assert.assertEquals(tagAssociationClient.get(tagAssociation.getId(), new String[] {}).getMerlinResourceType(), tagAssociation.getMerlinResourceType());

		
		Program programToUpdate = new Program();
		programToUpdate.setId(program.getId());
		programToUpdate.setType(program.getType());
		programToUpdate.setVersion(null);
		programToUpdate.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		programClient.update(programToUpdate);

		Assert.assertEquals(tagAssociationClient.get(tagAssociation.getId(), new String[] {}).getMerlinResourceType(), tagAssociation.getMerlinResourceType());

		tagAssociation.setNull(TagAssociationField.merlinResourceType);
		tagAssociation.setMerlinResourceType(null);

		tagAssociation.setVersion(null);
		tagAssociation.setUpdated(null);
		tagAssociationClient.update(tagAssociation);

		Assert.assertEquals(tagAssociationClient.get(tagAssociation.getId(), new String[] {}).getMerlinResourceType(), programToUpdate.getMerlinResourceType());

	}

}
