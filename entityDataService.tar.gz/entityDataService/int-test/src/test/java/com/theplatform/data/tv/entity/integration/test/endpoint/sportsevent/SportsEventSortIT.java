package com.theplatform.data.tv.entity.integration.test.endpoint.sportsevent;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */
@Test(groups={"sportsEvent", "sort", "other"})
public class SportsEventSortIT extends EntityTestBase {
	private static final int SPORTS_EVENT_TO_CREATE = 4;
	private List<SportsEvent> sportsEvents;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		sportsEvents = this.sportsEventFactory.create(SPORTS_EVENT_TO_CREATE);
		this.sportsEventClient.create(sportsEvents);

	}
	

	@Test
	public void testSortBySortFields() throws UnknownHostException {
		List<Sort> supportedSorts = new ArrayList<>();
		boolean sortDescending = false;
		supportedSorts.add(new Sort("title", sortDescending));
		// supportedSorts.add(new Sort("programIds", sortDescending));
		supportedSorts.add(new Sort("leagueId", sortDescending));
		supportedSorts.add(new Sort("country", sortDescending));
		supportedSorts.add(new Sort("division", sortDescending));
		supportedSorts.add(new Sort("venue", sortDescending));
		for (int i = 0; i < 5; i++) {
			Feed<SportsEvent> sortedSportsEvent = this.sportsEventClient.getOwned(new String[] {}, new Query[] {},
					new Sort[] { supportedSorts.get(i) }, null, false);
			// TODO: verify equality
			// comparator.assertSportsEventsEqual(sortedSportsEvent ,
			// sportsEvents);
		}
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableField() throws UnknownHostException {
		List<Sort> unsupportedSorts = new ArrayList<>();
		boolean sortDescending = false;
		unsupportedSorts.add(new Sort("city", sortDescending));
		unsupportedSorts.add(new Sort("state", sortDescending));
		unsupportedSorts.add(new Sort("sportType", sortDescending));
		unsupportedSorts.add(new Sort("conference", sortDescending));
		unsupportedSorts.add(new Sort("imageIds", sortDescending));
		unsupportedSorts.add(new Sort("mainImages", sortDescending));
		for (int i = 0; i < 6; i++) {
			this.sportsEventClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { unsupportedSorts.get(i) },
					null, false);
		}
	}
}
