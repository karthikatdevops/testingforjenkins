package com.theplatform.data.tv.entity.integration.test;

import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.comparator.DataComparator;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.contrib.testing.provider.GBTestIdProvider;
import com.theplatform.contrib.testing.test.AuthProxyTestBase;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.tv.entity.api.client.*;
import com.theplatform.data.tv.entity.api.data.objects.Album;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.test.EntityMessageComparator;
import com.theplatform.data.tv.entity.api.test.PersonAssociationFactory;
import com.theplatform.data.tv.entity.api.test.ProgramAssociationFactory;
import com.theplatform.data.tv.entity.test.api.data.factory.*;
import com.theplatform.data.tv.image.api.client.ImageAssociationClient;
import com.theplatform.data.tv.image.api.client.MainImageFileClient;
import com.theplatform.data.tv.image.api.client.MainImageTypeClient;
import com.theplatform.data.tv.image.api.client.MainImageTypeGroupClient;
import com.theplatform.data.tv.image.api.test.ImageCriteriaFactory;
import com.theplatform.data.tv.social.api.client.SocialMediaAssociationClient;
import com.theplatform.data.tv.tag.api.client.TagAssociationClient;
import com.theplatform.media.api.data.objects.Media;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;

import javax.annotation.Resource;
import java.util.Random;

@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class EntityTestBase extends AuthProxyTestBase {

    @Resource
    protected GBTestIdProvider objectIdProvider;

    @Autowired
    @Qualifier("baseEntityUrl")
    protected String baseUrl;

    @Autowired
    @Qualifier("baseLinearUrl")
    private String linearBaseUrl;

    @Resource
    private String mediaBaseUrl;

    @Autowired
    @Qualifier("idBaseUrl")
    private String idBaseUrl;

    @Autowired
    protected SocialMediaAssociationClient socialMediaAssociationClient;

    @Resource
    protected EntityMessageClient entityMessageClient;

    @Resource
    protected EntityMessageFactory entityMessageFactory;

    @Resource
    protected VideogameClient videogameClient;

    @Resource
    protected VideogameFactory videogameFactory;

    @Autowired
    protected AwardClient awardClient;
    @Autowired
    protected ProgramClient programClient;
    @Autowired
    protected PersonClient personClient;
    @Autowired
    protected InstitutionClient institutionClient;
    @Autowired
    protected AwardAssociationClient awardAssociationClient;
    @Autowired
    protected CreditClient creditClient;
    @Autowired
    protected ImageAssociationClient imageAssociationClient;
    @Autowired
    protected MainImageTypeClient mainImageTypeClient;
    @Autowired
    protected MainImageTypeGroupClient mainImageTypeGroupClient;
    @Autowired
    protected MainImageFileClient mainImageFileClient;
    @Autowired
    protected TvSeasonClient tvSeasonClient;
    @Autowired
    protected TagClient tagClient;
    @Autowired
    protected TagAssociationClient tagAssociationClient;
    @Autowired
    protected SportsEventClient sportsEventClient;
    @Autowired
    protected ProgramSportsEventClient programSportsEventClient;
    @Autowired
    protected ProgramRankClient programRankClient;
    @Autowired
    protected SportsTeamClient sportsTeamClient;
    @Autowired
    protected RelatedProgramClient relatedProgramClient;
    @Autowired
    protected EntityCollectionClient entityCollectionClient;
    @Autowired
    protected ProgramTeamAssociationClient programTeamAssociationClient;
    @Autowired
    protected PersonTeamAssociationClient personTeamAssociationClient;
    @Autowired
    protected SportsLeagueClient sportsLeagueClient;
    @Autowired
    protected ReviewClient reviewClient;
    @Autowired
    protected AlbumClient albumClient;
    @Autowired
    protected AlbumCreditClient albumCreditClient;
    @Autowired
    protected AlbumReleaseClient albumReleaseClient;
    @Autowired
    protected SongClient songClient;
    @Autowired
    protected SongCreditClient songCreditClient;
    @Autowired
    protected RelatedPersonClient relatedPersonClient;
    @Autowired
    protected RelatedAlbumClient relatedAlbumClient;
    @Autowired
    protected RelatedSongClient relatedSongClient;
    @Autowired
    protected AlbumReleaseSongAssociationClient albumReleaseSongAssociationClient;
    @Autowired
    protected ProgramSongAssociationClient programSongAssociationClient;
    @Autowired
    protected SongCollectionClient songCollectionClient;
    @Autowired
    protected ProgramMediaAssociationClient programMediaAssociationClient;

    // factories

    @Autowired
    protected AlbumFactory albumFactory;
    @Autowired
    protected AlbumCreditFactory albumCreditFactory;
    @Autowired
    protected AlbumReleaseFactory albumReleaseFactory;
    @Autowired
    protected AlbumReleaseSongAssociationFactory albumReleaseSongAssociationFactory;
    @Autowired
    protected AwardFactory awardFactory;
    @Autowired
    protected AwardAssociationFactory awardAssociationFactory;
    @Autowired
    protected CreditFactory creditFactory;
    @Autowired
    protected EntityCollectionFactory entityCollectionFactory;
    @Autowired
    protected InstitutionFactory institutionFactory;
    @Autowired
    protected ImageAssociationFactory<Program, ProgramClient, Media, DataServiceClient<Media>> imageAssociationFactory;
    @Autowired
    protected MainImageFileFactory mainImageFileFactory;
    @Autowired
    protected MainImageTypeFactory mainImageTypeFactory;
    @Autowired
    protected MainImageTypeGroupFactory mainImageTypeGroupFactory;
    @Autowired
    protected PersonAssociationFactory personAssociationFactory;
    @Autowired
    protected ProgramAssociationFactory programAssociationFactory;
    @Autowired
    protected ProgramSongAssociationFactory programSongAssociationFactory;
    @Autowired
    protected ProgramRankFactory programRankFactory;
    @Autowired
    protected ProgramMediaAssociationFactory programMediaAssociationFactory;
    @Autowired
    protected PersonFactory personFactory;
    @Autowired
    protected ProgramFactory programFactory;
    @Autowired
    protected SeriesMasterProgramFactory seriesMasterProgramFactory;
    @Autowired
    protected EpisodeProgramFactory episodeProgramFactory;
    @Autowired
    protected MovieProgramFactory movieProgramFactory;
    @Autowired
    protected ProgramSportsEventFactory programSportsEventFactory;
    @Autowired
    protected ProgramTeamAssociationFactory programTeamAssociationFactory;
    @Autowired
    protected PersonTeamAssociationFactory personTeamAssociationFactory;
    @Autowired
    protected RelatedProgramFactory relatedProgramFactory;
    @Autowired
    protected ReviewFactory reviewFactory;
    @Autowired
    protected RelatedPersonFactory relatedPersonFactory;
    @Autowired
    protected RelatedAlbumFactory relatedAlbumFactory;
    @Autowired
    protected RelatedSongFactory relatedSongFactory;
    @Autowired
    @Qualifier("smaFactory")
    protected SocialMediaAssociationFactory socialMediaAssociationFactory;
    @Autowired
    protected SongFactory songFactory;
    @Autowired
    protected SongCollectionFactory songCollectionFactory;
    @Autowired
    protected SongCreditFactory songCreditFactory;
    @Autowired
    protected SportsEventFactory sportsEventFactory;
    @Autowired
    protected SportsLeagueFactory sportsLeagueFactory;
    @Autowired
    @Qualifier("guidoSportsTeamFactory")
    protected SportsTeamFactory sportsTeamFactory;
    @Autowired
    @Qualifier("guidoTagFactory")
    protected TagFactory tagFactory;
    @Autowired
    @Qualifier("guidoTagAssociationFactory")
    protected TagAssociationFactory tagAssociationFactory;
    @Autowired
    @Qualifier("guidoTagAssociationFactory")
    protected TagAssociationFactory sportsTeamTagAssociationFactory;
    @Autowired
    protected TvSeasonFactory tvSeasonFactory;
    @Autowired
    protected RatingsMappingFactory ratingsMappingFactory;
    @Autowired
    protected RatingsMappingClient ratingsMappingClient;

    @Autowired
    protected DataComparator<Album> albumComparator;
    @Autowired
    protected DataComparator<Song> songComparator;
    @Autowired
    protected DataComparator<ProgramRank> programRankComparator;

    @Resource
    protected ValueProvider<Long> dataObjectIdProvider;

    @Resource
    protected DataObjectFactory<Program, ProgramClient> persistingProgramFactory;
    @Resource
    protected DataObjectFactory<Person, PersonClient> persistingPersonFactory;
    @Resource
    protected DataObjectFactory<ProgramMediaAssociation, ProgramMediaAssociationClient> persistingProgramMediaAssociationFactory;

    @Autowired
    protected ImageCriteriaFactory imageCriteriaFactory;

    public AlbumCreditFactory getAlbumCreditFactory() {
        return albumCreditFactory;
    }

    public void setAlbumCreditFactory(AlbumCreditFactory albumCreditFactory) {
        this.albumCreditFactory = albumCreditFactory;
    }


    protected Random random = new Random();

    public MediaId createMediaId() {
        MediaId mediaId = new MediaId();
        mediaId.setAccountGuid("fake accountGuid");
        mediaId.setServiceGuid("fake serviceGuid");

        mediaId.setMediaGuid("fake mediaGuid " + random.nextInt());
        return mediaId;
    }

    public AwardClient getAwardClient() {
        return awardClient;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public PersonClient getPersonClient() {
        return personClient;
    }

    public InstitutionClient getInstitutionClient() {
        return institutionClient;
    }

    public AwardAssociationClient getAwardAssociationClient() {
        return awardAssociationClient;
    }

    public CreditClient getCreditClient() {
        return creditClient;
    }

    public ImageAssociationClient getImageAssociationClient() {
        return imageAssociationClient;
    }

    public MainImageTypeClient getMainImageTypeClient() {
        return mainImageTypeClient;
    }

    public MainImageFileClient getMainImageFileClient() {
        return mainImageFileClient;
    }

    public TvSeasonClient getTvSeasonClient() {
        return tvSeasonClient;
    }

    public TagClient getTagClient() {
        return tagClient;
    }

    public TagAssociationClient getTagAssociationClient() {
        return tagAssociationClient;
    }

    public SportsEventClient getSportsEventClient() {
        return sportsEventClient;
    }

    public EntityCollectionClient getEntityCollectionClient() {
        return entityCollectionClient;
    }

    public ProgramSportsEventClient getProgramSportsEventClient() {
        return programSportsEventClient;
    }

    public SportsTeamClient getSportsTeamClient() {
        return sportsTeamClient;
    }

    public RelatedProgramClient getRelatedProgramClient() {
        return relatedProgramClient;
    }

    public ProgramTeamAssociationClient getProgramTeamAssociationClient() {
        return programTeamAssociationClient;
    }

    public SportsLeagueClient getSportsLeagueClient() {
        return sportsLeagueClient;
    }

    public AwardAssociationFactory getAwardAssociationFactory() {
        return awardAssociationFactory;
    }

    @Deprecated
    public ImageAssociationFactory getImageAssociationFactory() {
        return imageAssociationFactory;
    }

    public MainImageFileFactory getMainImageFileFactory() {
        return mainImageFileFactory;
    }

    public TagAssociationFactory getTagAssociationFactory() {
        return tagAssociationFactory;
    }

    public ProgramSportsEventFactory getProgramSportsEventFactory() {
        return programSportsEventFactory;
    }

    public ProgramTeamAssociationFactory getProgramTeamAssociationFactory() {
        return programTeamAssociationFactory;
    }

    public RelatedProgramFactory getRelatedProgramFactory() {
        return relatedProgramFactory;
    }

    public EntityCollectionFactory getEntityCollectionFactory() {
        return entityCollectionFactory;
    }

    public TvSeasonFactory getTvSeasonFactory() {
        return tvSeasonFactory;
    }

    public void setAwardClient(AwardClient awardClient) {
        this.awardClient = awardClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }

    public void setPersonClient(PersonClient personClient) {
        this.personClient = personClient;
    }

    public void setInstitutionClient(InstitutionClient institutionClient) {
        this.institutionClient = institutionClient;
    }

    public void setAwardAssociationClient(AwardAssociationClient awardAssociationClient) {
        this.awardAssociationClient = awardAssociationClient;
    }

    public void setCreditClient(CreditClient creditClient) {
        this.creditClient = creditClient;
    }

    public void setImageAssociationClient(ImageAssociationClient imageAssociationClient) {
        this.imageAssociationClient = imageAssociationClient;
    }

    public void setMainImageTypeClient(MainImageTypeClient mainImageTypeClient) {
        this.mainImageTypeClient = mainImageTypeClient;
    }

    public void setMainImageFileClient(MainImageFileClient mainImageFileClient) {
        this.mainImageFileClient = mainImageFileClient;
    }

    public void setTvSeasonClient(TvSeasonClient tvSeasonClient) {
        this.tvSeasonClient = tvSeasonClient;
    }

    public void setTagClient(TagClient tagClient) {
        this.tagClient = tagClient;
    }

    public void setTagAssociationClient(TagAssociationClient tagAssociationClient) {
        this.tagAssociationClient = tagAssociationClient;
    }

    public void setSportsEventClient(SportsEventClient sportsEventClient) {
        this.sportsEventClient = sportsEventClient;
    }

    public void setProgramSportsEventClient(ProgramSportsEventClient programSportsEventClient) {
        this.programSportsEventClient = programSportsEventClient;
    }

    public void setSportsTeamClient(SportsTeamClient sportsTeamClient) {
        this.sportsTeamClient = sportsTeamClient;
    }

    public void setRelatedProgramClient(RelatedProgramClient relatedProgramClient) {
        this.relatedProgramClient = relatedProgramClient;
    }

    public void setEntityCollectionClient(EntityCollectionClient entityCollectionClient) {
        this.entityCollectionClient = entityCollectionClient;
    }

    public void setProgramTeamAssociationClient(ProgramTeamAssociationClient programTeamAssociationClient) {
        this.programTeamAssociationClient = programTeamAssociationClient;
    }

    public void setSportsLeagueClient(SportsLeagueClient sportsLeagueClient) {
        this.sportsLeagueClient = sportsLeagueClient;
    }

    public void setAwardAssociationFactory(AwardAssociationFactory awardAssociationFactory) {
        this.awardAssociationFactory = awardAssociationFactory;
    }

    public void setImageAssociationFactory(ImageAssociationFactory imageAssociationFactory) {
        this.imageAssociationFactory = imageAssociationFactory;
    }

    @Deprecated
    public void setMainImageFileFactory(MainImageFileFactory mainImageFileFactory) {
        this.mainImageFileFactory = mainImageFileFactory;
    }

    public void setTagAssociationFactory(TagAssociationFactory tagAssociationFactory) {
        this.tagAssociationFactory = tagAssociationFactory;
    }

    public void setProgramSportsEventFactory(ProgramSportsEventFactory programSportsEventFactory) {
        this.programSportsEventFactory = programSportsEventFactory;
    }

    public void setProgramTeamAssociationFactory(ProgramTeamAssociationFactory programTeamAssociationFactory) {
        this.programTeamAssociationFactory = programTeamAssociationFactory;
    }

    public void setRelatedProgramFactory(RelatedProgramFactory relatedProgramFactory) {
        this.relatedProgramFactory = relatedProgramFactory;
    }

    public void setEntityCollectionFactory(EntityCollectionFactory entityCollectionFactory) {
        this.entityCollectionFactory = entityCollectionFactory;
    }

    public void setTvSeasonFactory(TvSeasonFactory tvSeasonFactory) {
        this.tvSeasonFactory = tvSeasonFactory;
    }

    public AwardFactory getAwardFactory() {
        return awardFactory;
    }

    public void setAwardFactory(AwardFactory awardFactory) {
        this.awardFactory = awardFactory;
    }

    public SportsEventFactory getSportsEventFactory() {
        return sportsEventFactory;
    }

    public void setSportsEventFactory(SportsEventFactory sportsEventFactory) {
        this.sportsEventFactory = sportsEventFactory;
    }

    public SportsLeagueFactory getSportsLeagueFactory() {
        return sportsLeagueFactory;
    }

    public void setSportsLeagueFactory(SportsLeagueFactory sportsLeagueFactory) {
        this.sportsLeagueFactory = sportsLeagueFactory;
    }

    public SportsTeamFactory getSportsTeamFactory() {
        return sportsTeamFactory;
    }

    public void setSportsTeamFactory(SportsTeamFactory sportsTeamFactory) {
        this.sportsTeamFactory = sportsTeamFactory;
    }

    public ReviewClient getReviewClient() {
        return reviewClient;
    }

    public void setReviewClient(ReviewClient reviewClient) {
        this.reviewClient = reviewClient;
    }

    public ReviewFactory getReviewFactory() {
        return reviewFactory;
    }

    public void setReviewFactory(ReviewFactory reviewFactory) {
        this.reviewFactory = reviewFactory;
    }

    public ProgramFactory getProgramEndpointFactory() {
        return programFactory;
    }

    public void setProgramEndpointFactory(ProgramFactory programFactory) {
        this.programFactory = programFactory;
    }

    public EpisodeProgramFactory getEpisodeProgramFactory() {
        return episodeProgramFactory;
    }

    public void setEpisodeProgramFactory(EpisodeProgramFactory episodeProgramFactory) {
        this.episodeProgramFactory = episodeProgramFactory;
    }

    public SeriesMasterProgramFactory getSeriesMasterProgramFactory() {
        return seriesMasterProgramFactory;
    }

    public void setSeriesMasterProgramFactory(SeriesMasterProgramFactory seriesMasterProgramFactory) {
        this.seriesMasterProgramFactory = seriesMasterProgramFactory;
    }

    public MovieProgramFactory getMovieProgramFactory() {
        return movieProgramFactory;
    }

    public void setMovieProgramFactory(MovieProgramFactory MovieProgramFactory) {
        this.movieProgramFactory = movieProgramFactory;
    }

    public CreditFactory getCreditFactory() {
        return creditFactory;
    }

    public void setCreditFactory(CreditFactory creditFactory) {
        this.creditFactory = creditFactory;
    }

    public PersonFactory getPersonFactory() {
        return personFactory;
    }

    public void setPersonFactory(PersonFactory personFactory) {
        this.personFactory = personFactory;
    }

    public ProgramMediaAssociationClient getProgramMediaAssociationClient() {
        return programMediaAssociationClient;
    }

    public void setProgramMediaAssociationClient(ProgramMediaAssociationClient programMediaAssociationClient) {
        this.programMediaAssociationClient = programMediaAssociationClient;
    }

    public TagFactory getTagFactory() {
        return tagFactory;
    }

    public void setTagFactory(TagFactory tagFactory) {
        this.tagFactory = tagFactory;
    }

    public InstitutionFactory getInstitutionFactory() {
        return institutionFactory;
    }

    public void setInstitutionFactory(InstitutionFactory institutionFactory) {
        this.institutionFactory = institutionFactory;
    }

    public MainImageTypeFactory getMainImageTypeFactory() {
        return mainImageTypeFactory;
    }

    public void setMainImageTypeFactory(MainImageTypeFactory mainImageTypeFactory) {
        this.mainImageTypeFactory = mainImageTypeFactory;
    }

    public PersonAssociationFactory getPersonAssociationFactory() {
        return personAssociationFactory;
    }

    public void setPersonAssociationFactory(PersonAssociationFactory personAssociationFactory) {
        this.personAssociationFactory = personAssociationFactory;
    }

    public ProgramAssociationFactory getProgramAssociationFactory() {
        return programAssociationFactory;
    }

    public void setProgramAssociationFactory(ProgramAssociationFactory programAssociationFactory) {
        this.programAssociationFactory = programAssociationFactory;
    }

    public AlbumFactory getAlbumFactory() {
        return albumFactory;
    }

    public void setAlbumFactory(AlbumFactory albumFactory) {
        this.albumFactory = albumFactory;
    }

    public AlbumReleaseFactory getAlbumReleaseFactory() {
        return albumReleaseFactory;
    }

    public void setAlbumReleaseFactory(AlbumReleaseFactory albumReleaseFactory) {
        this.albumReleaseFactory = albumReleaseFactory;
    }

    public SongFactory getSongFactory() {
        return songFactory;
    }

    public void setSongFactory(SongFactory songFactory) {
        this.songFactory = songFactory;
    }

    public AlbumClient getAlbumClient() {
        return albumClient;
    }

    public void setAlbumClient(AlbumClient albumClient) {
        this.albumClient = albumClient;
    }

    public AlbumReleaseClient getAlbumReleaseClient() {
        return albumReleaseClient;
    }

    public void setAlbumReleaseClient(AlbumReleaseClient albumReleaseClient) {
        this.albumReleaseClient = albumReleaseClient;
    }

    public SongClient getSongClient() {
        return songClient;
    }

    public void setSongClient(SongClient songClient) {
        this.songClient = songClient;
    }

    public AlbumCreditClient getAlbumCreditClient() {
        return albumCreditClient;
    }

    public void setAlbumCreditClient(AlbumCreditClient albumCreditClient) {
        this.albumCreditClient = albumCreditClient;
    }

    public SongCreditClient getSongCreditClient() {
        return songCreditClient;
    }

    public void setSongCreditClient(SongCreditClient songCreditClient) {
        this.songCreditClient = songCreditClient;
    }

    public SongCreditFactory getSongCreditFactory() {
        return songCreditFactory;
    }

    public void setSongCreditFactory(SongCreditFactory songCreditFactory) {
        this.songCreditFactory = songCreditFactory;
    }

    public RelatedPersonClient getRelatedPersonClient() {
        return relatedPersonClient;
    }

    public void setRelatedPersonClient(RelatedPersonClient relatedPersonClient) {
        this.relatedPersonClient = relatedPersonClient;
    }

    public RelatedPersonFactory getRelatedPersonFactory() {
        return relatedPersonFactory;
    }

    public void setRelatedPersonFactory(RelatedPersonFactory relatedPersonFactory) {
        this.relatedPersonFactory = relatedPersonFactory;
    }

    public RelatedAlbumClient getRelatedAlbumClient() {
        return relatedAlbumClient;
    }

    public void setRelatedAlbumClient(RelatedAlbumClient relatedAlbumClient) {
        this.relatedAlbumClient = relatedAlbumClient;
    }

    public RelatedAlbumFactory getRelatedAlbumFactory() {
        return relatedAlbumFactory;
    }

    public void setRelatedAlbumFactory(RelatedAlbumFactory relatedAlbumFactory) {
        this.relatedAlbumFactory = relatedAlbumFactory;
    }

    public RelatedSongClient getRelatedSongClient() {
        return relatedSongClient;
    }

    public void setRelatedSongClient(RelatedSongClient relatedSongClient) {
        this.relatedSongClient = relatedSongClient;
    }

    public RelatedSongFactory getRelatedSongFactory() {
        return relatedSongFactory;
    }

    public void setRelatedSongFactory(RelatedSongFactory relatedSongFactory) {
        this.relatedSongFactory = relatedSongFactory;
    }

    public AlbumReleaseSongAssociationClient getAlbumReleaseSongAssociationClient() {
        return albumReleaseSongAssociationClient;
    }

    public void setAlbumReleaseSongAssociationClient(AlbumReleaseSongAssociationClient albumReleaseSongAssociationClient) {
        this.albumReleaseSongAssociationClient = albumReleaseSongAssociationClient;
    }

    public ProgramSongAssociationClient getProgramSongAssociationClient() {
        return programSongAssociationClient;
    }

    public void setProgramSongAssociationClient(ProgramSongAssociationClient programSongAssociationClient) {
        this.programSongAssociationClient = programSongAssociationClient;
    }

    public AlbumReleaseSongAssociationFactory getAlbumReleaseSongAssociationFactory() {
        return albumReleaseSongAssociationFactory;
    }

    public void setAlbumReleaseSongAssociationFactory(AlbumReleaseSongAssociationFactory albumReleaseSongAssociationFactory) {
        this.albumReleaseSongAssociationFactory = albumReleaseSongAssociationFactory;
    }

    public ProgramSongAssociationFactory getProgramSongAssociationFactory() {
        return programSongAssociationFactory;
    }

    public void setProgramSongAssociationFactory(ProgramSongAssociationFactory programSongAssociationFactory) {
        this.programSongAssociationFactory = programSongAssociationFactory;
    }

    public SongCollectionClient getSongCollectionClient() {
        return songCollectionClient;
    }

    public void setSongCollectionClient(SongCollectionClient songCollectionClient) {
        this.songCollectionClient = songCollectionClient;
    }

    public SongCollectionFactory getSongCollectionFactory() {
        return songCollectionFactory;
    }

    public void setSongCollectionFactory(SongCollectionFactory songCollectionFactory) {
        this.songCollectionFactory = songCollectionFactory;
    }

    public DataComparator<Album> getAlbumComparator() {
        return albumComparator;
    }

    public void setAlbumComparator(DataComparator<Album> albumComparator) {
        this.albumComparator = albumComparator;
    }

    public DataComparator<Song> getSongComparator() {
        return songComparator;
    }

    public void setSongComparator(DataComparator<Song> songComparator) {
        this.songComparator = songComparator;
    }

    public ProgramMediaAssociationFactory getProgramMediaAssociationFactory() {
        return programMediaAssociationFactory;
    }

    public void setProgramMediaAssociationFactory(ProgramMediaAssociationFactory programMediaAssociationFactory) {
        this.programMediaAssociationFactory = programMediaAssociationFactory;
    }

    public void setPersonTeamAssociationFactory(PersonTeamAssociationFactory personTeamAssociationFactory) {
        this.personTeamAssociationFactory = personTeamAssociationFactory;
    }

    public ProgramRankClient getProgramRankClient() {
        return programRankClient;
    }

    public void setProgramRankClient(ProgramRankClient programRankClient) {
        this.programRankClient = programRankClient;
    }

    public ProgramRankFactory getProgramRankFactory() {
        return programRankFactory;
    }

    public void setProgramRankFactory(ProgramRankFactory programRankFactory) {
        this.programRankFactory = programRankFactory;
    }

    public DataComparator<ProgramRank> getProgramRankComparator() {
        return programRankComparator;
    }

    public void setProgramRankComparator(DataComparator<ProgramRank> programRankComparator) {
        this.programRankComparator = programRankComparator;
    }

    public MainImageTypeGroupFactory getMainImageTypeGroupFactory() {
        return mainImageTypeGroupFactory;
    }

    public void setMainImageTypeGroupFactory(MainImageTypeGroupFactory mainImageTypeGroupFactory) {
        this.mainImageTypeGroupFactory = mainImageTypeGroupFactory;
    }

    public MainImageTypeGroupClient getMainImageTypeGroupClient() {
        return mainImageTypeGroupClient;
    }

    public void setMainImageTypeGroupClient(MainImageTypeGroupClient mainImageTypeGroupClient) {
        this.mainImageTypeGroupClient = mainImageTypeGroupClient;
    }

    public ImageCriteriaFactory getImageCriteriaFactory() {
        return imageCriteriaFactory;
    }

    public void setImageCriteriaFactory(ImageCriteriaFactory imageCriteriaFactory) {
        this.imageCriteriaFactory = imageCriteriaFactory;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getLinearBaseUrl() {
        return linearBaseUrl;
    }

    public void setLinearBaseUrl(String linearBaseUrl) {
        this.linearBaseUrl = linearBaseUrl;
    }

    public String getIdBaseUrl() {
        return idBaseUrl;
    }

    public void setIdBaseUrl(String idBaseUrl) {
        this.idBaseUrl = idBaseUrl;
    }

    public String getMediaBaseUrl() {
        return mediaBaseUrl;
    }

    public void setMediaBaseUrl(String mediaBaseUrl) {
        this.mediaBaseUrl = mediaBaseUrl;
    }

    public TagAssociationFactory getSportsTeamTagAssociationFactory() {
        return sportsTeamTagAssociationFactory;
    }

    public void setSportsTeamTagAssociationFactory(TagAssociationFactory sportsTeamTagAssociationFactory) {
        this.sportsTeamTagAssociationFactory = sportsTeamTagAssociationFactory;
    }
}
