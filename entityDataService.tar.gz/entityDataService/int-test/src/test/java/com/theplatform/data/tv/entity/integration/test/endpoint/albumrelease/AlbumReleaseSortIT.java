package com.theplatform.data.tv.entity.integration.test.endpoint.albumrelease;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.test.AlbumReleaseComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "albumRelease", "sort" })
public class AlbumReleaseSortIT extends EntityTestBase {


	public void testAlbumReleaseSortByGuid() {
		List<AlbumRelease> albumReleases = albumReleaseFactory.create(4);
		albumReleases.get(0).setGuid("1");
		albumReleases.get(3).setGuid("2");
		albumReleases.get(1).setGuid("3");
		albumReleases.get(2).setGuid("4");

		this.albumReleaseClient.create(albumReleases);

		List<AlbumRelease> expectedSortedAlbumReleases = new ArrayList<>(albumReleases.size());
		expectedSortedAlbumReleases.add(albumReleases.get(0));
		expectedSortedAlbumReleases.add(albumReleases.get(3));
		expectedSortedAlbumReleases.add(albumReleases.get(1));
		expectedSortedAlbumReleases.add(albumReleases.get(2));

		Feed<AlbumRelease> retrievedAlbumReleases = this.albumReleaseClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("guid", false) },
				null, false);

		AlbumReleaseComparator.assertEquals(retrievedAlbumReleases, expectedSortedAlbumReleases);
	}

	public void testAlbumReleaseSortByTitle() {
		List<AlbumRelease> albumReleases = albumReleaseFactory.create(4);
		albumReleases.get(0).setTitle("A");
		albumReleases.get(2).setTitle("B");
		albumReleases.get(3).setTitle("C");
		albumReleases.get(1).setTitle("D");

		this.albumReleaseClient.create(albumReleases);

		List<AlbumRelease> expectedSortedAlbumReleases = new ArrayList<>(albumReleases.size());
		expectedSortedAlbumReleases.add(albumReleases.get(0));
		expectedSortedAlbumReleases.add(albumReleases.get(2));
		expectedSortedAlbumReleases.add(albumReleases.get(3));
		expectedSortedAlbumReleases.add(albumReleases.get(1));

		Feed<AlbumRelease> retrievedAlbumReleases = this.albumReleaseClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("title", false) },
				null, false);

		AlbumReleaseComparator.assertEquals(retrievedAlbumReleases, expectedSortedAlbumReleases);
	}

	public void testAlbumReleaseSortBySortTitle() {
		List<AlbumRelease> albumReleases = albumReleaseFactory.create(4);
		albumReleases.get(0).setSortTitle("A");
		albumReleases.get(2).setSortTitle("B");
		albumReleases.get(3).setSortTitle("C");
		albumReleases.get(1).setSortTitle("D");

		this.albumReleaseClient.create(albumReleases);

		List<AlbumRelease> expectedSortedAlbumReleases = new ArrayList<>(albumReleases.size());
		expectedSortedAlbumReleases.add(albumReleases.get(0));
		expectedSortedAlbumReleases.add(albumReleases.get(2));
		expectedSortedAlbumReleases.add(albumReleases.get(3));
		expectedSortedAlbumReleases.add(albumReleases.get(1));

		Feed<AlbumRelease> retrievedAlbumReleases = this.albumReleaseClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort("sortTitle", false) }, null, false);

		AlbumReleaseComparator.assertEquals(retrievedAlbumReleases, expectedSortedAlbumReleases);
	}

	public void testAlbumReleaseSortByReleaseDate() {
		List<AlbumRelease> albumReleases = albumReleaseFactory.create(4);
		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(11);
		releaseDate.setDay(4);

		albumReleases.get(0).setReleaseDate(releaseDate);
		releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(12);
		releaseDate.setDay(4);
		albumReleases.get(2).setReleaseDate(releaseDate);
		releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(12);
		releaseDate.setDay(6);
		albumReleases.get(3).setReleaseDate(releaseDate);
		
		releaseDate = new DateOnly();
		releaseDate.setYear(2012);
		releaseDate.setMonth(12);
		releaseDate.setDay(4);
		albumReleases.get(1).setReleaseDate(releaseDate);

		this.albumReleaseClient.create(albumReleases);

		List<AlbumRelease> expectedSortedAlbumReleases = new ArrayList<>(albumReleases.size());
		expectedSortedAlbumReleases.add(albumReleases.get(0));
		expectedSortedAlbumReleases.add(albumReleases.get(2));
		expectedSortedAlbumReleases.add(albumReleases.get(3));
		expectedSortedAlbumReleases.add(albumReleases.get(1));

		Feed<AlbumRelease> retrievedAlbums = this.albumReleaseClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("releaseDate", false) },
				null, false);

		AlbumReleaseComparator.assertEquals(retrievedAlbums, expectedSortedAlbumReleases);
	}

	public void testAlbumReleaseSortByDistributionDate() {
		List<AlbumRelease> albumReleases = albumReleaseFactory.create(4);
		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(11);
		releaseDate.setDay(4);

		albumReleases.get(0).setDistributionDate(releaseDate);
		releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(12);
		releaseDate.setDay(4);
		albumReleases.get(2).setDistributionDate(releaseDate);
		releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(12);
		releaseDate.setDay(6);
		albumReleases.get(3).setDistributionDate(releaseDate);
		
		releaseDate = new DateOnly();
		releaseDate.setYear(2012);
		releaseDate.setMonth(12);
		releaseDate.setDay(4);
		albumReleases.get(1).setDistributionDate(releaseDate);

		this.albumReleaseClient.create(albumReleases);

		List<AlbumRelease> expectedSortedAlbumReleases = new ArrayList<>(albumReleases.size());
		expectedSortedAlbumReleases.add(albumReleases.get(0));
		expectedSortedAlbumReleases.add(albumReleases.get(2));
		expectedSortedAlbumReleases.add(albumReleases.get(3));
		expectedSortedAlbumReleases.add(albumReleases.get(1));

		Feed<AlbumRelease> retrievedAlbums = this.albumReleaseClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort("distributionDate", false) }, null, false);

		AlbumReleaseComparator.assertEquals(retrievedAlbums, expectedSortedAlbumReleases);
	}

	public void testAlbumReleaseSortByDiscontinuedDate() {
		List<AlbumRelease> albumReleases = albumReleaseFactory.create(4);
		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(11);
		releaseDate.setDay(4);

		albumReleases.get(0).setDiscontinuedDate(releaseDate);
		releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(12);
		releaseDate.setDay(4);
		albumReleases.get(2).setDiscontinuedDate(releaseDate);
		releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(12);
		releaseDate.setDay(6);
		albumReleases.get(3).setDiscontinuedDate(releaseDate);
		
		releaseDate = new DateOnly();
		releaseDate.setYear(2012);
		releaseDate.setMonth(12);
		releaseDate.setDay(4);
		albumReleases.get(1).setDiscontinuedDate(releaseDate);

		this.albumReleaseClient.create(albumReleases);

		List<AlbumRelease> expectedSortedAlbumReleases = new ArrayList<>(albumReleases.size());
		expectedSortedAlbumReleases.add(albumReleases.get(0));
		expectedSortedAlbumReleases.add(albumReleases.get(2));
		expectedSortedAlbumReleases.add(albumReleases.get(3));
		expectedSortedAlbumReleases.add(albumReleases.get(1));

		Feed<AlbumRelease> retrievedAlbums = this.albumReleaseClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort("discontinuedDate", false) }, null, false);

		AlbumReleaseComparator.assertEquals(retrievedAlbums, expectedSortedAlbumReleases);
	}
}
