package com.theplatform.data.tv.entity.integration.test.endpoint.albumrelease;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseProductForm;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSoundType;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseField;
import com.theplatform.data.tv.entity.api.test.AlbumReleaseComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.media.api.data.objects.Rating;

@Test(groups = { "albumRelease", "crud" })
public class AlbumReleaseCRUDIT extends EntityTestBase {
	
	@Test(groups = { TestGroup.gbTest })
	public void testSingleAlbumReleaseCrud() {
		AlbumRelease entity = albumReleaseFactory.create();

		// CREATE
		AlbumRelease persistedEntity = albumReleaseClient.create(entity, new String[] {});
		AlbumReleaseComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		AlbumRelease retrievedEntity = albumReleaseClient.get(entity.getId(), new String[] {});
		AlbumReleaseComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setTitle(entity.getTitle() != null ? entity.getTitle().concat("update") : "albumRelease title");
		entity.setSortTitle(entity.getSortTitle() != null ? entity.getSortTitle().concat("update") : "albumRelease SortTitle");
		entity.setDescription(entity.getDescription() != null ? entity.getDescription().concat("update") : "albumRelease description");
		entity.setCopyrightInfo(entity.getCopyrightInfo() != null ? entity.getCopyrightInfo().concat("update") : "albumRelease copyrightInfo");
		entity.setProductForm(entity.getProductForm() != null && entity.getProductForm().equals(AlbumReleaseProductForm.Album.getFriendlyName()) ? AlbumReleaseProductForm.Album
				.getFriendlyName() : AlbumReleaseProductForm.Single.getFriendlyName());
		entity.setSoundType(entity.getSoundType() != null && entity.getSoundType().equals(AlbumReleaseSoundType.Stereo.getFriendlyName()) ? AlbumReleaseSoundType.Stereo
				.getFriendlyName() : AlbumReleaseSoundType.Mixed.getFriendlyName());
		entity.setDomesticImport(entity.getDomesticImport() != null && entity.getDomesticImport().equals("Domestic") ? "Import" : "Domestic");
		entity.setDuration(entity.getDuration() != null ? entity.getDuration() + 1 : 1);

		if (entity.getReleaseDate() != null) {
			entity.getReleaseDate().setDay(entity.getReleaseDate().getDay() + 1);
			entity.getReleaseDate().setMonth(entity.getReleaseDate().getMonth() + 1);
			entity.getReleaseDate().setYear(entity.getReleaseDate().getYear() + 1);
		} else
			entity.setReleaseDate(new DateOnly());

		if (entity.getDistributionDate() != null) {
			entity.getDistributionDate().setDay(entity.getDistributionDate().getDay() + 1);
			entity.getDistributionDate().setMonth(entity.getDistributionDate().getMonth() + 1);
			entity.getDistributionDate().setYear(entity.getDistributionDate().getYear() + 1);
		} else
			entity.setDistributionDate(new DateOnly());
		if (entity.getDiscontinuedDate() != null) {
			entity.getDiscontinuedDate().setDay(entity.getDiscontinuedDate().getDay() + 1);
			entity.getDiscontinuedDate().setMonth(entity.getDiscontinuedDate().getMonth() + 1);
			entity.getDiscontinuedDate().setYear(entity.getDiscontinuedDate().getYear() + 1);
		} else
			entity.setDiscontinuedDate(new DateOnly());

		entity.setAlbumId(albumClient.create(albumFactory.create()).getId());
		entity.setLabelCompanyId(entity.getLabelCompanyId() != null ? URI.create(entity.getLabelCompanyId().toString().concat("1")) : URI.create(this
				.getLinearBaseUrl() + "/data/Company/14231413"));
		entity.setDistributorCompanyId(entity.getDistributorCompanyId() != null ? URI.create(entity.getDistributorCompanyId().toString().concat("1")) : URI
				.create(getLinearBaseUrl() + "/data/Company/14231413"));
		entity.setMainRelease(!entity.getMainRelease());

		if (entity.getContentRatings() != null && entity.getContentRatings().size() > 0)
			entity.getContentRatings().get(0).setScheme(entity.getContentRatings().get(0).getScheme().equals("urn:mpaa") ? "urn:csm" : "urn:mpaa");

		else {
			Rating rating = new Rating();
			rating.setScheme("urn:mpaa");
			rating.setRating("NR");

			entity.setContentRatings(Arrays.asList(rating));
		}

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		albumReleaseClient.update(entity);

		AlbumRelease retrievedAfterUpdate = albumReleaseClient.get(entity.getId(), new String[] {});
		AlbumReleaseComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = albumReleaseClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			albumReleaseClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("AlbumRelease should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testAlbumReleaseFeedCrud() throws UnknownHostException {
		List<AlbumRelease> entities = albumReleaseFactory.create(5);

		// CREATE
		Feed<AlbumRelease> persistedEntities = albumReleaseClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			AlbumReleaseComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i));

		URI[] entityIds = new URI[entities.size()];
		for (int i = 0; i < entityIds.length; i++)
			entityIds[i] = entities.get(i).getId();

		// RETRIEVE
		Feed<AlbumRelease> retrievedEntities = albumReleaseClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			AlbumReleaseComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i));

		// DELETE
		long deletedEntities = albumReleaseClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (AlbumRelease entity : entities) {
			try {
				albumReleaseClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumReleaseDefaultFieldValues() {
		AlbumRelease entity = albumReleaseFactory.create();

		entity.setTitle(null);
		entity.setSortTitle(null);
		entity.setDescription(null);
		entity.setCopyrightInfo(null);
		entity.setProductForm(null);
		entity.setSoundType(null);
		entity.setDomesticImport(null);
		entity.setDuration(null);
		entity.setReleaseDate(null);
		entity.setDistributionDate(null);
		entity.setDiscontinuedDate(null);
		entity.setMerlinResourceType(null);
		entity.setLabelCompanyId(null);
		entity.setDistributorCompanyId(null);
		entity.setMainRelease(null);
		entity.setContentRatings(null);
		entity.setImageIds(null);
		entity.setTagIds(null);
		entity.setMerlinResourceType(null);

		AlbumRelease actual = albumReleaseClient.create(entity, new String[] {});
		entity.setMainRelease(false);
		entity.setContentRatings(new ArrayList<Rating>());
		entity.setImageIds(new ArrayList<URI>());
		entity.setTagIds(new ArrayList<URI>());
		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		AlbumReleaseComparator.assertEquals(actual, entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(DataObjectField.title, null),
			new DataServiceField(AlbumReleaseField.sortTitle, null), new DataServiceField(DataObjectField.description, null),
			new DataServiceField(AlbumReleaseField.copyrightInfo, null), new DataServiceField(AlbumReleaseField.productForm, null),
			new DataServiceField(AlbumReleaseField.soundType, null), new DataServiceField(AlbumReleaseField.domesticImport, null),
			new DataServiceField(AlbumReleaseField.duration, null), new DataServiceField(AlbumReleaseField.releaseDate, null),
			new DataServiceField(AlbumReleaseField.distributionDate, null), new DataServiceField(AlbumReleaseField.discontinuedDate, null),
			new DataServiceField(AlbumReleaseField.labelCompanyId, null), new DataServiceField(AlbumReleaseField.distributorCompanyId, null),
			new DataServiceField(AlbumReleaseField.mainRelease, false), new DataServiceField(AlbumReleaseField.contentRatings, new ArrayList<Rating>()),
			new DataServiceField(AlbumReleaseField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumReleaseCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(albumReleaseClient, albumReleaseFactory.create(), AlbumReleaseComparator.class,
				defaultValues, new DataServiceField[] { new DataServiceField(AlbumReleaseField.imageIds, new ArrayList<URI>()),
						new DataServiceField(AlbumReleaseField.tagIds, new ArrayList<URI>()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumReleaseCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(albumReleaseClient, albumReleaseFactory.create(), AlbumReleaseComparator.class,
				defaultValues, new DataServiceField[] { new DataServiceField(AlbumReleaseField.imageIds, new ArrayList<URI>()),
						new DataServiceField(AlbumReleaseField.tagIds, new ArrayList<URI>()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumReleaseUpdateWithAllNullNonRequiredFieldsGeneric() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		DateOnly dateOnly = new DateOnly(); 
		dateOnly.setDay(4); 
		dateOnly.setMonth(12);
		dateOnly.setYear(1999);
		Rating rating = new Rating();
		rating.setRating("True");
		rating.setScheme("urn:riaa");

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.title, "albumRelease title"));
		createValues.add(new DataServiceField(AlbumReleaseField.sortTitle, "albumRelease sortTitle"));
		createValues.add(new DataServiceField(DataObjectField.description, "albumRelease description"));
		createValues.add(new DataServiceField(AlbumReleaseField.copyrightInfo, "albumRelease copyrightInfo"));
		createValues.add(new DataServiceField(AlbumReleaseField.productForm, "Single"));
		createValues.add(new DataServiceField(AlbumReleaseField.soundType, "Mixed"));
		createValues.add(new DataServiceField(AlbumReleaseField.domesticImport, "Import"));
		createValues.add(new DataServiceField(AlbumReleaseField.duration, 100));
		createValues.add(new DataServiceField(AlbumReleaseField.releaseDate, dateOnly));
		createValues.add(new DataServiceField(AlbumReleaseField.distributionDate, dateOnly));
		createValues.add(new DataServiceField(AlbumReleaseField.discontinuedDate, dateOnly));
		createValues.add(new DataServiceField(AlbumReleaseField.labelCompanyId, URI.create(getLinearBaseUrl()+"/data/Company/11111")));
		createValues.add(new DataServiceField(AlbumReleaseField.distributorCompanyId, URI.create(getLinearBaseUrl()+"/data/Company/11112")));
		createValues.add(new DataServiceField(AlbumReleaseField.mainRelease, true));
		createValues.add(new DataServiceField(AlbumReleaseField.contentRatings, Arrays.asList(rating)));
		createValues.add(new DataServiceField(AlbumReleaseField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(albumReleaseClient, albumReleaseFactory.create(), AlbumReleaseComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), new DataServiceField[] { new DataServiceField(AlbumReleaseField.imageIds, new ArrayList<URI>()),
					new DataServiceField(AlbumReleaseField.tagIds, new ArrayList<URI>()) });
	}

	@Test(groups = TestGroup.gbTest)
	public void testAlbumReleaseUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		DateOnly dateOnly = new DateOnly(); 
		dateOnly.setDay(4); 
		dateOnly.setMonth(12);
		dateOnly.setYear(1999);
		Rating rating = new Rating();
		rating.setRating("True");
		rating.setScheme("urn:riaa");

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.title, "albumRelease title"));
		createValues.add(new DataServiceField(AlbumReleaseField.sortTitle, "albumRelease sortTitle"));
		createValues.add(new DataServiceField(DataObjectField.description, "albumRelease description"));
		createValues.add(new DataServiceField(AlbumReleaseField.copyrightInfo, "albumRelease copyrightInfo"));
		createValues.add(new DataServiceField(AlbumReleaseField.productForm, "Single"));
		createValues.add(new DataServiceField(AlbumReleaseField.soundType, "Mixed"));
		createValues.add(new DataServiceField(AlbumReleaseField.domesticImport, "Import"));
		createValues.add(new DataServiceField(AlbumReleaseField.duration, 100));
		createValues.add(new DataServiceField(AlbumReleaseField.releaseDate, dateOnly));
		createValues.add(new DataServiceField(AlbumReleaseField.distributionDate, dateOnly));
		createValues.add(new DataServiceField(AlbumReleaseField.discontinuedDate, dateOnly));
		createValues.add(new DataServiceField(AlbumReleaseField.labelCompanyId, URI.create(getLinearBaseUrl()+"/data/Company/11111")));
		createValues.add(new DataServiceField(AlbumReleaseField.distributorCompanyId, URI.create(getLinearBaseUrl()+"/data/Company/11112")));
		createValues.add(new DataServiceField(AlbumReleaseField.mainRelease, true));
		createValues.add(new DataServiceField(AlbumReleaseField.contentRatings, Arrays.asList(rating)));
		createValues.add(new DataServiceField(AlbumReleaseField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(albumReleaseClient, albumReleaseFactory.create(), AlbumReleaseComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), new DataServiceField[] { new DataServiceField(AlbumReleaseField.imageIds, new ArrayList<URI>()),
					new DataServiceField(AlbumReleaseField.tagIds, new ArrayList<URI>()) });
	}

}
