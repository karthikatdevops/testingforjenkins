package com.theplatform.data.tv.entity.integration.test.endpoint.ratingsmapping;

import com.theplatform.contrib.data.api.objects.RatingScheme;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.ratingsmapping.BySourceRatingSystem;
import com.theplatform.data.tv.entity.api.client.query.ratingsmapping.ByTargetRatingSystem;
import com.theplatform.data.tv.entity.api.data.objects.RatingsMapping;
import com.theplatform.data.tv.entity.api.fields.RatingsMappingField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.annotations.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by lemuri200 on 6/2/15.
 */
public class RatingsMappingQueryIT extends EntityTestBase {
    @Test
    public void bySourceRatingSystemQueryShouldReturnCorrectRatingsMapping() {
        RatingsMapping v1  = ratingsMappingFactory.create(new DataServiceField(RatingsMappingField.sourceRatingSystem, RatingScheme.AGVOT.getScheme()));
        ratingsMappingClient.create(v1);

        RatingsMapping ratingsMapping1  = ratingsMappingFactory.create(new DataServiceField(RatingsMappingField.sourceRatingSystem, RatingScheme.MPAA.getScheme()));
        ratingsMappingClient.create(ratingsMapping1);

        Query[] queries = new Query[] { new BySourceRatingSystem(RatingScheme.AGVOT.getScheme())};

        Feed<RatingsMapping> results = ratingsMappingClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getSourceRatingSystem(), equalTo(RatingScheme.AGVOT.getScheme()));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }

    @Test
    public void byTargetRatingSystemQueryShouldReturnCorrectRatingsMapping() {
        RatingsMapping v1  = ratingsMappingFactory.create(new DataServiceField(RatingsMappingField.targetRatingSystem, RatingScheme.MPAA.getScheme()));
        ratingsMappingClient.create(v1);

        RatingsMapping ratingsMapping1  = ratingsMappingFactory.create(new DataServiceField(RatingsMappingField.targetRatingSystem, RatingScheme.OFRB.getScheme()));
        ratingsMappingClient.create(ratingsMapping1);

        Query[] queries = new Query[] { new ByTargetRatingSystem(RatingScheme.MPAA.getScheme())};

        Feed<RatingsMapping> results = ratingsMappingClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getTargetRatingSystem(), equalTo(RatingScheme.MPAA.getScheme()));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }


}
