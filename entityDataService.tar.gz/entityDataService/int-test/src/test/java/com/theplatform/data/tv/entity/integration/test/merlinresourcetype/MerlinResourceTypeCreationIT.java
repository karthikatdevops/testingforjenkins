package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.objects.ManagedMerlinDataObject;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.MerlinTestReflectionUtil;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.NamespacedField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.fields.ProgramRankField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author jethrolai
 * 
 */
@Test(groups = { "merlinResourceType", "crud", TestGroup.gbTest })
public class MerlinResourceTypeCreationIT extends EntityTestBase {

	/**
	 * Disabling this method because ProgramRank no longer gets its MerlinResourceType from the parent Program.
     * See MERLIN-8805.
     *
	 * @param expected
	 *            unpersisted test target
	 * @param parentIdField
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 */
	@Test(dataProvider = "singleParentAssociatedObjects", enabled = false)
	public void testMerlinResourceTypeCreationSingleParent(ManagedMerlinDataObject expected, DataServiceClient client, ManagedMerlinDataObject parent,
			DataServiceClient parentClient, NamespacedField parentIdField, MerlinResourceType associatedObjectType, MerlinResourceType parentType)
			throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		parent.setMerlinResourceType(parentType);

		parent = (ManagedMerlinDataObject) parentClient.create(parent, new String[] { "merlinResourceType" });
		Assert.assertEquals(parent.getMerlinResourceType(), parentType);

		expected.setMerlinResourceType(associatedObjectType);

		MerlinTestReflectionUtil.set(expected, parentIdField, parent.getId());

		ManagedMerlinDataObject actual = (ManagedMerlinDataObject) client.create(expected, new String[] { "merlinResourceType" });

		Assert.assertEquals(
				actual.getMerlinResourceType(),
				expected.getMerlinResourceType().isLessVisibleThan(parent.getMerlinResourceType()) ? expected.getMerlinResourceType() : parent
						.getMerlinResourceType());
	}

	@DataProvider
	public Object[][] singleParentAssociatedObjects() {
		List<Object[]> argumentList = new ArrayList<>();
		for (MerlinResourceType associatedObjectType : MerlinResourceType.values())
			for (MerlinResourceType parentType : MerlinResourceType.values()) {

				Program program = programFactory.create();
				if (parentType.equals(MerlinResourceType.Editorial))
					program.setId(URI.create(this.getBaseUrl().concat("/data/Program/")
							.concat("" + ((URIUtils.getIdValue(program.getId()) / 1000) * 1000 + 500))));

				argumentList.add(new Object[] { programRankFactory.create(), programRankClient, program, programClient, ProgramRankField.programId,
						associatedObjectType, parentType });
			}
		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	@Test( dataProvider = "twoParentsAssociatedObjects")
	public void testMerlinResourceTypeCreationTwoParents(ManagedMerlinDataObject expected, DataServiceClient client,
			NamespacedField parentIdField1, DataServiceClient parentClient1, ManagedMerlinDataObject parent1, MerlinResourceType parentType1,
			NamespacedField parentIdField2, DataServiceClient parentClient2, ManagedMerlinDataObject parent2, MerlinResourceType parentType2)
			throws Exception {
		parent1.setMerlinResourceType(parentType1);
		parent1 = (ManagedMerlinDataObject) parentClient1.create(parent1, new String[] {});
		Assert.assertEquals(parent1.getMerlinResourceType(), parentType1);
		parent2.setMerlinResourceType(parentType2);
		parent2 = (ManagedMerlinDataObject) parentClient2.create(parent2, new String[] {});
		Assert.assertEquals(parent2.getMerlinResourceType(), parentType2);

		MerlinTestReflectionUtil.set(expected, parentIdField1, parent1.getId());
		MerlinTestReflectionUtil.set(expected, parentIdField2, parent2.getId());

		MerlinResourceType expectedType = findLeastVisible(parentType1, parentType2);
		
		ManagedMerlinDataObject actual = (ManagedMerlinDataObject) client.create(expected, new String[] {});

		Assert.assertEquals(actual.getMerlinResourceType(), expectedType);
	}

	@DataProvider
	public Object[][] twoParentsAssociatedObjects() {
		List<Object[]> argumentList = new ArrayList<>();
		
		for (MerlinResourceType parentType1 : MerlinResourceType.values()) {
			for (MerlinResourceType parentType2 : MerlinResourceType.values()) {
				Program program = programFactory.create();
					
				if (parentType1.equals(MerlinResourceType.Editorial))
					program.setId(URI.create(this.getBaseUrl().concat("/data/Program/")
							.concat("" + ((URIUtils.getIdValue(program.getId()) / 1000) * 1000 + 500))));
					
				Tag tag = tagFactory.create();
					
				if (parentType2.equals(MerlinResourceType.Editorial))
					tag.setId(URI.create(this.getBaseUrl().concat("/data/Tag/").concat("" + ((URIUtils.getIdValue(tag.getId()) / 1000) * 1000 + 500))));
					
				MerlinResourceType expectedType = findLeastVisible(parentType1, parentType2);
					
				TagAssociation expected = tagAssociationFactory.create();
					
				if(expectedType.equals(MerlinResourceType.Editorial)) {
					Long id = ((URIUtils.getIdValue(tag.getId()) / 1000) * 1000 + 540);
					
					expected.setId(URI.create(this.tagAssociationClient.getRequestUrl() + "/" + id));
					expected.setMerlinResourceType(null);
				}
					
				argumentList.add(new Object[] { expected, tagAssociationClient, TagAssociationField.entityId,
						programClient, program, parentType1, TagAssociationField.tagId, tagClient, tag, parentType2 });
			}
		}
		
		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		
		return argumentSet;
	}

	public void testMerlinResourceTypeCreationProgramRank() {
		ProgramRank expected = programRankFactory.create();
		Program program = programFactory.create();
		program.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		program = programClient.create(program);
		expected.setProgramId(program.getId());
		expected.setMerlinResourceType(MerlinResourceType.Temporary);

		ProgramRank actual = programRankClient.create(expected, new String[] { "merlinResourceType" });
		Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
	}

	public void testMerlinResourceTypeCreationTagAssociation() {
		TagAssociation expected = tagAssociationFactory.create();
		Program program = programFactory.create();
		program.setMerlinResourceType(MerlinResourceType.Editorial);
		program.setId(URI.create(this.getBaseUrl().concat("/data/Program/").concat("" + ((URIUtils.getIdValue(program.getId()) / 1000) * 1000 + 500))));
		program = programClient.create(program);
		expected.setEntityId(program.getId());

		Tag tag = tagFactory.create();
		tag.setMerlinResourceType(MerlinResourceType.Inactive);
		tag = tagClient.create(tag);
		expected.setTagId(tag.getId());
		expected.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		TagAssociation actual = tagAssociationClient.create(expected, new String[] { "merlinResourceType" });
		Assert.assertEquals(actual.getMerlinResourceType(), MerlinResourceType.Inactive);
	}

	private MerlinResourceType findLeastVisible(MerlinResourceType... types) {
		Set<MerlinResourceType> typeMap = new HashSet<>(Arrays.asList(types));

		final MerlinResourceType[] visibility = new MerlinResourceType[] { MerlinResourceType.Inactive, MerlinResourceType.Editorial,
				MerlinResourceType.Temporary, MerlinResourceType.AudienceAvailable };

		for (MerlinResourceType type : visibility)
			if (typeMap.contains(type))
				return type;
		// input is empty
		return null;

	}

}
