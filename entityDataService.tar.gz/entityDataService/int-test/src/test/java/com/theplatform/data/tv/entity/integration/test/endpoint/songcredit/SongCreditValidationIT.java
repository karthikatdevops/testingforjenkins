package com.theplatform.data.tv.entity.integration.test.endpoint.songcredit;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;

import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.fields.SongCreditField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "songCredit", "validation" })
public class SongCreditValidationIT extends EntityTestBase {

	@Test(expectedExceptions = ValidationException.class)
	public void testSongCreditCreationWithNullSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.songId, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testSongCreditCreationWithNonpersistedSong() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.songId, songFactory.create().getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testSongCreditCreationWithNonlocalSong() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localSongId = this.songClient.create(this.songFactory.create()).getId();
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.songId, songFactory.create(
				new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9002/entityDataService/data/Song/" + URIUtils.getIdValue(localSongId)))).getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testSongCreditCreationWithNullPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.personId, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testSongCreditCreationWithNonpersistedPerson() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.personId, personFactory.create().getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testSongCreditCreationWithNonlocalPerson() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localPersonId = this.personClient.create(this.personFactory.create()).getId();
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.personId, personFactory.create(
				new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9002/entityDataService/data/Person/" + URIUtils.getIdValue(localPersonId)))).getId())));
	}

	
	//person type validation not implemented because now there are only Person and Band type and this validation will be done in Person validation, 
	//knownFor contains Music validation is not implemented. 
}
