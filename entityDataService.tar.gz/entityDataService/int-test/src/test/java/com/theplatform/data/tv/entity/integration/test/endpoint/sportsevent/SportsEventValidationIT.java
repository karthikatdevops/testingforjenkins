package com.theplatform.data.tv.entity.integration.test.endpoint.sportsevent;

import static org.testng.Assert.assertEquals;

import java.net.UnknownHostException;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */
@Test(groups={"sportsEvent", "validation", "other"})
public class SportsEventValidationIT extends EntityTestBase {

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForTitle() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();
		// title string field allow 256 characters
		inputSportsEvent
				.setTitle("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Lengt");
		this.sportsEventClient.create(inputSportsEvent);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForCity() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();
		// title string field allow 255 characters
		inputSportsEvent
				.setCity("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		this.sportsEventClient.create(inputSportsEvent);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForState() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();
		// title string field allow 50 characters
		inputSportsEvent.setState("State validation State validation State validations");
		this.sportsEventClient.create(inputSportsEvent);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForCountry() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();
		// title string field allow 255 characters
		inputSportsEvent
				.setCountry("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		this.sportsEventClient.create(inputSportsEvent);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForSportType() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();
		// title string field allow 255 characters
		inputSportsEvent
				.setSportType("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		this.sportsEventClient.create(inputSportsEvent);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForConference() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();
		// title string field allow 255 characters
		inputSportsEvent
				.setConference("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		this.sportsEventClient.create(inputSportsEvent);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForDivision() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();
		// title string field allow 255 characters
		inputSportsEvent
				.setDivision("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		this.sportsEventClient.create(inputSportsEvent);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForVenue() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();
		// title string field allow 50 characters
		inputSportsEvent.setVenue("State validation State validation State validations");
		this.sportsEventClient.create(inputSportsEvent);
	}
}
