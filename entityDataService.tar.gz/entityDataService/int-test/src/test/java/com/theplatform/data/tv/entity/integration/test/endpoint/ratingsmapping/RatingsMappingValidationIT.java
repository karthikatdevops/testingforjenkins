package com.theplatform.data.tv.entity.integration.test.endpoint.ratingsmapping;

import com.theplatform.data.tv.entity.api.data.objects.RatingsMapping;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;
import org.testng.annotations.Test;

/**
 * Created by lemuri200 on 6/2/15.
 */
public class RatingsMappingValidationIT extends EntityTestBase{

    @Test(expectedExceptions = ValidationException.class)
    public void creatingRatingsMappingWithoutSourceRatingTypeShouldThrowException(){
        RatingsMapping ratingsMapping = ratingsMappingFactory.create();
        ratingsMapping.setSourceRatingSystem(null);
        ratingsMappingClient.create(ratingsMapping);
    }

    @Test(expectedExceptions = ValidationException.class)
    public void creatingRatingsMappingWithoutTargetRatingTypeShouldThrowException(){
        RatingsMapping ratingsMapping = ratingsMappingFactory.create();
        ratingsMapping.setTargetRatingSystem(null);
        ratingsMappingClient.create(ratingsMapping);
    }

    @Test(expectedExceptions = ValidationException.class)
    public void creatingRatingsMappingWithInvalidTargetRatingSystemShouldThrowException(){
        RatingsMapping ratingsMapping = ratingsMappingFactory.create();
        ratingsMapping.setTargetRatingSystem("Rating");
        ratingsMappingClient.create(ratingsMapping);
    }

    @Test(expectedExceptions = ValidationException.class)
    public void creatingRatingsMappingWithInvalidSourceRatingTypeShouldThrowException(){
        RatingsMapping ratingsMapping = ratingsMappingFactory.create();
        ratingsMapping.setSourceRatingSystem("Rating");
        ratingsMappingClient.create(ratingsMapping);
    }

}
