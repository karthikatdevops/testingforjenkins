package com.theplatform.data.tv.entity.integration.test.endpoint.albumreleasesongassociation;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.tv.entity.api.fields.AlbumReleaseSongAssociationField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.albumreleasesongassociation.ByAlbumReleaseId;
import com.theplatform.data.tv.entity.api.client.query.albumreleasesongassociation.BySongId;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import com.theplatform.data.tv.entity.api.test.AlbumReleaseSongAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "albumReleaseSongAssociation", "query" })
public class AlbumReleaseSongAssociationQueryIT extends EntityTestBase {



	public void testAlbumReleaseSongAssociationQueryBySongIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songClient.create(
				songFactory.create()).getId())));
		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songClient.create(songFactory.create()).getId())) };
		Feed<AlbumReleaseSongAssociation> results = this.albumReleaseSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumReleaseSongAssociation should be found");
	}

	public void testAlbumReleaseSongAssociationQueryBySongIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI songId = songClient.create(songFactory.create()).getId();
		AlbumReleaseSongAssociation expected = this.albumReleaseSongAssociationClient.create(
				this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songId)), new String[] {});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songClient.create(
				songFactory.create()).getId())));

		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<AlbumReleaseSongAssociation> results = this.albumReleaseSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumReleaseSongAssociation should be found");

		AlbumReleaseSongAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumReleaseSongAssociationQueryBySongIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId = songClient.create(songFactory.create()).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songClient.create(
				songFactory.create()).getId())));

		List<AlbumReleaseSongAssociation> expectedAlbumReleaseSongAssociations = this.albumReleaseSongAssociationClient.create(
				this.albumReleaseSongAssociationFactory.create(2, new DataServiceField(AlbumReleaseSongAssociationField.songId, songId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<AlbumReleaseSongAssociation> results = this.albumReleaseSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumReleaseSongAssociations should be found");

		Map<URI, AlbumReleaseSongAssociation> resultMap = new HashMap<URI, AlbumReleaseSongAssociation>();
		for (AlbumReleaseSongAssociation albumReleaseSongAssociation : results.getEntries())
			resultMap.put(albumReleaseSongAssociation.getId(), albumReleaseSongAssociation);

		for (AlbumReleaseSongAssociation expected : expectedAlbumReleaseSongAssociations)
			AlbumReleaseSongAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testAlbumReleaseSongAssociationQueryByAlbumReleaseIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient
				.create(albumReleaseFactory.create()).getId())));
		Query[] queries = new Query[] { new ByAlbumReleaseId(URIUtils.getIdValue(albumReleaseClient.create(albumReleaseFactory.create()).getId())) };
		Feed<AlbumReleaseSongAssociation> results = this.albumReleaseSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumReleaseSongAssociation should be found");
	}

	public void testAlbumReleaseSongAssociationQueryByAlbumReleaseIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI albumReleaseId = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		AlbumReleaseSongAssociation expected = this.albumReleaseSongAssociationClient.create(
				this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId)), new String[] {});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient
				.create(albumReleaseFactory.create()).getId())));

		Query[] queries = new Query[] { new ByAlbumReleaseId(URIUtils.getIdValue(albumReleaseId)) };
		Feed<AlbumReleaseSongAssociation> results = this.albumReleaseSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumReleaseSongAssociation should be found");

		AlbumReleaseSongAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumReleaseSongAssociationQueryByAlbumReleaseIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI albumReleaseId = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient
				.create(albumReleaseFactory.create()).getId())));

		List<AlbumReleaseSongAssociation> expectedAlbumReleaseSongAssociations = this.albumReleaseSongAssociationClient.create(
				this.albumReleaseSongAssociationFactory.create(2, new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByAlbumReleaseId(URIUtils.getIdValue(albumReleaseId)) };
		Feed<AlbumReleaseSongAssociation> results = this.albumReleaseSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumReleaseSongAssociations should be found");

		Map<URI, AlbumReleaseSongAssociation> resultMap = new HashMap<URI, AlbumReleaseSongAssociation>();
		for (AlbumReleaseSongAssociation albumReleaseSongAssociation : results.getEntries())
			resultMap.put(albumReleaseSongAssociation.getId(), albumReleaseSongAssociation);

		for (AlbumReleaseSongAssociation expected : expectedAlbumReleaseSongAssociations)
			AlbumReleaseSongAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testAlbumReleaseSongAssociationQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.merlinResourceType,
				MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<AlbumReleaseSongAssociation> results = this.albumReleaseSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumReleaseSongAssociation should be found");
	}

	public void testAlbumReleaseSongAssociationQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		AlbumReleaseSongAssociation expected = this.albumReleaseSongAssociationClient.create(
				this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
				new String[] {});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.merlinResourceType,
				MerlinResourceType.Editorial)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<AlbumReleaseSongAssociation> results = this.albumReleaseSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumReleaseSongAssociation should be found");

		AlbumReleaseSongAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumReleaseSongAssociationQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.merlinResourceType,
				MerlinResourceType.Editorial)));
		List<AlbumReleaseSongAssociation> expectedAlbumReleaseSongAssociations = this.albumReleaseSongAssociationClient.create(
				this.albumReleaseSongAssociationFactory.create(2, new DataServiceField(AlbumReleaseSongAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<AlbumReleaseSongAssociation> results = this.albumReleaseSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumReleaseSongAssociations should be found");

		Map<URI, AlbumReleaseSongAssociation> resultMap = new HashMap<URI, AlbumReleaseSongAssociation>();
		for (AlbumReleaseSongAssociation albumReleaseSongAssociation : results.getEntries()) {
			resultMap.put(albumReleaseSongAssociation.getId(), albumReleaseSongAssociation);
		}

		for (AlbumReleaseSongAssociation expected : expectedAlbumReleaseSongAssociations)
			AlbumReleaseSongAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

}
