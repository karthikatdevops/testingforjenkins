package com.theplatform.data.tv.entity.integration.test.endpoint.programsportsevent;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.fields.ProgramSportsEventField;
import com.theplatform.data.tv.entity.api.test.ProgramSportsEventComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * @since 4/7/2011
 */

@Test(groups = { "programSportsEvent", "crud" })
public class ProgramSportsEventCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void crudProgramSportsEventEntry() throws UnknownHostException {
		ProgramSportsEvent inputProgramSportsEvent = this.programSportsEventFactory.create();

		// CREATE
		ProgramSportsEvent persistedProgramSportsEvent = this.programSportsEventClient.create(inputProgramSportsEvent);
		assertEquals(persistedProgramSportsEvent.getId(), inputProgramSportsEvent.getId(), "ProgramSportsEvent ids should match after creation");

		// RETRIEVE
		ProgramSportsEvent retrievedProgramSportsEvent = this.programSportsEventClient.get(persistedProgramSportsEvent.getId(), new String[] {});
		ProgramSportsEventComparator.assertEquals(retrievedProgramSportsEvent, inputProgramSportsEvent);

		// UPDATE
		SportsEvent sportsEvent = this.sportsEventClient.create(this.sportsEventFactory.create());
		inputProgramSportsEvent.setSportsEventId(sportsEvent.getId());
		this.programSportsEventClient.update(inputProgramSportsEvent);
		ProgramSportsEvent retrievedAfterUpdate = this.programSportsEventClient.get(inputProgramSportsEvent.getId(), new String[] {});
		ProgramSportsEventComparator.assertEquals(retrievedAfterUpdate, inputProgramSportsEvent);
		assertFalse(retrievedProgramSportsEvent.getSportsEventId().equals(retrievedAfterUpdate.getSportsEventId()));

		// DELETE
		long deletedObjects = this.programSportsEventClient.delete(inputProgramSportsEvent.getId());
		assertEquals(deletedObjects, 1);
		try {
			this.programSportsEventClient.get(inputProgramSportsEvent.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		fail("ProgramSportsEvent should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudProgramSportsEventFeed() throws UnknownHostException {
		List<ProgramSportsEvent> inputProgramSportsEvents = this.programSportsEventFactory.create(7);

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] ProgramSportsEventIds = (URI[]) CollectionUtils.collect(inputProgramSportsEvents, TransformerUtils.invokerTransformer("getId")).toArray(
				new URI[] {});

		// CREATE
		Feed<ProgramSportsEvent> persistedProgramSportsEvents = this.programSportsEventClient.create(inputProgramSportsEvents);
		ComparatorUtils.assertIdsAreEqual(inputProgramSportsEvents, persistedProgramSportsEvents);

		// RETRIEVE
		Feed<ProgramSportsEvent> retrievedProgramSportsEvents = this.programSportsEventClient.get(ProgramSportsEventIds, new String[] {});
		ProgramSportsEventComparator.assertEquals(retrievedProgramSportsEvents, inputProgramSportsEvents);

		// UPDATE
		for (int i = 1; i < inputProgramSportsEvents.size(); i++) {
			SportsEvent sportsEvent = this.sportsEventClient.create(this.sportsEventFactory.create());
			inputProgramSportsEvents.get(i).setSportsEventId(sportsEvent.getId());
		}
		this.programSportsEventClient.update(inputProgramSportsEvents);
		Feed<ProgramSportsEvent> retrievedAfterUpdate = this.programSportsEventClient.get(ProgramSportsEventIds, new String[] {});
		ProgramSportsEventComparator.assertEquals(retrievedAfterUpdate, inputProgramSportsEvents);

		// DELETE
		long deletedProgramSportsEvents = this.programSportsEventClient.delete(ProgramSportsEventIds);
		assertEquals(deletedProgramSportsEvents, inputProgramSportsEvents.size());
		long notFoundProgramSportsEvents = 0;
		for (ProgramSportsEvent ProgramSportsEvent : inputProgramSportsEvents) {
			try {
				this.programSportsEventClient.get(ProgramSportsEvent.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundProgramSportsEvents++;
			}
		}
		assertEquals(notFoundProgramSportsEvents, deletedProgramSportsEvents, "Still found ProgramSportsEvent after deleting");
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] {
	// merlinResourceType is default to leastVisisble(associated sportsEvent,
	// program)
	new DataServiceField(ProgramSportsEventField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testProgramSportsEventCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(programSportsEventClient, programSportsEventFactory.create(),
				ProgramSportsEventComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramSportsEventCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(programSportsEventClient, programSportsEventFactory.create(),
				ProgramSportsEventComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramSportsEventUpdateWithAllNullNonRequiredFieldsGeneric() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ProgramSportsEventField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(programSportsEventClient, programSportsEventFactory.create(),
				ProgramSportsEventComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testProgramSportsEventUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ProgramSportsEventField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(programSportsEventClient, programSportsEventFactory.create(),
				ProgramSportsEventComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

}
