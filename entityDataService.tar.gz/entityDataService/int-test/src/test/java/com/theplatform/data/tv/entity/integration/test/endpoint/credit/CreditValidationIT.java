package com.theplatform.data.tv.entity.integration.test.endpoint.credit;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.PersonKnownForType;
import com.theplatform.data.tv.entity.api.data.objects.PersonType;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author jethrolai
 * 
 */
@Test(groups = { "credit", "validation" })
public class CreditValidationIT extends EntityTestBase {


	@Test(groups = { TestGroup.gbTest, "nightlyDisabled" })
	public void testCreditValidationCreateWithValidProgramId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.programId, this.programClient.create(
				this.programFactory.create()).getId())));
	}

	@Test(groups = TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreditValidationCreateWithNonPersistedProgram() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.programId, this.programFactory.create().getId())));

	}

	@Test(groups = TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreditValidationCreateWithNonLocalProgramId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.programId, URI
				.create("http://fakehost:9002/entityDataService/data/Program/122"))));

	}

	@Test(groups = { TestGroup.gbTest })
	public void testCreditValidationCreateWithValidPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.personId, this.personClient.create(this.personFactory.create())
				.getId())));
	}

	@Test(groups = TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreditValidationCreateWithNonPersistedPerson() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.personId, this.personFactory.create().getId())));

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testCreditValidationCreateWithNonLocalPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.personId, URI
				.create("http://fakehost:9002/entityDataService/data/Person/122"))));

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testCreditValidationCreateWithPersonIdPointingToWrongType() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.personId, this.programClient.create(
				this.programFactory.create()).getId())));

		// TODO add all other types of endpoints
	}

	// TODO MERLIN-7260 add this test back when this validation is implemented,
	// MERLIN-7260
	@Test(groups = { TestGroup.notImplemented }, expectedExceptions = ValidationException.class)
	public void testCreditValidationCreateWithProgramEntityAndNonPersonPersonType() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		List<String> knownFor = new ArrayList<String>();
		knownFor.add(PersonKnownForType.Video.getFriendlyName());
		URI personId = this.personClient.create(
				this.personFactory.create(new DataServiceField(PersonField.personType, PersonType.Band.getFriendlyName()), new DataServiceField(
						PersonField.knownFor, knownFor))).getId();

		this.creditClient.create(this.creditFactory.create(
				new DataServiceField(CreditField.entityId, this.programClient.create(this.programFactory.create()).getId()), new DataServiceField(
						CreditField.personId, personId)));
	}

	// TODO MERLIN-7260 add this test back when this validation is implemented,
	// MERLIN-7260
	@Test(groups = { TestGroup.notImplemented }, expectedExceptions = ValidationException.class)
	public void testCreditValidationCreateWithProgramEntityAndNoVideoKnownForType() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		List<String> knownFor = new ArrayList<String>();
		knownFor.add(PersonKnownForType.Music.getFriendlyName());
		URI personId = this.personClient.create(
				this.personFactory.create(new DataServiceField(PersonField.personType, PersonType.Person.getFriendlyName()), new DataServiceField(
						PersonField.knownFor, knownFor))).getId();

		this.creditClient.create(this.creditFactory.create(
				new DataServiceField(CreditField.entityId, this.programClient.create(this.programFactory.create()).getId()), new DataServiceField(
						CreditField.personId, personId)));
	}

	// TODO MERLIN-XXXX add this test back to core when those endpoints are
	// completed
	@Test(groups = { TestGroup.notImplemented }, expectedExceptions = ValidationException.class, dataProvider = "nonProgramEntityIds")
	public void testCreditValidationCreateWithNonProgramEntityAndNoMusicKnownForType(URI entityId) throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		List<String> knownFor = new ArrayList<String>();
		knownFor.add(PersonKnownForType.Video.getFriendlyName());
		URI personId = this.personClient.create(
				this.personFactory.create(new DataServiceField(PersonField.personType, PersonType.Person.getFriendlyName()), new DataServiceField(
						PersonField.knownFor, knownFor))).getId();

		this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.entityId, entityId), new DataServiceField(CreditField.personId,
				personId)));
	}

	@Test(groups = { TestGroup.gbTest })
	public void testCreditValidationWithGuidLargerMaxDefault() {
		Credit credit = this.creditFactory.create();
		StringBuilder guid = new StringBuilder();
		for (int i = 0; i < 280; i++) {
			guid.append("a");
		}
		credit.setGuid(guid.toString());
		creditClient.create(credit);
	}

	@DataProvider
	protected Object[][] nonProgramEntityIds() {
		List<Object[]> argumentList = new ArrayList<Object[]>();
		argumentList.add(new Object[] { this.albumClient.create(this.albumFactory.create()).getId() });
		argumentList.add(new Object[] { this.albumReleaseClient.create(this.albumReleaseFactory.create()).getId() });
		argumentList.add(new Object[] { this.songClient.create(this.songFactory.create()).getId() });
		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

}
