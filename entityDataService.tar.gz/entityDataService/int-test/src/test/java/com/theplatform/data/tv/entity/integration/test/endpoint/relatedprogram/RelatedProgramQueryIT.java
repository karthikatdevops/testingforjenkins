package com.theplatform.data.tv.entity.integration.test.endpoint.relatedprogram;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.relatedprogram.BySourceProgramId;
import com.theplatform.data.tv.entity.api.client.query.relatedprogram.ByTargetProgramId;
import com.theplatform.data.tv.entity.api.client.query.relatedprogram.ByType;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import com.theplatform.data.tv.entity.api.fields.RelatedProgramField;
import com.theplatform.data.tv.entity.api.test.RelatedProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "relatedProgram", "query", TestGroup.gbTest })
public class RelatedProgramQueryIT extends EntityTestBase {

	public void testRelatedProgramQueryBySourceProgramIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedProgramClient.create(this.relatedProgramFactory.create());
		Query[] queries = new Query[] { new BySourceProgramId(URIUtils.getIdValue(programClient.create(programFactory.create()).getId())) };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedProgram should be found");
	}

	public void testRelatedProgramQueryBySourceProgramIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		RelatedProgram expected = this.relatedProgramClient.create(this.relatedProgramFactory.create(), new String[] {});
		this.relatedProgramClient.create(this.relatedProgramFactory.create());

		Query[] queries = new Query[] { new BySourceProgramId(URIUtils.getIdValue(expected.getSourceProgramId())) };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedProgram should be found");

		RelatedProgramComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedProgramQueryBySourceProgramIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI sourceProgramId = programClient.create(programFactory.create()).getId();
		this.relatedProgramClient.create(this.relatedProgramFactory.create());

		List<RelatedProgram> expectedRelatedPrograms = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(2, new DataServiceField(RelatedProgramField.sourceProgramId, sourceProgramId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySourceProgramId(URIUtils.getIdValue(sourceProgramId)) };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedPrograms should be found");

		Map<URI, RelatedProgram> resultMap = new HashMap<>();
		for (RelatedProgram relatedProgram : results.getEntries())
			resultMap.put(relatedProgram.getId(), relatedProgram);

		for (RelatedProgram expected : expectedRelatedPrograms)
			RelatedProgramComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testRelatedProgramQueryByTargetProgramIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedProgramClient.create(this.relatedProgramFactory.create());
		Query[] queries = new Query[] { new ByTargetProgramId(URIUtils.getIdValue(programClient.create(programFactory.create()).getId())) };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedProgram should be found");
	}

	public void testRelatedProgramQueryByTargetProgramIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		RelatedProgram expected = this.relatedProgramClient.create(this.relatedProgramFactory.create(), new String[] {});
		this.relatedProgramClient.create(this.relatedProgramFactory.create());

		Query[] queries = new Query[] { new ByTargetProgramId(URIUtils.getIdValue(expected.getTargetProgramId())) };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedProgram should be found");

		RelatedProgramComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedProgramQueryByTargetProgramIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI targetProgramId = programClient.create(programFactory.create()).getId();
		this.relatedProgramClient.create(this.relatedProgramFactory.create());

		List<RelatedProgram> expectedRelatedPrograms = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(2, new DataServiceField(RelatedProgramField.targetProgramId, targetProgramId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByTargetProgramId(URIUtils.getIdValue(targetProgramId)) };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedPrograms should be found");

		Map<URI, RelatedProgram> resultMap = new HashMap<>();
		for (RelatedProgram relatedProgram : results.getEntries())
			resultMap.put(relatedProgram.getId(), relatedProgram);

		for (RelatedProgram expected : expectedRelatedPrograms)
			RelatedProgramComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testRelatedProgramQueryByTypeIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedProgramClient.create(this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.type, "HasTrailer")));
		Query[] queries = new Query[] { new ByType("HasMakingOf") };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedProgram should be found");
	}

	public void testRelatedProgramQueryByTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		RelatedProgram expected = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.type, "HasTrailer")), new String[] {});
		this.relatedProgramClient.create(this.relatedProgramFactory.create());

		Query[] queries = new Query[] { new ByType("HasTrailer") };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedProgram should be found");

		RelatedProgramComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedProgramQueryByTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		Feed<RelatedProgram> expectedRelatedPrograms = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(2, new DataServiceField(RelatedProgramField.type, "HasTrailer")), new String[] {});
		this.relatedProgramClient.create(this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.type, "HasMakingOf")));

		Query[] queries = new Query[] { new ByType("HasTrailer") };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedPrograms should be found");

		Map<URI, RelatedProgram> resultMap = new HashMap<>();
		for (RelatedProgram relatedProgram : results.getEntries())
			resultMap.put(relatedProgram.getId(), relatedProgram);

		for (RelatedProgram expected : expectedRelatedPrograms.getEntries())
			RelatedProgramComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testRelatedProgramQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedProgramClient.create(this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.merlinResourceType,
				MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedProgram should be found");
	}

	public void testRelatedProgramQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		RelatedProgram relatedProgram = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
				new String[] {});
		this.relatedProgramClient.create(this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.merlinResourceType,
				MerlinResourceType.Inactive)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedProgram should be found");

		RelatedProgramComparator.assertEquals(results.getEntries().get(0), relatedProgram);
	}

	public void testRelatedProgramQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedProgramClient.create(this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.merlinResourceType,
				MerlinResourceType.Inactive)));
		List<RelatedProgram> expectedRelatedPrograms = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(2, new DataServiceField(RelatedProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
				new String[] {}).getEntries();

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<RelatedProgram> results = this.relatedProgramClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedPrograms should be found");

		Map<URI, RelatedProgram> resultMap = new HashMap<>();
		for (RelatedProgram relatedProgram : results.getEntries())
			resultMap.put(relatedProgram.getId(), relatedProgram);

		for (RelatedProgram expected : expectedRelatedPrograms)
			RelatedProgramComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}
}
