package com.theplatform.data.tv.entity.integration.test.endpoint.sportsteam;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.client.query.SearchQuery;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.test.PersonComparator;
import com.theplatform.data.tv.entity.api.test.SportsTeamComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Test(groups = {"person"})
public class SportsTeamSearchQueryIT extends EntityTestBase {

    @Test(groups = {TestGroup.gbTest}, enabled = true)
    public void testGetSportsTeamsByLucene() {
        List<SportsTeam> teams = sportsTeamFactory.create(6);

        teams.get(0).setRepresentingName("Philadelphia");
        teams.get(0).setNickName("Phillies");
        teams.get(0).setCity("Philadelphia");
        teams.get(0).setState("PA");
        teams.get(0).setConference("NL");
        teams.get(0).setSportType("Baseball");

        teams.get(1).setRepresentingName("New York");
        teams.get(1).setNickName("Mets");
        teams.get(1).setCity("Flushing");
        teams.get(1).setState("NY");
        teams.get(1).setConference("NL");
        teams.get(1).setSportType("Baseball");

        teams.get(2).setRepresentingName("New York");
        teams.get(2).setNickName("Yankees");
        teams.get(2).setCity("Bronx");
        teams.get(2).setState("NY");
        teams.get(2).setConference("AL");
        teams.get(2).setSportType("Baseball");

        teams.get(3).setRepresentingName("Yeshiva");
        teams.get(3).setNickName("Maccabees");
        teams.get(3).setCity("New York City");
        teams.get(3).setState("NY");
        teams.get(3).setConference("Skyline Conference");
        teams.get(4).setSportType("Baseball");

        teams.get(4).setRepresentingName("Philadelphia");
        teams.get(4).setNickName("Eagles");
        teams.get(4).setCity("Philadelphia");
        teams.get(4).setState("PA");
        teams.get(4).setConference("NFC");
        teams.get(4).setSportType("Football");

        teams.get(5).setRepresentingName("Philadelphia");
        teams.get(5).setNickName("Flyers");
        teams.get(5).setCity("Philadelphia");
        teams.get(5).setState("PA");
        teams.get(5).setConference("Eastern");
        teams.get(5).setSportType("Hockey");

        sportsTeamClient.create(teams);

        // Wait for some arbitrary amount of time so notification can be picked up by
        // entityIndexer and it can push the persons into solr
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
        }

        Feed<SportsTeam> retrievedTeams;
        List<SportsTeam> expectedTeams;
        List<SportsTeam> sortedTeams;

        retrievedTeams = sportsTeamClient.getAll(null, new Query[]{new SearchQuery("Giants")}, null, null, true);
        Assert.assertEquals(retrievedTeams.getEntryCount(), new Long(0));

        retrievedTeams = sportsTeamClient.getAll(null, new Query[]{new SearchQuery("Philadelphia AND Phillies")}, null, null, true);
        expectedTeams = Arrays.asList(teams.get(0));
        SportsTeamComparator.assertEquals(retrievedTeams, expectedTeams);

        retrievedTeams = sportsTeamClient.getAll(null, new Query[]{new SearchQuery("Philadelphia Phillies")}, null, null, true);
        expectedTeams = Arrays.asList(teams.get(0), teams.get(4), teams.get(5));
        sortedTeams = sortDataObjectsById(retrievedTeams);
        SportsTeamComparator.assertEquals(expectedTeams, sortedTeams);

        retrievedTeams = sportsTeamClient.getAll(null, new Query[]{new SearchQuery("Philadelphia")}, null, null, true);
        expectedTeams = Arrays.asList(teams.get(0), teams.get(4), teams.get(5));
        sortedTeams = sortDataObjectsById(retrievedTeams);
        SportsTeamComparator.assertEquals(expectedTeams, sortedTeams);

        retrievedTeams = sportsTeamClient.getAll(null, new Query[]{new SearchQuery("Phillies")}, null, null, true);
        expectedTeams = Arrays.asList(teams.get(0));
        SportsTeamComparator.assertEquals(retrievedTeams, expectedTeams);

        retrievedTeams = sportsTeamClient.getAll(null, new Query[]{new SearchQuery("New York")}, null, null, true);
        expectedTeams = Arrays.asList(teams.get(1), teams.get(2), teams.get(3));
        sortedTeams = sortDataObjectsById(retrievedTeams);
        SportsTeamComparator.assertEquals(expectedTeams, sortedTeams);

        retrievedTeams = sportsTeamClient.getAll(null, new Query[]{new SearchQuery("representingName:\"New York\"")}, null, null, true);
        expectedTeams = Arrays.asList(teams.get(1), teams.get(2));
        sortedTeams = sortDataObjectsById(retrievedTeams);
        SportsTeamComparator.assertEquals(expectedTeams, sortedTeams);

        retrievedTeams = sportsTeamClient.getAll(null, new Query[]{new SearchQuery("nickName:Flyers")}, null, null, true);
        expectedTeams = Arrays.asList(teams.get(5));
        SportsTeamComparator.assertEquals(retrievedTeams, expectedTeams);
    }

    private <T extends DataObject> List<T> sortDataObjectsById(Feed<T> feed) {
        List<T> entries = feed.getEntries();
        Collections.sort(entries, new Comparator<T>() {
            @Override
            public int compare(T o1, T o2) {
                if (o1 == null && o2 == null) {
                    return 0;
                }
                if (o1 == null) {
                    return -1;
                }
                if (o2 == null) {
                    return 1;
                }
                return (int) (URIUtils.getIdValue(o1.getId()) - URIUtils.getIdValue(o2.getId()));
            }
        });
        return entries;
    }
}
