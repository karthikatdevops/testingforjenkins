package com.theplatform.data.tv.entity.integration.test;

import java.lang.reflect.InvocationTargetException;

import org.springframework.test.context.ContextConfiguration;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.noop.Endpoint;
import com.theplatform.contrib.testing.noop.NoOpUpdateIntegrationTest;
import com.theplatform.contrib.testing.test.TestGroup;

/**
 * EntityNoOpUpdateTest
 * Created by: Seth Kelly
 * Date: 3/11/14
 */
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Test( enabled = false, groups = { TestGroup.gbTest, "noOpUpdate" })
public class EntityNoOpUpdateIT  extends NoOpUpdateIntegrationTest {

    // Overriding test methods so it is disabled
	@Override
	public void validateFactoriesForAllEndpoints()
			throws IllegalAccessException, NoSuchMethodException,
			InvocationTargetException {
		// TODO Auto-generated method stub
		super.validateFactoriesForAllEndpoints();
	}

	// Overriding test method so it is disabled
	@Override
	public void testNoOpUpdates(Endpoint endpoint)
			throws IllegalAccessException, NoSuchMethodException,
			InvocationTargetException, InterruptedException {
		// TODO Auto-generated method stub
		super.testNoOpUpdates(endpoint);
	}
    
    

}
