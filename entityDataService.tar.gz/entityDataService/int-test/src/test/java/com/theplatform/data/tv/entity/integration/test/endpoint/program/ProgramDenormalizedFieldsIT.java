package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.util.MerlinUriUtil;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.albumreleasesongassociation.ByAlbumReleaseId;
import com.theplatform.data.tv.entity.api.client.query.program.BySportsTeamId;
import com.theplatform.data.tv.entity.api.data.objects.Album;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.fields.AlbumField;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.ProgramTeamAssociationField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;

/**
 * This test (and others like it) is meant to validate that the Program client does not return denormalized
 * entities (from associated endpoints) that are marked (have their MRT set to something)
 * other than AudienceAvailable
 * <p/>
 * Author: Vincent Fumo (vfumo) : vincent_fumo@cable.comcast.com
 * Created Date: 3/14/14 (today was pi day)
 */
@Test(groups = {"program", "denormalizedFields", TestGroup.gbTest})
public class ProgramDenormalizedFieldsIT extends EntityTestBase {

    public void gettingAProgramShouldNotReturnNonAACredits() {
        Program entity = programFactory.create();
        programClient.create(entity);
        URI entityId = entity.getId();

        Credit relatedEntity = creditFactory.create();
        relatedEntity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        relatedEntity.setProgramId(entityId);
        creditClient.create(relatedEntity);
        URI creditId = relatedEntity.getId();

        // 1) make sure that we get the relatedEntity (since it's AA)
        Program retrievedEntity = programClient.get(entityId, new String[]{ProgramField.credits.name()});
        List<CreditAssociation> associations = retrievedEntity.getCredits();
        assertThat(associations.size(), is(1));

        CreditAssociation ca = associations.get(0);
        assertThat(ca.getCreditId(), is(creditId));

        // 2) change the relatedEntity to be non AA
        relatedEntity.setMerlinResourceType(MerlinResourceType.Inactive);
        creditClient.update(relatedEntity);

        // 3) validate that the relatedEntity doesn't return
        // note: we change the fields returned so we aren't dealing with a stale cache
        retrievedEntity = programClient.get(entityId, new String[]{ProgramField.merlinResourceType.name(), ProgramField.credits.name()});
        associations = retrievedEntity.getCredits();
        assertThat(associations.size(), is(0));
    }

    public void gettingAProgramShouldNotReturnNonAATagAssociations() {
        Program entity = programFactory.create();
        programClient.create(entity);
        URI entityId = entity.getId();

        TagAssociation relatedEntity = tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId,entityId));
        relatedEntity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        tagAssociationClient.create(relatedEntity);
        URI relatedEntityId = relatedEntity.getTagId();

        // 1) make sure that we get the relatedEntity (since it's AA)
        Program retrievedEntity = programClient.get(entityId, new String[]{ProgramField.tagIds.name()});
        List<URI> ids = retrievedEntity.getTagIds();
        assertThat(ids, hasItem(relatedEntityId));

        // 2) change the relatedEntity to be non AA
        relatedEntity.setMerlinResourceType(MerlinResourceType.Inactive);
        tagAssociationClient.update(relatedEntity);

        // 3) validate that the relatedEntity doesn't return
        // note: we change the fields returned so we aren't dealing with a stale cache
        retrievedEntity = programClient.get(entityId, new String[]{ProgramField.merlinResourceType.name(), ProgramField.tagIds.name()});
        ids = retrievedEntity.getTagIds();
        assertThat(ids, not(hasItem(relatedEntityId)));
    }

    public void gettingAProgramShouldNotReturnNonAASportsTeamAssociations() {
        Program entity = programFactory.create();
        programClient.create(entity);
        URI entityId = entity.getId();

        SportsTeam team = sportsTeamClient.create(sportsTeamFactory.create());
        URI teamId = team.getId();

        ProgramTeamAssociation association = programTeamAssociationFactory.create(new DataServiceField(ProgramTeamAssociationField.programId, entityId), new DataServiceField(ProgramTeamAssociationField.sportsTeamId,teamId));
        association.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        programTeamAssociationClient.create(association);

        // 1) make sure that we get the entity by the relatedEnityt (since it's AA)
        Feed<Program> retrievedEntities = programClient.getAll(new String[]{"id"}, new Query[]{new BySportsTeamId(MerlinUriUtil.getIdValue(teamId))}, null, null, null);
        assertThat(retrievedEntities.getEntryCount(), is(1L));
        Program retrievedEntity = retrievedEntities.getEntries().get(0);
        assertThat(retrievedEntity.getId(), is(entityId));

        // 2) change the relatedEntity to be non AA
        association.setMerlinResourceType(MerlinResourceType.Inactive);
        programTeamAssociationClient.update(association);

        // 3) validate that the relatedEntity doesn't return
        // note: we change the fields returned so we aren't dealing with a stale cache
        retrievedEntities = programClient.getAll(new String[]{"id", "merlinResourceType"}, new Query[]{new BySportsTeamId(MerlinUriUtil.getIdValue(teamId))}, null, null, null);
        assertThat(retrievedEntities.getEntryCount(), is(0L));
    }
}
