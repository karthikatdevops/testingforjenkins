package com.theplatform.data.tv.entity.integration.test.endpoint.programsongassociation;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociationType;
import com.theplatform.data.tv.entity.api.fields.ProgramSongAssociationField;
import com.theplatform.data.tv.entity.api.test.ProgramSongAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "programSongAssociation", "crud" })
public class ProgramSongAssociationCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testSingleProgramSongAssociationCrud() {
		ProgramSongAssociation entity = this.programSongAssociationFactory.create();

		// CREATE
		ProgramSongAssociation persistedEntity = this.programSongAssociationClient.create(entity, new String[] {});
		ProgramSongAssociationComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		ProgramSongAssociation retrievedEntity = this.programSongAssociationClient.get(entity.getId(), new String[] {});
		ProgramSongAssociationComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setProgramId(this.programClient.create(this.programFactory.create()).getId());
		entity.setSongId(this.songClient.create(this.songFactory.create()).getId());

		entity.setType(entity.getType() != null && entity.getType().equals(ProgramSongAssociationType.MusicVideo.getFriendlyName()) ? ProgramSongAssociationType.FeaturedIn
				.getFriendlyName() : ProgramSongAssociationType.MusicVideo.getFriendlyName());

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		this.programSongAssociationClient.update(entity);

		ProgramSongAssociation retrievedAfterUpdate = this.programSongAssociationClient.get(entity.getId(), new String[] {});
		ProgramSongAssociationComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = this.programSongAssociationClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.programSongAssociationClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("ProgramSongAssociation should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testProgramSongAssociationFeedCrud() throws UnknownHostException {
		List<ProgramSongAssociation> entities = this.programSongAssociationFactory.create(5);

		// CREATE
		Feed<ProgramSongAssociation> persistedEntities = this.programSongAssociationClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			ProgramSongAssociationComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i));

		URI[] entityIds = new URI[entities.size()];
		for (int i = 0; i < entityIds.length; i++)
			entityIds[i] = entities.get(i).getId();

		// RETRIEVE
		Feed<ProgramSongAssociation> retrievedEntities = this.programSongAssociationClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			ProgramSongAssociationComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i));

		// DELETE
		long deletedEntities = this.programSongAssociationClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (ProgramSongAssociation entity : entities) {
			try {
				this.programSongAssociationClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramSongAssociationDefaultFieldValues() {
		ProgramSongAssociation entity = this.programSongAssociationFactory.create();

		entity.setMerlinResourceType(null);
		ProgramSongAssociation actual = this.programSongAssociationClient.create(entity, new String[] {});

		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		ProgramSongAssociationComparator.assertEquals(actual, entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(ProgramSongAssociationField.merlinResourceType,
			MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testProgramSongAssociationCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		ProgramSongAssociation psa = programSongAssociationFactory.create();
		Program program = programClient.get(psa.getProgramId(), new String[] { "type" });

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(programSongAssociationClient, psa, ProgramSongAssociationComparator.class,
				this.defaultValues, new DataServiceField[] { new DataServiceField(ProgramSongAssociationField.programType, program.getType()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramSongAssociationCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		ProgramSongAssociation psa = programSongAssociationFactory.create();
		Program program = programClient.get(psa.getProgramId(), new String[] { "type" });

		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(programSongAssociationClient, psa, ProgramSongAssociationComparator.class,
				this.defaultValues, new DataServiceField[] { new DataServiceField(ProgramSongAssociationField.programType, program.getType()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramSongAssociationUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		ProgramSongAssociation psa = programSongAssociationFactory.create();
		Program program = programClient.get(psa.getProgramId(), new String[] { "type" });
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ProgramSongAssociationField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(programSongAssociationClient, programSongAssociationFactory.create(),
				ProgramSongAssociationComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}),
				new DataServiceField[] { new DataServiceField(ProgramSongAssociationField.programType, program.getType()) });
	}

	@Test(groups = TestGroup.gbTest)
	public void testProgramSongAssociationUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		ProgramSongAssociation psa = programSongAssociationFactory.create();
		Program program = programClient.get(psa.getProgramId(), new String[] { "type" });
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ProgramSongAssociationField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(programSongAssociationClient, programSongAssociationFactory.create(),
				ProgramSongAssociationComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}),
				new DataServiceField[] { new DataServiceField(ProgramSongAssociationField.programType, program.getType()) });
	}
}
