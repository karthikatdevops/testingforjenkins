package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagetypegroup;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageTypeGroup;
import com.theplatform.data.tv.image.api.test.MainImageTypeGroupComparator;

@Test(groups = { "mainImageTypeGroup", "crud"})
public class MainImageTypeGroupCRUDIT extends EntityTestBase {



	@Test(groups = { TestGroup.gbTest })
	public void crudSingleMainImageTypeGroup() throws UnknownHostException {
		MainImageTypeGroup mainImageTypeGroup = this.mainImageTypeGroupFactory.create();

		// CREATE
		MainImageTypeGroup persistedMainImageTypeGroup = this.mainImageTypeGroupClient.create(mainImageTypeGroup, new String[] {});
		mainImageTypeGroup.setId(persistedMainImageTypeGroup.getId());
		MainImageTypeGroupComparator.assertEquals(persistedMainImageTypeGroup, mainImageTypeGroup);

		// RETRIEVE
		MainImageTypeGroup retrievedMainImageTypeGroup = this.mainImageTypeGroupClient.get(mainImageTypeGroup.getId(), new String[] {});
		MainImageTypeGroupComparator.assertEquals(retrievedMainImageTypeGroup, mainImageTypeGroup);

		// UPDATE
		mainImageTypeGroup.setTitle(mainImageTypeGroup.getTitle().concat(" updated"));
//		mainImageTypeGroup.setMerlinResourceType(mainImageTypeGroup.getMerlinResourceType() != null && mainImageTypeGroup.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
//				: MerlinResourceType.AudienceAvailable);

		this.mainImageTypeGroupClient.update(mainImageTypeGroup);

		MainImageTypeGroup retrievedAfterUpdate = this.mainImageTypeGroupClient.get(mainImageTypeGroup.getId(), new String[] {});
		MainImageTypeGroupComparator.assertEquals(retrievedAfterUpdate, mainImageTypeGroup);

		// DELETE
		long deletedObjects = this.mainImageTypeGroupClient.delete(mainImageTypeGroup.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.mainImageTypeGroupClient.get(mainImageTypeGroup.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("MainImageTypeGroup should not be found after deleting it");
	}

	public void crudMainImageTypeGroupFeed() throws UnknownHostException {
		List<MainImageTypeGroup> mainImageTypeGroups = this.mainImageTypeGroupFactory.create(5);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] MainImageTypeGroupIds = (URI[]) CollectionUtils.collect(mainImageTypeGroups, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<MainImageTypeGroup> persistedMainImageTypeGroups = this.mainImageTypeGroupClient.create(mainImageTypeGroups);
		ComparatorUtils.assertIdsAreEqual(mainImageTypeGroups, persistedMainImageTypeGroups);

		// RETRIEVE
		Feed<MainImageTypeGroup> retrievedMainImageTypeGroups = this.mainImageTypeGroupClient.get(MainImageTypeGroupIds, new String[] {});
		MainImageTypeGroupComparator.assertEquals(retrievedMainImageTypeGroups, mainImageTypeGroups);

		// DELETE
		long deletedMainImageTypeGroups = this.mainImageTypeGroupClient.delete(MainImageTypeGroupIds);
		Assert.assertEquals(deletedMainImageTypeGroups, mainImageTypeGroups.size());

		long notFoundMainImageTypeGroups = 0;
		for (MainImageTypeGroup MainImageTypeGroup : mainImageTypeGroups) {
			try {
				this.mainImageTypeGroupClient.get(MainImageTypeGroup.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundMainImageTypeGroups++;
			}
		}
		Assert.assertEquals(notFoundMainImageTypeGroups, deletedMainImageTypeGroups, "Still found MainImageTypeGroups after deleting");
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] {
//			new DataServiceField(MainImageTypeGroupField.merlinResourceType, MerlinResourceType.AudienceAvailable)
			};
	
	@Test(groups = { TestGroup.gbTest })
	public void testMainImageTypeGroupCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(mainImageTypeGroupClient, mainImageTypeGroupFactory.create(), MainImageTypeGroupComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testMainImageTypeGroupCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(mainImageTypeGroupClient, mainImageTypeGroupFactory.create(), MainImageTypeGroupComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testMainImageTypeGroupUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		
		List<DataServiceField> createValues = new ArrayList<>();
//		createValues.add(new DataServiceField(MainImageTypeGroupField.merlinResourceType, MerlinResourceType.Temporary));
		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(mainImageTypeGroupClient, mainImageTypeGroupFactory.create(), MainImageTypeGroupComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testMainImageTypeGroupUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
//		createValues.add(new DataServiceField(MainImageTypeGroupField.merlinResourceType, MerlinResourceType.Temporary));
		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(mainImageTypeGroupClient, mainImageTypeGroupFactory.create(), MainImageTypeGroupComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

}
