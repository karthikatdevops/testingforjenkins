package com.theplatform.data.tv.entity.integration.test.endpoint.song;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.test.SongComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "song", "sort"})
public class SongSortIT extends EntityTestBase {

	public void testSongSortByGuid() {
		List<Song> songs = songFactory.create(4);
		songs.get(0).setGuid("1");
		songs.get(3).setGuid("2");
		songs.get(1).setGuid("3");
		songs.get(2).setGuid("4");

		this.songClient.create(songs);

		List<Song> expectedSortedSongs = new ArrayList<>(songs.size());
		expectedSortedSongs.add(songs.get(0));
		expectedSortedSongs.add(songs.get(3));
		expectedSortedSongs.add(songs.get(1));
		expectedSortedSongs.add(songs.get(2));

		Feed<Song> retrievedSongs = this.songClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("guid", false) }, null, false);

		SongComparator.assertEquals(retrievedSongs, expectedSortedSongs);
	}
	public void testSongSortByTitle() {
		List<Song> songs = songFactory.create(4);
		songs.get(0).setTitle("A");
		songs.get(2).setTitle("B");
		songs.get(3).setTitle("C");
		songs.get(1).setTitle("D");

		this.songClient.create(songs);

		List<Song> expectedSortedSongs = new ArrayList<>(songs.size());
		expectedSortedSongs.add(songs.get(0));
		expectedSortedSongs.add(songs.get(2));
		expectedSortedSongs.add(songs.get(3));
		expectedSortedSongs.add(songs.get(1));

		Feed<Song> retrievedSongs = this.songClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("title", false) }, null, false);

		SongComparator.assertEquals(retrievedSongs, expectedSortedSongs);
	}
	public void testSongSortBySortTitle() {
		List<Song> songs = songFactory.create(4);
		songs.get(0).setSortTitle("A");
		songs.get(2).setSortTitle("B");
		songs.get(3).setSortTitle("C");
		songs.get(1).setSortTitle("D");

		this.songClient.create(songs);

		List<Song> expectedSortedSongs = new ArrayList<>(songs.size());
		expectedSortedSongs.add(songs.get(0));
		expectedSortedSongs.add(songs.get(2));
		expectedSortedSongs.add(songs.get(3));
		expectedSortedSongs.add(songs.get(1));

		Feed<Song> retrievedSongs = this.songClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("sortTitle", false) }, null, false);

		SongComparator.assertEquals(retrievedSongs, expectedSortedSongs);
	}
	public void testSongSortByIsrc() {
		List<Song> songs = songFactory.create(4);
		songs.get(0).setIsrc("A");
		songs.get(2).setIsrc("B");
		songs.get(3).setIsrc("C");
		songs.get(1).setIsrc("D");

		this.songClient.create(songs);

		List<Song> expectedSortedSongs = new ArrayList<>(songs.size());
		expectedSortedSongs.add(songs.get(0));
		expectedSortedSongs.add(songs.get(2));
		expectedSortedSongs.add(songs.get(3));
		expectedSortedSongs.add(songs.get(1));

		Feed<Song> retrievedSongs = this.songClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("isrc", false) }, null, false);

		SongComparator.assertEquals(retrievedSongs, expectedSortedSongs);
	}
}
