package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.io.IOException;
import java.net.UnknownHostException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * @since 4/7/2011
 */
@Test(groups = { "program" })
public class ProgramIndexerIT extends EntityTestBase {

	private static final String programPath = "/entity/data/Program";

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		Feed<Program> programs = this.programClient.getAll(new String[] {}, new Query[] {}, null, null, true);
		assertEquals(programs.getEntryCount().intValue(), 0, "There are already programs in to database before it runs test cases for GBTestProgramIndexer ");
	}

	// ProgramField.year
	@Test(groups = TestGroup.testBug)
	public void testSolrSearchForProgramByYear() throws HttpException, IOException {
		Program program = this.programFactory.create();
		// CREATE
		Program createdProgram = this.programClient.create(program);
		assertEquals(createdProgram.getId(), program.getId(), "Program id should match after creation");
		// RETRIEVE
		Program retrievedProgram = this.programClient.get(program.getId(), new String[] {});
		ProgramComparator.assertEquals(retrievedProgram, program);
		// HttpClient calls
		String val = getSolrServerResponse("year", program.getYear());
		if (val == null || val.length() == 0 || !val.contains(program.getYear() + "") || !val.contains(program.getId() + ""))
			fail("Unsuccessful return of created Program using Solr search byYear query");

		// UPDATE
		program.setYear(program.getYear() + 1);
		this.programClient.update(program);

		val = getSolrServerResponse("year", program.getYear());
		if (val == null || val.length() == 0 || !val.contains(program.getYear() + "") || !val.contains(program.getId() + ""))
			fail("Unsuccessful return of updated Program using Solr search byYear query");

		// DELETE
		long deletedObjects = this.programClient.delete(program.getId());
		assertEquals(deletedObjects, 1);

		val = getSolrServerResponse("year", program.getYear());
		if (val.contains(program.getYear() + "") || val.contains(program.getId() + ""))
			fail("After deleting program, Program return back using Solr search byYear query");
	}

	// Program end-point supported query field by solr search indexer
	// ProgramField.shortSynopsis
	// ProgramField.mediumSynopsis
	// ProgramField.longSynopsis
	// ProgramField.runtime
	// ProgramField.type
	// ProgramField.language
	// ProgramField.partNumber
	// ProgramField.totalParts
	// ProgramField.sortTitle
	// ProgramField.starRating
	// ProgramField.category
	// ProgramField.originalAirDate
	// ProgramField.firstRunCompanyId
	// ProgramField.adult
	// ProgramField.contentRating
	// ProgramField.releaseDate
	// ProgramField.seriesId
	// ProgramField.tvSeasonId
	// ProgramField.tvSeasonNumber
	// ProgramField.tvSeasonEpisodeNumber
	// ProgramField.seriesEpisodeNumber
	// ProgramField.episodeTitle
	// ProgramField.firstAirDate
	// ProgramField.lastAirDate
	// ProgramField.credits
	// ProgramField.tagIds
	// ProgramField.imageIds
	// ProgramField.mainImages

	private String getSolrServerResponse(String searchFieldName, Object searchFieldValue) throws HttpException, IOException {
		GetMethod method = new GetMethod(this.getBaseUrl());
		method.setPath(programPath);
		method.setQueryString(new NameValuePair[] { new NameValuePair("schema", "1.3.0"), new NameValuePair("form", "json"),
				new NameValuePair("fields", "id," + searchFieldName), new NameValuePair("q", "+" + searchFieldName + ":" + searchFieldValue) });
		HttpClient client = new HttpClient();
		int statusCode = client.executeMethod(method);
		if (statusCode != 200)
			fail("Unsuccessful return of Program using Solr search");
		byte[] responseBody = method.getResponseBody();
		String solrResponse = new String(responseBody);
		method.releaseConnection();
		if (solrResponse != null)
			return solrResponse.trim();
		else
			return null;
	}

}
