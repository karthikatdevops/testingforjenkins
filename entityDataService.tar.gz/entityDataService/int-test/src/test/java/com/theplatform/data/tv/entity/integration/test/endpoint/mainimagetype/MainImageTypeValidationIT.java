package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagetype;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.Arrays;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.StringUtil;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.NamespacedField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.image.api.fields.MainImageTypeField;
import com.theplatform.module.exception.ValidationException;

//TODO MERLIN-8965 updated validation tests for title and alias fails, need to debug
@Test(groups = { TestGroup.gbTest, "validation", "mainImageType"})
public class MainImageTypeValidationIT extends EntityTestBase {
	private Random random = new Random();

	@DataProvider
	private Object[][] editorialAndInactiveType() {
		return new Object[][] { { MerlinResourceType.Editorial }, { MerlinResourceType.Inactive } };
	}

	@DataProvider
	private Object[][] audienceAvailableAndTemporaryType() {
		return new Object[][] {
		 { MerlinResourceType.AudienceAvailable },
		{ MerlinResourceType.Temporary }
		 };
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryType")
	public void testMainImageTypeValidationCreateAudienceAvailableOrTemporaryWithNullTitle(MerlinResourceType merlinResourceType) {
		this.testMainImageTypeValidationCreateWithNullTitle(merlinResourceType);
	}

	@Test(dataProvider = "editorialAndInactiveType")
	public void testMainImageTypeValidationCreateEditorialOrInactiveWithNullTitle(MerlinResourceType merlinResourceType) {
		this.testMainImageTypeValidationCreateWithNullTitle(merlinResourceType);
	}

	private void testMainImageTypeValidationCreateWithNullTitle(MerlinResourceType merlinResourceType) {
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(DataObjectField.title, null), new DataServiceField(
				MainImageTypeField.merlinResourceType, merlinResourceType)));
	}

	//TODO MERLIN-8965 Temporary passes but AA fails. 
	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryType", groups = TestGroup.bug)
	public void testMainImageTypeValidationUpdateAudienceAvailableOrTemporaryWithNullTitle(MerlinResourceType merlinResourceType) {
		this.testMainImageTypeValidationUpdateWithNullTitle(merlinResourceType);
	}

	@Test(dataProvider = "editorialAndInactiveType", groups = TestGroup.bug)
	public void testMainImageTypeValidationUpdateEditorialOrInactiveWithNullTitle(MerlinResourceType merlinResourceType) {
		this.testMainImageTypeValidationUpdateWithNullTitle(merlinResourceType);
	}

	private void testMainImageTypeValidationUpdateWithNullTitle(MerlinResourceType merlinResourceType) {
		MainImageType mainImageType = this.mainImageTypeFactory.create(new DataServiceField(DataObjectField.title, "title"+ random.nextInt()), new DataServiceField(
				MainImageTypeField.merlinResourceType, merlinResourceType));
		final URI mainImageTypeId = this.mainImageTypeClient.create(mainImageType).getId();
		Assert.assertEquals(mainImageType.getId(), mainImageTypeId);
		
		mainImageType = new MainImageType();
		mainImageType.setId(mainImageTypeId);
		mainImageType.setTitle(null);
		mainImageType.setNull(DataObjectField.title);
		mainImageType.setNullFields(new NamespacedField[]{DataObjectField.title});
		this.mainImageTypeClient.create(mainImageType);
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryType")
	public void testMainImageTypeValidationCreateAudienceAvailableOrTemporaryWithNullAlias(MerlinResourceType merlinResourceType) {
		this.testMainImageTypeValidationCreateWithNullAlias(merlinResourceType);
	}

	@Test(dataProvider = "editorialAndInactiveType")
	public void testMainImageTypeValidationCreateEditorialOrInactiveWithNullAlias(MerlinResourceType merlinResourceType) {
		this.testMainImageTypeValidationCreateWithNullAlias(merlinResourceType);
	}

	private void testMainImageTypeValidationCreateWithNullAlias(MerlinResourceType merlinResourceType) {
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, null), new DataServiceField(
				MainImageTypeField.merlinResourceType, merlinResourceType)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryType")
	public void testMainImageTypeValidationUpdateAudienceAvailableOrTemporaryWithNullAlias(MerlinResourceType merlinResourceType) {
		this.testMainImageTypeValidationUpdateWithNullAlias(merlinResourceType);
	}

	@Test(dataProvider = "editorialAndInactiveType", groups = TestGroup.bug)
	public void testMainImageTypeValidationUpdateEditorialOrInactiveWithNullAlias(MerlinResourceType merlinResourceType) {
		this.testMainImageTypeValidationUpdateWithNullAlias(merlinResourceType);
	}

	private void testMainImageTypeValidationUpdateWithNullAlias(MerlinResourceType merlinResourceType) {
		MainImageType mainImageType = this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, "alias" + random.nextInt()),
				new DataServiceField(MainImageTypeField.merlinResourceType, merlinResourceType));
		final URI mainImageTypeId = this.mainImageTypeClient.create(mainImageType).getId();
		Assert.assertEquals(mainImageType.getId(), mainImageTypeId);
		mainImageType = new MainImageType();
		mainImageType.setId(mainImageTypeId);
		mainImageType.setAlias(null);
		mainImageType.setNull(MainImageTypeField.alias);
		mainImageType.setNullFields(new NamespacedField[]{MainImageTypeField.alias});
		this.mainImageTypeClient.create(mainImageType);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testMainImageTypeValidationCreateWithNonpersistedMainImageTypeGroup() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays
				.asList(mainImageTypeGroupFactory.create().getId()))));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testMainImageTypeValidationCreateWithInvalidMainImageTypeGroupId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays
				.asList(mainImageTypeFactory.create().getId()))));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testMainImageTypeValidationUpdateWithNonpersistedMainImageTypeGroup() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		MainImageType mainImageType = this.mainImageTypeClient.create(this.mainImageTypeFactory.create(), new String[] {});
		mainImageType.setMainImageTypeGroupIds(Arrays.asList(mainImageTypeGroupFactory.create().getId()));
		mainImageTypeClient.update(mainImageType);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testMainImageTypeValidationUpdateWithInvalidMainImageTypeGroupId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		MainImageType mainImageType = this.mainImageTypeClient.create(this.mainImageTypeFactory.create(), new String[] {});
		mainImageType.setMainImageTypeGroupIds(Arrays.asList(mainImageTypeFactory.create().getId()));
		mainImageTypeClient.update(mainImageType);
	}

	@Test(expectedExceptions = ValidationException.class, groups = TestGroup.bug)
	public void testMainImageTypeValidationCreateWithSameAliasEntityTypeEntityQuery() {

		MainImageType mainImageType1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create(), new String[] {});
		Assert.assertNotEquals(mainImageType1.getMerlinResourceType(), MerlinResourceType.Editorial);
		MainImageType mainImageType2 = this.mainImageTypeFactory.create();
		mainImageType2.setAlias(mainImageType1.getAlias());
		mainImageType2.setEntityType(mainImageType1.getEntityType());
		mainImageType2.setEntityQuery(mainImageType1.getEntityQuery());

		Assert.assertEquals(mainImageType1.getAlias(), mainImageType2.getAlias());
		Assert.assertEquals(mainImageType1.getEntityType(), mainImageType2.getEntityType());
		Assert.assertEquals(mainImageType1.getEntityQuery(), mainImageType2.getEntityQuery());

		Assert.assertNotEquals(mainImageType2.getMerlinResourceType(), MerlinResourceType.Editorial);

		this.mainImageTypeClient.create(mainImageType2);
	}

	public void testMainImageTypeValidationCreateEditorialWithSameAliasEntityTypeEntityQuery() {

		MainImageType mainImageType1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create(), new String[] {});
		MainImageType mainImageType2 = this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.merlinResourceType,
				MerlinResourceType.Editorial));

		mainImageType2.setAlias(mainImageType1.getAlias());
		mainImageType2.setEntityType(mainImageType1.getEntityType());
		mainImageType2.setEntityQuery(mainImageType1.getEntityQuery());

		Assert.assertEquals(mainImageType1.getAlias(), mainImageType2.getAlias());
		Assert.assertEquals(mainImageType1.getEntityType(), mainImageType2.getEntityType());
		Assert.assertEquals(mainImageType1.getEntityQuery(), mainImageType2.getEntityQuery());

		this.mainImageTypeClient.create(mainImageType2);
	}

	public void testMainImageTypeValidationCreateWithUniqueAliasEntityTypeEntityQuery() {
		MainImageType mainImageType1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create(), new String[] {});
		MainImageType mainImageType2 = this.mainImageTypeFactory.create();
		mainImageType2.setEntityType(mainImageType1.getEntityType().equals("Program") ? "Person" : "Program");
		mainImageType2.setEntityQuery(mainImageType1.getEntityQuery() != null ? mainImageType1.getEntityQuery().concat(" updated")
				: "mainImageType entityQuery".concat(StringUtil.generateRandomString()));
		mainImageType2.setAlias(mainImageType1.getAlias().concat(" updated"));

		Assert.assertNotEquals(mainImageType1.getEntityQuery(), mainImageType2.getEntityQuery());
		Assert.assertNotEquals(mainImageType1.getEntityType(), mainImageType2.getEntityType());
		Assert.assertNotEquals(mainImageType1.getAlias(), mainImageType2.getAlias());

		this.mainImageTypeClient.create(mainImageType2);
	}

	public void testMainImageTypeValidationUpdateWithUniqueAliasEntityTypeEntityQuery() {
		MainImageType mainImageType1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create(), new String[] {});
		MainImageType mainImageType2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create(), new String[] {});
		mainImageType2.setEntityType(mainImageType1.getEntityType().equals("Program") ? "Person" : "Program");
		mainImageType2.setEntityQuery(mainImageType1.getEntityQuery() != null ? mainImageType1.getEntityQuery().concat(" updated")
				: "mainImageType entityQuery".concat(StringUtil.generateRandomString()));
		mainImageType2.setAlias(mainImageType1.getAlias().concat(" updated"));

		Assert.assertNotEquals(mainImageType1.getEntityQuery(), mainImageType2.getEntityQuery());
		Assert.assertNotEquals(mainImageType1.getEntityType(), mainImageType2.getEntityType());
		Assert.assertNotEquals(mainImageType1.getAlias(), mainImageType2.getAlias());

		this.mainImageTypeClient.update(mainImageType2);
	}

	public void testMainImageTypeValidationCreateWithValidEntityType() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final String[] validEntityTypes = new String[] { "Program", "Person", "Credit", "SportsTeam", "SportsLeague", "SportsEvent", "EntityCollection",
				"Song", "Album", "AlbumRelease" };
		for (String entityType : validEntityTypes)
			mainImageTypeClient.create(mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.entityType, entityType)));
	}

	// TODO MERLIN-6991 every value except null fails. It seems no validation is
	// implemented. temporarily grouped to MERLIN-6991 because it's discovered
	// during this story
	@Test(groups = { TestGroup.bug }, dataProvider = "invalidEntityTypes", expectedExceptions = ValidationException.class)
	public void testMainImageTypeValidationCreateWithInvalidEntityType(String invalidEntityType) throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		mainImageTypeClient.create(mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.entityType, invalidEntityType)));
	}

	@DataProvider
	protected Object[][] invalidEntityTypes() {
		return new Object[][] { { null }, { "" }, { "asdfads" }, { "Company" }, { "Institution" } };
	}

}
