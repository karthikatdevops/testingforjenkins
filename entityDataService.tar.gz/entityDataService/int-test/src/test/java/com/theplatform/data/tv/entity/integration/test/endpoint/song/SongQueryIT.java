package com.theplatform.data.tv.entity.integration.test.endpoint.song;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.client.query.song.*;
import com.theplatform.data.tv.entity.api.fields.*;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.comparator.ExcludeField;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.data.objects.TagType;
import com.theplatform.data.tv.entity.api.test.SongComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "song", "query" })
public class SongQueryIT extends EntityTestBase {

	public void testSongQueryByTitleNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songClient.create(this.songFactory.create(new DataServiceField(DataObjectField.title, "title")));
		Query[] queries = new Query[] { new ByTitle("title altered") };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Song should be found");
	}

	public void testSongQueryByTitleOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String title1 = "title 1";
		final String title2 = "title 2";

		this.songClient.create(this.songFactory.create(new DataServiceField(DataObjectField.title, title1)));

		Song expectedSong = this.songClient.create(this.songFactory.create(new DataServiceField(DataObjectField.title, title2)), new String[] {});
		Query[] queries = new Query[] { new ByTitle(title2) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Song should be found");

		SongComparator.assertEquals(results.getEntries().get(0), expectedSong);
	}

	public void testSongQueryByTitleMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final String title1 = "title 1";
		final String title2 = "title 2";

		this.songClient.create(this.songFactory.create(3, new DataServiceField(DataObjectField.title, title1)));

		List<Song> expectedSongs = this.songClient.create(this.songFactory.create(2, new DataServiceField(DataObjectField.title, title2)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByTitle(title2) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Songs should be found");

		Map<URI, Song> resultMap = new HashMap<>();
		for (Song song : results.getEntries()) {
			resultMap.put(song.getId(), song);
		}

		for (Song expected : expectedSongs)
			SongComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testSongQueryByAlbumIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songClient.create(this.songFactory.create());
		Query[] queries = new Query[] { new ByAlbumId(URIUtils.getIdValue(albumClient.create(albumFactory.create()).getId())) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Song should be found");
	}

	public void testSongQueryByAlbumIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI albumId = albumClient.create(albumFactory.create()).getId();
		URI albumReleaseId = albumReleaseClient.create(albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumId))).getId();
		Song expected = songClient.create(this.songFactory.create(), new String[] {});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, expected.getId())));

		// adding some extra associations
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient
				.create(albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create()).getId()))).getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, songClient.create(this.songFactory.create()).getId())));
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient
				.create(albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create()).getId()))).getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, songClient.create(this.songFactory.create()).getId())));

		Query[] queries = new Query[] { new ByAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Song should be found");

		SongComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongQueryByAlbumIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI albumId = albumClient.create(albumFactory.create()).getId();
		URI albumReleaseId = albumReleaseClient.create(albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumId))).getId();
		Song expected1 = songClient.create(this.songFactory.create(), new String[] {});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, expected1.getId())));
		Song expected2 = songClient.create(this.songFactory.create(), new String[] {});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, expected2.getId())));
		// adding some extra associations
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient
				.create(albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create()).getId()))).getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, songClient.create(this.songFactory.create()).getId())));
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient
				.create(albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create()).getId()))).getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, songClient.create(this.songFactory.create()).getId())));

		Query[] queries = new Query[] { new ByAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Songs should be found");

		Map<URI, Song> resultMap = new HashMap<>();
		for (Song song : results.getEntries())
			resultMap.put(song.getId(), song);

		SongComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		SongComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testSongQueryByReleaseYearNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(1980);

		URI albumReleaseId = this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.releaseDate, releaseDate))).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(
				new DataServiceField(AlbumReleaseSongAssociationField.songId, this.songClient.create(this.songFactory.create()).getId()), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,
						albumReleaseId)));

		Query[] queries = new Query[] { new ByReleaseYear(releaseDate.getYear() + 1) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Song should be found");
	}

	public void testSongQueryByReleaseYearOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final int expectedYear = 1980;
		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		Song expected = this.songClient.create(this.songFactory.create(), new String[]{});
		URI albumReleaseId = this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.releaseDate, releaseDate))).getId();

		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, expected.getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId)));
		releaseDate.setYear(releaseDate.getYear() + 1);

		// adding extra association
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(
				new DataServiceField(AlbumReleaseSongAssociationField.songId, this.songClient.create(this.songFactory.create()).getId()), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,
						this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.releaseDate, releaseDate))).getId())));

		Query[] queries = new Query[] { new ByReleaseYear(expectedYear) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Song should be found");

		SongComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongQueryByReleaseYearMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final int expectedYear = 1980;
		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		Song expected1 = this.songClient.create(this.songFactory.create(), new String[]{});
		URI albumReleaseId = this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.releaseDate, releaseDate))).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, expected1.getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId)));
		Song expected2 = this.songClient.create(this.songFactory.create(), new String[]{});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, expected2.getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId)));

		// adding extra association
		releaseDate.setYear(releaseDate.getYear() + 1);
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(
				new DataServiceField(AlbumReleaseSongAssociationField.songId, this.songClient.create(this.songFactory.create()).getId()), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,
						this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.releaseDate, releaseDate))).getId())));

		Query[] queries = new Query[] { new ByReleaseYear(expectedYear) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Albums should be found");

		Map<URI, Song> resultMap = new HashMap<>();
		for (Song song : results.getEntries())
			resultMap.put(song.getId(), song);

		SongComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		SongComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testSongQueryByPrimaryPersonIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Song song = this.songClient.create(this.songFactory.create(), new String[] {});
		URI personId = this.personClient.create(this.personFactory.create()).getId();
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.type, "PrimaryArtist"),new DataServiceField(SongCreditField.personId, personId), new DataServiceField(SongCreditField.songId, song.getId())));

		Query[] queries = new Query[] { new ByPrimaryPersonId(URIUtils.getIdValue(this.personClient.create(this.personFactory.create()).getId())) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Song should be found");
	}
	public void testSongQueryByPrimaryPersonIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Song song = this.songClient.create(this.songFactory.create(), new String[] {});
		URI personId = this.personClient.create(this.personFactory.create()).getId();
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.type, "PrimaryArtist"),new DataServiceField(SongCreditField.personId, personId), new DataServiceField(SongCreditField.songId, song.getId())));

		Query[] queries = new Query[] { new ByPrimaryPersonId(URIUtils.getIdValue(personId)) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "One Song should be found");
		songComparator.assertEquals(results.getEntries().get(0), song, new ExcludeField("primaryPersonIds"));
	}
	public void testSongQueryByPrimaryPersonIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Song song1 = this.songClient.create(this.songFactory.create(), new String[] {});
		Song song2 = this.songClient.create(this.songFactory.create(), new String[] {});
		URI personId = this.personClient.create(this.personFactory.create()).getId();
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.type, "PrimaryArtist"),new DataServiceField(SongCreditField.personId, personId), new DataServiceField(SongCreditField.songId, song1.getId())));
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.type, "PrimaryArtist"),new DataServiceField(SongCreditField.personId, personId), new DataServiceField(SongCreditField.songId, song2.getId())));

		Query[] queries = new Query[] { new ByPrimaryPersonId(URIUtils.getIdValue(personId)) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "2 Songs should be found");
	}
	public void testSongQueryByTagIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI songId = this.songClient.create(this.songFactory.create()).getId();
		URI tagId = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, songId), new DataServiceField(TagAssociationField.tagId, tagId)));

		Query[] queries = new Query[] { new ByTagId(URIUtils.getIdValue(this.songClient.create(this.songFactory.create()).getId())) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Song should be found");
	}
	public void testSongQueryByTagIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		Song song = this.songClient.create(this.songFactory.create(), new String[] {});
		URI tagId = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		this.tagAssociationClient
				.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, song.getId()), new DataServiceField(TagAssociationField.tagId, tagId)));

		Query[] queries = new Query[] { new ByTagId(URIUtils.getIdValue(tagId)) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "One Song should be found");

		song.getTagIds().add(tagId);
		SongComparator.assertEquals(results.getEntries().get(0), song);
	}
	public void testSongQueryByTagIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		Song song1 = this.songClient.create(this.songFactory.create(), new String[] {});
		Song song2 = this.songClient.create(this.songFactory.create(), new String[] {});
		Song song3 = this.songClient.create(this.songFactory.create(), new String[] {});
		URI tagId1 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		URI tagId2 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		URI tagId3 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, song1.getId()), new DataServiceField(TagAssociationField.tagId,
				tagId1)));
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, song2.getId()), new DataServiceField(TagAssociationField.tagId,
				tagId2)));
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, song3.getId()), new DataServiceField(TagAssociationField.tagId,
				tagId3)));

		List<Long> tagIds = new ArrayList<>(Arrays.asList(new Long[] { URIUtils.getIdValue(tagId1), URIUtils.getIdValue(tagId2) }));
		Query[] queries = new Query[] { new ByTagId(tagIds) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Songs should be found");

		Map<URI, Song> resultMap = new HashMap<>();
		for (Song song : results.getEntries()) {
			resultMap.put(song.getId(), song);
		}

		song1.getTagIds().add(tagId1);
		song2.getTagIds().add(tagId2);
		SongComparator.assertEquals(resultMap.get(song1.getId()), song1);
		SongComparator.assertEquals(resultMap.get(song2.getId()), song2);
	}

	public void testSongQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songClient.create(this.songFactory.create(new DataServiceField(SongField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Song should be found");
	}

	public void testSongQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		Song song = this.songClient.create(this.songFactory.create(new DataServiceField(SongField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
				new String[] {});
		this.songClient.create(this.songFactory.create(new DataServiceField(SongField.merlinResourceType, MerlinResourceType.Editorial)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Song should be found");

		SongComparator.assertEquals(results.getEntries().get(0), song);
	}

	public void testSongQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songClient.create(this.songFactory.create(new DataServiceField(SongField.merlinResourceType, MerlinResourceType.Editorial)));
		List<Song> expectedSongs = this.songClient.create(
				this.songFactory.create(2, new DataServiceField(SongField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {}).getEntries();

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Songs should be found");

		Map<URI, Song> resultMap = new HashMap<>();
		for (Song song : results.getEntries())
			resultMap.put(song.getId(), song);

		for (Song expected : expectedSongs)
			SongComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}
	
	
	
	
	/****************************************************************************
	 * ByAlbumReleaseId
	 ****************************************************************************/
	public void testSongQueryByAlbumReleaseIdNoMatch() {

		this.songClient.create(this.songFactory.create(), new String[] {});
		Query[] queries = new Query[] { new ByAlbumReleaseId(URIUtils.getIdValue(albumReleaseFactory.create().getId())) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Song should be found");
	}

	public void testSongQueryByAlbumReleaseIdListNoMatch() {

		this.songClient.create(this.songFactory.create(2), new String[] {});
		Query[] queries = new Query[] { new ByAlbumReleaseId(Arrays.asList(URIUtils.getIdValue(albumReleaseFactory.create().getId()),
				URIUtils.getIdValue(albumReleaseFactory.create().getId()))) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Song should be found");
	}

	public void testSongQueryByAlbumReleaseIdOneMatch() {

		final URI albumReleaseId1 = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		final URI albumReleaseId2 = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		Assert.assertNotEquals(albumReleaseId1, albumReleaseId2);

		URI songId = this.songClient.create(this.songFactory.create()).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songId), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId1 ))); 
		
		Song expected = this.songClient.create(this.songFactory.create(), new String[]{});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, expected.getId()), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId2 )));

		Query[] queries = new Query[] { new ByAlbumReleaseId(URIUtils.getIdValue(albumReleaseId2)) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Song should be found");

		SongComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongQueryByAlbumReleaseIdListOneMatch() {

		final URI albumReleaseId1 = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		final URI albumReleaseId2 = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		Assert.assertNotEquals(albumReleaseId1, albumReleaseId2);

		URI songId = this.songClient.create(this.songFactory.create()).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songId), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId1 )));

		Song expected = this.songClient.create(this.songFactory.create(), new String[]{});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, expected.getId()), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId2 )));
		
		Query[] queries = new Query[] { new ByAlbumReleaseId(Arrays.asList(URIUtils.getIdValue(albumReleaseId2), URIUtils.getIdValue(albumReleaseFactory.create().getId()))) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Song should be found");

		SongComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongQueryByAlbumReleaseIdMultipleMatch() {

		final URI albumReleaseId1 = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		final URI albumReleaseId2 = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		Assert.assertNotEquals(albumReleaseId1, albumReleaseId2);

		Song expected1 = this.songClient.create(this.songFactory.create(), new String[]{});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, expected1.getId()), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId1 )));
		Song expected2 = this.songClient.create(this.songFactory.create(), new String[]{});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, expected2.getId()), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId1 )));
		URI songId = this.songClient.create(this.songFactory.create()).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songId), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId2 )));

		Query[] queries = new Query[] { new ByAlbumReleaseId(URIUtils.getIdValue(albumReleaseId1)) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Songs should be found");

		Map<URI, Song> resultMap = new HashMap<>();
		for (Song stream : results.getEntries())
			resultMap.put(stream.getId(), stream);

		SongComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		SongComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testSongQueryByAlbumReleaseIdListMultipleMatch() {

		final URI albumReleaseId1 = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		final URI albumReleaseId2 = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		final URI albumReleaseId3 = albumReleaseClient.create(albumReleaseFactory.create()).getId();
		Assert.assertNotEquals(albumReleaseId1, albumReleaseId3);
		Assert.assertNotEquals(albumReleaseId2, albumReleaseId3);
		Song expected1 = this.songClient.create(this.songFactory.create(), new String[]{});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, expected1.getId()), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId1 )));
		Song expected2 = this.songClient.create(this.songFactory.create(), new String[]{});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, expected2.getId()), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId2 )));
		URI songId = this.songClient.create(this.songFactory.create()).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songId), new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId,albumReleaseId3 )));

		Query[] queries = new Query[] { new ByAlbumReleaseId(Arrays.asList(URIUtils.getIdValue(albumReleaseId1), URIUtils.getIdValue(albumReleaseId2))) };
		Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Songs should be found");

		Map<URI, Song> resultMap = new HashMap<>();
		for (Song song : results.getEntries())
			resultMap.put(song.getId(), song);

		SongComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		SongComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

    public void testSongQueryByIsrcNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
        ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        this.songClient.create(this.songFactory.create(new DataServiceField(SongField.isrc, "notthere")));
        Query[] queries = new Query[] { new ByIsrc("isrc altered") };
        Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries().size(), 0, "No isrc should be found");
    }
    public void testSongQueryByIsrcOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        final String isrc1 = "isrc1";
        final String isrc2 = "isrc2";

        this.songClient.create(this.songFactory.create(new DataServiceField(SongField.isrc, isrc1)));

        Song expectedSong = this.songClient.create(this.songFactory.create(new DataServiceField(SongField.isrc, isrc2)), new String[] {});
        Query[] queries = new Query[] { new ByIsrc(isrc2) };
        Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries().size(), 1, "Exactly 1 isrc should be found");

        SongComparator.assertEquals(results.getEntries().get(0), expectedSong);
    }
    public void testSongQueryByIsrcMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
        final String isrc1 = "isrc1";
        final String isrc2 = "isrc2";

        this.songClient.create(this.songFactory.create(3, new DataServiceField(SongField.isrc, isrc1)));

        List<Song> expectedSongs = this.songClient.create(this.songFactory.create(2, new DataServiceField(SongField.isrc, isrc2)), new String[] {}).getEntries();
        Query[] queries = new Query[] { new ByIsrc(isrc2) };
        Feed<Song> results = this.songClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries().size(), 2, "Exactly two Songs should be found");

        Map<URI, Song> resultMap = new HashMap<>();
        for (Song song : results.getEntries()) {
            resultMap.put(song.getId(), song);
        }

        for (Song expected : expectedSongs)
            SongComparator.assertEquals(resultMap.get(expected.getId()), expected);
    }


}
