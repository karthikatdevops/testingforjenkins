package com.theplatform.data.tv.entity.integration.test.endpoint.sportsteam;

import static org.testng.Assert.assertEquals;

import java.net.UnknownHostException;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */
@Test(groups = { "sportsTeam", "validation","other" })
public class SportsTeamValidationIT extends EntityTestBase {

	private static final String[] GENDER_TYPE = { null, "Male", "Female", "Co-Ed", "Unknown" };

    @Test(expectedExceptions = ValidationException.class)
    public void testIllegalType() throws UnknownHostException {
        SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
        inputSportsTeam.setType("Illegal Type");
        sportsTeamClient.create(inputSportsTeam);
    }

	@Test(groups = { "other" })
	public void testValidatingGender() throws UnknownHostException {
		List<SportsTeam> inputSportsTeams = this.sportsTeamFactory.create(5);
		for (int i = 0; i < GENDER_TYPE.length; i++) {
			inputSportsTeams.get(i).setGender(GENDER_TYPE[i]);
		}
		assertEquals(sportsTeamClient.create(inputSportsTeams).getEntryCount().longValue(), 5);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testIllegalGender() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		inputSportsTeam.setGender("Illegal Gender");
		sportsTeamClient.create(inputSportsTeam);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForRepresentingName() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		// title string field allow 255 characters
		inputSportsTeam
				.setRepresentingName("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		sportsTeamClient.create(inputSportsTeam);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForNickname() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		// title string field allow 50 characters
		inputSportsTeam.setNickName("State validation State validation State validations");
		sportsTeamClient.create(inputSportsTeam);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForCity() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		// title string field allow 255 characters
		inputSportsTeam
				.setCity("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		sportsTeamClient.create(inputSportsTeam);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForState() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		// title string field allow 50 characters
		inputSportsTeam.setState("State validation State validation State validations");
		sportsTeamClient.create(inputSportsTeam);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForCountry() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		// title string field allow 255 characters
		inputSportsTeam
				.setCountry("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		sportsTeamClient.create(inputSportsTeam);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForCoach() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		// title string field allow 128 characters
		inputSportsTeam
				.setCoach("Coach length validation Coach length validation Coach length validation Coach length validation Coach length validation Coach len");
		sportsTeamClient.create(inputSportsTeam);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForConference() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		// title string field allow 255 characters
		inputSportsTeam
				.setConference("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		sportsTeamClient.create(inputSportsTeam);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForDivision() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		// title string field allow 255 characters
		inputSportsTeam
				.setDivision("Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Length validation for title Leng");
		sportsTeamClient.create(inputSportsTeam);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testLengthValidationForVenue() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();
		// title string field allow 75 characters
		inputSportsTeam.setVenue("Venue validation Venue validation Venue validation Venue validation Venue va");
		assertEquals(inputSportsTeam.getVenue().length(), 76);
		sportsTeamClient.create(inputSportsTeam);
	}
	// SKIP GENDER & SPORTSTYPE from length validation because there are valid
	// values
}
