package com.theplatform.data.tv.entity.integration.test.endpoint.awardassociation;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import com.theplatform.data.tv.entity.api.data.objects.AwardStatus;
import com.theplatform.data.tv.entity.api.data.objects.AwardType;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * GreenBuild test for validation of AwardAssociation
 * 
 * @author clai200
 * 
 */
@Test(groups = { "awardAssociation", "validation" })
public class AwardAssociationValidationIT extends EntityTestBase {



	/**
	 * Test of data validation during AwardAssociation creation with valid
	 * content and person id. All required fields have valid value including a
	 * person id. All optional fields have all null value.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreationSucceedWithPersonId() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription(null);
		input.setYear(new Integer(1980));
		input.setAwardStatus(AwardStatus.Winner.getFriendlyName());
		input.setAwardType(AwardType.Person.getFriendlyName());

		Award award = this.awardFactory.create();
		this.awardClient.create(award);
		input.setAwardId(award.getId());

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);
		input.setInstitutionId(institution.getId());

		Person person = this.personFactory.create();
		this.personClient.create(person);
		input.setPersonId(person.getId());

		input.setProgramId(null);

		input.setAwardShowId(null);

		this.awardAssociationClient.create(input);

	}

	/**
	 * Test of data validation during AwardAssociation creation with valid
	 * content and program id. All required fields have valid value including a
	 * program id. All optional fields have all null value.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreationSucceedWithProgramId() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription(null);
		input.setYear(new Integer(1980));
		input.setAwardStatus(AwardStatus.Winner.getFriendlyName());
		input.setAwardType(AwardType.Program.getFriendlyName());

		Award award = this.awardFactory.create();
		this.awardClient.create(award);
		input.setAwardId(award.getId());

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);
		input.setInstitutionId(institution.getId());

		Program program = this.programFactory.create();
		this.programClient.create(program);
		input.setProgramId(program.getId());

		input.setPersonId(null);

		input.setAwardShowId(null);

		this.awardAssociationClient.create(input);

	}

	/**
	 * Test of data validation during AwardAssociation creation. An exception
	 * should be thrown due to invalid value in the required field "year"
	 */
	@Test(groups = TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreationWithoutYear() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription("Test description");
		input.setYear(null);
		input.setAwardStatus(AwardStatus.Winner.getFriendlyName());
		input.setAwardType(AwardType.Person.getFriendlyName());

		Award award = this.awardFactory.create();
		this.awardClient.create(award);
		input.setAwardId(award.getId());

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);
		input.setInstitutionId(institution.getId());

		Person person = this.personFactory.create();
		this.personClient.create(person);
		input.setPersonId(person.getId());

		input.setProgramId(null);

		Program awardShow = this.programFactory.create();
		this.programClient.create(awardShow);
		input.setAwardShowId(awardShow.getId());

		this.awardAssociationClient.create(input);

	}

	/**
	 * Test of data validation during AwardAssociation creation. An exception
	 * should be thrown due to invalid value in the required field "awardStatus"
	 */
	@Test(groups = TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreationWithoutAwardStatus() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription("Test description");
		input.setYear(new Integer(1980));
		input.setAwardStatus(null);
		input.setAwardType(AwardType.Person.getFriendlyName());

		Award award = this.awardFactory.create();
		this.awardClient.create(award);
		input.setAwardId(award.getId());

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);
		input.setInstitutionId(institution.getId());

		Person person = this.personFactory.create();
		this.personClient.create(person);
		input.setPersonId(person.getId());

		input.setProgramId(null);

		Program awardShow = this.programFactory.create();
		this.programClient.create(awardShow);
		input.setAwardShowId(awardShow.getId());

		this.awardAssociationClient.create(input);

	}

	/**
	 * Test of data validation during AwardAssociation creation. An exception
	 * should be thrown due to invalid value in the required field "awardType"
	 */
	@Test(groups = TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreationWithoutAwardType() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription("Test description");
		input.setYear(new Integer(1980));
		input.setAwardStatus(AwardStatus.Winner.getFriendlyName());
		input.setAwardType(null);

		Award award = this.awardFactory.create();
		this.awardClient.create(award);
		input.setAwardId(award.getId());

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);
		input.setInstitutionId(institution.getId());

		Person person = this.personFactory.create();
		this.personClient.create(person);
		input.setPersonId(person.getId());

		input.setProgramId(null);

		Program awardShow = this.programFactory.create();
		this.programClient.create(awardShow);
		input.setAwardShowId(awardShow.getId());

		this.awardAssociationClient.create(input);

	}

	/**
	 * Test of data validation during AwardAssociation creation. An exception
	 * should be thrown due to lack of required field "institutionId"
	 */
	@Test(groups = TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreationWithoutInstitutionId() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription("Test description");
		input.setYear(new Integer(1980));
		input.setAwardStatus(AwardStatus.Winner.getFriendlyName());
		input.setAwardType(AwardType.Person.getFriendlyName());

		Award award = this.awardFactory.create();
		this.awardClient.create(award);
		input.setAwardId(award.getId());

		input.setInstitutionId(null);

		Person person = this.personFactory.create();
		this.personClient.create(person);
		input.setPersonId(person.getId());

		input.setProgramId(null);

		Program awardShow = this.programFactory.create();
		this.programClient.create(awardShow);
		input.setAwardShowId(awardShow.getId());

		this.awardAssociationClient.create(input);

	}

	/**
	 * Test of data validation during AwardAssociation creation. An exception
	 * should be thrown due to lack of the required field "awardId"
	 */
	@Test(groups = TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreationWithoutAwardId() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription("Test description");
		input.setYear(new Integer(1980));
		input.setAwardStatus(AwardStatus.Winner.getFriendlyName());
		input.setAwardType(AwardType.Person.getFriendlyName());

		input.setAwardId(null);

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);
		input.setInstitutionId(institution.getId());

		Person person = this.personFactory.create();
		this.personClient.create(person);
		input.setPersonId(person.getId());

		input.setProgramId(null);

		Program awardShow = this.programFactory.create();
		this.programClient.create(awardShow);
		input.setAwardShowId(awardShow.getId());

		this.awardAssociationClient.create(input);

	}

	/**
	 * Test of data validation during AwardAssociation creation. An exception
	 * should be thrown. Person id and program id should be mutually exclusive.
	 */
	// TODO MERLIN-XXXX no exception thrown
	@Test(groups = { TestGroup.testBug }, expectedExceptions = ValidationException.class)
	public void testCreationWithBothPersonIdAndProgramIdAndPersonAwardType() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription("Test description");
		input.setYear(new Integer(1980));
		input.setAwardStatus(AwardStatus.Winner.getFriendlyName());
		input.setAwardType(AwardType.Person.getFriendlyName());

		Award award = this.awardFactory.create();
		this.awardClient.create(award);
		input.setAwardId(award.getId());

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);
		input.setInstitutionId(institution.getId());

		Person person = this.personFactory.create();
		this.personClient.create(person);
		input.setPersonId(person.getId());

		Program program = this.programFactory.create();
		this.programClient.create(program);
		input.setProgramId(program.getId());

		Program awardShow = this.programFactory.create();
		this.programClient.create(awardShow);
		input.setAwardShowId(awardShow.getId());

		this.awardAssociationClient.create(input);

	}

	/**
	 * Test of data validation during AwardAssociation creation. An exception
	 * should be thrown due to trying to create an award association with person
	 * award type without person id but with program id.
	 */
	@Test(groups =TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreationWithoutPersonIdAndWithProgramIdAndPersonAwardType() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription("Test description");
		input.setYear(new Integer(1980));
		input.setAwardStatus(AwardStatus.Winner.getFriendlyName());
		input.setAwardType(AwardType.Person.getFriendlyName());

		Award award = this.awardFactory.create();
		this.awardClient.create(award);
		input.setAwardId(award.getId());

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);
		input.setInstitutionId(institution.getId());

		input.setPersonId(null);

		Program program = this.programFactory.create();
		this.programClient.create(program);
		input.setProgramId(program.getId());

		Program awardShow = this.programFactory.create();
		this.programClient.create(awardShow);
		input.setAwardShowId(awardShow.getId());

		this.awardAssociationClient.create(input);

	}

	/**
	 * Test of data validation during AwardAssociation creation. An exception
	 * should be thrown due to trying to create an award association with
	 * program award type without program id but with person id.
	 */
	@Test(groups = TestGroup.gbTest, expectedExceptions = ValidationException.class)
	public void testCreationWithoutProgramIdAndWithPersonIdAndProgramAwardType() {
		AwardAssociation input = this.awardAssociationFactory.create();

		input.setDescription("Test description");
		input.setYear(new Integer(1980));
		input.setAwardStatus(AwardStatus.Winner.getFriendlyName());
		input.setAwardType(AwardType.Program.getFriendlyName());

		Award award = this.awardFactory.create();
		this.awardClient.create(award);
		input.setAwardId(award.getId());

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);
		input.setInstitutionId(institution.getId());

		Person person = this.personFactory.create();
		this.personClient.create(person);
		input.setPersonId(person.getId());

		input.setProgramId(null);

		Program awardShow = this.programFactory.create();
		this.programClient.create(awardShow);
		input.setAwardShowId(awardShow.getId());

		this.awardAssociationClient.create(input);

	}

}
