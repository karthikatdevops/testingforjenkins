package com.theplatform.data.tv.entity.integration.test.endpoint;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.Review;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;
import com.theplatform.media.api.data.objects.Rating;

/**
 * 
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest })
public class CollectionFieldIT extends EntityTestBase {

	public void testAllEndpointsPostEmptyCollectionField() {

		Person person = this.personFactory.create();
		person.setAliases(new ArrayList<String>());
		personClient.create(person);

		Program program = this.programFactory.create();
		program.setContentRatings(new ArrayList<Rating>());
		this.programClient.create(program);

		Review review = this.reviewFactory.create();
		review.setContentRatings(new ArrayList<Rating>());
		this.reviewClient.create(review);

		EntityCollection entityCollection = this.entityCollectionFactory.create();
		entityCollection.setEntityIds(new ArrayList<URI>());
		entityCollection.setPrimaryEntities(new HashMap<String, URI>());
		this.entityCollectionClient.create(entityCollection);

		ImageAssociation imageAssociation = this.imageAssociationFactory.create();
		imageAssociation.setPreferForMainImageTypeIds(new ArrayList<URI>());
		this.imageAssociationClient.create(imageAssociation);

	}

	public void testAllEndpointsPostNullCollectionField() {

		Person person = this.personFactory.create();
		person.setAliases(null);
		Assert.assertNotNull(personClient.create(person, new String[] {}).getAliases());

		Program program = this.programFactory.create();
		program.setContentRatings(null);
		Assert.assertNotNull(this.programClient.create(program, new String[] {}).getContentRatings());

		Review review = this.reviewFactory.create();
		review.setContentRatings(new ArrayList<Rating>());
		Assert.assertNotNull(this.reviewClient.create(review, new String[] {}).getContentRatings());

		EntityCollection entityCollection = this.entityCollectionFactory.create();
		entityCollection.setEntityIds(null);
		entityCollection.setPrimaryEntities(null);
		EntityCollection returnedEntityCollection = this.entityCollectionClient.create(entityCollection, new String[] {});
		Assert.assertNotNull(returnedEntityCollection.getEntityIds());
		Assert.assertNotNull(returnedEntityCollection.getPrimaryEntities());

		ImageAssociation imageAssociation = this.imageAssociationFactory.create();
		imageAssociation.setPreferForMainImageTypeIds(null);
		Assert.assertNotNull(this.imageAssociationClient.create(imageAssociation, new String[] {}));

	}

}
