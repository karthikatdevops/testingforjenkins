package com.theplatform.data.tv.entity.integration.test.endpoint.institution;

import static org.testng.Assert.assertEquals;

import java.util.List;

import com.theplatform.data.api.client.query.ByTitlePrefix;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.test.InstitutionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * GreenBuild test of query of Institution
 * 
 * @author clai200
 * @since 4/7/2011
 * 
 */
public class InstitutionQueryIT extends EntityTestBase {



	@Test(groups = { TestGroup.gbTest })
	public void testQueryInstitutionByTitleOneFound() {
		List<Institution> inputInstitutions = this.institutionFactory.create(3);
		inputInstitutions.get(1).setTitle("Title1");
		this.institutionClient.create(inputInstitutions);
		Query queries[] = new Query[] { new ByTitle(inputInstitutions.get(1).getTitle()) };
		Feed<Institution> retrievedInstitutions = this.institutionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedInstitutions.getEntries().size(), 1, "No record found using query byTitle");
		InstitutionComparator.assertEquals(retrievedInstitutions.getEntries().get(0), inputInstitutions.get(1));
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testQueryInstitutionByTitleNoneFound() {
		// TODO to be implemented

	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testQueryInstitutionByTitleMultipleFound() {
		// TODO to be implemented

	}

	@Test(groups = { TestGroup.gbTest })
	public void testQueryInstitutionByTitlePrefixOneFound() {
		List<Institution> inputInstitutions = this.institutionFactory.create(3);
        inputInstitutions.get(0).setTitle("OtherTitle0");
        inputInstitutions.get(1).setTitle("Title1");
        inputInstitutions.get(2).setTitle("OtherTitle1");
		this.institutionClient.create(inputInstitutions);
		Query queries[] = new Query[] { new ByTitlePrefix(inputInstitutions.get(1).getTitle().substring(0, 2)) };
		Feed<Institution> retrievedInstitutions = this.institutionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedInstitutions.getEntries().size(), 1, "No record found using query byTitlePrefix");
		InstitutionComparator.assertEquals(retrievedInstitutions.getEntries().get(0), inputInstitutions.get(1));
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testQueryInstitutionByTitlePrefixNoneFound() {
		// TODO to be implemented

	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testQueryInstitutionByTitlePrefixMultipleFound() {
		// TODO to be implemented

	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testQueryInstitutionByTitleAndByTitlePrefixOneFound() {
		// TODO to be implemented

	}

	@Test(groups = { TestGroup.gbTest })
	public void testQueryInstitutionByTitleAndByTitlePrefixNoneFound() {
		// TODO to be implemented

	}

	@Test(groups = { TestGroup.gbTest })
	public void testQueryInstitutionByTitleAndByTitlePrefixMultipleFound() {
		// TODO to be implemented

	}

}
