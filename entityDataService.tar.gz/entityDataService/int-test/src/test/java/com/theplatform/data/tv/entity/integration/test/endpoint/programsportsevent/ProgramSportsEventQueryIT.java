package com.theplatform.data.tv.entity.integration.test.endpoint.programsportsevent;

import static org.testng.Assert.assertEquals;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.entity.api.client.query.programsportsevent.ByProgramId;
import com.theplatform.data.tv.entity.api.client.query.programsportsevent.BySportsEventId;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import com.theplatform.data.tv.entity.api.test.ProgramSportsEventComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * @since 4/7/2011
 */

@Test(groups = { "programSportsEvent", "query" })
public class ProgramSportsEventQueryIT extends EntityTestBase {

	// Merlin-1323
	@Test(groups = { TestGroup.gbTest })
	public void testQueryProgramSportsEventByProgramId() throws UnknownHostException {
		List<ProgramSportsEvent> inputProgramSportsEvents = this.programSportsEventFactory.create(6);
		this.programSportsEventClient.create(inputProgramSportsEvents);
		List<Long> programIds = new ArrayList<>();
		programIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(1).getProgramId()));
		programIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(2).getProgramId()));
		Query queries[] = new Query[] { new ByProgramId(programIds) };
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<ProgramSportsEvent> retrievedProgramSportsEvent = this.programSportsEventClient.getAll(null, queries, sorts, null, true);
		assertEquals(retrievedProgramSportsEvent.getEntries().size(), 2, "Not getting ProgramSportsEvents size using query byProgramId");
		assertEquals(retrievedProgramSportsEvent.getEntryCount().longValue(), 2, "Not getting ProgramSportsEvents entry count using query byProgramId");
		assertEquals(retrievedProgramSportsEvent.getTotalResults().longValue(), 2, "Not getting ProgramSportsEvents total results using query byProgramId");
		ProgramSportsEventComparator.assertEquals(retrievedProgramSportsEvent.getEntries().get(0), inputProgramSportsEvents.get(1));
		ProgramSportsEventComparator.assertEquals(retrievedProgramSportsEvent.getEntries().get(1), inputProgramSportsEvents.get(2));
	}

	// Merlin-1322
	@Test(groups = { TestGroup.gbTest })
	public void testQueryProgramSportsEventBySportsEventId() throws UnknownHostException {
		List<ProgramSportsEvent> inputProgramSportsEvents = this.programSportsEventFactory.create(3);
		List<Long> sportsEventIds = new ArrayList<>();
		sportsEventIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(0).getSportsEventId()));
		sportsEventIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(2).getSportsEventId()));
		this.programSportsEventClient.create(inputProgramSportsEvents);
		Query queries[] = new Query[] { new BySportsEventId(sportsEventIds) };
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<ProgramSportsEvent> retrievedProgramSportsEvents = this.programSportsEventClient.getAll(null, queries, sorts, null, true);
		assertEquals(retrievedProgramSportsEvents.getEntries().size(), 2, "Not getting ProgramSportsEvents size using query bySportsEventId");
		assertEquals(retrievedProgramSportsEvents.getEntryCount().longValue(), 2, "Not getting ProgramSportsEvents entry count using query bySportsEventId");
		assertEquals(retrievedProgramSportsEvents.getTotalResults().longValue(), 2, "Not getting ProgramSportsEvents total results using query bySportsEventId");
		ProgramSportsEventComparator.assertEquals(retrievedProgramSportsEvents.getEntries().get(0), inputProgramSportsEvents.get(0));
		ProgramSportsEventComparator.assertEquals(retrievedProgramSportsEvents.getEntries().get(1), inputProgramSportsEvents.get(2));
	}

	// Merlin-1321
	@Test(groups = { "other" })
	public void testQueryProgramSportsEventByAllQueryCombination() throws UnknownHostException {
		List<ProgramSportsEvent> inputProgramSportsEvents = this.programSportsEventFactory.create(6);

		this.programSportsEventClient.create(inputProgramSportsEvents);

		List<Long> sportsEventIds = new ArrayList<>();
		sportsEventIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(0).getSportsEventId()));
		sportsEventIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(2).getSportsEventId()));
		sportsEventIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(3).getSportsEventId()));

		List<Long> programIds = new ArrayList<>();
		programIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(0).getProgramId()));
		programIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(2).getProgramId()));
		programIds.add(LocalUriConverter.convertUriToID(inputProgramSportsEvents.get(3).getProgramId()));

		Query queries[] = new Query[] { new BySportsEventId(sportsEventIds), new ByProgramId(programIds) };

		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<ProgramSportsEvent> retrievedProgramSportsEvents = this.programSportsEventClient.getAll(null, queries, sorts, null, true);
		assertEquals(retrievedProgramSportsEvents.getEntries().size(), 3, "Not get all ProgramSportsEvents feed size using query combination");
		assertEquals(retrievedProgramSportsEvents.getEntryCount().longValue(), 3, "Not get all ProgramSportsEvents entry count using query combination");
		assertEquals(retrievedProgramSportsEvents.getTotalResults().longValue(), 3, "Not get all ProgramSportsEvents total results using query combination");

		// to make comparison for all fields
		ProgramSportsEventComparator.assertEquals(retrievedProgramSportsEvents.getEntries().get(0), inputProgramSportsEvents.get(0));
		ProgramSportsEventComparator.assertEquals(retrievedProgramSportsEvents.getEntries().get(1), inputProgramSportsEvents.get(2));
		ProgramSportsEventComparator.assertEquals(retrievedProgramSportsEvents.getEntries().get(2), inputProgramSportsEvents.get(3));
	}
}
