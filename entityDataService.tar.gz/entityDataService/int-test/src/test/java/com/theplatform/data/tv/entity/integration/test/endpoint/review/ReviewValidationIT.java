package com.theplatform.data.tv.entity.integration.test.endpoint.review;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.entity.api.fields.ReviewField;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.OverrideField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Review;
import com.theplatform.data.tv.entity.api.test.ReviewComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author jethrolai
 * @since 11/04/2011
 */
@Test(groups = { "review", TestGroup.gbTest, "validation" })
public class ReviewValidationIT extends EntityTestBase {

	@Test(expectedExceptions = ValidationException.class)
	public void createReviewNullProgramId() throws Exception {

		Review entity = this.reviewFactory.create(new DataServiceField(ReviewField.programId, (URI) null), new DataServiceField(ReviewField.provider, "fiji"));

		this.reviewClient.create(entity);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void createReviewNullProvider() throws Exception {

		Review entity = this.reviewFactory.create(new DataServiceField(ReviewField.provider, null));

		this.reviewClient.create(entity);
	}

	public void createReviewNullContentRatings() throws Exception {

		Review entity = this.reviewFactory.create(new DataServiceField(ReviewField.contentRatings, null));

		this.reviewClient.create(entity);
	}

	public void createReviewEmptyContentRatings() throws Exception {
		Review entity = this.reviewFactory.create(new DataServiceField(ReviewField.contentRatings, new ArrayList<Rating>()));
		this.reviewClient.create(entity);
	}

	@Test(dataProvider = "validContentRatingSchemes")
	public void createReviewNonNullValidSchemeContentRatings(String scheme, String ratingString) throws Exception {

		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating rating = new Rating();
		rating.setScheme(scheme);
		rating.setRating(ratingString);

		contentRatings.add(rating);

		Review entity = this.reviewFactory.create(new DataServiceField(ReviewField.contentRatings, contentRatings));

		Review returnedEntity = this.reviewClient.create(entity, (String[]) null);
		ReviewComparator.assertEquals(returnedEntity, entity);

	}

	@DataProvider
	public Object[][] validContentRatingSchemes() {
		List<Object[]> argumentList = new ArrayList<Object[]>();

		argumentList.add(new Object[] { "urn:mpaa", "R" });
		argumentList.add(new Object[] { "urn:v-chip", "TVG" });
		argumentList.add(new Object[] { "urn:csm", "notForKids=0,targetAge=6,offAge=4,onAge=6,rating=on" });
		argumentList
				.add(new Object[] { "urn:rt",
						"criticSummaryScore=40,criticSummaryCount=167,criticSummaryCertified=false,criticSummaryRotten=true,fanSummaryScore=64,fanSummaryCount=30348" });

		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	@Test(dataProvider = "invalidContentRatingSchemes", expectedExceptions = ValidationException.class)
	public void createReviewInvalidRatinghScheme(String scheme, String ratingString) throws Exception {

		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating rating = new Rating();
		rating.setScheme(scheme);
		rating.setRating(ratingString);

		contentRatings.add(rating);

		Review entity = this.reviewFactory.create(new DataServiceField(ReviewField.contentRatings, contentRatings));

		this.reviewClient.create(entity, (String[]) null);

	}

	@DataProvider
	public Object[][] invalidContentRatingSchemes() {
		List<Object[]> argumentList = new ArrayList<Object[]>();

		argumentList.add(new Object[] { "urn:mpaaa", "R" });
		argumentList.add(new Object[] { "urn:v-chipa", "TVG" });
		argumentList.add(new Object[] { "urn:csma", "notForKids=0,targetAge=6,offAge=4,onAge=6,rating=on" });
		argumentList.add(new Object[] { "", "R" });
		argumentList.add(new Object[] { "urn:csm", null });
		argumentList.add(new Object[] { "urn:csm", "R" });
		argumentList.add(new Object[] { "urn:csm", "" });

		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	@Test(dataProvider = "invalidRtContentRatingValues", expectedExceptions = ValidationException.class)
	public void createReviewInvalidRTContentRatingValue(String invalidRtContentRatingValue) throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating rating = new Rating();
		rating.setScheme("urn:rt");
		rating.setRating(invalidRtContentRatingValue);

		contentRatings.add(rating);

		Review entity = this.reviewFactory.create(new DataServiceField(ReviewField.contentRatings, contentRatings));

		this.reviewClient.create(entity, (String[]) null);
	}

	@DataProvider
	public Object[][] invalidRtContentRatingValues() {
		List<Object[]> argumentList = new ArrayList<Object[]>();

		// Missing criticSummaryScore
		argumentList
				.add(new Object[] { "criticSummaryCount=167,criticSummaryCertified=false,criticSummaryRotten=true,fanSummaryScore=64,fanSummaryCount=30348" });
		// // Missing criticSummaryScoreValue
		// argumentList
		// .add(new Object[] {
		// "criticSummaryScore=,criticSummaryCount=167,criticSummaryCertified=false,criticSummaryRotten=true,fanSummaryScore=64,fanSummaryCount=30348"
		// });
		// Missing criticSummaryCount
		argumentList
				.add(new Object[] { "criticSummaryScore=40,criticSummaryCertified=false,criticSummaryRotten=true,fanSummaryScore=64,fanSummaryCount=30348" });
		// Missing criticSummaryCount value
		// argumentList
		// .add(new Object[] {
		// "criticSummaryScore=40,criticSummaryCount=,criticSummaryCertified=false,criticSummaryRotten=true,fanSummaryScore=64,fanSummaryCount=30348"
		// });
		// Missing criticSummaryCertified,
		argumentList.add(new Object[] { "criticSummaryScore=40,criticSummaryCount=167,criticSummaryRotten=true,fanSummaryScore=64,fanSummaryCount=30348" });
		// Missing criticSummaryCertified value
		// argumentList
		// .add(new Object[] {
		// "criticSummaryScore=40,criticSummaryCount=167,criticSummaryCertified=,criticSummaryRotten=true,fanSummaryScore=64,fanSummaryCount=30348"
		// });
		// Missing criticSummaryRotten
		argumentList.add(new Object[] { "criticSummaryScore=40,criticSummaryCount=167,criticSummaryCertified=false,fanSummaryScore=64,fanSummaryCount=30348" });
		// Missing criticSummaryRotten value
		// argumentList
		// .add(new Object[] {
		// "criticSummaryScore=40,criticSummaryCount=167,criticSummaryCertified=false,criticSummaryRotten=,fanSummaryScore=64,fanSummaryCount=30348"
		// });
		// Missing fanSummaryScore
		argumentList
				.add(new Object[] { "criticSummaryScore=40,criticSummaryCount=167,criticSummaryCertified=false,criticSummaryRotten=true,fanSummaryCount=30348" });
		// Missing fanSummaryScore value
		// argumentList
		// .add(new Object[] {
		// "criticSummaryScore=40,criticSummaryCount=167,criticSummaryCertified=false,criticSummaryRotten=true,fanSummaryScore=,fanSummaryCount=30348"
		// });
		// Missing fanSummaryCount
		argumentList.add(new Object[] { "criticSummaryScore=40,criticSummaryCount=167,criticSummaryCertified=false,criticSummaryRotten=true" });
		// Missing fanSummaryCount value
		// argumentList
		// .add(new Object[] {
		// "criticSummaryScore=40,criticSummaryCount=167,criticSummaryCertified=false,criticSummaryRotten=true,fanSummaryScore=64,fanSummaryCount="
		// });

		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

}
