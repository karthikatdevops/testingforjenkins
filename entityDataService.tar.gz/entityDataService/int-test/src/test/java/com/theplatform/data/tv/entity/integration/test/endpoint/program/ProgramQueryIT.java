package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.program.ByIdSuffix;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = TestGroup.gbTest)
public class ProgramQueryIT extends EntityTestBase {

	public void testProgramQueryByIdSuffixNoMatch() {

		final URI programId1 = this.programClient.create(
				this.programFactory.create(new DataServiceField(DataObjectField.id, URI.create(this.getBaseUrl().concat(
						"/data/Program/" + (this.objectIdProvider.nextId()+1)))))).getId();
		final URI programId2 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+2)));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId2));

		Query[] queries = new Query[] { new ByIdSuffix(URIUtils.getIdSuffix(programId2)) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Program should be found");
	}

	public void testProgramQueryByIdSuffixListNoMatch() {
		final URI programId1 = this.programClient.create(
				this.programFactory.create(new DataServiceField(DataObjectField.id, URI.create(this.getBaseUrl().concat(
						"/data/Program/" + (this.objectIdProvider.nextId()+1)))))).getId();
		final URI programId2 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+2)));
		final URI programId3 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+3)));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId2));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId2), URIUtils.getIdSuffix(programId3));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId3));

		Query[] queries = new Query[] { new ByIdSuffix(Arrays.asList(URIUtils.getIdSuffix(programId2), URIUtils.getIdSuffix(programId3))) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Program should be found");
	}

	public void testProgramQueryByIdSuffixOneMatch() {

		final URI programId1 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+1)));
		final URI programId2 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+2)));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId2));
		this.programClient.create(this.programFactory.create(new DataServiceField(DataObjectField.id, programId1)));

		Program expectedProgram = this.programClient.create(this.programFactory.create(new DataServiceField(DataObjectField.id, programId2)),
				new String[] {});
		Query[] queries = new Query[] { new ByIdSuffix(URIUtils.getIdSuffix(programId2)) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Program should be found");

		ProgramComparator.assertEquals(results.getEntries().get(0), expectedProgram);
	}

	public void testProgramQueryByIdSuffixListOneMatch() {

		final URI programId1 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+1)));
		final URI programId2 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+2)));
		final URI programId3 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+3)));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId2));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId2), URIUtils.getIdSuffix(programId3));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId3));

		this.programClient.create(this.programFactory.create(new DataServiceField(DataObjectField.id, programId1)));

		Program expectedProgram = this.programClient.create(this.programFactory.create(new DataServiceField(DataObjectField.id, programId2)),
				new String[] {});
		Query[] queries = new Query[] { new ByIdSuffix(Arrays.asList(URIUtils.getIdSuffix(programId2), URIUtils.getIdSuffix(programId3))) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Program should be found");

		ProgramComparator.assertEquals(results.getEntries().get(0), expectedProgram);
	}

	public void testProgramQueryByIdSuffixMultipleMatch() {

		final Long id = this.objectIdProvider.nextId();
		final URI programId1 = URI.create(this.getBaseUrl().concat("/data/Program/" + id));
		final URI programId2 = URI.create(this.getBaseUrl().concat("/data/Program/" + (9000000000000000l + id)));
		Assert.assertNotEquals(URIUtils.getIdValue(programId1), URIUtils.getIdValue(programId2));
		Assert.assertEquals(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId2));

		Program program1 = this.programClient.create(this.programFactory.create(new DataServiceField(DataObjectField.id, programId1)), new String[] {});
		Program program2 = this.programClient.create(this.programFactory.create(new DataServiceField(DataObjectField.id, programId2)), new String[] {});

		Query[] queries = new Query[] { new ByIdSuffix(URIUtils.getIdSuffix(programId1)) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Programs should be found");

		Map<URI, Program> resultMap = new HashMap<>();
		for (Program Program : results.getEntries())
			resultMap.put(Program.getId(), Program);

		ProgramComparator.assertEquals(resultMap.get(program1.getId()), program1);
		ProgramComparator.assertEquals(resultMap.get(program2.getId()), program2);
	}

	public void testProgramQueryByIdSuffixListMultipleMatch() {

		final URI programId1 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+1)));
		final URI programId2 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+2)));
		final URI programId3 = URI.create(this.getBaseUrl().concat("/data/Program/" + (this.objectIdProvider.nextId()+3)));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId2));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId2), URIUtils.getIdSuffix(programId3));
		Assert.assertNotEquals(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId3));

		Program program1 = this.programClient.create(this.programFactory.create(new DataServiceField(DataObjectField.id, programId1)), new String[] {});
		Program program2 = this.programClient.create(this.programFactory.create(new DataServiceField(DataObjectField.id, programId2)), new String[] {});
		this.programClient.create(this.programFactory.create(new DataServiceField(DataObjectField.id, programId3)));

		Query[] queries = new Query[] { new ByIdSuffix(Arrays.asList(URIUtils.getIdSuffix(programId1), URIUtils.getIdSuffix(programId2))) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Programs should be found");

		Map<URI, Program> resultMap = new HashMap<>();
		for (Program Program : results.getEntries())
			resultMap.put(Program.getId(), Program);

		ProgramComparator.assertEquals(resultMap.get(program1.getId()), program1);
		ProgramComparator.assertEquals(resultMap.get(program2.getId()), program2);
	}
}
