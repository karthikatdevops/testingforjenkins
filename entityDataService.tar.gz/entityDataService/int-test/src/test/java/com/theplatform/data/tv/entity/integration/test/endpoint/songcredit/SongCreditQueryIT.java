package com.theplatform.data.tv.entity.integration.test.endpoint.songcredit;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.tv.entity.api.fields.SongCreditField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.songcredit.ByActive;
import com.theplatform.data.tv.entity.api.client.query.songcredit.ByPersonId;
import com.theplatform.data.tv.entity.api.client.query.songcredit.BySongId;
import com.theplatform.data.tv.entity.api.client.query.songcredit.ByType;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;
import com.theplatform.data.tv.entity.api.test.SongCreditComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "songCredit", "query" })
public class SongCreditQueryIT extends EntityTestBase {

	public void testSongCreditQueryBySongIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.songId, songClient.create(songFactory.create()).getId())));
		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songClient.create(songFactory.create()).getId())) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCredit should be found");
	}

	public void testSongCreditQueryBySongIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI songId = songClient.create(songFactory.create()).getId();
		SongCredit expected = this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.songId, songId)), new String[] {});
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.songId, songClient.create(songFactory.create()).getId())));

		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCredit should be found");

		SongCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongCreditQueryBySongIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId = songClient.create(songFactory.create()).getId();
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.songId, songClient.create(songFactory.create()).getId())));

		List<SongCredit> expectedSongCredits = this.songCreditClient.create(this.songCreditFactory.create(2, new DataServiceField(SongCreditField.songId, songId)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCredits should be found");

		Map<URI, SongCredit> resultMap = new HashMap<>();
		for (SongCredit songCredit : results.getEntries())
			resultMap.put(songCredit.getId(), songCredit);

		for (SongCredit expected : expectedSongCredits)
			SongCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testSongCreditQueryByPersonIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.personId, personClient.create(personFactory.create()).getId())));
		Query[] queries = new Query[] { new ByPersonId(URIUtils.getIdValue(personClient.create(personFactory.create()).getId())) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCredit should be found");
	}

	public void testSongCreditQueryByPersonIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI personId = personClient.create(personFactory.create()).getId();
		SongCredit expected = this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.personId, personId)), new String[] {});
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.personId, personClient.create(personFactory.create()).getId())));

		Query[] queries = new Query[] { new ByPersonId(URIUtils.getIdValue(personId)) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCredit should be found");

		SongCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongCreditQueryByPersonIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI personId = personClient.create(personFactory.create()).getId();
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.personId, personClient.create(personFactory.create()).getId())));

		List<SongCredit> expectedSongCredits = this.songCreditClient.create(this.songCreditFactory.create(2, new DataServiceField(SongCreditField.personId, personId)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByPersonId(URIUtils.getIdValue(personId)) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCredits should be found");

		Map<URI, SongCredit> resultMap = new HashMap<>();
		for (SongCredit songCredit : results.getEntries()) {
			resultMap.put(songCredit.getId(), songCredit);
		}

		for (SongCredit expected : expectedSongCredits)
			SongCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testSongCreditQueryByTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.type, "Primary Artist")));
		Query[] queries = new Query[] { new ByType("Guest Artist") };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCredit should be found");
	}

	public void testSongCreditQueryByTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		SongCredit expected = this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.type, "Primary Artist")), new String[] {});
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.type, "Guest Artist")));

		Query[] queries = new Query[] { new ByType("Primary Artist") };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCredit should be found");

		SongCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongCreditQueryByTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.type, "Guest Artist")));
		List<SongCredit> expectedSongCredits = this.songCreditClient.create(
				this.songCreditFactory.create(2, new DataServiceField(SongCreditField.type, "Primary Artist")), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByType("Primary Artist") };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCredits should be found");

		Map<URI, SongCredit> resultMap = new HashMap<>();
		for (SongCredit songCredit : results.getEntries()) {
			resultMap.put(songCredit.getId(), songCredit);
		}

		for (SongCredit expected : expectedSongCredits)
			SongCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testSongCreditQueryByActiveNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.active, true)));
		Query[] queries = new Query[] { new ByActive(false) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCredit should be found");
	}

	public void testSongCreditQueryByActiveOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		SongCredit expected = this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.active, true)), new String[] {});
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.active, false)));

		Query[] queries = new Query[] { new ByActive(true) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCredit should be found");

		SongCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongCreditQueryByActiveMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.active, false)));
		List<SongCredit> expectedSongCredits = this.songCreditClient.create(this.songCreditFactory.create(2, new DataServiceField(SongCreditField.active, true)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByActive(true) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCredits should be found");

		Map<URI, SongCredit> resultMap = new HashMap<>();
		for (SongCredit songCredit : results.getEntries()) {
			resultMap.put(songCredit.getId(), songCredit);
		}

		for (SongCredit expected : expectedSongCredits)
			SongCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testSongCreditQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCredit should be found");
	}

	public void testSongCreditQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		SongCredit expected = this.songCreditClient.create(
				this.songCreditFactory.create(new DataServiceField(SongCreditField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {});
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.merlinResourceType, MerlinResourceType.Editorial)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCredit should be found");

		SongCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongCreditQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.merlinResourceType, MerlinResourceType.Editorial)));
		List<SongCredit> expectedSongCredits = this.songCreditClient.create(
				this.songCreditFactory.create(2, new DataServiceField(SongCreditField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {})
				.getEntries();
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<SongCredit> results = this.songCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCredits should be found");

		Map<URI, SongCredit> resultMap = new HashMap<>();
		for (SongCredit songCredit : results.getEntries()) {
			resultMap.put(songCredit.getId(), songCredit);
		}

		for (SongCredit expected : expectedSongCredits)
			SongCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

}
