package com.theplatform.data.tv.entity.integration.test.endpoint.person;

import static org.testng.Assert.assertEquals;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.OverrideField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.test.CreditAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author jethrolai
 * @since 01/22/2012
 */
@Test(groups = { "person", TestGroup.gbTest, "crud" })
public class PersonCreditsCRUDIT extends EntityTestBase {



	public void testPersonCreditsOnlyContainActiveCredits() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		// Create

        URI personId = this.personClient.create(this.personFactory.create()).getId();
        URI programId = this.programClient.create(this.programFactory.create()).getId();

		// Need to use null fields array or the credits are not returned (see
		// bug MERLIN-6723), can't use empty String array.
		// However, if we use null here, for the second request to Program
		// (PersonretrievedPersonAfterAddingCredits =
		// this.personClient.get(personId, null);)
		// will be returned from cache, which means the returned program will
		// not have any credit.
		// // Retrieve
		// Person retrievedPersonBeforeAddingCredits =
		// this.personClient.get(inputPerson.getId(), new String[]{});
		// assertEquals(retrievedPersonBeforeAddingCredits.getCredits().size(),
		// 0, "Person should have no Credit");

		List<Credit> credits = new ArrayList<Credit>();

		final int numberOfActiveCredits = 5;

		credits.addAll(this.creditFactory.create(numberOfActiveCredits, new DataServiceField(CreditField.personId, personId), new DataServiceField(CreditField.active, true)));
		credits.addAll(this.creditFactory.create(5, new DataServiceField(CreditField.personId, personId), new DataServiceField(CreditField.active, false)));

		Collections.shuffle(credits);
		this.creditClient.create(credits);
		Map<URI, Credit> creditMap = new HashMap<URI, Credit>();
		for (Credit credit : credits) {
			creditMap.put(credit.getId(), credit);
		}
		// Need to use null fields array or the credits are not returned (see
		// bug MERLIN-6723)
		Person retrievedPersonAfterAddingCredits = this.personClient.get(personId, null);
		assertEquals(retrievedPersonAfterAddingCredits.getCredits().size(), numberOfActiveCredits, "The person should have " + numberOfActiveCredits
				+ " active Credit but there are " + retrievedPersonAfterAddingCredits.getCredits().size());

		for (CreditAssociation credit : retrievedPersonAfterAddingCredits.getCredits()) {
			CreditAssociationComparator.assertEquals(credit,
					getInputCreditAssociation(creditMap.get(credit.getCreditId()), creditClient.get(credit.getCreditId(), null)));
		}

	}

	private CreditAssociation getInputCreditAssociation(Credit inputCredit, Credit retrievedCredit) {

		Program program = this.programClient.get(retrievedCredit.getProgramId(), null);
		CreditAssociation creditAssociation = new CreditAssociation();
		creditAssociation.setType(inputCredit.getType());
		creditAssociation.setPartName(inputCredit.getPartName());
		creditAssociation.setRank(inputCredit.getRank());
		creditAssociation.setCameo(inputCredit.getCameo());
		creditAssociation.setPersonId(inputCredit.getPersonId());
		creditAssociation.setProgramId(inputCredit.getProgramId());
		creditAssociation.setPersonName(retrievedCredit.getPerson().getName());
		creditAssociation.setProgramTitle(program.getTitle());
		creditAssociation.setCreditId(inputCredit.getId());
		creditAssociation.setProgramYear(program.getYear());
		return creditAssociation;
	}
}
