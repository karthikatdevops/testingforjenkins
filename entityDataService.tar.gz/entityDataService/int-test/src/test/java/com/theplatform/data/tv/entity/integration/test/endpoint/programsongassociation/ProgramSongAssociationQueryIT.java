package com.theplatform.data.tv.entity.integration.test.endpoint.programsongassociation;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.ProgramSongAssociationField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.programmediaassociation.ByProgramId;
import com.theplatform.data.tv.entity.api.client.query.programsongassociation.ByProgramType;
import com.theplatform.data.tv.entity.api.client.query.programsongassociation.BySongId;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.test.ProgramSongAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "programSongAssociation", "query" })
public class ProgramSongAssociationQueryIT extends EntityTestBase {

	public void testProgramSongAssociationQueryBySongIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.songId, songClient.create(
				songFactory.create()).getId())));
		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songClient.create(songFactory.create()).getId())) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramSongAssociation should be found");
	}

	public void testProgramSongAssociationQueryBySongIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI songId = songClient.create(songFactory.create()).getId();
		ProgramSongAssociation expected = this.programSongAssociationClient.create(
				this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.songId, songId)), new String[] {});
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.songId, songClient.create(
				songFactory.create()).getId())));

		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramSongAssociation should be found");

		ProgramSongAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testProgramSongAssociationQueryBySongIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId = songClient.create(songFactory.create()).getId();
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.songId, songClient.create(
				songFactory.create()).getId())));

		List<ProgramSongAssociation> expectedProgramSongAssociations = this.programSongAssociationClient.create(
				this.programSongAssociationFactory.create(2, new DataServiceField(ProgramSongAssociationField.songId, songId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramSongAssociations should be found");

		Map<URI, ProgramSongAssociation> resultMap = new HashMap<>();
		for (ProgramSongAssociation programSongAssociation : results.getEntries())
			resultMap.put(programSongAssociation.getId(), programSongAssociation);

		for (ProgramSongAssociation expected : expectedProgramSongAssociations)
			ProgramSongAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramSongAssociationQueryByProgramIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, programClient.create(
				programFactory.create()).getId())));
		Query[] queries = new Query[] { new ByProgramId(URIUtils.getIdValue(programClient.create(programFactory.create()).getId())) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramSongAssociation should be found");
	}

	public void testProgramSongAssociationQueryByProgramIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI programId = programClient.create(programFactory.create()).getId();
		ProgramSongAssociation expected = this.programSongAssociationClient.create(
				this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, programId)), new String[] {});
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, programClient.create(
				programFactory.create()).getId())));

		Query[] queries = new Query[] { new ByProgramId(URIUtils.getIdValue(programId)) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramSongAssociation should be found");

		ProgramSongAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testProgramSongAssociationQueryByProgramIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI programId = programClient.create(programFactory.create()).getId();
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, programClient.create(
				programFactory.create()).getId())));

		List<ProgramSongAssociation> expectedProgramSongAssociations = this.programSongAssociationClient.create(
				this.programSongAssociationFactory.create(2, new DataServiceField(ProgramSongAssociationField.programId, programId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByProgramId(URIUtils.getIdValue(programId)) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramSongAssociations should be found");

		Map<URI, ProgramSongAssociation> resultMap = new HashMap<>();
		for (ProgramSongAssociation programSongAssociation : results.getEntries())
			resultMap.put(programSongAssociation.getId(), programSongAssociation);

		for (ProgramSongAssociation expected : expectedProgramSongAssociations)
			ProgramSongAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramSongAssociationQueryByProgramTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, programClient.create(
                programFactory.create(new DataServiceField(ProgramField.type, ProgramType.MusicVideo))).getId())));
		Query[] queries = new Query[] { new ByProgramType(ProgramType.Concert) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramSongAssociation should be found");
	}

	public void testProgramSongAssociationQueryByProgramTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI programId = programClient.create(programFactory.create(new DataServiceField(ProgramField.type,ProgramType.MusicVideo))).getId();
		ProgramSongAssociation expected = this.programSongAssociationClient.create(
				this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, programId)), new String[] {});
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, programClient.create(
				programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Other))).getId())));

		Query[] queries = new Query[] { new ByProgramType(ProgramType.MusicVideo) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramSongAssociation should be found");

		ProgramSongAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testProgramSongAssociationQueryByProgramTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI programId = programClient.create(programFactory.create(new DataServiceField(ProgramField.type,ProgramType.MusicVideo))).getId();
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, programClient.create(
				programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Other))).getId())));

		List<ProgramSongAssociation> expectedProgramSongAssociations = this.programSongAssociationClient.create(
				this.programSongAssociationFactory.create(2, new DataServiceField(ProgramSongAssociationField.programId, programId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByProgramType(ProgramType.MusicVideo) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramSongAssociations should be found");

		Map<URI, ProgramSongAssociation> resultMap = new HashMap<>();
		for (ProgramSongAssociation programSongAssociation : results.getEntries())
			resultMap.put(programSongAssociation.getId(), programSongAssociation);

		for (ProgramSongAssociation expected : expectedProgramSongAssociations)
			ProgramSongAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramSongAssociationQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.merlinResourceType,
				MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramSongAssociation should be found");
	}

	public void testProgramSongAssociationQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		ProgramSongAssociation expected = this.programSongAssociationClient.create(
				this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {});
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.merlinResourceType,
				MerlinResourceType.Editorial)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramSongAssociation should be found");

		ProgramSongAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testProgramSongAssociationQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.merlinResourceType,
				MerlinResourceType.Editorial)));
		List<ProgramSongAssociation> expectedProgramSongAssociations = this.programSongAssociationClient
				.create(this.programSongAssociationFactory.create(2, new DataServiceField(ProgramSongAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
						new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<ProgramSongAssociation> results = this.programSongAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramSongAssociations should be found");

		Map<URI, ProgramSongAssociation> resultMap = new HashMap<>();
		for (ProgramSongAssociation programSongAssociation : results.getEntries()) {
			resultMap.put(programSongAssociation.getId(), programSongAssociation);
		}

		for (ProgramSongAssociation expected : expectedProgramSongAssociations)
			ProgramSongAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

}
