package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagetype;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.ImageCriteria;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.image.api.fields.MainImageTypeField;
import com.theplatform.data.tv.image.api.test.MainImageTypeComparator;

/**
 * Basic CRUD tests for Main Image Type
 * 
 * @since 4/7/2011
 * 
 * 
 */

@Test(groups = { "mainImageType", "crud" })
public class MainImageTypeCRUDIT extends EntityTestBase {



	@Test(groups = { TestGroup.gbTest })
	public void crudSingleMainImageType() throws UnknownHostException {
		MainImageType mainImageType = this.mainImageTypeFactory.create();

		// CREATE
		MainImageType persistedMainImageType = this.mainImageTypeClient.create(mainImageType, new String[] {});
		MainImageTypeComparator.assertEquals(persistedMainImageType, mainImageType);

		// RETRIEVE
		MainImageType retrievedMainImageType = this.mainImageTypeClient.get(mainImageType.getId(), new String[] {});
		MainImageTypeComparator.assertEquals(retrievedMainImageType, mainImageType);

		// UPDATE
		mainImageType.setEntityType(mainImageType.getEntityType().equals("Person") ? "Program" : "Person");
		mainImageType.setEntityQuery(mainImageType.getEntityQuery() != null && mainImageType.getEntityType().equals("Person") ? "Program" : "Person");
		mainImageType.setTitle(mainImageType.getTitle().concat(" updated"));
		mainImageType.setAlias(mainImageType.getAlias().concat(" updated"));
		mainImageType
				.setDescription(mainImageType.getDescription() != null && mainImageType.getDescription().equals("mainImageType description") ? mainImageType
						.getDescription().concat(" updated") : "mainImageType description");

		ImageCriteria imageCriteria = new ImageCriteria();
		imageCriteria.setRequireExclusive(true);
		imageCriteria.setRequireExclusiveByType(false);
		imageCriteria.setAllowImagesFromParent(false);
		imageCriteria.setAllowImagesFromCredits(true);
		imageCriteria.setMediaQuery("media query");
		imageCriteria.setContentQuery("content query");
		imageCriteria.setMediaFileQuery("media file query");
		imageCriteria.setImageAssociationRelationshipQuery("ia rel query");

		if (mainImageType.getImageCriteria() != null && mainImageType.getImageCriteria().size() > 0)
			mainImageType.getImageCriteria().add(imageCriteria);
		else
			mainImageType.setImageCriteria(Arrays.asList(imageCriteria));

		this.mainImageTypeClient.update(mainImageType);

		MainImageType retrievedAfterUpdate = this.mainImageTypeClient.get(mainImageType.getId(), new String[] {});
		MainImageTypeComparator.assertEquals(retrievedAfterUpdate, mainImageType);

		// DELETE
		long deletedObjects = this.mainImageTypeClient.delete(mainImageType.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.mainImageTypeClient.get(mainImageType.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("MainImageType should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudMainImageTypeFeed() throws UnknownHostException {
		List<MainImageType> mainImageTypes = this.mainImageTypeFactory.create(5);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] MainImageTypeIds = (URI[]) CollectionUtils.collect(mainImageTypes, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<MainImageType> persistedMainImageTypes = this.mainImageTypeClient.create(mainImageTypes);
		ComparatorUtils.assertIdsAreEqual(mainImageTypes, persistedMainImageTypes);

		// RETRIEVE
		Feed<MainImageType> retrievedMainImageTypes = this.mainImageTypeClient.get(MainImageTypeIds, new String[] {});
		MainImageTypeComparator.assertEquals(retrievedMainImageTypes, mainImageTypes);

		// DELETE
		long deletedMainImageTypes = this.mainImageTypeClient.delete(MainImageTypeIds);
		Assert.assertEquals(deletedMainImageTypes, mainImageTypes.size());

		long notFoundMainImageTypes = 0;
		for (MainImageType MainImageType : mainImageTypes) {
			try {
				this.mainImageTypeClient.get(MainImageType.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundMainImageTypes++;
			}
		}
		Assert.assertEquals(notFoundMainImageTypes, deletedMainImageTypes, "Still found MainImageTypes after deleting");
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] {

	new DataServiceField(MainImageTypeField.entityQuery, null), new DataServiceField(DataObjectField.description, null),
			new DataServiceField(MainImageTypeField.imageCriteria, new ArrayList<ImageCriteria>()),
			new DataServiceField(MainImageTypeField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testMainImageTypeCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(mainImageTypeClient, mainImageTypeFactory.create(), MainImageTypeComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testMainImageTypeCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(mainImageTypeClient, mainImageTypeFactory.create(), MainImageTypeComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testMainImageTypeUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(MainImageTypeField.entityQuery, "mainImageType entityQuery"));
		createValues.add(new DataServiceField(DataObjectField.description, "mainImageTypedescription"));
		createValues.add(new DataServiceField(MainImageTypeField.imageCriteria, Arrays.asList(imageCriteriaFactory.create())));
		createValues.add(new DataServiceField(MainImageTypeField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(mainImageTypeClient, mainImageTypeFactory.create(), MainImageTypeComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testMainImageTypeUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(MainImageTypeField.entityQuery, "mainImageType entityQuery"));
		createValues.add(new DataServiceField(DataObjectField.description, "mainImageTypedescription"));
		createValues.add(new DataServiceField(MainImageTypeField.imageCriteria, Arrays.asList(imageCriteriaFactory.create())));
		createValues.add(new DataServiceField(MainImageTypeField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(mainImageTypeClient, mainImageTypeFactory.create(), MainImageTypeComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

}
