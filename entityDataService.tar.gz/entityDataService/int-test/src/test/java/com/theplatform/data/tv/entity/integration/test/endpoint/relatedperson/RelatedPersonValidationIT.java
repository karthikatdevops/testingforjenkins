package com.theplatform.data.tv.entity.integration.test.endpoint.relatedperson;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.Date;

import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.fields.RelatedPersonField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "relatedPerson", "validation" })
public class RelatedPersonValidationIT extends EntityTestBase {

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedPersonCreateNullSourcePersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedPersonCreateNonpersistedSourcePersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, this.personFactory.create().getId())));
	}

	@Test(groups = TestGroup.testBug, expectedExceptions = ValidationException.class)
	public void testRelatedPersonCreateNonLocalSourcePersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localPersonId = this.personClient.create(this.personFactory.create()).getId();

		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, this.personFactory.create(
				new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9003/linearDataService/data/Person/" + URIUtils.getIdValue(localPersonId)))).getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedPersonCreateNullTargetPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.targetPersonId, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedPersonCreateNonpersistedTargetPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.targetPersonId, this.personFactory.create().getId())));
	}

	@Test(groups = TestGroup.testBug, expectedExceptions = ValidationException.class)
	// TODO waiting for implementation
	public void testRelatedPersonCreateNonLocalTargetPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localPersonId = this.personClient.create(this.personFactory.create()).getId();

		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.targetPersonId, this.personFactory.create(
				new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9003/linearDataService/data/Person/" + URIUtils.getIdValue(localPersonId)))).getId())));
	}

	// Type validation
	// TODO to be implemented

	// rank validation
	public void testRelatedPersonCreatePositiveRank() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.rank, 1)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedPersonCreateNegativeRank() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.rank, -1)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedPersonCreateZeroRank() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.rank, 0)));
	}

	// sourcePersonId, sourcePersonId, type startDate, endDate uniqueness
	//uniqueness constraint removed to allow editorial objects
	//@Test(expectedExceptions = ValidationException.class)
	public void testRelatedPersonCreateWithSameSourcePersonIdTargetPersonIdStartDateEndDateAndType() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final URI sourcePersonId = personClient.create(personFactory.create()).getId();
		final URI targetPersonId = personClient.create(personFactory.create()).getId();
		final Date startDate = new Date();
		final Date endDate = new Date();
		final String type = "influencedMusic";
		this.relatedPersonClient.create(this.relatedPersonFactory.create(2, new DataServiceField(RelatedPersonField.sourcePersonId, sourcePersonId), new DataServiceField(
				RelatedPersonField.targetPersonId, targetPersonId), new DataServiceField(RelatedPersonField.type, type), new DataServiceField(RelatedPersonField.startDate, startDate), new DataServiceField(
				RelatedPersonField.endDate, endDate)));
	}

	@Test(groups = TestGroup.testBug)
	public void testRelatedPersonCreateWithDifferentSourcePersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
	InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final URI targetPersonId = personClient.create(personFactory.create()).getId();
		final Date startDate = new Date();
		final Date endDate = new Date();
		final String type = "influencedMusic";
		this.relatedPersonClient.create(this.relatedPersonFactory.create(2,
				new DataServiceField(RelatedPersonField.sourcePersonId, this.personClient.create(personFactory.create()).getId()), new DataServiceField(RelatedPersonField.targetPersonId,
						targetPersonId), new DataServiceField(RelatedPersonField.type, type), new DataServiceField(RelatedPersonField.startDate, startDate), new DataServiceField(RelatedPersonField.endDate,
								endDate)));
	}
	
	@Test(groups = TestGroup.testBug)
	public void testRelatedPersonCreateWithDifferentTargetPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
	InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final URI sourcePersonId = personClient.create(personFactory.create()).getId();
		final Date startDate = new Date();
		final Date endDate = new Date();
		final String type = "influencedMusic";
		this.relatedPersonClient.create(this.relatedPersonFactory.create(2,
				new DataServiceField(RelatedPersonField.targetPersonId, this.personClient.create(personFactory.create()).getId()), new DataServiceField(RelatedPersonField.sourcePersonId,
						sourcePersonId), new DataServiceField(RelatedPersonField.type, type), new DataServiceField(RelatedPersonField.startDate, startDate), new DataServiceField(RelatedPersonField.endDate,
								endDate)));
	}

	public void testRelatedPersonCreateWithDifferentType() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final URI sourcePersonId = personClient.create(personFactory.create()).getId();
		final URI targetPersonId = personClient.create(personFactory.create()).getId();
		final Date startDate = new Date();
		final Date endDate = new Date();
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, sourcePersonId), new DataServiceField(
				RelatedPersonField.targetPersonId, targetPersonId), new DataServiceField(RelatedPersonField.type, "influencedMusic"), new DataServiceField(RelatedPersonField.startDate, startDate),
				new DataServiceField(RelatedPersonField.endDate, endDate)));
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, sourcePersonId), new DataServiceField(
				RelatedPersonField.targetPersonId, targetPersonId), new DataServiceField(RelatedPersonField.type, "followedMusic"), new DataServiceField(RelatedPersonField.startDate, startDate),
				new DataServiceField(RelatedPersonField.endDate, endDate)));
	}
	@Test(groups = TestGroup.testBug)//TODO pass locally but failed on bamboo
	public void testRelatedPersonCreateWithDifferentStartDate() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final URI sourcePersonId = personClient.create(personFactory.create()).getId();
		final URI targetPersonId = personClient.create(personFactory.create()).getId();
		final Date endDate = new Date();
		final String type = "influencedMusic";
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, sourcePersonId), new DataServiceField(
				RelatedPersonField.targetPersonId, targetPersonId), new DataServiceField(RelatedPersonField.type, type), new DataServiceField(RelatedPersonField.startDate, new Date()), new DataServiceField(
				RelatedPersonField.endDate, endDate)));
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, sourcePersonId), new DataServiceField(
				RelatedPersonField.targetPersonId, targetPersonId), new DataServiceField(RelatedPersonField.type, type), new DataServiceField(RelatedPersonField.startDate, new Date()), new DataServiceField(
				RelatedPersonField.endDate, endDate)));
	}
	@Test(groups = TestGroup.testBug)//TODO pass locally but failed on bamboo
	public void testRelatedPersonCreateWithDifferentEndDate() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final URI sourcePersonId = personClient.create(personFactory.create()).getId();
		final URI targetPersonId = personClient.create(personFactory.create()).getId();
		final Date startDate = new Date();
		final String type = "influencedMusic";
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, sourcePersonId), new DataServiceField(
				RelatedPersonField.targetPersonId, targetPersonId), new DataServiceField(RelatedPersonField.type, type), new DataServiceField(RelatedPersonField.endDate, new Date()), new DataServiceField(
				RelatedPersonField.startDate, startDate)));
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, sourcePersonId), new DataServiceField(
				RelatedPersonField.targetPersonId, targetPersonId), new DataServiceField(RelatedPersonField.type, type), new DataServiceField(RelatedPersonField.endDate, new Date()), new DataServiceField(
				RelatedPersonField.startDate, startDate)));
	}

}
