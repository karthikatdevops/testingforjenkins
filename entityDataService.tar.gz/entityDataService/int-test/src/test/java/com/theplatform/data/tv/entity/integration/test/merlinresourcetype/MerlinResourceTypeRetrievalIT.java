package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.program.ByLocal;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * @since 9/16/2011
 */
public class MerlinResourceTypeRetrievalIT extends EntityTestBase {

	private static final Sort SORT_BY_ID_ASC[] = new Sort[] { new Sort("id", false) };

	private URI[] allIds;

	private Map<MerlinResourceType, Program> programMap = new HashMap<>();

	@BeforeClass(alwaysRun = true)
	public void setUp() {

		Program programAudienceAvailable = this.programFactory.create(ProgramType.Movie);
		programAudienceAvailable.setLocal(true);
		programAudienceAvailable.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		programAudienceAvailable = this.programClient.create(programAudienceAvailable, new String[] { "merlinResourceType" });
		programMap.put(MerlinResourceType.AudienceAvailable, programAudienceAvailable);

		Program programTemporary = this.programFactory.create(ProgramType.Movie);
		programTemporary.setLocal(true);
		programTemporary.setMerlinResourceType(MerlinResourceType.Temporary);
		programTemporary = this.programClient.create(programTemporary, new String[] { "merlinResourceType" });
		programMap.put(MerlinResourceType.Temporary, programTemporary);

		Program programEditorial = this.programFactory.create(ProgramType.Movie);
		programEditorial.setMerlinResourceType(MerlinResourceType.Editorial);
		programEditorial.setLocal(true);
		programEditorial = this.programClient.create(programEditorial, new String[] { "merlinResourceType" });
		programMap.put(MerlinResourceType.Editorial, programEditorial);

		Program programInactive = this.programFactory.create(ProgramType.Movie);
		programInactive.setMerlinResourceType(MerlinResourceType.Inactive);
		programInactive.setLocal(true);
		programInactive = this.programClient.create(programInactive, new String[] { "merlinResourceType" });
		programMap.put(MerlinResourceType.Inactive, programInactive);

		allIds = new URI[] { programMap.get(MerlinResourceType.AudienceAvailable).getId(), programMap.get(MerlinResourceType.Temporary).getId(),
				programMap.get(MerlinResourceType.Editorial).getId(), programMap.get(MerlinResourceType.Inactive).getId() };

	}

	// by default, all test data created will be removed after class

	/**
	 * Use get(URI id, String[] fields), no byMerlinResourceType query is added
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetSingleIdOnlyAudienceAvailableWithoutMerlinResourceTypeQuery() {
		for (MerlinResourceType type : MerlinResourceType.values()) {
			Program program = this.programClient.get(programMap.get(type).getId(), null);
			Assert.assertEquals(program.getMerlinResourceType(), type);
		}
	}

	/**
	 * Use get(URI[] ids, String[] fields), no implicit byMerlinResourceType
	 * query is added
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetIdArrayOnlyAudienceAvailableWithoutMerlinResourceTypeQuery() {
		Feed<Program> programs = this.programClient.get(
				new URI[] { programMap.get(MerlinResourceType.AudienceAvailable).getId(), programMap.get(MerlinResourceType.Temporary).getId(),
						programMap.get(MerlinResourceType.Editorial).getId(), programMap.get(MerlinResourceType.Inactive).getId() }, null);
		Assert.assertEquals(programs.getEntryCount(), new Long(4), "This list should contain exact 4 program");
		for (MerlinResourceType type : MerlinResourceType.values()) {
			boolean typeHit = false;
			for (Program program : programs.getEntries()) {
				if (program.getMerlinResourceType().equals(type)) {
					typeHit = true;
					break;
				}
			}
			if (!typeHit)
				Assert.fail("Result doesn't contain endpoint of merlinResourceType=" + type);
		}

	}

	/**
	 * Use get(URI[] ids, String[] fields, Query[] queries, Sort[] sort, Range
	 * range), no byMerlinResourceType query included, and queries is non null,
	 * non-empty, only AudienceAvailable objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetWithNonMerlinResourceTypeQuery() {

		Feed<Program> programAudienceAvailables = this.programClient.get(allIds, null, new Query[] { new ByLocal(true) }, SORT_BY_ID_ASC, null);
		Assert.assertEquals(programAudienceAvailables.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getId(), programMap.get(MerlinResourceType.AudienceAvailable).getId());
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.AudienceAvailable,
				"Retrieved object should be of MerlinResourceType.AudienceAvailable");
	}

	/**
	 * Use get(URI[] ids, String[] fields, Query[] queries, Sort[] sort, Range
	 * range), no byMerlinResourceType query included, and queries is null, only
	 * AudienceAvailable objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetWithNullQuery() {

		Feed<Program> programAudienceAvailables = this.programClient.get(allIds, null, null, SORT_BY_ID_ASC, null);
		Assert.assertEquals(programAudienceAvailables.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getId(), programMap.get(MerlinResourceType.AudienceAvailable).getId());
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.AudienceAvailable,
				"Retrieved object should be of MerlinResourceType.AudienceAvailable");
	}

	/**
	 * Use get(URI[] ids, String[] fields, Query[] queries, Sort[] sort, Range
	 * range), empty, not null queries, only AudienceAvailable objects should be
	 * returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetWithEmptyQuery() {

		Feed<Program> programAudienceAvailables = this.programClient.get(allIds, null, new Query[] {}, SORT_BY_ID_ASC, null);
		Assert.assertEquals(programAudienceAvailables.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getId(), programMap.get(MerlinResourceType.AudienceAvailable).getId());
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.AudienceAvailable,
				"Retrieved object should be of MerlinResourceType.AudienceAvailable");
	}

	/**
	 * Use get(URI[] ids, String[] fields, Query[] queries, Sort[] sort, Range
	 * range), byMerlinResourceType(AudienceAvailable) queries, only
	 * AudienceAvailable objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetWithMerlinResourceTypeQueryAudienceAvailable() {

		Feed<Program> programAudienceAvailables = this.programClient.get(allIds, null, new Query[] { new ByMerlinResourceType(
				MerlinResourceType.AudienceAvailable) }, SORT_BY_ID_ASC, null);
		Assert.assertEquals(programAudienceAvailables.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getId(), programMap.get(MerlinResourceType.AudienceAvailable).getId());
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.AudienceAvailable,
				"Retrieved object should be of MerlinResourceType.AudienceAvailable");
	}

	/**
	 * Use get(URI[] ids, String[] fields, Query[] queries, Sort[] sort, Range
	 * range), byMerlinResourceType(Temporary) queries, only Temporary objects
	 * should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetWithMerlinResourceTypeQueryTemporary() {

		Feed<Program> programTemporaries = this.programClient.get(allIds, null, new Query[] { new ByMerlinResourceType(MerlinResourceType.Temporary) },
				SORT_BY_ID_ASC, null);
		Assert.assertEquals(programTemporaries.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programTemporaries.getEntries().get(0).getId(), programMap.get(MerlinResourceType.Temporary).getId());
		Assert.assertEquals(programTemporaries.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.Temporary,
				"Retrieved object should be of MerlinResourceType.Temporary");
	}

	/**
	 * Use get(URI[] ids, String[] fields, Query[] queries, Sort[] sort, Range
	 * range), byMerlinResourceType(Editorial) queries, only Editorial objects
	 * should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetWithMerlinResourceTypeQueryEditorial() {

		Feed<Program> programEditorials = this.programClient.get(allIds, null, new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) },
				SORT_BY_ID_ASC, null);
		Assert.assertEquals(programEditorials.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programEditorials.getEntries().get(0).getId(), programMap.get(MerlinResourceType.Editorial).getId());
		Assert.assertEquals(programEditorials.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.Editorial,
				"Retrieved object should be of MerlinResourceType.Editorial");
	}

	/**
	 * Use get(URI[] ids, String[] fields, Query[] queries, Sort[] sort, Range
	 * range), byMerlinResourceType(Inactive) queries, only Inactive objects
	 * should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetWithMerlinResourceTypeQueryInactive() {

		Feed<Program> programInactives = this.programClient.get(allIds, null, new Query[] { new ByMerlinResourceType(MerlinResourceType.Inactive) },
				SORT_BY_ID_ASC, null);
		Assert.assertEquals(programInactives.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programInactives.getEntries().get(0).getId(), programMap.get(MerlinResourceType.Inactive).getId());
		Assert.assertEquals(programInactives.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.Inactive,
				"Retrieved object should be of MerlinResourceType.Inactive");
	}

	/**
	 * Use get(URI[] ids, String[] fields, Query[] queries, Sort[] sort, Range
	 * range), byMerlinResourceType(Inactive or AudienceAvailable) queries, only
	 * Inactive and AudienceAvailable objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetWithMerlinResourceTypeQueryAudienceAvailableOrInactive() {

		Feed<Program> programs = this.programClient.get(allIds, null, new Query[] { new ByMerlinResourceType(MerlinResourceType.Inactive),
				new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) }, SORT_BY_ID_ASC, null);
		Assert.assertEquals(programs.getEntryCount(), new Long(2), "This list should only contain 2 program");
		if (programs.getEntries().get(0).getId().equals(programMap.get(MerlinResourceType.Inactive).getId())
				|| programs.getEntries().get(0).getId().equals(programMap.get(MerlinResourceType.AudienceAvailable))) {
			// pass
		} else {
			Assert.fail("Only MerlinResourceType.AudienceAvailable and MerlinResourceType.Inactive should be returned.");
		}
		if (programs.getEntries().get(1).getId().equals(programMap.get(MerlinResourceType.Inactive).getId())
				|| programs.getEntries().get(1).getId().equals(programMap.get(MerlinResourceType.AudienceAvailable))) {
			// pass
		} else {
			Assert.fail("Only MerlinResourceType.AudienceAvailable and MerlinResourceType.Inactive should be returned.");
		}
	}

	/**
	 * Use getAll(String[] fields, Query[] queries, Sort[] sort, Range range,
	 * Boolean count), no byMerlinResourceType query included, and queries is
	 * non null, non-empty, only AudienceAvailable objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetAllWithNonMerlinResourceTypeQuery() {

		Feed<Program> programAudienceAvailables = this.programClient.getAll(null, new Query[] { new ByLocal(true) }, SORT_BY_ID_ASC, null, true);
		Assert.assertEquals(programAudienceAvailables.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getId(), programMap.get(MerlinResourceType.AudienceAvailable).getId());
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.AudienceAvailable,
				"Retrieved object should be of MerlinResourceType.AudienceAvailable");
	}

	/**
	 * Use getAll(String[] fields, Query[] queries, Sort[] sort, Range range,
	 * Boolean count), no byMerlinResourceType query included, and queries is
	 * null, only AudienceAvailable objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetAllWithNullQuery() {
		Feed<Program> programAudienceAvailables = this.programClient.getAll(null, null, SORT_BY_ID_ASC, null, true);
		Assert.assertEquals(programAudienceAvailables.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getId(), programMap.get(MerlinResourceType.AudienceAvailable).getId());
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.AudienceAvailable,
				"Retrieved object should be of MerlinResourceType.AudienceAvailable");
	}

	/**
	 * Use getAll(String[] fields, Query[] queries, Sort[] sort, Range range,
	 * Boolean count), empty, not null queries, only AudienceAvailable objects
	 * should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetAllWithEmptyQuery() {

		Feed<Program> programAudienceAvailables = this.programClient.getAll(null, new Query[] {}, SORT_BY_ID_ASC, null, true);
		Assert.assertEquals(programAudienceAvailables.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getId(), programMap.get(MerlinResourceType.AudienceAvailable).getId());
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.AudienceAvailable,
				"Retrieved object should be of MerlinResourceType.AudienceAvailable");
	}

	/**
	 * Use getAll(String[] fields, Query[] queries, Sort[] sort, Range range,
	 * Boolean count), byMerlinResourceType(AudienceAvailable) queries, only
	 * AudienceAvailable objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetAllWithMerlinResourceTypeQueryAudienceAvailable() {

		Feed<Program> programAudienceAvailables = this.programClient.getAll(null,
				new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) }, SORT_BY_ID_ASC, null, true);
		Assert.assertEquals(programAudienceAvailables.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getId(), programMap.get(MerlinResourceType.AudienceAvailable).getId());
		Assert.assertEquals(programAudienceAvailables.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.AudienceAvailable,
				"Retrieved object should be of MerlinResourceType.AudienceAvailable");
	}

	/**
	 * Use getAll(String[] fields, Query[] queries, Sort[] sort, Range range,
	 * Boolean count), byMerlinResourceType(Temporary) queries, only Temporary
	 * objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetAllWithMerlinResourceTypeQueryTemporary() {

		Feed<Program> programTemporaries = this.programClient.getAll(null, new Query[] { new ByMerlinResourceType(MerlinResourceType.Temporary) },
				SORT_BY_ID_ASC, null, true);
		Assert.assertEquals(programTemporaries.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programTemporaries.getEntries().get(0).getId(), programMap.get(MerlinResourceType.Temporary).getId());
		Assert.assertEquals(programTemporaries.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.Temporary,
				"Retrieved object should be of MerlinResourceType.Temporary");
	}

	/**
	 * Use getAll(String[] fields, Query[] queries, Sort[] sort, Range range,
	 * Boolean count), byMerlinResourceType(Editorial) queries, only Editorial
	 * objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetAllWithMerlinResourceTypeQueryEditorial() {

		Feed<Program> programEditorials = this.programClient.getAll(null, new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) },
				SORT_BY_ID_ASC, null, true);
		Assert.assertEquals(programEditorials.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programEditorials.getEntries().get(0).getId(), programMap.get(MerlinResourceType.Editorial).getId());
		Assert.assertEquals(programEditorials.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.Editorial,
				"Retrieved object should be of MerlinResourceType.Editorial");
	}

	/**
	 * Use getAll(String[] fields, Query[] queries, Sort[] sort, Range range,
	 * Boolean count), byMerlinResourceType(Inactive) queries, only Inactive
	 * objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetAllWithMerlinResourceTypeQueryInactive() {

		Feed<Program> programInactives = this.programClient.getAll(null, new Query[] { new ByMerlinResourceType(MerlinResourceType.Inactive) }, SORT_BY_ID_ASC,
				null, true);
		Assert.assertEquals(programInactives.getEntryCount(), new Long(1), "This list should only contain one program");
		Assert.assertEquals(programInactives.getEntries().get(0).getId(), programMap.get(MerlinResourceType.Inactive).getId());
		Assert.assertEquals(programInactives.getEntries().get(0).getMerlinResourceType(), MerlinResourceType.Inactive,
				"Retrieved object should be of MerlinResourceType.Inactive");
	}

	/**
	 * Use getAll(String[] fields, Query[] queries, Sort[] sort, Range range,
	 * Boolean count), byMerlinResourceType(Inactive or AudienceAvailable)
	 * queries, only Inactive and AudienceAvailable objects should be returned.
	 */
	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testGetAllWithMerlinResourceTypeQueryAudienceAvailableOrInactive() {

		Feed<Program> programs = this.programClient.getAll(null, new Query[] { new ByMerlinResourceType(MerlinResourceType.Inactive),
				new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) }, SORT_BY_ID_ASC, null, true);
		Assert.assertEquals(programs.getEntryCount(), new Long(2), "This list should only contain 2 program");
		if (programs.getEntries().get(0).getId().equals(programMap.get(MerlinResourceType.Inactive).getId())
				|| programs.getEntries().get(0).getId().equals(programMap.get(MerlinResourceType.AudienceAvailable))) {
			// pass
		} else {
			Assert.fail("Only MerlinResourceType.AudienceAvailable and MerlinResourceType.Inactive should be returned.");
		}
		if (programs.getEntries().get(1).getId().equals(programMap.get(MerlinResourceType.Inactive).getId())
				|| programs.getEntries().get(1).getId().equals(programMap.get(MerlinResourceType.AudienceAvailable))) {
			// pass
		} else {
			Assert.fail("Only MerlinResourceType.AudienceAvailable and MerlinResourceType.Inactive should be returned.");
		}
	}
}
