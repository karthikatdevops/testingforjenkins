package com.theplatform.data.tv.entity.integration.test.endpoint.programrank;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.programrank.ByProgramId;
import com.theplatform.data.tv.entity.api.client.query.programrank.ByType;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.entity.api.fields.ProgramRankField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "programRank", "query" })
public class ProgramRankQueryIT extends EntityTestBase {

	public void testProgramRankQueryByProgramIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI programId1 = this.programRankClient.create(this.programRankFactory.create(), new String[] {}).getProgramId();
		URI programId2 = this.programRankFactory.create().getProgramId();
		Assert.assertNotEquals(programId2, programId1);
		Query[] queries = new Query[] { new ByProgramId(URIUtils.getIdValue(programId2)) };
		Feed<ProgramRank> results = this.programRankClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramRank should be found");
	}

	public void testProgramRankQueryByProgramIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.programRankClient.create(this.programRankFactory.create());
		ProgramRank expected = this.programRankClient.create(this.programRankFactory.create(), new String[] {});

		Query[] queries = new Query[] { new ByProgramId(URIUtils.getIdValue(expected.getProgramId())) };
		Feed<ProgramRank> results = this.programRankClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramRank should be found");

		programRankComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testProgramRankQueryByProgramIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI programId = programClient.create(this.programFactory.create()).getId();

		ProgramRank programRank1 = programRankClient.create(
				programRankFactory.create(new DataServiceField(ProgramRankField.type, "Algorithmic"), new DataServiceField(ProgramRankField.programId, programId)), new String[] {});
		ProgramRank programRank2 = programRankClient.create(
				programRankFactory.create(new DataServiceField(ProgramRankField.type, "Gross"), new DataServiceField(ProgramRankField.programId, programId)), new String[] {});
		this.programRankClient.create(this.programRankFactory.create());
		this.programRankClient.create(this.programRankFactory.create());

		Query[] queries = new Query[] { new ByProgramId(URIUtils.getIdValue(programId)) };
		Feed<ProgramRank> results = this.programRankClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramRanks should be found");

		Map<URI, ProgramRank> resultMap = new HashMap<>();
		for (ProgramRank programRank : results.getEntries())
			resultMap.put(programRank.getId(), programRank);

		programRankComparator.assertEquals(resultMap.get(programRank1.getId()), programRank1);
		programRankComparator.assertEquals(resultMap.get(programRank2.getId()), programRank2);
	}

	public void testProgramRankQueryByTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.type, "Algorithmic")));
		Query[] queries = new Query[] { new ByType("Gross") };
		Feed<ProgramRank> results = this.programRankClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramRank should be found");
	}

	public void testProgramRankQueryByTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		ProgramRank expected = this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.type, "Cumulative")), new String[] {});
		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.type, "Gross")));

		Query[] queries = new Query[] { new ByType("Cumulative") };
		Feed<ProgramRank> results = this.programRankClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramRank should be found");

		programRankComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testProgramRankQueryByTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.type, "Algorithmic")));
		List<ProgramRank> expectedProgramRanks = this.programRankClient.create(this.programRankFactory.create(2, new DataServiceField(ProgramRankField.type, "Gross")),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByType("Gross") };
		Feed<ProgramRank> results = this.programRankClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramRanks should be found");

		Map<URI, ProgramRank> resultMap = new HashMap<>();
		for (ProgramRank programRank : results.getEntries())
			resultMap.put(programRank.getId(), programRank);

		for (ProgramRank expected : expectedProgramRanks)
			programRankComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	//FIXME the database didn't seem to be cleaned up, has to set ProgramRank to editorial=true 
	public void testProgramRankQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.merlinResourceType,
				MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<ProgramRank> results = this.programRankClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramRank should be found");
	}

	public void testProgramRankQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		ProgramRank programRank = this.programRankClient.create(
				this.programRankFactory.create(new DataServiceField(ProgramRankField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
				new String[] {});
		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.merlinResourceType, MerlinResourceType.Inactive)),
				new String[] {});

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<ProgramRank> results = this.programRankClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramRank should be found");

		programRankComparator.assertEquals(results.getEntries().get(0), programRank);
	}

	public void testProgramRankQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.merlinResourceType, MerlinResourceType.Temporary)));
		List<ProgramRank> expectedProgramRanks = this.programRankClient.create(
				this.programRankFactory.create(2, new DataServiceField(ProgramRankField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
				new String[] {}).getEntries();

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<ProgramRank> results = this.programRankClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramRanks should be found");

		Map<URI, ProgramRank> resultMap = new HashMap<>();
		for (ProgramRank programRank : results.getEntries())
			resultMap.put(programRank.getId(), programRank);

		for (ProgramRank expected : expectedProgramRanks)
			programRankComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}
}
