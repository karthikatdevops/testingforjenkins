package com.theplatform.data.tv.entity.integration.test.endpoint.albumreleasesongassociation;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;

import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseSongAssociationField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "albumReleaseSongAssociation", "validation" })
public class AlbumReleaseSongAssociationValidationIT extends EntityTestBase {

	public void testAlbumReleaseSongAssociationCreationWithNullSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseSongAssociationCreationWithNonpersistedSong() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songFactory.create()
				.getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseSongAssociationCreationWithNonlocalSong() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localSongId = this.songClient.create(this.songFactory.create()).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songFactory.create(
				new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9002/entityDataService/data/Song/" + URIUtils.getIdValue(localSongId)))).getId())));
	}

	public void testAlbumReleaseSongAssociationCreationWithNullAlbumReleaseId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseSongAssociationCreationWithNonpersistedAlbumRelease() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseFactory
				.create().getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseSongAssociationCreationWithNonlocalAlbumRelease() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localAlbumReleaseId = this.albumReleaseClient.create(this.albumReleaseFactory.create()).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseFactory
				.create(new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9002/entityDataService/data/AlbumRelease/"
						+ URIUtils.getIdValue(localAlbumReleaseId)))).getId())));
	}

	public void testAlbumReleaseSongAssociationCreationWithPositiveTrackNumber() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.trackNumber, 1)));
	}

	public void testAlbumReleaseSongAssociationCreationWithNullTrackNumber() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.trackNumber, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseSongAssociationCreationWithNegativeTrackNumber() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.trackNumber, -3)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseSongAssociationCreationWithZeroTrackNumber() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.trackNumber, 0)));
	}

	public void testAlbumReleaseSongAssociationCreationOneSongTwoAlbumReleases() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId = this.songClient.create(this.songFactory.create()).getId();

		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songId),
				new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient.create(albumReleaseFactory.create()).getId())));
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.songId, songId),
				new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient.create(albumReleaseFactory.create()).getId())));
	}
}
