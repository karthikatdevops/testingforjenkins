package com.theplatform.data.tv.entity.integration.test.endpoint.sportsteam;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.theplatform.data.tv.entity.api.client.query.sportsteam.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.fields.SportsTeamField;
import com.theplatform.data.tv.entity.api.test.SportsTeamComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "sportsTeam", "query", TestGroup.gbTest })
public class SportsTeamQueryIT extends EntityTestBase {
	private Random random = new Random();


	public void testQuerySportsTeamBySportType() throws UnknownHostException {
		List<SportsTeam> inputSportsTeams = this.sportsTeamFactory.create(3);
		inputSportsTeams.get(1).setSportType("Tennis");
		this.sportsTeamClient.create(inputSportsTeams);
		Query queries[] = new Query[] { new BySportType(inputSportsTeams.get(1).getSportType()), };
		Feed<SportsTeam> retrievedSportsTeams = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedSportsTeams.getEntries().size(), 1, "Not getting SportsTeams using query bySportType");
		SportsTeamComparator.assertEquals(retrievedSportsTeams.getEntries().get(0), inputSportsTeams.get(1));
	}

    public void testQuerySportsTeamByType() throws UnknownHostException {
        List<SportsTeam> inputSportsTeams = this.sportsTeamFactory.create(3);
        inputSportsTeams.get(0).setType("Organization");
        inputSportsTeams.get(1).setType("Team");
        inputSportsTeams.get(2).setType("Organization");
        this.sportsTeamClient.create(inputSportsTeams);
        Query queries[] = new Query[] { new ByType(inputSportsTeams.get(1).getType()), };
        Feed<SportsTeam> retrievedSportsTeams = this.sportsTeamClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(retrievedSportsTeams.getEntries().size(), 1, "Not getting SportsTeams using query byType");
        SportsTeamComparator.assertEquals(retrievedSportsTeams.getEntries().get(0), inputSportsTeams.get(1));
    }

	public void testQuerySportsTeamByLeagueId() throws UnknownHostException {
		List<SportsTeam> inputSportsTeams = this.sportsTeamFactory.create(3);
		inputSportsTeams.get(0).setLeagueId(this.sportsLeagueClient.create(this.sportsLeagueFactory.create()).getId());
		this.sportsTeamClient.create(inputSportsTeams);
		Query queries[] = new Query[] { new ByLeagueId(URIUtils.getIdValue(inputSportsTeams.get(0).getLeagueId())) };
		Feed<SportsTeam> retrievedSportsTeams = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedSportsTeams.getEntries().size(), 1, "Not getting SportsTeams using query byLeagueId");
		SportsTeamComparator.assertEquals(retrievedSportsTeams.getEntries().get(0), inputSportsTeams.get(0));
	}

	public void testQuerySportsTeamByParentSportsTeamId() throws UnknownHostException {
		List<SportsTeam> inputSportsTeams = this.sportsTeamFactory.create(3);
		inputSportsTeams.get(0).setParentSportsTeamId(this.sportsTeamClient.create(this.sportsTeamFactory.create()).getId());
		this.sportsTeamClient.create(inputSportsTeams);
		Query queries[] = new Query[] { new ByParentSportsTeamId(URIUtils.getIdValue(inputSportsTeams.get(0).getParentSportsTeamId())) };
		Feed<SportsTeam> retrievedSportsTeams = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedSportsTeams.getEntries().size(), 1, "Not getting SportsTeams using query byParentSportsTeamId");
		SportsTeamComparator.assertEquals(retrievedSportsTeams.getEntries().get(0), inputSportsTeams.get(0));
	}

	public void testSportsTeamQueryByNickNameNoMatch() {

		SportsTeam entity = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, "nickname".concat("" + random.nextInt()))), new String[] {});
		Query[] queries = new Query[] { new ByNickName(entity.getNickName().concat("updated")) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SportsTeam should be found");
	}

	public void testSportsTeamQueryByNickNameListNoMatch() {

		SportsTeam entity = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, "nickName".concat("" + random.nextInt()))), new String[] {});
		Query[] queries = new Query[] { new ByNickName(Arrays.asList(entity.getNickName().concat("updated"))) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SportsTeam should be found");
	}

	public void testSportsTeamQueryByNickNameOneMatch() {

		final String nickName1 = "nickname 1".concat("" + random.nextInt());
		final String nickName2 = "nickname 2".concat("" + random.nextInt());

		this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, nickName1)));

		SportsTeam expectedSportsTeam = this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, nickName2)),
				new String[] {});
		Query[] queries = new Query[] { new ByNickName(nickName2) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SportsTeam should be found");
		SportsTeamComparator.assertEquals(results.getEntries().get(0), expectedSportsTeam);
	}

	public void testSportsTeamQueryByNickNameListOneMatch() {

		final String nickName1 = "nickName 1".concat("" + random.nextInt());
		final String nickName2 = "nickName 2".concat("" + random.nextInt());

		this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, nickName1)));

		SportsTeam expectedSportsTeam = this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, nickName2)),
				new String[] {});
		Query[] queries = new Query[] { new ByNickName(Arrays.asList(nickName2, "dummy nickName".concat("" + random.nextInt()))) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SportsTeam should be found");

		SportsTeamComparator.assertEquals(results.getEntries().get(0), expectedSportsTeam);
	}

	public void testQuerySportsTeamByCountry() throws UnknownHostException {
		List<SportsTeam> inputSportsTeams = this.sportsTeamFactory.create(2);
		inputSportsTeams.get(0).setAbbreviation("USA");
		inputSportsTeams.get(1).setAbbreviation("RUS");
		this.sportsTeamClient.create(inputSportsTeams);
		Query queries[] = new Query[] { new ByAbbreviation(inputSportsTeams.get(0).getAbbreviation()), };
		Feed<SportsTeam> retrievedSportsTeams = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedSportsTeams.getEntries().size(), 1, "Not getting SportsTeams using query byCountry");
		SportsTeamComparator.assertEquals(retrievedSportsTeams.getEntries().get(0), inputSportsTeams.get(0));
	}

	public void testSportsTeamQueryByNickNameMultipleMatches() {

		final String nickName1 = "nickName 1".concat("" + random.nextInt());

		SportsTeam sportsTeam1 = this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, nickName1)),
				new String[] {});
		SportsTeam sportsTeam2 = this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, nickName1)),
				new String[] {});
		this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName,
				"dummy nickName".concat("" + random.nextInt()))));

		Query[] queries = new Query[] { new ByNickName(nickName1) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SportsTeams should be found");

		Map<URI, SportsTeam> resultMap = new HashMap<>();
		for (SportsTeam SportsTeam : results.getEntries())
			resultMap.put(SportsTeam.getId(), SportsTeam);

		SportsTeamComparator.assertEquals(resultMap.get(sportsTeam1.getId()), sportsTeam1);
		SportsTeamComparator.assertEquals(resultMap.get(sportsTeam2.getId()), sportsTeam2);
	}

	public void testSportsTeamQueryByNickNameListMultipleMatches() {

		final String nickName1 = "nickName 1".concat("" + random.nextInt());
		final String nickName2 = "nickName 2".concat("" + random.nextInt());

		SportsTeam sportsTeam1 = this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, nickName1)),
				new String[] {});
		SportsTeam sportsTeam2 = this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName, nickName2)),
				new String[] {});
		this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.nickName,
				"dummy nickName".concat("" + random.nextInt()))));

		Query[] queries = new Query[] { new ByNickName(Arrays.asList(nickName1, nickName2)) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SportsTeams should be found");

		Map<URI, SportsTeam> resultMap = new HashMap<>();
		for (SportsTeam SportsTeam : results.getEntries())
			resultMap.put(SportsTeam.getId(), SportsTeam);

		SportsTeamComparator.assertEquals(resultMap.get(sportsTeam1.getId()), sportsTeam1);
		SportsTeamComparator.assertEquals(resultMap.get(sportsTeam2.getId()), sportsTeam2);
	}

	public void testSportsTeamQueryByRepresentingNameNoMatch() {

		SportsTeam entity = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, "representingName".concat("" + random.nextInt()))),
				new String[] {});
		Query[] queries = new Query[] { new ByRepresentingName(entity.getRepresentingName().concat("updated")) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SportsTeam should be found");
	}

	public void testSportsTeamQueryByRepresentingNameListNoMatch() {

		SportsTeam entity = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, "representingName".concat("" + random.nextInt()))),
				new String[] {});
		Query[] queries = new Query[] { new ByRepresentingName(Arrays.asList(entity.getRepresentingName().concat("updated"))) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SportsTeam should be found");
	}

	public void testSportsTeamQueryByRepresentingNameOneMatch() {

		final String representingName1 = "representingName 1".concat("" + random.nextInt());
		final String representingName2 = "representingName 2".concat("" + random.nextInt());

		this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, representingName1)));

		SportsTeam expectedSportsTeam = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, representingName2)), new String[] {});
		Query[] queries = new Query[] { new ByRepresentingName(representingName2) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SportsTeam should be found");
		SportsTeamComparator.assertEquals(results.getEntries().get(0), expectedSportsTeam);
	}

	public void testSportsTeamQueryByRepresentingNameListOneMatch() {

		final String representingName1 = "representingName 1".concat("" + random.nextInt());
		final String representingName2 = "representingName 2".concat("" + random.nextInt());

		this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, representingName1)));

		SportsTeam expectedSportsTeam = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, representingName2)), new String[] {});
		Query[] queries = new Query[] { new ByRepresentingName(Arrays.asList(representingName2, "dummy representingName".concat("" + random.nextInt()))) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SportsTeam should be found");

		SportsTeamComparator.assertEquals(results.getEntries().get(0), expectedSportsTeam);
	}

	public void testSportsTeamQueryByRepresentingNameMultipleMatches() {

		final String representingName1 = "representingName 1".concat("" + random.nextInt());

		SportsTeam sportsTeam1 = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, representingName1)), new String[] {});
		SportsTeam sportsTeam2 = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, representingName1)), new String[] {});
		this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, "dummy representingName".concat(""
				+ random.nextInt()))));

		Query[] queries = new Query[] { new ByRepresentingName(representingName1) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SportsTeams should be found");

		Map<URI, SportsTeam> resultMap = new HashMap<>();
		for (SportsTeam SportsTeam : results.getEntries())
			resultMap.put(SportsTeam.getId(), SportsTeam);

		SportsTeamComparator.assertEquals(resultMap.get(sportsTeam1.getId()), sportsTeam1);
		SportsTeamComparator.assertEquals(resultMap.get(sportsTeam2.getId()), sportsTeam2);
	}

	public void testSportsTeamQueryByRepresentingNameListMultipleMatches() {

		final String representingName1 = "representingName 1".concat("" + random.nextInt());
		final String representingName2 = "representingName 2".concat("" + random.nextInt());

		SportsTeam sportsTeam1 = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, representingName1)), new String[] {});
		SportsTeam sportsTeam2 = this.sportsTeamClient.create(
				this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, representingName2)), new String[] {});
		this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, "dummy representingName".concat(""
				+ random.nextInt()))));

		Query[] queries = new Query[] { new ByRepresentingName(Arrays.asList(representingName1, representingName2)) };
		Feed<SportsTeam> results = this.sportsTeamClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SportsTeams should be found");

		Map<URI, SportsTeam> resultMap = new HashMap<>();
		for (SportsTeam SportsTeam : results.getEntries())
			resultMap.put(SportsTeam.getId(), SportsTeam);

		SportsTeamComparator.assertEquals(resultMap.get(sportsTeam1.getId()), sportsTeam1);
		SportsTeamComparator.assertEquals(resultMap.get(sportsTeam2.getId()), sportsTeam2);
	}

}
