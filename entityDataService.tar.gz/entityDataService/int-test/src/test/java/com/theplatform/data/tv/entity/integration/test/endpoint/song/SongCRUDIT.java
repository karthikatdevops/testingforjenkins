package com.theplatform.data.tv.entity.integration.test.endpoint.song;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.Lists;
import com.theplatform.data.api.objects.DataObjectField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;
import com.theplatform.data.tv.entity.api.fields.SongField;
import com.theplatform.data.tv.entity.api.test.SongComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "song", "crud" })
public class SongCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testSingleSongCrud() {
		Song entity = this.songFactory.create();

		// CREATE
		Song persistedEntity = songClient.create(entity, new String[] {});
		SongComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		Song retrievedEntity = songClient.get(entity.getId(), new String[] {});
		SongComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setTitle(entity.getTitle() != null ? entity.getTitle().concat("update") : "albumRelease title");
		entity.setSortTitle(entity.getSortTitle() != null ? entity.getSortTitle().concat("update") : "albumRelease SortTitle");
		entity.setIsrc(entity.getIsrc() != null ? entity.getIsrc().concat("update") : "song isrc");
		entity.setDescription(entity.getDescription() != null ? entity.getDescription().concat("update") : "albumRelease description");
		entity.setDuration(entity.getDuration() != null ? entity.getDuration() + 1 : 1);
		
		List<URI> primaryPersonIds = entity.getPrimaryPersonIds();
		URI songCreditId = null;
		if (primaryPersonIds == null || primaryPersonIds.isEmpty()) {
			Person p = personFactory.create();
			URI personId = personClient.create(p).getId();
			entity.setPrimaryPersonIds(Lists.newArrayList(personId));

			SongCredit sc = songCreditFactory.create();
			sc.setPersonId(personId);
			sc.setSongId(entity.getId());
			sc.setType("PrimaryArtist");
			sc.setRank(0);

			songCreditId = songCreditClient.create(sc).getId();
		}

		// TODO update primaryPersonIds, imageIds, tagIds

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		songClient.update(entity);

		Song retrievedAfterUpdate = songClient.get(entity.getId(), new String[] {});
		SongComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		if(songCreditId != null) {
			songCreditClient.delete(songCreditId);
		}
		
		long deletedObjects = songClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			songClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("Song should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testSongFeedCrud() throws UnknownHostException {
		List<Song> entities = this.songFactory.create(5);

		// CREATE
		Feed<Song> persistedEntities = this.songClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			SongComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i));

		URI[] entityIds = new URI[entities.size()];
		for (int i = 0; i < entityIds.length; i++)
			entityIds[i] = entities.get(i).getId();

		// RETRIEVE
		Feed<Song> retrievedEntities = this.songClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			SongComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i));

		// DELETE
		long deletedEntities = this.songClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (Song entity : entities) {
			try {
				this.songClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSongDefaultFieldValues() {
		Song entity = this.songFactory.create();

		entity.setTitle(null);
		entity.setSortTitle(null);
		entity.setIsrc(null);
		entity.setDescription(null);
		entity.setDuration(null);
		entity.setPrimaryPersonIds(null);
		entity.setImageIds(null);
		entity.setTagIds(null);
		entity.setMerlinResourceType(null);
		Song actual = this.songClient.create(entity, new String[] {});

		entity.setPrimaryPersonIds(new ArrayList<URI>());
		entity.setImageIds(new ArrayList<URI>());
		entity.setTagIds(new ArrayList<URI>());
		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		SongComparator.assertEquals(actual, entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(DataObjectField.title, null),
			new DataServiceField(SongField.sortTitle, null), new DataServiceField(SongField.isrc, null), new DataServiceField(DataObjectField.description, null),
			new DataServiceField(SongField.duration, null), new DataServiceField(SongField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testSongCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(songClient, songFactory.create(), SongComparator.class, this.defaultValues,
				new DataServiceField[] { new DataServiceField(SongField.primaryPersonIds, new ArrayList<URI>()),
						new DataServiceField(SongField.imageIds, new ArrayList<URI>()), new DataServiceField(SongField.tagIds, new ArrayList<URI>()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSongCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(songClient, songFactory.create(), SongComparator.class, this.defaultValues,
				new DataServiceField[] { new DataServiceField(SongField.primaryPersonIds, new ArrayList<URI>()),
						new DataServiceField(SongField.imageIds, new ArrayList<URI>()), new DataServiceField(SongField.tagIds, new ArrayList<URI>()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSongUpdateWithAllNullNonRequiredFieldsGeneric() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.title, "song title"));
		createValues.add(new DataServiceField(SongField.sortTitle, "song sortTitle"));
		createValues.add(new DataServiceField(SongField.isrc, "song isrc"));
		createValues.add(new DataServiceField(DataObjectField.description, "song description"));
		createValues.add(new DataServiceField(SongField.duration, 20));
		createValues.add(new DataServiceField(SongField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(songClient, songFactory.create(), SongComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(SongField.primaryPersonIds, new ArrayList<URI>()), new DataServiceField(SongField.imageIds, new ArrayList<URI>()),
						new DataServiceField(SongField.tagIds, new ArrayList<URI>()) });
	}

	@Test(groups = TestGroup.gbTest)
	public void testSongUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(SongField.sortTitle, "song sortTitle"));
		createValues.add(new DataServiceField(SongField.isrc, "song isrc"));
		createValues.add(new DataServiceField(DataObjectField.description, "song description"));
		createValues.add(new DataServiceField(SongField.duration, 20));
		createValues.add(new DataServiceField(SongField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(songClient, songFactory.create(), SongComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(SongField.primaryPersonIds, new ArrayList<URI>()), new DataServiceField(SongField.imageIds, new ArrayList<URI>()),
						new DataServiceField(SongField.tagIds, new ArrayList<URI>()) });
	}
}
