package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagetypegroup;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.StringUtil;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageTypeGroup;
import com.theplatform.data.tv.image.api.test.MainImageTypeGroupComparator;

@Test(groups = { TestGroup.gbTest, "mainImageTypeGroup", "sort" })
public class MainImageTypeGroupSortIT extends EntityTestBase {



	public void testMainImageTypeGroupSortByGuid() {
		List<MainImageTypeGroup> mainImageTypeGroups = mainImageTypeGroupFactory.create(4);
		mainImageTypeGroups.get(0).setGuid("1".concat(StringUtil.generateRandomString()));
		mainImageTypeGroups.get(3).setGuid("2".concat(StringUtil.generateRandomString()));
		mainImageTypeGroups.get(1).setGuid("3".concat(StringUtil.generateRandomString()));
		mainImageTypeGroups.get(2).setGuid("4".concat(StringUtil.generateRandomString()));

		this.mainImageTypeGroupClient.create(mainImageTypeGroups);

		List<MainImageTypeGroup> expectedSortedMainImageTypeGroups = new ArrayList<>(mainImageTypeGroups.size());
		expectedSortedMainImageTypeGroups.add(mainImageTypeGroups.get(0));
		expectedSortedMainImageTypeGroups.add(mainImageTypeGroups.get(3));
		expectedSortedMainImageTypeGroups.add(mainImageTypeGroups.get(1));
		expectedSortedMainImageTypeGroups.add(mainImageTypeGroups.get(2));

		Feed<MainImageTypeGroup> retrievedMainImageTypeGroups = this.mainImageTypeGroupClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"guid", false) }, null, false);

		MainImageTypeGroupComparator.assertEquals(retrievedMainImageTypeGroups, expectedSortedMainImageTypeGroups);
	}

	public void testMainImageTypeGroupSortByTitle() {
		List<MainImageTypeGroup> mainImageTypeGroups = mainImageTypeGroupFactory.create(4);
		mainImageTypeGroups.get(0).setTitle("A".concat(mainImageTypeGroups.get(0).getTitle()));
		mainImageTypeGroups.get(2).setTitle("B".concat(mainImageTypeGroups.get(0).getTitle()));
		mainImageTypeGroups.get(3).setTitle("C".concat(mainImageTypeGroups.get(0).getTitle()));
		mainImageTypeGroups.get(1).setTitle("D".concat(mainImageTypeGroups.get(0).getTitle()));

		this.mainImageTypeGroupClient.create(mainImageTypeGroups);

		List<MainImageTypeGroup> expectedSortedMainImageTypeGroups = new ArrayList<>(mainImageTypeGroups.size());
		expectedSortedMainImageTypeGroups.add(mainImageTypeGroups.get(0));
		expectedSortedMainImageTypeGroups.add(mainImageTypeGroups.get(2));
		expectedSortedMainImageTypeGroups.add(mainImageTypeGroups.get(3));
		expectedSortedMainImageTypeGroups.add(mainImageTypeGroups.get(1));

		Feed<MainImageTypeGroup> retrievedMainImageTypeGroups = this.mainImageTypeGroupClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"title", false) }, null, false);

		MainImageTypeGroupComparator.assertEquals(retrievedMainImageTypeGroups, expectedSortedMainImageTypeGroups);
	}
}
