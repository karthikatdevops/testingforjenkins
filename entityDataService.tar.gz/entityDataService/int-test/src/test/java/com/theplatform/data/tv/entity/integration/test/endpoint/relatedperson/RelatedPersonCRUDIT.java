package com.theplatform.data.tv.entity.integration.test.endpoint.relatedperson;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPerson;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPersonType;
import com.theplatform.data.tv.entity.api.fields.RelatedPersonField;
import com.theplatform.data.tv.entity.api.test.RelatedPersonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "relatedPerson", "crud" })
public class RelatedPersonCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testSingleRelatedPersonCrud() {
		RelatedPerson entity = this.relatedPersonFactory.create();

		// CREATE
		RelatedPerson persistedEntity = this.relatedPersonClient.create(entity, new String[] {});
		RelatedPersonComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		RelatedPerson retrievedEntity = this.relatedPersonClient.get(entity.getId(), new String[] {});
		RelatedPersonComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setSourcePersonId(this.personClient.create(this.personFactory.create()).getId());
		entity.setTargetPersonId(this.personClient.create(this.personFactory.create()).getId());
		entity.setStartDate(new Date());
		entity.setEndDate(new Date());
		entity.setType(entity.getType() != null && entity.getType() != RelatedPersonType.hasSimilarMusic.getFriendlyName() ? RelatedPersonType.hasSimilarMusic
				.getFriendlyName() : RelatedPersonType.influencedMusic.getFriendlyName());
		entity.setRank(entity.getRank() != null ? entity.getRank() + 1 : 1);

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		this.relatedPersonClient.update(entity);

		RelatedPerson retrievedAfterUpdate = this.relatedPersonClient.get(entity.getId(), new String[] {});
		RelatedPersonComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = this.relatedPersonClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.relatedPersonClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("RelatedPerson should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testRelatedPersonFeedCrud() throws UnknownHostException {
		List<RelatedPerson> entities = this.relatedPersonFactory.create(5);

		// CREATE
		Feed<RelatedPerson> persistedEntities = this.relatedPersonClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			RelatedPersonComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i));

		URI[] entityIds = new URI[entities.size()];
		for (int i = 0; i < entityIds.length; i++)
			entityIds[i] = entities.get(i).getId();

		// RETRIEVE
		Feed<RelatedPerson> retrievedEntities = this.relatedPersonClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			RelatedPersonComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i));

		// DELETE
		long deletedEntities = this.relatedPersonClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (RelatedPerson entity : entities) {
			try {
				this.relatedPersonClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedPersonDefaultFieldValues() {
		RelatedPerson entity = this.relatedPersonFactory.create();

		entity.setStartDate(null);
		entity.setEndDate(null);
		entity.setRank(null);
		entity.setMerlinResourceType(null);
		RelatedPerson actual = this.relatedPersonClient.create(entity, new String[] {});

		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		RelatedPersonComparator.assertEquals(actual, entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(RelatedPersonField.startDate, null),
			new DataServiceField(RelatedPersonField.endDate, null), new DataServiceField(RelatedPersonField.rank, null),
			new DataServiceField(RelatedPersonField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedPersonCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(relatedPersonClient, relatedPersonFactory.create(), RelatedPersonComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedPersonCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(relatedPersonClient, relatedPersonFactory.create(), RelatedPersonComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedPersonUpdateWithAllNullNonRequiredFieldsGeneric() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(RelatedPersonField.startDate, new Date()));
		createValues.add(new DataServiceField(RelatedPersonField.endDate, new Date()));
		createValues.add(new DataServiceField(RelatedPersonField.rank, 1));
		createValues.add(new DataServiceField(RelatedPersonField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(relatedPersonClient, relatedPersonFactory.create(), RelatedPersonComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testRelatedPersonUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(RelatedPersonField.startDate, new Date()));
		createValues.add(new DataServiceField(RelatedPersonField.endDate, new Date()));
		createValues.add(new DataServiceField(RelatedPersonField.rank, 1));
		createValues.add(new DataServiceField(RelatedPersonField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(relatedPersonClient, relatedPersonFactory.create(), RelatedPersonComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}
}
