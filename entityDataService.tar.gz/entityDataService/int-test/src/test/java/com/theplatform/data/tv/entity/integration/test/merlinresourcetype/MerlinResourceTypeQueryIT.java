package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import java.net.URI;
import java.util.Random;

import com.theplatform.data.tv.entity.api.fields.*;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.test.merlinresourcetype.MerlinResourceTypeQueryTest;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.client.query.albumreleasesongassociation.BySongId;
import com.theplatform.data.tv.entity.api.client.query.credit.ByPersonId;
import com.theplatform.data.tv.entity.api.client.query.person.ByName;
import com.theplatform.data.tv.entity.api.client.query.relatedalbum.BySourceAlbumId;
import com.theplatform.data.tv.entity.api.client.query.relatedperson.BySourcePersonId;
import com.theplatform.data.tv.entity.api.client.query.relatedprogram.BySourceProgramId;
import com.theplatform.data.tv.entity.api.client.query.relatedsong.BySourceSongId;
import com.theplatform.data.tv.entity.api.client.query.review.ByProgramId;
import com.theplatform.data.tv.entity.api.client.query.tag.ByType;
import com.theplatform.data.tv.entity.api.client.query.tvseason.BySeriesId;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.client.query.imageassociation.ByIsDefault;
import com.theplatform.data.tv.image.api.fields.ImageAssociationField;
import com.theplatform.data.tv.tag.api.client.query.ByTagId;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;

@Test(groups = { "merlinResourceType", "query", TestGroup.gbTest })
public class MerlinResourceTypeQueryIT extends EntityTestBase {

	private Random random = new Random();


	public void testProgramMerlinResourceTypeQuery() {
		final String title = "program title " + random.nextInt();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.programClient, programFactory, new ByTitle(title),
                new DataServiceField(DataObjectField.title, title), title);

	}

	public void testCreditMerlinResourceTypeQuery() {
		final URI personId = personClient.create(personFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.creditClient, creditFactory, new ByPersonId(URIUtils.getIdValue(personId)),
                new DataServiceField(CreditField.personId, personId), personId);
	}

	public void testPersonMerlinResourceTypeQuery() {
		final String name = "person name " + random.nextInt();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.personClient, personFactory,
				new ByName(name),new DataServiceField(PersonField.name, name), name);
	}

	public void testReviewMerlinResourceTypeQuery() {
		final URI programId = programClient.create(programFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.reviewClient, reviewFactory, new ByProgramId(URIUtils.getIdValue(programId)),
                new DataServiceField(ReviewField.programId, programId), programId);

	}

	public void testTvSeasonMerlinResourceTypeQuery() {
		final URI seriesId = programClient.create(programFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster))).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.tvSeasonClient, tvSeasonFactory, new BySeriesId(URIUtils.getIdValue(seriesId)),
                new DataServiceField(TvSeasonField.seriesId, seriesId), seriesId);
	}

	public void testRelatedProgramMerlinResourceTypeQuery() {
		final URI sourceProgramId = programClient.create(programFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.relatedProgramClient, relatedProgramFactory, new BySourceProgramId(URIUtils.getIdValue(sourceProgramId)),
                new DataServiceField(RelatedProgramField.sourceProgramId, sourceProgramId), sourceProgramId);
	}

	public void testEntityCollectionMerlinResourceTypeQuery() {
		final String title = "entityCollection title " + random.nextInt();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.entityCollectionClient, entityCollectionFactory, new ByTitle(title),
                new DataServiceField(DataObjectField.title, title), title);
	}

	public void testTagMerlinResourceTypeQuery() {
		final String type = "Decade";
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.tagClient, tagFactory, new ByType(type), new DataServiceField(TagField.type, type), type);
	}

	public void testAwardMerlinResourceTypeQuery() {
		final String title = "award title " + random.nextInt();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.awardClient, awardFactory, new ByTitle(
                title),new DataServiceField(DataObjectField.title, title), title);
	}

	public void testInstitutionMerlinResourceTypeQuery() {
		final String title = "institution title " + random.nextInt();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.institutionClient, institutionFactory, new ByTitle(title),
                new DataServiceField(DataObjectField.title, title), title);
	}

	public void testAwardAssociationMerlinResourceTypeQuery() {
		final URI programId = programClient.create(programFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.awardAssociationClient, awardAssociationFactory, new com.theplatform.data.tv.entity.api.client.query.awardassociation.ByProgramId(URIUtils.getIdValue(programId)),
                new DataServiceField(AwardAssociationField.programId, programId), programId);

	}

	public void testAlbumMerlinResourceTypeQuery() {
		final String title = "album title " + random.nextInt();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.albumClient, albumFactory, new ByTitle(title), new DataServiceField(DataObjectField.title, title), title);
	}

	public void testAlbumCreditMerlinResourceTypeQuery() {
		final URI personId = personClient.create(personFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.albumCreditClient, albumCreditFactory, new com.theplatform.data.tv.entity.api.client.query.albumcredit.ByPersonId(URIUtils.getIdValue(personId)),
                new DataServiceField(AlbumCreditField.personId,personId), personId);
	}

	public void testAlbumReleaseMerlinResourceTypeQuery() {
		final String title = "albumRelease title " + random.nextInt();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.albumReleaseClient, albumReleaseFactory, new ByTitle(title),
                DataObjectField.title, title);
	}

	public void testSongMerlinResourceTypeQuery() {
		final String title = "song title " + random.nextInt();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.songClient, songFactory, new ByTitle(title),new DataServiceField(DataObjectField.title, title), title);
	}

	public void testSongCreditMerlinResourceTypeQuery() {
		final URI personId = personClient.create(personFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.songCreditClient, songCreditFactory, new com.theplatform.data.tv.entity.api.client.query.songcredit.ByPersonId(URIUtils.getIdValue(personId)),
                new DataServiceField(SongCreditField.personId,personId), personId);
	}

	public void testRelatedPersonMerlinResourceTypeQuery() {
		final URI sourcePersonId = personClient.create(personFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.relatedPersonClient, relatedPersonFactory, new BySourcePersonId(URIUtils.getIdValue(sourcePersonId)),
                new DataServiceField(RelatedPersonField.sourcePersonId, sourcePersonId), sourcePersonId);
	}

	public void testRelatedAlbumMerlinResourceTypeQuery() {
		final URI sourceAlbumId = albumClient.create(albumFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.relatedAlbumClient, relatedAlbumFactory, new BySourceAlbumId(URIUtils.getIdValue(sourceAlbumId)),new DataServiceField(
				RelatedAlbumField.sourceAlbumId, sourceAlbumId), sourceAlbumId);
	}

	public void testRelatedSongMerlinResourceTypeQuery() {
		final URI sourceSongId = songClient.create(songFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.relatedSongClient, relatedSongFactory, new BySourceSongId(URIUtils.getIdValue(sourceSongId)),new DataServiceField(RelatedSongField.sourceSongId,
				sourceSongId), sourceSongId);
	}

	public void testAlbumReleaseSongAssociationMerlinResourceTypeQuery() {
		final URI songId = songClient.create(songFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.albumReleaseSongAssociationClient, albumReleaseSongAssociationFactory,new BySongId(URIUtils.getIdValue(songId)),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, songId), songId);
	}

	public void testProgramSongAssociationMerlinResourceTypeQuery() {
		final URI songId = songClient.create(songFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.programSongAssociationClient, programSongAssociationFactory,new com.theplatform.data.tv.entity.api.client.query.programsongassociation.BySongId(URIUtils.getIdValue(songId)),
                new DataServiceField(ProgramSongAssociationField.songId, songId), songId);
	}

	public void testSongCollectionMerlinResourceTypeQuery() {
		final String title = "songCollection title " + random.nextInt();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.songCollectionClient, songCollectionFactory, new ByTitle(title), new DataServiceField(
				DataObjectField.title, title), title);
	}

	public void testTagAssociationMerlinResourceTypeQuery() {
		final URI tagId = tagClient.create(tagFactory.create()).getId();
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.tagAssociationClient, tagAssociationFactory,new ByTagId(URIUtils.getIdValue(tagId)), new DataServiceField(
				TagAssociationField.tagId, tagId), tagId);
	}

	public void testImageAssociationMerlinResourceTypeQuery() {
		final boolean isDefault = true;
		MerlinResourceTypeQueryTest.testMerlinResourceTypeQuery(this.imageAssociationClient, imageAssociationFactory, new ByIsDefault(isDefault), new DataServiceField(
				ImageAssociationField.isDefault, isDefault), isDefault);
	}
}
