package com.theplatform.data.tv.entity.integration.test.endpoint.credit;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import com.theplatform.data.tv.entity.api.test.CreditComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.net.URI;

/**
 * Created by kglikin on 7/22/14.
 */
@Test(groups = {"credit", "part_name"})
public class CreditPartNameIT extends EntityTestBase {

    @Test(groups = {TestGroup.gbTest}, dataProvider = "dataProviderTypesThatCanHavePartNames")
    public void createWithValidTypes(String creditType) {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();

        Credit credit = this.creditFactory.create(
                new DataServiceField(CreditField.personId, personId),
                new DataServiceField(CreditField.programId, programId),
                new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                new DataServiceField(CreditField.program, programAssociationFactory.create(programId))
        );



        credit.setType(creditType);
        credit.setPartName("Batman");
        Credit savedCredit = this.creditClient.create(credit, (String[]) null);
        CreditComparator.assertEquals(savedCredit, credit);
    }

    @Test(groups = {TestGroup.gbTest}, dataProvider = "dataProviderTypesThatCannotHavePartNames")
    public void createWithInValidTypes(String creditType) {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();

        Credit credit = this.creditFactory.create(
                new DataServiceField(CreditField.personId, personId),
                new DataServiceField(CreditField.programId, programId),
                new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                new DataServiceField(CreditField.program, programAssociationFactory.create(programId))
        );

        credit.setType(creditType);
        credit.setPartName("Batman");

        Credit savedCredit = this.creditClient.create(credit, (String[]) null);
        credit.setPartName(null);
        CreditComparator.assertEquals(savedCredit, credit);
    }

    @Test(groups = {TestGroup.gbTest}, dataProvider = "dataProviderTypesThatCanHavePartNames")
    public void updateWithValidTypes(String creditType) {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();

        Credit credit = this.creditFactory.create(
                new DataServiceField(CreditField.personId, personId),
                new DataServiceField(CreditField.programId, programId),
                new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                new DataServiceField(CreditField.program, programAssociationFactory.create(programId))
        );

        credit.setType("Actor");
        credit.setPartName("Batman");
        Credit savedCredit = this.creditClient.create(credit, (String[]) null);
        CreditComparator.assertEquals(savedCredit, credit);
        credit = savedCredit;
        credit.setType(creditType);
        savedCredit = this.creditClient.update(credit, (String[]) null);
        CreditComparator.assertEquals(savedCredit, credit);
    }

    @Test(groups = {TestGroup.gbTest}, dataProvider = "dataProviderTypesThatCannotHavePartNames")
    public void updateWithInValidTypes(String creditType) {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();

        Credit credit = this.creditFactory.create(
                new DataServiceField(CreditField.personId, personId),
                new DataServiceField(CreditField.programId, programId),
                new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                new DataServiceField(CreditField.program, programAssociationFactory.create(programId))
        );

        credit.setType("Actor");
        credit.setPartName("Batman");
        Credit savedCredit = this.creditClient.create(credit, (String[]) null);
        CreditComparator.assertEquals(savedCredit, credit);
        credit = savedCredit;
        credit.setType(creditType);
        savedCredit = this.creditClient.update(credit, (String[]) null);
        credit.setPartName(null);
        CreditComparator.assertEquals(savedCredit, credit);
    }

    @Test(groups = {TestGroup.gbTest}, dataProvider = "dataProviderTypesThatCanHavePartNames")
    public void createInvalidThenUpdateWithValidTypes(String creditType) {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();

        Credit credit = this.creditFactory.create(
                new DataServiceField(CreditField.personId, personId),
                new DataServiceField(CreditField.programId, programId),
                new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                new DataServiceField(CreditField.program, programAssociationFactory.create(programId))
        );

        credit.setType("Director");
        credit.setPartName("Batman");
        Credit savedCredit = this.creditClient.create(credit, (String[]) null);
        credit.setPartName(null);
        CreditComparator.assertEquals(savedCredit, credit);
        credit = savedCredit;
        credit.setType(creditType);
        credit.setPartName("Bruce Wayne");
        savedCredit = this.creditClient.update(credit, (String[]) null);
        CreditComparator.assertEquals(savedCredit, credit);
    }

    @Test(groups = {TestGroup.gbTest}, dataProvider = "dataProviderTypesThatCannotHavePartNames")
    public void createInvalidThenUpdateWithInValidTypes(String creditType) {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();

        Credit credit = this.creditFactory.create(
                new DataServiceField(CreditField.personId, personId),
                new DataServiceField(CreditField.programId, programId),
                new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                new DataServiceField(CreditField.program, programAssociationFactory.create(programId))
        );

        credit.setType("Director");
        credit.setPartName("Batman");
        Credit savedCredit = this.creditClient.create(credit, (String[]) null);
        credit.setPartName(null);
        CreditComparator.assertEquals(savedCredit, credit);
        credit = savedCredit;
        credit.setType(creditType);
        credit.setPartName("Bruce Wayne");
        savedCredit = this.creditClient.update(credit, (String[]) null);
        credit.setPartName(null);
        CreditComparator.assertEquals(savedCredit, credit);
    }

    @DataProvider(name = "dataProviderTypesThatCanHavePartNames")
    public Object[][] dataProviderTypesThatCanHavePartNames() {
        return new Object[][]{
                {"Actor"},
                {"Voice"},
                {"Reality Cast Member"},
                {"Performer"},
                {"Host"},
                {"Narrator"},
                {"Animal Actor"},
                {"Appearing"},
                {"Guest"}
        };
    }

    @DataProvider(name = "dataProviderTypesThatCannotHavePartNames")
    public Object[][] dataProviderTypesThatCannotHavePartNames() {
        return new Object[][]{
                {"Animation"},
                {"Technical Advisor"},
                {"Analyst"},
                {"Composer"},
                {"Casting"},
                {"Voice Casting"},
                {"Panelist"},
                {"Voice Director"}
        };
    }

}
