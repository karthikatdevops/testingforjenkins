package com.theplatform.data.tv.entity.integration.test.endpoint.programmediaassociation;

import com.theplatform.contrib.testing.client.ClientUtils;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociationMetadataManagementInfo;
import com.theplatform.data.tv.entity.api.test.ProgramMediaAssociationMetadataManagementInfoComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 6/27/14
 * Time: 11:21 PM
 * To change this template use File | Settings | File Templates.
 */

    @Test(groups = { "programMediaAssociation", TestGroup.gbTest})
    public class ProgramMediaAssociationMmiIT extends EntityTestBase {

        public void testProgramMediaAssociationCreateWithAPmammi() {

            ProgramMediaAssociationMetadataManagementInfo pmaMmi = new ProgramMediaAssociationMetadataManagementInfo();
            List<String> categoryPathsToAppend = Arrays.asList("Movies/First", "Movies/Second");
            List<String> categoryPathsToRemove = Arrays.asList("Movies/Third");

            pmaMmi.setAppendCategoryPaths(categoryPathsToAppend);
            pmaMmi.setRemoveCategoryPaths(categoryPathsToRemove);

            ProgramMediaAssociation pma = programMediaAssociationFactory.create();
            pma.setMetadataManagementInfo(pmaMmi);
            ProgramMediaAssociation createdPma = this.programMediaAssociationClient.create(pma, new String[]{});
            ProgramMediaAssociationMetadataManagementInfoComparator.assertEquals(createdPma.getMetadataManagementInfo(), pmaMmi);
        }

        public void testProgramMediaAssociationUpdateWithAPmammi() {
            ProgramMediaAssociationMetadataManagementInfo pmaMmi = new ProgramMediaAssociationMetadataManagementInfo();
            List<String> categoryPathsToAppend = Arrays.asList("Movies/First","Movies/Seconds");
            List<String> categoryPathsToRemove = Arrays.asList("Movies/Third");

            pmaMmi.setAppendCategoryPaths(categoryPathsToAppend);
            pmaMmi.setRemoveCategoryPaths(categoryPathsToRemove);

            ProgramMediaAssociation pma = programMediaAssociationFactory.create();
            pma.setMetadataManagementInfo(pmaMmi);
            ProgramMediaAssociation createdPma = this.programMediaAssociationClient.create(pma, ClientUtils.ALL_FIELDS);
            ProgramMediaAssociationMetadataManagementInfoComparator.assertEquals(createdPma.getMetadataManagementInfo(), pmaMmi);

            createdPma.setMetadataManagementInfo(pmaMmi);

            ProgramMediaAssociation updatedPma = this.programMediaAssociationClient.update(createdPma, ClientUtils.ALL_FIELDS);
            ProgramMediaAssociationMetadataManagementInfoComparator.assertEquals(updatedPma.getMetadataManagementInfo(), pmaMmi);
        }
    }

