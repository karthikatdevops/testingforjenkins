package com.theplatform.data.tv.entity.integration.test.endpoint.albumrelease;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.fields.AlbumField;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.not;

/**
 * This test (and others like it) is meant to validate that the AlbumRelease client does not return
 * denormalized entities (from associated endpoints) that are marked (have their MRT set to something)
 * other than AudienceAvailable
 * <p/>
 * Author: Vincent Fumo (vfumo) : vincent_fumo@cable.comcast.com
 * Created Date: 3/13/14
 */
@Test(groups = {"albumRelease", "denormalizedFields", TestGroup.gbTest})
public class AlbumReleaseDenormalizedFieldsIT extends EntityTestBase {

    public void gettingAnAlbumReleaseShouldNotReturnNonAATagAssociations() {
        AlbumRelease entity = albumReleaseFactory.create();
        albumReleaseClient.create(entity);
        URI entityId = entity.getId();

        TagAssociation relatedEntity = tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId,entityId));
        relatedEntity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        tagAssociationClient.create(relatedEntity);
        URI relatedEntityId = relatedEntity.getTagId();

        // 1) make sure that we get the relatedEntity (since it's AA)
        AlbumRelease retrievedEntity = albumReleaseClient.get(entityId, new String[]{AlbumReleaseField.tagIds.name()});
        List<URI> ids = retrievedEntity.getTagIds();
        assertThat(ids, hasItem(relatedEntityId));

        // 2) change the relatedEntity to be non AA
        relatedEntity.setMerlinResourceType(MerlinResourceType.Inactive);
        tagAssociationClient.update(relatedEntity);

        // 3) validate that the relatedEntity doesn't return
        // note: we change the fields returned so we aren't dealing with a stale cache
        retrievedEntity = albumReleaseClient.get(entityId, new String[]{AlbumField.merlinResourceType.name(), AlbumField.tagIds.name()});
        ids = retrievedEntity.getTagIds();
        assertThat(ids, not(hasItem(relatedEntityId)));
    }
}
