package com.theplatform.data.tv.entity.integration.test.endpoint.relatedsong;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.tv.entity.api.fields.RelatedSongField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.relatedsong.BySourceSongId;
import com.theplatform.data.tv.entity.api.client.query.relatedsong.ByTargetSongId;
import com.theplatform.data.tv.entity.api.data.objects.RelatedSong;
import com.theplatform.data.tv.entity.api.test.RelatedSongComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "relatedSong", "query" })
public class RelatedSongQueryIT extends EntityTestBase {

	public void testRelatedSongQueryBySourceSongIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedSongClient.create(this.relatedSongFactory.create());
		Query[] queries = new Query[] { new BySourceSongId(URIUtils.getIdValue(songClient.create(songFactory.create()).getId())) };
		Feed<RelatedSong> results = this.relatedSongClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedSong should be found");
	}

	public void testRelatedSongQueryBySourceSongIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI songId = songClient.create(songFactory.create()).getId();
		RelatedSong expected = this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.sourceSongId, songId)), new String[] {});
		this.relatedSongClient.create(this.relatedSongFactory.create());

		Query[] queries = new Query[] { new BySourceSongId(URIUtils.getIdValue(songId)) };
		Feed<RelatedSong> results = this.relatedSongClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedSong should be found");

		RelatedSongComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedSongQueryBySourceSongIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId = songClient.create(songFactory.create()).getId();
		this.relatedSongClient.create(this.relatedSongFactory.create());

		List<RelatedSong> expectedRelatedSongs = this.relatedSongClient.create(this.relatedSongFactory.create(2, new DataServiceField(RelatedSongField.sourceSongId, songId)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySourceSongId(URIUtils.getIdValue(songId)) };
		Feed<RelatedSong> results = this.relatedSongClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedSongs should be found");

		Map<URI, RelatedSong> resultMap = new HashMap<>();
		for (RelatedSong relatedSong : results.getEntries())
			resultMap.put(relatedSong.getId(), relatedSong);

		for (RelatedSong expected : expectedRelatedSongs)
			RelatedSongComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testRelatedSongQueryByTargetSongIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedSongClient.create(this.relatedSongFactory.create());
		Query[] queries = new Query[] { new ByTargetSongId(URIUtils.getIdValue(songClient.create(songFactory.create()).getId())) };
		Feed<RelatedSong> results = this.relatedSongClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedSong should be found");
	}

	public void testRelatedSongQueryByTargetSongIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI songId = songClient.create(songFactory.create()).getId();
		RelatedSong expected = this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.targetSongId, songId)), new String[] {});
		this.relatedSongClient.create(this.relatedSongFactory.create());

		Query[] queries = new Query[] { new ByTargetSongId(URIUtils.getIdValue(songId)) };
		Feed<RelatedSong> results = this.relatedSongClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedSong should be found");

		RelatedSongComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedSongQueryByTargetSongIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId = songClient.create(songFactory.create()).getId();
		this.relatedSongClient.create(this.relatedSongFactory.create());

		List<RelatedSong> expectedRelatedSongs = this.relatedSongClient.create(this.relatedSongFactory.create(2, new DataServiceField(RelatedSongField.targetSongId, songId)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByTargetSongId(URIUtils.getIdValue(songId)) };
		Feed<RelatedSong> results = this.relatedSongClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedSongs should be found");

		Map<URI, RelatedSong> resultMap = new HashMap<>();
		for (RelatedSong relatedSong : results.getEntries())
			resultMap.put(relatedSong.getId(), relatedSong);

		for (RelatedSong expected : expectedRelatedSongs)
			RelatedSongComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	// Only one type which is also required

	public void testRelatedSongQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<RelatedSong> results = this.relatedSongClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedSong should be found");
	}

	public void testRelatedSongQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		RelatedSong expected = this.relatedSongClient.create(
				this.relatedSongFactory.create(new DataServiceField(RelatedSongField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {});
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.merlinResourceType, MerlinResourceType.Editorial)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<RelatedSong> results = this.relatedSongClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedSong should be found");

		RelatedSongComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedSongQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.merlinResourceType, MerlinResourceType.Editorial)));
		List<RelatedSong> expectedRelatedSongs = this.relatedSongClient.create(
				this.relatedSongFactory.create(2, new DataServiceField(RelatedSongField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {})
				.getEntries();
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<RelatedSong> results = this.relatedSongClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedSongs should be found");

		Map<URI, RelatedSong> resultMap = new HashMap<>();
		for (RelatedSong relatedSong : results.getEntries()) {
			resultMap.put(relatedSong.getId(), relatedSong);
		}

		for (RelatedSong expected : expectedRelatedSongs)
			RelatedSongComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

}
