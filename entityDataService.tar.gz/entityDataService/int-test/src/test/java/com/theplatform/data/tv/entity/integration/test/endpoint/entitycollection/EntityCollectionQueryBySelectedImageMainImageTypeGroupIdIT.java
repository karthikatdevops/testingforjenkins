package com.theplatform.data.tv.entity.integration.test.endpoint.entitycollection;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import com.theplatform.data.api.NamespacedField;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.ById;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.client.query.BySelectedImageMainImageTypeGroupId;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.image.api.data.objects.MainImageTypeGroup;
import com.theplatform.data.tv.image.api.fields.MainImageFileField;
import com.theplatform.data.tv.image.api.fields.MainImageTypeField;

@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
@Test(groups = { "entityCollection", "query", TestGroup.gbTest })
public class EntityCollectionQueryBySelectedImageMainImageTypeGroupIdIT extends EntityTestBase {


	private final String ENTITY_COLLECTION_TITLE = "entityCollection title for bySelectedImageMainImageTypeGroupId test ".concat("" + new Random().nextInt());
	private List<URI> mainImageTypeGroupIds;

	private List<URI> mainImageTypeIds;

	private EntityCollection entity1, entity2;


	/**
	 * P:EntityCollection T:MainImageType G:MainImageTypeGroup
	 * 
	 * Creating P1:T1(G0,G1), T2(G0,G1,G2), T3(G0,G3,G4,G5) Creating
	 * P2:T4(G0,G5), T5(G0,G5,G6), T6(G0,G7,G8) Creating G9 (For no match case)
	 * 
	 */
	@BeforeClass(alwaysRun = true)
	public void setUp() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, ClassNotFoundException,
			InstantiationException, NoSuchMethodException, NoSuchFieldException {
		mainImageTypeGroupIds = new ArrayList<>();

		Feed<MainImageTypeGroup> mainImageTypeGroups = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(10));
		for (MainImageTypeGroup group : mainImageTypeGroups.getEntries())
			mainImageTypeGroupIds.add(group.getId());

		mainImageTypeIds = new ArrayList<>();

		// T1
		mainImageTypeIds.add(createMainImageTypeWithGroupIds(mainImageTypeGroupIds.get(0), mainImageTypeGroupIds.get(1)));
		// T2
		mainImageTypeIds.add(createMainImageTypeWithGroupIds(mainImageTypeGroupIds.get(0), mainImageTypeGroupIds.get(1), mainImageTypeGroupIds.get(2)));
		// T3
		mainImageTypeIds.add(createMainImageTypeWithGroupIds(mainImageTypeGroupIds.get(0), mainImageTypeGroupIds.get(3), mainImageTypeGroupIds.get(4),
				mainImageTypeGroupIds.get(5)));
		// T4
		mainImageTypeIds.add(createMainImageTypeWithGroupIds(mainImageTypeGroupIds.get(0), mainImageTypeGroupIds.get(5)));
		// T5
		mainImageTypeIds.add(createMainImageTypeWithGroupIds(mainImageTypeGroupIds.get(0), mainImageTypeGroupIds.get(5), mainImageTypeGroupIds.get(6)));
		// T6
		mainImageTypeIds.add(createMainImageTypeWithGroupIds(mainImageTypeGroupIds.get(0), mainImageTypeGroupIds.get(7), mainImageTypeGroupIds.get(8)));

		entity1 = this.entityCollectionClient.create(entityCollectionFactory.create(new DataServiceField(DataObjectField.title, ENTITY_COLLECTION_TITLE)));
		entity2 = this.entityCollectionClient.create(entityCollectionFactory.create(new DataServiceField(DataObjectField.title, ENTITY_COLLECTION_TITLE)));

		// Associating mainImageTypes with entityCollections
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entity1.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageTypeIds.get(0))));
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entity1.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageTypeIds.get(1))));
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entity1.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageTypeIds.get(2))));
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entity2.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageTypeIds.get(3))));
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entity2.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageTypeIds.get(4))));
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entity2.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageTypeIds.get(5))));

		entity1 = this.entityCollectionClient.get(entity1.getId(), new String[] {});
		entity2 = this.entityCollectionClient.get(entity2.getId(), new String[] {});

	}

	/**
	 * G6:None
	 */
	public void testEntityCollectionQueryOneEntityCollectionBySelectedImageMainImageTypeGroupIdNoMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = new Query[] { new ById(URIUtils.getIdValue(entity1.getId())),
				new BySelectedImageMainImageTypeGroupId(URIUtils.getIdValue(mainImageTypeGroupIds.get(6))) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().size(), 0, "No mainImageInfo(from mainImageType) should be found");

	}

	/**
	 * G3:T3
	 */
	public void testEntityCollectionQueryOneEntityCollectionBySelectedImageMainImageTypeGroupIdOneMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = new Query[] { new ById(URIUtils.getIdValue(entity1.getId())),
				new BySelectedImageMainImageTypeGroupId(URIUtils.getIdValue(mainImageTypeGroupIds.get(3))) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);

		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().size(), 1, "Only 1 mainImageInfo(from mainImageType) should be found");
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().get(0).getMainImageTypeId(), mainImageTypeIds.get(2));
	}

	/**
	 * G1:T1, T2
	 */
	public void testEntityCollectionQueryOneEntityCollectionBySelectedImageMainImageTypeGroupIdMultipleMatches() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = new Query[] { new ById(URIUtils.getIdValue(entity1.getId())),
				new BySelectedImageMainImageTypeGroupId(URIUtils.getIdValue(mainImageTypeGroupIds.get(1))) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().size(), 2, "2 mainImageInfo(from mainImageType) should be found");
		Set<URI> typeIds = new HashSet<>();
		typeIds.add(mainImageTypeIds.get(0));
		typeIds.add(mainImageTypeIds.get(1));
		Assert.assertEquals(typeIds.size(), 2);
		Assert.assertTrue(typeIds.contains(retrievedEntityCollections.getEntries().get(0).getSelectedImages().get(0).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(retrievedEntityCollections.getEntries().get(0).getSelectedImages().get(1).getMainImageTypeId()));
	}

	/**
	 * G6, G7:None
	 */

	public void testEntityCollectionQueryOneEntityCollectionBySelectedImageMainImageTypeGroupIdListNoneMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = new Query[] {
				new ById(URIUtils.getIdValue(entity1.getId())),
				new BySelectedImageMainImageTypeGroupId(Arrays.asList(URIUtils.getIdValue(mainImageTypeGroupIds.get(6)),
						URIUtils.getIdValue(mainImageTypeGroupIds.get(7)))) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().size(), 0, "0 mainImageInfo(from mainImageType) should be found");
	}

	/**
	 * G2, G3:T2, T3
	 */
	public void testEntityCollectionQueryOneEntityCollectionBySelectedImageMainImageTypeGroupIdListMultipleMatches() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = createQueries(entity1.getId(), mainImageTypeGroupIds.get(2), mainImageTypeGroupIds.get(3));
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().size(), 2, "2 mainImageInfo(from mainImageType) should be found");
		Set<URI> typeIds = new HashSet<>();
		typeIds.add(mainImageTypeIds.get(1));
		typeIds.add(mainImageTypeIds.get(2));
		Assert.assertTrue(typeIds.contains(retrievedEntityCollections.getEntries().get(0).getSelectedImages().get(0).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(retrievedEntityCollections.getEntries().get(0).getSelectedImages().get(1).getMainImageTypeId()));
	}

	/**
	 * G2, G6:T2
	 */
	public void testEntityCollectionQueryOneEntityCollectionBySelectedImageMainImageTypeGroupIdListOneMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = createQueries(entity1.getId(), mainImageTypeGroupIds.get(2), mainImageTypeGroupIds.get(6));
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().size(), 1, "1 mainImageInfo(from mainImageType) should be found");
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().get(0).getMainImageTypeId(), mainImageTypeIds.get(1));
	}

	/**
	 * G0:T1,T2,T3
	 */
	public void testEntityCollectionQueryOneEntityCollectionBySelectedImageMainImageTypeGroupIdAllMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = createQueries(entity1.getId(), mainImageTypeGroupIds.get(0));
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().size(), 3, "3 mainImageInfo(from mainImageType) should be found");

		Set<URI> typeIds = new HashSet<>();
		typeIds.add(mainImageTypeIds.get(0));
		typeIds.add(mainImageTypeIds.get(1));
		typeIds.add(mainImageTypeIds.get(2));
		Assert.assertTrue(typeIds.contains(retrievedEntityCollections.getEntries().get(0).getSelectedImages().get(0).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(retrievedEntityCollections.getEntries().get(0).getSelectedImages().get(1).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(retrievedEntityCollections.getEntries().get(0).getSelectedImages().get(2).getMainImageTypeId()));
	}

	/**
	 * No selectedImageMainImageTypeGroupId query:None by default
	 */
	public void testEntityCollectionQueryOneEntityCollectionNoBySelectedImageMainImageTypeGroupIdAllMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = new Query[] { new ById(URIUtils.getIdValue(entity1.getId())) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().size(), 0, "0 mainImageInfo(from mainImageType) should be found");
	}

	/**
	 * G9:None
	 */
	public void testEntityCollectionQueryTwoEntityCollectionsBySelectedImageMainImageTypeGroupIdNoMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = createQueriesByTitle(ENTITY_COLLECTION_TITLE, mainImageTypeGroupIds.get(9));
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(0).getSelectedImages().size(), 0, "No mainImageInfo(from mainImageType) should be found");
		Assert.assertEquals(retrievedEntityCollections.getEntries().get(1).getSelectedImages().size(), 0, "No mainImageInfo(from mainImageType) should be found");
	}

	/**
	 * G2:T2
	 */
	public void testEntityCollectionQueryTwoEntityCollectionsBySelectedImageMainImageTypeGroupIdOneMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = createQueriesByTitle(ENTITY_COLLECTION_TITLE, mainImageTypeGroupIds.get(2));
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		EntityCollection entityCollection1 = retrievedEntityCollections.getEntries().get(0).equals(entity1.getId()) ? retrievedEntityCollections.getEntries().get(0) : retrievedEntityCollections
				.getEntries().get(1);
		EntityCollection entityCollection2 = retrievedEntityCollections.getEntries().get(1).equals(entity2.getId()) ? retrievedEntityCollections.getEntries().get(1) : retrievedEntityCollections
				.getEntries().get(0);
		Assert.assertEquals(entityCollection1.getSelectedImages().size(), 1, "One mainImageInfo(from mainImageType) should be found");
		Assert.assertEquals(entityCollection1.getSelectedImages().get(0).getMainImageTypeId(), mainImageTypeIds.get(1));
		Assert.assertEquals(entityCollection2.getSelectedImages().size(), 0, "0 mainImageInfo(from mainImageType) should be found");
	}

	/**
	 * G5:T3,T4,T5
	 */
	public void testEntityCollectionQueryTwoEntityCollectionsBySelectedImageMainImageTypeGroupIdMultipleMatches() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = createQueriesByTitle(ENTITY_COLLECTION_TITLE, mainImageTypeGroupIds.get(5));
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		EntityCollection entityCollection1 = retrievedEntityCollections.getEntries().get(0).equals(entity1.getId()) ? retrievedEntityCollections.getEntries().get(0) : retrievedEntityCollections
				.getEntries().get(1);
		EntityCollection entityCollection2 = retrievedEntityCollections.getEntries().get(1).equals(entity2.getId()) ? retrievedEntityCollections.getEntries().get(1) : retrievedEntityCollections
				.getEntries().get(0);
		Assert.assertEquals(entityCollection1.getSelectedImages().size(), 1, "One mainImageInfo(from mainImageType) should be found");
		Assert.assertEquals(entityCollection1.getSelectedImages().get(0).getMainImageTypeId(), mainImageTypeIds.get(2));
		Assert.assertEquals(entityCollection2.getSelectedImages().size(), 2, "Two mainImageInfo(from mainImageType) should be found");
		Set<URI> typeIds = new HashSet<>();
		typeIds.add(mainImageTypeIds.get(3));
		typeIds.add(mainImageTypeIds.get(4));
		// make sure all mainImageTypeIds in this set are different
		Assert.assertEquals(typeIds.size(), 2);
		Assert.assertTrue(typeIds.contains(entityCollection2.getSelectedImages().get(0).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(entityCollection2.getSelectedImages().get(1).getMainImageTypeId()));
	}

	/**
	 * G2,G5:T2,T3,T4,T5
	 */
	public void testEntityCollectionQueryTwoEntityCollectionsBySelectedImageMainImageTypeGroupIdListMultipleMatches() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = createQueriesByTitle(ENTITY_COLLECTION_TITLE, mainImageTypeGroupIds.get(2), mainImageTypeGroupIds.get(5));
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		EntityCollection entityCollection1 = retrievedEntityCollections.getEntries().get(0).equals(entity1.getId()) ? retrievedEntityCollections.getEntries().get(0) : retrievedEntityCollections
				.getEntries().get(1);
		EntityCollection entityCollection2 = retrievedEntityCollections.getEntries().get(1).equals(entity2.getId()) ? retrievedEntityCollections.getEntries().get(1) : retrievedEntityCollections
				.getEntries().get(0);

		Assert.assertEquals(entityCollection1.getSelectedImages().size(), 2, "Two mainImageInfo(from mainImageType) should be found");

		Set<URI> typeIds = new HashSet<>();
		typeIds.add(mainImageTypeIds.get(1));
		typeIds.add(mainImageTypeIds.get(2));
		Assert.assertTrue(typeIds.contains(entityCollection1.getSelectedImages().get(0).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(entityCollection1.getSelectedImages().get(1).getMainImageTypeId()));
		Assert.assertNotEquals(entityCollection1.getSelectedImages().get(0).getMainImageTypeId(), entityCollection1.getSelectedImages().get(1).getMainImageTypeId());

		Assert.assertEquals(entityCollection2.getSelectedImages().size(), 2, "Two mainImageInfo(from mainImageType) should be found");
		typeIds = new HashSet<>();
		typeIds.add(mainImageTypeIds.get(3));
		typeIds.add(mainImageTypeIds.get(4));
		Assert.assertTrue(typeIds.contains(entityCollection2.getSelectedImages().get(0).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(entityCollection2.getSelectedImages().get(1).getMainImageTypeId()));
		Assert.assertNotEquals(entityCollection2.getSelectedImages().get(0).getMainImageTypeId(), entityCollection2.getSelectedImages().get(1).getMainImageTypeId());
	}

	/**
	 * G7,G9:T6
	 */
	public void testEntityCollectionQueryTwoEntityCollectionsBySelectedImageMainImageTypeGroupIdListOneMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = createQueriesByTitle(ENTITY_COLLECTION_TITLE, mainImageTypeGroupIds.get(7), mainImageTypeGroupIds.get(9));
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);

		EntityCollection entityCollection1 = retrievedEntityCollections.getEntries().get(0).equals(entity1.getId()) ? retrievedEntityCollections.getEntries().get(0) : retrievedEntityCollections
				.getEntries().get(1);
		EntityCollection entityCollection2 = retrievedEntityCollections.getEntries().get(1).equals(entity2.getId()) ? retrievedEntityCollections.getEntries().get(1) : retrievedEntityCollections
				.getEntries().get(0);

		Assert.assertEquals(entityCollection1.getSelectedImages().size(), 0, "None mainImageInfo(from mainImageType) should be found");
		Assert.assertEquals(entityCollection2.getSelectedImages().size(), 1, "One mainImageInfo(from mainImageType) should be found");
		Assert.assertEquals(entityCollection2.getSelectedImages().get(0).getMainImageTypeId(), mainImageTypeIds.get(5));
	}

	/**
	 * G0:T1, T2, T3, T4, T5, T6
	 */
	public void testEntityCollectionQueryTwoEntityCollectionsBySelectedImageMainImageTypeGroupIdAllMatch() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Query queries[] = createQueriesByTitle(ENTITY_COLLECTION_TITLE, mainImageTypeGroupIds.get(0));
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		EntityCollection entityCollection1 = retrievedEntityCollections.getEntries().get(0).equals(entity1.getId()) ? retrievedEntityCollections.getEntries().get(0) : retrievedEntityCollections
				.getEntries().get(1);
		EntityCollection entityCollection2 = retrievedEntityCollections.getEntries().get(1).equals(entity2.getId()) ? retrievedEntityCollections.getEntries().get(1) : retrievedEntityCollections
				.getEntries().get(0);

		Assert.assertEquals(entityCollection1.getSelectedImages().size(), 3, "Three mainImageInfo(from mainImageType) should be found");
		Set<URI> typeIds = new HashSet<>();
		typeIds.add(mainImageTypeIds.get(0));
		typeIds.add(mainImageTypeIds.get(1));
		typeIds.add(mainImageTypeIds.get(2));
		// all ids are different
		Assert.assertEquals(typeIds.size(), 3);
		Assert.assertTrue(typeIds.contains(entityCollection1.getSelectedImages().get(0).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(entityCollection1.getSelectedImages().get(1).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(entityCollection1.getSelectedImages().get(2).getMainImageTypeId()));

		Assert.assertEquals(entityCollection2.getSelectedImages().size(), 3, "Three mainImageInfo(from mainImageType) should be found");
		typeIds = new HashSet<>();
		typeIds.add(mainImageTypeIds.get(3));
		typeIds.add(mainImageTypeIds.get(4));
		typeIds.add(mainImageTypeIds.get(5));
		// all ids are different
		Assert.assertEquals(typeIds.size(), 3);
		Assert.assertTrue(typeIds.contains(entityCollection2.getSelectedImages().get(0).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(entityCollection2.getSelectedImages().get(1).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(entityCollection2.getSelectedImages().get(2).getMainImageTypeId()));
	}

	/**
	 * G9:None. Then add G9 to T1. G9:T1
	 */
	public void testEntityCollectionQueryBySelectedImageMainImageTypeGroupIdQueryAfterAddingMainImageTypeGroup() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		EntityCollection entityCollection = entityCollectionClient.create(entityCollectionFactory.create(), new String[] {});
		URI groupId = mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId();
		MainImageType mainImageType = this.mainImageTypeClient.create(mainImageTypeFactory.create(), new String[] {});
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entityCollection.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageType.getId())));
		Query queries[] = createQueries(entityCollection.getId(), groupId);
		Feed<EntityCollection> result = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(result.getEntries().get(0).getSelectedImages().size(), 0);

		mainImageType.setMainImageTypeGroupIds(Arrays.asList(groupId));
		mainImageTypeClient.update(mainImageType);

		entityCollection.setTitle(entityCollection.getTitle().concat(" updated"));
		entityCollection.setVersion(null);
		entityCollection.setUpdated(null);
		entityCollection.setUpdatedByUserId(null);
		entityCollectionClient.update(entityCollection);

		result = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(result.getEntries().get(0).getSelectedImages().size(), 1);
		Assert.assertEquals(result.getEntries().get(0).getSelectedImages().get(0).getMainImageTypeId(), mainImageType.getId());
	}

	/**
	 * G9:T1. Then Remove G9 to T1. G9:None
	 */
	public void testEntityCollectionQueryBySelectedImageMainImageTypeGroupIdQueryAfterRemovingMainImageTypeGroup() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		EntityCollection entityCollection = entityCollectionClient.create(entityCollectionFactory.create(), new String[] {});
		URI groupId = mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId();
		MainImageType mainImageType = this.mainImageTypeClient.create(
				mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupId))), new String[] {});
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entityCollection.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageType.getId())));
		Query queries[] = createQueries(entityCollection.getId(), groupId);
		Feed<EntityCollection> result = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(result.getEntries().get(0).getSelectedImages().size(), 1);
		Assert.assertEquals(result.getEntries().get(0).getSelectedImages().get(0).getMainImageTypeId(), mainImageType.getId());

        mainImageType.setMainImageTypeGroupIds(null);
        mainImageType.setNullFields(new NamespacedField[]{MainImageTypeField.mainImageTypeGroupIds});
		mainImageTypeClient.update(mainImageType);

		entityCollection.setTitle(entityCollection.getTitle().concat(" updated"));
		entityCollection.setVersion(null);
		entityCollection.setUpdated(null);
		entityCollection.setUpdatedByUserId(null);
		entityCollectionClient.update(entityCollection);

		result = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(result.getEntries().get(0).getSelectedImages().size(), 0);
	}

	/**
	 * G1:T1, T2. Then remove G1 from T2. G1:T1.
	 */
	public void testEntityCollectionQueryBySelectedImageMainImageTypeGroupIdQueryAfterRemovingOneOfMainImageTypeGroups() throws IllegalArgumentException,
			SecurityException, IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException,
			NoSuchFieldException {
		EntityCollection entityCollection = entityCollectionClient.create(entityCollectionFactory.create(), new String[] {});
		URI groupId = mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId();
		MainImageType mainImageType1 = this.mainImageTypeClient.create(
				mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupId))), new String[] {});
		MainImageType mainImageType2 = this.mainImageTypeClient.create(
				mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupId))), new String[] {});
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entityCollection.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageType1.getId())));
		mainImageFileClient.create(mainImageFileFactory.create(new DataServiceField(MainImageFileField.entityId, entityCollection.getId()), new DataServiceField(
				MainImageFileField.mainImageTypeId, mainImageType2.getId())));
		Query queries[] = createQueries(entityCollection.getId(), groupId);
		Feed<EntityCollection> result = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(result.getEntries().get(0).getSelectedImages().size(), 2);
		Set<URI> typeIds = new HashSet<>();
		typeIds.add(mainImageType1.getId());
		typeIds.add(mainImageType2.getId());
		Assert.assertEquals(typeIds.size(), 2);
		Assert.assertTrue(typeIds.contains(result.getEntries().get(0).getSelectedImages().get(0).getMainImageTypeId()));
		Assert.assertTrue(typeIds.contains(result.getEntries().get(0).getSelectedImages().get(1).getMainImageTypeId()));

        mainImageType2.setMainImageTypeGroupIds(null);
        mainImageType2.setNullFields(new NamespacedField[]{MainImageTypeField.mainImageTypeGroupIds});
		mainImageType2.setVersion(null);
		mainImageTypeClient.update(mainImageType2);

		entityCollection.setTitle(entityCollection.getTitle().concat(" updated"));
		entityCollection.setVersion(null);
		entityCollection.setUpdated(null);
		entityCollection.setUpdatedByUserId(null);
		entityCollectionClient.update(entityCollection);

		result = this.entityCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(result.getEntries().get(0).getSelectedImages().size(), 1);
		Assert.assertEquals(result.getEntries().get(0).getSelectedImages().get(0).getMainImageTypeId(), mainImageType1.getId());
	}

	private URI createMainImageTypeWithGroupIds(URI... groupIds) throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		return this.mainImageTypeClient.create(
				mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.entityType, "EntityCollection"),new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupIds)))).getId();
	}

	private Query[] createQueries(URI entityCollectionId, URI... mainImageTypeGroupIds) {
		if (mainImageTypeGroupIds.length == 1) {
			return new Query[] { new ById(URIUtils.getIdValue(entityCollectionId)),
					new BySelectedImageMainImageTypeGroupId(URIUtils.getIdValue(mainImageTypeGroupIds[0])) };
		} else {
			Long[] groupIds = new Long[mainImageTypeGroupIds.length];
			for (int i = 0; i < mainImageTypeGroupIds.length; i++)
				groupIds[i] = URIUtils.getIdValue(mainImageTypeGroupIds[i]);
			return new Query[] { new ById(URIUtils.getIdValue(entity1.getId())), new BySelectedImageMainImageTypeGroupId(Arrays.asList(groupIds)) };
		}
	}

	private Query[] createQueriesByTitle(String entityCollectionName, URI... mainImageTypeGroupIds) {
		if (mainImageTypeGroupIds.length == 1) {
			return new Query[] { new ByTitle(entityCollectionName), new BySelectedImageMainImageTypeGroupId(URIUtils.getIdValue(mainImageTypeGroupIds[0])) };
		} else {
			Long[] groupIds = new Long[mainImageTypeGroupIds.length];
			for (int i = 0; i < mainImageTypeGroupIds.length; i++)
				groupIds[i] = URIUtils.getIdValue(mainImageTypeGroupIds[i]);
			return new Query[] { new ByTitle(entityCollectionName), new BySelectedImageMainImageTypeGroupId(Arrays.asList(groupIds)) };
		}
	}
}
