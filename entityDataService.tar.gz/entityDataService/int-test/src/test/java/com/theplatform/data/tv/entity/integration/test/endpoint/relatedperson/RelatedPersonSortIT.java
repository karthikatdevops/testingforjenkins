package com.theplatform.data.tv.entity.integration.test.endpoint.relatedperson;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPerson;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPersonType;
import com.theplatform.data.tv.entity.api.fields.RelatedPersonField;
import com.theplatform.data.tv.entity.api.test.RelatedPersonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "relatedPerson", "sort" })
public class RelatedPersonSortIT extends EntityTestBase {

	public void testRelatedPersonSortById() {

		List<RelatedPerson> relatedPersons = this.relatedPersonFactory.create(4);

		Long id1 = this.objectIdProvider.nextId(), id2 = this.objectIdProvider.nextId(), id3 = this.objectIdProvider.nextId(), id4 = this.objectIdProvider
				.nextId();

		Assert.assertTrue(id1 < id2);
		Assert.assertTrue(id2 < id3);
		Assert.assertTrue(id3 < id4);

		relatedPersons.get(3).setId(URI.create(this.getBaseUrl().concat("/data/RelatedPerson/" + id1)));
		relatedPersons.get(0).setId(URI.create(this.getBaseUrl().concat("/data/RelatedPerson/" + id2)));
		relatedPersons.get(1).setId(URI.create(this.getBaseUrl().concat("/data/RelatedPerson/" + id3)));
		relatedPersons.get(2).setId(URI.create(this.getBaseUrl().concat("/data/RelatedPerson/" + id4)));

		relatedPersons.set(3, this.relatedPersonClient.create(relatedPersons.get(3), new String[] {}));
		relatedPersons.set(0, this.relatedPersonClient.create(relatedPersons.get(0), new String[] {}));
		relatedPersons.set(1, this.relatedPersonClient.create(relatedPersons.get(1), new String[] {}));
		relatedPersons.set(2, this.relatedPersonClient.create(relatedPersons.get(2), new String[] {}));

		List<RelatedPerson> expected = new ArrayList<>(relatedPersons.size());
		expected.add(relatedPersons.get(3));
		expected.add(relatedPersons.get(0));
		expected.add(relatedPersons.get(1));
		expected.add(relatedPersons.get(2));

		Sort requestSort = new Sort(DataObjectField.id.getLocalName(), false);
		Feed<RelatedPerson> actual = this.relatedPersonClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		RelatedPersonComparator.assertEquals(actual, expected);
	}

	public void testRelatedPersonSortBySourcePersonId() {
		final URI personId1 = this.personClient.create(this.personFactory.create()).getId();
		final URI personId2 = this.personClient.create(this.personFactory.create()).getId();
		final URI personId3 = this.personClient.create(this.personFactory.create()).getId();
		final URI personId4 = this.personClient.create(this.personFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(personId1) < URIUtils.getIdValue(personId2));
		Assert.assertTrue(URIUtils.getIdValue(personId2) < URIUtils.getIdValue(personId3));
		Assert.assertTrue(URIUtils.getIdValue(personId3) < URIUtils.getIdValue(personId4));

		List<RelatedPerson> relatedPersons = this.relatedPersonFactory.create(4);
		relatedPersons.get(0).setSourcePersonId(personId1);
		relatedPersons.get(3).setSourcePersonId(personId2);
		relatedPersons.get(1).setSourcePersonId(personId3);
		relatedPersons.get(2).setSourcePersonId(personId4);

		this.relatedPersonClient.create(relatedPersons);

		List<RelatedPerson> expected = new ArrayList<>(relatedPersons.size());
		expected.add(relatedPersons.get(0));
		expected.add(relatedPersons.get(3));
		expected.add(relatedPersons.get(1));
		expected.add(relatedPersons.get(2));

		Feed<RelatedPerson> actual = this.relatedPersonClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(RelatedPersonField.sourcePersonId.getLocalName(), false) }, null, false);

		RelatedPersonComparator.assertEquals(actual, expected);
	}

	public void testRelatedPersonSortByTargetPersonId() {
		final URI personId1 = this.personClient.create(this.personFactory.create()).getId();
		final URI personId2 = this.personClient.create(this.personFactory.create()).getId();
		final URI personId3 = this.personClient.create(this.personFactory.create()).getId();
		final URI personId4 = this.personClient.create(this.personFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(personId1) < URIUtils.getIdValue(personId2));
		Assert.assertTrue(URIUtils.getIdValue(personId2) < URIUtils.getIdValue(personId3));
		Assert.assertTrue(URIUtils.getIdValue(personId3) < URIUtils.getIdValue(personId4));

		List<RelatedPerson> relatedPersons = this.relatedPersonFactory.create(4);
		relatedPersons.get(0).setTargetPersonId(personId1);
		relatedPersons.get(3).setTargetPersonId(personId2);
		relatedPersons.get(1).setTargetPersonId(personId3);
		relatedPersons.get(2).setTargetPersonId(personId4);

		this.relatedPersonClient.create(relatedPersons);

		List<RelatedPerson> expected = new ArrayList<>(relatedPersons.size());
		expected.add(relatedPersons.get(0));
		expected.add(relatedPersons.get(3));
		expected.add(relatedPersons.get(1));
		expected.add(relatedPersons.get(2));

		Feed<RelatedPerson> actual = this.relatedPersonClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(RelatedPersonField.targetPersonId.getLocalName(), false) }, null, false);

		RelatedPersonComparator.assertEquals(actual, expected);
	}

	public void testRelatedPersonSortByStartDate() {
		List<RelatedPerson> relatedPersons = this.relatedPersonFactory.create(4);
		DateOnly startDate = new DateOnly();
		startDate.setYear(1980);
		startDate.setMonth(11);
		startDate.setDay(4);

		relatedPersons.get(0).setStartDate(startDate.toDate());
		startDate = new DateOnly();
		startDate.setYear(1980);
		startDate.setMonth(12);
		startDate.setDay(4);
		relatedPersons.get(2).setStartDate(startDate.toDate());
		startDate = new DateOnly();
		startDate.setYear(1980);
		startDate.setMonth(12);
		startDate.setDay(6);
		relatedPersons.get(3).setStartDate(startDate.toDate());

		startDate = new DateOnly();
		startDate.setYear(2012);
		startDate.setMonth(12);
		startDate.setDay(4);
		relatedPersons.get(1).setStartDate(startDate.toDate());

		this.relatedPersonClient.create(relatedPersons);

		List<RelatedPerson> expected = new ArrayList<>(relatedPersons.size());
		expected.add(relatedPersons.get(0));
		expected.add(relatedPersons.get(2));
		expected.add(relatedPersons.get(3));
		expected.add(relatedPersons.get(1));

		Feed<RelatedPerson> actual = this.relatedPersonClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(RelatedPersonField.startDate.getLocalName(), false) }, null, false);

		RelatedPersonComparator.assertEquals(actual, expected);
	}

	public void testRelatedPersonSortByEndDate() {
		List<RelatedPerson> relatedPersons = this.relatedPersonFactory.create(4);
		DateOnly endDate = new DateOnly();
		endDate.setYear(1980);
		endDate.setMonth(11);
		endDate.setDay(4);

		relatedPersons.get(0).setEndDate(endDate.toDate());
		endDate = new DateOnly();
		endDate.setYear(1980);
		endDate.setMonth(12);
		endDate.setDay(4);
		relatedPersons.get(2).setEndDate(endDate.toDate());
		endDate = new DateOnly();
		endDate.setYear(1980);
		endDate.setMonth(12);
		endDate.setDay(6);
		relatedPersons.get(3).setEndDate(endDate.toDate());

		endDate = new DateOnly();
		endDate.setYear(2012);
		endDate.setMonth(12);
		endDate.setDay(4);
		relatedPersons.get(1).setEndDate(endDate.toDate());

		this.relatedPersonClient.create(relatedPersons);

		List<RelatedPerson> expected = new ArrayList<>(relatedPersons.size());
		expected.add(relatedPersons.get(0));
		expected.add(relatedPersons.get(2));
		expected.add(relatedPersons.get(3));
		expected.add(relatedPersons.get(1));

		Feed<RelatedPerson> actual = this.relatedPersonClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(RelatedPersonField.endDate.getLocalName(), false) }, null, false);

		RelatedPersonComparator.assertEquals(actual, expected);
	}

	public void testRelatedPersonSortByType() {
		List<RelatedPerson> relatedPersons = this.relatedPersonFactory.create(5);
		relatedPersons.get(0).setType(RelatedPersonType.collaboratorWith.getFriendlyName());
		relatedPersons.get(2).setType(RelatedPersonType.followedMusic.getFriendlyName());
		relatedPersons.get(3).setType(RelatedPersonType.hasSimilarMusic.getFriendlyName());
		relatedPersons.get(1).setType(RelatedPersonType.influencedMusic.getFriendlyName());
		relatedPersons.get(4).setType(RelatedPersonType.memberOf.getFriendlyName());

		this.relatedPersonClient.create(relatedPersons);

		List<RelatedPerson> expected = new ArrayList<>(relatedPersons.size());
		expected.add(relatedPersons.get(0));
		expected.add(relatedPersons.get(2));
		expected.add(relatedPersons.get(3));
		expected.add(relatedPersons.get(1));
		expected.add(relatedPersons.get(4));

		Feed<RelatedPerson> retrievedPrograms = this.relatedPersonClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				RelatedPersonField.type.getLocalName(), false) }, null, false);

		RelatedPersonComparator.assertEquals(retrievedPrograms, expected);
	}

}
