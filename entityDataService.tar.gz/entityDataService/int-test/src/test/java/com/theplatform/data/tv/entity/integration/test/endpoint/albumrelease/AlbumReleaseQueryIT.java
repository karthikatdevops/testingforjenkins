package com.theplatform.data.tv.entity.integration.test.endpoint.albumrelease;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseField;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseSongAssociationField;
import com.theplatform.data.tv.entity.api.fields.TagField;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.client.query.albumrelease.ByAlbumId;
import com.theplatform.data.tv.entity.api.client.query.albumrelease.ByAlbumTitle;
import com.theplatform.data.tv.entity.api.client.query.albumrelease.ByMainRelease;
import com.theplatform.data.tv.entity.api.client.query.albumrelease.ByProductForm;
import com.theplatform.data.tv.entity.api.client.query.albumrelease.ByReleaseYear;
import com.theplatform.data.tv.entity.api.client.query.albumrelease.BySongId;
import com.theplatform.data.tv.entity.api.client.query.albumrelease.ByTagId;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.data.objects.TagType;
import com.theplatform.data.tv.entity.api.test.AlbumReleaseComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "albumRelease", "query" })
public class AlbumReleaseQueryIT extends EntityTestBase {

	public void testAlbumReleaseQueryByTitleNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(DataObjectField.title, "title")));
		Query[] queries = new Query[] { new ByTitle("title altered") };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumRelease should be found");
	}

	public void testAlbumReleaseQueryByTitleOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String title1 = "title 1";
		final String title2 = "title 2";

		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(DataObjectField.title, title1)));

		AlbumRelease expectedAlbumRelease = this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(DataObjectField.title, title2)),
				new String[] {});
		Query[] queries = new Query[] { new ByTitle(title2) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumRelease should be found");

		AlbumReleaseComparator.assertEquals(results.getEntries().get(0), expectedAlbumRelease);
	}

	public void testAlbumReleaseQueryByTitleMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final String title1 = "title 1";
		final String title2 = "title 2";

		this.albumReleaseClient.create(this.albumReleaseFactory.create(3, new DataServiceField(DataObjectField.title, title1)));

		List<AlbumRelease> expectedAlbumReleases = this.albumReleaseClient.create(this.albumReleaseFactory.create(2, new DataServiceField(DataObjectField.title, title2)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByTitle(title2) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Albums should be found");

		Map<URI, AlbumRelease> resultMap = new HashMap<>();
		for (AlbumRelease album : results.getEntries())
			resultMap.put(album.getId(), album);

		for (AlbumRelease expected : expectedAlbumReleases)
			AlbumReleaseComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}
	
	public void testAlbumReleaseQueryByAlbumTitleNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create(new DataServiceField(DataObjectField.title, "album title"))).getId())));
		Query[] queries = new Query[] { new ByAlbumTitle("album title altered") };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumRelease should be found");
	}
	
	public void testAlbumReleaseQueryByAlbumTitleOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String albumTitle1 = "album title 1";
		final String albumTitle2 = "album title 2";
		
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create(new DataServiceField(DataObjectField.title, albumTitle1))).getId())));
		
		URI albumId = albumClient.create(albumFactory.create(new DataServiceField(DataObjectField.title, albumTitle2))).getId();
		AlbumRelease expected = this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumId)), new String[] {});
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create()).getId())));

		Query[] queries = new Query[] { new ByAlbumTitle(albumTitle2) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumRelease should be found");

		AlbumReleaseComparator.assertEquals(results.getEntries().get(0), expected);
	}
		
	public void testAlbumReleaseQueryByAlbumTitleMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
	InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		
		final String albumTitle1 = "album title 1";
		final String albumTitle2 = "album title 2";
		
		this.albumReleaseClient.create(this.albumReleaseFactory.create(3, new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create(new DataServiceField(DataObjectField.title, albumTitle1))).getId())));
		
		URI albumId = albumClient.create(albumFactory.create(new DataServiceField(DataObjectField.title, albumTitle2))).getId();
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create()).getId())));

		List<AlbumRelease> expectedAlbumReleases = this.albumReleaseClient.create(this.albumReleaseFactory.create(2, new DataServiceField(AlbumReleaseField.albumId, albumId)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByAlbumTitle(albumTitle2) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumReleases should be found");

		Map<URI, AlbumRelease> resultMap = new HashMap<>();
		for (AlbumRelease albumRelease : results.getEntries()) {
			resultMap.put(albumRelease.getId(), albumRelease);
		}

		for (AlbumRelease expected : expectedAlbumReleases)
			AlbumReleaseComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}
	
	public void testAlbumReleaseQueryByProductFormNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.productForm, "EP")));
		Query[] queries = new Query[] { new ByProductForm("Album") };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumRelease should be found");
	}
	
	public void testAlbumReleaseQueryByProductFormOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		
		final String productForm1 = "Album";
		final String productForm2 = "EP";

		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.productForm, productForm1)));

		AlbumRelease expectedAlbumRelease = this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.productForm, productForm2)),
				new String[] {});
		Query[] queries = new Query[] { new ByProductForm(productForm2) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumRelease should be found");

		AlbumReleaseComparator.assertEquals(results.getEntries().get(0), expectedAlbumRelease);
	}
	
	public void testAlbumReleaseQueryByProductFormMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
	InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		
		final String productForm1 = "Album";
		final String productForm2 = "EP";

		this.albumReleaseClient.create(this.albumReleaseFactory.create(3, new DataServiceField(AlbumReleaseField.productForm, productForm1)));

		List<AlbumRelease> expectedAlbumReleases = this.albumReleaseClient.create(this.albumReleaseFactory.create(2, new DataServiceField(AlbumReleaseField.productForm, productForm2)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByProductForm(productForm2) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Albums should be found");

		Map<URI, AlbumRelease> resultMap = new HashMap<>();
		for (AlbumRelease album : results.getEntries())
			resultMap.put(album.getId(), album);

		for (AlbumRelease expected : expectedAlbumReleases)
			AlbumReleaseComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testAlbumReleaseQueryByAlbumIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create()).getId())));
		Query[] queries = new Query[] { new ByAlbumId(URIUtils.getIdValue(albumClient.create(albumFactory.create()).getId())) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumRelease should be found");
	}

	public void testAlbumReleaseQueryByAlbumIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI albumId = albumClient.create(albumFactory.create()).getId();
		AlbumRelease expected = this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumId)), new String[] {});
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create()).getId())));

		Query[] queries = new Query[] { new ByAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumRelease should be found");

		AlbumReleaseComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumReleaseQueryByAlbumIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI albumId = albumClient.create(albumFactory.create()).getId();
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, albumClient.create(albumFactory.create()).getId())));

		List<AlbumRelease> expectedAlbumReleases = this.albumReleaseClient.create(this.albumReleaseFactory.create(2, new DataServiceField(AlbumReleaseField.albumId, albumId)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumReleases should be found");

		Map<URI, AlbumRelease> resultMap = new HashMap<>();
		for (AlbumRelease albumRelease : results.getEntries()) {
			resultMap.put(albumRelease.getId(), albumRelease);
		}

		for (AlbumRelease expected : expectedAlbumReleases)
			AlbumReleaseComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testAlbumReleaseQueryBySongIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI albumReleaseId = this.albumReleaseClient.create(this.albumReleaseFactory.create()).getId();
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, this.songClient.create(this.songFactory.create()).getId())));

		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songClient.create(songFactory.create()).getId())) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumRelease should be found");
	}

	public void testAlbumReleaseQueryBySongIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI songId = songClient.create(songFactory.create()).getId();
		AlbumRelease expected = this.albumReleaseClient.create(this.albumReleaseFactory.create(), new String[] {});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, expected.getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, songId)));
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseClient
				.create(albumReleaseFactory.create()).getId()), new DataServiceField(AlbumReleaseSongAssociationField.songId, this.songClient.create(this.songFactory.create()).getId())));

		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumRelease should be found");

		AlbumReleaseComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumReleaseQueryBySongIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId = songClient.create(songFactory.create()).getId();
		AlbumRelease expected1 = this.albumReleaseClient.create(this.albumReleaseFactory.create(), new String[] {});
		AlbumRelease expected2 = this.albumReleaseClient.create(this.albumReleaseFactory.create(), new String[] {});
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, expected1.getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, songId)));
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, expected2.getId()),
				new DataServiceField(AlbumReleaseSongAssociationField.songId, songId)));

		this.albumReleaseClient.create(this.albumReleaseFactory.create(4), new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumReleases should be found");

		Map<URI, AlbumRelease> resultMap = new HashMap<>();
		for (AlbumRelease albumRelease : results.getEntries())
			resultMap.put(albumRelease.getId(), albumRelease);

		AlbumReleaseComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		AlbumReleaseComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testAlbumReleaseQueryByReleaseYearNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(2012);
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.releaseDate, releaseDate)));
		Query[] queries = new Query[] { new ByReleaseYear(2011) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumRelease should be found");
	}

	public void testAlbumReleaseQueryByReleaseYearOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final int releaseYear1 = 2012;
		final int releaseYear2 = 2011;

		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(releaseYear1);

		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.releaseDate, releaseDate)));
		releaseDate.setYear(releaseYear2);

		AlbumRelease expectedAlbumRelease = this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.releaseDate, releaseDate)),
				new String[] {});
		Query[] queries = new Query[] { new ByReleaseYear(releaseYear2) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumRelease should be found");

		AlbumReleaseComparator.assertEquals(results.getEntries().get(0), expectedAlbumRelease);
	}

	public void testAlbumReleaseQueryByReleaseYearMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final int releaseYear1 = 2012;
		final int releaseYear2 = 2011;

		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(releaseYear1);

		this.albumReleaseClient.create(this.albumReleaseFactory.create(3, new DataServiceField(AlbumReleaseField.releaseDate, releaseDate)));
		releaseDate.setYear(releaseYear2);

		List<AlbumRelease> expectedAlbumReleases = this.albumReleaseClient.create(
				this.albumReleaseFactory.create(2, new DataServiceField(AlbumReleaseField.releaseDate, releaseDate)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByReleaseYear(releaseYear2) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Albums should be found");

		Map<URI, AlbumRelease> resultMap = new HashMap<>();
		for (AlbumRelease album : results.getEntries())
			resultMap.put(album.getId(), album);

		for (AlbumRelease expected : expectedAlbumReleases)
			AlbumReleaseComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testAlbumReleaseQueryByTagIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI albumReleaseId = this.albumReleaseClient.create(this.albumReleaseFactory.create()).getId();
		URI tagId = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, albumReleaseId), new DataServiceField(TagAssociationField.tagId,
				tagId)));

		Query[] queries = new Query[] { new ByTagId(URIUtils.getIdValue(this.tagClient.create(this.tagFactory.create()).getId())) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumRelease should be found");
	}

	public void testAlbumReleaseQueryByTagIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		AlbumRelease albumRelease = this.albumReleaseClient.create(this.albumReleaseFactory.create(), new String[] {});
		URI tagId = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, albumRelease.getId()), new DataServiceField(
				TagAssociationField.tagId, tagId)));

		Query[] queries = new Query[] { new ByTagId(URIUtils.getIdValue(tagId)) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "One AlbumRelease should be found");

		albumRelease.setTagIds(Arrays.asList(new URI[] { tagId }));
		AlbumReleaseComparator.assertEquals(results.getEntries().get(0), albumRelease);
	}
	public void testAlbumReleaseQueryByTagIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		AlbumRelease albumRelease1 = this.albumReleaseClient.create(this.albumReleaseFactory.create(), new String[] {});
		AlbumRelease albumRelease2 = this.albumReleaseClient.create(this.albumReleaseFactory.create(), new String[] {});
		AlbumRelease albumRelease3 = this.albumReleaseClient.create(this.albumReleaseFactory.create(), new String[] {});
		URI tagId1 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		URI tagId2 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		URI tagId3 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, TagType.Music.getFriendlyName()))).getId();
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, albumRelease1.getId()), new DataServiceField(
				TagAssociationField.tagId, tagId1)));
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, albumRelease2.getId()), new DataServiceField(
				TagAssociationField.tagId, tagId2)));
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, albumRelease3.getId()), new DataServiceField(
				TagAssociationField.tagId, tagId3)));

		List<Long> tagIds = new ArrayList<>(Arrays.asList(new Long[] { URIUtils.getIdValue(tagId1), URIUtils.getIdValue(tagId2) }));
		Query[] queries = new Query[] { new ByTagId(tagIds) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumReleases should be found");

		Map<URI, AlbumRelease> resultMap = new HashMap<>();
		for (AlbumRelease albumRelease : results.getEntries())
			resultMap.put(albumRelease.getId(), albumRelease);

		albumRelease1.setTagIds(Arrays.asList(new URI[] { tagId1 }));
		albumRelease2.setTagIds(Arrays.asList(new URI[] { tagId2 }));

		AlbumReleaseComparator.assertEquals(resultMap.get(albumRelease1.getId()), albumRelease1);
		AlbumReleaseComparator.assertEquals(resultMap.get(albumRelease2.getId()), albumRelease2);
	}

	public void testAlbumReleaseQueryByMainReleaseNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.mainRelease, true)));
		Query[] queries = new Query[] { new ByMainRelease(false) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumRelease should be found");
	}

	public void testAlbumReleaseQueryByMainReleaseOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		AlbumRelease expected = this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.mainRelease, true)), new String[] {});
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.mainRelease, false)));

		Query[] queries = new Query[] { new ByMainRelease(true) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumRelease should be found");

		AlbumReleaseComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumReleaseQueryByMainReleaseMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.mainRelease, false)));
		List<AlbumRelease> expectedAlbumReleases = this.albumReleaseClient.create(
				this.albumReleaseFactory.create(2, new DataServiceField(AlbumReleaseField.mainRelease, true)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByMainRelease(true) };
		Feed<AlbumRelease> results = this.albumReleaseClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumReleases should be found");

		Map<URI, AlbumRelease> resultMap = new HashMap<>();
		for (AlbumRelease albumRelease : results.getEntries()) {
			resultMap.put(albumRelease.getId(), albumRelease);
		}

		for (AlbumRelease expected : expectedAlbumReleases)
			AlbumReleaseComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}
}
