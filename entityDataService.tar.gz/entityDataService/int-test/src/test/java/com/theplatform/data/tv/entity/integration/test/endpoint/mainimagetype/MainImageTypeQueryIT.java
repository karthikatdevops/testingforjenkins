package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagetype;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.client.query.mainimagetype.ByAlias;
import com.theplatform.data.tv.image.api.client.query.mainimagetype.ByMainImageTypeGroupId;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.image.api.fields.MainImageTypeField;
import com.theplatform.data.tv.image.api.test.MainImageTypeComparator;

/**
 * 
 * @author jethrolai
 * @since 2/21/2012
 */
@Test(groups = { TestGroup.gbTest, "mainImageType", "query" })
public class MainImageTypeQueryIT extends EntityTestBase {

	public void testMainImageTypeQueryByAliasNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String aliasToBeFound = "expectedAliasId";

		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound.concat(""
				+ new Random().nextInt()))));
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound.concat(""
				+ new Random().nextInt()))));
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound.concat(""
				+ new Random().nextInt()))));
		Query[] queries = new Query[] { new ByAlias(aliasToBeFound) };
		Feed<MainImageType> results = this.mainImageTypeClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageType should be found");
	}

	public void testMainImageTypeQueryByAliasOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String aliasToBeFound = "expectedalias";

		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound.concat(""
				+ new Random().nextInt()))));
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound.concat(""
				+ new Random().nextInt()))));
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound.concat(""
				+ new Random().nextInt()))));

		MainImageType expectedMainImageType = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound)), new String[] {});
		Query[] queries = new Query[] { new ByAlias(aliasToBeFound) };
		Feed<MainImageType> results = this.mainImageTypeClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageType should be found");

		MainImageTypeComparator.assertEquals(results.getEntries().get(0), expectedMainImageType);
	}

	public void testMainImageTypeQueryByAliasListMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String aliasToBeFound1 = "expectedAlias1";
		final String aliasToBeFound2 = "expectedAlias2";

		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound1.concat("update"
				+ new Random().nextInt()))));
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound1.concat("update"
				+ new Random().nextInt()))));
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound1.concat("update"
				+ new Random().nextInt()))));

		MainImageType expectedMainImageType1 = this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound1));
		MainImageType expectedMainImageType2 = this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.alias, aliasToBeFound2));
		this.mainImageTypeClient.create(expectedMainImageType1);
		this.mainImageTypeClient.create(expectedMainImageType2);

		List<String> alias = Arrays.asList(new String[] { aliasToBeFound1, aliasToBeFound2 });
		Query[] queries = new Query[] { new ByAlias(alias) };
		Feed<MainImageType> results = this.mainImageTypeClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageTypes should be found");

		Map<URI, MainImageType> resultMap = new HashMap<>();
		for (MainImageType mainImageType : results.getEntries()) {
			resultMap.put(mainImageType.getId(), mainImageType);
		}

		MainImageTypeComparator.assertEquals(resultMap.get(expectedMainImageType1.getId()), expectedMainImageType1);
		MainImageTypeComparator.assertEquals(resultMap.get(expectedMainImageType2.getId()), expectedMainImageType2);
	}

	public void testMainImageTypeQueryByMainImageTypeGroupIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.mainImageTypeClient.create(this.mainImageTypeFactory.create());
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create());
		Query[] queries = new Query[] { new ByMainImageTypeGroupId(URIUtils.getIdValue(mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create())
				.getId())) };
		Feed<MainImageType> results = this.mainImageTypeClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageType should be found");
	}

	public void testMainImageTypeQueryByMainImageTypeGroupIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI groupId = mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId();
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create());

		MainImageType expectedMainImageType = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupId))), new String[] {});
		Query[] queries = new Query[] { new ByMainImageTypeGroupId(URIUtils.getIdValue(groupId)) };
		Feed<MainImageType> results = this.mainImageTypeClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageType should be found");

		MainImageTypeComparator.assertEquals(results.getEntries().get(0), expectedMainImageType);
	}

	public void testMainImageTypeQueryByMainImageTypGroupIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI groupId = mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId();
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create());

		MainImageType expectedMainImageType1 = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupId))), new String[] {});
		MainImageType expectedMainImageType2 = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupId))), new String[] {});

		Query[] queries = new Query[] { new ByMainImageTypeGroupId(URIUtils.getIdValue(groupId)) };
		Feed<MainImageType> results = this.mainImageTypeClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageTypes should be found");

		Map<URI, MainImageType> resultMap = new HashMap<>();
		for (MainImageType mainImageType : results.getEntries())
			resultMap.put(mainImageType.getId(), mainImageType);

		MainImageTypeComparator.assertEquals(resultMap.get(expectedMainImageType1.getId()), expectedMainImageType1);
		MainImageTypeComparator.assertEquals(resultMap.get(expectedMainImageType2.getId()), expectedMainImageType2);
	}

	public void testMainImageTypeQueryByMainImageTypeGroupIdListNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.mainImageTypeClient.create(this.mainImageTypeFactory.create());
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create());

		long groupId1 = URIUtils.getIdValue(mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId());
		long groupId2 = URIUtils.getIdValue(mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId());

		Query[] queries = new Query[] { new ByMainImageTypeGroupId(Arrays.asList(groupId1, groupId2)) };
		Feed<MainImageType> results = this.mainImageTypeClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageType should be found");
	}

	public void testMainImageTypeQueryByMainImageTypeGroupIdListOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI groupId1 = mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId();
		final URI groupId2 = mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId();
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create());

		MainImageType expectedMainImageType = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupId1))), new String[] {});

		Query[] queries = new Query[] { new ByMainImageTypeGroupId(Arrays.asList(URIUtils.getIdValue(groupId1), URIUtils.getIdValue(groupId2))) };
		Feed<MainImageType> results = this.mainImageTypeClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageType should be found");

		MainImageTypeComparator.assertEquals(results.getEntries().get(0), expectedMainImageType);
	}

	public void testMainImageTypeQueryByMainImageTypGroupIdListMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI groupId1 = mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId();
		final URI groupId2 = mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create()).getId();
		this.mainImageTypeClient.create(this.mainImageTypeFactory.create());

		MainImageType expectedMainImageType1 = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupId1))), new String[] {});
		MainImageType expectedMainImageType2 = this.mainImageTypeClient.create(
				this.mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.mainImageTypeGroupIds, Arrays.asList(groupId2))), new String[] {});

		Query[] queries = new Query[] { new ByMainImageTypeGroupId(Arrays.asList(URIUtils.getIdValue(groupId1), URIUtils.getIdValue(groupId2))) };
		Feed<MainImageType> results = this.mainImageTypeClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageTypes should be found");

		Map<URI, MainImageType> resultMap = new HashMap<>();
		for (MainImageType mainImageType : results.getEntries())
			resultMap.put(mainImageType.getId(), mainImageType);

		MainImageTypeComparator.assertEquals(resultMap.get(expectedMainImageType1.getId()), expectedMainImageType1);
		MainImageTypeComparator.assertEquals(resultMap.get(expectedMainImageType2.getId()), expectedMainImageType2);
	}
}
