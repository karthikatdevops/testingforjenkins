package com.theplatform.data.tv.entity.integration.test.endpoint.socialmediaassociation;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 */
@Test(groups = { "review", TestGroup.gbTest, "validation" }, enabled = false)
public class SocialMediaAssociationValidationIT extends EntityTestBase {

}
