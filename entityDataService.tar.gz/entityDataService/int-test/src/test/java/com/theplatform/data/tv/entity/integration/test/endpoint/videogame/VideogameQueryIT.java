package com.theplatform.data.tv.entity.integration.test.endpoint.videogame;

import com.google.common.collect.Lists;
import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.ByTitlePrefix;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.videogame.ByMultiPlayer;
import com.theplatform.data.tv.entity.api.client.query.videogame.BySinglePlayer;
import com.theplatform.data.tv.entity.api.client.query.videogame.ByType;
import com.theplatform.data.tv.entity.api.data.objects.Videogame;
import com.theplatform.data.tv.entity.api.fields.VideogameField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.annotations.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 12/3/14
 */
@Test(groups = { "videogame", "query", TestGroup.gbTest })
public class VideogameQueryIT extends EntityTestBase {

    public void byTitleQueryShouldReurnVideogameByTitleWhenItExists() {
        Videogame v1  = videogameFactory.create(new DataServiceField(DataObjectField.title, "title1"));
        videogameClient.create(v1);
        Videogame v2  = videogameFactory.create(new DataServiceField(DataObjectField.title, "title2"));
        videogameClient.create(v2);

        Query[] queries = new Query[] { new ByTitle("title1")};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getTitle(), equalTo("title1"));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }

    public void byTitleQueryShouldHandleOrs() {
        Videogame v1  = videogameFactory.create(new DataServiceField(DataObjectField.title, "title1"));
        videogameClient.create(v1);
        Videogame v2  = videogameFactory.create(new DataServiceField(DataObjectField.title, "title2"));
        videogameClient.create(v2);

        Query[] queries = new Query[] { new ByTitle(Lists.newArrayList("title1", "title2"))};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(2));
        assertThat(results.getEntries().get(0).getTitle(), anyOf(equalTo("title1"), equalTo("title2")));
        assertThat(results.getEntries().get(1).getTitle(), anyOf(equalTo("title1"), equalTo("title2")));
    }

    public void byTitleQueryShouldReurnNoResultsWhenItsNotFound() {
        Videogame v1  = videogameFactory.create(new DataServiceField(DataObjectField.title, "title1"));
        videogameClient.create(v1);
        Videogame v2  = videogameFactory.create(new DataServiceField(DataObjectField.title, "title2"));
        videogameClient.create(v2);

        Query[] queries = new Query[] { new ByTitle("otherTitle")};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(0));
    }

    public void byTitlePrefixQueryShouldReurnVideogameByTitlePrefixWhenItExists() {
        Videogame v1  = videogameFactory.create(new DataServiceField(DataObjectField.title, "title1"));
        videogameClient.create(v1);
        Videogame v2  = videogameFactory.create(new DataServiceField(DataObjectField.title, "otherTitle1"));
        videogameClient.create(v2);

        Query[] queries = new Query[] { new ByTitlePrefix("other")};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getTitle(), equalTo("otherTitle1"));
        assertThat(results.getEntries().get(0).getId(), equalTo(v2.getId()));
    }

    public void byTitlePrefixQueryShouldHandleOrs() {
        Videogame v1  = videogameFactory.create(new DataServiceField(DataObjectField.title, "title1"));
        videogameClient.create(v1);
        Videogame v2  = videogameFactory.create(new DataServiceField(DataObjectField.title, "other1"));
        videogameClient.create(v2);

        Query[] queries = new Query[] { new ByTitlePrefix(Lists.newArrayList("title", "other"))};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(2));
        assertThat(results.getEntries().get(0).getTitle(), anyOf(equalTo("title1"), equalTo("other1")));
        assertThat(results.getEntries().get(1).getTitle(), anyOf(equalTo("title1"), equalTo("other1")));
    }

    public void byTypeQueryShouldReurnVideogameByTypeWhenItExists() {
        Videogame v1  = videogameFactory.create(new DataServiceField(VideogameField.type, "Game"));
        videogameClient.create(v1);

        Query[] queries = new Query[] { new ByType("Game")};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getType(), equalTo("Game"));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }

    public void byMerlinResourceTypeQueryShouldWork() {
        Videogame v1  = videogameFactory.create(new DataServiceField(VideogameField.merlinResourceType, MerlinResourceType.AudienceAvailable));
        videogameClient.create(v1);
        Videogame v2  = videogameFactory.create(new DataServiceField(VideogameField.merlinResourceType, MerlinResourceType.Temporary));
        videogameClient.create(v2);

        Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable)};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getMerlinResourceType(), equalTo(MerlinResourceType.AudienceAvailable));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }

    public void byMerlinResourceTypeQueryShouldHandleOr() {
        Videogame v1  = videogameFactory.create(new DataServiceField(VideogameField.merlinResourceType, MerlinResourceType.AudienceAvailable));
        videogameClient.create(v1);
        Videogame v2  = videogameFactory.create(new DataServiceField(VideogameField.merlinResourceType, MerlinResourceType.Temporary));
        videogameClient.create(v2);

        Query[] queries = new Query[] { new ByMerlinResourceType(Lists.newArrayList(MerlinResourceType.AudienceAvailable, MerlinResourceType.Temporary))};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(2));
        assertThat(results.getEntries().get(0).getMerlinResourceType(), anyOf(equalTo(MerlinResourceType.AudienceAvailable), equalTo(MerlinResourceType.Temporary)));
    }

    public void byMultiplayerQueryShouldWork() {
        Videogame v1  = videogameFactory.create(new DataServiceField(VideogameField.multiPlayer, true));
        videogameClient.create(v1);
        Videogame v2  = videogameFactory.create(new DataServiceField(VideogameField.multiPlayer, false));
        v2.setMaxPlayers(null);
        v2.setMinPlayers(null);
        videogameClient.create(v2);

        Query[] queries = new Query[] { new ByMultiPlayer(true)};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getMultiPlayer(), equalTo(true));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }


    public void bySingleplayerQueryShouldWork() {
        Videogame v1  = videogameFactory.create(new DataServiceField(VideogameField.singlePlayer, true));
        videogameClient.create(v1);
        Videogame v2  = videogameFactory.create(new DataServiceField(VideogameField.singlePlayer, false));
        videogameClient.create(v2);

        Query[] queries = new Query[] { new BySinglePlayer(true)};

        Feed<Videogame> results = videogameClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getSinglePlayer(), equalTo(true));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }


}
