package com.theplatform.data.tv.entity.integration.test.endpoint.songcredit;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;
import com.theplatform.data.tv.entity.api.test.SongCreditComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "songCredit", "sort" })
public class SongCreditSortIT extends EntityTestBase {

	public void testSongCreditSortByGuid() {
		List<SongCredit> songCredits = songCreditFactory.create(4);
		songCredits.get(0).setGuid("1");
		songCredits.get(3).setGuid("2");
		songCredits.get(1).setGuid("3");
		songCredits.get(2).setGuid("4");

		this.songCreditClient.create(songCredits);

		List<SongCredit> expectedSortedSongCredits = new ArrayList<>(songCredits.size());
		expectedSortedSongCredits.add(songCredits.get(0));
		expectedSortedSongCredits.add(songCredits.get(3));
		expectedSortedSongCredits.add(songCredits.get(1));
		expectedSortedSongCredits.add(songCredits.get(2));

		Feed<SongCredit> retrievedSongCredits = this.songCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("guid", false) }, null,
				false);

		SongCreditComparator.assertEquals(retrievedSongCredits, expectedSortedSongCredits);
	}

	public void testSongCreditSortByType() {
		List<SongCredit> songCredits = songCreditFactory.create(2);
		songCredits.get(0).setType("Primary Artist");
		songCredits.get(1).setType("Guest Artist");

		this.songCreditClient.create(songCredits);

		List<SongCredit> expectedSortedSongCredits = new ArrayList<>(songCredits.size());
		expectedSortedSongCredits.add(songCredits.get(1));
		expectedSortedSongCredits.add(songCredits.get(0));

		Feed<SongCredit> retrievedSongCredits = this.songCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("type", false) }, null,
				false);

		SongCreditComparator.assertEquals(retrievedSongCredits, expectedSortedSongCredits);
	}

	public void testSongCreditSortByRank() {
		List<SongCredit> songCredits = songCreditFactory.create(4);
		songCredits.get(0).setRank(1);
		songCredits.get(3).setRank(2);
		songCredits.get(1).setRank(3);
		songCredits.get(2).setRank(4);

		this.songCreditClient.create(songCredits);

		List<SongCredit> expectedSortedSongCredits = new ArrayList<>(songCredits.size());
		expectedSortedSongCredits.add(songCredits.get(0));
		expectedSortedSongCredits.add(songCredits.get(3));
		expectedSortedSongCredits.add(songCredits.get(1));
		expectedSortedSongCredits.add(songCredits.get(2));

		Feed<SongCredit> retrievedSongCredits = this.songCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("rank", false) }, null,
				false);

		SongCreditComparator.assertEquals(retrievedSongCredits, expectedSortedSongCredits);
	}

	public void testSongCreditSortByPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI personId1 = this.personClient.create(personFactory.create()).getId();
		URI personId2 = this.personClient.create(personFactory.create()).getId();
		URI personId3 = this.personClient.create(personFactory.create()).getId();
		URI personId4 = this.personClient.create(personFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(personId1) < URIUtils.getIdValue(personId2));
		Assert.assertTrue(URIUtils.getIdValue(personId2) < URIUtils.getIdValue(personId3));
		Assert.assertTrue(URIUtils.getIdValue(personId3) < URIUtils.getIdValue(personId4));

		List<SongCredit> songCredits = songCreditFactory.create(4);
		songCredits.get(0).setPersonId(personId1);
		songCredits.get(3).setPersonId(personId2);
		songCredits.get(1).setPersonId(personId3);
		songCredits.get(2).setPersonId(personId4);

		this.songCreditClient.create(songCredits);

		List<SongCredit> expectedSortedSongCredits = new ArrayList<>(songCredits.size());
		expectedSortedSongCredits.add(songCredits.get(0));
		expectedSortedSongCredits.add(songCredits.get(3));
		expectedSortedSongCredits.add(songCredits.get(1));
		expectedSortedSongCredits.add(songCredits.get(2));

		Feed<SongCredit> retrievedSongCredits = this.songCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("personId", false) },
				null, false);

		SongCreditComparator.assertEquals(retrievedSongCredits, expectedSortedSongCredits);
	}

	public void testSongCreditSortBySongId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId1 = this.songClient.create(songFactory.create()).getId();
		URI songId2 = this.songClient.create(songFactory.create()).getId();
		URI songId3 = this.songClient.create(songFactory.create()).getId();
		URI songId4 = this.songClient.create(songFactory.create()).getId();
		
		Assert.assertTrue(URIUtils.getIdValue(songId1) < URIUtils.getIdValue(songId2));
		Assert.assertTrue(URIUtils.getIdValue(songId2) < URIUtils.getIdValue(songId3));
		Assert.assertTrue(URIUtils.getIdValue(songId3) < URIUtils.getIdValue(songId4));

		List<SongCredit> songCredits = songCreditFactory.create(4);
		songCredits.get(0).setSongId(songId1);
		songCredits.get(3).setSongId(songId2);
		songCredits.get(1).setSongId(songId3);
		songCredits.get(2).setSongId(songId4);

		this.songCreditClient.create(songCredits);

		List<SongCredit> expectedSortedSongCredits = new ArrayList<>(songCredits.size());
		expectedSortedSongCredits.add(songCredits.get(0));
		expectedSortedSongCredits.add(songCredits.get(3));
		expectedSortedSongCredits.add(songCredits.get(1));
		expectedSortedSongCredits.add(songCredits.get(2));

		Feed<SongCredit> retrievedSongCredits = this.songCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("songId", false) }, null,
				false);

		SongCreditComparator.assertEquals(retrievedSongCredits, expectedSortedSongCredits);
	}

	public void testSongCreditSortByActive() {
		List<SongCredit> songCredits = songCreditFactory.create(2);
		songCredits.get(0).setActive(true);
		songCredits.get(1).setActive(false);

		this.songCreditClient.create(songCredits);

		List<SongCredit> expectedSortedSongCredits = new ArrayList<>(songCredits.size());
		expectedSortedSongCredits.add(songCredits.get(1));
		expectedSortedSongCredits.add(songCredits.get(0));

		Feed<SongCredit> retrievedSongCredits = this.songCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("active", false) }, null,
				false);

		SongCreditComparator.assertEquals(retrievedSongCredits, expectedSortedSongCredits);
	}

}
