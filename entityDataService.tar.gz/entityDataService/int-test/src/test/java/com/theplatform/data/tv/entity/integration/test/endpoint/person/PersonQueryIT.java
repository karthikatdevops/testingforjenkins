package com.theplatform.data.tv.entity.integration.test.endpoint.person;

import static org.testng.Assert.assertEquals;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.theplatform.data.tv.entity.api.fields.PersonField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.person.ByKnownFor;
import com.theplatform.data.tv.entity.api.client.query.person.ByPersonType;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.PersonKnownForType;
import com.theplatform.data.tv.entity.api.data.objects.PersonType;
import com.theplatform.data.tv.entity.api.test.PersonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "person", "query" })
public class PersonQueryIT extends EntityTestBase {



	public void testPersonQueryByPersonTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.personClient.create(personFactory.create(3, new DataServiceField(PersonField.personType, PersonType.Band.getFriendlyName())));
		Query queries[] = new Query[] { new ByPersonType(PersonType.Person.getFriendlyName()) };
		Feed<Person> retrievedPersons = this.personClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedPersons.getEntries().size(), 0, "No record should be found using query byPersonType");
	}

	public void testPersonQueryByPersonTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
        this.personClient.create(personFactory.create(3, new DataServiceField(PersonField.personType, PersonType.Band.getFriendlyName())));
        URI personId = this.personClient.create(personFactory.create(new DataServiceField(PersonField.personType, PersonType.Person.getFriendlyName()))).getId();
        Query queries[] = new Query[] { new ByPersonType(PersonType.Person.getFriendlyName()) };
        Feed<Person> retrievedPerson = this.personClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(retrievedPerson.getEntries().size(), 1, "Exact one record should be found using query byPersonType");
		PersonComparator.assertEquals(retrievedPerson.getEntries().get(0), this.personClient.get(personId, new String[] {}));
	}

	public void testPersonQueryByPersonTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        this.personClient.create(personFactory.create(3, new DataServiceField(PersonField.personType, PersonType.Band.getFriendlyName())));
        this.personClient.create(personFactory.create(2, new DataServiceField(PersonField.personType, PersonType.Person.getFriendlyName())));

		Query queries[] = new Query[] { new ByPersonType(PersonType.Person.getFriendlyName()) };
		Feed<Person> retrievedPerson = this.personClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedPerson.getEntries().size(), 2, "Exact 2 records should be found using query byPersonType");
		queries = new Query[] { new ByPersonType(PersonType.Band.getFriendlyName()) };
		retrievedPerson = this.personClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedPerson.getEntries().size(), 3, "Exact 3 records should be found using query byPersonType");
		queries = new Query[] { new ByPersonType(new ArrayList<String>(Arrays.asList(new String[] { PersonType.Band.getFriendlyName(),
				PersonType.Person.getFriendlyName() }))) };
		retrievedPerson = this.personClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedPerson.getEntries().size(), 5, "Exact 5 records should be found using query byPersonType");

	}

	public void testPersonQueryByKnownForNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.knownFor, new ArrayList<String>(Arrays
				.asList(new String[] { PersonKnownForType.Music.getFriendlyName() })))));
		Query queries[] = new Query[] { new ByKnownFor(PersonKnownForType.Video.getFriendlyName()) };
		Feed<Person> retrievedPersons = this.personClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedPersons.getEntries().size(), 0, "No record should be found using query byKnownFor");
	}

	public void testPersonQueryByKnownForOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.knownFor, new ArrayList<String>(Arrays
				.asList(new String[] { PersonKnownForType.Music.getFriendlyName() })))));
		URI personId = this.personClient.create(
				personFactory.create(new DataServiceField(PersonField.knownFor, new ArrayList<String>(Arrays.asList(new String[] { PersonKnownForType.Video
						.getFriendlyName() }))))).getId();
		Query queries[] = new Query[] { new ByKnownFor(PersonKnownForType.Video.getFriendlyName()) };
		Feed<Person> retrievedPerson = this.personClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedPerson.getEntries().size(), 1, "Exact one record should be found using query byKnownFor");
		PersonComparator.assertEquals(retrievedPerson.getEntries().get(0), this.personClient.get(personId, new String[] {}));
	}

	public void testPersonQueryByKnownForMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.personClient.create(personFactory.create(3,
				new DataServiceField(PersonField.knownFor, new ArrayList<String>(Arrays.asList(new String[] { PersonKnownForType.Music.getFriendlyName() })))));
		this.personClient.create(personFactory.create(2,
				new DataServiceField(PersonField.knownFor, new ArrayList<String>(Arrays.asList(new String[] { PersonKnownForType.Video.getFriendlyName() })))));
		Query queries[] = new Query[] { new ByKnownFor(PersonKnownForType.Video.getFriendlyName()) };
		Feed<Person> retrievedPerson = this.personClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedPerson.getEntries().size(), 2, "Exact 2 records should be found using query byKnownFor");
		queries = new Query[] { new ByKnownFor(PersonKnownForType.Music.getFriendlyName()) };
		retrievedPerson = this.personClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedPerson.getEntries().size(), 3, "Exact 3 records should be found using query byKnownFor");
		queries = new Query[] { new ByKnownFor(new ArrayList<String>(Arrays.asList(new String[] { PersonKnownForType.Music.getFriendlyName(),
				PersonKnownForType.Video.getFriendlyName() }))) };
		retrievedPerson = this.personClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(retrievedPerson.getEntries().size(), 5, "Exact 5 records should be found using query byKnownFor");

	}
}
