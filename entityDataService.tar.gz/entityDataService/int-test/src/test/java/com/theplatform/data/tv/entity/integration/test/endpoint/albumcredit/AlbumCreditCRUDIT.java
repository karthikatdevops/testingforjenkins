package com.theplatform.data.tv.entity.integration.test.endpoint.albumcredit;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.AlbumCredit;
import com.theplatform.data.tv.entity.api.fields.AlbumCreditField;
import com.theplatform.data.tv.entity.api.test.AlbumCreditComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "albumCredit", "crud" })
public class AlbumCreditCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testSingleAlbumCreditCrud() {
		AlbumCredit entity = this.albumCreditFactory.create();

		// CREATE
		AlbumCredit persistedEntity = this.albumCreditClient.create(entity, new String[] {});
		AlbumCreditComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		AlbumCredit retrievedEntity = this.albumCreditClient.get(entity.getId(), new String[] {});
		AlbumCreditComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setType(entity.getType() != null && entity.getType() != "Primary Artist" ? "Primary Artist" : "Guest Artist");
		entity.setRank(entity.getRank() != null ? entity.getRank() + 1 : 1);
		entity.setPersonId(this.personClient.create(this.personFactory.create()).getId());
		entity.setAlbumId(this.albumClient.create(this.albumFactory.create()).getId());
		entity.setActive(!entity.getActive());

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		this.albumCreditClient.update(entity);

		AlbumCredit retrievedAfterUpdate = this.albumCreditClient.get(entity.getId(), new String[] {});
		AlbumCreditComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = this.albumCreditClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.albumCreditClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("AlbumCredit should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testAlbumCreditFeedCrud() throws UnknownHostException {
		List<AlbumCredit> entities = this.albumCreditFactory.create(5);

		// CREATE
		Feed<AlbumCredit> persistedEntities = this.albumCreditClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			AlbumCreditComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i));

		URI[] entityIds = new URI[entities.size()];
		for (int i = 0; i < entityIds.length; i++)
			entityIds[i] = entities.get(i).getId();

		// RETRIEVE
		Feed<AlbumCredit> retrievedEntities = this.albumCreditClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			AlbumCreditComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i));

		// DELETE
		long deletedEntities = this.albumCreditClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (AlbumCredit entity : entities) {
			try {
				this.albumCreditClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumCreditDefaultFieldValues() {
		AlbumCredit entity = this.albumCreditFactory.create();

		entity.setType(null);
		entity.setRank(null);
		entity.setActive(null);
		entity.setMerlinResourceType(null);
		AlbumCredit actual = this.albumCreditClient.create(entity, new String[] {});

		entity.setActive(true);
		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		AlbumCreditComparator.assertEquals(actual, entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(AlbumCreditField.type, null),
			new DataServiceField(AlbumCreditField.rank, null), new DataServiceField(AlbumCreditField.active, true),
			new DataServiceField(AlbumCreditField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumCreditCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(albumCreditClient, albumCreditFactory.create(), AlbumCreditComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumCreditCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(albumCreditClient, albumCreditFactory.create(), AlbumCreditComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAlbumCreditUpdateWithAllNullNonRequiredFieldsGeneric() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(AlbumCreditField.type, "Primary Artist"));
		createValues.add(new DataServiceField(AlbumCreditField.rank, 1));
		createValues.add(new DataServiceField(AlbumCreditField.active, false));
		createValues.add(new DataServiceField(AlbumCreditField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(albumCreditClient, albumCreditFactory.create(), AlbumCreditComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testAlbumCreditUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(AlbumCreditField.type, "Primary Artist"));
		createValues.add(new DataServiceField(AlbumCreditField.rank, 1));
		createValues.add(new DataServiceField(AlbumCreditField.active, false));
		createValues.add(new DataServiceField(AlbumCreditField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(albumCreditClient, albumCreditFactory.create(), AlbumCreditComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}
}
