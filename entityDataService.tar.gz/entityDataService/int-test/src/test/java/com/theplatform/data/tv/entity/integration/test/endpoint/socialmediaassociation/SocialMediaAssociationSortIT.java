package com.theplatform.data.tv.entity.integration.test.endpoint.socialmediaassociation;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.social.api.data.objects.SocialMediaAssociation;
import com.theplatform.data.tv.social.api.test.SocialMediaAssociationComparator;
import com.theplatform.module.exception.BadParameterException;

/**
 * There are no special sortable fields on SMAs so we test sort by GUID
 */
@Test(groups = { "review", "sort", TestGroup.gbTest })
public class SocialMediaAssociationSortIT extends EntityTestBase {

	private static final int NUM_TO_CREATE = 4;
	private List<SocialMediaAssociation> entityList;

	@BeforeClass(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		entityList = socialMediaAssociationFactory.create(NUM_TO_CREATE);
		entityList.get(0).setId(URI.create(baseUrl + "/data/SocialMediaAssociation/" + objectIdProvider.nextId()));
		entityList.get(0).setGuid("2");
		entityList.get(1).setId(URI.create(baseUrl + "/data/SocialMediaAssociation/" + objectIdProvider.nextId()));
		entityList.get(1).setGuid("4");
		entityList.get(2).setId(URI.create(baseUrl + "/data/SocialMediaAssociation/" + objectIdProvider.nextId()));
		entityList.get(2).setGuid("3");
		entityList.get(3).setId(URI.create(baseUrl + "/data/SocialMediaAssociation/" + objectIdProvider.nextId()));
		entityList.get(3).setGuid("1");
		socialMediaAssociationClient.create(entityList, new String[] {});
	}

	@Test
	public void testSortAscendingRelatedProgramByGuid() throws UnknownHostException {
		// SORT EXPECTED
		List<SocialMediaAssociation> expectedSortedEntities = new ArrayList<>(NUM_TO_CREATE);
		expectedSortedEntities.add(entityList.get(3));
		expectedSortedEntities.add(entityList.get(0));
		expectedSortedEntities.add(entityList.get(2));
		expectedSortedEntities.add(entityList.get(1));

		// RETRIEVE WITH SORTING
		Sort requestSort = new Sort("guid", false);
		Feed<SocialMediaAssociation> retreivedEntities = socialMediaAssociationClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { requestSort }, null, false);

		SocialMediaAssociationComparator smaC = new SocialMediaAssociationComparator();
		smaC.assertEquals(retreivedEntities, expectedSortedEntities);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableField() throws UnknownHostException {
		// RETRIVE WHITH SORTING
		String sortField = "justification";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortField, sortDescending);
		socialMediaAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
	}
}
