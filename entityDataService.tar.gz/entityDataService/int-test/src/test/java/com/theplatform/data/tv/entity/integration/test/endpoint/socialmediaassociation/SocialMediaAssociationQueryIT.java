package com.theplatform.data.tv.entity.integration.test.endpoint.socialmediaassociation;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.social.api.client.query.socialMediaAssociation.ByEntityId;
import com.theplatform.data.tv.social.api.client.query.socialMediaAssociation.ByPrimary;
import com.theplatform.data.tv.social.api.client.query.socialMediaAssociation.ByType;
import com.theplatform.data.tv.social.api.client.query.socialMediaAssociation.ByIdentifier;
import com.theplatform.data.tv.social.api.data.objects.SocialMediaAssociation;
import com.theplatform.data.tv.social.api.fields.SocialMediaAssociationField;

/**
 * @author vfumo
 */
@Test(groups = { "review", "query", TestGroup.gbTest })
public class SocialMediaAssociationQueryIT extends EntityTestBase {

	public void byTypeQueryShouldReturnSmaByTypeWhenItExists() {

		// create 2 entities with diff types
		SocialMediaAssociation sma1 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.type,
				"Facebook"));
		socialMediaAssociationClient.create(sma1);

		SocialMediaAssociation sma2 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.type,
				"Twitter"));
		SocialMediaAssociation sma2c = socialMediaAssociationClient.create(sma2);

		// make the query for just one of them
		Query[] queries = new Query[] { new ByType("Twitter") };

		// get them from the client
		Feed<SocialMediaAssociation> results = socialMediaAssociationClient.getAll(null, queries, null, null, null);

		// make sure we got a good result
		assertThat(results.getEntries().size(), equalTo(1));
		assertThat(results.getEntries().get(0).getType(), equalTo("Twitter"));
		assertThat(results.getEntries().get(0).getId(), equalTo(sma2c.getId()));
	}

	public void byTypeQueryShouldReturnNoResultsWhenItDoesntExist() {

		// create 2 entities with diff types
		SocialMediaAssociation sma1 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.type,
				"Facebook"));
		SocialMediaAssociation sma2 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.type,
				"Twitter"));
		List<SocialMediaAssociation> smaList = Arrays.asList(sma1, sma2);
		socialMediaAssociationClient.create(smaList);

		// make the query for one that doesn't exist
		Query[] queries = new Query[] { new ByType("typeC") };

		// get them from the client
		Feed<SocialMediaAssociation> results = socialMediaAssociationClient.getAll(null, queries, null, null, null);

		// make sure we got a good result
		assertThat(results.getEntries().size(), equalTo(0));
	}

	public void byPrimaryShouldReturnSmaByPrimaryWhenItExists() {

		// create 2 entities with diff primary values
		URI sma1Id = URI.create(baseUrl.concat("/data/Program/" + objectIdProvider.nextId()));
		SocialMediaAssociation sma1 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.primary, true),
				new DataServiceField(SocialMediaAssociationField.entityId, sma1Id));

		socialMediaAssociationClient.create(sma1);

		SocialMediaAssociation sma2 = socialMediaAssociationFactory.create(
				new DataServiceField(SocialMediaAssociationField.primary, false), new DataServiceField(SocialMediaAssociationField.type,
						"Facebook"));
		SocialMediaAssociation sma2c = socialMediaAssociationClient.create(sma2);

		// make the query for one that doesn't exist
		Query[] queries = new Query[] { new ByPrimary(false) };

		// get them from the client
		Feed<SocialMediaAssociation> results = socialMediaAssociationClient.getAll(null, queries, null, null, null);

		// make sure we got a good result
		assertThat(results.getEntries().size(), equalTo(1));
		assertThat(results.getEntries().get(0).getPrimary(), equalTo(false));
		assertThat(results.getEntries().get(0).getId(), equalTo(sma2c.getId()));
	}

	public void byPrimaryShouldReturnNoResultsWhenItDoesntExist() {

		// create 2 entities with diff primary values
		URI sma1Id = URI.create(baseUrl.concat("/data/Program/" + objectIdProvider.nextId()));
		SocialMediaAssociation sma1 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.primary, true),
				new DataServiceField(SocialMediaAssociationField.entityId, sma1Id));
		socialMediaAssociationClient.create(sma1);

		URI sma2Id = URI.create(baseUrl.concat("/data/Program/" + objectIdProvider.nextId()));
		SocialMediaAssociation sma2 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.primary, true),
				new DataServiceField(SocialMediaAssociationField.entityId, sma2Id));
		socialMediaAssociationClient.create(sma2);

		// make the query for one that doesn't exist
		Query[] queries = new Query[] { new ByPrimary(false) };

		// get them from the client
		Feed<SocialMediaAssociation> results = socialMediaAssociationClient.getAll(null, queries, null, null, null);

		// make sure we got a good result
		assertThat(results.getEntries().size(), equalTo(0));
	}

	public void byIdentifierShouldReturnSmaByPrimaryWhenItExists() {

		// create 2 entities with diff Identifier values
		String id1 = "uid" + objectIdProvider.nextId();
		SocialMediaAssociation sma1 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.identifier, id1));
		socialMediaAssociationClient.create(sma1);

		String id2 = "uid" + objectIdProvider.nextId();
		SocialMediaAssociation sma2 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.identifier, id2));
		SocialMediaAssociation sma2c = socialMediaAssociationClient.create(sma2);

		// make the query for one that doesn't exist
		Query[] queries = new Query[] { new ByIdentifier(id2) };

		// get them from the client
		Feed<SocialMediaAssociation> results = socialMediaAssociationClient.getAll(null, queries, null, null, null);

		// make sure we got a good result
		assertThat(results.getEntries().size(), equalTo(1));
		assertThat(results.getEntries().get(0).getIdentifier(), equalTo(id2));
		assertThat(results.getEntries().get(0).getId(), equalTo(sma2c.getId()));
	}

	public void byIdentifierShouldReturnNoResultsWhenItDoesntExist() {

		// create 2 entities with diff Identifier values
		String id1 = "uid" + objectIdProvider.nextId();
		SocialMediaAssociation sma1 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.identifier, id1));
		socialMediaAssociationClient.create(sma1);

		String id2 = "uid" + objectIdProvider.nextId();
		SocialMediaAssociation sma2 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.identifier, id2));
		socialMediaAssociationClient.create(sma2);

		// make the query for one that doesn't exist
		String otherId = "uid" + objectIdProvider.nextId();
		Query[] queries = new Query[] { new ByIdentifier(otherId) };

		// get them from the client
		Feed<SocialMediaAssociation> results = socialMediaAssociationClient.getAll(null, queries, null, null, null);

		// make sure we got a good result
		assertThat(results.getEntries().size(), equalTo(0));
	}

	public void byEntityIdShouldReturnSmaByEntityIdWhenItExists() {

		// create 2 entities with diff Identifier values
		URI sma1Id = URI.create(baseUrl.concat("/data/Program/" + objectIdProvider.nextId()));
		SocialMediaAssociation sma1 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.entityId,
				sma1Id));
		socialMediaAssociationClient.create(sma1);

		URI sma2Id = URI.create(baseUrl.concat("/data/Program/" + objectIdProvider.nextId()));
		SocialMediaAssociation sma2 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.entityId,
				sma2Id));
		SocialMediaAssociation sma2c = socialMediaAssociationClient.create(sma2);

		// make the query for one that exists
		Query[] queries = new Query[] { new ByEntityId(URIUtils.getIdValue(sma2Id)) };

		// get them from the client
		Feed<SocialMediaAssociation> results = socialMediaAssociationClient.getAll(null, queries, null, null, null);

		// make sure we got a good result
		assertThat(results.getEntries().size(), equalTo(1));
		assertThat(results.getEntries().get(0).getEntityId(), equalTo(sma2Id));
		assertThat(results.getEntries().get(0).getId(), equalTo(sma2c.getId()));
	}

	public void byEntityIdShouldReturnNoResultsWhenItDoesntExist() {

		// create 2 entities with diff Identifier values
		URI sma1Id = URI.create(baseUrl.concat("/data/Program/" + objectIdProvider.nextId()));
		SocialMediaAssociation sma1 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.entityId,
				sma1Id));
		socialMediaAssociationClient.create(sma1);

		URI sma2Id = URI.create(baseUrl.concat("/data/Program/" + objectIdProvider.nextId()));
		SocialMediaAssociation sma2 = socialMediaAssociationFactory.create(new DataServiceField(SocialMediaAssociationField.entityId,
				sma2Id));
		socialMediaAssociationClient.create(sma2);

		// make the query for one that doesn't exist
		Query[] queries = new Query[] { new ByEntityId(-1l) };

		// get them from the client
		Feed<SocialMediaAssociation> results = socialMediaAssociationClient.getAll(null, queries, null, null, null);

		// make sure we got a good result
		assertThat(results.getEntries().size(), equalTo(0));
	}

}
