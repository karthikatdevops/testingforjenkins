package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import java.net.URI;
import java.net.UnknownHostException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;

/**
 * Green Build test for cascading update for Program using TagAssociation
 * 
 * @author jethrolai
 * TODO MERLIN-9745
 */
@Test(groups = { "program", "tagAssociation", TestGroup.bug })
public class TagAssociationProgramCascadingUpdateIT extends EntityTestBase {

	/**
	 * 1. Create an entity instance and persist it 
	 * 2. Verify entity.version = 0
	 * 3. Verify entity has no tag ids 
	 * 4. Create TagAssociation 1 linking to entity and persist it 
	 * 5. Verify entity.version = 1 
	 * 6. Verify entity has 1 tag id 
	 * 7. Create TagAssociation 2 linking to entity 
	 * 8. Verify entity.version = 2 
	 * 9. Verify entity has 2 tags 
	 * 10.Delete TagAssociation 1
	 * 11.Verify entity.version = 3 
	 * 12.Verify entity has 1 tag 
	 * 13.Update Tag id of TagAssociation2 
	 * 14.Verify entity.version=4 
	 * 15.Verify entity's tag id
	 * 
	 * @throws UnknownHostException
	 *             Exception
	 * @throws InterruptedException
	 *             Exception
	 */
	public void cascadingUpdateValidationTest() throws UnknownHostException, InterruptedException {

		Program program = this.programClient.create(programFactory.create());
		program.setTitle("title");
		program.setType(ProgramType.Movie);
		Program programCreated = this.programClient.get(program.getId(),
				new String[] { ProgramField.tagIds.getLocalName(), DataObjectField.version.getLocalName(), DataObjectField.id.getLocalName() });

		Assert.assertEquals(programCreated.getTagIds().size(), 0);
		Assert.assertEquals(programCreated.getVersion(), new Long(0));

		program.setTitle(program.getTitle().concat(" update"));
		programClient.update(program);

		TagAssociation tagAssociation = this.tagAssociationClient.create(
				tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, program.getId())),
				new String[] { TagAssociationField.tagId.getLocalName(), DataObjectField.id.getLocalName() });
		URI tagId1 = tagAssociation.getTagId();

		programCreated = this.programClient.get(program.getId(), new String[] { ProgramField.tagIds.getLocalName(), DataObjectField.version.getLocalName(),
				DataObjectField.id.getLocalName() });
		Assert.assertEquals(programCreated.getVersion(), new Long(2));
		Assert.assertEquals(programCreated.getTagIds().size(), 1);
		Assert.assertEquals(programCreated.getTagIds().get(0), tagId1);
		
		program.setTitle(program.getTitle().concat(" update"));
		programClient.update(program);

		URI tagId2 = this.tagAssociationClient.create(
				tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, programCreated.getId())),
				new String[] { TagAssociationField.tagId.getLocalName() }).getTagId();

		programCreated = this.programClient.get(program.getId(), new String[] { ProgramField.tagIds.getLocalName(), DataObjectField.version.getLocalName(),
				DataObjectField.id.getLocalName() });

		Assert.assertEquals(programCreated.getVersion(), new Long(4));
		Assert.assertEquals(programCreated.getTagIds().size(), 2);
		Assert.assertTrue(programCreated.getTagIds().contains(tagId1));
		Assert.assertTrue(programCreated.getTagIds().contains(tagId2));

		long deletedObjects = this.tagAssociationClient.delete(tagAssociation.getId());
		Assert.assertEquals(1, deletedObjects);
		
		program.setTitle(program.getTitle().concat(" update"));
		programClient.update(program);
		
		programCreated = this.programClient.get(program.getId(), new String[] { ProgramField.tagIds.getLocalName(), DataObjectField.version.getLocalName(),
				DataObjectField.id.getLocalName() });
		Assert.assertEquals(programCreated.getVersion(), new Long(6));
		Assert.assertEquals(programCreated.getTagIds().size(), 1);
	}

}
