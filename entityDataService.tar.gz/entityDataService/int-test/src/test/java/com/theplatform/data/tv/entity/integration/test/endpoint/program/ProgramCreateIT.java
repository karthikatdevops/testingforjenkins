package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import static org.testng.Assert.assertNull;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * Created by gservente
 * 
 * Green Build Test cases for the creation of Programs.
 */
@Test(groups = { "program", "crud" })
public class ProgramCreateIT extends EntityTestBase {


	private static final int COMBINE_POST_BATCH_SIZE = 30;


	/**
	 * Test Case: CUC-C-P01
	 * 
	 * A program creation with all field set should be allowed.
	 * 
	 * @throws UnknownHostException
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateSeriesMasterWithAllFieldsSet() throws UnknownHostException {
		Program seriesMaster = this.seriesMasterProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster));
		seriesMaster.setTitle("A Program title");
		seriesMaster.setSortTitle("A sort title.");
		seriesMaster.setYear(2010);
		seriesMaster.setLongSynopsis("A long long long synopsis.");
		seriesMaster.setRuntime(120);
		seriesMaster.setStarRating(5);
		seriesMaster.setLanguage("eng");
		seriesMaster.setOriginalAirDate(new DateOnly(2010, 1, 24));
		seriesMaster.setCategory("Other");
		seriesMaster.setListByTitle(false);

		Program savedProgram = this.programClient.create(seriesMaster, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, seriesMaster);
	}

	/**
	 * Test Case: CUC-C-P02
	 * 
	 * A program creation with all field set and nulling fields that allow null
	 * should be allowed.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateSeriesMasterWithSomeFieldsAsNull() throws UnknownHostException {
		Program seriesMaster = this.seriesMasterProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster));
		seriesMaster.setTitle("A Program title");
		seriesMaster.setSortTitle("A sort title.");
		seriesMaster.setYear(null);
		seriesMaster.setLongSynopsis(null);
		seriesMaster.setRuntime(null);
		seriesMaster.setStarRating(null);
		seriesMaster.setLanguage(null);
		seriesMaster.setOriginalAirDate(null);
		seriesMaster.setCategory("Other");
		seriesMaster.setListByTitle(null);

		Program savedProgram = this.programClient.create(seriesMaster, (String[]) null);
		seriesMaster.setListByTitle(true);
		ProgramComparator.assertEquals(savedProgram, seriesMaster);
	}

	/**
	 * Test Case: CUC-C-P03
	 * 
	 * A program creation with some fields set should be allowed.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateSeriesMasterWithSomeFieldsSet() {
		Program seriesMaster = this.seriesMasterProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster));
		seriesMaster.setTitle("A Program title");
		seriesMaster.setSortTitle("A sort title.");
		seriesMaster.setYear(2010);
		seriesMaster.setLongSynopsis(null);
		seriesMaster.setRuntime(null);
		seriesMaster.setStarRating(5);
		seriesMaster.setLanguage("eng");
		seriesMaster.setOriginalAirDate(null);
		seriesMaster.setCategory("Other");
		seriesMaster.setListByTitle(false);

		Program savedProgram = this.programClient.create(seriesMaster, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, seriesMaster);
	}

	/**
	 * Test Case: CUC-C-P04
	 * 
	 * A program creation with all field set should be allowed.
	 * 
	 * @throws UnknownHostException
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateEpisodeWithAllFieldsSet() throws UnknownHostException {
		Program episode = this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		episode.setTitle("A Program title");
		episode.setEpisodeTitle("An episode title");
		episode.setSortTitle("A sort title.");
		episode.setYear(2010);
		episode.setLongSynopsis("A long long long synopsis.");
		episode.setRuntime(120);
		episode.setStarRating(5);
		episode.setLanguage("eng");
		episode.setOriginalAirDate(new DateOnly(2010, 1, 24));
		episode.setCategory("Other");
		episode.setListByTitle(false);

		Program savedProgram = this.programClient.create(episode, new String[] {});
		ProgramComparator.assertEquals(savedProgram, episode);
	}

	/**
	 * Test Case: CUC-C-P05
	 * 
	 * A program creation with all field set nulling fields that allow null
	 * should be allowed.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateEpisodeWithSomeFieldsAsNull() throws UnknownHostException {
		Program episode = this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		episode.setTitle("A Program title");
		episode.setEpisodeTitle("An episode title");
		episode.setSortTitle("A sort title.");
		episode.setYear(null);
		episode.setLongSynopsis(null);
		episode.setRuntime(null);
		episode.setStarRating(null);
		episode.setLanguage(null);
		episode.setOriginalAirDate(null);
		episode.setCategory("Other");
		episode.setListByTitle(null);

		Program savedProgram = this.programClient.create(episode, (String[]) null);
		episode.setListByTitle(true);
		ProgramComparator.assertEquals(savedProgram, episode);
	}

	/**
	 * Test Case: CUC-C-P06
	 * 
	 * A program creation with some field set should be allowed.
	 * 
	 * @throws UnknownHostException
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateEpisodeWithSomeFieldsSet() throws UnknownHostException {
		Program episode = this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		episode.setTitle("A Program title");
		episode.setEpisodeTitle("An episode title");
		episode.setSortTitle("A sort title.");
		episode.setYear(null);
		episode.setLongSynopsis(null);
		episode.setRuntime(120);
		episode.setStarRating(null);
		episode.setLanguage(null);
		episode.setOriginalAirDate(new DateOnly(2010, 1, 24));
		episode.setCategory("Other");
		episode.setListByTitle(false);

		Program savedProgram = this.programClient.create(episode, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, episode);
	}

	/**
	 * Test Case: CUC-C-P07
	 * 
	 * A program (Other) creation with all field set should be allowed.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateOtherWithAllFieldsSet() {
		Program otherProgram = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Other),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		otherProgram.setTitle("A Program title");
		otherProgram.setSortTitle("A sort title.");
		otherProgram.setYear(2010);
		otherProgram.setLongSynopsis("A long long long synopsis.");
		otherProgram.setRuntime(120);
		otherProgram.setStarRating(5);
		otherProgram.setLanguage("eng");
		otherProgram.setOriginalAirDate(new DateOnly(2010, 1, 24));
		otherProgram.setCategory("Other");
		otherProgram.setListByTitle(false);

		Program savedProgram = this.programClient.create(otherProgram, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, otherProgram);
	}

	/**
	 * Test Case: CUC-C-P07
	 * 
	 * A program (SportingEvent) creation with all field set should be allowed.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateSportingEventWithAllFieldsSet() {
		Program sportingEventProgram = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.SportingEvent),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		sportingEventProgram.setTitle("A Program title");
		sportingEventProgram.setSortTitle("A sort title.");
		sportingEventProgram.setYear(2010);
		sportingEventProgram.setLongSynopsis("A long long long synopsis.");
		sportingEventProgram.setRuntime(120);
		sportingEventProgram.setStarRating(5);
		sportingEventProgram.setLanguage("eng");
		sportingEventProgram.setOriginalAirDate(new DateOnly(2010, 1, 24));
		sportingEventProgram.setCategory("Other");
		sportingEventProgram.setListByTitle(false);

		Program savedProgram = this.programClient.create(sportingEventProgram, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, sportingEventProgram);
	}

	/**
	 * Test Case: CUC-C-P07
	 * 
	 * A program (Movie) creation with all field set should be allowed.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateMovieWithAllFieldsSet() {
		Program movie = this.movieProgramFactory.create(new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		movie.setTitle("A Program title");
		movie.setSortTitle("A sort title.");
		movie.setYear(2010);
		movie.setLongSynopsis("A long long long synopsis.");
		movie.setRuntime(120);
		movie.setStarRating(5);
		movie.setLanguage("eng");
		movie.setOriginalAirDate(new DateOnly(2010, 1, 24));
		movie.setCategory("Other");
		movie.setListByTitle(false);

		Program savedProgram = this.programClient.create(movie, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, movie);
	}

	/**
	 * Test Case: CUC-C-P08
	 * 
	 * A program (Other) creation with all field set nulling fields that allow
	 * null should be allowed .
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateOtherWithSomeFieldsAsNull() {
		Program otherProgram = this.programFactory.create(new DataServiceField(ProgramField.type, ProgramType.Other),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		otherProgram.setTitle("A Program title");
		otherProgram.setSortTitle("A sort title.");
		otherProgram.setYear(null);
		otherProgram.setLongSynopsis(null);
		otherProgram.setRuntime(null);
		otherProgram.setStarRating(null);
		otherProgram.setLanguage(null);
		otherProgram.setOriginalAirDate(null);
		otherProgram.setCategory("Other");
		otherProgram.setListByTitle(null);

		Program savedProgram = this.programClient.create(otherProgram, (String[]) null);
		otherProgram.setListByTitle(true);
		ProgramComparator.assertEquals(savedProgram, otherProgram);
	}

	/**
	 * Test Case: CUC-C-P08
	 * 
	 * A program (SportingEvent) creation with all field set nulling fields that
	 * allow null should be allowed .
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateSportingEventWithSomeFieldsAsNull() {
		Program sportingEvent = this.programFactory.create(new DataServiceField(ProgramField.type, ProgramType.SportingEvent),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		sportingEvent.setTitle("A Program title");
		sportingEvent.setSortTitle("A sort title.");
		sportingEvent.setYear(null);
		sportingEvent.setLongSynopsis(null);
		sportingEvent.setRuntime(null);
		sportingEvent.setStarRating(null);
		sportingEvent.setLanguage(null);
		sportingEvent.setOriginalAirDate(null);
		sportingEvent.setCategory("Other");
		sportingEvent.setListByTitle(null);

		Program savedProgram = this.programClient.create(sportingEvent, (String[]) null);
		sportingEvent.setListByTitle(true);
		ProgramComparator.assertEquals(savedProgram, sportingEvent);
	}

	/**
	 * Test Case: CUC-C-P08
	 * 
	 * A program (Movie) creation with all field set nulling fields that allow
	 * null should be allowed .
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateMovieWithSomeFieldsAsNull() {
		Program movie = this.movieProgramFactory.create(new DataServiceField(ProgramField.type, ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		movie.setTitle("A Program title");
		movie.setSortTitle("A sort title.");
		movie.setYear(null);
		movie.setLongSynopsis(null);
		movie.setRuntime(null);
		movie.setStarRating(null);
		movie.setLanguage(null);
		movie.setOriginalAirDate(null);
		movie.setCategory("Other");
		movie.setListByTitle(null);

		Program savedProgram = this.programClient.create(movie, (String[]) null);
		movie.setListByTitle(true);
		ProgramComparator.assertEquals(savedProgram, movie);
	}

	/**
	 * Test Case: CUC-C-P09
	 * 
	 * A program (Other) creation with all field set should be allowed.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateOtherWithSomeFieldsSet() {
		Program otherProgram = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Other),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		otherProgram.setTitle("A Program title");
		otherProgram.setSortTitle("A sort title.");
		otherProgram.setYear(null);
		otherProgram.setLongSynopsis(null);
		otherProgram.setRuntime(120);
		otherProgram.setStarRating(5);
		otherProgram.setLanguage("eng");
		otherProgram.setOriginalAirDate(null);
		otherProgram.setCategory("Other");
		otherProgram.setListByTitle(false);

		Program savedProgram = this.programClient.create(otherProgram, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, otherProgram);
	}

	/**
	 * Test Case: CUC-C-P09
	 * 
	 * A program (SportingEvent) creation with all field set should be allowed.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateSportingEventWithSomeFieldsSet() {
		Program sportingEvent = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.SportingEvent),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		sportingEvent.setTitle("A Program title");
		sportingEvent.setSortTitle("A sort title.");
		sportingEvent.setYear(null);
		sportingEvent.setLongSynopsis(null);
		sportingEvent.setRuntime(120);
		sportingEvent.setStarRating(5);
		sportingEvent.setLanguage("eng");
		sportingEvent.setOriginalAirDate(null);
		sportingEvent.setCategory("Other");
		sportingEvent.setListByTitle(false);

		Program savedProgram = this.programClient.create(sportingEvent, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, sportingEvent);
	}

	/**
	 * Test Case: CUC-C-P09
	 * 
	 * A program (Movie) creation with all field set should be allowed.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateMovieWithSomeFieldsSet() {
		Program movie = this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		movie.setTitle("A Program title");
		movie.setSortTitle("A sort title.");
		movie.setYear(null);
		movie.setLongSynopsis(null);
		movie.setRuntime(120);
		movie.setStarRating(5);
		movie.setLanguage("eng");
		movie.setOriginalAirDate(null);
		movie.setCategory("Other");
		movie.setListByTitle(false);

		Program savedProgram = this.programClient.create(movie, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, movie);
	}

	/**
	 * Test Case: CUC-C-P10
	 * 
	 * The Category field only allows specific values.
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateProgramsAllowedCategoyValues() {
		this.doCreateProgramTest(this.createBasicProgramForCategory("Other"));
		this.doCreateProgramTest(this.createBasicProgramForCategory("Movie"));
		this.doCreateProgramTest(this.createBasicProgramForCategory("Children\'s"));
		this.doCreateProgramTest(this.createBasicProgramForCategory("News"));
		this.doCreateProgramTest(this.createBasicProgramForCategory("Music"));
		this.doCreateProgramTest(this.createBasicProgramForCategory("Lifestyle"));
		this.doCreateProgramTest(this.createBasicProgramForCategory("Sports"));
	}

	/**
	 * Test Case: CUC-C-P11
	 * 
	 * The Category field only allows specific values.
	 */
	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testCreateProgramsWithInvalidCategoyValues() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Other),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		program.setTitle("A Program title");
		program.setSortTitle("A sort title.");
		program.setYear(1990);
		program.setLongSynopsis("A long long long synopsis");
		program.setRuntime(120);
		program.setStarRating(5);
		program.setLanguage("eng");
		program.setOriginalAirDate(new DateOnly(1990, 1, 24));
		program.setCategory("An invalid category");
		program.setListByTitle(false);

		Program savedProgram = this.programClient.create(program, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, program);
	}

	private Program createBasicProgramForCategory(String category) {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type, ProgramType.Other),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		program.setTitle("A Program title");
		program.setSortTitle("A sort title.");
		program.setYear(1990);
		program.setLongSynopsis("A long long long synopsis");
		program.setRuntime(120);
		program.setStarRating(5);
		program.setLanguage("eng");
		program.setOriginalAirDate(new DateOnly(1990, 1, 24));
		program.setCategory(category);
		program.setListByTitle(false);

		return program;
	}

	/**
	 * Test Case: CoUC-C-P03
	 * 
	 * When creating a list of objects specify that only the id fields will be
	 * retrieved and data object is created completely.
	 * 
	 */
	@Test(groups = { TestGroup.gbTest })
	public void testCreateProgramsGettingOnlyIdFieldBack() {
		List<Program> createdPrograms = this.programFactory.create(COMBINE_POST_BATCH_SIZE,
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));

		String[] returnedFieldsSet = { "id" };
		Feed<Program> savedProgramsFeed = this.programClient.create(createdPrograms, returnedFieldsSet);
		List<Program> savedPrograms = savedProgramsFeed.getEntries();

		this.verifyIdsAreEquals(createdPrograms, savedPrograms);
		this.veryfyOnlyIdFieldIsSet(savedPrograms);
		this.verifyCreatedAndSavedAreEqualsByRetrieve(createdPrograms);
	}

	private void doCreateProgramTest(Program aProgram) {
		Program savedProgram = this.programClient.create(aProgram, (String[]) null);
		ProgramComparator.assertEquals(savedProgram, aProgram);
	}

	private void verifyCreatedAndSavedAreEqualsByRetrieve(List<Program> expectedPrograms) {
		URI[] ids = this.getProgramsIds(expectedPrograms);
		ProgramComparator.assertEquals(this.programClient.get(ids, new String[] {}), expectedPrograms);
	}

	private List<Program> retrievePrograms(List<Program> programs) {
		URI[] ids = this.getProgramsIds(programs);
		Feed<Program> programFeed = this.programClient.get(ids, null);
		return programFeed.getEntries();
	}

	private URI[] getProgramsIds(List<Program> programs) {
		URI[] ids = new URI[programs.size()];
		int i = 0;
		for (Program program : programs) {
			ids[i++] = program.getId();
		}
		return ids;
	}

	private void veryfyOnlyIdFieldIsSet(List<Program> savedPrograms) {
		for (Program program : savedPrograms) {
			this.assertAllFieldsOtherThanIdAreNull(program);
		}
	}

	private void verifyIdsAreEquals(List<Program> expectedPrograms, List<Program> actualPrograms) {
		ComparatorUtils.assertIdsAreEqual(expectedPrograms, actualPrograms);
	}

	private void assertAllFieldsOtherThanIdAreNull(Program program) {
		assertNull(program.getOwnerId());
		assertNull(program.getTitle());
		assertNull(program.getYear());
		assertNull(program.getShortSynopsis());
		assertNull(program.getMediumSynopsis());
		assertNull(program.getLongSynopsis());
		assertNull(program.getRuntime());
		assertNull(program.getType());
		assertNull(program.getLanguage());
		assertNull(program.getPartNumber());
		assertNull(program.getTotalParts());
		assertNull(program.getSortTitle());
		assertNull(program.getStarRating());
		assertNull(program.getOriginalAirDate());
		assertNull(program.getCategory());
		assertNull(program.getFirstRunCompanyId());
		assertNull(program.getReleaseDate());
		assertNull(program.getFirstAirDate());
		assertNull(program.getLastAirDate());
		assertNull(program.getSeriesId());
		assertNull(program.getTvSeasonId());
		assertNull(program.getTvSeasonNumber());
		assertNull(program.getTvSeasonEpisodeNumber());
		assertNull(program.getSeriesEpisodeNumber());
		assertNull(program.getEpisodeTitle());
	}

}
