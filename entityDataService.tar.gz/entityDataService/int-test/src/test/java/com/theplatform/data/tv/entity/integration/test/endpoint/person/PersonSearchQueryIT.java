package com.theplatform.data.tv.entity.integration.test.endpoint.person;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.client.query.SearchQuery;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.test.PersonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Test(groups = {"person"})
public class PersonSearchQueryIT extends EntityTestBase {

    @Test(groups = {TestGroup.gbTest}, enabled = true)
    public void testGetPersonsByLucene() {
        List<Person> persons = personFactory.create(6);

        persons.get(0).setBirthName("Robert James Smith");
        persons.get(0).setKnownFor(Arrays.asList("Music"));
        persons.get(0).setSortName("Bobby Muzik");
        persons.get(0).setPersonType("Person");

        persons.get(1).setBirthName("Francis Thomas James");
        persons.get(1).setKnownFor(Arrays.asList("Video"));
        persons.get(1).setSortName("Frank Benjamin");
        persons.get(1).setPersonType("Person");

        persons.get(2).setKnownFor(Arrays.asList("Music"));
        persons.get(2).setSortName("Susie Muzik");
        persons.get(2).setPersonType("Person");

        persons.get(3).setBirthName("Jennifer Word Smith");
        persons.get(3).setKnownFor(Arrays.asList("Video"));
        persons.get(3).setPersonType("Band");

        persons.get(4).setBirthName("Benjamin Abraham Horowitz");
        persons.get(4).setKnownFor(Arrays.asList("Music", "Video"));
        persons.get(4).setSortName("Benny MV");
        persons.get(4).setPersonType("Band");

        persons.get(5).setBirthName("Jacqueline Words McNeil");
        persons.get(5).setKnownFor(Arrays.asList("Video", "Music"));
        persons.get(5).setSortName("Jackie VM");
        persons.get(5).setPersonType("Band");

        personClient.create(persons);

        // Wait for some arbitrary amount of time so notification can be picked up by
        // entityIndexer and it can push the persons into solr
        try {
            Thread.sleep(15000);
        } catch (InterruptedException e) {
        }

        Feed<Person> retrievedPersons;
        List<Person> expectedPersons;
        List<Person> sortedPersons;

        retrievedPersons = personClient.getAll(null, new Query[]{new SearchQuery("Michael")}, null, null, true);
        Assert.assertEquals(retrievedPersons.getEntryCount(), new Long(0));

        retrievedPersons = personClient.getAll(null, new Query[]{new SearchQuery("Thomas")}, null, null, true);
        expectedPersons = Arrays.asList(persons.get(1));
        PersonComparator.assertEquals(retrievedPersons, expectedPersons);

        retrievedPersons = personClient.getAll(null, new Query[]{new SearchQuery("Muzik")}, null, null, true);
        expectedPersons = Arrays.asList(persons.get(0), persons.get(2));
        sortedPersons = sortDataObjectsById(retrievedPersons);
        PersonComparator.assertEquals(expectedPersons, sortedPersons);

        retrievedPersons = personClient.getAll(null, new Query[]{new SearchQuery("Word")}, null, null, true);
        expectedPersons = Arrays.asList(persons.get(3), persons.get(5));
        sortedPersons = sortDataObjectsById(retrievedPersons);
        PersonComparator.assertEquals(expectedPersons, sortedPersons);

        retrievedPersons = personClient.getAll(null, new Query[]{new SearchQuery("birthName:Benjamin")}, null, null, true);
        expectedPersons = Arrays.asList(persons.get(4));
        PersonComparator.assertEquals(retrievedPersons, expectedPersons);
    }

    private <T extends DataObject> List<T> sortDataObjectsById(Feed<T> feed) {
        List<T> entries = feed.getEntries();
        Collections.sort(entries, new Comparator<T>() {
            @Override
            public int compare(T o1, T o2) {
                if (o1 == null && o2 == null) {
                    return 0;
                }
                if (o1 == null) {
                    return -1;
                }
                if (o2 == null) {
                    return 1;
                }
                return (int) (URIUtils.getIdValue(o1.getId()) - URIUtils.getIdValue(o2.getId()));
            }
        });
        return entries;
    }
}
