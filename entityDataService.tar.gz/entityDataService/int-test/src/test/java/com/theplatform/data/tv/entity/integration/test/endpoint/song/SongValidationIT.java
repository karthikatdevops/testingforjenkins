package com.theplatform.data.tv.entity.integration.test.endpoint.song;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.Arrays;

import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.entity.api.fields.SongCreditField;
import com.theplatform.data.tv.entity.api.fields.SongField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.test.SongComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "song", "validation" })
public class SongValidationIT extends EntityTestBase {

	//duration
	@Test(expectedExceptions = ValidationException.class)
	public void testSongCreateDurationLessThanZero() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songClient.create(this.songFactory.create(new DataServiceField(SongField.duration, -1)));
	}

	public void testSongCreateDurationMoreThanZero() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songClient.create(this.songFactory.create(new DataServiceField(SongField.duration, 1)));
	}

	public void testSongCreateDurationEqualToZero() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songClient.create(this.songFactory.create(new DataServiceField(SongField.duration, 0)));
	}

	// primaryPersonIds
	// TODO no Person side validation, might need to be implemented
	public void testSongCreateWithPrimaryAndGuestArtistSongCredits() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		Song song = this.songClient.create(this.songFactory.create(), new String[] {});
		this.songCreditClient.create(songCreditFactory.create(new DataServiceField(SongCreditField.type, "GuestArtist"), new DataServiceField(SongCreditField.songId, song.getId())));
		URI primaryPersonPersonTypePersonId = this.personClient.create(
				personFactory.create(new DataServiceField(PersonField.personType, "Person"), new DataServiceField(PersonField.knownFor, Arrays.asList("Music")))).getId();
		URI primaryPersonPersonTypeBandId = this.personClient.create(
				personFactory.create(new DataServiceField(PersonField.personType, "Band"), new DataServiceField(PersonField.knownFor, Arrays.asList("Music")))).getId();
		URI primaryPersonPersonTypeNoMusicKnownForId = this.personClient.create(
				personFactory.create(new DataServiceField(PersonField.personType, "Person"), new DataServiceField(PersonField.knownFor, Arrays.asList("Video")))).getId();
		this.songCreditClient.create(songCreditFactory.create(new DataServiceField(SongCreditField.type, "PrimaryArtist"), new DataServiceField(SongCreditField.songId, song.getId()),
				new DataServiceField(SongCreditField.personId, primaryPersonPersonTypePersonId), new DataServiceField(SongCreditField.rank, 1)));
		this.songCreditClient.create(songCreditFactory.create(new DataServiceField(SongCreditField.type, "PrimaryArtist"), new DataServiceField(SongCreditField.songId, song.getId()),
				new DataServiceField(SongCreditField.personId, primaryPersonPersonTypeBandId), new DataServiceField(SongCreditField.rank, 2)));
		this.songCreditClient.create(songCreditFactory.create(new DataServiceField(SongCreditField.type, "PrimaryArtist"), new DataServiceField(SongCreditField.songId, song.getId()),
				new DataServiceField(SongCreditField.personId, primaryPersonPersonTypeNoMusicKnownForId), new DataServiceField(SongCreditField.rank, 3)));

		song.setPrimaryPersonIds(Arrays.asList(new URI[] { primaryPersonPersonTypePersonId, primaryPersonPersonTypeBandId,
				primaryPersonPersonTypeNoMusicKnownForId }));

		SongComparator.assertEquals(songClient.get(song.getId(), new String[] {}), song);
	}

}
