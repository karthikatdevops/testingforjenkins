package com.theplatform.data.tv.entity.integration.test.endpoint.programmediaassociation;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.DateUtil;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.fields.ProgramMediaAssociationField;
import com.theplatform.data.tv.entity.api.test.ProgramMediaAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;


@Test(groups = { "programMediaAssociation","sort",  TestGroup.gbTest })
public class ProgramMediaAssociationSortIT extends EntityTestBase {
	private static final int TEST_LIST_SIZE = 4;

	private List<ProgramMediaAssociation> programMediaAssociations;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		programMediaAssociations = this.programMediaAssociationFactory.create(TEST_LIST_SIZE);

	}

	public void testProgramMediaAssociationSortByAvailableDate() {
		
		programMediaAssociations.set(3, this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.availableDate, DateUtil.parseDate("12/04/2010")));
		programMediaAssociations.set(0, this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.availableDate, DateUtil.parseDate("12/05/2010")));
		programMediaAssociations.set(1, this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.availableDate, DateUtil.parseDate("01/05/2011")));
		programMediaAssociations.set(2, this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.availableDate, DateUtil.parseDate("12/05/2012")));

		// SORT EXPECTED
		List<ProgramMediaAssociation> expectedSortedProgramMediaAssociations = new ArrayList<>(programMediaAssociations.size());
		expectedSortedProgramMediaAssociations.add(programMediaAssociations.get(3));
		expectedSortedProgramMediaAssociations.add(programMediaAssociations.get(0));
		expectedSortedProgramMediaAssociations.add(programMediaAssociations.get(1));
		expectedSortedProgramMediaAssociations.add(programMediaAssociations.get(2));

		// RETRIVE WHITH SORTING
		Sort requestSort = new Sort(ProgramMediaAssociationField.availableDate.getLocalName(), false);
		Feed<ProgramMediaAssociation> retrievedEntities = this.programMediaAssociationClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { requestSort }, null, false);

		ProgramMediaAssociationComparator.assertEquals(retrievedEntities, expectedSortedProgramMediaAssociations);
	}

	public void testProgramMediaAssociationSortByExpirationDate() {
		
		programMediaAssociations.set(3, this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.expirationDate, DateUtil.parseDate("12/04/2010")));
		programMediaAssociations.set(0, this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.expirationDate, DateUtil.parseDate("12/05/2010")));
		programMediaAssociations.set(1, this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.expirationDate, DateUtil.parseDate("01/05/2011")));
		programMediaAssociations.set(2, this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.expirationDate, DateUtil.parseDate("12/05/2012")));

		// SORT EXPECTED
		List<ProgramMediaAssociation> expectedSortedProgramMediaAssociations = new ArrayList<>(programMediaAssociations.size());
		expectedSortedProgramMediaAssociations.add(programMediaAssociations.get(3));
		expectedSortedProgramMediaAssociations.add(programMediaAssociations.get(0));
		expectedSortedProgramMediaAssociations.add(programMediaAssociations.get(1));
		expectedSortedProgramMediaAssociations.add(programMediaAssociations.get(2));

		// RETRIVE WHITH SORTING
		Sort requestSort = new Sort(ProgramMediaAssociationField.expirationDate.getLocalName(), false);
		Feed<ProgramMediaAssociation> retrievedAwards = this.programMediaAssociationClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { requestSort }, null, false);

		ProgramMediaAssociationComparator.assertEquals(retrievedAwards, expectedSortedProgramMediaAssociations);
	}
}
