package com.theplatform.data.tv.entity.integration.test.endpoint.sportsevent;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.util.MerlinUriUtil;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.albumreleasesongassociation.ByAlbumReleaseId;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.SongField;
import com.theplatform.data.tv.entity.api.fields.SportsEventField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

/**
 * This test (and others like it) is meant to validate that the SportsEvent client does not return denormalized
 * entities (from associated endpoints) that are marked (have their MRT set to something)
 * other than AudienceAvailable
 * <p/>
 * Author: Vincent Fumo (vfumo) : vincent_fumo@cable.comcast.com
 * Created Date: 3/14/14 (today was pi day)
 */
@Test(groups = {"sportsEvent", "denormalizedFields", TestGroup.gbTest})
public class SportsEventDenormalizedFieldsIT extends EntityTestBase {

    public void gettingASportsEventShouldNotReturnNonAAProgramSportsEvents() {
        SportsEvent entity = sportsEventFactory.create();
        sportsEventClient.create(entity);
        URI entityId = entity.getId();

        // create a program
        Program program = programClient.create(programFactory.create());
        URI programId = program.getId();

        // create a program Sports Event
        ProgramSportsEvent programSportsEvent = new ProgramSportsEvent();
        programSportsEvent.setId(URI.create(programSportsEventClient.getBaseUrl() + "data/ProgramSportsEvent/" + objectIdProvider.nextId()));
        programSportsEvent.setProgramId(programId);
        programSportsEvent.setSportsEventId(entityId);
        programSportsEvent.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        programSportsEventClient.create(programSportsEvent);

        // 1) make sure that we get the relatedEntity (since it's AA)
        SportsEvent retrievedEntity = sportsEventClient.get(entityId, new String[]{SportsEventField.programIds.name()});
        List<URI> associations = retrievedEntity.getProgramIds();
        assertThat(associations.size(), is(1));

        URI association = associations.get(0);
        assertThat(association, is(programId));

        // 2) change the relatedEntity to be non AA
        programSportsEvent.setMerlinResourceType(MerlinResourceType.Inactive);
        programSportsEventClient.update(programSportsEvent);

        // 3) validate that the relatedEntity doesn't return
        // note: we change the fields returned so we aren't dealing with a stale cache
        retrievedEntity = sportsEventClient.get(entityId, new String[]{SportsEventField.merlinResourceType.name(), SportsEventField.programIds.name()});
        associations = retrievedEntity.getProgramIds();
        assertThat(associations.size(), is(0));
    }


}
