package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.ProgramMediaAssociationField;
import com.theplatform.data.tv.entity.api.fields.TagField;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.api.test.ProgramMediaAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;

/**
 * 
 * @author jethrolai
 */
@Test(groups = {"merlinResourceType"})
public class MerlinResourceTypeUpdateIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testProgramMediaAssociationUpdate() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        //stage MRT Temporary and AA programs to be used by PMA later...
        Program programAudienceAvailable = this.programFactory.create(
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.local, false),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>())
        );
		URI programAudienceAvailableId = this.programClient.create(programAudienceAvailable).getId();
		programAudienceAvailable.setId(programAudienceAvailableId);
		ProgramComparator.assertEquals(this.programClient.get(programAudienceAvailableId, null), programAudienceAvailable);

		Program programTemporary = this.programFactory.create(
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.Temporary),
                new DataServiceField(ProgramField.local, false),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>())
        );
		URI programTemporaryId = this.programClient.create(programTemporary).getId();
		programTemporary.setId(programTemporaryId);
		ProgramComparator.assertEquals(this.programClient.get(programTemporaryId, null), programTemporary);

		ProgramMediaAssociation programMediaAssociation = this.programMediaAssociationFactory.create(
                new DataServiceField(ProgramMediaAssociationField.programId, programAudienceAvailableId),
				new DataServiceField(ProgramMediaAssociationField.merlinResourceType, null),
                new DataServiceField(ProgramMediaAssociationField.mediaId, createMediaId())
        );
		programMediaAssociation.setId(this.programMediaAssociationClient.create(programMediaAssociation).getId());

        //created a PMA with no MRT set, but should see it default to AA:
		programMediaAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		programMediaAssociation.setProgramType(programAudienceAvailable.getType());
        programMediaAssociation.setMediaGuid(programMediaAssociation.getMediaId().getMediaGuid());
		ProgramMediaAssociationComparator.assertEquals(this.programMediaAssociationClient.get(programMediaAssociation.getId(), null), programMediaAssociation);

        // now updating PMA programId to temporary program id, and null MRT; should see it default to Temporary.
		programMediaAssociation.setProgramId(programTemporaryId);
		programMediaAssociation.setMerlinResourceType(null);
		programMediaAssociationClient.update(programMediaAssociation);

		programMediaAssociation.setMerlinResourceType(MerlinResourceType.Temporary);
		ProgramMediaAssociationComparator.assertEquals(this.programMediaAssociationClient.get(programMediaAssociation.getId(), null), programMediaAssociation);

	}

	@Test(groups = { TestGroup.gbTest })
	public void testTagAssociationMerlinResourceTypeUpdateOneParent() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI tagAudienceAvailableId = this.tagClient.create(
				this.tagFactory.create(new DataServiceField(TagField.merlinResourceType, MerlinResourceType.AudienceAvailable))).getId();
		Assert.assertEquals(this.tagClient.get(tagAudienceAvailableId, new String[] { TagField.merlinResourceType.getLocalName() }).getMerlinResourceType(),
				MerlinResourceType.AudienceAvailable);

		URI tagTemporaryId = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.merlinResourceType, MerlinResourceType.Temporary)))
				.getId();
		Assert.assertEquals(this.tagClient.get(tagTemporaryId, new String[] { TagField.merlinResourceType.getLocalName() }).getMerlinResourceType(),
				MerlinResourceType.Temporary);

		URI programAudienceAvailableId = this.programClient.create(
				this.programFactory.create(new DataServiceField(TagField.merlinResourceType, MerlinResourceType.AudienceAvailable))).getId();
		Assert.assertEquals(this.programClient.get(programAudienceAvailableId, new String[] { ProgramField.merlinResourceType.getLocalName() })
				.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);

		URI programTemporaryId = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.Temporary))).getId();
		Assert.assertEquals(
				this.programClient.get(programTemporaryId, new String[] { ProgramField.merlinResourceType.getLocalName() }).getMerlinResourceType(),
				MerlinResourceType.Temporary);

		TagAssociation tagAssociation = this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, programTemporaryId),
				new DataServiceField(TagAssociationField.tagId, tagTemporaryId), new DataServiceField(TagAssociationField.merlinResourceType, null));
		URI tagAssociationId = this.tagAssociationClient.create(tagAssociation).getId();
		Assert.assertEquals(this.tagAssociationClient.get(tagAssociationId, new String[] { TagAssociationField.merlinResourceType.getLocalName() })
				.getMerlinResourceType(), MerlinResourceType.Temporary);

		tagAssociation.setTagId(tagAudienceAvailableId);
		tagAssociation.setMerlinResourceType(null);
		this.tagAssociationClient.update(tagAssociation);

		Assert.assertEquals(this.tagAssociationClient.get(tagAssociationId, new String[] { TagAssociationField.merlinResourceType.getLocalName() })
				.getMerlinResourceType(), MerlinResourceType.Temporary);

		tagAssociation.setEntityId(programAudienceAvailableId);
		tagAssociation.setMerlinResourceType(null);
		this.tagAssociationClient.update(tagAssociation);

		Assert.assertEquals(this.tagAssociationClient.get(tagAssociationId, new String[] { TagAssociationField.merlinResourceType.getLocalName() })
				.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);

		tagAssociation.setTagId(tagTemporaryId);
		tagAssociation.setMerlinResourceType(null);
		this.tagAssociationClient.update(tagAssociation);

		Assert.assertEquals(this.tagAssociationClient.get(tagAssociationId, new String[] { TagAssociationField.merlinResourceType.getLocalName() })
				.getMerlinResourceType(), MerlinResourceType.Temporary);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testTagAssociationMerlinResourceTypeUpdateBothParents() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI tagAudienceAvailableId = this.tagClient.create(
				this.tagFactory.create(new DataServiceField(TagField.merlinResourceType, MerlinResourceType.AudienceAvailable))).getId();
		Assert.assertEquals(this.tagClient.get(tagAudienceAvailableId, new String[] { TagField.merlinResourceType.getLocalName() }).getMerlinResourceType(),
				MerlinResourceType.AudienceAvailable);

		URI tagTemporaryId = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.merlinResourceType, MerlinResourceType.Temporary)))
				.getId();
		Assert.assertEquals(this.tagClient.get(tagTemporaryId, new String[] { TagField.merlinResourceType.getLocalName() }).getMerlinResourceType(),
				MerlinResourceType.Temporary);

		URI programAudienceAvailableId = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable))).getId();
		Assert.assertEquals(this.programClient.get(programAudienceAvailableId, new String[] { ProgramField.merlinResourceType.getLocalName() })
				.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);

		URI programTemporaryId = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.Temporary))).getId();
		Assert.assertEquals(
				this.programClient.get(programTemporaryId, new String[] { ProgramField.merlinResourceType.getLocalName() }).getMerlinResourceType(),
				MerlinResourceType.Temporary);

		TagAssociation tagAssociation = this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, programTemporaryId),
				new DataServiceField(TagAssociationField.tagId, tagTemporaryId), new DataServiceField(TagAssociationField.merlinResourceType, null));
		URI tagAssociationId = this.tagAssociationClient.create(tagAssociation).getId();
		Assert.assertEquals(this.tagAssociationClient.get(tagAssociationId, new String[] { TagAssociationField.merlinResourceType.getLocalName() })
				.getMerlinResourceType(), MerlinResourceType.Temporary);

		tagAssociation.setTagId(tagAudienceAvailableId);
		tagAssociation.setEntityId(programAudienceAvailableId);
		tagAssociation.setMerlinResourceType(null);
		this.tagAssociationClient.update(tagAssociation);

		Assert.assertEquals(this.tagAssociationClient.get(tagAssociationId, new String[] { TagAssociationField.merlinResourceType.getLocalName() })
				.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);

		tagAssociation.setTagId(tagTemporaryId);
		tagAssociation.setEntityId(programTemporaryId);
		tagAssociation.setMerlinResourceType(null);
		this.tagAssociationClient.update(tagAssociation);

		Assert.assertEquals(this.tagAssociationClient.get(tagAssociationId, new String[] { TagAssociationField.merlinResourceType.getLocalName() })
				.getMerlinResourceType(), MerlinResourceType.Temporary);
	}
}
