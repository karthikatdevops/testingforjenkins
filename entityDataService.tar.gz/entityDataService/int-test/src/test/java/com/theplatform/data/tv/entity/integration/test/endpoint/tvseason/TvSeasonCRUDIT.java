package com.theplatform.data.tv.entity.integration.test.endpoint.tvseason;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.TvSeason;
import com.theplatform.data.tv.entity.api.fields.TvSeasonField;
import com.theplatform.data.tv.entity.api.test.TvSeasonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * User: llowenthal Date: 28/06/2010 Basic CRUD tests for tv season
 * 
 * @since 4/8/2011
 */

@Test(groups = { "tvSeason", "crud" })
public class TvSeasonCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void crudSingleTvSeason() throws UnknownHostException {
		TvSeason tvSeason = this.tvSeasonFactory.create();

		// CREATE
		TvSeason persistedTvSeason = this.tvSeasonClient.create(tvSeason);
		assertEquals(persistedTvSeason.getId(), tvSeason.getId(), "TvSeason ids should match after creation");

		// RETRIEVE
		TvSeason retrievedTvSeason = this.tvSeasonClient.get(tvSeason.getId(), new String[] {});
		TvSeasonComparator.assertEquals(retrievedTvSeason, tvSeason);

		// UPDATE
		tvSeason.setDescription(tvSeason.getDescription() + " - changed");
		this.tvSeasonClient.update(tvSeason);

		TvSeason retrievedAfterUpdate = this.tvSeasonClient.get(tvSeason.getId(), new String[] {});
		TvSeasonComparator.assertEquals(retrievedAfterUpdate, tvSeason);

		// DELETE
		long deletedObjects = this.tvSeasonClient.delete(tvSeason.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.tvSeasonClient.get(tvSeason.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("TvSeason should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudTvSeasonFeed() throws UnknownHostException {
		List<TvSeason> tvSeasons = this.tvSeasonFactory.create(5);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] tvSeasonIds = (URI[]) CollectionUtils.collect(tvSeasons, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<TvSeason> persistedTvSeasons = this.tvSeasonClient.create(tvSeasons, new String[] {});
		TvSeasonComparator.assertEquals(persistedTvSeasons, tvSeasons);

		// RETRIEVE
		Feed<TvSeason> retrievedTvSeasons = this.tvSeasonClient.get(tvSeasonIds, new String[] {});
		TvSeasonComparator.assertEquals(retrievedTvSeasons, tvSeasons);

		// DELETE
		long deletedTvSeasons = this.tvSeasonClient.delete(tvSeasonIds);
		Assert.assertEquals(deletedTvSeasons, tvSeasons.size());

		long notFoundTvSeasons = 0;
		for (TvSeason tvSeason : tvSeasons) {
			try {
				this.tvSeasonClient.get(tvSeason.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundTvSeasons++;
			}
		}
		Assert.assertEquals(notFoundTvSeasons, deletedTvSeasons, "Still found tvSeasons after deleting");
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(TvSeasonField.tvSeasonNumber, null),
			new DataServiceField(TvSeasonField.startYear, null), new DataServiceField(TvSeasonField.endYear, null),
			new DataServiceField(DataObjectField.description, null), new DataServiceField(TvSeasonField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testTvSeasonCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(tvSeasonClient, tvSeasonFactory.create(), TvSeasonComparator.class, this.defaultValues,
				null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testTvSeasonCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(tvSeasonClient, tvSeasonFactory.create(), TvSeasonComparator.class, this.defaultValues,
				null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testTvSeasonUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(TvSeasonField.tvSeasonNumber, 1));
		createValues.add(new DataServiceField(TvSeasonField.startYear, 1999));
		createValues.add(new DataServiceField(TvSeasonField.endYear, 2000));
		createValues.add(new DataServiceField(DataObjectField.description, "tvseason descrption"));
		createValues.add(new DataServiceField(TvSeasonField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(tvSeasonClient, tvSeasonFactory.create(), TvSeasonComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testTvSeasonUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(TvSeasonField.tvSeasonNumber, 1));
		createValues.add(new DataServiceField(TvSeasonField.startYear, 1999));
		createValues.add(new DataServiceField(TvSeasonField.endYear, 2000));
		createValues.add(new DataServiceField(DataObjectField.description, "tvseason descrption"));
		createValues.add(new DataServiceField(TvSeasonField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(tvSeasonClient, tvSeasonFactory.create(), TvSeasonComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), null);

	}

}
