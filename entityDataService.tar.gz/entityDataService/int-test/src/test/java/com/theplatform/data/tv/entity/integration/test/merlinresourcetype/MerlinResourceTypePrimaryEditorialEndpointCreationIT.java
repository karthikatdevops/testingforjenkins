package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.SerializationUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.objects.MerlinDataObject;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.SportsLeague;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.data.objects.TvSeason;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.module.exception.ValidationException;

/**
 * tests of merlinResourceType fields of editorial endpoint related to CRUD
 * operation
 * 
 * @author jethrolai
 * 
 */

@Test(groups = { TestGroup.testBug })
public class MerlinResourceTypePrimaryEditorialEndpointCreationIT extends EntityTestBase {

	@Test(enabled = false, groups = { TestGroup.gbTest }, dataProvider = "endpointDataProvider")
	public void testMerlinResourceTypeEndpointCreationEditorialIdSuffix(MerlinDataObject endpoint, MerlinResourceType originalType, String baseUri,
			DataServiceClient<DataObject> client) throws Exception {
		createEndpointAndAssert(endpoint, 500, baseUri, client, originalType, MerlinResourceType.Editorial);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest }, dataProvider = "endpointDataProviderNonEditorial")
	public void testMerlinResourceTypeEndpointCreationNonEditorialIdSuffix(MerlinDataObject endpoint, MerlinResourceType originalType, String baseUri,
			DataServiceClient<DataObject> client) throws Exception {
		createEndpointAndAssert(endpoint, 600, baseUri, client, originalType, originalType);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest }, dataProvider = "endpointDataProviderEditorial", expectedExceptions = ValidationException.class)
	public void testMerlinResourceTypeEndpointCreationSettingTypeEditorialWithNonEditorialIdSuffix(MerlinDataObject endpoint, MerlinResourceType originalType,
			String baseUri, DataServiceClient<DataObject> client) throws Exception {
		createEndpointAndAssert(endpoint, 600, baseUri, client, originalType, null);
	}

	@DataProvider
	public Object[][] endpointDataProviderEditorial() {
		return generateEndpointDataSetByTypes(new MerlinResourceType[] { MerlinResourceType.Editorial });
	}

	@DataProvider
	public Object[][] endpointDataProviderNonEditorial() {
		return generateEndpointDataSetByTypes(new MerlinResourceType[] { MerlinResourceType.AudienceAvailable, MerlinResourceType.Temporary,
				MerlinResourceType.Inactive });
	}

	@DataProvider
	public Object[][] endpointDataProvider() {
		return generateEndpointDataSetByTypes(new MerlinResourceType[] { MerlinResourceType.AudienceAvailable, MerlinResourceType.Temporary,
				MerlinResourceType.Editorial, MerlinResourceType.Inactive });
	}

	private Object[][] generateEndpointDataSetByTypes(MerlinResourceType[] merinResourceTypes) {

		List<Object[]> arguementSetList = new ArrayList<>();
		// TODO uncomment this part when the implmentation is completed
		// arguementSetList.addAll(getSingleEndpointDataObject(this.creditFactory.createCredit(),
		// this.getBaseUrl() + "/data/Credit/", this.creditClient,
		// merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.personFactory.createPerson(),
		// this.getBaseUrl() + "/data/Person/", this.personClient,
		// merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.programFactory.createMovie(),
		// this.getBaseUrl() + "/data/Program/", this.programClient,
		// merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.tvSeasonFactory.createTvSeason(),
		// this.getBaseUrl() + "/data/TvSeason/", this.tvSeasonClient,
		// merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.entityCollectionFactory.createInstance(),
		// this.getBaseUrl() + "/data/EntityCollection/",
		// this.entityCollectionClient, merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.tagFactory.createTag(),
		// this.getBaseUrl() + "/data/Tag/", this.tagClient,
		// merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.sportsTeamFactory.createSportsTeam(),
		// this.getBaseUrl() + "/data/SportsTeam/",
		// this.sportsTeamClient, merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.sportsEventFactory.createSportsEvent(),
		// this.getBaseUrl() + "/data/SportsEvent/",
		// this.sportsEventClient, merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.sportsLeagueFactory.createSportsLeague(),
		// this.getBaseUrl() + "/data/SportsLeague/",
		// this.sportsLeagueClient, merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.awardFactory.createInstance(),
		// this.getBaseUrl() + "/data/Award/", this.awardClient,
		// merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.institutionFactory.createInstance(),
		// this.getBaseUrl() + "/data/Institution/",
		// this.institutionClient, merinResourceTypes));
		// arguementSetList.addAll(getSingleEndpointDataObject(this.mainImageTypeFactory.createMainImageType(),
		// this.getBaseUrl() + "/data/MainImageType/",
		// this.mainImageTypeClient, merinResourceTypes));

		Object[][] arguementSet = new Object[arguementSetList.size()][];
		int index = 0;
		for (Object[] objects : arguementSetList) {
			arguementSet[index] = objects;
			index++;
		}
		return arguementSet;
	}

	private List<Object[]> getSingleEndpointDataObject(MerlinDataObject dataObject, String baseUri, DataServiceClient client,
			MerlinResourceType[] merlinResourceTypes) {
		List<Object[]> dataSetList = new ArrayList<>();
		for (MerlinResourceType type : merlinResourceTypes)
			dataSetList.add(new Object[] { dataObject, type, baseUri, client });
		return dataSetList;
	}

	private void createEndpointAndAssert(MerlinDataObject endpoint, final long idSuffix, final String baseUri, DataServiceClient client,
			MerlinResourceType originalType, MerlinResourceType expectedType) throws Exception {
		MerlinDataObject endpointLocal = (MerlinDataObject) SerializationUtils.clone(endpoint);
		URI id = URI.create(baseUri + idSuffix);
		endpointLocal.setId(id);
		endpointLocal.setMerlinResourceType(originalType);
		MerlinDataObject retrievedEndpoint = (MerlinDataObject) client.create(endpoint, new String[] { "merlinResourceType" });

		Assert.assertEquals(expectedType, retrievedEndpoint.getMerlinResourceType());
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testMerlinResourceTypeCreditCreation() {

		Credit credit = this.creditFactory.create();

		URI creditId = URI.create(this.getBaseUrl() + "/data/Credit/" + 1500L);
		credit.setId(creditId);
		// TODO uncommented when this field is added
		// credit.setMerlinResourceType(null);
		Credit retrievedCredit = this.creditClient.create(credit, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedCredit.getMerlinResourceType());

		credit = this.creditFactory.create();

		creditId = URI.create(this.getBaseUrl() + "/data/Credit/" + 1000L);
		credit.setId(creditId);
		// TODO uncommented when this field is added
		// credit.setMerlinResourceType(null);
		retrievedCredit = this.creditClient.create(credit, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedCredit.getMerlinResourceType());
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testMerlinResourceTypePersonCreation() {

		Person person = this.personFactory.create();

		URI personId = URI.create(this.getBaseUrl() + "/data/Person/" + 1500L);
		person.setId(personId);
		// TODO uncommented when this field is added
		// person.setMerlinResourceType(null);
		Person retrievedPerson = this.personClient.create(person, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedPerson.getMerlinResourceType());

		person = this.personFactory.create();

		personId = URI.create(this.getBaseUrl() + "/data/Person/" + 1000L);
		person.setId(personId);
		// TODO uncommented when this field is added
		// person.setMerlinResourceType(null);
		retrievedPerson = this.personClient.create(person, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedPerson.getMerlinResourceType());
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testMerlinResourceTypeProgramCreation() {

		Program program = this.programFactory.create();

		URI programId = URI.create(this.getBaseUrl() + "/data/Program/" + 1500L);
		program.setId(programId);
		// TODO uncommented when this field is added
		// program.setMerlinResourceType(null);
		Program retrievedProgram = this.programClient.create(program, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedProgram.getMerlinResourceType());

		program = this.programFactory.create();

		programId = URI.create(this.getBaseUrl() + "/data/Program/" + 1000L);
		program.setId(programId);
		// TODO uncommented when this field is added
		// program.setMerlinResourceType(null);
		retrievedProgram = this.programClient.create(program, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedProgram.getMerlinResourceType());
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testMerlinResourceTypeTvSeasonCreation() throws UnknownHostException {

		TvSeason tvSeason = this.tvSeasonFactory.create();

		URI tvSeasonId = URI.create(this.getBaseUrl() + "/data/TvSeason/" + 1500L);
		tvSeason.setId(tvSeasonId);
		// TODO uncommented when this field is added
		// tvSeason.setMerlinResourceType(null);
		TvSeason retrievedTvSeason = this.tvSeasonClient.create(tvSeason, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedTvSeason.getMerlinResourceType());

		tvSeason = this.tvSeasonFactory.create();

		tvSeasonId = URI.create(this.getBaseUrl() + "/data/TvSeason/" + 1000L);
		tvSeason.setId(tvSeasonId);
		// TODO uncommented when this field is added
		// tvSeason.setMerlinResourceType(null);
		retrievedTvSeason = this.tvSeasonClient.create(tvSeason, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedTvSeason.getMerlinResourceType());
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testMerlinResourceTypeEntityCollectionCreation() {

		EntityCollection entityCollection = this.entityCollectionFactory.create();

		URI entityCollectionId = URI.create(this.getBaseUrl() + "/data/EntityCollection/" + 1500L);
		entityCollection.setId(entityCollectionId);
		// TODO uncommented when this field is added
		// entityCollection.setMerlinResourceType(null);
		EntityCollection retrievedEntityCollection = this.entityCollectionClient.create(entityCollection, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedEntityCollection.getMerlinResourceType());

		entityCollection = this.entityCollectionFactory.create();

		entityCollectionId = URI.create(this.getBaseUrl() + "/data/EntityCollection/" + 1000L);
		entityCollection.setId(entityCollectionId);
		// TODO uncommented when this field is added
		// entityCollection.setMerlinResourceType(null);
		retrievedEntityCollection = this.entityCollectionClient.create(entityCollection, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedEntityCollection.getMerlinResourceType());
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testMerlinResourceTypeTagCreation() {

		Tag tag = this.tagFactory.create();

		URI tagId = URI.create(this.getBaseUrl() + "/data/Tag/" + 1500L);
		tag.setId(tagId);
		// TODO uncommented when this field is added
		// tag.setMerlinResourceType(null);
		Tag retrievedTag = this.tagClient.create(tag, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedTag.getMerlinResourceType());

		tag = this.tagFactory.create();

		tagId = URI.create(this.getBaseUrl() + "/data/Tag/" + 1000L);
		tag.setId(tagId);
		// TODO uncommented when this field is added
		// tag.setMerlinResourceType(null);
		retrievedTag = this.tagClient.create(tag, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedTag.getMerlinResourceType());
	}

	@Test(groups = { "other" })
	public void testMerlinResourceTypeSportsTeamCreation() {

		SportsTeam sportsTeam = this.sportsTeamFactory.create();

		URI sportsTeamId = URI.create(this.getBaseUrl() + "/data/SportsTeam/" + 1500L);
		sportsTeam.setId(sportsTeamId);
		// TODO uncommented when this field is added
		// sportsTeam.setMerlinResourceType(null);
		SportsTeam retrievedSportsTeam = this.sportsTeamClient.create(sportsTeam, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedSportsTeam.getMerlinResourceType());

		sportsTeam = this.sportsTeamFactory.create();

		sportsTeamId = URI.create(this.getBaseUrl() + "/data/SportsTeam/" + 1000L);
		sportsTeam.setId(sportsTeamId);
		// TODO uncommented when this field is added
		// sportsTeam.setMerlinResourceType(null);
		retrievedSportsTeam = this.sportsTeamClient.create(sportsTeam, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedSportsTeam.getMerlinResourceType());
	}

	@Test(groups = { "other" })
	public void testMerlinResourceTypeSportsEventCreation() {

		SportsEvent sportsEvent = this.sportsEventFactory.create();

		URI sportsEventId = URI.create(this.getBaseUrl() + "/data/SportsEvent/" + 1500L);
		sportsEvent.setId(sportsEventId);
		// TODO uncommented when this field is added
		// sportsEvent.setMerlinResourceType(null);
		SportsEvent retrievedSportsEvent = this.sportsEventClient.create(sportsEvent, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedSportsEvent.getMerlinResourceType());

		sportsEvent = this.sportsEventFactory.create();

		sportsEventId = URI.create(this.getBaseUrl() + "/data/SportsEvent/" + 1000L);
		sportsEvent.setId(sportsEventId);
		// TODO uncommented when this field is added
		// sportsEvent.setMerlinResourceType(null);
		retrievedSportsEvent = this.sportsEventClient.create(sportsEvent, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedSportsEvent.getMerlinResourceType());
	}

	@Test(groups = { "other" })
	public void testMerlinResourceTypeSportsLeagueCreation() {

		SportsLeague sportsLeague = this.sportsLeagueFactory.create();

		URI sportsLeagueId = URI.create(this.getBaseUrl() + "/data/SportsLeague/" + 1500L);
		sportsLeague.setId(sportsLeagueId);
		// TODO uncommented when this field is added
		// sportsLeague.setMerlinResourceType(null);
		SportsLeague retrievedSportsLeague = this.sportsLeagueClient.create(sportsLeague, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedSportsLeague.getMerlinResourceType());

		sportsLeague = this.sportsLeagueFactory.create();

		sportsLeagueId = URI.create(this.getBaseUrl() + "/data/SportsLeague/" + 1000L);
		sportsLeague.setId(sportsLeagueId);
		// TODO uncommented when this field is added
		// sportsLeague.setMerlinResourceType(null);
		retrievedSportsLeague = this.sportsLeagueClient.create(sportsLeague, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedSportsLeague.getMerlinResourceType());
	}

	@Test(groups = { TestGroup.gbTest })
	public void testMerlinResourceTypeAwardCreation() {

		Award award = this.awardFactory.create();

		URI awardId = URI.create(this.getBaseUrl() + "/data/Award/" + 1500L);
		award.setId(awardId);
		// TODO uncommented when this field is added
		// award.setMerlinResourceType(null);
		Award retrievedAward = this.awardClient.create(award, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedAward.getMerlinResourceType());

		award = this.awardFactory.create();

		awardId = URI.create(this.getBaseUrl() + "/data/Award/" + 1000L);
		award.setId(awardId);
		// TODO uncommented when this field is added
		// award.setMerlinResourceType(null);
		retrievedAward = this.awardClient.create(award, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedAward.getMerlinResourceType());
	}

	@Test(groups = { TestGroup.gbTest })
	public void testMerlinResourceTypeInstitutionCreation() {

		Institution institution = this.institutionFactory.create();

		URI institutionId = URI.create(this.getBaseUrl() + "/data/Institution/" + 1500L);
		institution.setId(institutionId);
		// TODO uncommented when this field is added
		// institution.setMerlinResourceType(null);
		Institution retrievedInstitution = this.institutionClient.create(institution, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedInstitution.getMerlinResourceType());

		institution = this.institutionFactory.create();

		institutionId = URI.create(this.getBaseUrl() + "/data/Institution/" + 1000L);
		institution.setId(institutionId);
		// TODO uncommented when this field is added
		// insitution.setMerlinResourceType(null);
		retrievedInstitution = this.institutionClient.create(institution, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedInstitution.getMerlinResourceType());
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testMerlinResourceTypeMainImageTypeCreation() {

		MainImageType mainImageType = this.mainImageTypeFactory.create();

		URI mainImageTypeId = URI.create(this.getBaseUrl() + "/data/MainImageType/" + 1500L);
		mainImageType.setId(mainImageTypeId);
		// TODO uncommented when this field is added
		// mainImageType.setMerlinResourceType(null);
		MainImageType retrievedMainImageType = this.mainImageTypeClient.create(mainImageType, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.Editorial,
		// retrievedMainImageType.getMerlinResourceType());

		mainImageType = this.mainImageTypeFactory.create();

		mainImageTypeId = URI.create(this.getBaseUrl() + "/data/MainImageType/" + 1000L);
		mainImageType.setId(mainImageTypeId);
		// TODO uncommented when this field is added
		// mainImageType.setMerlinResourceType(null);
		retrievedMainImageType = this.mainImageTypeClient.create(mainImageType, new String[] { "merlinResourceType" });

		// TODO uncommented when this field is added
		// Assert.assertEquals(MerlinResourceType.AudienceAvailable,
		// retrievedMainImageType.getMerlinResourceType());
	}

}
