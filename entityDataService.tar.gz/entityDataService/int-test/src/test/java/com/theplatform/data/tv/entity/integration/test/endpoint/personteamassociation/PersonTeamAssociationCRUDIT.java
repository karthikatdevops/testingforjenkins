package com.theplatform.data.tv.entity.integration.test.endpoint.personteamassociation;

import com.theplatform.contrib.testing.comparator.DataObjectComparator;
import com.theplatform.contrib.testing.crud.CrudTestBase;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.contrib.testing.provider.GBTestIdProvider;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.DataService;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.NamespacedField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.PersonTeamAssociationClient;
import com.theplatform.data.tv.entity.api.data.objects.PersonTeamAssociation;
import com.theplatform.data.tv.entity.api.fields.PersonTeamAssociationField;
import com.theplatform.data.tv.entity.api.test.PersonTeamAssociationComparator;
import com.theplatform.data.tv.entity.test.api.data.factory.PersonTeamAssociationFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


@Test(groups = {"crud", "personteamassociation", TestGroup.gbTest}, enabled = true)
public class PersonTeamAssociationCRUDIT extends CrudTestBase<PersonTeamAssociation> {

    @Autowired
    @Qualifier("baseEntityUrl")
    private String baseEntityUrl;

    @Resource
    protected PersonTeamAssociationClient personTeamAssociationClient;

    @Resource
    protected PersonTeamAssociationFactory personTeamAssociationFactory;

    @Resource
    protected PersonTeamAssociationComparator personTeamAssociationComparator;

    @Resource
    protected GBTestIdProvider objectIdProvider;


    @Override
    protected DataServiceClient<PersonTeamAssociation> getClient() {
        return personTeamAssociationClient;
    }

    @Override
    protected DataObjectComparator<PersonTeamAssociation> getComparator() {
        return personTeamAssociationComparator;
    }

    @Override
    protected ValueProvider<Long> getValueProvider() {
        return objectIdProvider;
    }

    @Override
    protected DataObjectFactory<PersonTeamAssociation, ? extends DataService<PersonTeamAssociation>> getDataObjectFactory() {
        return personTeamAssociationFactory;
    }

    @Override
    protected Map<NamespacedField, Object> getUpdateValues(PersonTeamAssociation personTeamAssociation) {
        Map<NamespacedField, Object> updateValues = new HashMap<>();

        updateValues.put(PersonTeamAssociationField.nativeId, "new-nativeId");

        MerlinResourceType oMerlinResourceType = personTeamAssociation.getMerlinResourceType();
        if (oMerlinResourceType != null && oMerlinResourceType != MerlinResourceType.Temporary) {
            updateValues.put(PersonTeamAssociationField.merlinResourceType, MerlinResourceType.Temporary);
        } else {
            updateValues.put(PersonTeamAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable);
        }

        return updateValues;
    }

    @Override
    protected Set<NamespacedField> getRequiredFields() {
        Set<NamespacedField> required = new HashSet<>();

        required.add(PersonTeamAssociationField.personId);
        required.add(PersonTeamAssociationField.sportsTeamId);
        required.add(PersonTeamAssociationField.merlinResourceType);

        return required;
    }

    @Override
    protected Set<NamespacedField> getNullableFields() {
        Set<NamespacedField> nullable = new HashSet<>();
        return nullable;
    }

    @Override
    protected void populateDependencies(PersonTeamAssociation personTeamAssociation) {

    }
}
