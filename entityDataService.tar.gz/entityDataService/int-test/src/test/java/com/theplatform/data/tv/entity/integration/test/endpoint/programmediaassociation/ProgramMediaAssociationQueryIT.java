package com.theplatform.data.tv.entity.integration.test.endpoint.programmediaassociation;

import com.theplatform.contrib.data.api.client.query.ByMediaIdMediaGuid;
import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.data.api.client.query.ByMezzanineMediaIdAccountGuid;
import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.DateOnlyUtil;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.awardassociation.ByProgramId;
import com.theplatform.data.tv.entity.api.client.query.programmediaassociation.*;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.ProgramMediaAssociationField;
import com.theplatform.data.tv.entity.api.test.ProgramMediaAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.*;

/**
 * 
 * @author jethrolai
 * 
 */

@Test(groups = { "programMediaAssociation", "query", TestGroup.gbTest})
public class ProgramMediaAssociationQueryIT extends EntityTestBase {

	public void testProgramMediaAssociationQueryByProgramIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.persistingProgramMediaAssociationFactory.create(3);
		
        Query[] queries = new Query[] { new ByProgramId(URIUtils.getIdValue(this.programClient.create(this.programFactory.create()).getId())) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByProgramIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		List<ProgramMediaAssociation> pmas = this.persistingProgramMediaAssociationFactory.create(4);
		URI expectedProgramId = pmas.get(3).getProgramId();

        Query[] queries = new Query[] { new ByProgramId(URIUtils.getIdValue(expectedProgramId)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), pmas.get(3));
	}

    public void testProgramMediaAssociationQueryByProgramIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

    	this.persistingProgramMediaAssociationFactory.create(3);
    	final URI programId = this.programClient.create(this.programFactory.create()).getId();
    	List<ProgramMediaAssociation> pmas = this.persistingProgramMediaAssociationFactory.create(
    			2, ProgramMediaAssociationField.programId, programId);
    	
		Query[] queries = new Query[] { new ByProgramId(URIUtils.getIdValue(programId)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
			resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
		}

		for (ProgramMediaAssociation expected : pmas)
			ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

    public void mediaGuidIsCorrectlyTranslatedFromMediaId(){
        MediaId mediaId = this.persistingProgramMediaAssociationFactory.create().getMediaId();

        Query[] queries = new Query[]{new ByMediaIdMediaGuid(mediaId.getMediaGuid())};
        Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries().size(), 1, String.format("Expected mediaGuid: %s", mediaId.getMediaGuid()));
        Assert.assertEquals(results.getEntries().get(0).getMediaGuid(), mediaId.getMediaGuid(), "Expected mediaGuid to be identical to mediaId.mediaGuid");
    }

	public void testProgramMediaAssociationQueryByMediaIdMediaGuidNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.persistingProgramMediaAssociationFactory.create();
		Query[] queries = new Query[] { new ByMediaIdMediaGuid(createMediaId().getMediaGuid()) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByMediaIdMediaGuidOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(2).get(1);
		MediaId mediaId = expectedProgramMediaAssociation.getMediaId();

		Query[] queries = new Query[] { new ByMediaIdMediaGuid(mediaId.getMediaGuid()) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByMediaGuidMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		Long id = this.objectIdProvider.nextId();
		MediaId mediaId = new MediaId("accountGuid_" + id, "guid_" + id, "serviceGuid_" + id);
        MediaId mediaId2 = new MediaId("accountGuid_" + id, "guid_" + id, "serviceGuid_" + this.objectIdProvider.nextId());

        List<ProgramMediaAssociation> expectedProgramMediaAssociations = new ArrayList<>();
        expectedProgramMediaAssociations.add(this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.mediaId, mediaId));
        expectedProgramMediaAssociations.add(this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.mediaId, mediaId2));

		Query[] queries = new Query[] { new ByMediaIdMediaGuid(mediaId.getMediaGuid()) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
			resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
		}
		for (ProgramMediaAssociation expected : expectedProgramMediaAssociations)
			ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

    public void testProgramMediaAssociationQueryByMezzanineMediaIdAccountGuidNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
            InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        this.persistingProgramMediaAssociationFactory.create();
        Query[] queries = new Query[] { new ByMezzanineMediaIdAccountGuid(createMediaId().getAccountGuid()) };
        Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
    }

    public void testProgramMediaAssociationQueryByMezzanineMediaIdAccountGuidOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
            InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        Long id = this.objectIdProvider.nextId();
        MediaId mediaId = new MediaId("accountGuid_" + id, "guid_" + id, "serviceGuid_" + id);
        MediaId mediaId2 = new MediaId("accountGuid_" + this.objectIdProvider.nextId(), "guid_" + id, "serviceGuid_" + this.objectIdProvider.nextId());

        ProgramMediaAssociation expectedProgramMediaAssociation = persistingProgramMediaAssociationFactory.create(
                ProgramMediaAssociationField.mediaId, mediaId,
                ProgramMediaAssociationField.mezzanineMediaId, mediaId);

        //create a second that shouldn't be returned
        this.persistingProgramMediaAssociationFactory.create(
                ProgramMediaAssociationField.mediaId, mediaId2,
                ProgramMediaAssociationField.mezzanineMediaId, mediaId2);

        Query[] queries = new Query[] { new ByMezzanineMediaIdAccountGuid(mediaId.getAccountGuid()) };
        Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

        ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
    }

    public void testProgramMediaAssociationQueryByMezzanineMediaIdAccountGuidMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
            InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        Long id = this.objectIdProvider.nextId();
        MediaId mediaId = new MediaId("accountGuid_" + id, "guid_" + id, "serviceGuid_" + id);
        MediaId mediaId2 = new MediaId("accountGuid_" + id, "guid_" + id, "serviceGuid_" + this.objectIdProvider.nextId());

        List<ProgramMediaAssociation> expectedProgramMediaAssociations = new ArrayList<>();
        expectedProgramMediaAssociations.add(this.persistingProgramMediaAssociationFactory.create(
                ProgramMediaAssociationField.mediaId, mediaId,
                ProgramMediaAssociationField.mezzanineMediaId, mediaId));
        expectedProgramMediaAssociations.add(this.persistingProgramMediaAssociationFactory.create(
                ProgramMediaAssociationField.mediaId, mediaId2,
                ProgramMediaAssociationField.mezzanineMediaId, mediaId2));

        Query[] queries = new Query[] { new ByMezzanineMediaIdAccountGuid(mediaId.getAccountGuid()) };
        Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

        Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
        for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
            resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
        }
        for (ProgramMediaAssociation expected : expectedProgramMediaAssociations)
            ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
    }

	public void testProgramMediaAssociationQueryByDistributionIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI distributionId1 = URI.create(this.getBaseUrl().concat("/data/Program/123"));
		final URI distributionId2 = URI.create(this.getBaseUrl().concat("/data/Program/124"));
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.distributionId, distributionId1);
		
		Query[] queries = new Query[] { new ByDistributionId(URIUtils.getIdValue(distributionId2)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByDistributionIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		
		final URI distributionId1 = URI.create(this.getBaseUrl().concat("/data/Program/123"));
		final URI distributionId2 = URI.create(this.getBaseUrl().concat("/data/Program/124"));
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.distributionId, distributionId1);
		ProgramMediaAssociation pma = this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.distributionId, distributionId2);

		Query[] queries = new Query[] { new ByDistributionId(URIUtils.getIdValue(distributionId2)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), pma);
	}

	public void testProgramMediaAssociationQueryByDistributionIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI distributionId1 = URI.create(this.getBaseUrl().concat("/data/Program/123"));
		final URI distributionId2 = URI.create(this.getBaseUrl().concat("/data/Program/124"));
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.distributionId, distributionId1);
		List<ProgramMediaAssociation> expectedProgramMediaAssociations = this.persistingProgramMediaAssociationFactory.create(
				2, ProgramMediaAssociationField.distributionId, distributionId2);

		Query[] queries = new Query[] { new ByDistributionId(URIUtils.getIdValue(distributionId2)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
			resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
		}

		for (ProgramMediaAssociation expected : expectedProgramMediaAssociations)
			ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramMediaAssociationQueryByProviderIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String providerId1 = "providerId1";
		final String providerId2 = "providerId2";
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.providerId, providerId1);

		Query[] queries = new Query[] { new ByProviderId(providerId2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByProviderIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String providerId1 = "providerId1";
		final String providerId2 = "providerId2";
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.providerId, providerId1);
		ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.providerId, providerId2);

		Query[] queries = new Query[] { new ByProviderId(providerId2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByProviderIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String providerId1 = "providerId1";
		final String providerId2 = "providerId2";
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.providerId, providerId1);
		List<ProgramMediaAssociation> expectedProgramMediaAssociations = this.persistingProgramMediaAssociationFactory.create(
				2, ProgramMediaAssociationField.providerId, providerId2);

        Query[] queries = new Query[] { new ByProviderId(providerId2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
			resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
		}

		for (ProgramMediaAssociation expected : expectedProgramMediaAssociations)
			ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramMediaAssociationQueryByTitleAssetIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String titleAssetId1 = "titleAssetId1";
		final String titleAssetId2 = "titleAssetId2";
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.titleAssetId, titleAssetId1);

		Query[] queries = new Query[] { new ByTitleAssetId(titleAssetId2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByTitleAssetIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		
		final String titleAssetId1 = "TitleAssetId1";
		final String titleAssetId2 = "TitleAssetId2";
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.titleAssetId, titleAssetId1);
		ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.titleAssetId, titleAssetId2);

		Query[] queries = new Query[] { new ByTitleAssetId(titleAssetId2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByTitleAssetIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String titleAssetId1 = "TitleAssetId1";
		final String titleAssetId2 = "TitleAssetId2";
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.titleAssetId, titleAssetId1);
		List<ProgramMediaAssociation> expectedProgramMediaAssociations = this.persistingProgramMediaAssociationFactory.create(
				2, ProgramMediaAssociationField.titleAssetId, titleAssetId2);

        Query[] queries = new Query[] { new ByTitleAssetId(titleAssetId2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
			resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
		}

		for (ProgramMediaAssociation expected : expectedProgramMediaAssociations)
			ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramMediaAssociationQueryByTitlePaidNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String titlePaid1 = "titlePaid1";
		final String titlePaid2 = "titlePaid2";
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.titlePaid, titlePaid1);

		Query[] queries = new Query[] { new ByTitlePaid(titlePaid2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByTitlePaidOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String titlePaid1 = "TitlePaid1";
		final String titlePaid2 = "TitlePaid2";
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.titlePaid, titlePaid1);

        ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.titlePaid, titlePaid2);
        
		Query[] queries = new Query[] { new ByTitlePaid(titlePaid2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByTitlePaidMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String titlePaid1 = "TitlePaid1";
		final String titlePaid2 = "TitlePaid2";
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.titlePaid, titlePaid1);
		List<ProgramMediaAssociation> expectedProgramMediaAssociations = this.persistingProgramMediaAssociationFactory.create(
				2, ProgramMediaAssociationField.titlePaid, titlePaid2);

        Query[] queries = new Query[] { new ByTitlePaid(titlePaid2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
			resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
		}

		for (ProgramMediaAssociation expected : expectedProgramMediaAssociations)
			ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramMediaAssociationQueryByContentAssetIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String contentAssetId1 = "contentAssetId1";
		final String contentAssetId2 = "contentAssetId2";
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.contentAssetId, contentAssetId1);

		Query[] queries = new Query[] { new ByContentAssetId(contentAssetId2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByContentAssetIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String contentAssetId1 = "ContentAssetId1";
		final String contentAssetId2 = "ContentAssetId2";
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.contentAssetId, contentAssetId1);

        ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.contentAssetId, contentAssetId2);

		Query[] queries = new Query[] { new ByContentAssetId(contentAssetId2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByContentAssetIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String contentAssetId1 = "ContentAssetId1";
		final String contentAssetId2 = "ContentAssetId2";
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.contentAssetId, contentAssetId1);
        List<ProgramMediaAssociation> expectedProgramMediaAssociations = this.persistingProgramMediaAssociationFactory.create(
        		2, ProgramMediaAssociationField.contentAssetId, contentAssetId2);

		Query[] queries = new Query[] { new ByContentAssetId(contentAssetId2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
			resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
		}

		for (ProgramMediaAssociation expected : expectedProgramMediaAssociations)
			ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramMediaAssociationQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final MerlinResourceType merlinResourceType1 = MerlinResourceType.AudienceAvailable;
		final MerlinResourceType merlinResourceType2 = MerlinResourceType.Temporary;
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.merlinResourceType, merlinResourceType1);

        Query[] queries = new Query[] { new ByMerlinResourceType(merlinResourceType2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final MerlinResourceType merlinResourceType1 = MerlinResourceType.AudienceAvailable;
		final MerlinResourceType merlinResourceType2 = MerlinResourceType.Temporary;
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.merlinResourceType, merlinResourceType1);

		ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.merlinResourceType, merlinResourceType2);

		Query[] queries = new Query[] { new ByMerlinResourceType(merlinResourceType2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final MerlinResourceType merlinResourceType1 = MerlinResourceType.AudienceAvailable;
		final MerlinResourceType merlinResourceType2 = MerlinResourceType.Temporary;
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.merlinResourceType, merlinResourceType1);
		List<ProgramMediaAssociation> expectedProgramMediaAssociations = this.persistingProgramMediaAssociationFactory.create(
				2, ProgramMediaAssociationField.merlinResourceType, merlinResourceType2);

		Query[] queries = new Query[] { new ByMerlinResourceType(merlinResourceType2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
			resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
		}

		for (ProgramMediaAssociation expected : expectedProgramMediaAssociations)
			ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramMediaAssociationQueryByProgramTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final ProgramType programType1 = ProgramType.Advertisement;
		final ProgramType programType2 = ProgramType.Concert;
		Program program1 = this.programClient.create(programFactory.create(new DataServiceField(ProgramField.type,programType1)), new String[] {});
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.programId, program1.getId());

		Query[] queries = new Query[] { new ByProgramType(programType2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByProgramTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final ProgramType programType1 = ProgramType.Advertisement;
		final ProgramType programType2 = ProgramType.Concert;
		Program program1 = this.programClient.create(programFactory.create(new DataServiceField(ProgramField.type,programType1)), new String[] {});
		Program program2 = this.programClient.create(programFactory.create(new DataServiceField(ProgramField.type,programType2)), new String[] {});
		
		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.programId, program1.getId());
        ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.programId, program2.getId());

		Query[] queries = new Query[] { new ByProgramType(programType2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByProgramTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final ProgramType programType1 = ProgramType.Advertisement;
		final ProgramType programType2 = ProgramType.Concert;
		Program program1 = this.programClient.create(programFactory.create(new DataServiceField(ProgramField.type,programType1)), new String[] {});
		Program program2 = this.programClient.create(programFactory.create(new DataServiceField(ProgramField.type,programType2)), new String[] {});

		this.persistingProgramMediaAssociationFactory.create(3, ProgramMediaAssociationField.programId, program1.getId());
        List<ProgramMediaAssociation> expectedProgramMediaAssociations = this.persistingProgramMediaAssociationFactory.create(
        		2, ProgramMediaAssociationField.programId, program2.getId());
        
		Query[] queries = new Query[] { new ByProgramType(programType2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociation should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation programMediaAssociation : results.getEntries()) {
			resultMap.put(programMediaAssociation.getId(), programMediaAssociation);
		}

		for (ProgramMediaAssociation expected : expectedProgramMediaAssociations)
			ProgramMediaAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testProgramMediaAssociationQueryByProviderNoMatch() {

		final String provider = "provider";
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.provider, provider);

		Query[] queries = new Query[] { new ByProvider(provider.concat(" update")) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByProviderListNoMatch() {
		final String provider = "provider";
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.provider, provider);
		
		Query[] queries = new Query[] { new ByProvider(Arrays.asList(provider.concat(" updated1"), provider.concat(" updated2"))) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByProviderOneMatch() {

		final String provider1 = "provider1";
		final String provider2 = "provider2";
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.provider, provider1);
        ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.provider, provider2);
        
		Query[] queries = new Query[] { new ByProvider(provider2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByProviderListOneMatch() {

		final String provider1 = "provider1";
		final String provider2 = "provider2";
		final String provider3 = "provider3";
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.provider, provider1);
		ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.provider, provider2);
        
		Query[] queries = new Query[] { new ByProvider(Arrays.asList(provider2, provider3)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByProviderMultipleMatch() {

		final String provider1 = "programMediaAssociation provider1";
		final String provider2 = "programMediaAssociation provider2";
		List<ProgramMediaAssociation> pmas = this.persistingProgramMediaAssociationFactory.create(
				2, ProgramMediaAssociationField.provider, provider1);
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.provider, provider2);

        Query[] queries = new Query[] { new ByProvider(provider1) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(pmas.get(0).getId()), pmas.get(0));
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(pmas.get(1).getId()), pmas.get(1));
	}

	public void testProgramMediaAssociationQueryByProviderListMultipleMatch() {

		final String provider1 = "programMediaAssociation provider1";
		final String provider2 = "programMediaAssociation provider2";
		final String provider3 = "programMediaAssociation provider3";
        ProgramMediaAssociation programMediaAssociation1 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.provider, provider1);
        ProgramMediaAssociation programMediaAssociation2 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.provider, provider2);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.provider, provider3);

        Query[] queries = new Query[] { new ByProvider(Arrays.asList(provider1, provider2)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}

	public void testProgramMediaAssociationQueryByCompanyIdNoMatch() {

		final URI companyId1 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		final URI companyId2 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		Assert.assertNotEquals(companyId1, companyId2);	
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.companyId, companyId1);

		Query[] queries = new Query[] { new ByCompanyId(URIUtils.getIdValue(companyId2)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByCompanyIdListNoMatch() {
		final URI companyId1 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		final URI companyId2 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		final URI companyId3 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		Assert.assertNotEquals(companyId1, companyId2);
		Assert.assertNotEquals(companyId1, companyId3);
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.companyId, companyId1);
		
		Query[] queries = new Query[] { new ByCompanyId(Arrays.asList(URIUtils.getIdValue(companyId2), URIUtils.getIdValue(companyId3))) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByCompanyIdOneMatch() {

		final URI companyId1 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		final URI companyId2 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		Assert.assertNotEquals(companyId1, companyId2);
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.companyId, companyId1);
        ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.companyId, companyId2);
        
		Query[] queries = new Query[] { new ByCompanyId(URIUtils.getIdValue(companyId2)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByCompanyIdListOneMatch() {

		final URI companyId1 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		final URI companyId2 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		final URI companyId3 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		Assert.assertNotEquals(companyId1, companyId2);
		Assert.assertNotEquals(companyId1, companyId3);
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.companyId, companyId1);
		ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.companyId, companyId2);

		Query[] queries = new Query[] { new ByCompanyId(Arrays.asList(URIUtils.getIdValue(companyId2), URIUtils.getIdValue(companyId3))) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByCompanyIdMultipleMatch() {

		final URI companyId1 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		final URI companyId2 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		Assert.assertNotEquals(companyId1, companyId2);
        ProgramMediaAssociation programMediaAssociation1 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.companyId, companyId1);
        ProgramMediaAssociation programMediaAssociation2 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.companyId, companyId1);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.companyId, companyId2);

        Query[] queries = new Query[] { new ByCompanyId(URIUtils.getIdValue(companyId1)) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}

	public void testProgramMediaAssociationQueryByCompanyIdListMultipleMatch() {

		final URI companyId1 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		final URI companyId2 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		final URI companyId3 = URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt()));
		Assert.assertNotEquals(companyId1, companyId2);

        ProgramMediaAssociation programMediaAssociation1 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.companyId, companyId1);
        ProgramMediaAssociation programMediaAssociation2 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.companyId, companyId2);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.companyId, companyId3);

        Query[] queries = new Query[] { new ByCompanyId(Arrays.asList(URIUtils.getIdValue(companyId1), URIUtils.getIdValue(companyId2))) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}

	public void testProgramMediaAssociationQueryByAvailableDateNoMatch() {

		final Date availableDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date availableDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.availableDate, availableDate1);

		Query[] queries = new Query[] { new ByAvailableDate(availableDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByAvailableDateRangeNoMatch() {
		final Date availableDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date availableDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date availableDate3 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		Assert.assertTrue(availableDate2.after(availableDate3));
		Assert.assertTrue(availableDate1.after(availableDate2));

		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.availableDate, availableDate1);
		
		Query[] queries = new Query[] { new ByAvailableDate(availableDate3, availableDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByAvailableDateOneMatch() {

		final Date availableDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date availableDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.availableDate, availableDate1);
        ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.availableDate, availableDate2);
        
		Query[] queries = new Query[] { new ByAvailableDate(availableDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByAvailableDateRangeOneMatch() {

		final Date availableDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date availableDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date availableDate3 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		final Date availableDate4 = DateOnlyUtil.getDateOnly("12/04/2009").toDate();
		Assert.assertTrue(availableDate3.after(availableDate4));
		Assert.assertTrue(availableDate2.after(availableDate3));
		Assert.assertTrue(availableDate1.after(availableDate2));
		
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.availableDate, availableDate1);
        ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.availableDate, availableDate3);
        
		Query[] queries = new Query[] { new ByAvailableDate(availableDate4, availableDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByAvailableDateMultipleMatch() {

		final Date availableDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date availableDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		List <ProgramMediaAssociation> pmas = this.persistingProgramMediaAssociationFactory.create(
        		2, ProgramMediaAssociationField.availableDate, availableDate1);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.availableDate, availableDate2);

		Query[] queries = new Query[] { new ByAvailableDate(availableDate1) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(pmas.get(0).getId()), pmas.get(0));
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(pmas.get(1).getId()), pmas.get(1));
	}

	public void testProgramMediaAssociationQueryByAvailableDateRangeMultipleMatch() {

		final Date availableDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date availableDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date availableDate3 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		final Date availableDate4 = DateOnlyUtil.getDateOnly("12/04/2009").toDate();
		final Date availableDate5 = DateOnlyUtil.getDateOnly("12/04/2008").toDate();
		Assert.assertTrue(availableDate4.after(availableDate5));
		Assert.assertTrue(availableDate3.after(availableDate4));
		Assert.assertTrue(availableDate2.after(availableDate3));
		Assert.assertTrue(availableDate1.after(availableDate2));

        ProgramMediaAssociation programMediaAssociation1 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.availableDate, availableDate3);
        ProgramMediaAssociation programMediaAssociation2 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.availableDate, availableDate4);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.availableDate, availableDate1);

        Query[] queries = new Query[] { new ByAvailableDate(availableDate5, availableDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}
	
	public void testProgramMediaAssociationQueryByAvailableDateBefore(){
		
		final Date availableDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date availableDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date availableDate3 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		final Date availableDate4 = DateOnlyUtil.getDateOnly("12/04/2009").toDate();
		Assert.assertTrue(availableDate2.after(availableDate3));
        Assert.assertTrue(availableDate1.after(availableDate2));

        ProgramMediaAssociation programMediaAssociation1 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.availableDate, availableDate3);
        ProgramMediaAssociation programMediaAssociation2 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.availableDate, availableDate4);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.availableDate, availableDate1);

        Query[] queries = new Query[] { new ByAvailableDate(null, availableDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}
	
	public void testProgramMediaAssociationQueryByAvailableDateAfter(){
		final Date availableDate1 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		final Date availableDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date availableDate3 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		Assert.assertTrue(availableDate3.after(availableDate2));
		Assert.assertTrue(availableDate2.after(availableDate1));

        ProgramMediaAssociation programMediaAssociation1 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.availableDate, availableDate3);
        ProgramMediaAssociation programMediaAssociation2 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.availableDate, availableDate2);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.availableDate, availableDate1);

        Query[] queries = new Query[] { new ByAvailableDate(availableDate2, null) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");
		
		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);
		
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}

	public void testProgramMediaAssociationQueryByExpirationDateNoMatch() {

		final Date expirationDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date expirationDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.expirationDate, expirationDate1);

		Query[] queries = new Query[] { new ByExpirationDate(expirationDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByExpirationDateRangeNoMatch() {
		final Date expirationDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date expirationDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date expirationDate3 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		Assert.assertTrue(expirationDate2.after(expirationDate3));
		Assert.assertTrue(expirationDate1.after(expirationDate2));
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.expirationDate, expirationDate1);

		Query[] queries = new Query[] { new ByExpirationDate(expirationDate3, expirationDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ProgramMediaAssociation should be found");
	}

	public void testProgramMediaAssociationQueryByExpirationDateOneMatch() {

		final Date expirationDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date expirationDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.expirationDate, expirationDate1);
        ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.expirationDate, expirationDate2);

		Query[] queries = new Query[] { new ByExpirationDate(expirationDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByExpirationDateRangeOneMatch() {

		final Date expirationDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date expirationDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date expirationDate3 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		final Date expirationDate4 = DateOnlyUtil.getDateOnly("12/04/2009").toDate();
		Assert.assertTrue(expirationDate3.after(expirationDate4));
		Assert.assertTrue(expirationDate2.after(expirationDate3));
		Assert.assertTrue(expirationDate1.after(expirationDate2));
		
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.expirationDate, expirationDate1);
        ProgramMediaAssociation expectedProgramMediaAssociation = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.expirationDate, expirationDate3);

		Query[] queries = new Query[] { new ByExpirationDate(expirationDate4, expirationDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ProgramMediaAssociation should be found");

		ProgramMediaAssociationComparator.assertEquals(results.getEntries().get(0), expectedProgramMediaAssociation);
	}

	public void testProgramMediaAssociationQueryByExpirationDateMultipleMatch() {

		final Date expirationDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date expirationDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		List<ProgramMediaAssociation> pmas = this.persistingProgramMediaAssociationFactory.create(
        		2, ProgramMediaAssociationField.expirationDate, expirationDate1);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.expirationDate, expirationDate2);

        Query[] queries = new Query[] { new ByExpirationDate(expirationDate1) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(pmas.get(0).getId()), pmas.get(0));
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(pmas.get(1).getId()), pmas.get(1));
	}
	public void testProgramMediaAssociationQueryByExpirationDateRangeMultipleMatch() {

		final Date expirationDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date expirationDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date expirationDate3 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		final Date expirationDate4 = DateOnlyUtil.getDateOnly("12/04/2009").toDate();
		final Date expirationDate5 = DateOnlyUtil.getDateOnly("12/04/2008").toDate();
		Assert.assertTrue(expirationDate4.after(expirationDate5));
		Assert.assertTrue(expirationDate3.after(expirationDate4));
		Assert.assertTrue(expirationDate2.after(expirationDate3));
		Assert.assertTrue(expirationDate1.after(expirationDate2));

        ProgramMediaAssociation programMediaAssociation1 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.expirationDate, expirationDate3);
        ProgramMediaAssociation programMediaAssociation2 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.expirationDate, expirationDate4);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.expirationDate, expirationDate1);

        Query[] queries = new Query[] { new ByExpirationDate(expirationDate5, expirationDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}
	
	public void testProgramMediaAssociationQueryByExpirationDateBefore(){
		final Date expirationDate1 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		final Date expirationDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date expirationDate3 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		final Date expirationDate4 = DateOnlyUtil.getDateOnly("12/04/2009").toDate();
		Assert.assertTrue(expirationDate3.after(expirationDate4));
		Assert.assertTrue(expirationDate2.after(expirationDate3));
		Assert.assertTrue(expirationDate1.after(expirationDate2));

        ProgramMediaAssociation programMediaAssociation1 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.expirationDate, expirationDate4);
        ProgramMediaAssociation programMediaAssociation2 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.expirationDate, expirationDate3);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.expirationDate, expirationDate1);

        Query[] queries = new Query[] { new ByExpirationDate(null, expirationDate2) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");

		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);

		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}
	
	@Test(groups = TestGroup.notImplemented)
	public void testProgramMediaAssociationQueryByExpirationDateAfter(){
		final Date expirationDate1 = DateOnlyUtil.getDateOnly("12/04/2010").toDate();
		final Date expirationDate2 = DateOnlyUtil.getDateOnly("12/04/2011").toDate();
		final Date expirationDate3 = DateOnlyUtil.getDateOnly("12/04/2012").toDate();
		Assert.assertTrue(expirationDate3.after(expirationDate2));
		Assert.assertTrue(expirationDate2.after(expirationDate1));
		
		ProgramMediaAssociation programMediaAssociation1 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.expirationDate, expirationDate3);
        ProgramMediaAssociation programMediaAssociation2 = this.persistingProgramMediaAssociationFactory.create(
        		ProgramMediaAssociationField.expirationDate, expirationDate2);
        this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.expirationDate, expirationDate1);
		
		Query[] queries = new Query[] { new ByExpirationDate(expirationDate2, null) };
		Feed<ProgramMediaAssociation> results = this.programMediaAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ProgramMediaAssociations should be found");
		
		Map<URI, ProgramMediaAssociation> resultMap = new HashMap<>();
		for (ProgramMediaAssociation ProgramMediaAssociation : results.getEntries())
			resultMap.put(ProgramMediaAssociation.getId(), ProgramMediaAssociation);
		
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramMediaAssociationComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}
}
