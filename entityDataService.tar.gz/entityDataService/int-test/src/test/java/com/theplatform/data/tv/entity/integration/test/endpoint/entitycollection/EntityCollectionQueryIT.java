package com.theplatform.data.tv.entity.integration.test.endpoint.entitycollection;

import static org.testng.Assert.assertEquals;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.api.client.query.ByTitlePrefix;
import com.theplatform.data.tv.entity.api.fields.EntityCollectionField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.entitycollection.ByEntityId;
import com.theplatform.data.tv.entity.api.client.query.entitycollection.BySubtype;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.test.EntityCollectionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * GreenBuild test of query of EntityCollection
 * 
 * @author jethrolai
 * @since 9/1/2011
 * 
 */
@Test(groups = { "entityCollection", "query" })
public class EntityCollectionQueryIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionByTitleOneFound() {
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		inputEntityCollections.get(1).setTitle("Title1");
		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new ByTitle(inputEntityCollections.get(1).getTitle()) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 1, "No record found using query byTitle");
		inputEntityCollections.get(1).setMerlinResourceType(retrievedEntityCollections.getEntries().get(0).getMerlinResourceType());
		EntityCollectionComparator.assertEquals(retrievedEntityCollections.getEntries().get(0), inputEntityCollections.get(1));
	}

	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionByTitleNoneFound() {
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		inputEntityCollections.get(1).setTitle("Title1");
		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new ByTitle("titles randome") };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 0, "No record should be found using query byTitle");
	}

	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionByTitleMultipleFound() {

		final String TITLE = "title1";
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		inputEntityCollections.get(1).setTitle(TITLE);
		inputEntityCollections.get(0).setTitle(TITLE);
		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new ByTitle(TITLE) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 2, "2 records should be found using query byTitle");
		inputEntityCollections.get(1).setMerlinResourceType(retrievedEntityCollections.getEntries().get(0).getMerlinResourceType());
		EntityCollectionComparator.assertEquals(retrievedEntityCollections.getEntries().get(0), inputEntityCollections.get(1));

	}

	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionByTitlePrefixOneFound() {
		final String TITLE = "title1zxcvzxc";
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		inputEntityCollections.get(1).setTitle(TITLE + new Random().nextInt());
		inputEntityCollections.get(0).setTitle("sdfs" + TITLE + new Random().nextInt());
		inputEntityCollections.get(2).setTitle("asdf" + TITLE + new Random().nextInt());
		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new ByTitlePrefix(inputEntityCollections.get(1).getTitle().substring(0, 2)) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 1, "No record found using query byTitlePrefix");
		inputEntityCollections.get(1).setMerlinResourceType(retrievedEntityCollections.getEntries().get(0).getMerlinResourceType());
		EntityCollectionComparator.assertEquals(retrievedEntityCollections.getEntries().get(0), inputEntityCollections.get(1));
	}

	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionByTitlePrefixNoneFound() {
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new ByTitlePrefix("randome title") };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 0, "No record should be found using query byTitlePrefix");

	}

	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionByTitlePrefixMultipleFound() {
		final String TITLE = "title1zxcvzxc";
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		inputEntityCollections.get(0).setTitle("prefix" + TITLE + new Random().nextInt());
		inputEntityCollections.get(1).setTitle(TITLE + new Random().nextInt());
		inputEntityCollections.get(2).setTitle(TITLE + new Random().nextInt());
		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new ByTitlePrefix(TITLE) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 2, "2 records should be found using query byTitlePrefix");

	}

	@Test(groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionBySubtypeOneFound() {
		final String SUBTYPE = "Content";
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		inputEntityCollections.get(0).setSubtype("Language");
		inputEntityCollections.get(2).setSubtype("Language");
		inputEntityCollections.get(1).setSubtype(SUBTYPE);
		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new BySubtype(SUBTYPE) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 1, "No record found using query bySubtype");
		inputEntityCollections.get(1).setMerlinResourceType(retrievedEntityCollections.getEntries().get(0).getMerlinResourceType());
		EntityCollectionComparator.assertEquals(retrievedEntityCollections.getEntries().get(0), inputEntityCollections.get(1));
	}

	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionBySubtypeNoneFound() {
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		for (EntityCollection entityCollection : inputEntityCollections) {
			entityCollection.setSubtype("Language");
		}

		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new BySubtype("Content") };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 0, "No record should be found using query bySubtype");

	}

	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionBySubtypeMultipleFound() {
		final String SUBTYPE = "Content";
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		inputEntityCollections.get(0).setSubtype("Language");
		inputEntityCollections.get(1).setSubtype(SUBTYPE);
		inputEntityCollections.get(2).setSubtype(SUBTYPE);

		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new BySubtype(SUBTYPE) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 2, "2 records should be found using query bySubtype");

	}

	@Test(groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionByEntityIdOneFound() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programFactory.create().getId());

		EntityCollection entityCollection = entityCollectionFactory.create(new DataServiceField(EntityCollectionField.entityIds, entityIds));
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);
		inputEntityCollections.add(entityCollection);

		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new ByEntityId(removeEntityIdNonNumbericPrefix(entityCollection.getEntityIds().get(0))) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 1, "No or more than one records found using query byEntityId");
		inputEntityCollections.get(3).setMerlinResourceType(retrievedEntityCollections.getEntries().get(0).getMerlinResourceType());
		EntityCollectionComparator.assertEquals(retrievedEntityCollections.getEntries().get(0), inputEntityCollections.get(3));
	}

	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionByEntityIdNoneFound() {
		final URI entityId = this.personClient.create(this.personFactory.create(), (String[]) null).getId();
		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3);

		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new ByEntityId(removeEntityIdNonNumbericPrefix(entityId)) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 0, "No record should be found using query byEntityId");

	}

	@Test(groups = { TestGroup.gbTest })
	public void testQueryEntityCollectionByEntityIdMultipleFound() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programFactory.create().getId());

		List<EntityCollection> inputEntityCollections = entityCollectionFactory.create(3, new DataServiceField(EntityCollectionField.entityIds, entityIds));
		List<EntityCollection> extraEntityCollections = entityCollectionFactory.create(2);

		inputEntityCollections.addAll(extraEntityCollections);
		this.entityCollectionClient.create(inputEntityCollections);
		Query queries[] = new Query[] { new ByEntityId(removeEntityIdNonNumbericPrefix(inputEntityCollections.get(0).getEntityIds().get(0))) };
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedEntityCollections.getEntries().size(), 3, "3 records should be found using query byEntityId");

	}

	private long removeEntityIdNonNumbericPrefix(URI id) {

		return Long.parseLong(id.toString().substring(id.toString().lastIndexOf("/") + 1));
	}

}
