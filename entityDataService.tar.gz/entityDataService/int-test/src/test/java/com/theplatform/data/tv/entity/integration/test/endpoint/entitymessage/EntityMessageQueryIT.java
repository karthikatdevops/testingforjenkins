package com.theplatform.data.tv.entity.integration.test.endpoint.entitymessage;

import com.google.common.collect.Lists;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.entitymessage.ByEntityId;
import com.theplatform.data.tv.entity.api.client.query.entitymessage.ByType;
import com.theplatform.data.tv.entity.api.data.objects.EntityMessage;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.fields.EntityMessageField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.annotations.Test;

import java.net.URI;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/23/15
 */
@Test(groups = {"entitymessage", "query", TestGroup.gbTest})
public class EntityMessageQueryIT extends EntityTestBase {

    public void byTitleQueryShouldReurnEntityMessageByTitleWhenItExists() {
        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(DataObjectField.title, "title1"));
        entityMessageClient.create(v1);
        EntityMessage v2 = entityMessageFactory.create(new DataServiceField(DataObjectField.title, "title2"));
        entityMessageClient.create(v2);

        Query[] queries = new Query[]{new ByTitle("title1")};

        Feed<EntityMessage> results = entityMessageClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getTitle(), equalTo("title1"));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }

    public void byTitleQueryShouldHandleOrs() {
        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(DataObjectField.title, "title1"));
        entityMessageClient.create(v1);
        EntityMessage v2 = entityMessageFactory.create(new DataServiceField(DataObjectField.title, "title2"));
        entityMessageClient.create(v2);

        Query[] queries = new Query[]{new ByTitle(Lists.newArrayList("title1", "title2"))};

        Feed<EntityMessage> results = entityMessageClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(2));
        assertThat(results.getEntries().get(0).getTitle(), anyOf(equalTo("title1"), equalTo("title2")));
        assertThat(results.getEntries().get(1).getTitle(), anyOf(equalTo("title1"), equalTo("title2")));
    }

    public void byTitleQueryShouldReurnNoResultsWhenItsNotFound() {
        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(DataObjectField.title, "title1"));
        entityMessageClient.create(v1);
        EntityMessage v2 = entityMessageFactory.create(new DataServiceField(DataObjectField.title, "title2"));
        entityMessageClient.create(v2);

        Query[] queries = new Query[]{new ByTitle("otherTitle")};

        Feed<EntityMessage> results = entityMessageClient.getAll(null, queries, null, null, null);

        assertThat(results.getEntries().size(), equalTo(0));
    }

    public void byTypeQueryShouldReurnEntityMessageByTypeWhenItExists() {
        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(EntityMessageField.type, "type1"));
        entityMessageClient.create(v1);

        Query[] queries = new Query[]{new ByType("type1")};

        Feed<EntityMessage> results = entityMessageClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getType(), equalTo("type1"));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }

    public void byTypeQueryShouldSupportOr() {
        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(EntityMessageField.type, "type1"));
        entityMessageClient.create(v1);
        EntityMessage v2 = entityMessageFactory.create(new DataServiceField(EntityMessageField.type, "type2"));
        entityMessageClient.create(v2);

        Query[] queries = new Query[]{new ByType(Lists.newArrayList("type1", "type2"))};

        Feed<EntityMessage> results = entityMessageClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(2));
        assertThat(results.getEntries().get(0).getType(), anyOf(equalTo("type1"), equalTo("type2")));
        assertThat(results.getEntries().get(1).getType(), anyOf(equalTo("type1"), equalTo("type2")));
    }

    public void byTypeQueryShouldReurnNoResultsWhenItsNotFound() {
        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(EntityMessageField.type, "type1"));
        entityMessageClient.create(v1);

        Query[] queries = new Query[]{new ByType("type2")};

        Feed<EntityMessage> results = entityMessageClient.getAll(null, queries, null, null, null);

        assertThat(results.getEntries().size(), equalTo(0));
    }

    public void byEntityIdQueryShouldReurnEntityMessageByTypeWhenItExists() {
        Program rawProgram = programFactory.create();
        Program program = programClient.create(rawProgram);
        URI programId = program.getId();

        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(EntityMessageField.entityId, programId));
        entityMessageClient.create(v1);

        Query[] queries = new Query[]{new ByEntityId(programId)};

        Feed<EntityMessage> results = entityMessageClient.getAll(null, queries, null, null, null);

        assertThat(results.getEntries().size(), equalTo(1));
        assertThat(results.getEntries().get(0).getEntityId(), equalTo(programId));
        assertThat(results.getEntries().get(0).getId(), equalTo(v1.getId()));
    }

    public void byEntityIdQueryShouldSupportOr() {
        Program rawProgram1 = programFactory.create();
        Program program1 = programClient.create(rawProgram1);
        URI programId1 = program1.getId();

        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(EntityMessageField.entityId, programId1));
        entityMessageClient.create(v1);

        Program rawProgram2 = programFactory.create();
        Program program2 = programClient.create(rawProgram2);
        URI programId2 = program2.getId();

        EntityMessage v2 = entityMessageFactory.create(new DataServiceField(EntityMessageField.entityId, programId2));
        entityMessageClient.create(v2);

        Query[] queries = new Query[]{new ByEntityId(Lists.newArrayList(programId1, programId2))};

        Feed<EntityMessage> results = entityMessageClient.getAll(null, queries, null, null, null);

        // make sure we got a good result
        assertThat(results.getEntries().size(), equalTo(2));
        assertThat(results.getEntries().get(0).getEntityId(), anyOf(equalTo(programId1), equalTo(programId2)));
        assertThat(results.getEntries().get(1).getEntityId(), anyOf(equalTo(programId1), equalTo(programId2)));
    }

    public void byEntityIdQueryShouldReurnNoResultsWhenItsNotFound() {
        Program rawProgram1 = programFactory.create();
        Program program1 = programClient.create(rawProgram1);
        URI programId1 = program1.getId();

        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(EntityMessageField.entityId, programId1));
        entityMessageClient.create(v1);

        Program rawProgram2 = programFactory.create();
        Program program2 = programClient.create(rawProgram2);
        URI programId2 = program2.getId();

        Query[] queries = new Query[]{new ByEntityId(programId2)};

        Feed<EntityMessage> results = entityMessageClient.getAll(null, queries, null, null, null);

        assertThat(results.getEntries().size(), equalTo(0));
    }
}
