package com.theplatform.data.tv.entity.integration.test.endpoint.tvseason;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.TvSeason;
import com.theplatform.data.tv.entity.api.test.TvSeasonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;

/**
 * User: gservente
 * 
 * Basic Sort tests for TvSeason
 * 
 * @since 4/8/2011
 */
@Test(groups = { "other" })
public class TvSeasonSortIT extends EntityTestBase {

	private static final int TVSEASONS_TO_CREATE = 4;
	private List<TvSeason> tvSeasons;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		this.tvSeasons = this.tvSeasonFactory.create(TVSEASONS_TO_CREATE);
		this.tvSeasonClient.create(tvSeasons);

	}

	/*
	 * This test-case passes when run against an empty db, which makes me think
	 * this is data-cleanup related and not a service bug. I'm commenting this
	 * out until someone on the testing side can enable it. ~aloder 07/28
	 */
	@Test(groups = TestGroup.testBug)
	public void testSortAscendingTvSeasonByOwnerId() throws UnknownHostException {
		// UPDATE VALUES
		this.tvSeasons.get(3).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/123"));
		this.tvSeasons.get(0).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/222"));
		this.tvSeasons.get(2).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/1311"));
		this.tvSeasons.get(1).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/1531"));

		this.tvSeasonClient.update(this.tvSeasons);

		// SORT EXPECTED
		List<TvSeason> expectedSortedImageAssociations = new ArrayList<>(tvSeasons.size());
		expectedSortedImageAssociations.add(this.tvSeasons.get(3));
		expectedSortedImageAssociations.add(this.tvSeasons.get(0));
		expectedSortedImageAssociations.add(this.tvSeasons.get(2));
		expectedSortedImageAssociations.add(this.tvSeasons.get(1));

		// RETRIVE WHITH SORTING
		String sortFiedld = "ownerId";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<TvSeason> retrievedImageAssociations = this.tvSeasonClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { requestSort }, null, false);

		TvSeasonComparator.assertEquals(retrievedImageAssociations, expectedSortedImageAssociations);
	}

	/*
	 * This test-case passes when run against an empty db, which makes me think
	 * this is data-cleanup related and not a service bug. I'm commenting this
	 * out until someone on the testing side can enable it. ~aloder 07/28
	 */
	@Test(groups = TestGroup.testBug)
	public void testSortAscendingTvSeasonByTitle() throws UnknownHostException {

		// UPDATE VALUES
		this.tvSeasons.get(1).setTvSeasonNumber(5);
		this.tvSeasons.get(3).setTvSeasonNumber(54);
		this.tvSeasons.get(0).setTvSeasonNumber(512);
		this.tvSeasons.get(2).setTvSeasonNumber(852);
		this.tvSeasonClient.update(this.tvSeasons);

		// SORT EXPECTED
		List<TvSeason> expectedSortedTvSeasons = new ArrayList<>(this.tvSeasons.size());
		expectedSortedTvSeasons.add(this.tvSeasons.get(1));
		expectedSortedTvSeasons.add(this.tvSeasons.get(3));
		expectedSortedTvSeasons.add(this.tvSeasons.get(0));
		expectedSortedTvSeasons.add(this.tvSeasons.get(2));

		// RETRIVE WHITH SORTING
		String sortFiedld = "tvSeasonNumber";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<TvSeason> retrievedTvSeasons = this.tvSeasonClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { requestSort }, null, false);

		TvSeasonComparator.assertEquals(retrievedTvSeasons, expectedSortedTvSeasons);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableField() throws UnknownHostException {
		// RETRIVE WHITH SORTING
		String sortField = "description";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortField, sortDescending);
		this.tvSeasonClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
	}
}
