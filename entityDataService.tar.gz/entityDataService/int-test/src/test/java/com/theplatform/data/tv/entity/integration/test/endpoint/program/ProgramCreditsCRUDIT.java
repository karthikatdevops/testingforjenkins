package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.OverrideField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.test.CreditAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * @since 4/7/2011
 */
@Test(groups = { "program", "crud", TestGroup.testBug })
public class ProgramCreditsCRUDIT extends EntityTestBase {



	/**
	 * 1 ) Create program 2 ) Get program; validate that doesn't have any
	 * credits 3 ) Create credit linking to program 4 ) Update program year 5 )
	 * Get program; validate that it has the new credit 6 ) Update credit 7 )
	 * Update program year 8 ) Get program; validate that it has updated credit
	 * 9 ) Delete credit 10) Update program year 11) Get program; validate that
	 * doesn't have any credits
	 * 
	 * @throws UnknownHostException
	 *             Exception
	 */
	public void crudSingleCredit() throws UnknownHostException {
		// Create Program
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// RETRIEVE
		Program retrievedProgramOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		Assert.assertEquals(retrievedProgramOnce.getCredits().size(), 0, "Program has no Credit");
		// Create Credit
		Credit inputCredit = this.creditFactory.create();
		inputCredit.setEntityId(inputProgram.getId());
		this.creditClient.create(inputCredit);
		// RETRIEVE
		Credit retrievedCredit = this.creditClient.get(inputCredit.getId(), new String[] {});
		inputProgram.setYear(1998);
		inputProgram.setCredits(null);
		this.programClient.update(inputProgram);
		Program retrievedProgramAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		Assert.assertEquals(retrievedProgramAgain.getCredits().size(), 1, "Created Program has one Credit");
		CreditAssociationComparator.assertEquals(retrievedProgramAgain.getCredits().get(0),
				getInputCreditAssociation(inputCredit, retrievedCredit, inputProgram));

		// UPDATE credit & program both and retrieve program
		inputCredit.setType("Director");
		inputCredit.setProgram(null);
		inputCredit.setPerson(null);
		this.creditClient.update(inputCredit);
		inputProgram.setYear(1999);
		this.programClient.update(inputProgram);
		Program retrieveAfterUpdateOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdateOnce.getCredits().size(), 1, "Updated Program has one Credit");
		CreditAssociationComparator.assertEquals(retrieveAfterUpdateOnce.getCredits().get(0),
				getInputCreditAssociation(inputCredit, retrievedCredit, inputProgram));

		// DELETE credit, update program & retrieve program
		this.creditClient.delete(inputCredit.getId());
		inputProgram.setYear(2000);
		this.programClient.update(inputProgram);
		Program retrieveAfterUpdateAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdateAgain.getCredits().size(), 0, "Updated Program has no Credit");

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		assertEquals(deletedObjects, 1);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		fail("Program should not be found after deleting it");
	}

	/**
	 * 1 ) Create program 2 ) Get program; validate that doesn't have any
	 * credits 3 ) Create credit linking to program 4 ) Get program; validate
	 * that it has the new credit 5 ) Update credit 6 ) Get program; validate
	 * that it has updated credit 7 ) Delete credit 8 ) Get program; validate
	 * that doesn't have any credits
	 * 
	 * @throws UnknownHostException
	 *             Exception
	 */
	public void crudSingleCachingCredit() throws UnknownHostException {
		// Create Program
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// RETRIEVE
		Program retrievedProgram1 = this.programClient.get(inputProgram.getId(), new String[] {});
		Assert.assertEquals(retrievedProgram1.getCredits().size(), 0, "Program has no Credit");
		// Create Credit
		Credit inputCredit = this.creditFactory.create();
		inputCredit.setEntityId(inputProgram.getId());
		this.creditClient.create(inputCredit);
		// RETRIEVE
		Credit retrievedCredit = this.creditClient.get(inputCredit.getId(), new String[] {});
		Program retrievedProgram2 = this.programClient.get(inputProgram.getId(), new String[] {});
		Assert.assertEquals(retrievedProgram2.getCredits().size(), 1, "Created Program should have one Credit");
		CreditAssociationComparator.assertEquals(retrievedProgram2.getCredits().get(0), getInputCreditAssociation(inputCredit, retrievedCredit, inputProgram));

		// UPDATE only credit
		inputCredit.setType("Director");
		this.creditClient.update(inputCredit);
		Program retrieveProgram3 = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveProgram3.getCredits().size(), 1, "Program has one Credit");
		CreditAssociationComparator.assertEquals(retrieveProgram3.getCredits().get(0), getInputCreditAssociation(inputCredit, retrievedCredit, inputProgram));

		// DELETE credit
		this.creditClient.delete(inputCredit.getId());
		Program retrieveProgram4 = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveProgram4.getCredits().size(), 0, "Updated Program has no Credit");

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		assertEquals(deletedObjects, 1);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		fail("Program should not be found after deleting it");
	}
	public void crudSingleCacheInvalidationCredit() throws UnknownHostException {
		// Create Program
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// RETRIEVE
		Program retrievedProgramOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgramOnce.getCredits().size(), 0, "Program has no Credit");
		assertEquals(retrievedProgramOnce.getVersion(), new Long("0"), "Before creating credit link to Program then version should be zero");

		// Create Credit
		Credit inputCredit = this.creditFactory.create();
		inputCredit.setEntityId(inputProgram.getId());
		this.creditClient.create(inputCredit);
		// RETRIEVE
		Program retrievedProgramAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgramAgain.getCredits().size(), 1, "Created Program has one Credit");
		assertEquals(retrievedProgramAgain.getCredits().get(0).getCreditId(), inputCredit.getId());
		assertEquals(retrievedProgramAgain.getVersion(), new Long("1"), "After created credits link to Program then version should be one");
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramOnce.getUpdated().before(retrievedProgramAgain.getUpdated())
		// );

		// UPDATE only credit
		inputCredit.setType("Director");
		this.creditClient.update(inputCredit);
		Program retrieveAfterUpdateOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdateOnce.getCredits().size(), 1, "Updated Program has one Credit");
		assertEquals(retrieveAfterUpdateOnce.getCredits().get(0).getCreditId(), inputCredit.getId());
		assertEquals(retrieveAfterUpdateOnce.getVersion(), new Long("2"), "After updating credits which link to Program then version should be two");
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramOnce.getUpdated().before(retrieveAfterUpdateOnce.getUpdated())
		// );
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramAgain.getUpdated().before(retrieveAfterUpdateOnce.getUpdated())
		// );

		// DELETE association & retrieve program
		this.creditClient.delete(inputCredit.getId());
		Program retrieveAfterUpdateAgain = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdateAgain.getCredits().size(), 0, "Updated Program has no Credit");
		assertEquals(retrieveAfterUpdateOnce.getVersion(), new Long("3"), "After deleting credits which link to Program then version should be three");
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramOnce.getUpdated().before(retrieveAfterUpdateAgain.getUpdated())
		// );
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrievedProgramAgain.getUpdated().before(retrieveAfterUpdateAgain.getUpdated())
		// );
		// assertTrue("Program updated time-stamp are not updated after notification",
		// retrieveAfterUpdateOnce.getUpdated().before(retrieveAfterUpdateAgain.getUpdated())
		// );

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		assertEquals(deletedObjects, 1);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
			fail("Program should not be found after deleting it");
		} catch (ObjectNotFoundException e) {
			// ok
		}
	}
	public void crudCollectionOfCredits() throws UnknownHostException {
		// Create
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// Retrieve
		Program retrievedProgramOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgramOnce.getCredits().size(), 0, "Program has no Credit");

		List<Credit> inputCredits = this.creditFactory.create(5);
		for (Credit credit : inputCredits) {
			credit.setEntityId(inputProgram.getId());
		}
		this.creditClient.create(inputCredits);
		// Update Program
		inputProgram.setYear(1998);
		this.programClient.update(inputProgram);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] creditIds = (URI[]) CollectionUtils.collect(inputCredits, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
		// RETRIEVE
		Feed<Credit> retrievedCredits = this.creditClient.get(creditIds, new String[] {});
		Program retrievedProgram = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgram.getCredits().size(), 5, "Program has five Credits");
		for (int i = 0; i < inputCredits.size(); i++) {
			CreditAssociationComparator.assertEquals(retrievedProgram.getCredits().get(i),
					getInputCreditAssociation(inputCredits.get(i), retrievedCredits.getEntries().get(i), inputProgram));
		}

		// UPDATE
		for (Credit credit : inputCredits) {
			credit.setType("Director");
		}
		this.creditClient.update(inputCredits);
		inputProgram.setYear(1999);
		this.programClient.update(inputProgram);
		Program retrieveAfterUpdate = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdate.getCredits().size(), 5, "Program has five Credits");
		for (int i = 0; i < inputCredits.size(); i++) {
			CreditAssociationComparator.assertEquals(retrieveAfterUpdate.getCredits().get(i),
					getInputCreditAssociation(inputCredits.get(i), retrievedCredits.getEntries().get(i), inputProgram));
		}

		// DELETE
		this.creditClient.delete(creditIds);
		inputProgram.setYear(2000);
		this.programClient.update(inputProgram);
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		assertEquals(deletedObjects, 1);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		fail("Program should not be found after deleting it");
	}

	public void crudCollectionOfCreditsCaching() throws UnknownHostException {
		// Create
		Program inputProgram = this.programFactory.create();
		this.programClient.create(inputProgram);
		// Retrieve
		Program retrievedProgramOnce = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgramOnce.getCredits().size(), 0, "Program has no Credit");

		List<Credit> inputCredits = this.creditFactory.create(5);
		for (Credit credit : inputCredits) {
			credit.setEntityId(inputProgram.getId());
		}
		this.creditClient.create(inputCredits);
		// Update Program
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] creditIds = (URI[]) CollectionUtils.collect(inputCredits, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
		// RETRIEVE
		Feed<Credit> retrievedCredits = this.creditClient.get(creditIds, new String[] {});
		Program retrievedProgram = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrievedProgram.getCredits().size(), 5, "Program has five Credits");
		for (int i = 0; i < inputCredits.size(); i++) {
			CreditAssociationComparator.assertEquals(retrievedProgram.getCredits().get(i),
					getInputCreditAssociation(inputCredits.get(i), retrievedCredits.getEntries().get(i), inputProgram));
		}

		// UPDATE credits
		for (Credit credit : inputCredits) {
			credit.setType("Director");
		}
		this.creditClient.update(inputCredits);
		Program retrieveAfterUpdate = this.programClient.get(inputProgram.getId(), new String[] {});
		assertEquals(retrieveAfterUpdate.getCredits().size(), 5, "Program has five Credits");
		for (int i = 0; i < inputCredits.size(); i++) {
			CreditAssociationComparator.assertEquals(retrieveAfterUpdate.getCredits().get(i),
					getInputCreditAssociation(inputCredits.get(i), retrievedCredits.getEntries().get(i), inputProgram));
		}

		// DELETE
		this.creditClient.delete(creditIds);
		long deletedObjects = this.programClient.delete(inputProgram.getId());
		assertEquals(deletedObjects, 1);
		try {
			this.programClient.get(inputProgram.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		fail("Program should not be found after deleting it");
	}
	public void crudCollectionOfCacheInvalidationCredits() throws UnknownHostException {
		// Create Program
		List<Program> inputPrograms = this.programFactory.create(3);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
		this.programClient.create(inputPrograms);
		// RETRIEVE
		Feed<Program> retrievedProgramOnce = this.programClient.get(programIds, new String[] {});
		for (Program program : retrievedProgramOnce.getEntries()) {
			assertEquals(program.getCredits().size(), 0, "Program has no Credit");
			assertEquals(program.getVersion(), new Long("0"), "Before creating credit link to Program, version should be zero");
		}

		// Create Association
		List<Credit> inputCredits = this.creditFactory.create(3);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] creditIds = (URI[]) CollectionUtils.collect(inputCredits, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		inputCredits.get(0).setEntityId(inputPrograms.get(0).getId());
		inputCredits.get(1).setEntityId(inputPrograms.get(1).getId());
		inputCredits.get(2).setEntityId(inputPrograms.get(1).getId());
		this.creditClient.create(inputCredits);
		// RETRIEVE
		Feed<Program> retrievedProgramAgain = this.programClient.get(programIds, new String[] {});
		for (Program program : retrievedProgramAgain.getEntries()) {
			if (inputPrograms.get(0).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("1"), "After create Program version should be one");
				assertEquals(program.getCredits().size(), 1, "This program has one credit");
				assertEquals(program.getCredits().get(0).getCreditId(), inputCredits.get(0).getId(), "is program has right credit ?");
			} else if (inputPrograms.get(1).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("1"), "After create Program version should be one");
				assertEquals(program.getCredits().size(), 2, "This program has two credits");
				assertEquals(program.getCredits().get(0).getCreditId(), inputCredits.get(2).getId(), "is program has right credit ?");
				assertEquals(program.getCredits().get(1).getCreditId(), inputCredits.get(1).getId(), "is program has right credit ?");
			} else {
				assertEquals(program.getVersion(), new Long("0"), "After create Program version should be one");
				assertEquals(program.getCredits().size(), 0, "This program has no credit");
			}
		}

		// UPDATE credits and retrieve program
		for (Credit credit : inputCredits) {
			credit.setType("Director");
		}
		this.creditClient.update(inputCredits);
		Feed<Program> retrieveAfterUpdateOnce = this.programClient.get(programIds, new String[] {});
		for (Program program : retrieveAfterUpdateOnce.getEntries()) {
			if (inputPrograms.get(0).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("2"), "After create Program version should be one");
				assertEquals(program.getCredits().size(), 1, "This program has one credit");
				assertEquals(program.getCredits().get(0).getCreditId(), inputCredits.get(0).getId(), "is program has right credit ?");
			} else if (inputPrograms.get(1).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("2"), "After create Program version should be one");
				assertEquals(program.getCredits().size(), 2, "This program has two credits");
				assertEquals(program.getCredits().get(0).getCreditId(), inputCredits.get(2).getId(), "is program has right credit ?");
				assertEquals(program.getCredits().get(1).getCreditId(), inputCredits.get(1).getId(), "is program has right credit ?");
			} else {
				assertEquals(program.getVersion(), new Long("0"), "After create Program version should be one");
				assertEquals(program.getCredits().size(), 0, "This program has no credit");
			}
		}

		// DELETE association, update program & retrieve program
		this.creditClient.delete(creditIds);
		Feed<Program> retrieveAfterUpdateAgain = this.programClient.get(programIds, new String[] {});
		for (Program program : retrieveAfterUpdateAgain.getEntries()) {
			if (inputPrograms.get(0).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("3"), "After create Program version should be one");
				assertEquals(program.getCredits().size(), 0, "This program has one credit");
			} else if (inputPrograms.get(1).getId().equals(program.getId())) {
				assertEquals(program.getVersion(), new Long("3"), "After create Program version should be one");
				assertEquals(program.getCredits().size(), 0, "This program has two credits");
			} else {
				assertEquals(program.getVersion(), new Long("0"), "After create Program version should be one");
				assertEquals(program.getCredits().size(), 0, "This program has no credit");
			}
		}

		// DELETE Program (It's part of cleaning up database at the end of each
		// test case)
		long deletedObjects = this.programClient.delete(programIds);
		assertEquals(deletedObjects, 3);
		for (Program program : inputPrograms) {
			try {
				this.programClient.get(program.getId(), new String[] {});
				fail("Program should not be found after deleting it");
			} catch (ObjectNotFoundException e) {
				// ok
			}
		}
	}
	public void testProgramCreditsOnlyContainActiveCredits() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		// Create

		URI programId = this.programClient.create(this.programFactory.create()).getId();

		// Need to use null fields array or the credits are not returned (see
		// bug MERLIN-6723), can't use empty String array.
		// However, if we use null here, for the second request to Program
		// (Program retrievedProgramAfterAddingCredits =
		// this.programClient.get(programId, null);)
		// will be returned from cache, which means the returned program will
		// not have any credit.
		// // Retrieve
		// Program retrievedProgramBeforeAddingCredits =
		// this.programClient.get(inputProgram.getId(), new String[]{});
		// assertEquals(retrievedProgramBeforeAddingCredits.getCredits().size(),
		// 0, "Program should have no Credit");

		List<Credit> credits = new ArrayList<Credit>();

		final int numberOfActiveCredits = 5;

		credits.addAll(this.creditFactory.create(numberOfActiveCredits, new OverrideField("entityId", programId), new OverrideField("active", true)));
		credits.addAll(this.creditFactory.create(5, new OverrideField("entityId", programId), new OverrideField("active", false)));
		Collections.shuffle(credits);
		this.creditClient.create(credits);
		Map<URI, Credit> creditMap = new HashMap<URI, Credit>();
		for (Credit credit : credits) {
			creditMap.put(credit.getId(), credit);
		}
		// Need to use null fields array or the credits are not returned (see
		// bug MERLIN-6723)
		Program retrievedProgramAfterAddingCredits = this.programClient.get(programId, null);
		Assert.assertEquals(retrievedProgramAfterAddingCredits.getCredits().size(), numberOfActiveCredits, "The program should have " + numberOfActiveCredits
				+ " active Credit but there are " + retrievedProgramAfterAddingCredits.getCredits().size());

		for (CreditAssociation credit : retrievedProgramAfterAddingCredits.getCredits()) {
			CreditAssociationComparator.assertEquals(
					credit,
					getInputCreditAssociation(creditMap.get(credit.getCreditId()), creditClient.get(credit.getCreditId(), null),
							retrievedProgramAfterAddingCredits));
		}
	}

	private CreditAssociation getInputCreditAssociation(Credit inputCredit, Credit retrievedCredit, Program inputProgram) {
		CreditAssociation creditAssociation = new CreditAssociation();
		creditAssociation.setType(inputCredit.getType());
		creditAssociation.setPartName(inputCredit.getPartName());
		creditAssociation.setRank(inputCredit.getRank());
		creditAssociation.setCameo(inputCredit.getCameo());
		creditAssociation.setPersonId(inputCredit.getPersonId());
		creditAssociation.setProgramId(inputCredit.getEntityId());
		creditAssociation.setPersonName(retrievedCredit.getPerson().getName());
		creditAssociation.setProgramTitle(inputProgram.getTitle());
		creditAssociation.setCreditId(inputCredit.getId());
		creditAssociation.setProgramYear(inputProgram.getYear());
		return creditAssociation;
	}
}
