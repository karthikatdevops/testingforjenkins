package com.theplatform.data.tv.entity.integration.test.endpoint.person;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.objects.FieldInfo;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;
import com.theplatform.media.api.data.objects.MediaFile;

/**
 * Created by IntelliJ IDEA. User: Vinay Date: Jan 20, 2011 Time: 1:32:54 PM To
 * change this template use File | Settings | File Templates.
 * 
 * 
 * @since 4/7/2011
 */
@Test(groups = { "person", TestGroup.testBug })
public class MainImagePersonCascadingUpdateIT extends EntityTestBase {


	/*
	 * Due to a change in the mainImage logic, we now only expose a mainImage
	 * (MainImageFile) if its mainImageTypeId matches an approved set
	 * (configured in the service). For Persons, the current approved
	 * MainImageTypeIds are 220 and 221, so we need to ensure the MainImageFile
	 * gets created with one of those mainImageTypeId.
	 */

	// FIXME can't really use hardcoded id in systest/shared environment with
	// authProxy
	private static final Long VALID_PERSON_MAIN_IMAGE_TYPE_ID_1 = 220L;
	private static final Long VALID_PERSON_MAIN_IMAGE_TYPE_ID_2 = 221L;
	private static final long THREAD_SLEEP_INTERVAL = 20000L;


	/**
	 * 1. Create Person 2. Verify Person.version = 0 3. Verify Person has no
	 * Main Image 4. Create MainImageFile 1 linking to Person 5. Verify
	 * Person.version = 1 6. Verify Person has 1 main Image 7. Create
	 * MainImageFile 2 linking to Person 8. Verify Person.version = 2 9. Verify
	 * Person has 2 main Images 7. Delete MainImageFile 1 8. Verify
	 * Person.version = 3 9. Verify Person has 1 main Images 10. Update Main
	 * Image 2 11. Verify Person has version =4
	 * 
	 * @throws UnknownHostException
	 *             Exception
	 * @throws InterruptedException
	 *             Exception
	 * @throws NoSuchFieldException 
	 * @throws NoSuchMethodException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 * @throws SecurityException 
	 * @throws IllegalArgumentException 
	 */

	// TODO need to update because of removing person.mainImages
	public void cascadingUpdateValidationTest() throws UnknownHostException, InterruptedException, IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		Person inputPerson = this.personFactory.create();
		// CREATE person
		this.personClient.create(inputPerson);
		// Retrieve person
		Person initialPersonRetrieval = this.personClient.get(inputPerson.getId(), new String[] {});
		// verify the person has no mainImages
		// Assert.assertEquals(initialPersonRetrieval.getMainImages().size(), 0,
		// "The entity has zero main Image Files");
		// check the version number to make sure it is 0
		Assert.assertEquals(initialPersonRetrieval.getVersion(), new Long("0"), "Before creating MainImageFile link to Person, version should be zero");
		// set the main image link 1 to entity
		MainImageFile inputMainImageFileOne = this.mainImageFileFactory.create(new DataServiceField("mainImageTypeId", URI.create(this.getBaseUrl()
				+ "/data/MainImageType/" + VALID_PERSON_MAIN_IMAGE_TYPE_ID_1)));
		inputMainImageFileOne.setEntityId(inputPerson.getId());
		// CREATE MainImageFile
		this.mainImageFileClient.create(inputMainImageFileOne);

		Thread.sleep(THREAD_SLEEP_INTERVAL);

		Person retrievedPersonAfterCreate = this.personClient.get(inputMainImageFileOne.getEntityId(), new String[] {});
		// check the version number to make sure it is incremented
		assertEquals(retrievedPersonAfterCreate.getVersion(), new Long("1"), "After create Person version should be one");
		// verify the person has 1 mainImages
		// assertEquals(retrievedPersonAfterCreate.getMainImages().size(), 1,
		// "The entity should have 1 main Image Files");

		// TODO verify this main image file is the same with the one created
		// earlier

		// set the main image link 2 to entity
		MainImageFile inputMainImageFileTwo = this.mainImageFileFactory.create(new DataServiceField("mainImageTypeId", URI.create(this.getBaseUrl()
				+ "/data/MainImageType/" + VALID_PERSON_MAIN_IMAGE_TYPE_ID_2)));
		inputMainImageFileTwo.setEntityId(inputPerson.getId());
		// CREATE MainImageFile
		this.mainImageFileClient.create(inputMainImageFileTwo);

		Thread.sleep(THREAD_SLEEP_INTERVAL);

		Person retrievedPersonAfterSecondCreate = this.personClient.get(inputMainImageFileTwo.getEntityId(), new String[] {});
		// check the version number to make sure it is incremented
		assertEquals(retrievedPersonAfterSecondCreate.getVersion(), new Long("2"), "After create Person version should be two");
		// verify the person has 1 mainImages
		// assertEquals(retrievedPersonAfterSecondCreate.getMainImages().size(),
		// 2,
		// "The entity should have 2 main Image Files");

		// Delete Main Image 1
		long deletedObjects = this.mainImageFileClient.delete(inputMainImageFileOne.getId());
		assertEquals(deletedObjects, 1);

		Thread.sleep(THREAD_SLEEP_INTERVAL);

		Person retrievedPersonAfterDelete = this.personClient.get(inputPerson.getId(), new String[] {});
		assertEquals(retrievedPersonAfterDelete.getVersion(), new Long("3"), "After deleting MainImageFile link to person, version should be three");
		// verify the person has 1 mainImages
		// assertEquals(retrievedPersonAfterDelete.getMainImages().size(), 1,
		// "The entity does not have 1 main Image Files");

		// UPDATE MainImageFile which should notify to person
		inputMainImageFileTwo.setHeight(400);
		this.mainImageFileClient.update(inputMainImageFileTwo);

		Thread.sleep(THREAD_SLEEP_INTERVAL);

		Person retrievedPersonAfterUpdate = this.personClient.get(inputMainImageFileTwo.getEntityId(), new String[] {});
		// assertEquals(retrievedPersonAfterUpdate.getMainImages().size(), 1,
		// "person has one Main Images");
		assertEquals(retrievedPersonAfterUpdate.getVersion(), new Long("4"), "After updating MainImageFile link to person, version should be four");
		// making sure person has MainImageFile with updated height 400
		// assertMainImagesHeight(retrievedPersonAfterUpdate.getMainImages().values(),
		// "400");
	}

	private void assertMainImagesHeight(Collection<MediaFile> mediaFiles, String value) {
		if (mediaFiles.isEmpty())
			fail("person should have Media File");
		else {
			MediaFile actualMediaFile = null;
			FieldInfo height = null;
			for (MediaFile mediaFile : mediaFiles) {
				Map<FieldInfo, Object> maps = mediaFile.getCustomValues();
				Set<FieldInfo> keys = maps.keySet();
				for (FieldInfo fieldInfo : keys) {
					if (fieldInfo.getFieldName().endsWith("url")) {
						String url = (String) maps.get(fieldInfo);
						if (url.equals("http://image.gif")) {
							actualMediaFile = mediaFile;
						}
					}
				}
				for (FieldInfo fieldInfo : keys) {
					if (fieldInfo.getFieldName().endsWith("height")) {
						height = fieldInfo;
						if (actualMediaFile != null && actualMediaFile.getCustomValue(height) != null) {
							String ht = actualMediaFile.getCustomValue(height).toString();
							if (ht.equals(value)) {
								assertEquals(ht, value, "After update person has updated MediaFile");
								return;
							}
						}
					}
				}
			}
			fail("person failed due to MinImages value comparison");
		}
	}

}
