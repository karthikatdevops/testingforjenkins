package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import com.theplatform.contrib.data.api.objects.RatingScheme;
import com.theplatform.contrib.testing.client.ClientUtils;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociationMetadataManagementInfo;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMetadataManagementInfo;
import com.theplatform.data.tv.entity.api.test.ProgramMediaAssociationMetadataManagementInfoComparator;
import com.theplatform.data.tv.entity.api.test.ProgramMetadataManagementInfoComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.media.api.data.objects.Rating;
import org.springframework.util.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static java.util.Collections.singletonList;

/**
 * @author jcoelho
 */

@Test(groups = {"program", TestGroup.gbTest})
public class ProgramMmiIT extends EntityTestBase {

    @Test
    public void createProgram_hasMmiContentRatings() {

        ProgramMetadataManagementInfo pMmi = getProgramMetadataManagementInfo();

        Program p = programFactory.create();
        p.setMetadataManagementInfo(pMmi);

        Program createdProgram = programClient.create(p, new String[]{});

        Assert.notNull(createdProgram.getMetadataManagementInfo());
        ProgramMetadataManagementInfoComparator.assertEquals(createdProgram.getMetadataManagementInfo(), pMmi);
    }

    @Test
    public void updateProgram_hasMmiContentRatings() {

        ProgramMetadataManagementInfo pMmi = getProgramMetadataManagementInfo();

        Program p = programFactory.create();
        Program createdProgram = programClient.create(p, new String[]{});

        p.setId(createdProgram.getId());
        p.setMetadataManagementInfo(pMmi);
        programClient.update(p);

        Program fetchedProgram = programClient.get(createdProgram.getId(), new String[]{"metadataManagementInfo"});

        Assert.notNull(fetchedProgram.getMetadataManagementInfo());
        ProgramMetadataManagementInfoComparator.assertEquals(fetchedProgram.getMetadataManagementInfo(), pMmi);
    }

    @Test
    public void updateProgram_hasPartialMmiContentRatings() {

        ProgramMetadataManagementInfo pMmi = getPartialProgramMetadataManagementInfo();

        Program p = programFactory.create();
        Program createdProgram = programClient.create(p, new String[]{});

        p.setId(createdProgram.getId());
        p.setMetadataManagementInfo(pMmi);
        programClient.update(p);

        Program fetchedProgram = programClient.get(createdProgram.getId(), new String[]{"metadataManagementInfo"});

        Assert.notNull(fetchedProgram.getMetadataManagementInfo());
        logger.info(fetchedProgram.getMetadataManagementInfo());
        logger.info(pMmi);
        ProgramMetadataManagementInfoComparator.assertEquals(fetchedProgram.getMetadataManagementInfo(), pMmi);
    }

    private ProgramMetadataManagementInfo getProgramMetadataManagementInfo() {
        ProgramMetadataManagementInfo pMmi = new ProgramMetadataManagementInfo();
        pMmi.setAppendContentRatings(singletonList(new Rating(RatingScheme.MPAA.name(), "R", null)));
        pMmi.setRemoveContentRatingSchemes(singletonList(RatingScheme.AGVOT.name()));
        return pMmi;
    }

    private ProgramMetadataManagementInfo getPartialProgramMetadataManagementInfo() {
        ProgramMetadataManagementInfo pMmi = new ProgramMetadataManagementInfo();
        pMmi.setAppendContentRatings(Collections.emptyList());
        pMmi.setRemoveContentRatingSchemes(singletonList(RatingScheme.AGVOT.name()));
        return pMmi;
    }
}

