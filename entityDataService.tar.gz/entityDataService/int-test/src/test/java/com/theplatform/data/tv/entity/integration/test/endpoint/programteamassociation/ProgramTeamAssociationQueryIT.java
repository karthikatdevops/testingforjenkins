package com.theplatform.data.tv.entity.integration.test.endpoint.programteamassociation;

import static org.testng.Assert.assertEquals;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.entity.api.client.query.programteamassociation.ByProgramId;
import com.theplatform.data.tv.entity.api.client.query.programteamassociation.BySportsTeamId;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.api.test.ProgramTeamAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * 
 */

@Test(groups = {TestGroup.gbTest, "programTeamAssociation", "query"})
public class ProgramTeamAssociationQueryIT extends EntityTestBase {
	@Test(groups = { TestGroup.gbTest })
	public void testQueryProgramTeamAssociationBySportsTeamId() throws UnknownHostException {
		List<ProgramTeamAssociation> inputProgramTeamAssociations = this.programTeamAssociationFactory
				.create(3);
		this.programTeamAssociationClient.create(inputProgramTeamAssociations);
		Query queries[] = new Query[] { new BySportsTeamId(LocalUriConverter.convertUriToID(inputProgramTeamAssociations.get(1).getSportsTeamId())) };
		Feed<ProgramTeamAssociation> retrievedProgramTeamAssociation = this.programTeamAssociationClient.getAll(null,
				queries, null, null, null);
		assertEquals(retrievedProgramTeamAssociation.getEntries().size(), 1,
				"Not getting ProgramTeamAssociations using query bySportsTeamId");
		ProgramTeamAssociationComparator.assertEquals(retrievedProgramTeamAssociation
				.getEntries().get(0), inputProgramTeamAssociations.get(1));
	}

	@Test(groups = { TestGroup.gbTest })
	public void testQueryProgramTeamAssociationByProgramId() throws UnknownHostException {
		List<ProgramTeamAssociation> inputProgramTeamAssociations = this.programTeamAssociationFactory
				.create(3);
		this.programTeamAssociationClient.create(inputProgramTeamAssociations);
		Query queries[] = new Query[] { new ByProgramId(LocalUriConverter.convertUriToID(inputProgramTeamAssociations
				.get(2).getProgramId())) };
		Feed<ProgramTeamAssociation> retrievedProgramTeamAssociations = this.programTeamAssociationClient.getAll(null,
				queries, null, null, null);
		assertEquals(retrievedProgramTeamAssociations.getEntries().size(), 1,
				"Not getting ProgramTeamAssociations using query byProgramId");
		ProgramTeamAssociationComparator.assertEquals(retrievedProgramTeamAssociations
				.getEntries().get(0), inputProgramTeamAssociations.get(2));
	}

	@Test(groups = { "other" })
	public void testQueryProgramTeamAssociationByAllQueryCombination() throws UnknownHostException {
		List<ProgramTeamAssociation> inputProgramTeamAssociations = this.programTeamAssociationFactory
				.create(15);
		this.programTeamAssociationClient.create(inputProgramTeamAssociations);
		List<Long> sportsTeamIds = new ArrayList<>();
		sportsTeamIds.add(LocalUriConverter.convertUriToID(inputProgramTeamAssociations.get(2).getSportsTeamId()));
		sportsTeamIds.add(LocalUriConverter.convertUriToID(inputProgramTeamAssociations.get(6).getSportsTeamId()));

		List<Long> programIds = new ArrayList<>();
		programIds.add(LocalUriConverter.convertUriToID(inputProgramTeamAssociations.get(2).getProgramId()));
		programIds.add(LocalUriConverter.convertUriToID(inputProgramTeamAssociations.get(6).getProgramId()));

		Query queries[] = new Query[] { new BySportsTeamId(sportsTeamIds), new ByProgramId(programIds) };
		Feed<ProgramTeamAssociation> retrievedProgramTeamAssociations = this.programTeamAssociationClient.getAll(null,
				queries, null, null, null);
		assertEquals(retrievedProgramTeamAssociations.getEntries().size(), 2,
				"Not get all ProgramTeamAssociations using query combination");

		// to make comparison for all fields
		ProgramTeamAssociationComparator.assertEquals(retrievedProgramTeamAssociations
				.getEntries().get(0), inputProgramTeamAssociations.get(6));
		ProgramTeamAssociationComparator.assertEquals(retrievedProgramTeamAssociations
				.getEntries().get(1), inputProgramTeamAssociations.get(2));

		assertEquals(retrievedProgramTeamAssociations.getEntryCount().longValue(), 2,
				"Not get all ProgramTeamAssociations using query combination");

	}
}
