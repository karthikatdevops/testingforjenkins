package com.theplatform.data.tv.entity.integration.test.endpoint.entitycollection;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.fields.EntityCollectionField;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.test.EntityCollectionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * GreenBuild test for sorting of EntityCollection
 * 
 * @author jethrolai
 * @since 9/2/2011
 * 
 */
@Test(groups = { "entityCollection", "sort" })
public class EntityCollectionSortIT extends EntityTestBase {

	private static final int TEST_LIST_SIZE = 4;

	private List<EntityCollection> entityCollections;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		entityCollections = this.entityCollectionFactory.create(TEST_LIST_SIZE, new DataServiceField(EntityCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		this.entityCollectionClient.create(entityCollections);

	}


	@Test(groups = { TestGroup.gbTest })
	public void testSortEntityCollectionByTitleAlphabetically() {
		entityCollections.get(3).setTitle("A");
		entityCollections.get(0).setTitle("B");
		entityCollections.get(1).setTitle("C");
		entityCollections.get(2).setTitle("D");

		this.entityCollectionClient.update(entityCollections);

		// SORT EXPECTED
		List<EntityCollection> expectedSortedEntityCollections = new ArrayList<>(entityCollections.size());
		expectedSortedEntityCollections.add(entityCollections.get(3));
		expectedSortedEntityCollections.add(entityCollections.get(0));
		expectedSortedEntityCollections.add(entityCollections.get(1));
		expectedSortedEntityCollections.add(entityCollections.get(2));

		// RETRIVE WHITH SORTING
		String sortFiedld = "title";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<EntityCollection> retrievedEntityCollections = this.entityCollectionClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort },
				null, false);

		EntityCollectionComparator.assertEquals(retrievedEntityCollections, expectedSortedEntityCollections);
	}
}
