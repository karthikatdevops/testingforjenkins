package com.theplatform.data.tv.entity.integration.test.endpoint.imageassociation;

import com.theplatform.contrib.data.api.client.query.ByMediaIdAccountGuid;
import com.theplatform.contrib.data.api.client.query.ByMediaIdMediaGuid;
import com.theplatform.contrib.data.api.client.query.ByMediaIdServiceGuid;
import com.theplatform.contrib.data.api.client.query.QueryType;
import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.client.query.imageassociation.*;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociationMetadataManagementInfo;
import com.theplatform.data.tv.image.api.fields.ImageAssociationField;
import com.theplatform.data.tv.image.api.test.ImageAssociationComparator;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.*;

@Test(groups = { "imageAssociation", "query", TestGroup.gbTest })
public class ImageAssociationQueryIT extends EntityTestBase {

	private Random random = new Random();

	public void testImageAssociationQueryByEntityIdNoMatch() {

		final URI entityId = this.programClient.create(this.programFactory.create()).getId();
		final URI actualEntityId = this.imageAssociationClient.create(
                this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, this.programClient.create(
                        this.programFactory.create()).getId())), new String[] { ImageAssociationField.entityId.getLocalName() }).getEntityId();
		Assert.assertNotEquals(entityId, actualEntityId);
		Query[] queries = new Query[] { new ByEntityId(URIUtils.getIdValue(entityId)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByEntityIdListNoMatch() {
		final URI entityId1 = this.programClient.create(this.programFactory.create()).getId();
		final URI entityId2 = this.programClient.create(this.programFactory.create()).getId();
		final URI actualEntityId = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, this.programClient.create(
						this.programFactory.create()).getId())), new String[] { ImageAssociationField.entityId.getLocalName() }).getEntityId();
		Assert.assertNotEquals(entityId1, actualEntityId);
		Assert.assertNotEquals(entityId2, actualEntityId);
		Query[] queries = new Query[] { new ByEntityId(Arrays.asList(URIUtils.getIdValue(entityId1), URIUtils.getIdValue(entityId2))) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByEntityIdOneMatch() {

		final URI entityId = this.programClient.create(this.programFactory.create()).getId();
		ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId)), new String[] {});
		ImageAssociation unexpected = this.imageAssociationClient.create(this.imageAssociationFactory.create(), new String[] {});
		Assert.assertNotEquals(expected.getEntityId(), unexpected.getEntityId());

		Query[] queries = new Query[] { new ByEntityId(URIUtils.getIdValue(entityId)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testImageAssociationQueryByEntityIdListOneMatch() {

		final URI entityId1 = this.programClient.create(this.programFactory.create()).getId();
		final URI entityId2 = this.programClient.create(this.programFactory.create()).getId();
		final URI entityId3 = this.programClient.create(this.programFactory.create()).getId();

		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId1)));

		ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId2)), new String[] {});
		Query[] queries = new Query[] { new ByEntityId(Arrays.asList(URIUtils.getIdValue(entityId2), URIUtils.getIdValue(entityId3))) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testImageAssociationQueryByEntityIdMultipleMatch() {

		final URI entityId1 = this.programClient.create(this.programFactory.create()).getId();
		final URI entityId2 = this.programClient.create(this.programFactory.create()).getId();
		Assert.assertNotEquals(entityId1, entityId2);

		ImageAssociation imageAssociation1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId1)), new String[] {});
		ImageAssociation imageAssociation2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId1)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId2)));

		Query[] queries = new Query[] { new ByEntityId(URIUtils.getIdValue(entityId1)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");

		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);

		ImageAssociationComparator.assertEquals(resultMap.get(imageAssociation1.getId()), imageAssociation1);
		ImageAssociationComparator.assertEquals(resultMap.get(imageAssociation2.getId()), imageAssociation2);
	}

	public void testImageAssociationQueryByEntityIdListMultipleMatch() {

		final URI entityId1 = this.programClient.create(this.programFactory.create()).getId();
		final URI entityId2 = this.programClient.create(this.programFactory.create()).getId();
		final URI entityId3 = this.programClient.create(this.programFactory.create()).getId();
		Assert.assertNotEquals(entityId1, entityId2);
		Assert.assertNotEquals(entityId3, entityId2);

		ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId1)), new String[] {});
		ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId2)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId3)));

		Query[] queries = new Query[] { new ByEntityId(Arrays.asList(URIUtils.getIdValue(entityId1), URIUtils.getIdValue(entityId2))) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");

		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);

		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testImageAssociationQueryByEntityIdAndEntityTypeNoMatch() {

		final URI programEntityId = this.programClient.create(this.programFactory.create()).getId();
		final URI actualProgramEntityId = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, this.programClient.create(
						this.programFactory.create()).getId())), new String[] { ImageAssociationField.entityId.getLocalName() }).getEntityId();
		final URI personEntityId = this.personClient.create(this.personFactory.create()).getId();
		final URI actualPersonEntityId = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, this.personClient.create(this.personFactory.create())
						.getId())), new String[] { ImageAssociationField.entityId.getLocalName() }).getEntityId();
		Assert.assertNotEquals(programEntityId, actualProgramEntityId);
		Assert.assertNotEquals(personEntityId, actualPersonEntityId);
		Query[] queries = new Query[] { new ByEntityId(URIUtils.getIdValue(programEntityId)), new ByEntityType("Person") };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByEntityIdAndEntityTypeListNoMatch() {
		final URI actualEntityId = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, this.programClient.create(
						this.programFactory.create()).getId())), new String[] { ImageAssociationField.entityId.getLocalName() }).getEntityId();
		Query[] queries = new Query[] { new ByEntityId(Arrays.asList(URIUtils.getIdValue(actualEntityId))), new ByEntityType(Arrays.asList("Person", "Credit")) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByEntityIdAndEntityTypeOneMatch() {

		final URI entityId = this.programClient.create(this.programFactory.create()).getId();
		ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, entityId)), new String[] {});
		ImageAssociation unexpected = this.imageAssociationClient.create(this.imageAssociationFactory.create(), new String[] {});
		Assert.assertNotEquals(expected.getEntityId(), unexpected.getEntityId());

		Query[] queries = new Query[] { new ByEntityId(URIUtils.getIdValue(entityId)), new ByEntityType("Program") };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testImageAssociationQueryByEntityIdByEntityTypeListOneMatch() {

		final ImageAssociation actualProgramImageAssociation = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, this.programClient.create(
						this.programFactory.create()).getId())), new String[] {});
		final ImageAssociation actualPersonImageAssociation = this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(
				ImageAssociationField.entityId, this.personClient.create(this.personFactory.create()).getId())), new String[] {});
		Assert.assertNotEquals(actualProgramImageAssociation.getEntityId(), actualPersonImageAssociation.getEntityId());
		Query[] queries = new Query[] {
				new ByEntityId(Arrays.asList(URIUtils.getIdValue(actualProgramImageAssociation.getEntityId()),
						URIUtils.getIdValue(actualPersonImageAssociation.getEntityId()))), new ByEntityType("Program") };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), actualProgramImageAssociation);
	}

	// query by single EntityId and EntityType and return multiple result is
	// impossible when testing with AuthProxy because all ids need to be unique

	public void testImageAssociationQueryByEntityIdAndEntityTypeListMultipleMatch() {

		final ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.entityId, this.programClient.create(
						this.programFactory.create()).getId())), new String[] {});
		final ImageAssociation expected2 = this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(
				ImageAssociationField.entityId, this.personClient.create(this.personFactory.create()).getId())), new String[] {});

		Query[] queries = new Query[] {
				new ByEntityId(Arrays.asList(URIUtils.getIdValue(expected1.getEntityId()), URIUtils.getIdValue(expected2.getEntityId()))),
				new ByEntityType(Arrays.asList("Program", "Person")) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");

		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);

		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}


	public void testImageAssociationQuerybyPreferForMainImageTypeIdsNoMatch() {

		URI mainImageTypeId1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId2);

		final List<URI> actualPreferForMainImageTypeIds = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1))),
				new String[] { ImageAssociationField.preferForMainImageTypeIds.getLocalName() }).getPreferForMainImageTypeIds();
		Assert.assertNotNull(actualPreferForMainImageTypeIds);
		Assert.assertEquals(actualPreferForMainImageTypeIds.size(), 1);
		Assert.assertNotNull(actualPreferForMainImageTypeIds.get(0));
		Assert.assertNotEquals(actualPreferForMainImageTypeIds.get(0), mainImageTypeId2);

		Query[] queries = new Query[] { new ByPreferForMainImageTypeIds(URIUtils.getIdValue(mainImageTypeId2)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByPreferForMainImageIdsListOrQueryNoMatch() {
		URI mainImageTypeId1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId3 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId2);
		Assert.assertNotEquals(mainImageTypeId3, mainImageTypeId2);

		final List<URI> actualPreferForMainImageTypeIds = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1))),
				new String[] { ImageAssociationField.preferForMainImageTypeIds.getLocalName() }).getPreferForMainImageTypeIds();
		Assert.assertNotNull(actualPreferForMainImageTypeIds);
		Assert.assertEquals(actualPreferForMainImageTypeIds.size(), 1);
		Assert.assertNotNull(actualPreferForMainImageTypeIds.get(0));
		Assert.assertNotEquals(actualPreferForMainImageTypeIds.get(0), mainImageTypeId2);

		Query[] queries = new Query[] { new ByPreferForMainImageTypeIds(Arrays.asList(URIUtils.getIdValue(mainImageTypeId2),
				URIUtils.getIdValue(mainImageTypeId3)), QueryType.OR) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByPreferForMainImageIdsListAndQueryNoMatch() {
		URI mainImageTypeId1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId3 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId2);
		Assert.assertNotEquals(mainImageTypeId3, mainImageTypeId2);

		final List<URI> actualPreferForMainImageTypeIds = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1))),
				new String[] { ImageAssociationField.preferForMainImageTypeIds.getLocalName() }).getPreferForMainImageTypeIds();
		Assert.assertNotNull(actualPreferForMainImageTypeIds);
		Assert.assertEquals(actualPreferForMainImageTypeIds.size(), 1);
		Assert.assertNotNull(actualPreferForMainImageTypeIds.get(0));
		Assert.assertNotEquals(actualPreferForMainImageTypeIds.get(0), mainImageTypeId2);

		Query[] queries = new Query[] { new ByPreferForMainImageTypeIds(Arrays.asList(URIUtils.getIdValue(mainImageTypeId2),
				URIUtils.getIdValue(mainImageTypeId3)), QueryType.AND) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByPreferForMainImageTypeIdsOneMatch() {

		URI mainImageTypeId1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId2);

		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1))),
				new String[] {});
		this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId2))),
				new String[] { ImageAssociationField.preferForMainImageTypeIds.getLocalName() });
		Assert.assertNotNull(expected.getPreferForMainImageTypeIds());
		Assert.assertEquals(expected.getPreferForMainImageTypeIds().size(), 1);
		Assert.assertNotNull(expected.getPreferForMainImageTypeIds().get(0));
		Assert.assertNotEquals(expected.getPreferForMainImageTypeIds().get(0), mainImageTypeId2);
		Query[] queries = new Query[] { new ByPreferForMainImageTypeIds(URIUtils.getIdValue(mainImageTypeId1)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testImageAssociationQueryByPreferForMainImageTypeIdsListOrOneMatch() {

		URI mainImageTypeId1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId3 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId2);
		Assert.assertNotEquals(mainImageTypeId3, mainImageTypeId2);

		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1))),
				new String[] {});
		this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId2))),
				new String[] { ImageAssociationField.preferForMainImageTypeIds.getLocalName() });
		Assert.assertNotNull(expected.getPreferForMainImageTypeIds());
		Assert.assertEquals(expected.getPreferForMainImageTypeIds().size(), 1);
		Assert.assertNotNull(expected.getPreferForMainImageTypeIds().get(0));
		Assert.assertNotEquals(expected.getPreferForMainImageTypeIds().get(0), mainImageTypeId2);

		Query[] queries = new Query[] { new ByPreferForMainImageTypeIds(Arrays.asList(URIUtils.getIdValue(mainImageTypeId1),
				URIUtils.getIdValue(mainImageTypeId3)), QueryType.OR) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testImageAssociationQueryByPreferForMainImageTypeIdsListAndOneMatch() {

		URI mainImageTypeId1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		URI mainImageTypeId3 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId2);
		Assert.assertNotEquals(mainImageTypeId3, mainImageTypeId2);

		final ImageAssociation expected = this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(
				ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1, mainImageTypeId3))), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays
				.asList(mainImageTypeId2))));
		Assert.assertNotNull(expected.getPreferForMainImageTypeIds());
		Assert.assertEquals(expected.getPreferForMainImageTypeIds().size(), 2);
		Assert.assertNotNull(expected.getPreferForMainImageTypeIds().get(0));
		Assert.assertNotEquals(expected.getPreferForMainImageTypeIds().get(0), mainImageTypeId2);

		Query[] queries = new Query[] { new ByPreferForMainImageTypeIds(Arrays.asList(URIUtils.getIdValue(mainImageTypeId1),
				URIUtils.getIdValue(mainImageTypeId3)), QueryType.AND) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testImageAssociationQueryByPreferForMainImageTypeIdsMultipleMatch() {

		final URI mainImageTypeId1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		final URI mainImageTypeId2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId2);

		ImageAssociation imageAssociation1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1))),
				new String[] {});
		ImageAssociation imageAssociation2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1))),
				new String[] {});
		this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId2))),
				new String[] { ImageAssociationField.preferForMainImageTypeIds.getLocalName() });
		Assert.assertNotNull(imageAssociation1.getPreferForMainImageTypeIds());
		Assert.assertEquals(imageAssociation1.getPreferForMainImageTypeIds().size(), 1);
		Assert.assertNotNull(imageAssociation1.getPreferForMainImageTypeIds().get(0));
		Assert.assertEquals(imageAssociation1.getPreferForMainImageTypeIds().get(0), mainImageTypeId1);
		Assert.assertNotNull(imageAssociation2.getPreferForMainImageTypeIds());
		Assert.assertEquals(imageAssociation2.getPreferForMainImageTypeIds().size(), 1);
		Assert.assertNotNull(imageAssociation2.getPreferForMainImageTypeIds().get(0));
		Assert.assertEquals(imageAssociation2.getPreferForMainImageTypeIds().get(0), mainImageTypeId1);

		Query[] queries = new Query[] { new ByPreferForMainImageTypeIds(URIUtils.getIdValue(mainImageTypeId1)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");

		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);

		ImageAssociationComparator.assertEquals(resultMap.get(imageAssociation1.getId()), imageAssociation1);
		ImageAssociationComparator.assertEquals(resultMap.get(imageAssociation2.getId()), imageAssociation2);
	}

	public void testImageAssociationQueryByPerferForMainImageTypeIdsListOrQueryMultipleMatch() {

		final URI mainImageTypeId1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		final URI mainImageTypeId2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		final URI mainImageTypeId3 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId2);
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId3);

		ImageAssociation imageAssociation1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1))),
				new String[] {});
		ImageAssociation imageAssociation2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId2))),
				new String[] {});
		this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId3))),
				new String[] {});
		Assert.assertNotNull(imageAssociation1.getPreferForMainImageTypeIds());
		Assert.assertEquals(imageAssociation1.getPreferForMainImageTypeIds().size(), 1);
		Assert.assertNotNull(imageAssociation1.getPreferForMainImageTypeIds().get(0));
		Assert.assertEquals(imageAssociation1.getPreferForMainImageTypeIds().get(0), mainImageTypeId1);
		Assert.assertNotNull(imageAssociation2.getPreferForMainImageTypeIds());
		Assert.assertEquals(imageAssociation2.getPreferForMainImageTypeIds().size(), 1);
		Assert.assertNotNull(imageAssociation2.getPreferForMainImageTypeIds().get(0));
		Assert.assertEquals(imageAssociation2.getPreferForMainImageTypeIds().get(0), mainImageTypeId2);

		Query[] queries = new Query[] { new ByPreferForMainImageTypeIds(Arrays.asList(URIUtils.getIdValue(mainImageTypeId1),
				URIUtils.getIdValue(mainImageTypeId2)), QueryType.OR) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");

		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);

		ImageAssociationComparator.assertEquals(resultMap.get(imageAssociation1.getId()), imageAssociation1);
		ImageAssociationComparator.assertEquals(resultMap.get(imageAssociation2.getId()), imageAssociation2);
	}

	public void testImageAssociationQueryByPerferForMainImageTypeIdsListAndQueryMultipleMatch() {

		final URI mainImageTypeId1 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		final URI mainImageTypeId2 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		final URI mainImageTypeId3 = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId2);
		Assert.assertNotEquals(mainImageTypeId1, mainImageTypeId3);

		ImageAssociation imageAssociation1 = this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(
				ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1, mainImageTypeId2))), new String[] {});
		ImageAssociation imageAssociation2 = this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(
				ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId1, mainImageTypeId2))), new String[] {});
		this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypeId3))),
				new String[] {});
		Assert.assertNotNull(imageAssociation1.getPreferForMainImageTypeIds());
		Assert.assertEquals(imageAssociation1.getPreferForMainImageTypeIds().size(), 2);
		Assert.assertTrue(imageAssociation1.getPreferForMainImageTypeIds().contains(mainImageTypeId1));
		Assert.assertTrue(imageAssociation1.getPreferForMainImageTypeIds().contains(mainImageTypeId2));
		Assert.assertNotNull(imageAssociation2.getPreferForMainImageTypeIds());
		Assert.assertEquals(imageAssociation2.getPreferForMainImageTypeIds().size(), 2);
		Assert.assertTrue(imageAssociation2.getPreferForMainImageTypeIds().contains(mainImageTypeId2));

		Query[] queries = new Query[] { new ByPreferForMainImageTypeIds(Arrays.asList(URIUtils.getIdValue(mainImageTypeId1),
				URIUtils.getIdValue(mainImageTypeId2)), QueryType.AND) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");

		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);

		ImageAssociationComparator.assertEquals(resultMap.get(imageAssociation1.getId()), imageAssociation1);
		ImageAssociationComparator.assertEquals(resultMap.get(imageAssociation2.getId()), imageAssociation2);
	}

	public void testImageAssociationQueryByInDefaultNoMatch() {

		final boolean isDefault = true;
		final boolean actualIsDefault = this.imageAssociationClient.create(this.imageAssociationFactory.create(),
				new String[] { ImageAssociationField.isDefault.getLocalName() }).getIsDefault();
		Assert.assertNotEquals(isDefault, actualIsDefault);
		Query[] queries = new Query[] { new ByIsDefault(isDefault) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByIsDefaultOneMatch() {

		final boolean isDefault = false;
		ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.isDefault, isDefault)), new String[] {});
		ImageAssociation unexpected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.isDefault, !isDefault)), new String[] {});
		Assert.assertNotEquals(expected.getIsDefault(), unexpected.getIsDefault());

		Query[] queries = new Query[] { new ByIsDefault(isDefault) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testImageAssociationQueryByIsDefaultMultipleMatch() {

		final boolean isDefault = false;
		ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.isDefault, isDefault)), new String[] {});
		ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.isDefault, isDefault)), new String[] {});
		ImageAssociation unexpected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.isDefault, !isDefault)), new String[] {});
		Assert.assertNotEquals(expected1.getIsDefault(), unexpected.getIsDefault());
		Assert.assertNotEquals(expected2.getIsDefault(), unexpected.getIsDefault());

		Query[] queries = new Query[] { new ByIsDefault(isDefault) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");

		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);

		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}


	public void testImageAssociationQueryByMmiEntityIdNoMatch() {

		final String entityId = "fakeEntityId";
		ImageAssociationMetadataManagementInfo mmi = new ImageAssociationMetadataManagementInfo();
		mmi.setEntityId(entityId);

		final ImageAssociation unexpected = this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(
				ImageAssociationField.merlinResourceType, MerlinResourceType.Inactive), new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi)), new String[] {});
		Assert.assertNotNull(unexpected.getMetadataManagementInfo());
		Assert.assertEquals(unexpected.getMetadataManagementInfo().getEntityId(), entityId);

		Query[] queries = new Query[] { new ByMmiEntityId(entityId.concat("update")) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByMmiEntityIdListNoMatch() {
		final String entityId1 = "fakeEntityId1";
		final String entityId2 = "fakeEntityId2";
		final String entityId3 = "fakeEntityId3";
		ImageAssociationMetadataManagementInfo mmi1 = new ImageAssociationMetadataManagementInfo();
		mmi1.setEntityId(entityId1);
		ImageAssociationMetadataManagementInfo mmi2 = new ImageAssociationMetadataManagementInfo();
		mmi2.setEntityId(entityId2);

		final ImageAssociation unexpected1 = this.imageAssociationClient
				.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.merlinResourceType, MerlinResourceType.Inactive),
						new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi1)), new String[] {});
		final ImageAssociation unexpected2 = this.imageAssociationClient
				.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.merlinResourceType, MerlinResourceType.Inactive),
						new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi2)), new String[] {});
		Assert.assertNotNull(unexpected1.getMetadataManagementInfo());
		Assert.assertEquals(unexpected1.getMetadataManagementInfo().getEntityId(), entityId1);
		Assert.assertNotNull(unexpected2.getMetadataManagementInfo());
		Assert.assertEquals(unexpected2.getMetadataManagementInfo().getEntityId(), entityId2);

		Assert.assertNotEquals(entityId3, entityId1);
		Assert.assertNotEquals(entityId3, entityId2);
		Query[] queries = new Query[] { new ByMmiEntityId(Arrays.asList(entityId1, entityId2)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}

	public void testImageAssociationQueryByMmiEntityIdOneMatch() {

		final String entityId = "fakeEntityId1";
		ImageAssociationMetadataManagementInfo mmi = new ImageAssociationMetadataManagementInfo();
		mmi.setEntityId(entityId);
		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi)), new String[] {});
		Assert.assertNotNull(expected.getMetadataManagementInfo());
		Assert.assertEquals(expected.getMetadataManagementInfo().getEntityId(), entityId);
		Query[] queries = new Query[] { new ByMmiEntityId(entityId) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testImageAssociationQueryByMmiEntityIdListOneMatch() {

		final String entityId1 = "fakeEntityId1";
		final String entityId2 = "fakeEntityId2";
		final String entityId3 = "fakeEntityId3";
		ImageAssociationMetadataManagementInfo mmi1 = new ImageAssociationMetadataManagementInfo();
		mmi1.setEntityId(entityId1);
		ImageAssociationMetadataManagementInfo mmi2 = new ImageAssociationMetadataManagementInfo();
		mmi2.setEntityId(entityId2);
		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi1)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi2)));
		Assert.assertNotNull(expected.getMetadataManagementInfo());
		Assert.assertEquals(expected.getMetadataManagementInfo().getEntityId(), entityId1);

		Query[] queries = new Query[] { new ByMmiEntityId(Arrays.asList(entityId1, entityId3)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");

		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testImageAssociationQueryByMmiEntityIdMultipleMatch() {

		final String entityId1 = "fakeEntityId1";
		final String entityId2 = "fakeEntityId2";
		ImageAssociationMetadataManagementInfo mmi1 = new ImageAssociationMetadataManagementInfo();
		mmi1.setEntityId(entityId1);
		ImageAssociationMetadataManagementInfo mmi2 = new ImageAssociationMetadataManagementInfo();
		mmi2.setEntityId(entityId2);
		final ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi1)), new String[] {});
		final ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi1)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi2)), new String[] {});
		Assert.assertNotNull(expected1.getMetadataManagementInfo());
		Assert.assertEquals(expected1.getMetadataManagementInfo().getEntityId(), entityId1);
		Assert.assertNotNull(expected2.getMetadataManagementInfo());
		Assert.assertEquals(expected2.getMetadataManagementInfo().getEntityId(), entityId1);

		Query[] queries = new Query[] { new ByMmiEntityId(entityId1) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");

		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);

		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testImageAssociationQueryByMmiEntityIdListMultipleMatch() {

		final String entityId1 = "fakeEntityId1";
		final String entityId2 = "fakeEntityId2";
		final String entityId3 = "fakeEntityId3";
		Assert.assertNotEquals(entityId1, entityId2);
		Assert.assertNotEquals(entityId3, entityId2);
		ImageAssociationMetadataManagementInfo mmi1 = new ImageAssociationMetadataManagementInfo();
		mmi1.setEntityId(entityId1);
		ImageAssociationMetadataManagementInfo mmi2 = new ImageAssociationMetadataManagementInfo();
		mmi2.setEntityId(entityId2);
		ImageAssociationMetadataManagementInfo mmi3 = new ImageAssociationMetadataManagementInfo();
		mmi3.setEntityId(entityId3);

		ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi1)), new String[] {});
		Assert.assertNotNull(expected1.getMetadataManagementInfo());
		Assert.assertEquals(expected1.getMetadataManagementInfo().getEntityId(), entityId1);
		ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi2)), new String[] {});
		Assert.assertNotNull(expected2.getMetadataManagementInfo());
		Assert.assertEquals(expected2.getMetadataManagementInfo().getEntityId(), entityId2);
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ManagedMerlinDataObjectField.metadataManagementInfo, mmi3)));

		Query[] queries = new Query[] { new ByMmiEntityId(Arrays.asList(entityId1, entityId2)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");

		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);

		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}
	
	
	public void testImageAssociationQueryByMediaIdServiceGuidNoMatch() {
		
		final String serviceGuid = "serviceGuid";
		MediaId mediaId = new MediaId(); 
		mediaId.setServiceGuid(serviceGuid);
		mediaId.setAccountGuid("accountGuid");
		mediaId.setMediaGuid("mediaGuid");
		
		final ImageAssociation unexpected = this.imageAssociationClient.create(this.imageAssociationFactory.create( new DataServiceField(ImageAssociationField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(unexpected.getMediaId());
		Assert.assertEquals(unexpected.getMediaId().getServiceGuid(), serviceGuid);
		
		Query[] queries = new Query[] { new ByMediaIdServiceGuid(serviceGuid.concat("update")) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}
	
	public void testImageAssociationQueryByMediaIdServiceGuidListNoMatch() {
		final String serviceGuid1 = "serviceGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setServiceGuid(serviceGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String serviceGuid2 = "serviceGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setServiceGuid(serviceGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setMediaGuid("mediaGuid");
		final String serviceGuid3 = "serviceGuid3";
		MediaId mediaId3 = new MediaId(); 
		mediaId3.setServiceGuid(serviceGuid3);
		mediaId3.setAccountGuid("accountGuid");
		mediaId3.setMediaGuid("mediaGuid");

		final ImageAssociation unexpected1 = this.imageAssociationClient
				.create(this.imageAssociationFactory.create(
						new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		final ImageAssociation unexpected2 = this.imageAssociationClient
				.create(this.imageAssociationFactory.create(
						new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		Assert.assertNotNull(unexpected1.getMediaId());
		Assert.assertEquals(unexpected1.getMediaId().getServiceGuid(), serviceGuid1);
		Assert.assertNotNull(unexpected2.getMediaId());
		Assert.assertEquals(unexpected2.getMediaId().getServiceGuid(), serviceGuid1);
		
		
		Query[] queries = new Query[] { new ByMediaIdServiceGuid(Arrays.asList(serviceGuid3, serviceGuid2)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}
	
	public void testImageAssociationQueryByMediaIdServiceGuidOneMatch() {
		
		final String serviceGuid = "serviceGuid1";
		MediaId mediaId = new MediaId();
		mediaId.setServiceGuid(serviceGuid);
		mediaId.setAccountGuid("accountGuid");
		mediaId.setMediaGuid("mediaGuid");
		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getServiceGuid(), serviceGuid);
		Query[] queries = new Query[] { new ByMediaIdServiceGuid(serviceGuid) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");
		
		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}
	
	public void testImageAssociationQueryByMediaIdServiceGuidListOneMatch() {
		
		final String serviceGuid1 = "serviceGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setServiceGuid(serviceGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String serviceGuid2 = "serviceGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setServiceGuid(serviceGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setMediaGuid("mediaGuid");
		final String serviceGuid3 = "serviceGuid3";
		MediaId mediaId3 = new MediaId(); 
		mediaId3.setServiceGuid(serviceGuid3);
		mediaId3.setAccountGuid("accountGuid");
		mediaId3.setMediaGuid("mediaGuid");
		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId2)));
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getServiceGuid(), serviceGuid1);
		
		Query[] queries = new Query[] { new ByMediaIdServiceGuid(Arrays.asList(serviceGuid1, serviceGuid3)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");
		
		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}
	
	public void testImageAssociationQueryByMediaIdServiceGuidMultipleMatch() {
		
		final String serviceGuid1 = "serviceGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setServiceGuid(serviceGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String serviceGuid2 = "serviceGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setServiceGuid(serviceGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setMediaGuid("mediaGuid");
		
		final ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		final ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId2)), new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getServiceGuid(), serviceGuid1);
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getServiceGuid(), serviceGuid1);
		
		Query[] queries = new Query[] { new ByMediaIdServiceGuid(serviceGuid1) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");
		
		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);
		
		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}
	
	public void testImageAssociationQueryByMediaIdServiceGuidListMultipleMatch() {
		
		final String serviceGuid1 = "serviceGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setServiceGuid(serviceGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String serviceGuid2 = "serviceGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setServiceGuid(serviceGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setMediaGuid("mediaGuid");
		final String serviceGuid3 = "serviceGuid3";
		MediaId mediaId3 = new MediaId(); 
		mediaId3.setServiceGuid(serviceGuid3);
		mediaId3.setAccountGuid("accountGuid");
		mediaId3.setMediaGuid("mediaGuid");
		Assert.assertNotEquals(serviceGuid1, serviceGuid2);
		Assert.assertNotEquals(serviceGuid3, serviceGuid2);
		
		ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getServiceGuid(), serviceGuid1);
		ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId2)), new String[] {});
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getServiceGuid(), serviceGuid2);
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId3)));
		
		Query[] queries = new Query[] { new ByMediaIdServiceGuid(Arrays.asList(serviceGuid1, serviceGuid2)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");
		
		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);
		
		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}
	public void testImageAssociationQueryByMediaIdAccountGuidNoMatch() {
		
		final String accountGuid = "accountGuid";
		MediaId mediaId = new MediaId(); 
		mediaId.setAccountGuid(accountGuid);
		mediaId.setMediaGuid("mediaGuid");
		mediaId.setServiceGuid("serviceGuid");
		
		final ImageAssociation unexpected = this.imageAssociationClient.create(this.imageAssociationFactory.create( new DataServiceField(ImageAssociationField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(unexpected.getMediaId());
		Assert.assertEquals(unexpected.getMediaId().getAccountGuid(), accountGuid);
		
		Query[] queries = new Query[] { new ByMediaIdAccountGuid(accountGuid.concat("update")) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}
	
	public void testImageAssociationQueryByMediaIdAccountGuidListNoMatch() {
		final String accountGuid1 = "accountGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setAccountGuid(accountGuid1);
		mediaId1.setMediaGuid("mediaGuid");
		mediaId1.setServiceGuid("serviceGuid");
		final String accountGuid2 = "accountGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setAccountGuid(accountGuid2);
		mediaId2.setMediaGuid("mediaGuid");
		mediaId2.setServiceGuid("serviceGuid");
		final String accountGuid3 = "accountGuid3";
		MediaId mediaId3 = new MediaId(); 
		mediaId3.setAccountGuid(accountGuid3);
		mediaId3.setMediaGuid("mediaGuid");
		mediaId3.setServiceGuid("serviceGuid");
		
		final ImageAssociation unexpected1 = this.imageAssociationClient
				.create(this.imageAssociationFactory.create(
						new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		final ImageAssociation unexpected2 = this.imageAssociationClient
				.create(this.imageAssociationFactory.create(
						new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		Assert.assertNotNull(unexpected1.getMediaId());
		Assert.assertEquals(unexpected1.getMediaId().getAccountGuid(), accountGuid1);
		Assert.assertNotNull(unexpected2.getMediaId());
		Assert.assertEquals(unexpected2.getMediaId().getAccountGuid(), accountGuid1);
		
		
		Query[] queries = new Query[] { new ByMediaIdAccountGuid(Arrays.asList(accountGuid3, accountGuid2)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}
	
	public void testImageAssociationQueryByMediaIdAccountGuidOneMatch() {
		
		final String accountGuid = "accountGuid1";
		MediaId mediaId = new MediaId();
		mediaId.setAccountGuid(accountGuid);
		mediaId.setMediaGuid("mediaGuid");
		mediaId.setServiceGuid("serviceGuid");
		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getAccountGuid(), accountGuid);
		Query[] queries = new Query[] { new ByMediaIdAccountGuid(accountGuid) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");
		
		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}
	
	public void testImageAssociationQueryByMediaIdAccountGuidListOneMatch() {
		
		final String accountGuid1 = "accountGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setAccountGuid(accountGuid1);
		mediaId1.setMediaGuid("mediaGuid");
		mediaId1.setServiceGuid("serviceGuid");
		final String accountGuid2 = "accountGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setAccountGuid(accountGuid2);
		mediaId2.setMediaGuid("mediaGuid");
		mediaId2.setServiceGuid("serviceGuid");
		final String accountGuid3 = "accountGuid3";
		MediaId mediaId3 = new MediaId(); 
		mediaId3.setAccountGuid(accountGuid3);
		mediaId3.setMediaGuid("mediaGuid");
		mediaId3.setServiceGuid("serviceGuid");
		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId2)));
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getAccountGuid(), accountGuid1);
		
		Query[] queries = new Query[] { new ByMediaIdAccountGuid(Arrays.asList(accountGuid1, accountGuid3)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");
		
		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}
	
	public void testImageAssociationQueryByMediaIdAccountGuidMultipleMatch() {
		
		final String accountGuid1 = "accountGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setAccountGuid(accountGuid1);
		mediaId1.setMediaGuid("mediaGuid");
		mediaId1.setServiceGuid("serviceGuid");
		final String accountGuid2 = "accountGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setAccountGuid(accountGuid2);
		mediaId2.setMediaGuid("mediaGuid");
		mediaId2.setServiceGuid("serviceGuid");
		
		final ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		final ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId2)), new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getAccountGuid(), accountGuid1);
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getAccountGuid(), accountGuid1);
		
		Query[] queries = new Query[] { new ByMediaIdAccountGuid(accountGuid1) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");
		
		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);
		
		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}
	
	public void testImageAssociationQueryByMediaIdAccountGuidListMultipleMatch() {
		
		final String accountGuid1 = "accountGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setAccountGuid(accountGuid1);
		mediaId1.setMediaGuid("mediaGuid");
		mediaId1.setServiceGuid("serviceGuid");
		final String accountGuid2 = "accountGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setAccountGuid(accountGuid2);
		mediaId2.setMediaGuid("mediaGuid");
		mediaId2.setServiceGuid("serviceGuid");
		final String accountGuid3 = "accountGuid3";
		MediaId mediaId3 = new MediaId(); 
		mediaId3.setAccountGuid(accountGuid3);
		mediaId3.setMediaGuid("mediaGuid");
		mediaId3.setServiceGuid("serviceGuid");
		Assert.assertNotEquals(accountGuid1, accountGuid2);
		Assert.assertNotEquals(accountGuid3, accountGuid2);
		
		ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getAccountGuid(), accountGuid1);
		ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId2)), new String[] {});
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getAccountGuid(), accountGuid2);
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId3)));
		
		Query[] queries = new Query[] { new ByMediaIdAccountGuid(Arrays.asList(accountGuid1, accountGuid2)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");
		
		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);
		
		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}
	
	
	
	public void testImageAssociationQueryByMediaIdMediaGuidNoMatch() {
		
		final String mediaGuid = "mediaGuid";
		MediaId mediaId = new MediaId(); 
		mediaId.setMediaGuid(mediaGuid);
		mediaId.setAccountGuid("accountGuid");
		mediaId.setServiceGuid("serviceGuid");
		
		final ImageAssociation unexpected = this.imageAssociationClient.create(this.imageAssociationFactory.create( new DataServiceField(ImageAssociationField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(unexpected.getMediaId());
		Assert.assertEquals(unexpected.getMediaId().getMediaGuid(), mediaGuid);
		
		Query[] queries = new Query[] { new ByMediaIdMediaGuid(mediaGuid.concat("update")) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}
	
	public void testImageAssociationQueryByMediaIdMediaGuidListNoMatch() {
		final String mediaGuid1 = "mediaGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setMediaGuid(mediaGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setServiceGuid("serviceGuid");
		final String mediaGuid2 = "mediaGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setMediaGuid(mediaGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setServiceGuid("serviceGuid");
		final String mediaGuid3 = "mediaGuid3";
		MediaId mediaId3 = new MediaId(); 
		mediaId3.setMediaGuid(mediaGuid3);
		mediaId3.setAccountGuid("accountGuid");
		mediaId3.setServiceGuid("serviceGuid");
		
		final ImageAssociation unexpected1 = this.imageAssociationClient
				.create(this.imageAssociationFactory.create(
						new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		final ImageAssociation unexpected2 = this.imageAssociationClient
				.create(this.imageAssociationFactory.create(
						new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		Assert.assertNotNull(unexpected1.getMediaId());
		Assert.assertEquals(unexpected1.getMediaId().getMediaGuid(), mediaGuid1);
		Assert.assertNotNull(unexpected2.getMediaId());
		Assert.assertEquals(unexpected2.getMediaId().getMediaGuid(), mediaGuid1);
		
		
		Query[] queries = new Query[] { new ByMediaIdMediaGuid(Arrays.asList(mediaGuid3, mediaGuid2)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No ImageAssociation should be found");
	}
	
	public void testImageAssociationQueryByMediaIdMediaGuidOneMatch() {
		
		final String mediaGuid = "mediaGuid1";
		MediaId mediaId = new MediaId();
		mediaId.setMediaGuid(mediaGuid);
		mediaId.setAccountGuid("accountGuid");
		mediaId.setServiceGuid("serviceGuid");
		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getMediaGuid(), mediaGuid);
		Query[] queries = new Query[] { new ByMediaIdMediaGuid(mediaGuid) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");
		
		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}
	
	public void testImageAssociationQueryByMediaIdMediaGuidListOneMatch() {
		
		final String mediaGuid1 = "mediaGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setMediaGuid(mediaGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setServiceGuid("serviceGuid");
		final String mediaGuid2 = "mediaGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setMediaGuid(mediaGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setServiceGuid("serviceGuid");
		final String mediaGuid3 = "mediaGuid3";
		MediaId mediaId3 = new MediaId(); 
		mediaId3.setMediaGuid(mediaGuid3);
		mediaId3.setAccountGuid("accountGuid");
		mediaId3.setServiceGuid("serviceGuid");
		final ImageAssociation expected = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId2)));
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getMediaGuid(), mediaGuid1);
		
		Query[] queries = new Query[] { new ByMediaIdMediaGuid(Arrays.asList(mediaGuid1, mediaGuid3)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one ImageAssociation should be found");
		
		ImageAssociationComparator.assertEquals(results.getEntries().get(0), expected);
	}
	
	public void testImageAssociationQueryByMediaIdMediaGuidMultipleMatch() {
		
		final String mediaGuid1 = "mediaGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setMediaGuid(mediaGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setServiceGuid("serviceGuid");
		final String mediaGuid2 = "mediaGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setMediaGuid(mediaGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setServiceGuid("serviceGuid");
		
		final ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		final ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId2)), new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getMediaGuid(), mediaGuid1);
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getMediaGuid(), mediaGuid1);
		
		Query[] queries = new Query[] { new ByMediaIdMediaGuid(mediaGuid1) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");
		
		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);
		
		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}
	
	public void testImageAssociationQueryByMediaIdMediaGuidListMultipleMatch() {
		
		final String mediaGuid1 = "mediaGuid1";
		MediaId mediaId1 = new MediaId(); 
		mediaId1.setMediaGuid(mediaGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setServiceGuid("serviceGuid");
		final String mediaGuid2 = "mediaGuid2";
		MediaId mediaId2 = new MediaId(); 
		mediaId2.setMediaGuid(mediaGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setServiceGuid("serviceGuid");
		final String mediaGuid3 = "mediaGuid3";
		MediaId mediaId3 = new MediaId(); 
		mediaId3.setMediaGuid(mediaGuid3);
		mediaId3.setAccountGuid("accountGuid");
		mediaId3.setServiceGuid("serviceGuid");
		Assert.assertNotEquals(mediaGuid1, mediaGuid2);
		Assert.assertNotEquals(mediaGuid3, mediaGuid2);
		
		ImageAssociation expected1 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId1)), new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getMediaGuid(), mediaGuid1);
		ImageAssociation expected2 = this.imageAssociationClient.create(
				this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId2)), new String[] {});
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getMediaGuid(), mediaGuid2);
		this.imageAssociationClient.create(this.imageAssociationFactory.create(new DataServiceField(ImageAssociationField.mediaId, mediaId3)));
		
		Query[] queries = new Query[] { new ByMediaIdMediaGuid(Arrays.asList(mediaGuid1, mediaGuid2)) };
		Feed<ImageAssociation> results = this.imageAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two ImageAssociations should be found");
		
		Map<URI, ImageAssociation> resultMap = new HashMap<>();
		for (ImageAssociation ImageAssociation : results.getEntries())
			resultMap.put(ImageAssociation.getId(), ImageAssociation);
		
		ImageAssociationComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		ImageAssociationComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

}
