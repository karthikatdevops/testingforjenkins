package com.theplatform.data.tv.entity.integration.test.endpoint.credit;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.entity.api.client.query.credit.ByPersonType;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.PersonType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.OverrideField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.credit.ByProgramId;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.test.CreditComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author jethrolai
 * 
 */
@Test(groups = { "credit", "query" })
public class CreditQueryIT extends EntityTestBase {



	@Test(groups = { TestGroup.gbTest })
	public void testCreditQueryByProgramIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.creditClient.create(this.creditFactory.create(3, new DataServiceField(CreditField.programId, this.programClient.create(this.programFactory.create())
				.getId())));

		Long idToFind = URIUtils.getIdValue(this.programClient.create(this.programFactory.create()).getId());

		Query[] queries = new Query[] { new ByProgramId(idToFind) };
		Feed<Credit> results = this.creditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Credit should be found");

		List<Long> idsToFind = new ArrayList<Long>();
		idsToFind.add(idToFind);
		queries = new Query[] { new ByProgramId(idsToFind) };
		results = this.creditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Credit should be found");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testCreditQueryByProgramIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI programId1 = this.programClient.create(this.programFactory.create()).getId();
		final URI programId2 = this.programClient.create(this.programFactory.create()).getId();

		this.creditClient.create(this.creditFactory.create(3, new DataServiceField(CreditField.programId, programId1)));

		Long idToFind = URIUtils.getIdValue(programId2);

		Credit expectedCredit = this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.programId, programId2)), new String[] {});
		Query[] queries = new Query[] { new ByProgramId(idToFind) };
		Feed<Credit> results = this.creditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Credit should be found");
		CreditComparator.assertEquals(results.getEntries().get(0), expectedCredit);

		List<Long> idsToFind = new ArrayList<Long>();
		idsToFind.add(idToFind);
		queries = new Query[] { new ByProgramId(idsToFind) };
		results = this.creditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Credit should be found");

		CreditComparator.assertEquals(results.getEntries().get(0), expectedCredit);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testCreditQueryByProgramIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI programId1 = this.programClient.create(this.programFactory.create()).getId();
		final URI programId2 = this.programClient.create(this.programFactory.create()).getId();

		List<Long> idsToFind = new ArrayList<Long>();
		idsToFind.add(URIUtils.getIdValue(programId1));
		idsToFind.add(URIUtils.getIdValue(programId2));

		this.creditClient.create(this.creditFactory.create(3, new DataServiceField(CreditField.programId, programId1)));

		List<Credit> expectedCredits = this.creditClient.create(this.creditFactory.create(2, new DataServiceField(CreditField.programId, programId2)), new String[] {})
				.getEntries();
		Query[] queries = new Query[] { new ByProgramId(idsToFind.get(1)) };
		Feed<Credit> results = this.creditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Credits should be found");

		Map<URI, Credit> resultMap = new HashMap<URI, Credit>();
		for (Credit credit : results.getEntries()) {
			resultMap.put(credit.getId(), credit);
		}

		for (Credit expected : expectedCredits)
			CreditComparator.assertEquals(resultMap.get(expected.getId()), expected);

		queries = new Query[] { new ByProgramId(idsToFind) };
		results = this.creditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 5, "Exact 5 Credits should be found");

		resultMap = new HashMap<URI, Credit>();
		for (Credit credit : results.getEntries()) {
			resultMap.put(credit.getId(), credit);
		}

		for (Credit expected : expectedCredits)
			CreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}


    @Test(groups = { TestGroup.gbTest })
    public void testCreditQueryByPersonType() {

        Program program1 = this.programClient.create(this.programFactory.create());

        Person person1 = this.personClient.create(this.personFactory.create(new DataServiceField(PersonField.personType, PersonType.Person.getFriendlyName())));
        Person person2 = this.personClient.create(this.personFactory.create(new DataServiceField(PersonField.personType, PersonType.Band.getFriendlyName())));

        Credit credit1 = this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.personId, person1.getId()),
                new DataServiceField(CreditField.programId, program1.getId())));
        Credit credit2 = this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.personId, person2.getId()),
                new DataServiceField(CreditField.programId, program1.getId())));



        Query[] queries = new Query[] { new ByPersonType(PersonType.Person.toString()) };
        Feed<Credit> results = this.creditClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries(), Arrays.asList(credit1));

    }

}
