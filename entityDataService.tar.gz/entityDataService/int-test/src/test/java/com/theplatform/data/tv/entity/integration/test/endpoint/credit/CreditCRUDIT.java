package com.theplatform.data.tv.entity.integration.test.endpoint.credit;

import static org.testng.Assert.assertEquals;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.theplatform.data.tv.entity.api.data.objects.*;
import com.theplatform.data.tv.entity.api.test.PersonAssociationFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import com.theplatform.data.tv.entity.api.test.CreditComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

/**
 * Test case for CRUD operation of Credit endpoint
 * 
 * @since 4/7/2011
 */
@Test(groups = { "credit", "crud" })
public class CreditCRUDIT extends EntityTestBase {


	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(CreditField.type, null),
			new DataServiceField(CreditField.partName, null), new DataServiceField(CreditField.rank, null), new DataServiceField(CreditField.cameo, false),
			new DataServiceField(CreditField.active, true), new DataServiceField(CreditField.merlinResourceType, MerlinResourceType.AudienceAvailable) };


	@Test(groups = { TestGroup.gbTest })
	public void crudSingleCredit() throws UnknownHostException {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();

        Credit credit = this.creditFactory.create(
                new DataServiceField(CreditField.personId, personId),
                new DataServiceField(CreditField.programId, programId),
                new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                new DataServiceField(CreditField.program, programAssociationFactory.create(programId))
        );

		// CREATE
		Credit persistedCredit = this.creditClient.create(credit, new String[] {});

        CreditComparator.assertEquals(credit, persistedCredit);

		// RETRIEVE
		Credit retrievedCredit = this.creditClient.get(credit.getId(), new String[] {});
		CreditComparator.assertEquals(credit, retrievedCredit);

		// UPDATE
		if (credit.getType() == null)
			credit.setType("Voice");
		else
			credit.setType(credit.getType().equals("Director") ? "Actor" : "Actor");

		if (credit.getPartName() == null)
			credit.setPartName("credit partName");
		else
			credit.setPartName(credit.getPartName().equals("credit partName") ? "Austin Power" : "credit partName");

		if (credit.getRank() == null)
			credit.setRank(1);
		else
			credit.setRank(credit.getRank() == 1 ? 2 : 1);

		credit.setCameo(credit.getCameo() == false ? true : false);
		credit.setPersonId(this.personClient.create(this.personFactory.create()).getId());
		credit.setPerson(null);
		credit.setProgramId(this.programClient.create(this.programFactory.create()).getId());
		credit.setProgram(null);

		credit.setActive(credit.getActive() == false ? true : false);
		credit.setMainImages(new HashMap<String, MediaFile>());
		credit.setSelectedImages(new ArrayList<MainImageInfo>());
		credit.setMerlinResourceType(credit.getMerlinResourceType() == MerlinResourceType.AudienceAvailable ? MerlinResourceType.Editorial
				: MerlinResourceType.AudienceAvailable);

		this.creditClient.update(credit);

		// for now, it's of type program
		credit.setProgram(programAssociationFactory.create(credit.getProgramId()));
		credit.setPerson(personAssociationFactory.create(credit.getPersonId()));
		credit.setEntityId(credit.getProgramId());
		Credit retrievedAfterUpdate = this.creditClient.get(credit.getId(), new String[] {});
		CreditComparator.assertEquals(retrievedAfterUpdate, credit);

		// DELETE
		long deletedObjects = this.creditClient.delete(credit.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.creditClient.get(credit.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("Credit should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudCreditFeed() throws UnknownHostException {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();

		List<Credit> credits = this.creditFactory.create(5,
                new DataServiceField(CreditField.personId, personId),
                new DataServiceField(CreditField.programId, programId),
                new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                new DataServiceField(CreditField.program, programAssociationFactory.create(programId)));

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] creditIds = (URI[]) CollectionUtils.collect(credits, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<Credit> persistedCredits = this.creditClient.create(credits);
		ComparatorUtils.assertIdsAreEqual(credits, persistedCredits);

		// RETRIEVE
		Feed<Credit> retrievedCredits = this.creditClient.get(creditIds, new String[] {});
		CreditComparator.assertEquals(retrievedCredits, credits);

		// DELETE
		long deletedCredits = this.creditClient.delete(creditIds);
		Assert.assertEquals(deletedCredits, credits.size());

		long notFoundCredits = 0;
		for (Credit Credit : credits) {
			try {
				this.creditClient.get(Credit.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundCredits++;
			}
		}
		Assert.assertEquals(notFoundCredits, deletedCredits, "Still found Credits after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testCreditCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(creditClient,
                creditFactory.create(new DataServiceField(CreditField.personId, personId),
                        new DataServiceField(CreditField.programId, programId),
                        new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                        new DataServiceField(CreditField.program, programAssociationFactory.create(programId))),
                CreditComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testCreditCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
        URI programId = this.programClient.create(this.programFactory.create()).getId();
        URI personId = this.personClient.create(this.personFactory.create()).getId();
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(creditClient,
                creditFactory.create(new DataServiceField(CreditField.personId, personId),
                        new DataServiceField(CreditField.programId, programId),
                        new DataServiceField(CreditField.person, personAssociationFactory.create(personId)),
                        new DataServiceField(CreditField.program, programAssociationFactory.create(programId))),
                CreditComparator.class, this.defaultValues, null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testCreditUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(CreditField.type, "Actor"));
		createValues.add(new DataServiceField(CreditField.partName, "partName"));
		createValues.add(new DataServiceField(CreditField.rank, 2));
		createValues.add(new DataServiceField(CreditField.cameo, true));
		createValues.add(new DataServiceField(CreditField.active, false));
		createValues.add(new DataServiceField(CreditField.merlinResourceType, MerlinResourceType.Temporary));

        Credit credit = this.creditFactory.create();

		PersonAssociation personAssociation = personAssociationFactory.create(credit.getPersonId());
		ProgramAssociation programAssociation = programAssociationFactory.create(credit.getProgramId());

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(creditClient, credit, CreditComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] { new DataServiceField(CreditField.person, personAssociation),
						new DataServiceField(CreditField.program, programAssociation), new DataServiceField(CreditField.imageIds, new ArrayList<URI>()),
						new DataServiceField(CreditField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(CreditField.selectedImages, new ArrayList<MainImageInfo>()) });
	}
	
	//TODO MERLIN-XXXX need update
	@Test(groups = TestGroup.testBug)
	public void testCreditUpdateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(CreditField.type, "Actor"));
		createValues.add(new DataServiceField(CreditField.partName, "partName"));
		createValues.add(new DataServiceField(CreditField.rank, 2));
		createValues.add(new DataServiceField(CreditField.cameo, true));
		createValues.add(new DataServiceField(CreditField.active, false));
		createValues.add(new DataServiceField(CreditField.merlinResourceType, MerlinResourceType.Temporary));

		Credit credit = creditFactory.create();
		PersonAssociation personAssociation = personAssociationFactory.create(credit.getPersonId());
		ProgramAssociation programAssociation = programAssociationFactory.create(credit.getProgramId());

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(creditClient, credit, CreditComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] { new DataServiceField(CreditField.person, personAssociation),
						new DataServiceField(CreditField.program, programAssociation), new DataServiceField(CreditField.imageIds, new ArrayList<URI>()),
						new DataServiceField(CreditField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(CreditField.selectedImages, new ArrayList<MainImageInfo>()) });

	}

}
