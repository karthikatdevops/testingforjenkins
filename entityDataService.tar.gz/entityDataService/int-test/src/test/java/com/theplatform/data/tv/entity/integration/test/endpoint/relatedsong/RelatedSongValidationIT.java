package com.theplatform.data.tv.entity.integration.test.endpoint.relatedsong;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;

import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.fields.RelatedSongField;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.TestNGDataProviderUtil;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "relatedSong", "validation" })
public class RelatedSongValidationIT extends EntityTestBase {

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateNullSourceSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.sourceSongId, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateNonpersistedSourceSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.sourceSongId, this.songFactory.create().getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateNonLocalSourceSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localSongId = this.songClient.create(this.songFactory.create()).getId();

		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.sourceSongId, this.songFactory.create(
				new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9003/linearDataService/data/Song/" + URIUtils.getIdValue(localSongId)))).getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateNullTargetSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.targetSongId, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateNonpersistedTargetSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.targetSongId, this.songFactory.create().getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateNonLocalTargetSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localSongId = this.songClient.create(this.songFactory.create()).getId();

		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.targetSongId, this.songFactory.create(
				new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9003/linearDataService/data/Song/" + URIUtils.getIdValue(localSongId)))).getId())));
	}

	// Type validation

	public void testRelatedSongCreateValidType() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.type, "IsSimilar")));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateNullType() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.type, null)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "invalidTypes")
	public void testRelatedSongCreateInvalidType(String invalidType) throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.type, invalidType)));
	}

	@DataProvider
	public Object[][] invalidTypes() {
		return TestNGDataProviderUtil.generateDataProvider(new Object[] { "invalidtype" }, new Object[] { "" }, new Object[] { "ISSIMILAR" },
				new Object[] { "isSimilar" });
	}

	// rank validation
	public void testRelatedSongCreatePositiveRank() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.rank, 1)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateNegativeRank() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.rank, -1)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateZeroRank() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedSongClient.create(this.relatedSongFactory.create(new DataServiceField(RelatedSongField.rank, 0)));
	}

	// sourceSongId, sourceSongId, type uniqueness
	//uniqueness constraint removed to allow editorial objects
	//@Test(expectedExceptions = ValidationException.class)
	public void testRelatedSongCreateWithSameSourceSongIdTargetSongIdAndType() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI sourceSongId = songClient.create(songFactory.create()).getId();
		URI targetSongId = songClient.create(songFactory.create()).getId();
		final String type = "IsSimilar";
		this.relatedSongClient.create(this.relatedSongFactory.create(2, new DataServiceField(RelatedSongField.sourceSongId, sourceSongId), new DataServiceField(
				RelatedSongField.targetSongId, targetSongId), new DataServiceField(RelatedSongField.type, type)));
	}

	public void testRelatedSongCreateWithDifferentSourceSongIdSameTargetSongIdAndType() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI targetSongId = songClient.create(songFactory.create()).getId();
		final String type = "IsSimilar";
		this.relatedSongClient
				.create(this.relatedSongFactory.create(2, new DataServiceField(RelatedSongField.targetSongId, targetSongId), new DataServiceField(RelatedSongField.type, type)));
	}

	public void testRelatedSongCreateWithDifferentTargetSongIdSameSourceSongIdAndType() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI sourceSongId = songClient.create(songFactory.create()).getId();
		final String type = "IsSimilar";
		this.relatedSongClient
				.create(this.relatedSongFactory.create(2, new DataServiceField(RelatedSongField.sourceSongId, sourceSongId), new DataServiceField(RelatedSongField.type, type)));
	}

	// only one valid type, so no different type test

}
