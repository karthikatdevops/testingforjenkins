package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagetype;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.test.MainImageTypeComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.module.exception.BadParameterException;

/**
 * User: gservente
 * 
 * Basic Sort tests for MainImageType
 */
@Test(groups = { "mainImageType", "sort", "other" })
public class MainTypeFileSortIT extends EntityTestBase {


	private static final int IMAGE_ASSOACIATIONS_TO_CREATE = 4;
	private List<MainImageType> mainImageTypes;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		this.mainImageTypes = this.mainImageTypeFactory.create(IMAGE_ASSOACIATIONS_TO_CREATE);
		this.mainImageTypeClient.create(mainImageTypes);

	}


	@Test(groups = TestGroup.testBug)
	public void testSortAscendingMainImageTypeByGuid() throws UnknownHostException {
		// UPDATE VALUES
		this.mainImageTypes.get(3).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/123"));
		this.mainImageTypes.get(0).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/222"));
		this.mainImageTypes.get(2).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/1311"));
		this.mainImageTypes.get(1).setOwnerId(URI.create("http://access.auth.test.corp.theplatform.com/access/data/Account/1531"));

		this.mainImageTypeClient.update(this.mainImageTypes);

		// SORT EXPECTED
		List<MainImageType> expectedSortedImageAssociations = new ArrayList<>(mainImageTypes.size());
		expectedSortedImageAssociations.add(this.mainImageTypes.get(3));
		expectedSortedImageAssociations.add(this.mainImageTypes.get(0));
		expectedSortedImageAssociations.add(this.mainImageTypes.get(2));
		expectedSortedImageAssociations.add(this.mainImageTypes.get(1));

		// RETRIVE WHITH SORTING
		String sortFiedld = "ownerId";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<MainImageType> retrievedImageAssociations = this.mainImageTypeClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null,
				false);

		MainImageTypeComparator.assertMainImageTypesEqual(retrievedImageAssociations, expectedSortedImageAssociations);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableField() throws UnknownHostException {
		// RETRIVE WHITH SORTING
		String sortField = "height";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortField, sortDescending);
		this.mainImageTypeClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
	}
}
