package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagetypegroup;

import java.lang.reflect.InvocationTargetException;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageTypeGroup;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "mainImageTypeGroup", "validation" })
public class MainImageTypeGroupValidationIT extends EntityTestBase {



	//MERLIN-8963 disabled because this constraint has been relaxed for Editorial work
	@Test(groups = TestGroup.notImplemented, expectedExceptions = ValidationException.class)
	public void testMainImageTypeGroupCreateWithRepeatingTitle() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		MainImageTypeGroup mainImageTypeGroup = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(), new String[]{"title"});
		this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(new DataServiceField(DataObjectField.title, mainImageTypeGroup.getTitle())));
	}
	
	//MERLIN-8963 disabled because this constraint has been relaxed for Editorial work
	@Test(groups = TestGroup.notImplemented, expectedExceptions = ValidationException.class)
	public void testMainImageTypeGroupUpdateWithRepeatingTitle() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		
		MainImageTypeGroup mainImageTypeGroup1 = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(), new String[]{});
		MainImageTypeGroup mainImageTypeGroup2 = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(), new String[]{});
		mainImageTypeGroup2.setTitle(mainImageTypeGroup1.getTitle());
		this.mainImageTypeGroupClient.update(mainImageTypeGroup2);
	}

}
