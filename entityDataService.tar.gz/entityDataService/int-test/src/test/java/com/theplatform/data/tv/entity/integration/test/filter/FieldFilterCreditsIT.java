package com.theplatform.data.tv.entity.integration.test.filter;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.field.NamespacedFieldInfo;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.MerlinTestReflectionUtil;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.fields.CreditAssociationField;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.test.CreditAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.ArrayList;

@Test(groups = {"fieldFilter", TestGroup.gbTest})
public class FieldFilterCreditsIT extends EntityTestBase {

    private static NamespacedFieldInfo[] ALL_CREDITASSOCIATION_FIELDINFOS = {
            new NamespacedFieldInfo(CreditAssociationField.type, "type"),
            new NamespacedFieldInfo(CreditAssociationField.rank, "rank"),
            new NamespacedFieldInfo(CreditAssociationField.partName, "partName"),
            new NamespacedFieldInfo(CreditAssociationField.cameo, "cameo"),
            new NamespacedFieldInfo(CreditAssociationField.programId, "programId"),
            new NamespacedFieldInfo(CreditAssociationField.personName, "personName"),
            new NamespacedFieldInfo(CreditAssociationField.personId, "personId"),
            new NamespacedFieldInfo(CreditAssociationField.programTitle, "programTitle"),
            new NamespacedFieldInfo(CreditAssociationField.creditId, "creditId"),
            new NamespacedFieldInfo(CreditAssociationField.programYear, "programYear")};

    public void testGetCreditsSingleField() {
        Program program = programClient.create(programFactory.create(new DataServiceField(ProgramField.year, 1970),
                new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>())), new String[]{});
        Person person = personClient.create(personFactory.create(), new String[]{});

        Credit inputCredit = creditFactory.create(CreditField.programId, program.getId(),
                CreditField.personId, person.getId());
        inputCredit.setType("Actor");
        inputCredit.setRank(1);
        inputCredit.setPartName("credit partName");
        inputCredit.setActive(true);
        Credit credit = creditClient.create(inputCredit, new String[]{});

        CreditAssociation expected = makeNewCreditAssociation(credit, program, person);
        for (NamespacedFieldInfo fieldInfo : ALL_CREDITASSOCIATION_FIELDINFOS)
            Assert.assertNotNull(MerlinTestReflectionUtil.get(expected, fieldInfo.getFieldName()));

        final URI programId = program.getId();
        final URI personId = person.getId();

        for (NamespacedFieldInfo field : ALL_CREDITASSOCIATION_FIELDINFOS) {

            program = programClient.get(programId, new String[]{"credits", field.getField().getLocalName()});
            Assert.assertNotNull(program.getCredits());
            Assert.assertEquals(program.getCredits().size(), 1);
            Assert.assertNotNull(program.getCredits().get(0));
            Assert.assertEquals(MerlinTestReflectionUtil.get(program.getCredits().get(0), field.getFieldName()),
                    MerlinTestReflectionUtil.get(expected, field.getFieldName()));

            person = personClient.get(personId, new String[]{"credits", field.getField().getLocalName()});
            Assert.assertNotNull(person.getCredits());
            Assert.assertEquals(person.getCredits().size(), 1);
            Assert.assertNotNull(person.getCredits().get(0));
            Assert.assertEquals(MerlinTestReflectionUtil.get(person.getCredits().get(0), field.getFieldName()),
                    MerlinTestReflectionUtil.get(expected, field.getFieldName()));

            program = programClient.get(programId, new String[]{"credits", field.getField().getQualifiedName()});
            Assert.assertNotNull(program.getCredits());
            Assert.assertEquals(program.getCredits().size(), 1);
            Assert.assertNotNull(program.getCredits().get(0));
            Assert.assertEquals(MerlinTestReflectionUtil.get(program.getCredits().get(0), field.getFieldName()),
                    MerlinTestReflectionUtil.get(expected, field.getFieldName()));

            person = personClient.get(personId, new String[]{"credits", field.getField().getQualifiedName()});
            Assert.assertNotNull(person.getCredits());
            Assert.assertEquals(person.getCredits().size(), 1);
            Assert.assertNotNull(person.getCredits().get(0));
            Assert.assertEquals(MerlinTestReflectionUtil.get(person.getCredits().get(0), field.getFieldName()),
                    MerlinTestReflectionUtil.get(expected, field.getFieldName()));
        }
    }

    public void testGetFullCreditsNoParameter() {
        testGetFullCredits(null, null);
    }

    public void testGetFullCreditsWithCreditsParameter() {
        testGetFullCredits(new String[]{ProgramField.credits.getLocalName()}, new String[]{PersonField.credits.getLocalName()});
    }

    public void testGetFullCreditsWithFullyQualifiedCreditsParameter() {
        testGetFullCredits(new String[]{ProgramField.credits.getQualifiedName()}, new String[]{PersonField.credits.getQualifiedName()});
    }

    private void testGetFullCredits(String[] getProgramParameters, String[] getPersonParameters) {
		Program program = programClient.create(programFactory.create(new DataServiceField(ProgramField.year, 1970),
                new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>())), new String[] {});
		Person person = personClient.create(personFactory.create(), new String[] {});

        Credit inputCredit = creditFactory.create(CreditField.programId, program.getId(),
                CreditField.personId, person.getId());
        inputCredit.setType("Actor");
        inputCredit.setRank(1);
        inputCredit.setPartName("credit partName");
        inputCredit.setActive(true);
        Credit credit = creditClient.create(inputCredit, new String[]{});

        CreditAssociation expected = makeNewCreditAssociation(credit, program, person);
        for (NamespacedFieldInfo fieldInfo : ALL_CREDITASSOCIATION_FIELDINFOS)
            Assert.assertNotNull(MerlinTestReflectionUtil.get(expected, fieldInfo.getFieldName()));

        getProgramParameters = getProgramParameters == null ? new String[]{} : getProgramParameters;
        getPersonParameters = getPersonParameters == null ? new String[]{} : getPersonParameters;
        program = programClient.get(program.getId(), getProgramParameters);
        Assert.assertNotNull(program.getCredits());
        Assert.assertEquals(program.getCredits().size(), 1);
        Assert.assertNotNull(program.getCredits().get(0));
        CreditAssociationComparator.assertEquals(program.getCredits().get(0), expected);

        person = personClient.get(person.getId(), getPersonParameters);
        Assert.assertNotNull(person.getCredits());
        Assert.assertEquals(person.getCredits().size(), 1);
        Assert.assertNotNull(person.getCredits().get(0));
        CreditAssociationComparator.assertEquals(person.getCredits().get(0), expected);
    }

    private CreditAssociation makeNewCreditAssociation(Credit credit, Program program, Person person) {
        Assert.assertNotNull(program.getId());
        Assert.assertNotNull(credit.getPersonId());
        Assert.assertNotNull(credit.getId());

        CreditAssociation creditAssociation = new CreditAssociation();
        creditAssociation.setType(credit.getType());
        creditAssociation.setRank(credit.getRank());
        creditAssociation.setPartName(credit.getPartName());
        creditAssociation.setCameo(credit.getCameo());
        creditAssociation.setProgramId(program.getId());
        creditAssociation.setPersonName(person.getName());
        creditAssociation.setPersonId(credit.getPersonId());
        creditAssociation.setProgramTitle(program.getTitle());
        creditAssociation.setCreditId(credit.getId());
        creditAssociation.setProgramYear(program.getYear());

        return creditAssociation;
    }
}
