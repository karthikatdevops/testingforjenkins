package com.theplatform.data.tv.entity.integration.test.endpoint.entitymessage;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.EntityMessage;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.fields.EntityMessageField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;
import org.testng.annotations.Test;

import java.net.URI;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/23/15
 */
@Test(groups = {"entitymessage", "validation", TestGroup.gbTest})
public class EntityMessageValidationIT extends EntityTestBase {

    @Test(expectedExceptions = ValidationException.class)
    public void creatingAnEntityWithANonProgramIdShouldThrowAnException() {
        Song rawSong = songFactory.create();
        Song song = songClient.create(rawSong);
        URI songId = song.getId();

        EntityMessage v1 = entityMessageFactory.create(new DataServiceField(EntityMessageField.entityId, songId));
        entityMessageClient.create(v1);
    }
}

