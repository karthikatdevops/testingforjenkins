package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.fail;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.test.api.data.factory.SeriesMasterProgramFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.client.ClientUtils;
import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.EditorialObjectState;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMetadataManagementInfo;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;

/**
 * User: llowenthal Date: 23/06/2010 Basic CRUD tests for Program
 * 
 * @author Jet
 * @since 4/7/2011
 */
@Test(groups = { "program", "crud" })
public class ProgramCRUDIT extends EntityTestBase {



	@Test(groups = { TestGroup.gbTest })
	public void crudSingleProgram() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));

		// CREATE
		Program persistedProgram = this.programClient.create(program);
		assertEquals(persistedProgram.getId(), program.getId(), "Program ids should match after creation");

		// RETRIEVE
		Program retrievedProgram = this.programClient.get(program.getId(), new String[] {});
		ProgramComparator.assertEquals(retrievedProgram, program);

		// UPDATE
		// TODO update all fields possible
		program.setTitle(program.getTitle() + " - changed");
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());

		Program retrievedAfterUpdate = this.programClient.get(program.getId(), new String[] {});
		ProgramComparator.assertEquals(retrievedAfterUpdate, program);
		assertFalse(retrievedProgram.getTitle().equals(retrievedAfterUpdate.getTitle()));

		// DELETE
		long deletedObjects = this.programClient.delete(program.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.programClient.get(program.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("Program should not be found after deleting it");
	}

	@Test(groups = { TestGroup.gbTest })
	public void crudSingleMovie() throws UnknownHostException, URISyntaxException {
        Program movie = this.movieProgramFactory.create(new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));

		// CREATE
		Program persistedMovie = this.programClient.create(movie);
		assertEquals(persistedMovie.getId(), movie.getId(), "Program ids should match after creation");

		// RETRIEVE
		Program retrievedMovie = this.programClient.get(movie.getId(), new String[] {});
		ProgramComparator.assertEquals(retrievedMovie, movie);

		// UPDATE
		movie.setTitle(movie.getTitle() + " - changed");
		movie.getReleaseDate().setYear(movie.getReleaseDate().getYear() + 25);
		movie.setImageIds(null);
		movie.setTagIds(null);
		movie.setSelectedImages(null);
		movie.setCredits(null);
		programClient.update(movie);
		movie.setImageIds(new ArrayList<URI>());
		movie.setTagIds(new ArrayList<URI>());
		movie.setSelectedImages(new ArrayList<MainImageInfo>());
		movie.setCredits(new ArrayList<CreditAssociation>());

		Program retrievedAfterUpdate = this.programClient.get(movie.getId(), new String[] {});
		ProgramComparator.assertEquals(retrievedAfterUpdate, movie);
		assertFalse(retrievedMovie.getTitle().equals(retrievedAfterUpdate.getTitle()));
		assertFalse(retrievedMovie.getReleaseDate().equals(retrievedAfterUpdate.getReleaseDate()));

		// DELETE
		long deletedObjects = this.programClient.delete(movie.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.programClient.get(movie.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("Movie should not be found after deleting it");
	}

	@Test(groups = { TestGroup.gbTest })
	public void crudSingleSeries() throws UnknownHostException, URISyntaxException {
		Program series = this.seriesMasterProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster));

		// CREATE
		Program persistedSeries = this.programClient.create(series);
		assertEquals(persistedSeries.getId(), series.getId(), "Program ids should match after creation");

		// RETRIEVE
		Program retrievedSeries = this.programClient.get(series.getId(), new String[] {});
		ProgramComparator.assertEquals(retrievedSeries, series);

		// UPDATE
		series.setTitle(series.getTitle() + " - changed");
		series.getLastAirDate().setYear(series.getFirstAirDate().getYear() + 25);
		series.setImageIds(null);
		series.setTagIds(null);
		series.setSelectedImages(null);
		series.setCredits(null);
		programClient.update(series);
		series.setImageIds(new ArrayList<URI>());
		series.setTagIds(new ArrayList<URI>());
		series.setSelectedImages(new ArrayList<MainImageInfo>());
		series.setCredits(new ArrayList<CreditAssociation>());

		Program retrievedAfterUpdate = this.programClient.get(series.getId(), new String[] {});
		ProgramComparator.assertEquals(retrievedAfterUpdate, series);
		assertFalse(retrievedSeries.getTitle().equals(retrievedAfterUpdate.getTitle()));
		assertFalse(retrievedSeries.getLastAirDate().equals(retrievedAfterUpdate.getLastAirDate()));

		// DELETE
		long deletedObjects = this.programClient.delete(series.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.programClient.get(series.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("Series should not be found after deleting it");
	}

	@Test(groups = { TestGroup.gbTest })
	public void crudSingleEpisode() throws UnknownHostException, URISyntaxException {
        Program episode = this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.seriesEpisodeNumber, 1),
                new DataServiceField(ProgramField.episodeTitle, "title"));

		// CREATE
		Program persistedEpisode = this.programClient.create(episode);
		assertEquals(persistedEpisode.getId(), episode.getId(), "Program ids should match after creation");

		// RETRIEVE
		Program retrievedEpisode = this.programClient.get(episode.getId(), new String[] {});
		ProgramComparator.assertEquals(retrievedEpisode, episode);

		// UPDATE
		episode.setTitle(episode.getTitle() + " - changed");
		episode.setSeriesEpisodeNumber(episode.getSeriesEpisodeNumber() + 18);
		episode.setEpisodeTitle("another " + episode.getEpisodeTitle());
		episode.setImageIds(null);
		episode.setTagIds(null);
		episode.setSelectedImages(null);
		episode.setCredits(null);
		programClient.update(episode);
		episode.setImageIds(new ArrayList<URI>());
		episode.setTagIds(new ArrayList<URI>());
		episode.setSelectedImages(new ArrayList<MainImageInfo>());
		episode.setCredits(new ArrayList<CreditAssociation>());

		Program retrievedAfterUpdate = this.programClient.get(episode.getId(), new String[] {});
		ProgramComparator.assertEquals(retrievedAfterUpdate, episode);
		assertFalse(retrievedEpisode.getTitle().equals(retrievedAfterUpdate.getTitle()));
		assertFalse(retrievedEpisode.getSeriesEpisodeNumber().equals(retrievedAfterUpdate.getSeriesEpisodeNumber()));
		assertFalse(retrievedEpisode.getEpisodeTitle().equals(retrievedAfterUpdate.getEpisodeTitle()));

		// DELETE
		long deletedObjects = this.programClient.delete(episode.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.programClient.get(episode.getId(), new String[] {});
			fail("Episode should not be found after deleting it");
		} catch (ObjectNotFoundException e) {
			// expected
		}

	}

	// added based on bug MERLIN-1559
	// modfied and name of test altered based on MERLIN-6095
	@Test(groups = TestGroup.bug)
	public void crudSingleProgramMmiValues() {
		Program program = this.programFactory.create();

		ProgramMetadataManagementInfo mmInfo = new ProgramMetadataManagementInfo();
		mmInfo.setEditorialObjectId(4611686096790677112L);
	    mmInfo.setEditorialObjectState(EditorialObjectState.ReviewedApproved);

		program.setMetadataManagementInfo(mmInfo);
//		program.setOwnerId(URI.create(this.getOwnerId()));

		// CREATE
		ClientUtils.getAll(this.programClient);
		Program persistedProgram = this.programClient.create(program);
		assertEquals(persistedProgram.getId(), program.getId(), "Program ids should match after creation");

		// RETRIEVE
		Program retrievedProgram = this.programClient.get(program.getId(), new String[] {});
		assertEquals(retrievedProgram.getMetadataManagementInfo().getEditorialObjectId().longValue(), 4611686096790677112L);
		assertEquals(retrievedProgram.getMetadataManagementInfo().getEditorialObjectState(), EditorialObjectState.ReviewedApproved);

		// UPDATE the program using create call
		Program programToUpdate = new Program();
		programToUpdate.setId(program.getId());
		programToUpdate.setGuid(program.getGuid());
		programToUpdate.setOwnerId(program.getOwnerId());
		programToUpdate.setTitle(program.getTitle() + " - changed");
		programToUpdate.setType(program.getType());
		this.programClient.create(programToUpdate);

		Program retrievedAfterUpdate = this.programClient.get(program.getId(), new String[] {});
		// comparator.assertProgramEqual(retrievedAfterUpdate, program);
		assertFalse(retrievedProgram.getTitle().equals(retrievedAfterUpdate.getTitle()));
		assertEquals(retrievedProgram.getMetadataManagementInfo().getEditorialObjectId().longValue(), 4611686096790677112L);
        assertEquals(retrievedProgram.getMetadataManagementInfo().getEditorialObjectState(), EditorialObjectState.ReviewedApproved);
	}

	@Test(groups = TestGroup.testBug)
	public void crudSingleProgramMmiSpecificValues() {
		Program program = this.programFactory.create();

		ProgramMetadataManagementInfo mmInfo = new ProgramMetadataManagementInfo();
		mmInfo.setEditorialObjectId(4611686096790677112L);
	    mmInfo.setEditorialObjectState(EditorialObjectState.ReviewedApproved);
	    mmInfo.setTitlePaid("A TitlePaid");

		program.setMetadataManagementInfo(mmInfo);
//		program.setOwnerId(URI.create(this.getOwnerId()));

		// CREATE
		Program persistedProgram = this.programClient.create(program);
		assertEquals(persistedProgram.getId(), program.getId(), "Program ids should match after creation");

		// RETRIEVE
		Program retrievedProgram = this.programClient.get(program.getId(), new String[] {});
		assertEquals(retrievedProgram.getMetadataManagementInfo().getEditorialObjectId().longValue(), 4611686096790677112L);
		assertEquals(retrievedProgram.getMetadataManagementInfo().getEditorialObjectState(), EditorialObjectState.ReviewedApproved);

		// UPDATE the program using create call
		Program programToUpdate = new Program();
		programToUpdate.setId(program.getId());
		programToUpdate.setGuid(program.getGuid());
		programToUpdate.setOwnerId(program.getOwnerId());
		programToUpdate.setTitle(program.getTitle() + " - changed");
		programToUpdate.setType(program.getType());
		this.programClient.create(programToUpdate);

		Program retrievedAfterUpdate = this.programClient.get(program.getId(), new String[] {});
		// comparator.assertProgramEqual(retrievedAfterUpdate, program);
		assertFalse(retrievedProgram.getTitle().equals(retrievedAfterUpdate.getTitle()));
		assertEquals(retrievedProgram.getMetadataManagementInfo().getEditorialObjectId().longValue(), 4611686096790677112L);
        assertEquals(retrievedProgram.getMetadataManagementInfo().getEditorialObjectState(), EditorialObjectState.ReviewedApproved);
        assertEquals(retrievedProgram.getMetadataManagementInfo().getTitlePaid(), mmInfo.getTitlePaid());
	}

	
	public void crudProgramFeed() throws UnknownHostException {
		List<Program> programs = this.programFactory.create(5, new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		@SuppressWarnings({ "unchecked" })
		URI[] programIds = (URI[]) CollectionUtils.collect(programs, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<Program> persistedPrograms = this.programClient.create(programs);
		ComparatorUtils.assertIdsAreEqual(programs, persistedPrograms.getEntries());

		
		// RETRIEVE
		Feed<Program> retrievedPrograms = this.programClient.get(programIds, new String[] {});
		ProgramComparator.assertEquals(retrievedPrograms, programs);

		// DELETE
		long deletedPrograms = this.programClient.delete(programIds);
		assertEquals(deletedPrograms, programs.size());

		long notFoundPrograms = 0;
		for (Program program : programs) {
			try {
				this.programClient.get(program.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundPrograms++;
			}
		}
		assertEquals(notFoundPrograms, deletedPrograms, "Still found programs after deleting");
	}

	public void createCanAcceptAnEmptyFeed() throws UnknownHostException {
		@SuppressWarnings("unchecked")
		List<Program> programs = Collections.EMPTY_LIST;

		Feed<Program> persistedPrograms = this.programClient.create(programs);
//		assertEquals(persistedPrograms.getEntryCount(), (Long) 0L);
		assertEquals(persistedPrograms.getEntries().size(), 0);
	}

}
