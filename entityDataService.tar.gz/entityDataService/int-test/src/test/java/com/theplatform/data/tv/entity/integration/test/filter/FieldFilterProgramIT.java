package com.theplatform.data.tv.entity.integration.test.filter;

import java.net.URI;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.field.NamespacedFieldInfo;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.MerlinTestReflectionUtil;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.ProgramRankField;
import com.theplatform.data.tv.entity.api.fields.RelatedProgramField;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "fieldFilter", TestGroup.gbTest })
public class FieldFilterProgramIT extends EntityTestBase {

	private static NamespacedFieldInfo[] EMBEDDED_PROGRAM_FIELDINFOS = { new NamespacedFieldInfo(DataObjectField.id, "id"),
			new NamespacedFieldInfo(DataObjectField.title, "title"), new NamespacedFieldInfo(ProgramField.year, "year"),
			new NamespacedFieldInfo(ProgramField.shortSynopsis, "shortSynopsis"), new NamespacedFieldInfo(ProgramField.mediumSynopsis, "mediumSynopsis"),
			new NamespacedFieldInfo(ProgramField.longSynopsis, "longSynopsis"), new NamespacedFieldInfo(ProgramField.runtime, "runtime"),
			new NamespacedFieldInfo(ProgramField.type, "type"), new NamespacedFieldInfo(ProgramField.language, "language"),
			new NamespacedFieldInfo(ProgramField.partNumber, "partNumber"), new NamespacedFieldInfo(ProgramField.totalParts, "totalParts"),
			new NamespacedFieldInfo(ProgramField.releaseDate, "releaseDate"), new NamespacedFieldInfo(ProgramField.starRating, "starRating"),
			new NamespacedFieldInfo(ProgramField.seriesId, "seriesId"), new NamespacedFieldInfo(ProgramField.tvSeasonId, "tvSeasonId"),
			new NamespacedFieldInfo(ProgramField.originalAirDate, "originalAirDate"),
			new NamespacedFieldInfo(ProgramField.tvSeasonEpisodeNumber, "tvSeasonEpisodeNumber"),
			new NamespacedFieldInfo(ProgramField.seriesEpisodeNumber, "seriesEpisodeNumber"),
			new NamespacedFieldInfo(ProgramField.firstAirDate, "firstAirDate"), new NamespacedFieldInfo(ProgramField.lastAirDate, "lastAirDate") };

	public void testGetFullRelatedProgramTargetProgramNoParameter() {
		Program targetProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		RelatedProgram relatedProgram = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.targetProgramId, targetProgram.getId())), new String[] {});

		Program expected = this.getRelatedProgramTargetProgram(targetProgram);

		ProgramComparator.assertEquals(relatedProgram.getTargetProgram(), expected);

	}

	public void testGetFullRelatedProgramSourceProgramNoParameter() {
		Program sourceProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		RelatedProgram relatedProgram = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.sourceProgramId, sourceProgram.getId())), new String[] {});

		Program expected = this.getRelatedProgramSourceProgram(sourceProgram);

		ProgramComparator.assertEquals(relatedProgram.getSourceProgram(), expected);

	}

	public void testGetFullProgramRankProgramNoParameter() {
		Program program = this.programClient.create(this.programFactory.create(), new String[] {});

		ProgramRank programRank = this.programRankClient.create(
				this.programRankFactory.create(new DataServiceField(ProgramRankField.programId, program.getId())), new String[] {});

		Program expected = this.getProgramRankProgram(program);

		ProgramComparator.assertEquals(programRank.getProgram(), expected);

	}

	public void testGetFullRelatedProgramTargetProgramWithTargetProgramParameter() {
		Program targetProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		RelatedProgram relatedProgram = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.targetProgramId, targetProgram.getId())),
				new String[] { RelatedProgramField.targetProgram.getLocalName() });

		Program expected = this.getRelatedProgramTargetProgram(targetProgram);

		ProgramComparator.assertEquals(relatedProgram.getTargetProgram(), expected);

	}

	public void testGetFullRelatedProgramSourceProgramWithSourceProgramParameter() {
		Program sourceProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		RelatedProgram relatedProgram = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.sourceProgramId, sourceProgram.getId())),
				new String[] { RelatedProgramField.sourceProgram.getLocalName() });

		Program expected = this.getRelatedProgramSourceProgram(sourceProgram);

		ProgramComparator.assertEquals(relatedProgram.getSourceProgram(), expected);

	}

	public void testGetFullProgramRankProgramWithProgramParameter() {
		Program program = this.programClient.create(this.programFactory.create(), new String[] {});

		ProgramRank programRank = this.programRankClient.create(
				this.programRankFactory.create(new DataServiceField(ProgramRankField.programId, program.getId())),
				new String[] { ProgramRankField.program.getLocalName() });

		Program expected = this.getProgramRankProgram(program);

		ProgramComparator.assertEquals(programRank.getProgram(), expected);

	}

	public void testGetFullRelatedProgramTargetProgramWithTargetProgramQualifiedParameter() {
		Program targetProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		RelatedProgram relatedProgram = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.targetProgramId, targetProgram.getId())),
				new String[] { RelatedProgramField.targetProgram.getQualifiedName() });

		Program expected = this.getRelatedProgramTargetProgram(targetProgram);

		ProgramComparator.assertEquals(relatedProgram.getTargetProgram(), expected);

	}

	public void testGetFullRelatedProgramSourceProgramWithSourceProgramQualifiedParameter() {
		Program sourceProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		RelatedProgram relatedProgram = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.sourceProgramId, sourceProgram.getId())),
				new String[] { RelatedProgramField.sourceProgram.getQualifiedName() });

		Program expected = this.getRelatedProgramSourceProgram(sourceProgram);

		ProgramComparator.assertEquals(relatedProgram.getSourceProgram(), expected);

	}

	public void testGetFullProgramRankProgramWithProgramQualifiedParameter() {
		Program program = this.programClient.create(this.programFactory.create(), new String[] {});

		ProgramRank programRank = this.programRankClient.create(
				this.programRankFactory.create(new DataServiceField(ProgramRankField.programId, program.getId())),
				new String[] { ProgramRankField.program.getQualifiedName() });

		Program expected = this.getProgramRankProgram(program);

		ProgramComparator.assertEquals(programRank.getProgram(), expected);

	}

	public void testGetRelatedProgramTargetProgramSingleFieldWithTargetProgramParameter() {
		Program targetProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		URI relatedProgramId = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.targetProgramId, targetProgram.getId()))).getId();
		Program actual = null;
		for (NamespacedFieldInfo fieldInfo : EMBEDDED_PROGRAM_FIELDINFOS) {
			Program expected = new Program();
			MerlinTestReflectionUtil.set(expected, fieldInfo.getField(), MerlinTestReflectionUtil.get(targetProgram, fieldInfo.getField()));
			actual = this.relatedProgramClient.get(relatedProgramId,
					new String[] { RelatedProgramField.targetProgram.getLocalName(), fieldInfo.getField().getLocalName() }).getTargetProgram();
			Assert.assertEquals(MerlinTestReflectionUtil.get(actual, fieldInfo.getFieldName()),
					MerlinTestReflectionUtil.get(expected, fieldInfo.getFieldName()));
		}

	}

	public void testGetRelatedProgramSourceProgramSingleFieldWithSourceProgramParameter() {
		Program sourceProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		URI relatedProgramId = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.sourceProgramId, sourceProgram.getId()))).getId();
		Program actual = null;
		for (NamespacedFieldInfo fieldInfo : EMBEDDED_PROGRAM_FIELDINFOS) {
			Program expected = new Program();
			MerlinTestReflectionUtil.set(expected, fieldInfo.getField(), MerlinTestReflectionUtil.get(sourceProgram, fieldInfo.getField()));
			actual = this.relatedProgramClient.get(relatedProgramId,
					new String[] { RelatedProgramField.sourceProgram.getLocalName(), fieldInfo.getField().getLocalName() }).getSourceProgram();
			Assert.assertEquals(MerlinTestReflectionUtil.get(actual, fieldInfo.getFieldName()),
					MerlinTestReflectionUtil.get(expected, fieldInfo.getFieldName()));
		}

	}

	public void testGetProgramRankProgramSingleFieldWithProgramParameter() {
		Program program = this.programClient.create(this.programFactory.create(), new String[] {});

		URI programRankId = this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.programId, program.getId())))
				.getId();
		Program actual = null;
		for (NamespacedFieldInfo fieldInfo : EMBEDDED_PROGRAM_FIELDINFOS) {
			Program expected = new Program();
			MerlinTestReflectionUtil.set(expected, fieldInfo.getField(), MerlinTestReflectionUtil.get(program, fieldInfo.getField()));
			actual = this.programRankClient.get(programRankId, new String[] { ProgramRankField.program.getLocalName(), fieldInfo.getField().getLocalName() })
					.getProgram();
			Assert.assertEquals(MerlinTestReflectionUtil.get(actual, fieldInfo.getFieldName()),
					MerlinTestReflectionUtil.get(expected, fieldInfo.getFieldName()));
		}

	}

	public void testGetRelatedProgramTargetProgramSingleFieldWithTargetProgramQualifiedParameter() {
		Program targetProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		URI relatedProgramId = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.targetProgramId, targetProgram.getId()))).getId();
		Program actual = null;
		for (NamespacedFieldInfo fieldInfo : EMBEDDED_PROGRAM_FIELDINFOS) {
			Program expected = new Program();
			MerlinTestReflectionUtil.set(expected, fieldInfo.getField(), MerlinTestReflectionUtil.get(targetProgram, fieldInfo.getField()));
			actual = this.relatedProgramClient.get(relatedProgramId,
					new String[] { RelatedProgramField.targetProgram.getQualifiedName(), fieldInfo.getField().getQualifiedName() }).getTargetProgram();
			Assert.assertEquals(MerlinTestReflectionUtil.get(actual, fieldInfo.getFieldName()),
					MerlinTestReflectionUtil.get(expected, fieldInfo.getFieldName()));
		}

	}

	public void testGetRelatedProgramSourceProgramSingleFieldWithSourceProgramQualifiedParameter() {
		Program sourceProgram = this.programClient.create(this.programFactory.create(), new String[] {});

		URI relatedProgramId = this.relatedProgramClient.create(
				this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.sourceProgramId, sourceProgram.getId()))).getId();
		Program actual = null;
		for (NamespacedFieldInfo fieldInfo : EMBEDDED_PROGRAM_FIELDINFOS) {
			Program expected = new Program();
			MerlinTestReflectionUtil.set(expected, fieldInfo.getField(), MerlinTestReflectionUtil.get(sourceProgram, fieldInfo.getField()));
			actual = this.relatedProgramClient.get(relatedProgramId,
					new String[] { RelatedProgramField.sourceProgram.getQualifiedName(), fieldInfo.getField().getQualifiedName() }).getSourceProgram();
			Assert.assertEquals(MerlinTestReflectionUtil.get(actual, fieldInfo.getFieldName()),
					MerlinTestReflectionUtil.get(expected, fieldInfo.getFieldName()));
		}

	}

	public void testGetProgramRankProgramSingleFieldWithProgramQualifiedParameter() {
		Program program = this.programClient.create(this.programFactory.create(), new String[] {});

		URI programRankId = this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.programId, program.getId())))
				.getId();
		Program actual = null;
		for (NamespacedFieldInfo fieldInfo : EMBEDDED_PROGRAM_FIELDINFOS) {
			Program expected = new Program();
			MerlinTestReflectionUtil.set(expected, fieldInfo.getField(), MerlinTestReflectionUtil.get(program, fieldInfo.getField()));
			actual = this.programRankClient.get(programRankId,
					new String[] { ProgramRankField.program.getQualifiedName(), fieldInfo.getField().getQualifiedName() }).getProgram();
			Assert.assertEquals(MerlinTestReflectionUtil.get(actual, fieldInfo.getFieldName()),
					MerlinTestReflectionUtil.get(expected, fieldInfo.getFieldName()));
		}

	}

	private Program getRelatedProgramTargetProgram(Program inputProgram) {
		Program targetProgram = new Program();

		for (NamespacedFieldInfo fieldInfo : EMBEDDED_PROGRAM_FIELDINFOS)
			MerlinTestReflectionUtil.set(targetProgram, fieldInfo.getField(), MerlinTestReflectionUtil.get(inputProgram, fieldInfo.getField()));
		return targetProgram;
	}

	private Program getRelatedProgramSourceProgram(Program inputProgram) {
		Program sourceProgram = new Program();

		for (NamespacedFieldInfo fieldInfo : EMBEDDED_PROGRAM_FIELDINFOS)
			MerlinTestReflectionUtil.set(sourceProgram, fieldInfo.getField(), MerlinTestReflectionUtil.get(inputProgram, fieldInfo.getField()));
		return sourceProgram;
	}

	private Program getProgramRankProgram(Program inputProgram) {
		Program program = new Program();

		for (NamespacedFieldInfo fieldInfo : EMBEDDED_PROGRAM_FIELDINFOS)
			MerlinTestReflectionUtil.set(program, fieldInfo.getField(), MerlinTestReflectionUtil.get(inputProgram, fieldInfo.getField()));
		return program;
	}

}
