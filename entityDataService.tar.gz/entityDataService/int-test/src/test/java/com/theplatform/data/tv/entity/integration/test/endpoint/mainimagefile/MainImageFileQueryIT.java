package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagefile;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMediaIdAccountGuid;
import com.theplatform.contrib.data.api.client.query.ByMediaIdMediaGuid;
import com.theplatform.contrib.data.api.client.query.ByMediaIdServiceGuid;
import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;
import com.theplatform.data.tv.image.api.fields.MainImageFileField;
import com.theplatform.data.tv.image.api.test.MainImageFileComparator;

@Test(groups = { "mainImageFile", "query", TestGroup.gbTest })
public class MainImageFileQueryIT extends EntityTestBase {

	public void testMainImageFileQueryByMediaIdServiceGuidNoMatch() {

		final String serviceGuid = "serviceGuid";
		MediaId mediaId = new MediaId();
		mediaId.setServiceGuid(serviceGuid);
		mediaId.setAccountGuid("accountGuid");
		mediaId.setMediaGuid("mediaGuid");

		final MainImageFile unexpected = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(unexpected.getMediaId());
		Assert.assertEquals(unexpected.getMediaId().getServiceGuid(), serviceGuid);

		Query[] queries = new Query[] { new ByMediaIdServiceGuid(serviceGuid.concat("update")) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageFile should be found");
	}

	public void testMainImageFileQueryByMediaIdServiceGuidListNoMatch() {
		final String serviceGuid1 = "serviceGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setServiceGuid(serviceGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String serviceGuid2 = "serviceGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setServiceGuid(serviceGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setMediaGuid("mediaGuid");
		final String serviceGuid3 = "serviceGuid3";
		MediaId mediaId3 = new MediaId();
		mediaId3.setServiceGuid(serviceGuid3);
		mediaId3.setAccountGuid("accountGuid");
		mediaId3.setMediaGuid("mediaGuid");

		final MainImageFile unexpected1 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		final MainImageFile unexpected2 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		Assert.assertNotNull(unexpected1.getMediaId());
		Assert.assertEquals(unexpected1.getMediaId().getServiceGuid(), serviceGuid1);
		Assert.assertNotNull(unexpected2.getMediaId());
		Assert.assertEquals(unexpected2.getMediaId().getServiceGuid(), serviceGuid1);

		Query[] queries = new Query[] { new ByMediaIdServiceGuid(Arrays.asList(serviceGuid3, serviceGuid2)) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageFile should be found");
	}

	public void testMainImageFileQueryByMediaIdServiceGuidOneMatch() {

		final String serviceGuid = "serviceGuid1";
		MediaId mediaId = new MediaId();
		mediaId.setServiceGuid(serviceGuid);
		mediaId.setAccountGuid("accountGuid");
		mediaId.setMediaGuid("mediaGuid");
		final MainImageFile expected = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getServiceGuid(), serviceGuid);
		Query[] queries = new Query[] { new ByMediaIdServiceGuid(serviceGuid) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageFile should be found");

		MainImageFileComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testMainImageFileQueryByMediaIdServiceGuidListOneMatch() {

		final String serviceGuid1 = "serviceGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setServiceGuid(serviceGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String serviceGuid2 = "serviceGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setServiceGuid(serviceGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setMediaGuid("mediaGuid");
		final String serviceGuid3 = "serviceGuid3";
		MediaId mediaId3 = new MediaId();
		mediaId3.setServiceGuid(serviceGuid3);
		mediaId3.setAccountGuid("accountGuid");
		mediaId3.setMediaGuid("mediaGuid");
		final MainImageFile expected = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId2)));
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getServiceGuid(), serviceGuid1);

		Query[] queries = new Query[] { new ByMediaIdServiceGuid(Arrays.asList(serviceGuid1, serviceGuid3)) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageFile should be found");

		MainImageFileComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testMainImageFileQueryByMediaIdServiceGuidMultipleMatch() {

		final String serviceGuid1 = "serviceGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setServiceGuid(serviceGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String serviceGuid2 = "serviceGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setServiceGuid(serviceGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setMediaGuid("mediaGuid");

		final MainImageFile expected1 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		final MainImageFile expected2 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId2)), new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getServiceGuid(), serviceGuid1);
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getServiceGuid(), serviceGuid1);

		Query[] queries = new Query[] { new ByMediaIdServiceGuid(serviceGuid1) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageFiles should be found");

		Map<URI, MainImageFile> resultMap = new HashMap<>();
		for (MainImageFile MainImageFile : results.getEntries())
			resultMap.put(MainImageFile.getId(), MainImageFile);

		MainImageFileComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		MainImageFileComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testMainImageFileQueryByMediaIdServiceGuidListMultipleMatch() {

		final String serviceGuid1 = "serviceGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setServiceGuid(serviceGuid1);
		mediaId1.setAccountGuid("accountGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String serviceGuid2 = "serviceGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setServiceGuid(serviceGuid2);
		mediaId2.setAccountGuid("accountGuid");
		mediaId2.setMediaGuid("mediaGuid");
		final String serviceGuid3 = "serviceGuid3";
		MediaId mediaId3 = new MediaId();
		mediaId3.setServiceGuid(serviceGuid3);
		mediaId3.setAccountGuid("accountGuid");
		mediaId3.setMediaGuid("mediaGuid");
		Assert.assertNotEquals(serviceGuid1, serviceGuid2);
		Assert.assertNotEquals(serviceGuid3, serviceGuid2);

		MainImageFile expected1 = this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)),
				new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getServiceGuid(), serviceGuid1);
		MainImageFile expected2 = this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId2)),
				new String[] {});
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getServiceGuid(), serviceGuid2);
		this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId3)));

		Query[] queries = new Query[] { new ByMediaIdServiceGuid(Arrays.asList(serviceGuid1, serviceGuid2)) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageFiles should be found");

		Map<URI, MainImageFile> resultMap = new HashMap<>();
		for (MainImageFile MainImageFile : results.getEntries())
			resultMap.put(MainImageFile.getId(), MainImageFile);

		MainImageFileComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		MainImageFileComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testMainImageFileQueryByMediaIdAccountGuidNoMatch() {

		final String accountGuid = "accountGuid";
		MediaId mediaId = new MediaId();
		mediaId.setAccountGuid(accountGuid);
		mediaId.setServiceGuid("serviceGuid");
		mediaId.setMediaGuid("mediaGuid");

		final MainImageFile unexpected = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(unexpected.getMediaId());
		Assert.assertEquals(unexpected.getMediaId().getAccountGuid(), accountGuid);

		Query[] queries = new Query[] { new ByMediaIdAccountGuid(accountGuid.concat("update")) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageFile should be found");
	}

	public void testMainImageFileQueryByMediaIdAccountGuidListNoMatch() {
		final String accountGuid1 = "accountGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setAccountGuid(accountGuid1);
		mediaId1.setServiceGuid("serviceGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String accountGuid2 = "accountGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setAccountGuid(accountGuid2);
		mediaId2.setServiceGuid("serviceGuid");
		mediaId2.setMediaGuid("mediaGuid");
		final String accountGuid3 = "accountGuid3";
		MediaId mediaId3 = new MediaId();
		mediaId3.setAccountGuid(accountGuid3);
		mediaId3.setServiceGuid("serviceGuid");
		mediaId3.setMediaGuid("mediaGuid");

		final MainImageFile unexpected1 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		final MainImageFile unexpected2 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		Assert.assertNotNull(unexpected1.getMediaId());
		Assert.assertEquals(unexpected1.getMediaId().getAccountGuid(), accountGuid1);
		Assert.assertNotNull(unexpected2.getMediaId());
		Assert.assertEquals(unexpected2.getMediaId().getAccountGuid(), accountGuid1);

		Query[] queries = new Query[] { new ByMediaIdAccountGuid(Arrays.asList(accountGuid3, accountGuid2)) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageFile should be found");
	}

	public void testMainImageFileQueryByMediaIdAccountGuidOneMatch() {

		final String accountGuid = "accountGuid1";
		MediaId mediaId = new MediaId();
		mediaId.setAccountGuid(accountGuid);
		mediaId.setServiceGuid("serviceGuid");
		mediaId.setMediaGuid("mediaGuid");
		final MainImageFile expected = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getAccountGuid(), accountGuid);
		Query[] queries = new Query[] { new ByMediaIdAccountGuid(accountGuid) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageFile should be found");

		MainImageFileComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testMainImageFileQueryByMediaIdAccountGuidListOneMatch() {

		final String accountGuid1 = "accountGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setAccountGuid(accountGuid1);
		mediaId1.setServiceGuid("serviceGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String accountGuid2 = "accountGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setAccountGuid(accountGuid2);
		mediaId2.setServiceGuid("serviceGuid");
		mediaId2.setMediaGuid("mediaGuid");
		final String accountGuid3 = "accountGuid3";
		MediaId mediaId3 = new MediaId();
		mediaId3.setAccountGuid(accountGuid3);
		mediaId3.setServiceGuid("serviceGuid");
		mediaId3.setMediaGuid("mediaGuid");
		final MainImageFile expected = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId2)));
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getAccountGuid(), accountGuid1);

		Query[] queries = new Query[] { new ByMediaIdAccountGuid(Arrays.asList(accountGuid1, accountGuid3)) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageFile should be found");

		MainImageFileComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testMainImageFileQueryByMediaIdAccountGuidMultipleMatch() {

		final String accountGuid1 = "accountGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setAccountGuid(accountGuid1);
		mediaId1.setServiceGuid("serviceGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String accountGuid2 = "accountGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setAccountGuid(accountGuid2);
		mediaId2.setServiceGuid("serviceGuid");
		mediaId2.setMediaGuid("mediaGuid");

		final MainImageFile expected1 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		final MainImageFile expected2 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId2)), new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getAccountGuid(), accountGuid1);
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getAccountGuid(), accountGuid1);

		Query[] queries = new Query[] { new ByMediaIdAccountGuid(accountGuid1) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageFiles should be found");

		Map<URI, MainImageFile> resultMap = new HashMap<>();
		for (MainImageFile MainImageFile : results.getEntries())
			resultMap.put(MainImageFile.getId(), MainImageFile);

		MainImageFileComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		MainImageFileComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testMainImageFileQueryByMediaIdAccountGuidListMultipleMatch() {

		final String accountGuid1 = "accountGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setAccountGuid(accountGuid1);
		mediaId1.setServiceGuid("serviceGuid");
		mediaId1.setMediaGuid("mediaGuid");
		final String accountGuid2 = "accountGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setAccountGuid(accountGuid2);
		mediaId2.setServiceGuid("serviceGuid");
		mediaId2.setMediaGuid("mediaGuid");
		final String accountGuid3 = "accountGuid3";
		MediaId mediaId3 = new MediaId();
		mediaId3.setAccountGuid(accountGuid3);
		mediaId3.setServiceGuid("serviceGuid");
		mediaId3.setMediaGuid("mediaGuid");
		Assert.assertNotEquals(accountGuid1, accountGuid2);
		Assert.assertNotEquals(accountGuid3, accountGuid2);

		MainImageFile expected1 = this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)),
				new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getAccountGuid(), accountGuid1);
		MainImageFile expected2 = this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId2)),
				new String[] {});
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getAccountGuid(), accountGuid2);
		this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId3)));

		Query[] queries = new Query[] { new ByMediaIdAccountGuid(Arrays.asList(accountGuid1, accountGuid2)) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageFiles should be found");

		Map<URI, MainImageFile> resultMap = new HashMap<>();
		for (MainImageFile MainImageFile : results.getEntries())
			resultMap.put(MainImageFile.getId(), MainImageFile);

		MainImageFileComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		MainImageFileComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testMainImageFileQueryByMediaIdMediaGuidNoMatch() {

		final String mediaGuid = "mediaGuid";
		MediaId mediaId = new MediaId();
		mediaId.setMediaGuid(mediaGuid);
		mediaId.setServiceGuid("serviceGuid");
		mediaId.setAccountGuid("accountGuid");

		final MainImageFile unexpected = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(unexpected.getMediaId());
		Assert.assertEquals(unexpected.getMediaId().getMediaGuid(), mediaGuid);

		Query[] queries = new Query[] { new ByMediaIdMediaGuid(mediaGuid.concat("update")) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageFile should be found");
	}

	public void testMainImageFileQueryByMediaIdMediaGuidListNoMatch() {
		final String mediaGuid1 = "mediaGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setMediaGuid(mediaGuid1);
		mediaId1.setServiceGuid("serviceGuid");
		mediaId1.setAccountGuid("accountGuid");
		final String mediaGuid2 = "mediaGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setMediaGuid(mediaGuid2);
		mediaId2.setServiceGuid("serviceGuid");
		mediaId2.setAccountGuid("accountGuid");
		final String mediaGuid3 = "mediaGuid3";
		MediaId mediaId3 = new MediaId();
		mediaId3.setMediaGuid(mediaGuid3);
		mediaId3.setServiceGuid("serviceGuid");
		mediaId3.setAccountGuid("accountGuid");

		final MainImageFile unexpected1 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		final MainImageFile unexpected2 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		Assert.assertNotNull(unexpected1.getMediaId());
		Assert.assertEquals(unexpected1.getMediaId().getMediaGuid(), mediaGuid1);
		Assert.assertNotNull(unexpected2.getMediaId());
		Assert.assertEquals(unexpected2.getMediaId().getMediaGuid(), mediaGuid1);

		Query[] queries = new Query[] { new ByMediaIdMediaGuid(Arrays.asList(mediaGuid3, mediaGuid2)) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageFile should be found");
	}

	public void testMainImageFileQueryByMediaIdMediaGuidOneMatch() {

		final String mediaGuid = "mediaGuid1";
		MediaId mediaId = new MediaId();
		mediaId.setMediaGuid(mediaGuid);
		mediaId.setServiceGuid("serviceGuid");
		mediaId.setAccountGuid("accountGuid");
		final MainImageFile expected = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId)), new String[] {});
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getMediaGuid(), mediaGuid);
		Query[] queries = new Query[] { new ByMediaIdMediaGuid(mediaGuid) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageFile should be found");

		MainImageFileComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testMainImageFileQueryByMediaIdMediaGuidListOneMatch() {

		final String mediaGuid1 = "mediaGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setMediaGuid(mediaGuid1);
		mediaId1.setServiceGuid("serviceGuid");
		mediaId1.setAccountGuid("accountGuid");
		final String mediaGuid2 = "mediaGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setMediaGuid(mediaGuid2);
		mediaId2.setServiceGuid("serviceGuid");
		mediaId2.setAccountGuid("accountGuid");
		final String mediaGuid3 = "mediaGuid3";
		MediaId mediaId3 = new MediaId();
		mediaId3.setMediaGuid(mediaGuid3);
		mediaId3.setServiceGuid("serviceGuid");
		mediaId3.setAccountGuid("accountGuid");
		final MainImageFile expected = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId2)));
		Assert.assertNotNull(expected.getMediaId());
		Assert.assertEquals(expected.getMediaId().getMediaGuid(), mediaGuid1);

		Query[] queries = new Query[] { new ByMediaIdMediaGuid(Arrays.asList(mediaGuid1, mediaGuid3)) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageFile should be found");

		MainImageFileComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testMainImageFileQueryByMediaIdMediaGuidMultipleMatch() {

		final String mediaGuid1 = "mediaGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setMediaGuid(mediaGuid1);
		mediaId1.setServiceGuid("serviceGuid");
		mediaId1.setAccountGuid("accountGuid");
		final String mediaGuid2 = "mediaGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setMediaGuid(mediaGuid2);
		mediaId2.setServiceGuid("serviceGuid");
		mediaId2.setAccountGuid("accountGuid");

		final MainImageFile expected1 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		final MainImageFile expected2 = this.mainImageFileClient.create(
				this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)), new String[] {});
		this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId2)), new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getMediaGuid(), mediaGuid1);
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getMediaGuid(), mediaGuid1);

		Query[] queries = new Query[] { new ByMediaIdMediaGuid(mediaGuid1) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageFiles should be found");

		Map<URI, MainImageFile> resultMap = new HashMap<>();
		for (MainImageFile MainImageFile : results.getEntries())
			resultMap.put(MainImageFile.getId(), MainImageFile);

		MainImageFileComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		MainImageFileComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

	public void testMainImageFileQueryByMediaIdMediaGuidListMultipleMatch() {

		final String mediaGuid1 = "mediaGuid1";
		MediaId mediaId1 = new MediaId();
		mediaId1.setMediaGuid(mediaGuid1);
		mediaId1.setServiceGuid("serviceGuid");
		mediaId1.setAccountGuid("accountGuid");
		final String mediaGuid2 = "mediaGuid2";
		MediaId mediaId2 = new MediaId();
		mediaId2.setMediaGuid(mediaGuid2);
		mediaId2.setServiceGuid("serviceGuid");
		mediaId2.setAccountGuid("accountGuid");
		final String mediaGuid3 = "mediaGuid3";
		MediaId mediaId3 = new MediaId();
		mediaId3.setMediaGuid(mediaGuid3);
		mediaId3.setServiceGuid("serviceGuid");
		mediaId3.setAccountGuid("accountGuid");
		Assert.assertNotEquals(mediaGuid1, mediaGuid2);
		Assert.assertNotEquals(mediaGuid3, mediaGuid2);

		MainImageFile expected1 = this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId1)),
				new String[] {});
		Assert.assertNotNull(expected1.getMediaId());
		Assert.assertEquals(expected1.getMediaId().getMediaGuid(), mediaGuid1);
		MainImageFile expected2 = this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId2)),
				new String[] {});
		Assert.assertNotNull(expected2.getMediaId());
		Assert.assertEquals(expected2.getMediaId().getMediaGuid(), mediaGuid2);
		this.mainImageFileClient.create(this.mainImageFileFactory.create(new DataServiceField(MainImageFileField.mediaId, mediaId3)));

		Query[] queries = new Query[] { new ByMediaIdMediaGuid(Arrays.asList(mediaGuid1, mediaGuid2)) };
		Feed<MainImageFile> results = this.mainImageFileClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageFiles should be found");

		Map<URI, MainImageFile> resultMap = new HashMap<>();
		for (MainImageFile MainImageFile : results.getEntries())
			resultMap.put(MainImageFile.getId(), MainImageFile);

		MainImageFileComparator.assertEquals(resultMap.get(expected1.getId()), expected1);
		MainImageFileComparator.assertEquals(resultMap.get(expected2.getId()), expected2);
	}

}
