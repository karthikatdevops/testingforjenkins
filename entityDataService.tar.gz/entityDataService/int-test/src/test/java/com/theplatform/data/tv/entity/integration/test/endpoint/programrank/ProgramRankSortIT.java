package com.theplatform.data.tv.entity.integration.test.endpoint.programrank;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.IncludeField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "sort", "programRank", TestGroup.gbTest })
public class ProgramRankSortIT extends EntityTestBase {

	public void testProgramRankSortByGuid() throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		List<ProgramRank> programRanks = programRankFactory.create(4);
		programRanks.get(0).setGuid("1");
		programRanks.get(3).setGuid("2");
		programRanks.get(1).setGuid("3");
		programRanks.get(2).setGuid("4");

		this.programRankClient.create(programRanks);

		List<ProgramRank> expected = new ArrayList<>(programRanks.size());
		expected.add(programRanks.get(0));
		expected.add(programRanks.get(3));
		expected.add(programRanks.get(1));
		expected.add(programRanks.get(2));

		Feed<ProgramRank> retrievedProgramRanks = this.programRankClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("guid", false) },
				null, false);

		for (int i = 0; i < expected.size(); i++)
			programRankComparator.assertEquals(retrievedProgramRanks.getEntries().get(i), expected.get(i), new IncludeField("guid"));
	}

	public void testProgramRankSortByRank() throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		List<ProgramRank> programRanks = programRankFactory.create(4);
		programRanks.get(0).setRank(1f);
		programRanks.get(3).setRank(2.5f);
		programRanks.get(1).setRank(3.5f);
		programRanks.get(2).setRank(4f);

		this.programRankClient.create(programRanks);

		List<ProgramRank> expected = new ArrayList<>(programRanks.size());
		expected.add(programRanks.get(0));
		expected.add(programRanks.get(3));
		expected.add(programRanks.get(1));
		expected.add(programRanks.get(2));

		Feed<ProgramRank> retrievedProgramRanks = this.programRankClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("rank", false) },
				null, false);

		for (int i = 0; i < expected.size(); i++)
			programRankComparator.assertEquals(retrievedProgramRanks.getEntries().get(i), expected.get(i), new IncludeField("rank"));

	}
}
