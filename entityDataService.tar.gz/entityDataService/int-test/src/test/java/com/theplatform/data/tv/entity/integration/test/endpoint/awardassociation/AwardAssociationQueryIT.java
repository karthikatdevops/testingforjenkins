package com.theplatform.data.tv.entity.integration.test.endpoint.awardassociation;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.entity.api.client.query.awardassociation.ByAwardId;
import com.theplatform.data.tv.entity.api.client.query.awardassociation.ByAwardStatus;
import com.theplatform.data.tv.entity.api.client.query.awardassociation.ByAwardType;
import com.theplatform.data.tv.entity.api.client.query.awardassociation.ByInstitutionId;
import com.theplatform.data.tv.entity.api.client.query.awardassociation.ByPersonId;
import com.theplatform.data.tv.entity.api.client.query.awardassociation.ByProgramId;
import com.theplatform.data.tv.entity.api.client.query.awardassociation.ByYear;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import com.theplatform.data.tv.entity.api.data.objects.AwardStatus;
import com.theplatform.data.tv.entity.api.data.objects.AwardType;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.test.AwardAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * GreenBuild test of query of AwardAssociation
 * 
 * @author clai200
 * @since 4/5/2011
 * 
 */
@Test(groups = { TestGroup.gbTest, "awardAssociation", "query" })
public class AwardAssociationQueryIT extends EntityTestBase {



	public void testAwardAssociationQueryByInstitutionIdNoMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByInstitutionIdOneMatch() {
		List<AwardAssociation> entities = this.awardAssociationFactory.create(3);

		Institution institution = this.institutionFactory.create();
		this.institutionClient.create(institution);

		final int index = 0;
		entities.get(index).setInstitutionId(institution.getId());

		this.awardAssociationClient.create(entities);

		Query[] queries = new Query[] { new ByInstitutionId(LocalUriConverter.convertUriToID(entities.get(0).getInstitutionId())) };

		Feed<AwardAssociation> results = this.awardAssociationClient.getAll(null, queries, null, null, null);

		assertEquals(results.getEntries().size(), 1, "Numnber of result should be 1");
		AwardAssociationComparator.assertEquals(entities.get(index), results.getEntries().get(0));

	}

	public void testAwardAssociationQueryByInstitutionIdMultipleMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByYearNoMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByYearOneMatch() {
		List<AwardAssociation> entities = this.awardAssociationFactory.create(3);

		final int index = 0, defaultYear = 1980;

		for (int i = 0; i < entities.size(); i++) {
			entities.get(index + i).setYear(defaultYear + i);
		}

		this.awardAssociationClient.create(entities);

		Query[] queries = new Query[] { new ByYear(defaultYear) };

		Feed<AwardAssociation> results = this.awardAssociationClient.getAll(null, queries, null, null, null);

		assertEquals(results.getEntries().size(), 1, "Numnber of result should be 1");
		AwardAssociationComparator.assertEquals(entities.get(index), results.getEntries().get(0));

	}

	public void testAwardAssociationQueryByYearMultipleMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByAwardIdNoMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByAwardIdOneMatch() {
		List<AwardAssociation> entities = this.awardAssociationFactory.create(3);

		Award award = this.awardFactory.create();
		this.awardClient.create(award);

		final int index = 0;
		entities.get(index).setAwardId(award.getId());

		this.awardAssociationClient.create(entities);

		Query[] queries = new Query[] { new ByAwardId(LocalUriConverter.convertUriToID(entities.get(0).getAwardId())) };

		Feed<AwardAssociation> results = this.awardAssociationClient.getAll(null, queries, null, null, null);

		assertEquals(results.getEntries().size(), 1, "Numnber of result should be 1");
		AwardAssociationComparator.assertEquals(entities.get(index), results.getEntries().get(0));

	}

	public void testAwardAssociationQueryByAwardIdMultipleMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByProgramIdNoMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByProgramIdOneMatch() {
		List<AwardAssociation> entities = this.awardAssociationFactory.create(3);

		Program program = this.programFactory.create();
		this.programClient.create(program);

		final int index = 0;
		entities.get(index).setProgramId(program.getId());

		this.awardAssociationClient.create(entities);

		Query[] queries = new Query[] { new ByProgramId(LocalUriConverter.convertUriToID(entities.get(0).getProgramId())) };

		Feed<AwardAssociation> results = this.awardAssociationClient.getAll(null, queries, null, null, null);

		assertEquals(results.getEntries().size(), 1, "Numnber of result should be 1");
		AwardAssociationComparator.assertEquals(entities.get(index), results.getEntries().get(0));

	}

	public void testAwardAssociationQueryByProgramIdMultipleMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByPersonIdNoMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByPersonIdOneMatch() {
		List<AwardAssociation> entities = this.awardAssociationFactory.create(3);

		Person person = this.personFactory.create();
		this.personClient.create(person);

		final int index = 0;
		entities.get(index).setPersonId(person.getId());

		this.awardAssociationClient.create(entities);

		Query[] queries = new Query[] { new ByPersonId(LocalUriConverter.convertUriToID(entities.get(0).getPersonId())) };

		Feed<AwardAssociation> results = this.awardAssociationClient.getAll(null, queries, null, null, null);

		assertEquals(results.getEntries().size(), 1, "Numnber of result should be 1");
		AwardAssociationComparator.assertEquals(entities.get(index), results.getEntries().get(0));

	}

	public void testAwardAssociationQueryByPersonIdMultipleMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByAwardTypeNoMatch() {
		// TODO to be implemented
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAwardAssociationQueryByAwardTypeOneMatch() {
		List<AwardAssociation> entities = this.awardAssociationFactory.create(2);

		entities.get(0).setAwardType(AwardType.Person.getFriendlyName());
		entities.get(1).setAwardType(AwardType.Program.getFriendlyName());
		entities.get(1).setProgramId(this.programClient.create(this.programFactory.create()).getId());
		entities.get(1).setPersonId(null);

		this.awardAssociationClient.create(entities);

		Query[] queries = new Query[] { new ByAwardType(AwardType.Person) };

		Feed<AwardAssociation> results = this.awardAssociationClient.getAll(null, queries, null, null, null);

		assertEquals(results.getEntries().size(), 1, "Numnber of result should be 1");
		AwardAssociationComparator.assertEquals(entities.get(0), results.getEntries().get(0));

	}

	public void testAwardAssociationQueryByAwardTypeMultipleMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByAwardStatusNoMatch() {
		// TODO to be implemented
	}

	public void testAwardAssociationQueryByAwardStatusOneMatch() {
		List<AwardAssociation> entities = this.awardAssociationFactory.create(3);

		entities.get(0).setAwardStatus(AwardStatus.FestivalScreening.getFriendlyName());
		entities.get(1).setAwardStatus(AwardStatus.Nominee.getFriendlyName());
		entities.get(2).setAwardStatus(AwardStatus.Winner.getFriendlyName());

		this.awardAssociationClient.create(entities);

		Query[] queries = new Query[] { new ByAwardStatus(AwardStatus.FestivalScreening) };

		Feed<AwardAssociation> results = this.awardAssociationClient.getAll(null, queries, null, null, null);

		assertEquals(results.getEntries().size(), 1, "Numnber of result should be 1");
		AwardAssociationComparator.assertEquals(entities.get(0), results.getEntries().get(0));

	}

	public void testAwardAssociationQueryByAwardStatusMultipleMatch() {
		// TODO to be implemented
	}

}
