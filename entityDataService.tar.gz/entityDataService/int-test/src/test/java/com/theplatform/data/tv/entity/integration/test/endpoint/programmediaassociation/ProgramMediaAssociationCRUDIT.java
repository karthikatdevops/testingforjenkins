package com.theplatform.data.tv.entity.integration.test.endpoint.programmediaassociation;

import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.DateUtil;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.NamespacedField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.ProgramMediaAssociationField;
import com.theplatform.data.tv.entity.api.test.ProgramMediaAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.module.exception.AuthorizationException;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.*;

import static org.testng.Assert.*;

/**
 * 
 * @author jethrolai
 */
@Test(groups = { "crud", "programMediaAssociation", TestGroup.gbTest })
public class ProgramMediaAssociationCRUDIT extends EntityTestBase {
	private Random random = new Random();

	public void crudSingleProgramMediaAssociation() throws UnknownHostException {
		
		//CREATE
		ProgramMediaAssociation entity = this.persistingProgramMediaAssociationFactory.create();
		//RETRIEVE
		ProgramMediaAssociationComparator.assertEquals(this.programMediaAssociationClient.get(entity.getId(), new String[] {}), entity);

		// UPDATE
		URI entityId = entity.getId();
		
		Program program = this.programClient.create(this.programFactory.create(), new String[] {});
		entity.setProgramId(program.getId());
		entity.setProgramType(null);
		
		
		MediaId mediaId = new MediaId();
		mediaId.setMediaGuid(entity.getMediaGuid());
		mediaId.setAccountGuid(entityId.toString() + "_Fake_ACC");
		mediaId.setServiceGuid(entityId.toString() + "_Fake_SERV");

        MediaId mezzanineMediaId = new MediaId();
        mezzanineMediaId.setMediaGuid(entity.getMediaGuid());
        mezzanineMediaId.setAccountGuid(entityId.toString() + "_Fake_ACC");
        mezzanineMediaId.setServiceGuid(entityId.toString() + "_Fake_SERV");
		
		entity.setMediaId(mediaId);
        entity.setMezzanineMediaId(mezzanineMediaId);
		entity.setDistributionId(URI.create(this.getIdBaseUrl() + "/data/MerlinId/" + new Random().nextInt()));
		entity.setProviderId(entity.getProviderId() == null ? "comcast.com" : entity.getProviderId().concat("update"));
		entity.setTitleAssetId(entity.getTitleAssetId() == null ? "CCDN1234567890123456" : entity.getTitleAssetId().concat("update"));
		entity.setTitlePaid(entity.getTitlePaid() == null ? "comcast.comCCDN1234567890123456" : entity.getTitlePaid().concat("update"));
		
		this.programMediaAssociationClient.update(entity);
		entity = this.programMediaAssociationClient.get(entityId, new String[] {});
		
		entity.setProgramType(program.getType());

		entity.setProvider(entity.getProvider() == null ? "programMediaAssociation provider" : entity.getProvider().concat(" update"));
		entity.setCompanyId(URI.create(this.getLinearBaseUrl().concat("/data/Company/" + random.nextInt())));

		entity.setAvailableDate(DateUtil.getDateWithZeroMilliseconds(new Date()));
		entity.setExpirationDate(DateUtil.getDateWithZeroMilliseconds(new Date()));
		entity.setMediaGuid(null);
		programMediaAssociationClient.update(entity);

		entity.setMediaGuid(entity.getMediaId().getMediaGuid());
		ProgramMediaAssociationComparator.assertEquals(this.programMediaAssociationClient.get(entityId, new String[] {}), entity);

		// DELETE
		long deletedObjects = this.programMediaAssociationClient.delete(entity.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.programMediaAssociationClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("ProgramMediaAssociation:".concat(entity.getId().toString()).concat("should not be found after deleting it"));
	}

	public void crudProgramMediaAssociationFeed() throws UnknownHostException {

		// CREATE
		List<ProgramMediaAssociation> entities = this.persistingProgramMediaAssociationFactory.create(3);
		//RETRIEVE
		List<URI> entityIds = new ArrayList<URI>();
		for (ProgramMediaAssociation pma : entities)
			entityIds.add(pma.getId());
		URI[] entityIdArray = entityIds.toArray(new URI[] {});
		
		ProgramMediaAssociationComparator.assertEquals(this.programMediaAssociationClient.get(entityIdArray, new String[] {}), entities);

		// DELETE
		long deletedEntities = this.programMediaAssociationClient.delete(entityIdArray);
		assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (ProgramMediaAssociation entity : entities) {
			try {
				this.programMediaAssociationClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	public void testProgramMediaAssociationDefaultFieldValue() throws UnknownHostException {
		ProgramMediaAssociation entity = this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.merlinResourceType, null,
				ProgramMediaAssociationField.programType, null,
				ProgramMediaAssociationField.distributionId, null,
				ProgramMediaAssociationField.providerId, null,
				ProgramMediaAssociationField.titleAssetId, null,
				ProgramMediaAssociationField.titlePaid, null,
				ProgramMediaAssociationField.contentAssetId, null);
		
		Assert.assertEquals(entity.getProgramType(), ProgramType.Other);
		Assert.assertEquals(entity.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
		Assert.assertNull(entity.getDistributionId());
		Assert.assertNull(entity.getProviderId());
		Assert.assertNull(entity.getTitleAssetId());
		Assert.assertNull(entity.getTitlePaid());
		Assert.assertNull(entity.getContentAssetId());
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(ProgramMediaAssociationField.distributionId, null),
			new DataServiceField(ProgramMediaAssociationField.providerId, null), new DataServiceField(ProgramMediaAssociationField.titleAssetId, null),
			new DataServiceField(ProgramMediaAssociationField.titlePaid, null), new DataServiceField(ProgramMediaAssociationField.contentAssetId, null),
			new DataServiceField(ProgramMediaAssociationField.provider, null), new DataServiceField(ProgramMediaAssociationField.companyId, null),
			new DataServiceField(ProgramMediaAssociationField.availableDate, null), new DataServiceField(ProgramMediaAssociationField.expirationDate, null),
			// default to Program.merlinResourceType
			new DataServiceField(ProgramMediaAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable),
            new DataServiceField(ProgramMediaAssociationField.categoryPaths, null)
    };

	public void testProgramMediaAssociationCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		
		ProgramMediaAssociation pma = this.persistingProgramMediaAssociationFactory.create();
		ProgramType programType = programClient.get(pma.getProgramId(), new String[] { ProgramField.type.getLocalName() }).getType();
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(programMediaAssociationClient, pma, ProgramMediaAssociationComparator.class,
				this.defaultValues, new DataServiceField[] { new DataServiceField(ProgramMediaAssociationField.programType, programType),
						new DataServiceField(ProgramMediaAssociationField.mediaGuid, pma.getMediaId().getMediaGuid()),
						new DataServiceField(ProgramMediaAssociationField.mediaId, pma.getMediaId()) });
	}

	public void testProgramMediaAssociationCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		ProgramMediaAssociation pma = this.persistingProgramMediaAssociationFactory.create();
		ProgramType programType = programClient.get(pma.getProgramId(), new String[] { ProgramField.type.getLocalName() }).getType();
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(programMediaAssociationClient, pma, ProgramMediaAssociationComparator.class,
				this.defaultValues, new DataServiceField[] { new DataServiceField(ProgramMediaAssociationField.programType, programType),
						new DataServiceField(ProgramMediaAssociationField.mediaGuid, pma.getMediaId().getMediaGuid()),
						new DataServiceField(ProgramMediaAssociationField.mediaId, pma.getMediaId()) });
	}

	public void testProgramMediaAssociationUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		
		URI id = this.persistingProgramMediaAssociationFactory.create().getId();
		this.programMediaAssociationClient.delete(id);
		Program program = programClient.create(programFactory.create(), new String[] {});
		List<DataServiceField> createValues = new ArrayList<DataServiceField>();
		createValues.add(new DataServiceField(DataObjectField.id, id));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.programId, program.getId()));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.distributionId, URI.create(this.getIdBaseUrl() + "/data/MerlinId/12345")));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.providerId, "comcast.com"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.titleAssetId, "titleAssetId"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.titlePaid, "titlePaid"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.contentAssetId, "contentAssetId"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.provider, "provider"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.companyId, URI.create(this.getLinearBaseUrl().concat(
				"/data/Company/" + random.nextInt()))));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.availableDate, DateUtil.getDateWithZeroMilliseconds(new Date())));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.expirationDate, DateUtil.getDateWithZeroMilliseconds(new Date())));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.merlinResourceType, MerlinResourceType.Temporary));
        createValues.add(new DataServiceField(ProgramMediaAssociationField.categoryPaths, new HashSet<String>(Arrays.asList("test1", "test2"))));
        createValues.add(new DataServiceField(ProgramMediaAssociationField.mezzanineMediaId, createMediaId()));

		ProgramMediaAssociation programMediaAssociation = programMediaAssociationFactory.create();

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(programMediaAssociationClient, programMediaAssociation,
				ProgramMediaAssociationComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(ProgramMediaAssociationField.programType, program.getType()),
						new DataServiceField(ProgramMediaAssociationField.mediaGuid, programMediaAssociation.getMediaId().getMediaGuid()),
						new DataServiceField(ProgramMediaAssociationField.mediaId, programMediaAssociation.getMediaId()) });
	}

	public void testProgramMediaAssociationUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		URI id = this.persistingProgramMediaAssociationFactory.create().getId();
		this.programMediaAssociationClient.delete(id);
		List<DataServiceField> createValues = new ArrayList<DataServiceField>();
		createValues.add(new DataServiceField(DataObjectField.id, id));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.distributionId, URI.create(this.getIdBaseUrl() + "/data/MerlinId/12345")));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.providerId, "comcast.com"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.titleAssetId, "titleAssetId"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.titlePaid, "titlePaid"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.contentAssetId, "contentAssetId"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.provider, "provider"));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.companyId, URI.create(this.getLinearBaseUrl().concat(
				"/data/Company/" + random.nextInt()))));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.availableDate, DateUtil.getDateWithZeroMilliseconds(new Date())));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.expirationDate, DateUtil.getDateWithZeroMilliseconds(new Date())));
		createValues.add(new DataServiceField(ProgramMediaAssociationField.merlinResourceType, MerlinResourceType.Temporary));
        createValues.add(new DataServiceField(ProgramMediaAssociationField.categoryPaths, new HashSet<String>(Arrays.asList("test1", "test2"))));
        createValues.add(new DataServiceField(ProgramMediaAssociationField.mezzanineMediaId, createMediaId()));

		ProgramMediaAssociation programMediaAssociation = programMediaAssociationFactory.create();

		Program program = programClient.get(programMediaAssociation.getProgramId(), new String[] { ProgramField.type.getLocalName(),
				ProgramField.merlinResourceType.getLocalName() });
		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(programMediaAssociationClient, programMediaAssociation,
				ProgramMediaAssociationComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(ProgramMediaAssociationField.programType, program.getType()),
						new DataServiceField(ProgramMediaAssociationField.mediaGuid, programMediaAssociation.getMediaId().getMediaGuid()),
						new DataServiceField(ProgramMediaAssociationField.mediaId, programMediaAssociation.getMediaId()),
						new DataServiceField(ProgramMediaAssociationField.merlinResourceType, program.getMerlinResourceType()) });

	}

    public void categoryPathsCanBeNulledOut(){

        // create a PMA with some category paths:
        Set<String> categoryPaths = new HashSet<String>(Arrays.asList("one", "two"));
        ProgramMediaAssociation pma = persistingProgramMediaAssociationFactory.create(
                ProgramMediaAssociationField.categoryPaths, categoryPaths
        );

        ProgramMediaAssociation createdPma = getCreatedPma(pma);
        assertEquals(createdPma.getCategoryPaths(), categoryPaths, "ProgramMediaAssociation should have had categoryPaths created.");

        // update pma, null out category paths:
        createdPma.setCategoryPaths(null);
        createdPma.setNullFields(new NamespacedField[]{ProgramMediaAssociationField.categoryPaths});
        programMediaAssociationClient.update(createdPma);

        ProgramMediaAssociation updatedPma = getCreatedPma(createdPma);
        assertEquals(updatedPma.getCategoryPaths().size(), 0, "Updated PMA should have had categoryPaths nulled out.");
    }

    public void categoryPathsCanBeAppendedTo(){

        Set<String> categoryPaths = new HashSet<String>(Arrays.asList("one", "two"));

        ProgramMediaAssociation pma = persistingProgramMediaAssociationFactory.create(
                ProgramMediaAssociationField.categoryPaths, categoryPaths
        );
        ProgramMediaAssociation createdPma = getCreatedPma(pma);

        assertEquals(createdPma.getCategoryPaths(), categoryPaths, "ProgramMediaAssociation should have had categoryPaths created.");

        // update to add more paths:
        Set<String> morePaths = new HashSet<String>(Arrays.asList("one", "two", "three"));
        createdPma.setCategoryPaths(morePaths);
        programMediaAssociationClient.update(createdPma);

        ProgramMediaAssociation updatedPma = getCreatedPma(createdPma);
        assertTrue(updatedPma.getCategoryPaths().contains("one"), "ProgramMediaAssociation should have contained 'one'.");
        assertTrue(updatedPma.getCategoryPaths().contains("two"), "ProgramMediaAssociation should have contained 'two'.");
        assertTrue(updatedPma.getCategoryPaths().contains("three"), "ProgramMediaAssociation should have contained 'three'.");
    }

    public void categoryPathsCanBeIndividuallyRemoved(){

        Set<String> categoryPaths = new HashSet<String>(Arrays.asList("one", "two"));
        ProgramMediaAssociation pma = persistingProgramMediaAssociationFactory.create(
                ProgramMediaAssociationField.categoryPaths, categoryPaths
        );

        ProgramMediaAssociation createdPma = getCreatedPma(pma);
        assertEquals(createdPma.getCategoryPaths(), categoryPaths, "ProgramMediaAssociation should have had categoryPaths created.");

        // update to remove a path:
        Set<String> lessPaths = new HashSet<String>(Arrays.asList("one"));
        createdPma.setCategoryPaths(lessPaths);
        programMediaAssociationClient.update(createdPma);

        ProgramMediaAssociation updatedPma = getCreatedPma(createdPma);
        assertEquals(updatedPma.getCategoryPaths(), lessPaths, "ProgramMediaAssociation should have had one less path.");
    }

    private ProgramMediaAssociation getCreatedPma(ProgramMediaAssociation pma) {
        ProgramMediaAssociation createdPma = programMediaAssociationClient.get(pma.getId(), new String[]{"id", "categoryPaths"});
        assertNotNull(createdPma, "ProgramMediaAssociation should have been created");
        return createdPma;
    }

    @Test(expectedExceptions = AuthorizationException.class)
	public void mediaGuidFieldIsReadOnly() {
    	ProgramMediaAssociation pma = this.persistingProgramMediaAssociationFactory.create();
		pma.setMediaGuid("no dice");
		this.programMediaAssociationClient.update(pma);
	}
}
