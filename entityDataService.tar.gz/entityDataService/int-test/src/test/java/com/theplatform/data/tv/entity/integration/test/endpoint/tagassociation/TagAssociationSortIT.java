package com.theplatform.data.tv.entity.integration.test.endpoint.tagassociation;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.test.TagAssociationComparator;
import com.theplatform.module.exception.BadParameterException;

/**
 * User: gservente
 * 
 * Basic Sort tests for TagAssociation. TagAssosiation it doesn't has any
 * specific field sortable, so it only has tests methods for no sortable fields
 * and a base field.
 * 
 * @since 4/8/2011
 */
@Test(groups = { "sort", "tagAssociation", "other" })
public class TagAssociationSortIT extends EntityTestBase {

	private static final int TAG_ASSOACIATIONS_TO_CREATE = 4;
	private List<TagAssociation> tagAssociations;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		tagAssociations = this.tagAssociationFactory.create(TAG_ASSOACIATIONS_TO_CREATE);
		tagAssociations.get(3).setGuid("114561231");
		tagAssociations.get(0).setGuid("151252");
		tagAssociations.get(2).setGuid("21654564");
		tagAssociations.get(1).setGuid("9194562");
		tagAssociationClient.create(tagAssociations);

	}


	@Test
	public void testSortAscendingTagAssociationByGuid() throws UnknownHostException {
		// SORT EXPECTED
		List<TagAssociation> expectedSortedTagAssociations = new ArrayList<>(tagAssociations.size());
		expectedSortedTagAssociations.add(tagAssociations.get(3));
		expectedSortedTagAssociations.add(tagAssociations.get(0));
		expectedSortedTagAssociations.add(tagAssociations.get(2));
		expectedSortedTagAssociations.add(tagAssociations.get(1));

		// RETRIVE WHITH SORTING
		String sortFiedld = "guid";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<TagAssociation> retrievedTagAssociations = tagAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
		TagAssociationComparator.assertEquals(retrievedTagAssociations, expectedSortedTagAssociations);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableField() throws UnknownHostException {
		// RETRIVE WHITH SORTING
		String sortField = "entityId";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortField, sortDescending);
		tagAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
	}
}
