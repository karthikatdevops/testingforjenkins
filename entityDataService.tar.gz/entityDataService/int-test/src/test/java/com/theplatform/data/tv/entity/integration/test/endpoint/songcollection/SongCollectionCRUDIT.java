package com.theplatform.data.tv.entity.integration.test.endpoint.songcollection;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.data.objects.SongCollection;
import com.theplatform.data.tv.entity.api.fields.SongCollectionField;
import com.theplatform.data.tv.entity.api.test.SongCollectionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "songCollection", "crud" })
public class SongCollectionCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testSingleSongCollectionCrud() {
		SongCollection entity = this.songCollectionFactory.create();

		// CREATE
		SongCollection persistedEntity = this.songCollectionClient.create(entity, new String[] {});
		SongCollectionComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		SongCollection retrievedEntity = this.songCollectionClient.get(entity.getId(), new String[] {});
		SongCollectionComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setTitle(entity.getTitle() == null ? "song collection title" : entity.getTitle().concat(" updated"));
		entity.setTitle(entity.getDescription() == null ? "song collection description" : entity.getDescription().concat(" updated"));
		// not updating type because there is only one type now (4/2/2012)

		entity.setSubtype(entity.getSubtype() != null && entity.getSubtype().equals("Content") ? "Language" : "Content");
		List<URI> songIds = new ArrayList<>();
		songIds.add(this.songClient.create(songFactory.create()).getId());
		entity.setSongIds(songIds);
		entity.setPrimarySongId(songIds.get(0));

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		this.songCollectionClient.update(entity);

		SongCollection retrievedAfterUpdate = this.songCollectionClient.get(entity.getId(), new String[] {});
		SongCollectionComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = this.songCollectionClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.songCollectionClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("SongCollection should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testSongCollectionFeedCrud() throws UnknownHostException {
		List<SongCollection> entities = this.songCollectionFactory.create(5);

		// CREATE
		Feed<SongCollection> persistedEntities = this.songCollectionClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			SongCollectionComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i));

		URI[] entityIds = new URI[entities.size()];
		for (int i = 0; i < entityIds.length; i++)
			entityIds[i] = entities.get(i).getId();

		// RETRIEVE
		Feed<SongCollection> retrievedEntities = this.songCollectionClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			SongCollectionComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i));

		// DELETE
		long deletedEntities = this.songCollectionClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (SongCollection entity : entities) {
			try {
				this.songCollectionClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSongCollectionDefaultFieldValues() {
		SongCollection entity = this.songCollectionFactory.create();

		entity.setDescription(null);
		entity.setSubtype(null);
		entity.setPrimarySongId(null);
		entity.setMerlinResourceType(null);
		entity.setSongIds(null);
		SongCollection actual = this.songCollectionClient.create(entity, new String[] {});

		entity.setSongIds(new ArrayList<URI>());
		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		SongCollectionComparator.assertEquals(actual, entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] {

	new DataServiceField(DataObjectField.description, null), new DataServiceField(SongCollectionField.subtype, null),
			new DataServiceField(SongCollectionField.songIds, new ArrayList<URI>()), new DataServiceField(SongCollectionField.primarySongId, null),
			new DataServiceField(SongCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testSongCollectionCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(songCollectionClient, songCollectionFactory.create(), SongCollectionComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSongCollectionCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(songCollectionClient, songCollectionFactory.create(), SongCollectionComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSongCollectionUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		SongCollection songCollection = songCollectionFactory.create();
		List<Song> songs = songClient.create(songFactory.create(2)).getEntries();
		songCollection.setPrimarySongId(songs.get(0).getId());
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "songCollection description"));
		createValues.add(new DataServiceField(SongCollectionField.subtype, "Content"));
		createValues.add(new DataServiceField(SongCollectionField.songIds, Arrays.asList(songs.get(0).getId(), songs.get(1).getId())));
		createValues.add(new DataServiceField(SongCollectionField.primarySongId, songs.get(0).getId()));
		createValues.add(new DataServiceField(SongCollectionField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(songCollectionClient, songCollectionFactory.create(), SongCollectionComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

    @Test(groups = { TestGroup.gbTest })
	public void testSongCollectionUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		SongCollection songCollection = songCollectionFactory.create();
		List<Song> songs = songClient.create(songFactory.create(2)).getEntries();
		songCollection.setPrimarySongId(songs.get(0).getId());
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "songCollection description"));
		createValues.add(new DataServiceField(SongCollectionField.subtype, "Content"));
		createValues.add(new DataServiceField(SongCollectionField.songIds, Arrays.asList(songs.get(0).getId(), songs.get(1).getId())));
		createValues.add(new DataServiceField(SongCollectionField.primarySongId, songs.get(0).getId()));
		createValues.add(new DataServiceField(SongCollectionField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(songCollectionClient, songCollectionFactory.create(), SongCollectionComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}
}
