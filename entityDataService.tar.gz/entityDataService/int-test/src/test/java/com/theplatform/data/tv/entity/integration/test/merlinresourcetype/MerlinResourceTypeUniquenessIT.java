package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author jethrolai
 * @since 09/19/2011
 */
public class MerlinResourceTypeUniquenessIT extends EntityTestBase {
	@Test(groups = { TestGroup.testBug })
	public void testDuplicateGuidEditorialEndpoints() {

		// TODO uncomment this part when the implementation is done
		final String guid = "123419382123";

		List<Credit> credits = this.creditFactory.create(2);
		credits.get(0).setMerlinResourceType(MerlinResourceType.Editorial);
		credits.get(0).setGuid(guid);

		credits.get(1).setMerlinResourceType(MerlinResourceType.Editorial);
		credits.get(1).setGuid(guid);

		this.creditClient.create(credits);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testDuplicateGuidInactiveEndpoints() {

		// TODO uncomment this part when the implementation is done
		// final String guid = "123419382123";
		//
		// List<Credit> credits = this.creditFactory.createCredits(2);
		// credits.get(0).setMerlinResourceType(MerlinResourceType.Inactive);
		// credits.get(0).setGuid(guid);
		//
		// credits.get(1).setMerlinResourceType(MerlinResourceType.Inactive);
		// credits.get(1).setGuid(guid);
		//
		// this.creditClient.create(credits);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testDuplicateGuidEditorialAndInactiveEndpoints() {

		// TODO uncomment this part when the implementation is done
		// final String guid = "123419382123";
		//
		// List<Credit> credits = this.creditFactory.createCredits(2);
		// credits.get(0).setMerlinResourceType(MerlinResourceType.Inactive);
		// credits.get(0).setGuid(guid);
		//
		// credits.get(1).setMerlinResourceType(MerlinResourceType.Editorial);
		// credits.get(1).setGuid(guid);
		//
		// this.creditClient.create(credits);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testDuplicateGuidEditorialAndTemporaryEndpoints() {

		// TODO uncomment this part when the implementation is done
		// final String guid = "123419382123";
		//
		// List<Credit> credits = this.creditFactory.createCredits(2);
		// credits.get(0).setMerlinResourceType(MerlinResourceType.Temporary);
		// credits.get(0).setGuid(guid);
		//
		// credits.get(1).setMerlinResourceType(MerlinResourceType.Editorial);
		// credits.get(1).setGuid(guid);
		//
		// this.creditClient.create(credits);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testDuplicateGuidEditorialAndAudienceAvailableEndpoints() {

		// TODO uncomment this part when the implementation is done
		// final String guid = "123419382123";
		//
		// List<Credit> credits = this.creditFactory.createCredits(2);
		// credits.get(0).setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		// credits.get(0).setGuid(guid);
		//
		// credits.get(1).setMerlinResourceType(MerlinResourceType.Editorial);
		// credits.get(1).setGuid(guid);
		//
		// this.creditClient.create(credits);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testDuplicateGuidInactiveAndTemporaryEndpoints() {

		// TODO uncomment this part when the implementation is done
		// final String guid = "123419382123";
		//
		// List<Credit> credits = this.creditFactory.createCredits(2);
		// credits.get(0).setMerlinResourceType(MerlinResourceType.Temporary);
		// credits.get(0).setGuid(guid);
		//
		// credits.get(1).setMerlinResourceType(MerlinResourceType.Inactive);
		// credits.get(1).setGuid(guid);
		//
		// this.creditClient.create(credits);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest })
	public void testDuplicateGuidInactiveAndAudienceAvailableEndpoints() {

		// TODO uncomment this part when the implementation is done
		// final String guid = "123419382123";
		//
		// List<Credit> credits = this.creditFactory.createCredits(2);
		// credits.get(0).setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		// credits.get(0).setGuid(guid);
		//
		// credits.get(1).setMerlinResourceType(MerlinResourceType.Inactive);
		// credits.get(1).setGuid(guid);
		//
		// this.creditClient.create(credits);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testDuplicateGuidAudienceAvailableEndpoints() {

		// TODO uncomment this part when the implementation is done
		// final String guid = "123419382123";
		//
		// List<Credit> credits = this.creditFactory.createCredits(2);
		// credits.get(0).setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		// credits.get(0).setGuid(guid);
		//
		// credits.get(1).setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		// credits.get(1).setGuid(guid);
		//
		// this.creditClient.create(credits);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testDuplicateGuidTemporaryEndpoints() {

		// TODO uncomment this part when the implementation is done
		// final String guid = "123419382123";
		//
		// List<Credit> credits = this.creditFactory.createCredits(2);
		// credits.get(0).setMerlinResourceType(MerlinResourceType.Temporary);
		// credits.get(0).setGuid(guid);
		//
		// credits.get(1).setMerlinResourceType(MerlinResourceType.Temporary);
		// credits.get(1).setGuid(guid);
		//
		// this.creditClient.create(credits);
	}

	@Test(enabled = false, groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testDuplicateGuidTemporaryAndAudienceAvailableEndpoints() {

		// TODO uncomment this part when the implementation is done
		// final String guid = "123419382123";
		//
		// List<Credit> credits = this.creditFactory.createCredits(2);
		// credits.get(0).setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		// credits.get(0).setGuid(guid);
		//
		// credits.get(1).setMerlinResourceType(MerlinResourceType.Temporary);
		// credits.get(1).setGuid(guid);
		//
		// this.creditClient.create(credits);
	}
}
