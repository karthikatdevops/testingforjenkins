package com.theplatform.data.tv.entity.integration.test.endpoint.programsportsevent;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import com.theplatform.data.tv.entity.api.fields.ProgramSportsEventField;
import com.theplatform.data.tv.entity.api.test.ProgramSportsEventComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "programSportsEvent", "sort", TestGroup.gbTest })
public class ProgramSportsEventSortIT extends EntityTestBase {

	public void testProgramSportsEventSortById() {

		List<ProgramSportsEvent> programSportsEvents = this.programSportsEventFactory.create(4);

		Long id1 = this.objectIdProvider.nextId(), id2 = this.objectIdProvider.nextId(), id3 = this.objectIdProvider.nextId(), id4 = this.objectIdProvider
				.nextId();

		Assert.assertTrue(id1 < id2);
		Assert.assertTrue(id2 < id3);
		Assert.assertTrue(id3 < id4);

		programSportsEvents.get(3).setId(URI.create(this.getBaseUrl().concat("/data/ProgramSportsEvent/" + id1)));
		programSportsEvents.get(0).setId(URI.create(this.getBaseUrl().concat("/data/ProgramSportsEvent/" + id2)));
		programSportsEvents.get(1).setId(URI.create(this.getBaseUrl().concat("/data/ProgramSportsEvent/" + id3)));
		programSportsEvents.get(2).setId(URI.create(this.getBaseUrl().concat("/data/ProgramSportsEvent/" + id4)));

		programSportsEvents.set(3, this.programSportsEventClient.create(programSportsEvents.get(3), new String[] {}));
		programSportsEvents.set(0, this.programSportsEventClient.create(programSportsEvents.get(0), new String[] {}));
		programSportsEvents.set(1, this.programSportsEventClient.create(programSportsEvents.get(1), new String[] {}));
		programSportsEvents.set(2, this.programSportsEventClient.create(programSportsEvents.get(2), new String[] {}));

		List<ProgramSportsEvent> expected = new ArrayList<>(programSportsEvents.size());
		expected.add(programSportsEvents.get(3));
		expected.add(programSportsEvents.get(0));
		expected.add(programSportsEvents.get(1));
		expected.add(programSportsEvents.get(2));

		Sort requestSort = new Sort(DataObjectField.id.getLocalName(), false);
		Feed<ProgramSportsEvent> actual = this.programSportsEventClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		ProgramSportsEventComparator.assertEquals(actual, expected);
	}

	public void testProgramSportsEventSortByProgramId() {
		URI programId1 = this.programClient.create(this.programFactory.create()).getId();
		URI programId2 = this.programClient.create(this.programFactory.create()).getId();
		URI programId3 = this.programClient.create(this.programFactory.create()).getId();
		URI programId4 = this.programClient.create(this.programFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(programId1) < URIUtils.getIdValue(programId2));
		Assert.assertTrue(URIUtils.getIdValue(programId2) < URIUtils.getIdValue(programId3));
		Assert.assertTrue(URIUtils.getIdValue(programId3) < URIUtils.getIdValue(programId4));

		List<ProgramSportsEvent> programSportsEvents = this.programSportsEventFactory.create(4);
		programSportsEvents.get(0).setProgramId(programId1);
		programSportsEvents.get(3).setProgramId(programId2);
		programSportsEvents.get(1).setProgramId(programId3);
		programSportsEvents.get(2).setProgramId(programId4);

		this.programSportsEventClient.create(programSportsEvents);

		List<ProgramSportsEvent> expected = new ArrayList<>(programSportsEvents.size());
		expected.add(programSportsEvents.get(0));
		expected.add(programSportsEvents.get(3));
		expected.add(programSportsEvents.get(1));
		expected.add(programSportsEvents.get(2));

		Feed<ProgramSportsEvent> actual = this.programSportsEventClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				ProgramSportsEventField.programId.getLocalName(), false) }, null, false);

		ProgramSportsEventComparator.assertEquals(actual, expected);
	}

	public void testProgramSportsEventSortBySportsEventId() {
		URI sportsEventId1 = this.sportsEventClient.create(this.sportsEventFactory.create()).getId();
		URI sportsEventId2 = this.sportsEventClient.create(this.sportsEventFactory.create()).getId();
		URI sportsEventId3 = this.sportsEventClient.create(this.sportsEventFactory.create()).getId();
		URI sportsEventId4 = this.sportsEventClient.create(this.sportsEventFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(sportsEventId1) < URIUtils.getIdValue(sportsEventId2));
		Assert.assertTrue(URIUtils.getIdValue(sportsEventId2) < URIUtils.getIdValue(sportsEventId3));
		Assert.assertTrue(URIUtils.getIdValue(sportsEventId3) < URIUtils.getIdValue(sportsEventId4));

		List<ProgramSportsEvent> programSportsEvents = this.programSportsEventFactory.create(4);
		programSportsEvents.get(0).setSportsEventId(sportsEventId1);
		programSportsEvents.get(3).setSportsEventId(sportsEventId2);
		programSportsEvents.get(1).setSportsEventId(sportsEventId3);
		programSportsEvents.get(2).setSportsEventId(sportsEventId4);

		this.programSportsEventClient.create(programSportsEvents);

		List<ProgramSportsEvent> expected = new ArrayList<>(programSportsEvents.size());
		expected.add(programSportsEvents.get(0));
		expected.add(programSportsEvents.get(3));
		expected.add(programSportsEvents.get(1));
		expected.add(programSportsEvents.get(2));

		Feed<ProgramSportsEvent> actual = this.programSportsEventClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				ProgramSportsEventField.sportsEventId.getLocalName(), false) }, null, false);

		ProgramSportsEventComparator.assertEquals(actual, expected);
	}

}
