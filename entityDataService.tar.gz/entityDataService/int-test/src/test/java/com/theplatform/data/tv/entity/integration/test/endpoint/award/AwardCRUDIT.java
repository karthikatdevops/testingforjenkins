package com.theplatform.data.tv.entity.integration.test.endpoint.award;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.fields.AwardField;
import com.theplatform.data.tv.entity.api.test.AwardComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * GreenBuild test for CRUD operations of Award
 * 
 * @author clai200
 * @since 4/5/2011
 * 
 */

@Test(groups = { "crud", "award" })
public class AwardCRUDIT extends EntityTestBase {



	@Test(groups = { TestGroup.gbTest })
	public void crudSingleAward() throws UnknownHostException {
		Award entity = this.awardFactory.create();

		// CREATE
		Award persistedEntity = this.awardClient.create(entity);
		assertEquals(persistedEntity.getId(), entity.getId(), "Award ids should match after creation");

		// RETRIEVE
		Award retrievedEntity = this.awardClient.get(entity.getId(), new String[] {});
		AwardComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setDescription(entity.getDescription() != null ? entity.getDescription() + "updated" : "award description");
		entity.setTitle(entity.getTitle() + "updated");
		entity.setRank(entity.getRank() != null ? entity.getRank() + 1 : 1);
		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		this.awardClient.update(entity);

		Award retrievedAfterUpdate = this.awardClient.get(entity.getId(), new String[] {});
		AwardComparator.assertEquals(retrievedAfterUpdate, entity);
		assertFalse(retrievedEntity.getDescription().equals(retrievedAfterUpdate.getDescription()));

		// DELETE
		long deletedObjects = this.awardClient.delete(entity.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.awardClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("Award should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudAwardFeed() throws UnknownHostException {
		List<Award> entities = this.awardFactory.create(15);
		@SuppressWarnings({ "unchecked"})
		URI[] entityIds = (URI[]) CollectionUtils.collect(entities, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<Award> persistedEntities = this.awardClient.create(entities);
		ComparatorUtils.assertIdsAreEqual(entities, persistedEntities);

		// RETRIEVE
		Feed<Award> retrievedEntities = this.awardClient.get(entityIds, new String[] {});
		AwardComparator.assertEquals(retrievedEntities, entities);

		// DELETE
		long deletedEntities = this.awardClient.delete(entityIds);
		assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (Award entity : entities) {
			try {
				this.awardClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAwardDefaultFieldValues() {
		Award entity = this.awardFactory.create();

		entity.setDescription(null);
		entity.setRank(null);
		entity.setMerlinResourceType(null);

		this.awardClient.create(entity);

		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		AwardComparator.assertEquals(this.awardClient.get(entity.getId(), new String[] {}), entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(DataObjectField.description, null),
			new DataServiceField(AwardField.rank, null),
			// If not set on create defaults to 'AudienceAvailable', or
			// 'Editorial' if
			// ID has editorial suffix
			new DataServiceField(AwardField.merlinResourceType, MerlinResourceType.AudienceAvailable), };

	@Test(groups = { TestGroup.gbTest })
	public void testAwardCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(awardClient, awardFactory.create(), AwardComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAwardCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(awardClient, awardFactory.create(), AwardComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAwardUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "award description"));
		createValues.add(new DataServiceField(AwardField.rank, 1));
		createValues.add(new DataServiceField(AwardField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(awardClient, awardFactory.create(), AwardComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testAwardUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "award description"));
		createValues.add(new DataServiceField(AwardField.rank, 1));
		createValues.add(new DataServiceField(AwardField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(awardClient, awardFactory.create(), AwardComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), null);
	}

}
