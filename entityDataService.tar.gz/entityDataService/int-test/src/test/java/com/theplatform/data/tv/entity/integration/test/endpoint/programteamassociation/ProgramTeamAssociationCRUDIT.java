package com.theplatform.data.tv.entity.integration.test.endpoint.programteamassociation;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.api.fields.ProgramTeamAssociationField;
import com.theplatform.data.tv.entity.api.test.ProgramTeamAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * @since 4/7/2011
 */

@Test(groups = { "programTeamAssociation", "crud" })
public class ProgramTeamAssociationCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void crudProgramTeamAssociationEntry() throws UnknownHostException {
		ProgramTeamAssociation expected = this.programTeamAssociationFactory.create();

		// CREATE
		ProgramTeamAssociation persistedProgramTeamAssociation = this.programTeamAssociationClient.create(expected, new String[] {});
		ProgramTeamAssociationComparator.assertEquals(expected, persistedProgramTeamAssociation);

		// RETRIEVE
		ProgramTeamAssociation retrievedProgramTeamAssociation = this.programTeamAssociationClient
				.get(persistedProgramTeamAssociation.getId(), new String[] {});
		ProgramTeamAssociationComparator.assertEquals(retrievedProgramTeamAssociation, expected);

		// UPDATE ALL FIELDS
		expected.setCompetition(true);
		expected.setHomeAway("Away");

		this.programTeamAssociationClient.update(expected);
		ProgramTeamAssociation retrievedAfterUpdate = this.programTeamAssociationClient.get(expected.getId(), new String[] {});
		ProgramTeamAssociationComparator.assertEquals(retrievedAfterUpdate, expected);

		// DELETE
		long deletedObjects = this.programTeamAssociationClient.delete(expected.getId());
		Assert.assertEquals(1, deletedObjects);
		try {
			this.programTeamAssociationClient.get(expected.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		Assert.fail("ProgramTeamAssociation should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudProgramTeamAssociationFeed() throws UnknownHostException {
		List<ProgramTeamAssociation> inputProgramTeamAssociations = this.programTeamAssociationFactory.create(5);

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] programTeamAssociationIds = (URI[]) CollectionUtils.collect(inputProgramTeamAssociations, TransformerUtils.invokerTransformer("getId")).toArray(
				new URI[] {});

		// CREATE
		Feed<ProgramTeamAssociation> persistedProgramTeamAssociations = this.programTeamAssociationClient.create(inputProgramTeamAssociations);
		ComparatorUtils.assertIdsAreEqual(inputProgramTeamAssociations, persistedProgramTeamAssociations.getEntries());

		// RETRIEVE
		Feed<ProgramTeamAssociation> retrievedProgramTeamAssociations = this.programTeamAssociationClient.get(programTeamAssociationIds, new String[] {});
		ProgramTeamAssociationComparator.assertEquals(retrievedProgramTeamAssociations, inputProgramTeamAssociations);

		// UPDATE
		inputProgramTeamAssociations.get(0).setHomeAway("Home");
		inputProgramTeamAssociations.get(3).setHomeAway("Neutral");
		for (ProgramTeamAssociation inputProgramTeamAssociation : inputProgramTeamAssociations) {
			inputProgramTeamAssociation.setCompetition(true);
		}

		this.programTeamAssociationClient.update(inputProgramTeamAssociations);
		Feed<ProgramTeamAssociation> retrievedAfterUpdate = this.programTeamAssociationClient.get(programTeamAssociationIds, new String[] {});
		ProgramTeamAssociationComparator.assertEquals(retrievedAfterUpdate, inputProgramTeamAssociations);

		// DELETE
		long deletedProgramTeamAssociations = this.programTeamAssociationClient.delete(programTeamAssociationIds);
		Assert.assertEquals(inputProgramTeamAssociations.size(), deletedProgramTeamAssociations);
		long notFoundProgramTeamAssociations = 0;
		for (ProgramTeamAssociation programTeamAssociation : inputProgramTeamAssociations) {
			try {
				this.programTeamAssociationClient.get(programTeamAssociation.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundProgramTeamAssociations++;
			}
		}
		Assert.assertEquals(notFoundProgramTeamAssociations, deletedProgramTeamAssociations, "Still found ProgramTeamAssociation after deleting");
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(ProgramTeamAssociationField.homeAway, null),
			new DataServiceField(ProgramTeamAssociationField.competition, null),
			// default to leastVisible(Program.merlinResourceType,
			// sportsTeam.merlinResourceType)
			new DataServiceField(ProgramTeamAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable), };

	@Test(groups = { TestGroup.gbTest })
	public void testProgramTeamAssociationCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(programTeamAssociationClient, programTeamAssociationFactory.create(),
				ProgramTeamAssociationComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramTeamAssociationCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(programTeamAssociationClient, programTeamAssociationFactory.create(),
				ProgramTeamAssociationComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramTeamAssociationUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ProgramTeamAssociationField.homeAway, "Home"));
		createValues.add(new DataServiceField(ProgramTeamAssociationField.competition, true));
		createValues.add(new DataServiceField(ProgramTeamAssociationField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(programTeamAssociationClient, programTeamAssociationFactory.create(),
				ProgramTeamAssociationComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testProgramTeamAssociationUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ProgramTeamAssociationField.homeAway, "Home"));
		createValues.add(new DataServiceField(ProgramTeamAssociationField.competition, true));
		createValues.add(new DataServiceField(ProgramTeamAssociationField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(programTeamAssociationClient, programTeamAssociationFactory.create(),
				ProgramTeamAssociationComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}
}
