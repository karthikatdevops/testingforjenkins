package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.DateOnlyUtil;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.client.query.program.ByOriginalAirDate;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "program", "query" })
public class ProgramQueryByOriginalAirDateIT extends EntityTestBase {

	public void testProgramQueryByOriginalAirDateOnlyNoMatch() {

		final DateOnly originalAirDate1 = DateOnlyUtil.getDateOnly("12/04/2012");
		final DateOnly originalAirDate2 = DateOnlyUtil.getDateOnly("12/04/2011");

		this.programClient.create(this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate1)), new String[] {});

		Query[] queries = new Query[] { new ByOriginalAirDate(originalAirDate2) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Program should be found");
	}
	
	public void testProgramQueryByOriginalAirDateOnlyListNoMatch() {
		
		final DateOnly originalAirDate1 = DateOnlyUtil.getDateOnly("12/04/2012");
		final DateOnly originalAirDate2 = DateOnlyUtil.getDateOnly("12/04/2011");
		final DateOnly originalAirDate3 = DateOnlyUtil.getDateOnly("12/04/2010");
		
		this.programClient.create(this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate1)), new String[] {});
		
		ArrayList<DateOnly> unexpectedDates = new ArrayList<>();
		unexpectedDates.add(originalAirDate2);
		unexpectedDates.add(originalAirDate3);
		
		Query[] queries = new Query[] { new ByOriginalAirDate(unexpectedDates) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Program should be found");
	}

	public void testProgramQueryByOriginalAirDateOnlyOneMatch() {

		final DateOnly originalAirDate1 = DateOnlyUtil.getDateOnly("12/04/2012");
		final DateOnly originalAirDate2 = DateOnlyUtil.getDateOnly("12/04/2011");

		this.programClient.create(this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate1)));

		Program expectedProgram = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate2)), new String[] {});
		Query[] queries = new Query[] { new ByOriginalAirDate(originalAirDate2) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Program should be found");

		ProgramComparator.assertEquals(results.getEntries().get(0), expectedProgram);
	}
	
	public void testProgramQueryByOriginalAirDateOnlyListOneMatch() {
		
		final DateOnly originalAirDate1 = DateOnlyUtil.getDateOnly("12/04/2012");
		final DateOnly originalAirDate2 = DateOnlyUtil.getDateOnly("12/04/2011");
		final DateOnly originalAirDate3 = DateOnlyUtil.getDateOnly("12/04/2010");
		
		ArrayList<DateOnly> expectedDates = new ArrayList<>();
		expectedDates.add(originalAirDate2);
		expectedDates.add(originalAirDate3);
		
		this.programClient.create(this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate1)));
		
		Program expectedProgram = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate2)), new String[] {});
		Query[] queries = new Query[] { new ByOriginalAirDate(expectedDates) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Program should be found");
		
		ProgramComparator.assertEquals(results.getEntries().get(0), expectedProgram);
	}

	public void testProgramQueryByOriginalAirDateOnlyMultipleMatch() {

		final DateOnly originalAirDate1 = DateOnlyUtil.getDateOnly("12/04/2012");
		final DateOnly originalAirDate2 = DateOnlyUtil.getDateOnly("12/04/2011");

		Program programMediaAssociation1 = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate1)), new String[] {});
		Program programMediaAssociation2 = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate1)), new String[] {});
		this.programClient.create(this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate2)));

		Query[] queries = new Query[] { new ByOriginalAirDate(originalAirDate1) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Programs should be found");

		Map<URI, Program> resultMap = new HashMap<>();
		for (Program Program : results.getEntries())
			resultMap.put(Program.getId(), Program);

		ProgramComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}
	
	public void testProgramQueryByOriginalAirDateOnlyListMultipleMatch() {
		
		final DateOnly originalAirDate1 = DateOnlyUtil.getDateOnly("12/04/2012");
		final DateOnly originalAirDate2 = DateOnlyUtil.getDateOnly("12/04/2011");
		final DateOnly originalAirDate3 = DateOnlyUtil.getDateOnly("12/04/2010");
		
		Program programMediaAssociation1 = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate1)), new String[] {});
		Program programMediaAssociation2 = this.programClient.create(
				this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate2)), new String[] {});
		this.programClient.create(this.programFactory.create(new DataServiceField(ProgramField.originalAirDate, originalAirDate3)));
		
		ArrayList<DateOnly> expectedDates = new ArrayList<>();
		expectedDates.add(originalAirDate1);
		expectedDates.add(originalAirDate2);
		
		Query[] queries = new Query[] { new ByOriginalAirDate(expectedDates) };
		Feed<Program> results = this.programClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Programs should be found");
		
		Map<URI, Program> resultMap = new HashMap<>();
		for (Program Program : results.getEntries())
			resultMap.put(Program.getId(), Program);
		
		ProgramComparator.assertEquals(resultMap.get(programMediaAssociation1.getId()), programMediaAssociation1);
		ProgramComparator.assertEquals(resultMap.get(programMediaAssociation2.getId()), programMediaAssociation2);
	}

}
