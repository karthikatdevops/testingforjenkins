package com.theplatform.data.tv.entity.integration.test.endpoint.entitymessage;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.EntityMessage;
import com.theplatform.data.tv.entity.api.test.EntityMessageComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/23/15
 */
@Test(groups = {"entitymessage", "sort", TestGroup.gbTest})
public class EntityMessageSortIT extends EntityTestBase {

    private static final int NUM_TO_CREATE = 4;
    private List<EntityMessage> entityList;

    @BeforeMethod(alwaysRun = true)
    public void setUp() throws UnknownHostException {
        // CREATE
        entityList = entityMessageFactory.create(NUM_TO_CREATE);
        entityList.get(0).setEntityId(URI.create(baseUrl + "/data/Program/" + objectIdProvider.nextId()));
        entityList.get(0).setTitle("2");
        entityList.get(0).setPriority(10);
        entityList.get(1).setEntityId(URI.create(baseUrl + "/data/Program/" + objectIdProvider.nextId()));
        entityList.get(1).setTitle("4");
        entityList.get(1).setPriority(7);
        entityList.get(2).setEntityId(URI.create(baseUrl + "/data/Program/" + objectIdProvider.nextId()));
        entityList.get(2).setTitle("3");
        entityList.get(2).setPriority(1);
        entityList.get(3).setEntityId(URI.create(baseUrl + "/data/Program/" + objectIdProvider.nextId()));
        entityList.get(3).setTitle("1");
        entityList.get(3).setPriority(100);
        entityMessageClient.create(entityList, new String[]{});
    }

    @Test
    public void testSortAscendingByTitle() throws UnknownHostException {
        // SORT EXPECTED
        List<EntityMessage> expectedSortedEntities = new ArrayList<>(NUM_TO_CREATE);
        expectedSortedEntities.add(entityList.get(3));
        expectedSortedEntities.add(entityList.get(0));
        expectedSortedEntities.add(entityList.get(2));
        expectedSortedEntities.add(entityList.get(1));

        // RETRIEVE WITH SORTING
        Sort requestSort = new Sort("title", false);
        Feed<EntityMessage> retreivedEntities = entityMessageClient.getAll(new String[]{}, new Query[]{}, new Sort[]{requestSort}, null, false);

        EntityMessageComparator comparator = new EntityMessageComparator();
        comparator.assertEquals(retreivedEntities, expectedSortedEntities);
    }

    @Test
    public void testSortAscendingByEntityId() throws UnknownHostException {
        // SORT EXPECTED
        List<EntityMessage> expectedSortedEntities = new ArrayList<>(NUM_TO_CREATE);
        expectedSortedEntities.add(entityList.get(0));
        expectedSortedEntities.add(entityList.get(1));
        expectedSortedEntities.add(entityList.get(2));
        expectedSortedEntities.add(entityList.get(3));

        // RETRIEVE WITH SORTING
        Sort requestSort = new Sort("entityId", false);
        Feed<EntityMessage> retreivedEntities = entityMessageClient.getAll(new String[]{}, new Query[]{}, new Sort[]{requestSort}, null, false);

        EntityMessageComparator comparator = new EntityMessageComparator();
        comparator.assertEquals(retreivedEntities, expectedSortedEntities);
    }

    @Test
    public void testSortAscendingByPriority() throws UnknownHostException {
        // SORT EXPECTED
        List<EntityMessage> expectedSortedEntities = new ArrayList<>(NUM_TO_CREATE);
        expectedSortedEntities.add(entityList.get(2));
        expectedSortedEntities.add(entityList.get(1));
        expectedSortedEntities.add(entityList.get(0));
        expectedSortedEntities.add(entityList.get(3));

        // RETRIEVE WITH SORTING
        Sort requestSort = new Sort("priority", false);
        Feed<EntityMessage> retreivedEntities = entityMessageClient.getAll(new String[]{}, new Query[]{}, new Sort[]{requestSort}, null, false);

        EntityMessageComparator comparator = new EntityMessageComparator();
        comparator.assertEquals(retreivedEntities, expectedSortedEntities);
    }

    @Test(expectedExceptions = BadParameterException.class)
    public void testSortByNonSortableField() throws UnknownHostException {
        // RETRIVE WHITH SORTING
        String sortField = "mediumSynopsis";
        boolean sortDescending = false;
        Sort requestSort = new Sort(sortField, sortDescending);
        entityMessageClient.getOwned(new String[]{}, new Query[]{}, new Sort[]{requestSort}, null, false);
    }
}