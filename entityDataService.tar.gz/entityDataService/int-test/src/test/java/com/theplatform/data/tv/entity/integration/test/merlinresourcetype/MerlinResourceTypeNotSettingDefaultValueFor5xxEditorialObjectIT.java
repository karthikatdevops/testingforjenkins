package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.objects.ManagedMerlinDataObject;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBMerlinResourceTypeCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Album;
import com.theplatform.data.tv.entity.api.data.objects.AlbumCredit;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.data.objects.RelatedAlbum;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPerson;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import com.theplatform.data.tv.entity.api.data.objects.RelatedSong;
import com.theplatform.data.tv.entity.api.data.objects.Review;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.data.objects.SongCollection;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.SportsLeague;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.data.objects.TvSeason;
import com.theplatform.data.tv.entity.api.fields.AlbumField;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseField;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import com.theplatform.data.tv.entity.api.fields.EntityCollectionField;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.entity.api.fields.ReviewField;
import com.theplatform.data.tv.entity.api.fields.SongCollectionField;
import com.theplatform.data.tv.entity.api.fields.SongField;
import com.theplatform.data.tv.entity.api.fields.SportsEventField;
import com.theplatform.data.tv.entity.api.fields.SportsTeamField;
import com.theplatform.data.tv.entity.api.test.AlbumComparator;
import com.theplatform.data.tv.entity.api.test.AlbumCreditComparator;
import com.theplatform.data.tv.entity.api.test.AlbumReleaseComparator;
import com.theplatform.data.tv.entity.api.test.AlbumReleaseSongAssociationComparator;
import com.theplatform.data.tv.entity.api.test.AwardAssociationComparator;
import com.theplatform.data.tv.entity.api.test.AwardComparator;
import com.theplatform.data.tv.entity.api.test.CreditComparator;
import com.theplatform.data.tv.entity.api.test.EntityCollectionComparator;
import com.theplatform.data.tv.entity.api.test.InstitutionComparator;
import com.theplatform.data.tv.entity.api.test.PersonComparator;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.api.test.ProgramMediaAssociationComparator;
import com.theplatform.data.tv.entity.api.test.ProgramSongAssociationComparator;
import com.theplatform.data.tv.entity.api.test.ProgramTeamAssociationComparator;
import com.theplatform.data.tv.entity.api.test.RelatedAlbumComparator;
import com.theplatform.data.tv.entity.api.test.RelatedPersonComparator;
import com.theplatform.data.tv.entity.api.test.RelatedProgramComparator;
import com.theplatform.data.tv.entity.api.test.RelatedSongComparator;
import com.theplatform.data.tv.entity.api.test.ReviewComparator;
import com.theplatform.data.tv.entity.api.test.SongCollectionComparator;
import com.theplatform.data.tv.entity.api.test.SongComparator;
import com.theplatform.data.tv.entity.api.test.SongCreditComparator;
import com.theplatform.data.tv.entity.api.test.SportsEventComparator;
import com.theplatform.data.tv.entity.api.test.SportsLeagueComparator;
import com.theplatform.data.tv.entity.api.test.SportsTeamComparator;
import com.theplatform.data.tv.entity.api.test.TagComparator;
import com.theplatform.data.tv.entity.api.test.TvSeasonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.data.tv.image.api.fields.ImageAssociationField;
import com.theplatform.data.tv.image.api.test.ImageAssociationComparator;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.test.TagAssociationComparator;
import com.theplatform.media.api.data.objects.MediaFile;
import com.theplatform.media.api.data.objects.Rating;

@Test(groups = { TestGroup.gbTest, "merlinResourceType" })
public class MerlinResourceTypeNotSettingDefaultValueFor5xxEditorialObjectIT extends EntityTestBase {

	@Test(dataProvider = "editorialEndpointsAndClients")
	public void testNotSetingDefaultValueForEditorialEndpointWith5XXIDSuffix(ManagedMerlinDataObject expected, String endpointName,
			DataServiceClient<ManagedMerlinDataObject> client, @SuppressWarnings("rawtypes") Class comparatorClass, DataServiceField[] collectionFields)
			throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {

		GBMerlinResourceTypeCommonTestCollection.testNotSettingDefaultValueForEditorialEndpointWith5XXIDSuffix(this.getBaseUrl(), objectIdProvider, expected, endpointName, client, comparatorClass, collectionFields);

	}

	@DataProvider
	public Object[][] editorialEndpointsAndClients() {
		//Program.type should always be required. 
		return new Object[][] {
				new Object[] { new Credit(), "Credit", creditClient, CreditComparator.class, new DataServiceField[] {new DataServiceField(CreditField.imageIds, new ArrayList<URI>()), new DataServiceField(CreditField.mainImages, new HashMap<String, MediaFile>()), new DataServiceField(CreditField.selectedImages, new ArrayList<MainImageInfo>())} },
				new Object[] { new Person(), "Person", personClient, PersonComparator.class, new DataServiceField[]{new DataServiceField(PersonField.knownFor, new ArrayList<String>()), new DataServiceField(PersonField.credits, new ArrayList<CreditAssociation>()), new DataServiceField(PersonField.aliases, new ArrayList<String>()), new DataServiceField(PersonField.imageIds, new ArrayList<URI>()), new DataServiceField(PersonField.mainImages, new HashMap<String, MediaFile>()), new DataServiceField(PersonField.selectedImages, new ArrayList<MainImageInfo>())} },
//				new Object[] { new Program(), "Program", programClient, ProgramComparator.class, new DataServiceField[]{new DataServiceField(ProgramField.contentRatings, new ArrayList<Rating>()), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()),new DataServiceField(ProgramField.tagIds, new ArrayList<URI>()),new DataServiceField(ProgramField.imageIds, new ArrayList<URI>()), new DataServiceField(ProgramField.mainImages, new HashMap<String, MediaFile>()), new DataServiceField(ProgramField.selectedImages, new ArrayList<MainImageInfo>())} },
				new Object[] { new ProgramMediaAssociation(), "ProgramMediaAssociation",programMediaAssociationClient, ProgramMediaAssociationComparator.class, null },
				new Object[] { new Review(), "Review", reviewClient, ReviewComparator.class, new DataServiceField[]{new DataServiceField(ReviewField.contentRatings, new ArrayList<Rating>())} },
				new Object[] { new TvSeason(), "TvSeason", tvSeasonClient, TvSeasonComparator.class, null },
				new Object[] { new RelatedProgram(), "RelatedProgram", relatedProgramClient, RelatedProgramComparator.class, null },
				new Object[] { new EntityCollection(), "EntityCollection", entityCollectionClient, EntityCollectionComparator.class, new DataServiceField[]{new DataServiceField(EntityCollectionField.entityIds, new ArrayList<URI>()),new DataServiceField(EntityCollectionField.mainImages, new HashMap<String, MediaFile>()), new DataServiceField(EntityCollectionField.selectedImages, new ArrayList<MainImageInfo>()), new DataServiceField(EntityCollectionField.primaryEntities, new HashMap<String, URI>())} },
				new Object[] { new Tag(), "Tag", tagClient, TagComparator.class, null },
				new Object[] { new SportsTeam(), "SportsTeam", sportsTeamClient, SportsTeamComparator.class , new DataServiceField[]{new DataServiceField(SportsTeamField.imageIds, new ArrayList<URI>()), new DataServiceField(SportsTeamField.mainImages, new HashMap<String, MediaFile>()), new DataServiceField(SportsTeamField.selectedImages, new ArrayList<MainImageInfo>()), new DataServiceField(SportsTeamField.tagIds, new ArrayList<URI>())}},
				new Object[] { new SportsEvent(), "SportsEvent", sportsEventClient, SportsEventComparator.class, new DataServiceField[]{new DataServiceField(SportsEventField.programIds, new ArrayList<URI>()),new DataServiceField(SportsEventField.imageIds, new ArrayList<URI>()), new DataServiceField(SportsEventField.mainImages, new HashMap<String, MediaFile>()), new DataServiceField(SportsEventField.selectedImages, new ArrayList<MainImageInfo>())} },
				new Object[] { new ProgramTeamAssociation(), "ProgramTeamAssociation", programTeamAssociationClient, ProgramTeamAssociationComparator.class, null },
				new Object[] { new SportsLeague(), "SportsLeague", sportsLeagueClient, SportsLeagueComparator.class ,null},
				new Object[] { new Award(), "Award", awardClient, AwardComparator.class ,null},
				new Object[] { new Institution(), "Institution", institutionClient, InstitutionComparator.class, null },
				new Object[] { new AwardAssociation(), "AwardAssociation", awardAssociationClient, AwardAssociationComparator.class, null },
				new Object[] { new Album(), "Album", albumClient, AlbumComparator.class, new DataServiceField[]{new DataServiceField(AlbumField.primaryPersonIds, new ArrayList<URI>()), new DataServiceField(AlbumField.imageIds, new ArrayList<URI>()), new DataServiceField(AlbumField.tagIds, new ArrayList<URI>())} },
				new Object[] { new AlbumCredit(), "AlbumCredit", albumCreditClient, AlbumCreditComparator.class, null },
				new Object[] { new AlbumRelease(), "AlbumRelease", albumReleaseClient, AlbumReleaseComparator.class, new DataServiceField[]{new DataServiceField(AlbumReleaseField.contentRatings, new ArrayList<Rating>()), new DataServiceField(AlbumReleaseField.imageIds, new ArrayList<URI>()), new DataServiceField(AlbumReleaseField.tagIds, new ArrayList<URI>())} },
				new Object[] { new Song(), "Song", songClient, SongComparator.class , new DataServiceField[]{new DataServiceField(SongField.primaryPersonIds, new ArrayList<URI>()), new DataServiceField(SongField.imageIds, new ArrayList<URI>()), new DataServiceField(SongField.tagIds, new ArrayList<URI>())}},
				new Object[] { new SongCredit(), "SongCredit", songCreditClient, SongCreditComparator.class,null },
				new Object[] { new RelatedPerson(), "RelatedPerson", relatedPersonClient, RelatedPersonComparator.class, null },
				new Object[] { new RelatedAlbum(), "RelatedAlbum", relatedAlbumClient, RelatedAlbumComparator.class, null },
				new Object[] { new RelatedSong(), "RelatedSong", relatedSongClient, RelatedSongComparator.class, null },
				new Object[] { new AlbumReleaseSongAssociation(), "AlbumReleaseSongAssociation", albumReleaseSongAssociationClient,AlbumReleaseSongAssociationComparator.class, null },
				new Object[] { new ProgramSongAssociation(), "ProgramSongAssociation", programSongAssociationClient, ProgramSongAssociationComparator.class , null},
				new Object[] { new SongCollection(), "SongCollection", songCollectionClient, SongCollectionComparator.class, new DataServiceField[]{new DataServiceField(SongCollectionField.songIds, new ArrayList<URI>())} },
				new Object[] { new TagAssociation(), "TagAssociation", tagAssociationClient, TagAssociationComparator.class, null },
				new Object[] { new ImageAssociation(), "ImageAssociation", imageAssociationClient, ImageAssociationComparator.class, new DataServiceField[]{new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, new ArrayList<URI>()), new DataServiceField(ImageAssociationField.preferForMainImageTypes, new ArrayList<String>())} },
				};
	}
	public void testProgramNotSetingDefaultValueForEditorialEndpointWith5XXIDSuffix()
			throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {

		for (ProgramType type : ProgramType.values()){ 
			Program expected = new Program(); 
			expected.setType(type);
			expected.setId(URI.create((this.getBaseUrl().concat("/data/Program/") + (objectIdProvider.nextId() + 500))));
			
			Program actual = programClient.create(expected, new String[]{}); 
			
			expected.setMerlinResourceType(MerlinResourceType.Editorial);
			expected.setContentRatings(new ArrayList<Rating>());
			expected.setCredits(new ArrayList<CreditAssociation>());
			expected.setTagIds(new ArrayList<URI>());
			expected.setImageIds(new ArrayList<URI>());
			expected.setMainImages(new HashMap<String, MediaFile>());
			expected.setSelectedImages(new ArrayList<MainImageInfo>());
			
			ProgramComparator.assertEquals(actual, expected);
			
		}
		
	}

}
