package com.theplatform.data.tv.entity.integration.test.endpoint.sportsleague;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SportsLeague;
import com.theplatform.data.tv.entity.api.test.SportsLeagueComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */
@Test(groups = { "sportsLeague", "sort", TestGroup.gbTest })
public class SportsLeagueSortIT extends EntityTestBase {

	public void testSportsLeagueSortByTitle() {
		List<SportsLeague> sportsLeagues = sportsLeagueFactory.create(4);
		sportsLeagues.get(0).setTitle("A");
		sportsLeagues.get(2).setTitle("B");
		sportsLeagues.get(3).setTitle("C");
		sportsLeagues.get(1).setTitle("D");

		this.sportsLeagueClient.create(sportsLeagues);

		List<SportsLeague> expectedSportsLeagues = new ArrayList<>(sportsLeagues.size());
		expectedSportsLeagues.add(sportsLeagues.get(0));
		expectedSportsLeagues.add(sportsLeagues.get(2));
		expectedSportsLeagues.add(sportsLeagues.get(3));
		expectedSportsLeagues.add(sportsLeagues.get(1));

		Feed<SportsLeague> retrievedSportsLeagues = this.sportsLeagueClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("title", false) },
				null, false);

		SportsLeagueComparator.assertEquals(retrievedSportsLeagues, expectedSportsLeagues);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSportsLeagueSortByInvalidFields() {
		this.sportsLeagueClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("merlinResourceType", false) }, null, false);
	}
}
