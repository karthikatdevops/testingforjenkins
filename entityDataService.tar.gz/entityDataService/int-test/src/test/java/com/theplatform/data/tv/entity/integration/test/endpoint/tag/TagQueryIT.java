package com.theplatform.data.tv.entity.integration.test.endpoint.tag;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.StringUtil;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.tag.ByName;
import com.theplatform.data.tv.entity.api.client.query.tag.ByType;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.fields.TagField;
import com.theplatform.data.tv.entity.api.test.TagComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

//TODO MERLIN-XXXX byName query doesn't work
@Test(groups = { "tag", TestGroup.gbTest, "query" })
public class TagQueryIT extends EntityTestBase {

	@Test(groups = TestGroup.bug)
	public void testTagQueryByNameNoMatch() {

		Tag entity = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, "name".concat("" + new Random().nextInt()))),
				new String[] {});
		Query[] queries = new Query[] { new ByName(entity.getName().concat(StringUtil.generateRandomString(2))) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Tag should be found");
	}

	@Test(groups = TestGroup.bug)
	public void testTagQueryByNameListNoMatch() {

		Tag entity = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, "name".concat("" + new Random().nextInt()))),
				new String[] {});
		Query[] queries = new Query[] { new ByName(Arrays.asList(entity.getName().concat(StringUtil.generateRandomString(2)))) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Tag should be found");
	}

	@Test(groups = TestGroup.bug)
	public void testTagQueryByNameOneMatch() {

		final String name1 = "name 1".concat(StringUtil.generateRandomString());
		final String name2 = "name 2".concat(StringUtil.generateRandomString());

		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, name1)));

		Tag expectedTag = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, name2)), new String[] {});
		Query[] queries = new Query[] { new ByName(name2) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Tag should be found");

		TagComparator.assertEquals(results.getEntries().get(0), expectedTag);
	}

	@Test(groups = TestGroup.bug)
	public void testTagQueryByNameListOneMatch() {

		final String name1 = "name 1".concat(StringUtil.generateRandomString());
		final String name2 = "name 2".concat(StringUtil.generateRandomString());

		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, name1)));

		Tag expectedTag = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, name2)), new String[] {});
		Query[] queries = new Query[] { new ByName(Arrays.asList(name2, "dummy name".concat(StringUtil.generateRandomString()))) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Tag should be found");

		TagComparator.assertEquals(results.getEntries().get(0), expectedTag);
	}

	@Test(groups = TestGroup.bug)
	public void testTagQueryByNameMultipleMatch() {

		final String name1 = "name 1".concat(StringUtil.generateRandomString());

		Tag tag1 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, name1)), new String[] {});
		Tag tag2 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, name1)), new String[] {});
		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, "dummy name".concat(StringUtil.generateRandomString()))));

		Query[] queries = new Query[] { new ByName(name1) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Tags should be found");

		Map<URI, Tag> resultMap = new HashMap<>();
		for (Tag Tag : results.getEntries())
			resultMap.put(Tag.getId(), Tag);

		TagComparator.assertEquals(resultMap.get(tag1.getId()), tag1);
		TagComparator.assertEquals(resultMap.get(tag2.getId()), tag2);
	}

	@Test(groups = TestGroup.bug)
	public void testTagQueryByNameListMultipleMatch() {

		final String name1 = "name1".concat(StringUtil.generateRandomString());
		final String name2 = "name 2".concat(StringUtil.generateRandomString());

		Tag tag1 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, name1)), new String[] {});
		Tag tag2 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, name2)), new String[] {});
		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.name, "dummy name".concat(StringUtil.generateRandomString()))));

		Query[] queries = new Query[] { new ByName(Arrays.asList(name1, name2)) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Tags should be found");

		Map<URI, Tag> resultMap = new HashMap<>();
		for (Tag Tag : results.getEntries())
			resultMap.put(Tag.getId(), Tag);

		TagComparator.assertEquals(resultMap.get(tag1.getId()), tag1);
		TagComparator.assertEquals(resultMap.get(tag2.getId()), tag2);
	}

	public void testTagQueryByTypeNoMatch() {

		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, "Keyword")), new String[] {});
		Query[] queries = new Query[] { new ByType("Country") };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Tag should be found");
	}

	public void testTagQueryByTypeListNoMatch() {

		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, "Genre")), new String[] {});
		Query[] queries = new Query[] { new ByType(Arrays.asList("Music")) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No Tag should be found");
	}

	public void testTagQueryByTypeOneMatch() {

		final String type1 = "Tone";
		final String type2 = "Type";

		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, type1)));

		Tag expectedTag = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, type2)), new String[] {});
		Query[] queries = new Query[] { new ByType(type2) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Tag should be found");

		TagComparator.assertEquals(results.getEntries().get(0), expectedTag);
	}

	public void testTagQueryByTypeListOneMatch() {

		final String type1 = "Company";
		final String type2 = "KidsTheme";

		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, type1)));

		Tag expectedTag = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, type2)), new String[] {});
		Query[] queries = new Query[] { new ByType(Arrays.asList(type2, "Period")) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one Tag should be found");

		TagComparator.assertEquals(results.getEntries().get(0), expectedTag);
	}

	public void testTagQueryByTypeMultipleMatch() {

		final String type1 = "Decade";

		Tag tag1 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, type1)), new String[] {});
		Tag tag2 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, type1)), new String[] {});
		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, "ITheme")));

		Query[] queries = new Query[] { new ByType(type1) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Tags should be found");

		Map<URI, Tag> resultMap = new HashMap<>();
		for (Tag Tag : results.getEntries())
			resultMap.put(Tag.getId(), Tag);

		TagComparator.assertEquals(resultMap.get(tag1.getId()), tag1);
		TagComparator.assertEquals(resultMap.get(tag2.getId()), tag2);
	}

	public void testTagQueryByTypeListMultipleMatch() {

		final String type1 = "Location";
		final String type2 = "RatingFlag";

		Tag tag1 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, type1)), new String[] {});
		Tag tag2 = this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, type2)), new String[] {});
		this.tagClient.create(this.tagFactory.create(new DataServiceField(TagField.type, "MusicalGenre")));

		Query[] queries = new Query[] { new ByType(Arrays.asList(type1, type2)) };
		Feed<Tag> results = this.tagClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two Tags should be found");

		Map<URI, Tag> resultMap = new HashMap<>();
		for (Tag Tag : results.getEntries())
			resultMap.put(Tag.getId(), Tag);

		TagComparator.assertEquals(resultMap.get(tag1.getId()), tag1);
		TagComparator.assertEquals(resultMap.get(tag2.getId()), tag2);
	}

}
