package com.theplatform.data.tv.entity.integration.test.endpoint.programteamassociation;

import java.net.UnknownHostException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */
@Test(groups = { "programTeamAssociation", "sort", TestGroup.gbTest })
public class ProgramTeamAssociationValidationIT extends EntityTestBase {

	@Test(dataProvider = "validHomeAwayValues")
	public void testProgramTeamAssociationValidHomeAway(String validHomeAway) throws UnknownHostException {
		ProgramTeamAssociation inputProgramTeamAssociation = this.programTeamAssociationFactory.create();
		inputProgramTeamAssociation.setHomeAway(validHomeAway);
		this.programTeamAssociationClient.create(inputProgramTeamAssociation);
	}

	@DataProvider
	public Object[][] validHomeAwayValues() {
		return new Object[][] { new Object[] { "Home" }, new Object[] { "Away" }, new Object[] { "Neutral" }, new Object[] { null } };
	}

	@Test(dataProvider = "invalidHomeAwayValues", expectedExceptions = ValidationException.class)
	public void testProgramTeamAssociationInalidHomeAway(String invalidHomeAway) throws UnknownHostException {
		ProgramTeamAssociation inputProgramTeamAssociation = this.programTeamAssociationFactory.create();
		inputProgramTeamAssociation.setHomeAway(invalidHomeAway);
		this.programTeamAssociationClient.create(inputProgramTeamAssociation);
	}

	@DataProvider
	public Object[][] invalidHomeAwayValues() {
		return new Object[][] { new Object[] { "" }, new Object[] { "wrong type" }, new Object[] { "HOME" } };
	}

}
