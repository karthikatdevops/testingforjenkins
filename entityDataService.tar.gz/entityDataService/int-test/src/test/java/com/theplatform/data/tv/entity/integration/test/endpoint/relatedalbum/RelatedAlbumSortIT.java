package com.theplatform.data.tv.entity.integration.test.endpoint.relatedalbum;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.RelatedAlbum;
import com.theplatform.data.tv.entity.api.test.RelatedAlbumComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "relatedAlbum", "sort" })
public class RelatedAlbumSortIT extends EntityTestBase {

	public void testRelatedAlbumSortByGuid() {
		List<RelatedAlbum> relatedAlbums = relatedAlbumFactory.create(4);
		relatedAlbums.get(0).setGuid("1");
		relatedAlbums.get(3).setGuid("2");
		relatedAlbums.get(1).setGuid("3");
		relatedAlbums.get(2).setGuid("4");

		this.relatedAlbumClient.create(relatedAlbums);

		List<RelatedAlbum> expectedSortedRelatedAlbums = new ArrayList<>(relatedAlbums.size());
		expectedSortedRelatedAlbums.add(relatedAlbums.get(0));
		expectedSortedRelatedAlbums.add(relatedAlbums.get(3));
		expectedSortedRelatedAlbums.add(relatedAlbums.get(1));
		expectedSortedRelatedAlbums.add(relatedAlbums.get(2));

		Feed<RelatedAlbum> retrievedRelatedAlbums = this.relatedAlbumClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("guid", false) },
				null, false);

		RelatedAlbumComparator.assertEquals(retrievedRelatedAlbums, expectedSortedRelatedAlbums);
	}

	public void testRelatedAlbumSortBySourceAlbumId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI albumId1 = this.albumClient.create(albumFactory.create()).getId();
		URI albumId2 = this.albumClient.create(albumFactory.create()).getId();
		URI albumId3 = this.albumClient.create(albumFactory.create()).getId();
		URI albumId4 = this.albumClient.create(albumFactory.create()).getId();
		Assert.assertTrue(URIUtils.getIdValue(albumId1) < URIUtils.getIdValue(albumId2));
		Assert.assertTrue(URIUtils.getIdValue(albumId2) < URIUtils.getIdValue(albumId3));
		Assert.assertTrue(URIUtils.getIdValue(albumId3) < URIUtils.getIdValue(albumId4));

		List<RelatedAlbum> relatedAlbums = relatedAlbumFactory.create(4);
		relatedAlbums.get(0).setSourceAlbumId(albumId1);
		relatedAlbums.get(3).setSourceAlbumId(albumId2);
		relatedAlbums.get(1).setSourceAlbumId(albumId3);
		relatedAlbums.get(2).setSourceAlbumId(albumId4);

		this.relatedAlbumClient.create(relatedAlbums);

		List<RelatedAlbum> expectedSortedRelatedAlbums = new ArrayList<>(relatedAlbums.size());
		expectedSortedRelatedAlbums.add(relatedAlbums.get(0));
		expectedSortedRelatedAlbums.add(relatedAlbums.get(3));
		expectedSortedRelatedAlbums.add(relatedAlbums.get(1));
		expectedSortedRelatedAlbums.add(relatedAlbums.get(2));

		Feed<RelatedAlbum> retrievedRelatedAlbums = this.relatedAlbumClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("sourceAlbumId",
				false) }, null, false);

		RelatedAlbumComparator.assertEquals(retrievedRelatedAlbums, expectedSortedRelatedAlbums);
	}

	public void testRelatedAlbumSortByTargetAlbumId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI albumId1 = this.albumClient.create(albumFactory.create()).getId();
		URI albumId2 = this.albumClient.create(albumFactory.create()).getId();
		URI albumId3 = this.albumClient.create(albumFactory.create()).getId();
		URI albumId4 = this.albumClient.create(albumFactory.create()).getId();
		Assert.assertTrue(URIUtils.getIdValue(albumId1) < URIUtils.getIdValue(albumId2));
		Assert.assertTrue(URIUtils.getIdValue(albumId2) < URIUtils.getIdValue(albumId3));
		Assert.assertTrue(URIUtils.getIdValue(albumId3) < URIUtils.getIdValue(albumId4));
		List<RelatedAlbum> relatedAlbums = relatedAlbumFactory.create(4);
		relatedAlbums.get(0).setTargetAlbumId(albumId1);
		relatedAlbums.get(3).setTargetAlbumId(albumId2);
		relatedAlbums.get(1).setTargetAlbumId(albumId3);
		relatedAlbums.get(2).setTargetAlbumId(albumId4);

		this.relatedAlbumClient.create(relatedAlbums);

		List<RelatedAlbum> expectedSortedRelatedAlbums = new ArrayList<>(relatedAlbums.size());
		expectedSortedRelatedAlbums.add(relatedAlbums.get(0));
		expectedSortedRelatedAlbums.add(relatedAlbums.get(3));
		expectedSortedRelatedAlbums.add(relatedAlbums.get(1));
		expectedSortedRelatedAlbums.add(relatedAlbums.get(2));

		Feed<RelatedAlbum> retrievedRelatedAlbums = this.relatedAlbumClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("targetAlbumId",
				false) }, null, false);

		RelatedAlbumComparator.assertEquals(retrievedRelatedAlbums, expectedSortedRelatedAlbums);
	}

	// Only one valid type value so no sorting required
}
