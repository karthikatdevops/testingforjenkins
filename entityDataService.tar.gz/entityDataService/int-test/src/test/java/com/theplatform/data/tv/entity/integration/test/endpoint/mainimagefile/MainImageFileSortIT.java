package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagefile;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.test.MainImageFileComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;
import com.theplatform.module.exception.BadParameterException;

/**
 * User: gservente
 * 
 * Basic Sort tests for MainImageFile. MainImageFile it doesn't has any specific
 * field sortable, so it only has tests methods for no sortable fields and a
 * base field.
 */
@Test(groups = { "mainImageFile", "sort", "other" })
public class MainImageFileSortIT extends EntityTestBase {

	private static final int IMAGE_ASSOACIATIONS_TO_CREATE = 4;

	@Test(groups = TestGroup.testBug)
	public void testSortAscendingMainImageFileByOwnerId() throws UnknownHostException {

		// CREATE
		List<MainImageFile> mainImageFiles = this.mainImageFileFactory.create(IMAGE_ASSOACIATIONS_TO_CREATE);
		List<MainImageFile> persistedMainImageFile = this.mainImageFileClient.create(mainImageFiles).getEntries();

		// UPDATE VALUES
		mainImageFiles.get(3).setOwnerId(URI.create("http://a.owner.id/123"));
		mainImageFiles.get(0).setOwnerId(URI.create("http://a.owner.id/222"));
		mainImageFiles.get(2).setOwnerId(URI.create("http://ba.owner.id/1311"));
		mainImageFiles.get(1).setOwnerId(URI.create("http://bb.owner.id/1531"));

		mainImageFiles.get(0).setId(persistedMainImageFile.get(0).getId());
		mainImageFiles.get(1).setId(persistedMainImageFile.get(1).getId());
		mainImageFiles.get(2).setId(persistedMainImageFile.get(2).getId());
		mainImageFiles.get(3).setId(persistedMainImageFile.get(3).getId());

		this.mainImageFileClient.update(mainImageFiles);

		// SORT EXPECTED
		List<MainImageFile> expectedSortedImageAssociations = new ArrayList<>(mainImageFiles.size());
		expectedSortedImageAssociations.add(mainImageFiles.get(3));
		expectedSortedImageAssociations.add(mainImageFiles.get(0));
		expectedSortedImageAssociations.add(mainImageFiles.get(2));
		expectedSortedImageAssociations.add(mainImageFiles.get(1));

		// RETRIVE WHITH SORTING
		String sortFiedld = "ownerId";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<MainImageFile> retrievedImageAssociations = this.mainImageFileClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null,
				false);

		MainImageFileComparator.assertMainImageFilesEqual(retrievedImageAssociations, expectedSortedImageAssociations);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableField() throws UnknownHostException {
		// RETRIEVE WITH SORTING
		String sortField = "url";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortField, sortDescending);
		this.mainImageFileClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
	}
}
