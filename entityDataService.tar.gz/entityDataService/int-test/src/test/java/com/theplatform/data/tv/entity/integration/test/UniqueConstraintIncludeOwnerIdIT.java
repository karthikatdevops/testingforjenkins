package com.theplatform.data.tv.entity.integration.test;

import java.net.URI;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.comparator.MediaIdComparator;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.AwardAssociationClient;
import com.theplatform.data.tv.entity.api.client.ProgramMediaAssociationClient;
import com.theplatform.data.tv.entity.api.client.ProgramRankClient;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.image.api.client.ImageAssociationClient;
import com.theplatform.data.tv.image.api.client.MainImageFileClient;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;
import com.theplatform.data.tv.tag.api.client.TagAssociationClient;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest })
public class UniqueConstraintIncludeOwnerIdIT extends EntityTestBase {

	private URI programId;
	private URI tagId;
	private URI institutionId;
	private URI awardId;
	private URI personId;
	private URI mainImageTypeId;
	private final String programRankType = "Algorithmic";
	private final int year = 1980;

	private final MediaId mediaId;
	{
		mediaId = new MediaId();
		mediaId.setServiceGuid("serviceGuid");
		mediaId.setAccountGuid("accountGuid");
		mediaId.setMediaGuid("mediaGuid");
	}

	private TagAssociationClient anotherTagAssociationClient;
	private AwardAssociationClient anotherAwardAssociationClient;
	private ImageAssociationClient anotherImageAssociationClient;
	private MainImageFileClient anotherMainImageFileClient;
	private ProgramMediaAssociationClient anotherProgramMediaAssociationClient;
	private ProgramRankClient anotherProgramRankClient;

	public void setAnotherTagAssociationClient() {
		Assert.assertNull(this.anotherTagAssociationClient);
		this.anotherTagAssociationClient = this.tagAssociationClient;
	}

	public void setAnotherAwardAssociationClient() {
		Assert.assertNull(this.anotherAwardAssociationClient);
		this.anotherAwardAssociationClient = this.awardAssociationClient;
	}

	public void setAnotherImageAssociationClient() {
		Assert.assertNull(this.anotherImageAssociationClient);
		this.anotherImageAssociationClient = this.imageAssociationClient;
	}
	
	public void setAnotherMainImageFileClient() {
		Assert.assertNull(this.anotherMainImageFileClient);
		this.anotherMainImageFileClient = this.mainImageFileClient;
	}
	
	public void setAnotherProgramMediaAssociationClient() {
		Assert.assertNull(this.anotherProgramMediaAssociationClient);
		this.anotherProgramMediaAssociationClient = this.programMediaAssociationClient;
	}
	
	public void setAnotherProgramRankClient() {
		Assert.assertNull(this.anotherProgramRankClient);
		this.anotherProgramRankClient = this.programRankClient;
	}

	@BeforeClass
	private void setUp() {
		programId = this.programClient.create(this.programFactory.create()).getId();
		tagId = this.tagClient.create(this.tagFactory.create()).getId();
		institutionId = this.institutionClient.create(this.institutionFactory.create()).getId();
		awardId = this.awardClient.create(this.awardFactory.create()).getId();
		personId = this.personClient.create(this.personFactory.create()).getId();
		mainImageTypeId = this.mainImageTypeClient.create(this.mainImageTypeFactory.create()).getId();
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testCreateTagAssociationSameEntityIdTagIdSameOwnerId() {

		Assert.assertNotNull(programId);
		Assert.assertNotNull(tagId);

		TagAssociation tagAssociation1 = this.tagAssociationFactory.create();
		tagAssociation1.setEntityId(programId);
		tagAssociation1.setTagId(tagId);

		this.tagAssociationClient.create(tagAssociation1, new String[] {});

		TagAssociation tagAssociation2 = this.tagAssociationFactory.create();
		tagAssociation2.setEntityId(programId);
		tagAssociation2.setTagId(tagId);

		Assert.assertEquals(tagAssociation1.getOwnerId(), tagAssociation2.getOwnerId());
		this.tagAssociationClient.create(tagAssociation2, new String[] {});
	}

	@Test(dependsOnMethods = "setAnotherTagAssociationClient")
	public void testCreateTagAssociationSameEntityIdTagIdDifferentOwnerId() {

		Assert.assertNotNull(programId);
		Assert.assertNotNull(tagId);

		TagAssociation tagAssociation1 = this.tagAssociationFactory.create();
		tagAssociation1.setEntityId(programId);
		tagAssociation1.setTagId(tagId);
		tagAssociation1.setOwnerId(null);

		TagAssociation persistedTagAssociation1 = this.anotherTagAssociationClient.create(tagAssociation1, new String[] {});

		TagAssociation tagAssociation2 = this.tagAssociationFactory.create();
		tagAssociation2.setEntityId(programId);
		tagAssociation2.setTagId(tagId);
		tagAssociation2.setOwnerId(null);

		TagAssociation persistedTagAssociation2 = this.tagAssociationClient.create(tagAssociation2, new String[] {});

		Assert.assertNotEquals(persistedTagAssociation1.getOwnerId(), persistedTagAssociation2.getOwnerId());
		Assert.assertEquals(persistedTagAssociation1.getEntityId(), persistedTagAssociation2.getEntityId());
		Assert.assertEquals(persistedTagAssociation1.getTagId(), persistedTagAssociation2.getTagId());
		Assert.assertEquals(persistedTagAssociation1.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
		Assert.assertEquals(persistedTagAssociation2.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testCreateAwardAssociationSameInstitutionIdYearAwardIdProgramIdPersonIdSameOwnerId() {

		Assert.assertNotNull(institutionId);
		Assert.assertNotNull(awardId);
		Assert.assertNotNull(programId);
		Assert.assertNotNull(personId);

		AwardAssociation awardAssociation1 = this.awardAssociationFactory.create();
		awardAssociation1.setInstitutionId(institutionId);
		awardAssociation1.setProgramId(programId);
		awardAssociation1.setAwardId(awardId);
		awardAssociation1.setPersonId(personId);
		awardAssociation1.setYear(year);

		this.awardAssociationClient.create(awardAssociation1, new String[] {});

		AwardAssociation awardAssociation2 = this.awardAssociationFactory.create();
		awardAssociation2.setInstitutionId(institutionId);
		awardAssociation2.setProgramId(programId);
		awardAssociation2.setPersonId(personId);
		awardAssociation2.setAwardId(awardId);
		awardAssociation2.setYear(year);

		Assert.assertEquals(awardAssociation1.getOwnerId(), awardAssociation2.getOwnerId());
		this.awardAssociationClient.create(awardAssociation2, new String[] {});
	}

	@Test(dependsOnMethods = "setAnotherAwardAssociationClient")
	public void testCreateAwardAssociationSameInstitutionIdProgramIdAwardIdPersonIdYearDifferentOwnerId() {

		Assert.assertNotNull(institutionId);
		Assert.assertNotNull(programId);
		Assert.assertNotNull(awardId);
		Assert.assertNotNull(personId);

		AwardAssociation awardAssociation1 = this.awardAssociationFactory.create();
		awardAssociation1.setInstitutionId(institutionId);
		awardAssociation1.setProgramId(programId);
		awardAssociation1.setPersonId(personId);
		awardAssociation1.setAwardId(awardId);
		awardAssociation1.setYear(year);
		awardAssociation1.setOwnerId(null);

		AwardAssociation persistedAwardAssociation1 = this.anotherAwardAssociationClient.create(awardAssociation1, new String[] {});

		AwardAssociation awardAssociation2 = this.awardAssociationFactory.create();
		awardAssociation2.setInstitutionId(institutionId);
		awardAssociation2.setProgramId(programId);
		awardAssociation2.setAwardId(awardId);
		awardAssociation2.setPersonId(personId);
		awardAssociation2.setYear(year);
		awardAssociation2.setOwnerId(null);

		AwardAssociation persistedAwardAssociation2 = this.awardAssociationClient.create(awardAssociation2, new String[] {});

		Assert.assertNotEquals(persistedAwardAssociation1.getOwnerId(), persistedAwardAssociation2.getOwnerId());
		Assert.assertEquals(persistedAwardAssociation1.getInstitutionId(), persistedAwardAssociation2.getInstitutionId());
		Assert.assertEquals(persistedAwardAssociation1.getProgramId(), persistedAwardAssociation2.getProgramId());
		Assert.assertEquals(persistedAwardAssociation1.getAwardId(), persistedAwardAssociation2.getAwardId());
		Assert.assertEquals(persistedAwardAssociation1.getPersonId(), persistedAwardAssociation2.getPersonId());
		Assert.assertEquals(persistedAwardAssociation1.getYear(), persistedAwardAssociation2.getYear());
		Assert.assertEquals(persistedAwardAssociation1.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
		Assert.assertEquals(persistedAwardAssociation2.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testCreateImageAssociationSameEntityIdMediaIdSameOwnerId() {

		Assert.assertNotNull(programId);

		ImageAssociation imageAssociation1 = this.imageAssociationFactory.create();
		imageAssociation1.setEntityId(programId);
		imageAssociation1.setMediaId(mediaId);

		this.imageAssociationClient.create(imageAssociation1, new String[] {});

		ImageAssociation imageAssociation2 = this.imageAssociationFactory.create();
		imageAssociation2.setEntityId(programId);
		imageAssociation2.setMediaId(mediaId);

		Assert.assertEquals(imageAssociation1.getOwnerId(), imageAssociation2.getOwnerId());
		this.imageAssociationClient.create(imageAssociation2, new String[] {});
	}

	@Test(dependsOnMethods = "setAnotherImageAssociationClient")
	public void testCreateImageAssociationSameEntityIdMediaIdDifferentOwnerId() {

		Assert.assertNotNull(programId);

		ImageAssociation imageAssociation1 = this.imageAssociationFactory.create();
		imageAssociation1.setEntityId(programId);
		imageAssociation1.setMediaId(mediaId);
		imageAssociation1.setOwnerId(null);

		ImageAssociation persistedImageAssociation1 = this.anotherImageAssociationClient.create(imageAssociation1, new String[] {});

		ImageAssociation imageAssociation2 = this.imageAssociationFactory.create();
		imageAssociation2.setEntityId(programId);
		imageAssociation2.setMediaId(mediaId);
		imageAssociation2.setOwnerId(null);

		ImageAssociation persistedImageAssociation2 = this.imageAssociationClient.create(imageAssociation2, new String[] {});

		Assert.assertNotEquals(persistedImageAssociation1.getOwnerId(), persistedImageAssociation2.getOwnerId());
		Assert.assertEquals(persistedImageAssociation1.getEntityId(), persistedImageAssociation2.getEntityId());
		MediaIdComparator.assertEquals(persistedImageAssociation1.getMediaId(), persistedImageAssociation2.getMediaId());
		Assert.assertEquals(persistedImageAssociation1.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
		Assert.assertEquals(persistedImageAssociation2.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
	}
	@Test(expectedExceptions = ValidationException.class)
	public void testCreateMainImageFileSameEntityIdMainImageTypeIdSameOwnerId() {
		
		Assert.assertNotNull(programId);
		
		MainImageFile mainImageFile1 = this.mainImageFileFactory.create();
		mainImageFile1.setEntityId(programId);
		mainImageFile1.setMainImageTypeId(mainImageTypeId);
		
		this.mainImageFileClient.create(mainImageFile1, new String[] {});
		
		MainImageFile mainImageFile2 = this.mainImageFileFactory.create();
		mainImageFile2.setEntityId(programId);
		mainImageFile2.setMainImageTypeId(mainImageTypeId);
		
		Assert.assertEquals(mainImageFile1.getOwnerId(), mainImageFile2.getOwnerId());
		this.mainImageFileClient.create(mainImageFile2, new String[] {});
	}
	
	@Test(dependsOnMethods = "setAnotherMainImageFileClient")
	public void testCreateMainImageFileSameEntityIdMainImageTypeIdDifferentOwnerId() {
		
		Assert.assertNotNull(programId);
		
		MainImageFile mainImageFile1 = this.mainImageFileFactory.create();
		mainImageFile1.setEntityId(programId);
		mainImageFile1.setMainImageTypeId(mainImageTypeId);
		mainImageFile1.setOwnerId(null);
		
		MainImageFile persistedMainImageFile1 = this.anotherMainImageFileClient.create(mainImageFile1, new String[] {});
		
		MainImageFile mainImageFile2 = this.mainImageFileFactory.create();
		mainImageFile2.setEntityId(programId);
		mainImageFile2.setMainImageTypeId(mainImageTypeId);
		mainImageFile2.setOwnerId(null);
		
		MainImageFile persistedMainImageFile2 = this.mainImageFileClient.create(mainImageFile2, new String[] {});
		
		Assert.assertNotEquals(persistedMainImageFile1.getOwnerId(), persistedMainImageFile2.getOwnerId());
		Assert.assertEquals(persistedMainImageFile1.getEntityId(), persistedMainImageFile2.getEntityId());
		Assert.assertEquals(persistedMainImageFile1.getMainImageTypeId(), persistedMainImageFile2.getMainImageTypeId());
		Assert.assertEquals(persistedMainImageFile1.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
		Assert.assertEquals(persistedMainImageFile2.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
	}
	
	@Test(expectedExceptions = ValidationException.class)
	public void testCreateProgramMediaAssociationSameMediaIdSameOwnerId() {
		
		Assert.assertNotNull(programId);
		
		ProgramMediaAssociation programMediaAssociation1 = this.programMediaAssociationFactory.create();
		programMediaAssociation1.setMediaId(mediaId);
		
		this.programMediaAssociationClient.create(programMediaAssociation1, new String[] {});
		
		ProgramMediaAssociation programMediaAssociation2 = this.programMediaAssociationFactory.create();
		programMediaAssociation2.setMediaId(mediaId);
		
		Assert.assertEquals(programMediaAssociation1.getOwnerId(), programMediaAssociation2.getOwnerId());
		this.programMediaAssociationClient.create(programMediaAssociation2, new String[] {});
	}
	
	@Test(dependsOnMethods = "setAnotherProgramMediaAssociationClient")
	public void testCreateProgramMediaAssociationSameMediaIdDifferentOwnerId() {
		
		Assert.assertNotNull(programId);
		
		ProgramMediaAssociation programMediaAssociation1 = this.programMediaAssociationFactory.create();
		programMediaAssociation1.setMediaId(mediaId);
		programMediaAssociation1.setOwnerId(null);
		
		ProgramMediaAssociation persistedProgramMediaAssociation1 = this.anotherProgramMediaAssociationClient.create(programMediaAssociation1, new String[] {});
		
		ProgramMediaAssociation programMediaAssociation2 = this.programMediaAssociationFactory.create();
		programMediaAssociation2.setMediaId(mediaId);
		programMediaAssociation2.setOwnerId(null);
		
		ProgramMediaAssociation persistedProgramMediaAssociation2 = this.programMediaAssociationClient.create(programMediaAssociation2, new String[] {});
		
		Assert.assertNotEquals(persistedProgramMediaAssociation1.getOwnerId(), persistedProgramMediaAssociation2.getOwnerId());
		MediaIdComparator.assertEquals(persistedProgramMediaAssociation1.getMediaId(), persistedProgramMediaAssociation2.getMediaId());
		Assert.assertEquals(persistedProgramMediaAssociation1.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
		Assert.assertEquals(persistedProgramMediaAssociation2.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
	}
	
	@Test(expectedExceptions = ValidationException.class)
	public void testCreateProgramRankSameProgramIdTypeSameOwnerId() {
		
		Assert.assertNotNull(programId);
		
		ProgramRank programRank1 = this.programRankFactory.create();
		programRank1.setProgramId(programId);
		programRank1.setType(programRankType);
		
		this.programRankClient.create(programRank1, new String[] {});
		
		ProgramRank programRank2 = this.programRankFactory.create();
		programRank2.setProgramId(programId);
		programRank2.setType(programRankType);
		
		Assert.assertEquals(programRank1.getOwnerId(), programRank2.getOwnerId());
		this.programRankClient.create(programRank2, new String[] {});
	}
	
	@Test(dependsOnMethods = "setAnotherProgramRankClient")
	public void testCreateProgramRankSameProgramIdTypeDifferentOwnerId() {
		
		Assert.assertNotNull(programId);
		
		ProgramRank programRank1 = this.programRankFactory.create();
		programRank1.setProgramId(programId);
		programRank1.setType(programRankType);
		programRank1.setOwnerId(null);
		
		ProgramRank persistedRank1 = this.anotherProgramRankClient.create(programRank1, new String[] {});
		
		ProgramRank programRank2 = this.programRankFactory.create();
		programRank2.setProgramId(programId);
		programRank2.setType(programRankType);
		programRank2.setOwnerId(null);
		
		ProgramRank persistedProgramRank2 = this.programRankClient.create(programRank2, new String[] {});
		
		Assert.assertNotEquals(persistedRank1.getOwnerId(), persistedProgramRank2.getOwnerId());
		Assert.assertEquals(persistedRank1.getProgramId(), persistedProgramRank2.getProgramId());
		Assert.assertEquals(persistedRank1.getType(), persistedProgramRank2.getType());
		Assert.assertEquals(persistedRank1.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
		Assert.assertEquals(persistedProgramRank2.getMerlinResourceType(), MerlinResourceType.AudienceAvailable);
	}

}
