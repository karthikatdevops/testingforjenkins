package com.theplatform.data.tv.entity.integration.test.endpoint.tagassociation;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.client.query.ByEntityId;
import com.theplatform.data.tv.tag.api.client.query.ByTagId;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import com.theplatform.data.tv.tag.api.test.TagAssociationComparator;

/**
 * 
 */
// TODO MERLIN-XXXX more query tests need to be implemented
@Test(groups = { "tagAssociation", "query", TestGroup.gbTest })
public class TagAssociationQueryIT extends EntityTestBase {

	public void testTagAssociationQueryByEntityIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.tagAssociationClient.create(this.tagAssociationFactory.create(3,
				new DataServiceField(TagAssociationField.entityId, this.programClient.create(this.programFactory.create()).getId())));

		Long idToFind = URIUtils.getIdValue(this.programClient.create(this.programFactory.create()).getId());

		Query[] queries = new Query[] { new ByEntityId(idToFind) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No TagAssociation should be found");

		queries = new Query[] { new ByEntityId(Arrays.asList(new Long[] { idToFind })) };
		results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No TagAssociation should be found");
	}

	public void testTagAssociationQueryByEntityIdListNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.tagAssociationClient.create(this.tagAssociationFactory.create(3,
				new DataServiceField(TagAssociationField.entityId, this.programClient.create(this.programFactory.create()).getId())));

		Query[] queries = new Query[] { new ByEntityId(Arrays.asList(
				URIUtils.getIdValue(this.programClient.create(this.programFactory.create()).getId()),
				URIUtils.getIdValue(this.programClient.create(this.programFactory.create()).getId()))) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No TagAssociation should be found");

	}

	public void testTagAssociationQueryByEntityIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI entityId1 = this.programClient.create(this.programFactory.create()).getId();
		final URI entityId2 = this.programClient.create(this.programFactory.create()).getId();

		this.tagAssociationClient.create(this.tagAssociationFactory.create(3, new DataServiceField(TagAssociationField.entityId, entityId1)));

		Long idToFind = URIUtils.getIdValue(entityId2);

		TagAssociation expectedTagAssociation = this.tagAssociationClient.create(
				this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, entityId2)), new String[] {});
		Query[] queries = new Query[] { new ByEntityId(idToFind) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one TagAssociation should be found");
		TagAssociationComparator.assertEquals(results.getEntries().get(0), expectedTagAssociation);

		List<Long> idsToFind = new ArrayList<>();
		idsToFind.add(idToFind);
		queries = new Query[] { new ByEntityId(idsToFind) };
		results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one TagAssociation should be found");

		TagAssociationComparator.assertEquals(results.getEntries().get(0), expectedTagAssociation);
	}

	public void testTagAssociationQueryByEntityIdListOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.tagAssociationClient.create(this.tagAssociationFactory.create(3,
				new DataServiceField(TagAssociationField.entityId, this.programClient.create(this.programFactory.create()).getId())));

		TagAssociation expectedTagAssociation = this.tagAssociationClient.create(
				this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, this.programClient.create(
						this.programFactory.create()).getId())), new String[] {});

		Query[] queries = new Query[] { new ByEntityId(Arrays.asList(URIUtils.getIdValue(expectedTagAssociation.getEntityId()),
				URIUtils.getIdValue(this.programClient.create(this.programFactory.create()).getId()))) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one TagAssociation should be found");

		TagAssociationComparator.assertEquals(results.getEntries().get(0), expectedTagAssociation);
	}

	public void testTagAssociationQueryByEntityIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI entityId1 = this.programClient.create(this.programFactory.create()).getId();
		final URI entityId2 = this.programClient.create(this.programFactory.create()).getId();

		List<Long> idsToFind = new ArrayList<>();
		idsToFind.add(URIUtils.getIdValue(entityId1));
		idsToFind.add(URIUtils.getIdValue(entityId2));

		this.tagAssociationClient.create(this.tagAssociationFactory.create(3, new DataServiceField(TagAssociationField.entityId, entityId1)));

		List<TagAssociation> expectedTagAssociations = this.tagAssociationClient.create(
				this.tagAssociationFactory.create(2, new DataServiceField(TagAssociationField.entityId, entityId2)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByEntityId(idsToFind.get(1)) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two TagAssociations should be found");

		Map<URI, TagAssociation> resultMap = new HashMap<>();
		for (TagAssociation credit : results.getEntries()) {
			resultMap.put(credit.getId(), credit);
		}

		for (TagAssociation expected : expectedTagAssociations)
			TagAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);

		queries = new Query[] { new ByEntityId(idsToFind) };
		results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 5, "Exact 5 TagAssociations should be found");

		resultMap = new HashMap<>();
		for (TagAssociation credit : results.getEntries()) {
			resultMap.put(credit.getId(), credit);
		}

		for (TagAssociation expected : expectedTagAssociations)
			TagAssociationComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testTagAssociationQueryByTagIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI tagId = this.tagAssociationClient.create(this.tagAssociationFactory.create(), new String[] { TagAssociationField.tagId.getLocalName() }).getTagId();
		URI expectedTagId = tagFactory.create().getId();
		Assert.assertNotEquals(tagId, expectedTagId);

		Query[] queries = new Query[] { new ByTagId(URIUtils.getIdValue(expectedTagId)) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No TagAssociation should be found");
	}

	public void testTagAssociationQueryByTagIdListNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.tagAssociationClient.create(this.tagAssociationFactory.create(2), new String[] {});
		Query[] queries = new Query[] { new ByTagId(Arrays.asList(URIUtils.getIdValue(tagFactory.create().getId()),
				URIUtils.getIdValue(tagFactory.create().getId()))) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No TagAssociation should be found");
	}

	public void testTagAssociationQueryByTagIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI tagId1 = tagClient.create(tagFactory.create()).getId();
		final URI tagId2 = tagClient.create(tagFactory.create()).getId();
		Assert.assertNotEquals(tagId1, tagId2);

		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId1)));
		TagAssociation expectedTagAssociation = this.tagAssociationClient.create(
				this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId2)), new String[] {});

		Query[] queries = new Query[] { new ByTagId(URIUtils.getIdValue(tagId2)) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one TagAssociation should be found");

		TagAssociationComparator.assertEquals(results.getEntries().get(0), expectedTagAssociation);
	}

	public void testTagAssociationQueryByTagIdListOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI tagId1 = tagClient.create(tagFactory.create()).getId();
		final URI tagId2 = tagClient.create(tagFactory.create()).getId();
		Assert.assertNotEquals(tagId1, tagId2);

		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId1)));

		TagAssociation expectedTagAssociation = this.tagAssociationClient.create(
				this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId2)), new String[] {});
		Query[] queries = new Query[] { new ByTagId(Arrays.asList(URIUtils.getIdValue(tagId2), URIUtils.getIdValue(tagFactory.create().getId()))) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one TagAssociation should be found");

		TagAssociationComparator.assertEquals(results.getEntries().get(0), expectedTagAssociation);
	}

	public void testTagAssociationQueryByTagIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI tagId1 = tagClient.create(tagFactory.create()).getId();
		final URI tagId2 = tagClient.create(tagFactory.create()).getId();
		Assert.assertNotEquals(tagId1, tagId2);

		TagAssociation tagAssociation1 = this.tagAssociationClient.create(
				this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId1)), new String[] {});
		TagAssociation tagAssociation2 = this.tagAssociationClient.create(
				this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId1)), new String[] {});
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId2)));

		Query[] queries = new Query[] { new ByTagId(URIUtils.getIdValue(tagId1)) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two TagAssociations should be found");

		Map<URI, TagAssociation> resultMap = new HashMap<>();
		for (TagAssociation TagAssociation : results.getEntries())
			resultMap.put(TagAssociation.getId(), TagAssociation);

		TagAssociationComparator.assertEquals(resultMap.get(tagAssociation1.getId()), tagAssociation1);
		TagAssociationComparator.assertEquals(resultMap.get(tagAssociation2.getId()), tagAssociation2);
	}

	public void testTagAssociationQueryByTagIdListMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final URI tagId1 = tagClient.create(tagFactory.create()).getId();
		final URI tagId2 = tagClient.create(tagFactory.create()).getId();
		final URI tagId3 = tagClient.create(tagFactory.create()).getId();
		Assert.assertNotEquals(tagId1, tagId3);
		Assert.assertNotEquals(tagId2, tagId3);
		TagAssociation tagAssociation1 = this.tagAssociationClient.create(
				this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId1)), new String[] {});
		TagAssociation tagAssociation2 = this.tagAssociationClient.create(
				this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId2)), new String[] {});
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.tagId, tagId3)));

		Query[] queries = new Query[] { new ByTagId(Arrays.asList(URIUtils.getIdValue(tagId1), URIUtils.getIdValue(tagId2))) };
		Feed<TagAssociation> results = this.tagAssociationClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two TagAssociations should be found");

		Map<URI, TagAssociation> resultMap = new HashMap<>();
		for (TagAssociation TagAssociation : results.getEntries())
			resultMap.put(TagAssociation.getId(), TagAssociation);

		TagAssociationComparator.assertEquals(resultMap.get(tagAssociation1.getId()), tagAssociation1);
		TagAssociationComparator.assertEquals(resultMap.get(tagAssociation2.getId()), tagAssociation2);
	}

}
