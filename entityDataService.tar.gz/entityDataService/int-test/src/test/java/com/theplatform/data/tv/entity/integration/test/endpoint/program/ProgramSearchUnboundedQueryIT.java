package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.Range;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertEquals;

@Test(groups = { "program" })
public class ProgramSearchUnboundedQueryIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest }, enabled=true)
	public void testUnboundedQueries() {
        // Make some programs:
		List<Program> programs = this.programFactory.create(6, new DataServiceField(ProgramField.type,ProgramType.Other),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		this.programClient.create(programs);

        // Requesting 1-* should return an entryCount of 6:
        Feed<Program> results = this.programClient.getAll(null, null, null, new Range(1, Range.UNBOUNDED), false);
        assertEquals(results.getEntryCount(), (Long)6L);

        // Requesting 4-* should return an entryCount of 3:
        results = this.programClient.getAll(null, null, null, new Range(4, Range.UNBOUNDED), false);
        assertEquals(results.getEntryCount(), (Long)3L);

        // Requesting 5-* should return an entryCount of 2:
        results = this.programClient.getAll(null, null, null, new Range(5, Range.UNBOUNDED), false);
        assertEquals(results.getEntryCount(), (Long)2L);

        // Requesting 6-* should return an entryCount of 1:
        results = this.programClient.getAll(null, null, null, new Range(6, Range.UNBOUNDED), false);
        assertEquals(results.getEntryCount(), (Long)1L);

        // Requesting 7-* should return an entryCount of 0:
        results = this.programClient.getAll(null, null, null, new Range(7, Range.UNBOUNDED), false);
        assertEquals(results.getEntryCount(), (Long)0L);

        // Requesting 8-* should also return an entryCount of 0:
        results = this.programClient.getAll(null, null, null, new Range(8, Range.UNBOUNDED), false);
        assertEquals(results.getEntryCount(), (Long)0L);
    }
}
