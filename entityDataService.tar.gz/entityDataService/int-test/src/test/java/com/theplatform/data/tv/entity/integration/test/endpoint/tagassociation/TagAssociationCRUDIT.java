package com.theplatform.data.tv.entity.integration.test.endpoint.tagassociation;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import com.theplatform.data.tv.tag.api.test.TagAssociationComparator;

@Test(groups = { "tagAssociation", "crud" })
public class TagAssociationCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest , "SprintS"})
	public void crudSingleTagAssociation() throws UnknownHostException {

		TagAssociation tagAssociation = this.tagAssociationFactory.create();
		tagAssociation.setRank(1);
		// CREATE
		TagAssociation persistedTagAssociation = this.tagAssociationClient.create(tagAssociation);
		if (tagAssociation.getId() == null)
			tagAssociation.setId(persistedTagAssociation.getId());
		assertEquals(persistedTagAssociation.getId(), tagAssociation.getId(), "TagAssociation ids should match after creation");

		// RETRIEVE
		TagAssociation retrievedTagAssociation = this.tagAssociationClient.get(tagAssociation.getId(), new String[] {});
		TagAssociationComparator.assertEquals(retrievedTagAssociation, tagAssociation);

		// UPDATE
		Program anotherProgram = this.programClient.create(this.programFactory.create());
		tagAssociation.setEntityId(anotherProgram.getId());
		Integer oldRank = tagAssociation.getRank();
		tagAssociation.setRank(oldRank==null?1:oldRank+1);
		this.tagAssociationClient.update(tagAssociation);

		TagAssociation retrievedAfterUpdate = this.tagAssociationClient.get(tagAssociation.getId(), new String[] {});
		TagAssociationComparator.assertEquals(retrievedAfterUpdate, tagAssociation);
		assertFalse(retrievedTagAssociation.getEntityId().equals(retrievedAfterUpdate.getEntityId()));

		// DELETE
		long deletedObjects = this.tagAssociationClient.delete(tagAssociation.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.tagAssociationClient.get(tagAssociation.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("TagAssociation should not be found after deleting it");
	}

	@Test(groups = { TestGroup.gbTest }, enabled = false)
	public void crudSingleSportsTagAssociation() throws UnknownHostException {

		TagAssociation tagAssociation = getSportsTeamTagAssociationFactory().create();
		tagAssociation.setRank(1);
		// CREATE
		TagAssociation persistedTagAssociation = tagAssociationClient.create(tagAssociation);
		if (tagAssociation.getId() == null)
			tagAssociation.setId(persistedTagAssociation.getId());
		assertEquals(persistedTagAssociation.getId(), tagAssociation.getId(), "TagAssociation ids should match after creation");

		// RETRIEVE
		TagAssociation retrievedTagAssociation = tagAssociationClient.get(tagAssociation.getId(), new String[] {});
		TagAssociationComparator.assertEquals(retrievedTagAssociation, tagAssociation);

		// UPDATE
		SportsTeam sportsTeam = sportsTeamClient.create(sportsTeamFactory.create());
		tagAssociation.setEntityId(sportsTeam.getId());
		Integer oldRank = tagAssociation.getRank();
		tagAssociation.setRank(oldRank==null?1:oldRank+1);
		tagAssociationClient.update(tagAssociation);

		TagAssociation retrievedAfterUpdate = tagAssociationClient.get(tagAssociation.getId(), new String[] {});
		TagAssociationComparator.assertEquals(retrievedAfterUpdate, tagAssociation);
		assertFalse(retrievedTagAssociation.getEntityId().equals(retrievedAfterUpdate.getEntityId()));

		// DELETE
		long deletedObjects = tagAssociationClient.delete(tagAssociation.getId());
		assertEquals(deletedObjects, 1);

		try {
			tagAssociationClient.get(tagAssociation.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("TagAssociation should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudTagAssociationFeed() throws UnknownHostException {
		assertTagAssociationFeed(tagAssociationFactory.create(5));
	}

	@Test(groups = "other")
	public void crudTagAssociationFeedWithoutIds() throws UnknownHostException {
		assertTagAssociationFeed(tagAssociationFactory.create(5));
	}

	private void assertTagAssociationFeed(List<TagAssociation> tagAssociations) {
		// CREATE
		Feed<TagAssociation> persistedTagAssociations = this.tagAssociationClient.create(tagAssociations);
		if (tagAssociations.get(0).getId() == null) {
			int counter = 0;
			for (TagAssociation tagAssociation : persistedTagAssociations.getEntries())
				tagAssociations.get(counter++).setId(tagAssociation.getId());
		}

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] TagAssociationIds = (URI[]) CollectionUtils.collect(tagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		ComparatorUtils.assertIdsAreEqual(tagAssociations, persistedTagAssociations.getEntries());

		// RETRIEVE
		Feed<TagAssociation> retrievedTagAssociations = this.tagAssociationClient.get(TagAssociationIds, new String[] {});
		TagAssociationComparator.assertEquals(retrievedTagAssociations, tagAssociations);

		// DELETE
		long deletedTagAssociations = this.tagAssociationClient.delete(TagAssociationIds);
		assertEquals(deletedTagAssociations, tagAssociations.size());

		long notFoundTagAssociations = 0;
		for (TagAssociation TagAssociation : tagAssociations) {
			try {
				this.tagAssociationClient.get(TagAssociation.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundTagAssociations++;
			}
		}
		assertEquals(notFoundTagAssociations, deletedTagAssociations, "Still found TagAssociations after deleting");
	}

	@Test(groups = { TestGroup.gbTest , "SprintS"})
	public void testDefaultFieldValueWhenCreateTagAssociation() throws UnknownHostException {

		TagAssociation tagAssociation = this.tagAssociationFactory.create();
		tagAssociation.setPrimary(null);
		tagAssociation.setMerlinResourceType(null);
		tagAssociation.setRank(null);
		URI tagAssociationId = this.tagAssociationClient.create(tagAssociation).getId();

		TagAssociation retrievedTagAssociation = this.tagAssociationClient.get(tagAssociationId, null);

		// default values
		tagAssociation.setPrimary(false);
		tagAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		tagAssociation.setRank(null);

		TagAssociationComparator.assertEquals(retrievedTagAssociation, tagAssociation);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(TagAssociationField.primary, false),
			new DataServiceField(TagAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable),
			new DataServiceField(TagAssociationField.rank, null)};

	@Test(groups = { TestGroup.gbTest , "SprintS"})
	public void testTagAssociationCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(tagAssociationClient, tagAssociationFactory.create(), TagAssociationComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest , "SprintS"})
	public void testTagAssociationCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(tagAssociationClient, tagAssociationFactory.create(), TagAssociationComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest, "SprintS" })
	public void testTagAssociationUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(TagAssociationField.primary, true));
		createValues.add(new DataServiceField(TagAssociationField.merlinResourceType, MerlinResourceType.Temporary));
		createValues.add(new DataServiceField(TagAssociationField.rank, 1));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(tagAssociationClient, tagAssociationFactory.create(), TagAssociationComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = {TestGroup.gbTest, "SprintS"})
	public void testTagAssociationUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(TagAssociationField.primary, true));
		createValues.add(new DataServiceField(TagAssociationField.merlinResourceType, MerlinResourceType.Temporary));
		createValues.add(new DataServiceField(TagAssociationField.rank, 1));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(tagAssociationClient, tagAssociationFactory.create(), TagAssociationComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

}
