package com.theplatform.data.tv.entity.integration.test.endpoint.awardassociation;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import com.theplatform.data.tv.entity.api.test.AwardAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;

/**
 * GreenBuild test for sorting functionality of AwardAssociation
 * 
 * @author clai200
 * @since 4/5/2011
 * 
 */

@Test(groups = { TestGroup.gbTest, "awardAssociation", "sort"})
public class AwardAssociationSortIT extends EntityTestBase {

	public void testAwardAssociationSortByYear() {
		List<AwardAssociation> awardAssociations = awardAssociationFactory.create(4);
		awardAssociations.get(2).setYear(1980);
		awardAssociations.get(0).setYear(1999);
		awardAssociations.get(3).setYear(2001);
		awardAssociations.get(1).setYear(2012);

		this.awardAssociationClient.create(awardAssociations);

		List<AwardAssociation> expectedSortedAwardAssociations = new ArrayList<>(awardAssociations.size());
		expectedSortedAwardAssociations.add(awardAssociations.get(2));
		expectedSortedAwardAssociations.add(awardAssociations.get(0));
		expectedSortedAwardAssociations.add(awardAssociations.get(3));
		expectedSortedAwardAssociations.add(awardAssociations.get(1));

		Feed<AwardAssociation> retrievedAwardAssociations = this.awardAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("year",
				false) }, null, false);

		AwardAssociationComparator.assertEquals(retrievedAwardAssociations, expectedSortedAwardAssociations);
	}

	public void testAwardAssociationSortByAwardStatus() {
		List<AwardAssociation> awardAssociations = awardAssociationFactory.create(3);
		awardAssociations.get(2).setAwardStatus("FestivalScreening");
		awardAssociations.get(0).setAwardStatus("Nominee");
		awardAssociations.get(1).setAwardStatus("Winner");

		this.awardAssociationClient.create(awardAssociations);

		List<AwardAssociation> expectedSortedAwardAssociations = new ArrayList<>(awardAssociations.size());
		expectedSortedAwardAssociations.add(awardAssociations.get(2));
		expectedSortedAwardAssociations.add(awardAssociations.get(0));
		expectedSortedAwardAssociations.add(awardAssociations.get(1));

		Feed<AwardAssociation> retrievedAwardAssociations = this.awardAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"awardStatus", false) }, null, false);

		AwardAssociationComparator.assertEquals(retrievedAwardAssociations, expectedSortedAwardAssociations);
	}

	public void testAwardAssociationSortByAwardType() {
		List<AwardAssociation> awardAssociations = awardAssociationFactory.create(2);
		awardAssociations.get(1).setAwardType("Person");
		awardAssociations.get(0).setAwardType("Person");

		this.awardAssociationClient.create(awardAssociations);

		List<AwardAssociation> expectedSortedAwardAssociations = new ArrayList<>(awardAssociations.size());
		expectedSortedAwardAssociations.add(awardAssociations.get(1));
		expectedSortedAwardAssociations.add(awardAssociations.get(0));

		Feed<AwardAssociation> retrievedAwardAssociations = this.awardAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"awardType", false) }, null, false);

		AwardAssociationComparator.assertEquals(retrievedAwardAssociations, expectedSortedAwardAssociations);
	}

	public void testAwardAssociationSortByAwardId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI awardId1 = this.awardClient.create(awardFactory.create()).getId();
		URI awardId2 = this.awardClient.create(awardFactory.create()).getId();
		URI awardId3 = this.awardClient.create(awardFactory.create()).getId();
		URI awardId4 = this.awardClient.create(awardFactory.create()).getId();
		Assert.assertTrue(URIUtils.getIdValue(awardId1) < URIUtils.getIdValue(awardId2));
		Assert.assertTrue(URIUtils.getIdValue(awardId2) < URIUtils.getIdValue(awardId3));
		Assert.assertTrue(URIUtils.getIdValue(awardId3) < URIUtils.getIdValue(awardId4));

		List<AwardAssociation> awardAssociations = awardAssociationFactory.create(4);
		awardAssociations.get(0).setAwardId(awardId1);
		awardAssociations.get(3).setAwardId(awardId2);
		awardAssociations.get(1).setAwardId(awardId3);
		awardAssociations.get(2).setAwardId(awardId4);

		this.awardAssociationClient.create(awardAssociations);

		List<AwardAssociation> expectedSortedAwardAssociations = new ArrayList<>(awardAssociations.size());
		expectedSortedAwardAssociations.add(awardAssociations.get(0));
		expectedSortedAwardAssociations.add(awardAssociations.get(3));
		expectedSortedAwardAssociations.add(awardAssociations.get(1));
		expectedSortedAwardAssociations.add(awardAssociations.get(2));

		Feed<AwardAssociation> retrievedAwardAssociations = this.awardAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"awardId", false) }, null, false);

		AwardAssociationComparator.assertEquals(retrievedAwardAssociations, expectedSortedAwardAssociations);
	}

	public void testAwardAssociationSortByInstitutionId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI institutionId1 = this.institutionClient.create(institutionFactory.create()).getId();
		URI institutionId2 = this.institutionClient.create(institutionFactory.create()).getId();
		URI institutionId3 = this.institutionClient.create(institutionFactory.create()).getId();
		URI institutionId4 = this.institutionClient.create(institutionFactory.create()).getId();
		Assert.assertTrue(URIUtils.getIdValue(institutionId1) < URIUtils.getIdValue(institutionId2));
		Assert.assertTrue(URIUtils.getIdValue(institutionId2) < URIUtils.getIdValue(institutionId3));
		Assert.assertTrue(URIUtils.getIdValue(institutionId3) < URIUtils.getIdValue(institutionId4));

		List<AwardAssociation> awardAssociations = awardAssociationFactory.create(4);
		awardAssociations.get(0).setInstitutionId(institutionId1);
		awardAssociations.get(3).setInstitutionId(institutionId2);
		awardAssociations.get(1).setInstitutionId(institutionId3);
		awardAssociations.get(2).setInstitutionId(institutionId4);

		this.awardAssociationClient.create(awardAssociations);

		List<AwardAssociation> expectedSortedAwardAssociations = new ArrayList<>(awardAssociations.size());
		expectedSortedAwardAssociations.add(awardAssociations.get(0));
		expectedSortedAwardAssociations.add(awardAssociations.get(3));
		expectedSortedAwardAssociations.add(awardAssociations.get(1));
		expectedSortedAwardAssociations.add(awardAssociations.get(2));

		Feed<AwardAssociation> retrievedAwardAssociations = this.awardAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"institutionId", false) }, null, false);

		AwardAssociationComparator.assertEquals(retrievedAwardAssociations, expectedSortedAwardAssociations);
	}

	public void testAwardAssociationSortByProgramId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI programId1 = this.programClient.create(programFactory.create()).getId();
		URI programId2 = this.programClient.create(programFactory.create()).getId();
		URI programId3 = this.programClient.create(programFactory.create()).getId();
		URI programId4 = this.programClient.create(programFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(programId1) < URIUtils.getIdValue(programId2));
		Assert.assertTrue(URIUtils.getIdValue(programId2) < URIUtils.getIdValue(programId3));
		Assert.assertTrue(URIUtils.getIdValue(programId3) < URIUtils.getIdValue(programId4));

		List<AwardAssociation> awardAssociations = awardAssociationFactory.create(4);
		awardAssociations.get(0).setProgramId(programId1);
		awardAssociations.get(3).setProgramId(programId2);
		awardAssociations.get(1).setProgramId(programId3);
		awardAssociations.get(2).setProgramId(programId4);

		this.awardAssociationClient.create(awardAssociations);

		List<AwardAssociation> expectedSortedAwardAssociations = new ArrayList<>(awardAssociations.size());
		expectedSortedAwardAssociations.add(awardAssociations.get(0));
		expectedSortedAwardAssociations.add(awardAssociations.get(3));
		expectedSortedAwardAssociations.add(awardAssociations.get(1));
		expectedSortedAwardAssociations.add(awardAssociations.get(2));

		Feed<AwardAssociation> retrievedAwardAssociations = this.awardAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"programId", false) }, null, false);

		AwardAssociationComparator.assertEquals(retrievedAwardAssociations, expectedSortedAwardAssociations);
	}

	public void testAwardAssociationSortByPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI personId1 = this.personClient.create(personFactory.create()).getId();
		URI personId2 = this.personClient.create(personFactory.create()).getId();
		URI personId3 = this.personClient.create(personFactory.create()).getId();
		URI personId4 = this.personClient.create(personFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(personId1) < URIUtils.getIdValue(personId2));
		Assert.assertTrue(URIUtils.getIdValue(personId2) < URIUtils.getIdValue(personId3));
		Assert.assertTrue(URIUtils.getIdValue(personId3) < URIUtils.getIdValue(personId4));

		List<AwardAssociation> awardAssociations = awardAssociationFactory.create(4);
		awardAssociations.get(0).setPersonId(personId1);
		awardAssociations.get(3).setPersonId(personId2);
		awardAssociations.get(1).setPersonId(personId3);
		awardAssociations.get(2).setPersonId(personId4);

		this.awardAssociationClient.create(awardAssociations);

		List<AwardAssociation> expectedSortedAwardAssociations = new ArrayList<>(awardAssociations.size());
		expectedSortedAwardAssociations.add(awardAssociations.get(0));
		expectedSortedAwardAssociations.add(awardAssociations.get(3));
		expectedSortedAwardAssociations.add(awardAssociations.get(1));
		expectedSortedAwardAssociations.add(awardAssociations.get(2));

		Feed<AwardAssociation> retrievedAwardAssociations = this.awardAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"personId", false) }, null, false);

		AwardAssociationComparator.assertEquals(retrievedAwardAssociations, expectedSortedAwardAssociations);
	}

	public void testAwardAssociationSortByAwardShowId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI awardShowId1 = this.programClient.create(programFactory.create()).getId();
		URI awardShowId2 = this.programClient.create(programFactory.create()).getId();
		URI awardShowId3 = this.programClient.create(programFactory.create()).getId();
		URI awardShowId4 = this.programClient.create(programFactory.create()).getId();
		
		Assert.assertTrue(URIUtils.getIdValue(awardShowId1)<URIUtils.getIdValue(awardShowId2));
		Assert.assertTrue(URIUtils.getIdValue(awardShowId2)<URIUtils.getIdValue(awardShowId3));
		Assert.assertTrue(URIUtils.getIdValue(awardShowId3)<URIUtils.getIdValue(awardShowId4));

		List<AwardAssociation> awardAssociations = awardAssociationFactory.create(4);
		awardAssociations.get(0).setAwardShowId(awardShowId1);
		awardAssociations.get(3).setAwardShowId(awardShowId2);
		awardAssociations.get(1).setAwardShowId(awardShowId3);
		awardAssociations.get(2).setAwardShowId(awardShowId4);

		this.awardAssociationClient.create(awardAssociations);

		List<AwardAssociation> expectedSortedAwardAssociations = new ArrayList<>(awardAssociations.size());
		expectedSortedAwardAssociations.add(awardAssociations.get(0));
		expectedSortedAwardAssociations.add(awardAssociations.get(3));
		expectedSortedAwardAssociations.add(awardAssociations.get(1));
		expectedSortedAwardAssociations.add(awardAssociations.get(2));

		Feed<AwardAssociation> retrievedAwardAssociations = this.awardAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"awardShowId", false) }, null, false);

		AwardAssociationComparator.assertEquals(retrievedAwardAssociations, expectedSortedAwardAssociations);
	}

	@Test(expectedExceptions = BadParameterException.class, dataProvider = "invalidSortFields")
	public void testAwardAssociationSortByInvalidFields(String invalidSortField) {
		this.awardAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(invalidSortField, false) }, null, false);
	}

	@DataProvider
	public Object[][] invalidSortFields() {
		return new Object[][] { new Object[] { "merlinResourceType" }, new Object[] { "description" } };
	}

}
