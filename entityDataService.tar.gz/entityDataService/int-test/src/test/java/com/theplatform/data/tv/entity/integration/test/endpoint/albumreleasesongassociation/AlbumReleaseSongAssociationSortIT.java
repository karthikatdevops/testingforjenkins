package com.theplatform.data.tv.entity.integration.test.endpoint.albumreleasesongassociation;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import com.theplatform.data.tv.entity.api.test.AlbumReleaseSongAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = {TestGroup.gbTest, "albumReleaseSongAssociation", "sort" })
public class AlbumReleaseSongAssociationSortIT extends EntityTestBase {



	public void testAlbumReleaseSongAssociationSortByGuid() {
		List<AlbumReleaseSongAssociation> albumReleaseSongAssociations = albumReleaseSongAssociationFactory.create(4);
		albumReleaseSongAssociations.get(0).setGuid("1");
		albumReleaseSongAssociations.get(3).setGuid("2");
		albumReleaseSongAssociations.get(1).setGuid("3");
		albumReleaseSongAssociations.get(2).setGuid("4");

		this.albumReleaseSongAssociationClient.create(albumReleaseSongAssociations);

		List<AlbumReleaseSongAssociation> expectedSortedAlbumReleaseSongAssociations = new ArrayList<>(
				albumReleaseSongAssociations.size());
		expectedSortedAlbumReleaseSongAssociations.add(albumReleaseSongAssociations.get(0));
		expectedSortedAlbumReleaseSongAssociations.add(albumReleaseSongAssociations.get(3));
		expectedSortedAlbumReleaseSongAssociations.add(albumReleaseSongAssociations.get(1));
		expectedSortedAlbumReleaseSongAssociations.add(albumReleaseSongAssociations.get(2));

		Feed<AlbumReleaseSongAssociation> retrievedAlbumReleaseSongAssociations = this.albumReleaseSongAssociationClient.getOwned(new String[] {},
				new Query[] {}, new Sort[] { new Sort("guid", false) }, null, false);

		AlbumReleaseSongAssociationComparator.assertEquals(retrievedAlbumReleaseSongAssociations, expectedSortedAlbumReleaseSongAssociations);
	}
}
