package com.theplatform.data.tv.entity.integration.test.endpoint.albumcredit;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.tv.entity.api.fields.AlbumCreditField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.albumcredit.ByActive;
import com.theplatform.data.tv.entity.api.client.query.albumcredit.ByAlbumId;
import com.theplatform.data.tv.entity.api.client.query.albumcredit.ByPersonId;
import com.theplatform.data.tv.entity.api.client.query.albumcredit.ByType;
import com.theplatform.data.tv.entity.api.data.objects.AlbumCredit;
import com.theplatform.data.tv.entity.api.test.AlbumCreditComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "albumCredit", "query" })
public class AlbumCreditQueryIT extends EntityTestBase {

	public void testAlbumCreditQueryByAlbumIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.albumId, albumClient.create(albumFactory.create()).getId())));
		Query[] queries = new Query[] { new ByAlbumId(URIUtils.getIdValue(albumClient.create(albumFactory.create()).getId())) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumCredit should be found");
	}

	public void testAlbumCreditQueryByAlbumIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI albumId = albumClient.create(albumFactory.create()).getId();
		AlbumCredit expected = this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.albumId, albumId)), new String[] {});
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.albumId, albumClient.create(albumFactory.create()).getId())));

		Query[] queries = new Query[] { new ByAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumCredit should be found");

		AlbumCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumCreditQueryByAlbumIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI albumId = albumClient.create(albumFactory.create()).getId();
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.albumId, albumClient.create(albumFactory.create()).getId())));

		List<AlbumCredit> expectedAlbumCredits = this.albumCreditClient.create(this.albumCreditFactory.create(2, new DataServiceField(AlbumCreditField.albumId, albumId)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumCredits should be found");

		Map<URI, AlbumCredit> resultMap = new HashMap<>();
		for (AlbumCredit albumCredit : results.getEntries())
			resultMap.put(albumCredit.getId(), albumCredit);

		for (AlbumCredit expected : expectedAlbumCredits)
			AlbumCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testAlbumCreditQueryByPersonIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.personId, personClient.create(personFactory.create()).getId())));
		Query[] queries = new Query[] { new ByPersonId(URIUtils.getIdValue(personClient.create(personFactory.create()).getId())) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumCredit should be found");
	}

	public void testAlbumCreditQueryByPersonIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI personId = personClient.create(personFactory.create()).getId();
		AlbumCredit expected = this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.personId, personId)), new String[] {});
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.personId, personClient.create(personFactory.create()).getId())));

		Query[] queries = new Query[] { new ByPersonId(URIUtils.getIdValue(personId)) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumCredit should be found");

		AlbumCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumCreditQueryByPersonIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI personId = personClient.create(personFactory.create()).getId();
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.personId, personClient.create(personFactory.create()).getId())));

		List<AlbumCredit> expectedAlbumCredits = this.albumCreditClient.create(this.albumCreditFactory.create(2, new DataServiceField(AlbumCreditField.personId, personId)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByPersonId(URIUtils.getIdValue(personId)) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumCredits should be found");

		Map<URI, AlbumCredit> resultMap = new HashMap<>();
		for (AlbumCredit albumCredit : results.getEntries()) {
			resultMap.put(albumCredit.getId(), albumCredit);
		}

		for (AlbumCredit expected : expectedAlbumCredits)
			AlbumCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testAlbumCreditQueryByTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.type, "Primary Artist")));
		Query[] queries = new Query[] { new ByType("Guest Artist") };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumCredit should be found");
	}

	public void testAlbumCreditQueryByTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		AlbumCredit expected = this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.type, "Primary Artist")), new String[] {});
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.type, "Guest Artist")));

		Query[] queries = new Query[] { new ByType("Primary Artist") };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumCredit should be found");

		AlbumCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumCreditQueryByTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.type, "Guest Artist")));
		List<AlbumCredit> expectedAlbumCredits = this.albumCreditClient.create(
				this.albumCreditFactory.create(2, new DataServiceField(AlbumCreditField.type, "Primary Artist")), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByType("Primary Artist") };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumCredits should be found");

		Map<URI, AlbumCredit> resultMap = new HashMap<>();
		for (AlbumCredit albumCredit : results.getEntries()) {
			resultMap.put(albumCredit.getId(), albumCredit);
		}

		for (AlbumCredit expected : expectedAlbumCredits)
			AlbumCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testAlbumCreditQueryByActiveNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.active, true)));
		Query[] queries = new Query[] { new ByActive(false) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumCredit should be found");
	}

	public void testAlbumCreditQueryByActiveOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		AlbumCredit expected = this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.active, true)), new String[] {});
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.active, false)));

		Query[] queries = new Query[] { new ByActive(true) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumCredit should be found");

		AlbumCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumCreditQueryByActiveMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.active, false)));
		List<AlbumCredit> expectedAlbumCredits = this.albumCreditClient.create(this.albumCreditFactory.create(2, new DataServiceField(AlbumCreditField.active, true)),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByActive(true) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumCredits should be found");

		Map<URI, AlbumCredit> resultMap = new HashMap<>();
		for (AlbumCredit albumCredit : results.getEntries()) {
			resultMap.put(albumCredit.getId(), albumCredit);
		}

		for (AlbumCredit expected : expectedAlbumCredits)
			AlbumCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testAlbumCreditQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No AlbumCredit should be found");
	}

	public void testAlbumCreditQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		AlbumCredit expected = this.albumCreditClient.create(
				this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {});
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.merlinResourceType, MerlinResourceType.Editorial)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one AlbumCredit should be found");

		AlbumCreditComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testAlbumCreditQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.merlinResourceType, MerlinResourceType.Editorial)));
		List<AlbumCredit> expectedAlbumCredits = this.albumCreditClient.create(
				this.albumCreditFactory.create(2, new DataServiceField(AlbumCreditField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {})
				.getEntries();
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<AlbumCredit> results = this.albumCreditClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two AlbumCredits should be found");

		Map<URI, AlbumCredit> resultMap = new HashMap<>();
		for (AlbumCredit albumCredit : results.getEntries()) {
			resultMap.put(albumCredit.getId(), albumCredit);
		}

		for (AlbumCredit expected : expectedAlbumCredits)
			AlbumCreditComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

}
