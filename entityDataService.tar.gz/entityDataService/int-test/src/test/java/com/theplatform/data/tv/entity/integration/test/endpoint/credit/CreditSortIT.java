package com.theplatform.data.tv.entity.integration.test.endpoint.credit;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.test.CreditComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "credit", "sort" })
public class CreditSortIT extends EntityTestBase {



	public void testCreditSortByPersonName() {

        URI programId = this.programClient.create(this.programFactory.create()).getId();
        List<Person> persons = this.personFactory.create(4);
		List<Credit> credits = this.creditFactory.create(4,
                new DataServiceField(CreditField.programId, programId),
                new DataServiceField(CreditField.program, programAssociationFactory.create(programId)));

		persons.get(0).setName("c");
		credits.get(0).setPersonId(persons.get(0).getId());

		persons.get(1).setName("a");
		credits.get(1).setPersonId(persons.get(1).getId());
		persons.get(2).setName("d");
		credits.get(2).setPersonId(persons.get(2).getId());
		persons.get(3).setName("b");
		credits.get(3).setPersonId(persons.get(3).getId());
		this.personClient.create(persons);
		this.creditClient.create(credits);

		for (int i = 0; i < credits.size(); i++)
			credits.get(i).setPerson(this.personAssociationFactory.create(credits.get(i).getPersonId()));

		List<Credit> expectedCredits = new ArrayList<>();

		expectedCredits.add(credits.get(1));
		expectedCredits.add(credits.get(3));
		expectedCredits.add(credits.get(0));
		expectedCredits.add(credits.get(2));

		Sort requestSort = new Sort("person.name", false);
		Feed<Credit> retrievedCredits = this.creditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		CreditComparator.assertEquals(retrievedCredits, expectedCredits);
	}
}
