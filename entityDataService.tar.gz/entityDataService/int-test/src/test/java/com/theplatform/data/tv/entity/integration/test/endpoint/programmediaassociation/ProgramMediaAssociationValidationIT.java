package com.theplatform.data.tv.entity.integration.test.endpoint.programmediaassociation;

import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.fields.ProgramMediaAssociationField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;
import org.testng.annotations.Test;

import java.net.URI;

/**
 * 
 * @author jethrolai
 * 
 */
@Test(groups = { "programMediaAssociation", "validation" })
public class ProgramMediaAssociationValidationIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramMediaAssociationPersistingRepeatingMediaGuidAndProgramId() {

		URI programId = this.programClient.create(programFactory.create()).getId();
        MediaId mediaId = createMediaId();

        this.persistingProgramMediaAssociationFactory.create(
        		2, ProgramMediaAssociationField.mediaId, mediaId, ProgramMediaAssociationField.programId, programId);
	}

	@Test(groups = { TestGroup.testBug }, expectedExceptions = ValidationException.class)
	public void testProgramMediaAssociationPersistingNonpersistedProgramId() {
		
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.programId, programFactory.create().getId());
	}

	@Test(groups = { TestGroup.testBug }, expectedExceptions = ValidationException.class)
	public void testProgramMediaAssociationPersistingNonlocalProgramId() {

		URI programId = programFactory.create(
				new DataServiceField(DataObjectField.id, URI.create("http://faksehost/entityDataService/data/Program/" + this.objectIdProvider.nextId())))
				.getId();
		this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.programId, programId);
	}

    @Test(groups = {TestGroup.gbTest}, expectedExceptions = ValidationException.class)
    public void mediaIdIsRequired() {
    	
    	this.persistingProgramMediaAssociationFactory.create(ProgramMediaAssociationField.mediaId, null);
    }
}
