package com.theplatform.data.tv.entity.integration.test.endpoint.videogame;

import com.google.common.collect.Lists;
import com.theplatform.contrib.data.api.objects.EsrbRating;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Videogame;
import com.theplatform.data.tv.entity.api.fields.VideogameField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;
import org.testng.annotations.Test;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 12/3/14
 */
@Test(groups = {"videogame", "validation", TestGroup.gbTest})
public class VideogameValidationIT extends EntityTestBase {

    @Test(expectedExceptions = ValidationException.class)
    public void creatingAnEntityWithTypeOtherThanGameShouldFailValidation() {
        Videogame v1 = videogameFactory.create(new DataServiceField(VideogameField.type, "other"));
        videogameClient.create(v1);
    }

    @Test(expectedExceptions = ValidationException.class)
    public void creatingAnEntityWithALanguageOtherThanISO639ShouldFailValidation() {
        Videogame v1 = videogameFactory.create();
        v1.setLanguages(Lists.newArrayList("xxx"));
        videogameClient.create(v1);
    }

    @Test(expectedExceptions = ValidationException.class)
    public void creatingAnEntityWithMultiplayerFalseAndMinSetShouldFailValidation() {
        Videogame v1 = videogameFactory.create();
        v1.setMultiPlayer(false);
        v1.setMinPlayers(1);
        v1.setMaxPlayers(null);
        videogameClient.create(v1);
    }

    @Test(expectedExceptions = ValidationException.class)
    public void creatingAnEntityWithMultiplayerFalseAndMaxSetShouldFailValidation() {
        Videogame v1 = videogameFactory.create();
        v1.setMultiPlayer(false);
        v1.setMinPlayers(null);
        v1.setMaxPlayers(1);
        videogameClient.create(v1);
    }

    @Test(expectedExceptions = ValidationException.class)
    public void creatingAnEntityWithInvalidESRBRatingShouldFailValidation() {
        EsrbRating rating = new EsrbRating();
        rating.setRating("OTHER");

        Videogame v1 = videogameFactory.create();
        v1.setContentRatings(Lists.newArrayList(rating));
        videogameClient.create(v1);
    }
}
