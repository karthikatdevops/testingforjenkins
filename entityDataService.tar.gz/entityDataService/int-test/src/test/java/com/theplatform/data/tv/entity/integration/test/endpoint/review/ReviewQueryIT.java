package com.theplatform.data.tv.entity.integration.test.endpoint.review;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.entity.api.fields.ReviewField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.OverrideField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.review.ByProgramId;
import com.theplatform.data.tv.entity.api.client.query.review.ByProvider;
import com.theplatform.data.tv.entity.api.data.objects.Review;
import com.theplatform.data.tv.entity.api.test.ReviewComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author jethrolai
 * @since 11/04/2011
 */
@Test(groups = { "review", "query", TestGroup.gbTest })
public class ReviewQueryIT extends EntityTestBase {

    public void testReviewQueryByProgramIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        List<Review> entities = this.reviewFactory.create(3);
        this.reviewClient.create(entities);
        Query[] queries = new Query[] { new ByProgramId(42L) };
        Feed<Review> results = this.reviewClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries().size(), 0, "No Review should be found");
    }

    public void testReviewQueryByProgramIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

        this.reviewClient.create(reviewFactory.create(3));

        Review expected = this.reviewFactory.create();

        this.reviewClient.create(expected).getId();

        Query[] queries = new Query[] { new ByProgramId(expected.getProgramId()) };
        Feed<Review> results = this.reviewClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntryCount(), new Long(1), "Exact one Review should be found");

        ReviewComparator.assertEquals(results.getEntries().get(0), expected);
    }

    public void testReviewQueryByProgramIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
            InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
        this.reviewClient.create(this.reviewFactory.create(3));

        Review expected1 = this.reviewFactory.create();
        reviewClient.create(expected1);

        URI expectedProgramId = expected1.getProgramId();
        this.reviewClient.create(this.reviewFactory.create(ReviewField.programId, expectedProgramId));

        Query[] queries = new Query[] { new ByProgramId(expectedProgramId) };
        Feed<Review> results = this.reviewClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntryCount(), new Long(2), "Exact two review should be found");

        for (Review entity : results.getEntries()) {
            Assert.assertEquals(entity.getProgramId(), expectedProgramId);
        }
    }

    public void testReviewQueryByProviderNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
        List<Review> entities = this.reviewFactory.create(3, new DataServiceField(ReviewField.provider, "fiji"));
        this.reviewClient.create(entities);
        Query[] queries = new Query[] { new ByProvider("columbia") };
        Feed<Review> results = this.reviewClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntries().size(), 0, "No Review should be found");
    }

    public void testReviewQueryByProviderOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
        List<Review> entities = this.reviewFactory.create(3, new DataServiceField(ReviewField.provider, "fiji"));
        this.reviewClient.create(entities);

        Review expected = this.reviewFactory.create(new DataServiceField(ReviewField.provider, "columbia"));

        this.reviewClient.create(expected);
        Query[] queries = new Query[] { new ByProvider("columbia") };
        Feed<Review> results = this.reviewClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntryCount(), new Long(1), "Exact one Review should be found");

        ReviewComparator.assertEquals(results.getEntries().get(0), expected);
    }

    public void testReviewQueryByProviderMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
        List<Review> entities = this.reviewFactory.create(3, new DataServiceField(ReviewField.provider, "fiji"));
        this.reviewClient.create(entities);

        final String expectedProvider = "columbia";
        List<Review> expecteds = this.reviewFactory.create(2, new DataServiceField(ReviewField.provider, expectedProvider));

        this.reviewClient.create(expecteds);
        Query[] queries = new Query[] { new ByProvider(expectedProvider) };
        Feed<Review> results = this.reviewClient.getAll(null, queries, null, null, null);
        Assert.assertEquals(results.getEntryCount(), new Long(2), "Exact two Review should be found");
        for (Review entity : results.getEntries()) {
            Assert.assertEquals(entity.getProvider(), expectedProvider);
        }
    }
}
