package com.theplatform.data.tv.entity.integration.test.endpoint.programsongassociation;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociation;
import com.theplatform.data.tv.entity.api.test.ProgramSongAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "programSongAssociation", "sort" })
public class ProgramSongAssociationSortIT extends EntityTestBase {

	public void testProgramSongAssociationSortByGuid() {
		List<ProgramSongAssociation> programSongAssociations = programSongAssociationFactory.create(4);
		programSongAssociations.get(0).setGuid("1");
		programSongAssociations.get(3).setGuid("2");
		programSongAssociations.get(1).setGuid("3");
		programSongAssociations.get(2).setGuid("4");

		this.programSongAssociationClient.create(programSongAssociations);

		List<ProgramSongAssociation> expectedSortedProgramSongAssociations = new ArrayList<>(programSongAssociations.size());
		expectedSortedProgramSongAssociations.add(programSongAssociations.get(0));
		expectedSortedProgramSongAssociations.add(programSongAssociations.get(3));
		expectedSortedProgramSongAssociations.add(programSongAssociations.get(1));
		expectedSortedProgramSongAssociations.add(programSongAssociations.get(2));

		Feed<ProgramSongAssociation> retrievedProgramSongAssociations = this.programSongAssociationClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort("guid", false) }, null, false);

		ProgramSongAssociationComparator.assertEquals(retrievedProgramSongAssociations, expectedSortedProgramSongAssociations);
	}

	public void testProgramSongAssociationSortByType() {
		List<ProgramSongAssociation> programSongAssociations = programSongAssociationFactory.create(2);
		programSongAssociations.get(0).setType("MusicVideo");
		programSongAssociations.get(1).setType("FeaturedIn");

		this.programSongAssociationClient.create(programSongAssociations);

		List<ProgramSongAssociation> expectedSortedProgramSongAssociations = new ArrayList<>(programSongAssociations.size());
		expectedSortedProgramSongAssociations.add(programSongAssociations.get(1));
		expectedSortedProgramSongAssociations.add(programSongAssociations.get(0));

		Feed<ProgramSongAssociation> retrievedAlbumCredits = this.programSongAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(
				"type", false) }, null, false);

		ProgramSongAssociationComparator.assertEquals(retrievedAlbumCredits, expectedSortedProgramSongAssociations);
	}
}
