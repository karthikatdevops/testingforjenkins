package com.theplatform.data.tv.entity.integration.test.endpoint.person;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.entity.api.test.PersonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

/**
 * Basic CRUD tests for Person
 * 
 * @since 4/7/2011
 */
@Test(groups = { "person", "crud" })
public class PersonCRUDIT extends EntityTestBase {


	@Test(groups = { TestGroup.gbTest })
	public void crudSinglePerson() throws UnknownHostException {
		Person person = this.personFactory.create();

		// CREATE
		Person persistedPerson = this.personClient.create(person);
		assertEquals(persistedPerson.getId(), person.getId(), "Person ids should match after creation");

		// RETRIEVE
		Person retrievedPerson = this.personClient.get(person.getId(), new String[] {});
		PersonComparator.assertEquals(retrievedPerson, person);

		// UPDATE
		person.setName(person.getName() + " - changed");
		person.setCredits(null);
		person.setImageIds(null);
		person.setSelectedImages(null);
		this.personClient.update(person);
		person.setImageIds(new ArrayList<URI>());
		person.setSelectedImages(new ArrayList<MainImageInfo>());
		person.setCredits(new ArrayList<CreditAssociation>());

		Person retrievedAfterUpdate = this.personClient.get(person.getId(), new String[] {});
		PersonComparator.assertEquals(person, retrievedAfterUpdate);
		assertFalse(retrievedPerson.getName().equals(retrievedAfterUpdate.getName()));

		// DELETE
		long deletedObjects = this.personClient.delete(person.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.personClient.get(person.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("Person should not be found after deleting it");
	}

	public void crudPersonFeed() throws UnknownHostException {
		List<Person> persons = this.personFactory.create(5);
		@SuppressWarnings({ "unchecked" })
		URI[] PersonIds = (URI[]) CollectionUtils.collect(persons, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<Person> persistedPersons = this.personClient.create(persons);
		ComparatorUtils.assertIdsAreEqual(persons, persistedPersons);

		// RETRIEVE
		Feed<Person> retrievedPersons = this.personClient.get(PersonIds, new String[] {});
		PersonComparator.assertEquals(retrievedPersons, persons);

		// DELETE
		long deletedPersons = this.personClient.delete(PersonIds);
		Assert.assertEquals(persons.size(), deletedPersons);

		long notFoundPersons = 0;
		for (Person Person : persons) {
			try {
				this.personClient.get(Person.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundPersons++;
			}
		}
		Assert.assertEquals(notFoundPersons, deletedPersons, "Still found Persons after deleting");
	}
	
	private final DataServiceField[] defaultValues = new DataServiceField[] { 
			new DataServiceField(PersonField.name, null),
			new DataServiceField(PersonField.birth, null),
			new DataServiceField(PersonField.death, null), 
			new DataServiceField(PersonField.birthplace, null), 
			new DataServiceField(PersonField.shortBio, null),
			new DataServiceField(PersonField.mediumBio, null), 
			new DataServiceField(PersonField.longBio, null), 
			new DataServiceField(PersonField.credits, new ArrayList<CreditAssociation>()), 
			new DataServiceField(PersonField.birthName, null), 
			new DataServiceField(PersonField.sortName, null), 
			new DataServiceField(PersonField.aliases, new ArrayList<String>()), 
			new DataServiceField(PersonField.imageIds, new ArrayList<URI>()), 
			new DataServiceField(PersonField.mainImages, new HashMap<String, MediaFile>()), 
			new DataServiceField(PersonField.selectedImages, new ArrayList<MainImageInfo>()), 
			new DataServiceField(PersonField.merlinResourceType, MerlinResourceType.AudienceAvailable), 
					};

	
	@Test(groups = { TestGroup.gbTest })
	public void testPersonCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(personClient, personFactory.create(), PersonComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testPersonCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(personClient, personFactory.create(), PersonComparator.class, this.defaultValues, null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testPersonUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		
		
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(PersonField.name, "name"));
		createValues.add(new DataServiceField(PersonField.birth, new DateOnly()));
		createValues.add(new DataServiceField(PersonField.death, new DateOnly()));
		createValues.add(new DataServiceField(PersonField.birthplace, "birthplace"));
		createValues.add(new DataServiceField(PersonField.shortBio, "shortBio"));
		createValues.add(new DataServiceField(PersonField.mediumBio, "mediumBio"));
		createValues.add(new DataServiceField(PersonField.longBio, "longBio"));
		createValues.add(new DataServiceField(PersonField.birthName, "birthName"));
		createValues.add(new DataServiceField(PersonField.sortName, "sortName"));
		createValues.add(new DataServiceField(PersonField.aliases, Arrays.asList(new String[]{"alises"})));
		createValues.add(new DataServiceField(PersonField.merlinResourceType, MerlinResourceType.Temporary));

		Person person = personFactory.create();

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(personClient, person, PersonComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] { 
			new DataServiceField(PersonField.credits, new ArrayList<CreditAssociation>()),
			new DataServiceField(PersonField.imageIds, new ArrayList<URI>()),
			new DataServiceField(PersonField.mainImages, new HashMap<String, MediaFile>()),
			new DataServiceField(PersonField.selectedImages, new ArrayList<MainImageInfo>()) });
	}
	
	@Test(groups = TestGroup.testBug)//You do not have permission to update 'http://xml.theplatform.com/data/tv/entity/Person:credits
	public void testPersonUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(PersonField.name, "name"));
		createValues.add(new DataServiceField(PersonField.birth, new DateOnly()));
		createValues.add(new DataServiceField(PersonField.death, new DateOnly()));
		createValues.add(new DataServiceField(PersonField.birthplace, "birthplace"));
		createValues.add(new DataServiceField(PersonField.shortBio, "shortBio"));
		createValues.add(new DataServiceField(PersonField.mediumBio, "mediumBio"));
		createValues.add(new DataServiceField(PersonField.longBio, "longBio"));
		createValues.add(new DataServiceField(PersonField.birthName, "birthName"));
		createValues.add(new DataServiceField(PersonField.sortName, "sortName"));
		createValues.add(new DataServiceField(PersonField.aliases, Arrays.asList(new String[]{"alises"})));
		createValues.add(new DataServiceField(PersonField.merlinResourceType, MerlinResourceType.Temporary));

		Person person = personFactory.create();

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(personClient, person, PersonComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] { 
			new DataServiceField(PersonField.credits, new ArrayList<CreditAssociation>()),
			new DataServiceField(PersonField.imageIds, new ArrayList<URI>()),
			new DataServiceField(PersonField.mainImages, new HashMap<String, MediaFile>()),
			new DataServiceField(PersonField.selectedImages, new ArrayList<MainImageInfo>()) });

	}

}
