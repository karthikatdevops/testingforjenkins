package com.theplatform.data.tv.entity.integration.test.endpoint.person;

import static org.testng.Assert.assertEquals;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.test.PersonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * @since 4/7/2011
 */
@Test(groups = { "person" })
public class PersonCollectionCachingIT extends EntityTestBase {

	private PersonClient nodeA_Client;
	private PersonClient nodeB_Client;

	private String NODE_A_BASE_URL = "http://ccpdss-dt-f001-d.dt.ccp.cable.comcast.com:9002/entityDataService";
	private String NODE_B_BASE_URL = "http://ccpdss-dt-f002-d.dt.ccp.cable.comcast.com:9002/entityDataService";
	private String PERSON_END_POINT_URL = "/data/Person/";
	private static final URI DEFAULT_OWNER_ID_URI = URI.create("http://access.auth.dev.dt.ccp.cable.comcast.com/data/Account/1024");

	public PersonCollectionCachingIT() throws UnknownHostException {
		nodeA_Client = new PersonClient(NODE_A_BASE_URL, new NoAuthHeader());
		nodeB_Client = new PersonClient(NODE_B_BASE_URL, new NoAuthHeader());
	}

	@Test(groups = TestGroup.testBug)
	public void testAliasesCaching() throws UnknownHostException {
		Person person = createPerson(NODE_A_BASE_URL);

		// CREATE
		Person persistedPerson = nodeA_Client.create(person);

		// RETRIEVE
		Person retrievedPerson = nodeA_Client.get(persistedPerson.getId(), new String[] {});
		PersonComparator.assertEquals(retrievedPerson, person);

		retrievedPerson = nodeB_Client.get(URI.create(NODE_B_BASE_URL + PERSON_END_POINT_URL + LocalUriConverter.convertUriToID(person.getId())),
				new String[] {});
		assertAliases(retrievedPerson.getAliases(), person.getAliases());

		// UPDATE
		person.setAliases(Arrays.asList("Boy", "Girl"));
		nodeA_Client.update(person);
		Person retrievedAfterUpdateFromNodeA = nodeA_Client.get(person.getId(), new String[] {});
		Person retrievedAfterUpdateFromNodeB = nodeB_Client.get(
				URI.create(NODE_B_BASE_URL + PERSON_END_POINT_URL + LocalUriConverter.convertUriToID(person.getId())), new String[] {});

		// DELETE why this delete logic not in @After because this test only
		// deleting what it created....
		long deletedObjects = nodeA_Client.delete(person.getId());
		assertEquals(deletedObjects, 1);

		// why these lines at the end ? Because we want to delete. If below
		// lines failed then can not delete if deletion logic after these lines.
		PersonComparator.assertEquals(retrievedAfterUpdateFromNodeA, person);
		assertAliases(retrievedAfterUpdateFromNodeB.getAliases(), person.getAliases());
	}

	/**
	 * Create Person
	 * 
	 * @param baseUrl
	 *            String
	 * @return Person
	 */
	private Person createPerson(String baseUrl) {
		Person person = new Person();
		person.setId(URI.create(baseUrl + PERSON_END_POINT_URL + this.objectIdProvider.nextId()));
		person.setOwnerId(DEFAULT_OWNER_ID_URI);
		person.setAliases(Arrays.asList("Tomi", "Harry"));
		return person;
	}

	/**
	 * Assert Person.aliases List<String> values
	 * 
	 * @param expectedAliases
	 *            List<String>
	 * @param actualAliases
	 *            List<String>
	 */
	private void assertAliases(List<String> actualAliases, List<String> expectedAliases) {
		assertEquals(actualAliases.size(), expectedAliases.size(), "Unexpected number of Aliases");
		for (int i = 0; i < expectedAliases.size(); i++) {
			assertEquals(actualAliases.get(i), expectedAliases.get(i));
		}
	}
}
