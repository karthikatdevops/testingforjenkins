package com.theplatform.data.tv.entity.integration.test.testapi;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.StringUtil;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.fields.*;
import com.theplatform.data.tv.entity.api.test.*;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.fields.MainImageTypeField;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import org.testng.annotations.Test;

import java.lang.reflect.InvocationTargetException;

@Test(groups = { TestGroup.gbTest, "testApiTest" })
public class FactoryValidationIT extends EntityTestBase {

	public void validateAlbumCreditFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumCreditClient.create(this.albumCreditFactory.create());
		this.albumCreditClient.create(this.albumCreditFactory.create(2));
		this.albumCreditClient.create(this.albumCreditFactory.create(new DataServiceField(AlbumCreditField.rank, 2)));
		this.albumCreditClient.create(this.albumCreditFactory.create(2, new DataServiceField(AlbumCreditField.rank, 2)));
	}

	public void validateAlbumFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumClient.create(this.albumFactory.create());
		this.albumClient.create(this.albumFactory.create(2));
		this.albumClient.create(this.albumFactory.create(new DataServiceField(DataObjectField.title, "album title adsfads")));
		this.albumClient.create(this.albumFactory.create(2, new DataServiceField(DataObjectField.title, "album title adsfasdf")));
	}

	public void validateAlbumReleaseFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create());
		this.albumReleaseClient.create(this.albumReleaseFactory.create(2));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(DataObjectField.title, "albumRelease title asdfadsfasd")));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(2, new DataServiceField(DataObjectField.title, "albumRelease title asdfadsf")));
	}

	public void validateAlbumReleaseSongAssociationFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create());
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(2));
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.trackNumber, 2)));
		this.albumReleaseSongAssociationClient.create(this.albumReleaseSongAssociationFactory.create(2, new DataServiceField(AlbumReleaseSongAssociationField.trackNumber, 2)));
	}

	public void validateAwardAssociationFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.awardAssociationClient.create(this.awardAssociationFactory.create());
		this.awardAssociationClient.create(this.awardAssociationFactory.create(2));
		this.awardAssociationClient.create(this.awardAssociationFactory.create(new DataServiceField(DataObjectField.description, "")));
		this.awardAssociationClient.create(this.awardAssociationFactory.create(2, new DataServiceField(DataObjectField.description, "")));
	}

	public void validateAwardFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.awardClient.create(awardFactory.create());
		this.awardClient.create(awardFactory.create(2));
		this.awardClient.create(awardFactory.create(new DataServiceField(DataObjectField.description, "")));
		this.awardClient.create(awardFactory.create(2, new DataServiceField(DataObjectField.description, "")));

	}

	public void validateCreditFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.creditClient.create(this.creditFactory.create());
		this.creditClient.create(this.creditFactory.create(2));
		this.creditClient.create(this.creditFactory.create(new DataServiceField(CreditField.rank, 2)));
		this.creditClient.create(this.creditFactory.create(2, new DataServiceField(CreditField.rank, 2)));
	}

	public void validateEntityCollectionFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.entityCollectionClient.create(this.entityCollectionFactory.create());
		this.entityCollectionClient.create(this.entityCollectionFactory.create(2));
		this.entityCollectionClient.create(this.entityCollectionFactory.create(new DataServiceField(DataObjectField.title, "dfg")));
		this.entityCollectionClient.create(this.entityCollectionFactory.create(2, new DataServiceField(DataObjectField.title, "sfdgf")));
	}

	public void validateImageAssociationFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.imageAssociationClient.create(this.imageAssociationFactory.create());
		this.imageAssociationClient.create(this.imageAssociationFactory.create(2));
	}

	public void validateInstitutionFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.institutionClient.create(this.institutionFactory.create());
		this.institutionClient.create(this.institutionFactory.create(2));
		this.institutionClient.create(this.institutionFactory.create(new DataServiceField(DataObjectField.description, "")));
		this.institutionClient.create(this.institutionFactory.create(2, new DataServiceField(DataObjectField.description, "")));
	}

	public void validatePersonFactory() {

		this.personClient.create(personFactory.create());
		this.personClient.create(personFactory.create(2));
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.shortBio, "person shortBio changed")));
		this.personClient.create(personFactory.create(2, new DataServiceField(PersonField.shortBio, "person shortBio changed")));
	}

	@Test(groups = TestGroup.testBug)
	// FIXME complain about can't update Program.credits
	public void validateProgramFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		ProgramEndpointFactory programFactory = EntityFactoryCreator.createProgramFactory(this.getBaseUrl(), objectIdProvider);

		this.programClient.create(programFactory.create());
		this.programClient.create(programFactory.create(2));
		this.programClient.create(programFactory.create(new DataServiceField(ProgramField.shortTitle, "program shortTitle changed")));
		this.programClient.create(programFactory.create(2, new DataServiceField(ProgramField.shortTitle, "program shortTitle changed")));

		ProgramMovieFactory programMovieFactory = EntityFactoryCreator.createProgramMovieFactory(this.getBaseUrl(), objectIdProvider, null);

		this.programClient.create(programMovieFactory.create());
		this.programClient.create(programMovieFactory.create(2));
		this.programClient.create(programMovieFactory.create(new DataServiceField(ProgramField.shortTitle, "program shortTitle changed")));
		this.programClient.create(programMovieFactory.create(2, new DataServiceField(ProgramField.shortTitle, "program shortTitle changed")));

		ProgramEpisodeFactory programEpisodeFactory = EntityFactoryCreator.createProgramEpisodeFactory(this.getBaseUrl(), objectIdProvider, null);

		this.programClient.create(programEpisodeFactory.create());
		this.programClient.create(programEpisodeFactory.create(2));
		this.programClient.create(programEpisodeFactory.create(new DataServiceField(ProgramField.shortTitle, "program shortTitle changed")));
		this.programClient.create(programEpisodeFactory.create(2, new DataServiceField(ProgramField.shortTitle, "program shortTitle changed")));

		ProgramSeriesMasterFactory programSeriesMasterFactory = EntityFactoryCreator
				.createProgramSeriesMasterFactory(this.getBaseUrl(), objectIdProvider, null);

		this.programClient.create(programSeriesMasterFactory.create());
		this.programClient.create(programSeriesMasterFactory.create(2));
		this.programClient.create(programSeriesMasterFactory.create(new DataServiceField(ProgramField.shortTitle, "program shortTitle changed")));
		this.programClient.create(programSeriesMasterFactory.create(2, new DataServiceField(ProgramField.shortTitle, "program shortTitle changed")));
	}

	public void validateProgramMediaAssociationFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.persistingProgramMediaAssociationFactory.create();
		this.persistingProgramMediaAssociationFactory.create(2);
		this.persistingProgramMediaAssociationFactory.create(
				ProgramMediaAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable);
		this.persistingProgramMediaAssociationFactory.create(
				2, ProgramMediaAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable);
	}

	public void validateRelatedAlbumFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedAlbumClient.create(relatedAlbumFactory.create());
		this.relatedAlbumClient.create(relatedAlbumFactory.create(2));
		this.relatedAlbumClient.create(relatedAlbumFactory.create(new DataServiceField(RelatedAlbumField.rank, 2)));
		this.relatedAlbumClient.create(relatedAlbumFactory.create(2, new DataServiceField(RelatedAlbumField.rank, 2)));
	}

	public void validateRelatedPersonFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedPersonClient.create(relatedPersonFactory.create());
		this.relatedPersonClient.create(relatedPersonFactory.create(2));
		this.relatedPersonClient.create(relatedPersonFactory.create(new DataServiceField(RelatedPersonField.rank, 2)));
		this.relatedPersonClient.create(relatedPersonFactory.create(2, new DataServiceField(RelatedPersonField.rank, 2)));
	}

	public void validateRelatedProgramFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedProgramClient.create(relatedProgramFactory.create());
		this.relatedProgramClient.create(relatedProgramFactory.create(2));
		this.relatedProgramClient.create(relatedProgramFactory.create(new DataServiceField(RelatedProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		this.relatedProgramClient.create(relatedProgramFactory.create(2, new DataServiceField(RelatedProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
	}

	public void validateRelatedSongFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedSongClient.create(relatedSongFactory.create());
		this.relatedSongClient.create(relatedSongFactory.create(2));
		this.relatedSongClient.create(relatedSongFactory.create(new DataServiceField(RelatedSongField.rank, 2)));
		this.relatedSongClient.create(relatedSongFactory.create(2, new DataServiceField(RelatedSongField.rank, 2)));
	}

	public void validateReviewFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.reviewClient.create(reviewFactory.create());
		this.reviewClient.create(reviewFactory.create(2));
		this.reviewClient.create(reviewFactory.create(new DataServiceField(ReviewField.summary, "review summary changed")));
		this.reviewClient.create(reviewFactory.create(2, new DataServiceField(ReviewField.summary, "review summary changed")));

	}

	public void validateSongCollectionFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCollectionClient.create(this.songCollectionFactory.create());
		this.songCollectionClient.create(this.songCollectionFactory.create(2));
		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(DataObjectField.title, "23asdf")));
		this.songCollectionClient.create(this.songCollectionFactory.create(2, new DataServiceField(DataObjectField.title, "13413")));
	}

	public void validateSongCreditFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCreditClient.create(this.songCreditFactory.create());
		this.songCreditClient.create(this.songCreditFactory.create(2));
		this.songCreditClient.create(this.songCreditFactory.create(new DataServiceField(SongCreditField.rank, 2)));
		this.songCreditClient.create(this.songCreditFactory.create(2, new DataServiceField(SongCreditField.rank, 2)));
	}

	public void validateSongFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songClient.create(this.songFactory.create());
		this.songClient.create(this.songFactory.create(2));
		this.songClient.create(this.songFactory.create(new DataServiceField(DataObjectField.title, "title")));
		this.songClient.create(this.songFactory.create(2, new DataServiceField(DataObjectField.title, "title")));
	}

	public void validateSportsEventFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.sportsEventClient.create(this.sportsEventFactory.create());
		this.sportsEventClient.create(this.sportsEventFactory.create(2));
		this.sportsEventClient.create(this.sportsEventFactory.create(new DataServiceField(DataObjectField.title, "title")));
		this.sportsEventClient.create(this.sportsEventFactory.create(2, new DataServiceField(DataObjectField.title, "title")));
	}

	public void validateSportsLeagueFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.sportsLeagueClient.create(this.sportsLeagueFactory.create());
		this.sportsLeagueClient.create(this.sportsLeagueFactory.create(2));
		this.sportsLeagueClient.create(this.sportsLeagueFactory.create(new DataServiceField(DataObjectField.title, "title")));
		this.sportsLeagueClient.create(this.sportsLeagueFactory.create(2, new DataServiceField(DataObjectField.title, "title")));
	}

	public void validateSportsTeamFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.sportsTeamClient.create(this.sportsTeamFactory.create());
		this.sportsTeamClient.create(this.sportsTeamFactory.create(2));
		this.sportsTeamClient.create(this.sportsTeamFactory.create(new DataServiceField(SportsTeamField.representingName, "representingName")));
		this.sportsTeamClient.create(this.sportsTeamFactory.create(2, new DataServiceField(SportsTeamField.representingName, "representingName")));
	}

	public void validateTagAssociationFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.tagAssociationClient.create(this.tagAssociationFactory.create());
		this.tagAssociationClient.create(this.tagAssociationFactory.create(2));
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		this.tagAssociationClient
				.create(this.tagAssociationFactory.create(2, new DataServiceField(TagAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
	}

	public void validateTagFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.tagClient.create(this.tagFactory.create());
		this.tagClient.create(this.tagFactory.create(2));
		this.tagClient.create(this.tagFactory.create(new DataServiceField(DataObjectField.title, "title")));
		this.tagAssociationClient.create(this.tagAssociationFactory.create(2, new DataServiceField(DataObjectField.title, "title")));
	}

	public void validateTvSeasonFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.tvSeasonClient.create(this.tvSeasonFactory.create());
		this.tvSeasonClient.create(this.tvSeasonFactory.create(2));
		this.tvSeasonClient.create(this.tvSeasonFactory.create(new DataServiceField(DataObjectField.description, "")));
		this.tvSeasonClient.create(this.tvSeasonFactory.create(2, new DataServiceField(DataObjectField.description, "")));
	}

	public void validateMainImageTypeFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.mainImageTypeClient.create(mainImageTypeFactory.create());
		this.mainImageTypeClient.create(mainImageTypeFactory.create(2));
		this.mainImageTypeClient.create(mainImageTypeFactory.create(new DataServiceField(MainImageTypeField.entityType, "Station")));

	}

	public void validateMainImageTypeGroupFactory() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create());
		this.mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create(2));
		this.mainImageTypeGroupClient.create(mainImageTypeGroupFactory.create(new DataServiceField(DataObjectField.title, "mainImageTypeGroupTitle".concat(StringUtil
				.generateRandomString()))));

	}

}
