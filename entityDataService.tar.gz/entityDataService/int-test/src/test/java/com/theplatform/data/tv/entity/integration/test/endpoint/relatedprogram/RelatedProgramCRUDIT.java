package com.theplatform.data.tv.entity.integration.test.endpoint.relatedprogram;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramMediaAssociationField;
import com.theplatform.data.tv.entity.api.fields.RelatedProgramField;
import com.theplatform.data.tv.entity.api.test.RelatedProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "relatedProgram", "crud" })
public class RelatedProgramCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest, "relatedProgram" })
	public void crudSingleRelatedProgram() throws UnknownHostException {
		
		RelatedProgram relatedProgram = this.relatedProgramFactory.create();
		relatedProgram.setSourceProgram(programClient.get(relatedProgram.getSourceProgramId(), new String[]{}));
		relatedProgram.setTargetProgram(programClient.get(relatedProgram.getTargetProgramId(), new String[]{}));
		// CREATE
		RelatedProgramComparator.assertEquals(this.relatedProgramClient.create(relatedProgram, new String[] {}), relatedProgram);

		// RETRIEVE
		RelatedProgram retrievedRelatedProgram = this.relatedProgramClient.get(relatedProgram.getId(), new String[] {});
		RelatedProgramComparator.assertEquals(retrievedRelatedProgram, relatedProgram);

		// UPDATE
		relatedProgram.setType(relatedProgram.getType() != RelatedProgramType.HasMakingOf.getFriendlyName() ? RelatedProgramType.HasMakingOf.getFriendlyName()
				: RelatedProgramType.HasDerivation.getFriendlyName());
		relatedProgram.setRank(relatedProgram.getRank() == null?Integer.valueOf(1):relatedProgram.getRank()+1);
		relatedProgram.setScore(relatedProgram.getScore() == null?Float.valueOf("1.0"):relatedProgram.getScore()+Float.valueOf("0.01"));
		
		relatedProgram.setSourceProgram(null);
		relatedProgram.setTargetProgram(null);
		this.relatedProgramClient.update(relatedProgram);

		RelatedProgram retrievedAfterUpdate = this.relatedProgramClient.get(relatedProgram.getId(), new String[] {});
		relatedProgram.setSourceProgram(programClient.get(relatedProgram.getSourceProgramId(), new String[]{}));
		relatedProgram.setTargetProgram(programClient.get(relatedProgram.getTargetProgramId(), new String[]{}));
		RelatedProgramComparator.assertEquals(retrievedAfterUpdate, relatedProgram);
		assertFalse(retrievedRelatedProgram.getType().equals(retrievedAfterUpdate.getType()));

		// DELETE
		long deletedObjects = this.relatedProgramClient.delete(relatedProgram.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.relatedProgramClient.get(relatedProgram.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("RelatedProgram should not be found after deleting it");
	}

	@Test(groups = { TestGroup.gbTest, "relatedProgram" })
	public void crudRelatedProgramFeed() throws UnknownHostException {
		List<RelatedProgram> relatedPrograms = this.relatedProgramFactory.create(5);
		for ( int i=0; i<relatedPrograms.size();i++){
			relatedPrograms.get(i).setSourceProgram(programClient.get(relatedPrograms.get(i).getSourceProgramId(), new String[]{}));
			relatedPrograms.get(i).setTargetProgram(programClient.get(relatedPrograms.get(i).getTargetProgramId(), new String[]{}));
		}

		// CREATE
		Feed<RelatedProgram> persistedRelatedPrograms = this.relatedProgramClient.create(relatedPrograms, new String[]{});
		
		RelatedProgramComparator.assertEquals(persistedRelatedPrograms, relatedPrograms);
		
		List<URI> ids = new ArrayList<>();
		for(RelatedProgram relatedProgram: relatedPrograms)
			ids.add(relatedProgram.getId());
		URI[] relatedProgramIds = ids.toArray(new URI[]{});

		// RETRIEVE
		Feed<RelatedProgram> retrievedRelatedPrograms = this.relatedProgramClient.get(relatedProgramIds, new String[] {});
		RelatedProgramComparator.assertEquals(retrievedRelatedPrograms, relatedPrograms);

		// DELETE
		long deletedRelatedPrograms = this.relatedProgramClient.delete(relatedProgramIds);
		assertEquals(deletedRelatedPrograms, relatedPrograms.size());

		long notFoundRelatedPrograms = 0;
		for (RelatedProgram RelatedProgram : relatedPrograms) {
			try {
				this.relatedProgramClient.get(RelatedProgram.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundRelatedPrograms++;
			}
		}
		assertEquals(notFoundRelatedPrograms, deletedRelatedPrograms, "Still found RelatedPrograms after deleting");
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(RelatedProgramField.justification, null),
			// default to leastVisible(TargetProgram.merlinResourceType,
			// sourceProgram.merlinResourceType)
			new DataServiceField(ProgramMediaAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable),
			new DataServiceField(RelatedProgramField.rank, null),
			new DataServiceField(RelatedProgramField.score, null)};

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedProgramCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		RelatedProgram relatedProgram = relatedProgramFactory.create();
		Program sourceProgram = programClient.get(relatedProgram.getSourceProgramId(), new String[] {});
		Program targetProgram = programClient.get(relatedProgram.getTargetProgramId(), new String[] {});

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(relatedProgramClient, relatedProgram, RelatedProgramComparator.class, this.defaultValues,
				new DataServiceField[] { new DataServiceField(RelatedProgramField.sourceProgram, sourceProgram),
						new DataServiceField(RelatedProgramField.targetProgram, targetProgram) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedProgramCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		RelatedProgram relatedProgram = relatedProgramFactory.create();
		Program sourceProgram = programClient.get(relatedProgram.getSourceProgramId(), new String[] {});
		Program targetProgram = programClient.get(relatedProgram.getTargetProgramId(), new String[] {});

		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(relatedProgramClient, relatedProgram, RelatedProgramComparator.class,
				this.defaultValues, new DataServiceField[] { new DataServiceField(RelatedProgramField.sourceProgram, sourceProgram),
						new DataServiceField(RelatedProgramField.targetProgram, targetProgram) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedProgramUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		RelatedProgram relatedProgram = relatedProgramFactory.create();
		Program sourceProgram = programClient.get(relatedProgram.getSourceProgramId(), new String[] {});
		Program targetProgram = programClient.get(relatedProgram.getTargetProgramId(), new String[] {});

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(RelatedProgramField.justification, "relatedProgram justification"));
		createValues.add(new DataServiceField(RelatedProgramField.merlinResourceType, MerlinResourceType.Temporary));
		createValues.add(new DataServiceField(RelatedProgramField.rank, Integer.valueOf(2)));
		createValues.add(new DataServiceField(RelatedProgramField.score, Float.valueOf("3.7")));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(relatedProgramClient, relatedProgram, RelatedProgramComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(RelatedProgramField.sourceProgram, sourceProgram),
						new DataServiceField(RelatedProgramField.targetProgram, targetProgram) });
	}

	@Test(groups = TestGroup.gbTest)
	public void testRelatedProgramUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		RelatedProgram relatedProgram = relatedProgramFactory.create();
		Program sourceProgram = programClient.get(relatedProgram.getSourceProgramId(), new String[] {});
		Program targetProgram = programClient.get(relatedProgram.getTargetProgramId(), new String[] {});

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(RelatedProgramField.justification, "relatedProgram justification"));
		createValues.add(new DataServiceField(RelatedProgramField.merlinResourceType, MerlinResourceType.Temporary));
		createValues.add(new DataServiceField(RelatedProgramField.rank, Integer.valueOf(2)));
		createValues.add(new DataServiceField(RelatedProgramField.score, Float.valueOf("3.7")));
		
		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(relatedProgramClient, relatedProgram, RelatedProgramComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(RelatedProgramField.sourceProgram, sourceProgram),
						new DataServiceField(RelatedProgramField.targetProgram, targetProgram) });
	}

}
