package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import java.net.URI;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.IdGenerator;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramTypeSpecificUtils;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * Test cases to ensure that a program being updated from one type to another
 * behaves correctly. An episode will be updated to a minisode.
 * 
 * @author wpearce
 * @since 02/01/2012
 */
@Test(groups = { "program", "other" })
public class ProgramUpdateEpisodeToMinisodeIT extends EntityTestBase {
	/**
	 * A test showing that a program type can be changed when there are no
	 * fields that exist in one program type, but not the other.
	 * 
	 * @throws Exception
	 */
	public void updateEpisodeToMinisode() throws Exception {
		Program program = new Program();
		program.setId(URI.create(programClient.getBaseUrl() + "data/Program/" + objectIdProvider.nextId()));
		program.setType(ProgramType.Episode);
		program.setCategory(ProgramCategory.Other.name());

		programClient.create(program);

		program.setType(ProgramType.Minisode);
		programClient.update(program);
	}

	/**
	 * A test showing that a program type can be changed when there are fields
	 * that exist in one program type, but not the other.
	 * 
	 * @throws Exception
	 */
	public void updateEpisodeToMinisodeWithNonExistantField() throws Exception {
		Program program = new Program();
		program.setId(URI.create(programClient.getBaseUrl() + "data/Program/" + this.objectIdProvider.nextId()));
		program.setType(ProgramType.Episode);
		program.setCategory(ProgramCategory.Other.name());
		// this field is not applicable to minisodes
		program.setEpisodeTitle("Episode Title - The Final Frontier");

		programClient.create(program);

		program.setType(ProgramType.Minisode);
		ProgramTypeSpecificUtils.nullOutInconsistentTypeSpecificFields(program);
		programClient.update(program);
	}
}
