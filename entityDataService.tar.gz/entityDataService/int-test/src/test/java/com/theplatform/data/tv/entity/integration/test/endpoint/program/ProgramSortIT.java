package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.client.query.program.ByType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "program", "sort", TestGroup.gbTest })
public class ProgramSortIT extends EntityTestBase {

	public void testProgramSortById() {

		List<Program> programs = this.programFactory.create(4, new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));

		Long id1 = this.objectIdProvider.nextId(), id2 = this.objectIdProvider.nextId(), id3 = this.objectIdProvider.nextId(), id4 = this.objectIdProvider
				.nextId();

		Assert.assertTrue(id1 < id2);
		Assert.assertTrue(id2 < id3);
		Assert.assertTrue(id3 < id4);

		programs.get(3).setId(URI.create(this.getBaseUrl().concat("/data/Program/" + id1)));
		programs.get(0).setId(URI.create(this.getBaseUrl().concat("/data/Program/" + id2)));
		programs.get(1).setId(URI.create(this.getBaseUrl().concat("/data/Program/" + id3)));
		programs.get(2).setId(URI.create(this.getBaseUrl().concat("/data/Program/" + id4)));

		programs.set(3, this.programClient.create(programs.get(3), new String[] {}));
		programs.set(0, this.programClient.create(programs.get(0), new String[] {}));
		programs.set(1, this.programClient.create(programs.get(1), new String[] {}));
		programs.set(2, this.programClient.create(programs.get(2), new String[] {}));

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(1));
		expectedSortedPrograms.add(programs.get(2));

		Sort requestSort = new Sort(DataObjectField.id.getLocalName(), false);
		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByTitle() {
		List<Program> programs = this.programFactory.create(4, new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		programs.get(0).setTitle("A");
		programs.get(2).setTitle("B");
		programs.get(3).setTitle("C");
		programs.get(1).setTitle("D");

		this.programClient.create(programs);

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(2));
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(1));

		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(DataObjectField.title.getLocalName(), false) }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByYear() {
		List<Program> programs = this.programFactory.create(4,
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));

		programs.get(3).setYear(1);
		programs.get(0).setYear(2);
		programs.get(1).setYear(3);
		programs.get(2).setYear(4);
		Assert.assertTrue(programs.get(3).getYear() < programs.get(0).getYear());
		Assert.assertTrue(programs.get(0).getYear() < programs.get(1).getYear());
		Assert.assertTrue(programs.get(1).getYear() < programs.get(2).getYear());

		programs.set(3, this.programClient.create(programs.get(3), new String[] {}));
		programs.set(0, this.programClient.create(programs.get(0), new String[] {}));
		programs.set(1, this.programClient.create(programs.get(1), new String[] {}));
		programs.set(2, this.programClient.create(programs.get(2), new String[] {}));

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(1));
		expectedSortedPrograms.add(programs.get(2));

		Sort requestSort = new Sort(ProgramField.year.getLocalName(), false);
		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByRuntime() {
		List<Program> programs = this.programFactory.create(4,
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));

		programs.get(3).setRuntime(1);
		programs.get(0).setRuntime(2);
		programs.get(1).setRuntime(3);
		programs.get(2).setRuntime(4);
		Assert.assertTrue(programs.get(3).getRuntime() < programs.get(0).getRuntime());
		Assert.assertTrue(programs.get(0).getRuntime() < programs.get(1).getRuntime());
		Assert.assertTrue(programs.get(1).getRuntime() < programs.get(2).getRuntime());

		programs.set(3, this.programClient.create(programs.get(3), new String[] {}));
		programs.set(0, this.programClient.create(programs.get(0), new String[] {}));
		programs.set(1, this.programClient.create(programs.get(1), new String[] {}));
		programs.set(2, this.programClient.create(programs.get(2), new String[] {}));

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(1));
		expectedSortedPrograms.add(programs.get(2));

		Sort requestSort = new Sort(ProgramField.runtime.getLocalName(), false);
		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByType() {
		ArrayList<Program> programs = new ArrayList<Program>();
		programs.add(this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>())));
		programs.add(this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>())));
		programs.add(this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>())));
		programs.add(this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>())));

		Assert.assertEquals(programs.get(0).getType(), ProgramType.Movie);
		Assert.assertEquals(programs.get(1).getType(), ProgramType.Concert);
		Assert.assertEquals(programs.get(2).getType(), ProgramType.Episode);
		Assert.assertEquals(programs.get(3).getType(), ProgramType.SeriesMaster);

		this.programClient.create(programs);

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(2));
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(1));

		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(ProgramField.type.getLocalName(),
				false) }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByLanguage() {
		List<Program> programs = this.programFactory.create(4,
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		programs.get(0).setLanguage("aar");
		programs.get(2).setLanguage("arc");
		programs.get(3).setLanguage("chi");
		programs.get(1).setLanguage("del");

		this.programClient.create(programs);

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(2));
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(1));

		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(ProgramField.language.getLocalName(), false) }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByPartNumber() {
		List<Program> programs = this.programFactory.create(4,
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));

		programs.get(3).setPartNumber(1);
		programs.get(0).setPartNumber(2);
		programs.get(1).setPartNumber(3);
		programs.get(2).setPartNumber(4);
		Assert.assertTrue(programs.get(3).getPartNumber() < programs.get(0).getPartNumber());
		Assert.assertTrue(programs.get(0).getPartNumber() < programs.get(1).getPartNumber());
		Assert.assertTrue(programs.get(1).getPartNumber() < programs.get(2).getPartNumber());

		programs.set(3, this.programClient.create(programs.get(3), new String[] {}));
		programs.set(0, this.programClient.create(programs.get(0), new String[] {}));
		programs.set(1, this.programClient.create(programs.get(1), new String[] {}));
		programs.set(2, this.programClient.create(programs.get(2), new String[] {}));

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(1));
		expectedSortedPrograms.add(programs.get(2));

		Sort requestSort = new Sort(ProgramField.partNumber.getLocalName(), false);
		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByTotalParts() {
		List<Program> programs = this.programFactory.create(4,
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));

		programs.get(3).setTotalParts(1);
		programs.get(0).setTotalParts(2);
		programs.get(1).setTotalParts(3);
		programs.get(2).setTotalParts(4);
		Assert.assertTrue(programs.get(3).getTotalParts() < programs.get(0).getTotalParts());
		Assert.assertTrue(programs.get(0).getTotalParts() < programs.get(1).getTotalParts());
		Assert.assertTrue(programs.get(1).getTotalParts() < programs.get(2).getTotalParts());

		programs.set(3, this.programClient.create(programs.get(3), new String[] {}));
		programs.set(0, this.programClient.create(programs.get(0), new String[] {}));
		programs.set(1, this.programClient.create(programs.get(1), new String[] {}));
		programs.set(2, this.programClient.create(programs.get(2), new String[] {}));

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(1));
		expectedSortedPrograms.add(programs.get(2));

		Sort requestSort = new Sort(ProgramField.totalParts.getLocalName(), false);
		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByStarRating() {
		List<Program> programs = this.programFactory.create(4,
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));

		programs.get(3).setStarRating(1);
		programs.get(0).setStarRating(2);
		programs.get(1).setStarRating(3);
		programs.get(2).setStarRating(4);
		Assert.assertTrue(programs.get(3).getStarRating() < programs.get(0).getStarRating());
		Assert.assertTrue(programs.get(0).getStarRating() < programs.get(1).getStarRating());
		Assert.assertTrue(programs.get(1).getStarRating() < programs.get(2).getStarRating());

		programs.set(3, this.programClient.create(programs.get(3), new String[] {}));
		programs.set(0, this.programClient.create(programs.get(0), new String[] {}));
		programs.set(1, this.programClient.create(programs.get(1), new String[] {}));
		programs.set(2, this.programClient.create(programs.get(2), new String[] {}));

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(1));
		expectedSortedPrograms.add(programs.get(2));

		Sort requestSort = new Sort(ProgramField.starRating.getLocalName(), false);
		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByReleaseDate() {
		List<Program> programs = this.movieProgramFactory.create(4,new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		DateOnly releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(11);
		releaseDate.setDay(4);

		programs.get(0).setReleaseDate(releaseDate);
		releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(12);
		releaseDate.setDay(4);
		programs.get(2).setReleaseDate(releaseDate);
		releaseDate = new DateOnly();
		releaseDate.setYear(1980);
		releaseDate.setMonth(12);
		releaseDate.setDay(6);
		programs.get(3).setReleaseDate(releaseDate);

		releaseDate = new DateOnly();
		releaseDate.setYear(2012);
		releaseDate.setMonth(12);
		releaseDate.setDay(4);
		programs.get(1).setReleaseDate(releaseDate);

		this.programClient.create(programs);

		List<Program> expected = new ArrayList<Program>(programs.size());
		expected.add(programs.get(0));
		expected.add(programs.get(2));
		expected.add(programs.get(3));
		expected.add(programs.get(1));

		Feed<Program> actual = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(ProgramField.releaseDate.getLocalName(),
				false) }, null, false);

		ProgramComparator.assertEquals(actual, expected);
	}

	public void testProgramSortBySeriesId() {
		URI seriesId1 = this.programClient.create(this.seriesMasterProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster))).getId();
		URI seriesId2 = this.programClient.create(this.seriesMasterProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster))).getId();
		URI seriesId3 = this.programClient.create(this.seriesMasterProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster))).getId();
		URI seriesId4 = this.programClient.create(this.seriesMasterProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.SeriesMaster))).getId();

		Assert.assertTrue(URIUtils.getIdValue(seriesId1) < URIUtils.getIdValue(seriesId2));
		Assert.assertTrue(URIUtils.getIdValue(seriesId2) < URIUtils.getIdValue(seriesId3));
		Assert.assertTrue(URIUtils.getIdValue(seriesId3) < URIUtils.getIdValue(seriesId4));

		List<Program> programs = this.episodeProgramFactory.create(4, new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		programs.get(0).setSeriesId(seriesId1);
		programs.get(3).setSeriesId(seriesId2);
		programs.get(1).setSeriesId(seriesId3);
		programs.get(2).setSeriesId(seriesId4);

		this.programClient.create(programs);

		List<Program> expected = new ArrayList<Program>(programs.size());
		expected.add(programs.get(0));
		expected.add(programs.get(3));
		expected.add(programs.get(1));
		expected.add(programs.get(2));

		Feed<Program> actual = this.programClient.getOwned(new String[] {}, new Query[] { new ByType(ProgramType.Episode) }, new Sort[] { new Sort(
				ProgramField.seriesId.getLocalName(), false) }, null, false);

		ProgramComparator.assertEquals(actual, expected);
	}

	public void testProgramSortByTvSeasonId() {
		final URI tvSeasonId1 = this.tvSeasonClient.create(this.tvSeasonFactory.create()).getId();
		final URI tvSeasonId2 = this.tvSeasonClient.create(this.tvSeasonFactory.create()).getId();
		final URI tvSeasonId3 = this.tvSeasonClient.create(this.tvSeasonFactory.create()).getId();
		final URI tvSeasonId4 = this.tvSeasonClient.create(this.tvSeasonFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(tvSeasonId1) < URIUtils.getIdValue(tvSeasonId2));
		Assert.assertTrue(URIUtils.getIdValue(tvSeasonId2) < URIUtils.getIdValue(tvSeasonId3));
		Assert.assertTrue(URIUtils.getIdValue(tvSeasonId3) < URIUtils.getIdValue(tvSeasonId4));

		List<Program> programs = this.episodeProgramFactory.create(4,new DataServiceField(ProgramField.type, ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		programs.get(0).setTvSeasonId(tvSeasonId1);
		programs.get(3).setTvSeasonId(tvSeasonId2);
		programs.get(1).setTvSeasonId(tvSeasonId3);
		programs.get(2).setTvSeasonId(tvSeasonId4);

		this.programClient.create(programs);

		List<Program> expected = new ArrayList<Program>(programs.size());
		expected.add(programs.get(0));
		expected.add(programs.get(3));
		expected.add(programs.get(1));
		expected.add(programs.get(2));

		Feed<Program> actual = this.programClient.getOwned(new String[] {}, new Query[] { new ByType(ProgramType.Episode) }, new Sort[] { new Sort(
				ProgramField.tvSeasonId.getLocalName(), false) }, null, false);

		ProgramComparator.assertEquals(actual, expected);
	}

	public void testProgramSortByOriginalAirDate() {
		List<Program> programs = this.programFactory.create(4,
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		DateOnly originalAirDate = new DateOnly();
		originalAirDate.setYear(1980);
		originalAirDate.setMonth(11);
		originalAirDate.setDay(4);

		programs.get(0).setOriginalAirDate(originalAirDate);
		originalAirDate = new DateOnly();
		originalAirDate.setYear(1980);
		originalAirDate.setMonth(12);
		originalAirDate.setDay(4);
		programs.get(2).setOriginalAirDate(originalAirDate);
		originalAirDate = new DateOnly();
		originalAirDate.setYear(1980);
		originalAirDate.setMonth(12);
		originalAirDate.setDay(6);
		programs.get(3).setOriginalAirDate(originalAirDate);

		originalAirDate = new DateOnly();
		originalAirDate.setYear(2012);
		originalAirDate.setMonth(12);
		originalAirDate.setDay(4);
		programs.get(1).setOriginalAirDate(originalAirDate);

		this.programClient.create(programs);

		List<Program> expected = new ArrayList<Program>(programs.size());
		expected.add(programs.get(0));
		expected.add(programs.get(2));
		expected.add(programs.get(3));
		expected.add(programs.get(1));

		Feed<Program> actual = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(ProgramField.originalAirDate.getLocalName(),
				false) }, null, false);

		ProgramComparator.assertEquals(actual, expected);
	}

	public void testProgramSortByTvSeasonNumber() {
		List<Program> programs = this.programFactory.create(4, new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));

		programs.get(3).setTvSeasonNumber(1);
		programs.get(0).setTvSeasonNumber(2);
		programs.get(1).setTvSeasonNumber(3);
		programs.get(2).setTvSeasonNumber(4);
		Assert.assertTrue(programs.get(3).getTvSeasonNumber() < programs.get(0).getTvSeasonNumber());
		Assert.assertTrue(programs.get(0).getTvSeasonNumber() < programs.get(1).getTvSeasonNumber());
		Assert.assertTrue(programs.get(1).getTvSeasonNumber() < programs.get(2).getTvSeasonNumber());

		programs.set(3, this.programClient.create(programs.get(3), new String[] {}));
		programs.set(0, this.programClient.create(programs.get(0), new String[] {}));
		programs.set(1, this.programClient.create(programs.get(1), new String[] {}));
		programs.set(2, this.programClient.create(programs.get(2), new String[] {}));

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(1));
		expectedSortedPrograms.add(programs.get(2));

		Sort requestSort = new Sort(ProgramField.tvSeasonNumber.getLocalName(), false);
		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByEpisodeTitle() {
		List<Program> programs = this.programFactory.create(4, new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		programs.get(0).setEpisodeTitle("A");
		programs.get(2).setEpisodeTitle("B");
		programs.get(3).setEpisodeTitle("C");
		programs.get(1).setEpisodeTitle("D");

		this.programClient.create(programs);

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(2));
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(1));

		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(ProgramField.episodeTitle.getLocalName(), false) }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}

	public void testProgramSortByFirstAirDate() {
		List<Program> programs = this.seriesMasterProgramFactory.create(4,new DataServiceField(ProgramField.type,ProgramType.SeriesMaster), new DataServiceField(ProgramField.lastAirDate, null));
		DateOnly firstAirDate = new DateOnly();
		firstAirDate.setYear(1980);
		firstAirDate.setMonth(11);
		firstAirDate.setDay(4);

		programs.get(0).setFirstAirDate(firstAirDate);
		firstAirDate = new DateOnly();
		firstAirDate.setYear(1980);
		firstAirDate.setMonth(12);
		firstAirDate.setDay(4);
		programs.get(2).setFirstAirDate(firstAirDate);
		firstAirDate = new DateOnly();
		firstAirDate.setYear(1980);
		firstAirDate.setMonth(12);
		firstAirDate.setDay(6);
		programs.get(3).setFirstAirDate(firstAirDate);

		firstAirDate = new DateOnly();
		firstAirDate.setYear(2012);
		firstAirDate.setMonth(12);
		firstAirDate.setDay(4);
		programs.get(1).setFirstAirDate(firstAirDate);

		this.programClient.create(programs);

		List<Program> expected = new ArrayList<Program>(programs.size());
		expected.add(programs.get(0));
		expected.add(programs.get(2));
		expected.add(programs.get(3));
		expected.add(programs.get(1));

		Feed<Program> actual = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(ProgramField.firstAirDate.getLocalName(),
				false) }, null, false);

		ProgramComparator.assertEquals(actual, expected);
	}

	public void testProgramSortByLastAirDate() {
		List<Program> programs = this.seriesMasterProgramFactory.create(4,new DataServiceField(ProgramField.type,ProgramType.SeriesMaster), new DataServiceField(ProgramField.firstAirDate, null));
		DateOnly lastAirDate = new DateOnly();
		lastAirDate.setYear(1980);
		lastAirDate.setMonth(11);
		lastAirDate.setDay(4);

		programs.get(0).setLastAirDate(lastAirDate);
		lastAirDate = new DateOnly();
		lastAirDate.setYear(1980);
		lastAirDate.setMonth(12);
		lastAirDate.setDay(4);
		programs.get(2).setLastAirDate(lastAirDate);
		lastAirDate = new DateOnly();
		lastAirDate.setYear(1980);
		lastAirDate.setMonth(12);
		lastAirDate.setDay(6);
		programs.get(3).setLastAirDate(lastAirDate);

		lastAirDate = new DateOnly();
		lastAirDate.setYear(2012);
		lastAirDate.setMonth(12);
		lastAirDate.setDay(4);
		programs.get(1).setLastAirDate(lastAirDate);

		this.programClient.create(programs);

		List<Program> expected = new ArrayList<Program>(programs.size());
		expected.add(programs.get(0));
		expected.add(programs.get(2));
		expected.add(programs.get(3));
		expected.add(programs.get(1));

		Feed<Program> actual = this.programClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort(ProgramField.lastAirDate.getLocalName(),
				false) }, null, false);

		ProgramComparator.assertEquals(actual, expected);
	}

	public void testProgramSortBySortTitle() {
		List<Program> programs = this.programFactory.create(4, new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		programs.get(0).setSortTitle("A");
		programs.get(2).setSortTitle("B");
		programs.get(3).setSortTitle("C");
		programs.get(1).setSortTitle("D");

		this.programClient.create(programs);

		List<Program> expectedSortedPrograms = new ArrayList<Program>(programs.size());
		expectedSortedPrograms.add(programs.get(0));
		expectedSortedPrograms.add(programs.get(2));
		expectedSortedPrograms.add(programs.get(3));
		expectedSortedPrograms.add(programs.get(1));

		Feed<Program> retrievedPrograms = this.programClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(ProgramField.sortTitle.getLocalName(), false) }, null, false);

		ProgramComparator.assertEquals(retrievedPrograms, expectedSortedPrograms);
	}
}
