package com.theplatform.data.tv.entity.integration.test.endpoint.programsongassociation;

import java.net.URI;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.fields.ProgramSongAssociationField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "programSongAssociation", "validation" })
public class ProgramSongAssociationValidationIT extends EntityTestBase {

	@DataProvider
	private Object[][] audienceAvailableAndTemporaryTypes() {
		return new Object[][] { { MerlinResourceType.AudienceAvailable }, { MerlinResourceType.Temporary } };
	}

	@DataProvider
	private Object[][] editorialAndInactiveTypes() {
		return new Object[][] { { MerlinResourceType.Editorial }, { MerlinResourceType.Inactive } };
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryTypes")
	public void testProgramSongAssociationCreationWithNullSongIdAudienceAvailableAndTemporary(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.songId, null),
				new DataServiceField(ProgramSongAssociationField.merlinResourceType, merlinResourceType)));
	}

	@Test(dataProvider = "editorialAndInactiveTypes")
	public void testProgramSongAssociationCreationWithNullSongIdEditorialAndInactive(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.songId, null),
				new DataServiceField(ProgramSongAssociationField.merlinResourceType, merlinResourceType)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryTypes")
	public void testProgramSongAssociationCreationWithNonpersistedSongAudienceAvailableAndTemporary(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.songId, songFactory
				.create().getId()), new DataServiceField(ProgramSongAssociationField.merlinResourceType, merlinResourceType)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "editorialAndInactiveTypes")
	public void testProgramSongAssociationCreationWithNonpersistedSongEditorialAndInactive(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.songId, songFactory
				.create().getId()), new DataServiceField(ProgramSongAssociationField.merlinResourceType, merlinResourceType)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryTypes")
	public void testProgramSongAssociationCreationWithNonlocalSongAudienceAvailableAndTemporary(MerlinResourceType merlinResourceType) {

		URI localSongId = this.songClient.create(this.songFactory.create()).getId();
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(
				new DataServiceField(ProgramSongAssociationField.songId, songFactory.create(
						new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9002/entityDataService/data/Song/"
								+ URIUtils.getIdValue(localSongId)))).getId()), new DataServiceField(ProgramSongAssociationField.merlinResourceType,
						merlinResourceType)));
	}

	@Test(dataProvider = "editorialAndInactiveTypes")
	public void testProgramSongAssociationCreationWithNonlocalSongEditorialAndInactive(MerlinResourceType merlinResourceType) {

		URI localSongId = this.songClient.create(this.songFactory.create()).getId();
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(
				new DataServiceField(ProgramSongAssociationField.songId, songFactory.create(
						new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9002/entityDataService/data/Song/"
								+ URIUtils.getIdValue(localSongId)))).getId()), new DataServiceField(ProgramSongAssociationField.merlinResourceType,
						merlinResourceType)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryTypes")
	public void testProgramSongAssociationCreationWithNullProgramIdAudienceAvailableAndTemporary(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, null),
				new DataServiceField(ProgramSongAssociationField.merlinResourceType, merlinResourceType)));
	}

	@Test(dataProvider = "editorialAndInactiveTypes")
	public void testProgramSongAssociationCreationWithNullProgramIdEditorialAndInactive(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId, null),
				new DataServiceField(ProgramSongAssociationField.merlinResourceType, merlinResourceType)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryTypes")
	public void testProgramSongAssociationCreationWithNonpersistedProgramAudienceAvailableAndTemporary(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId,
				songFactory.create().getId()), new DataServiceField(ProgramSongAssociationField.merlinResourceType, merlinResourceType)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "editorialAndInactiveTypes")
	public void testProgramSongAssociationCreationWithNonpersistedProgramEditorialAndInactive(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.programId,
				songFactory.create().getId()), new DataServiceField(ProgramSongAssociationField.merlinResourceType, merlinResourceType)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryTypes")
	public void testProgramSongAssociationCreationWithNonlocalProgramAudienceAvailableAndTemporary(MerlinResourceType merlinResourceType) {

		URI localProgramId = this.programClient.create(this.programFactory.create()).getId();
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(
				new DataServiceField(ProgramSongAssociationField.programId, programFactory.create(
						new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9002/entityDataService/data/Program/"
								+ URIUtils.getIdValue(localProgramId)))).getId()), new DataServiceField(ProgramSongAssociationField.merlinResourceType,
						merlinResourceType)));
	}

	@Test(dataProvider = "editorialAndInactiveTypes")
	public void testProgramSongAssociationCreationWithNonlocalProgramEditorialAndInactive(MerlinResourceType merlinResourceType) {

		URI localProgramId = this.programClient.create(this.programFactory.create()).getId();
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(
				new DataServiceField(ProgramSongAssociationField.programId, programFactory.create(
						new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9002/entityDataService/data/Program/"
								+ URIUtils.getIdValue(localProgramId)))).getId()), new DataServiceField(ProgramSongAssociationField.merlinResourceType,
						merlinResourceType)));
	}

	@Test(dataProvider = "validTypes")
	public void testProgramSongAssociationCreationWithValidTypes(String validType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.type, validType),
				new DataServiceField(ProgramSongAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.type, validType),
				new DataServiceField(ProgramSongAssociationField.merlinResourceType, MerlinResourceType.Temporary)));
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.type, validType),
				new DataServiceField(ProgramSongAssociationField.merlinResourceType, MerlinResourceType.Editorial)));
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(new DataServiceField(ProgramSongAssociationField.type, validType),
				new DataServiceField(ProgramSongAssociationField.merlinResourceType, MerlinResourceType.Inactive)));
	}

	@DataProvider
	public Object[][] validTypes() {
		return new Object[][] { { "MusicVideo" }, { "FeaturedIn" } };
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryTypes")
	public void testProgramSongAssociationCreationWithInvalidTypesAudienceAvailableAndTemporary(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(
				new DataServiceField(ProgramSongAssociationField.type, "invalidType"), new DataServiceField(ProgramSongAssociationField.merlinResourceType,
						merlinResourceType)));
	}

	@Test(expectedExceptions = ValidationException.class, dataProvider = "editorialAndInactiveTypes")
	public void testProgramSongAssociationCreationWithInvalidTypesEditorialAndInactive(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(
				new DataServiceField(ProgramSongAssociationField.type, "invalidType"), new DataServiceField(ProgramSongAssociationField.merlinResourceType,
						merlinResourceType)));
	}
	@Test(dataProvider = "editorialAndInactiveTypes")
	public void testProgramSongAssociationCreationWithNullTypeEditorialAndInactive(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(
				new DataServiceField(ProgramSongAssociationField.type, null), new DataServiceField(ProgramSongAssociationField.merlinResourceType,
						merlinResourceType)));
	}
	@Test(expectedExceptions = ValidationException.class, dataProvider = "audienceAvailableAndTemporaryTypes")
	public void testProgramSongAssociationCreationWithNullTypeAudienceAvailableAndTemporary(MerlinResourceType merlinResourceType) {
		this.programSongAssociationClient.create(this.programSongAssociationFactory.create(
				new DataServiceField(ProgramSongAssociationField.type, null), new DataServiceField(ProgramSongAssociationField.merlinResourceType,
						merlinResourceType)));
	}

}
