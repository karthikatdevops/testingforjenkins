package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagefile;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.fail;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.image.api.test.MainImageFileComparator;

/**
 * Basic CRUD tests for Main Image File
 * 
 * @since 4/7/2011
 */
@Test(groups = { "crud", "mainImageFile" })
public class MainImageFileCRUDIT extends EntityTestBase {



	@Test(groups = { TestGroup.bug }) //FIXME MERLIN-XXXX locked is not nullable
	public void crudSingleMainImageFile() throws UnknownHostException {
		MainImageFile mainImageFile = this.mainImageFileFactory.create();

		// CREATE
		MainImageFile persistedMainImageFile = this.mainImageFileClient.create(mainImageFile, new String[] {});
		mainImageFile.setId(persistedMainImageFile.getId());
		mainImageFile.setMainImageType(new MainImageType());
		mainImageFile.getMainImageType().setEntityType(mainImageTypeClient.get(mainImageFile.getMainImageTypeId(), new String[] {}).getEntityType());
		MainImageFileComparator.assertEquals(persistedMainImageFile, mainImageFile);

		// RETRIEVE
		MainImageFile retrievedMainImageFile = this.mainImageFileClient.get(mainImageFile.getId(), new String[] {});
		MainImageFileComparator.assertEquals(retrievedMainImageFile, mainImageFile);

		// UPDATE
		mainImageFile.setHeight(retrievedMainImageFile.getHeight() + 100);
		
		MediaId mediaId = new MediaId();
		if (mainImageFile.getMediaId()!= null){
		mediaId.setAccountGuid(mainImageFile.getMediaId().getAccountGuid()==null? "accountGuid": mainImageFile.getMediaId().getAccountGuid().concat(" updated"));
		mediaId.setServiceGuid(mainImageFile.getMediaId().getServiceGuid()==null? "serviceGuid": mainImageFile.getMediaId().getServiceGuid().concat(" updated"));
		mediaId.setMediaGuid(mainImageFile.getMediaId().getMediaGuid()==null? "mediaGuid": mainImageFile.getMediaId().getMediaGuid().concat(" updated"));
		} else {
			mediaId.setAccountGuid("accountGuid"); 
			mediaId.setServiceGuid("serviceGuid"); 
			mediaId.setMediaGuid("mediaGuid");
		}
		mainImageFile.setMediaId(mediaId);
		
		this.mainImageFileClient.update(mainImageFile);

		MainImageFile retrievedAfterUpdate = this.mainImageFileClient.get(mainImageFile.getId(), new String[] {});
		MainImageFileComparator.assertEquals(retrievedAfterUpdate, mainImageFile);
		assertFalse(retrievedMainImageFile.getHeight().equals(retrievedAfterUpdate.getHeight()));

		// DELETE
		long deletedObjects = this.mainImageFileClient.delete(mainImageFile.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.mainImageFileClient.get(mainImageFile.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("MainImageFile should not be found after deleting it");
	}

	public void crudMainImageFileFeed() throws UnknownHostException {
		List<MainImageFile> mainImageFiles = this.mainImageFileFactory.create(5);

		// CREATE
		List<MainImageFile> persistedMainImageFiles = this.mainImageFileClient.create(mainImageFiles, new String[] {}).getEntries();
		for (int i = 0; i < mainImageFiles.size(); i++) {
			mainImageFiles.get(i).setId(persistedMainImageFiles.get(i).getId());
			mainImageFiles.get(i).setMainImageType(new MainImageType());
			mainImageFiles.get(i).getMainImageType()
					.setEntityType(mainImageTypeClient.get(mainImageFiles.get(i).getMainImageTypeId(), new String[] {}).getEntityType());
		}

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] MainImageFileIds = (URI[]) CollectionUtils.collect(persistedMainImageFiles, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// auto generated id needs to set at input MainImageFile
		for (int i = 0; i < 5; i++) {
			mainImageFiles.get(i).setId(persistedMainImageFiles.get(i).getId());
		}

		// RETRIEVE
		Feed<MainImageFile> retrievedMainImageFiles = this.mainImageFileClient.get(MainImageFileIds, new String[] {});
		MainImageFileComparator.assertEquals(retrievedMainImageFiles, mainImageFiles);

		// DELETE
		long deletedMainImageFiles = this.mainImageFileClient.delete(MainImageFileIds);
		assertEquals(deletedMainImageFiles, mainImageFiles.size());

		long notFoundMainImageFiles = 0;
		for (MainImageFile MainImageFile : mainImageFiles) {
			try {
				this.mainImageFileClient.get(MainImageFile.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundMainImageFiles++;
			}
		}
		assertEquals(notFoundMainImageFiles, deletedMainImageFiles, "Still found MainImageFiles after deleting");
	}

}
