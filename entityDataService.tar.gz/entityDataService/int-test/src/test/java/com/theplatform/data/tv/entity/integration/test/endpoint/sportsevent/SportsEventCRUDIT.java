package com.theplatform.data.tv.entity.integration.test.endpoint.sportsevent;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.theplatform.data.api.objects.DataObjectField;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.fields.SportsEventField;
import com.theplatform.data.tv.entity.api.test.SportsEventComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */
@Test(groups = { "sportsEvent", "crud" })
public class SportsEventCRUDIT extends EntityTestBase {

	// Merlin: 1042
	@Test(groups = { TestGroup.gbTest })
	public void crudSportsEventEntry() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();

		// CREATE
		SportsEvent persistedSportsEvent = this.sportsEventClient.create(inputSportsEvent);
		assertEquals(persistedSportsEvent.getId(), inputSportsEvent.getId(), "SportsEvent ids should match after creation");

		// RETRIEVE
		SportsEvent retrievedSportsEvent = this.sportsEventClient.get(persistedSportsEvent.getId(), new String[] {});
		SportsEventComparator.assertEquals(retrievedSportsEvent, inputSportsEvent);

		// UPDATE
		inputSportsEvent.setDivision(inputSportsEvent.getDivision() + " - changed");
		this.sportsEventClient.update(inputSportsEvent);
		SportsEvent retrievedAfterUpdate = this.sportsEventClient.get(inputSportsEvent.getId(), new String[] {});
		SportsEventComparator.assertEquals(retrievedAfterUpdate, inputSportsEvent);

		// DELETE
		long deletedObjects = this.sportsEventClient.delete(inputSportsEvent.getId());
		assertEquals(1, deletedObjects);
		try {
			this.sportsEventClient.get(inputSportsEvent.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		fail("SportsEvent should not be found after deleting it");
	}

	@Test(groups = { TestGroup.gbTest })
	public void crudSportsEventWithProgramIds() throws UnknownHostException {
		SportsEvent inputSportsEvent = this.sportsEventFactory.create();
		// Sports event created witn null Program Ids
		SportsEvent persistedSportsEvent = this.sportsEventClient.create(inputSportsEvent);
		SportsEvent retrievedSportsEvent = this.sportsEventClient.get(persistedSportsEvent.getId(), new String[] {});
		SportsEventComparator.assertEquals(retrievedSportsEvent, inputSportsEvent);

		// create a program
		Program program = this.programClient.create(this.programFactory.create());

		// create a program Sports Event
		ProgramSportsEvent programSportsEvent = new ProgramSportsEvent();
		programSportsEvent.setId(URI.create(this.programSportsEventClient.getBaseUrl() + "data/ProgramSportsEvent/" + this.objectIdProvider.nextId()));
		programSportsEvent.setProgramId(program.getId());
		programSportsEvent.setSportsEventId(retrievedSportsEvent.getId());
		this.programSportsEventClient.create(programSportsEvent);

		// update the sports event so that the cache is cleared
		inputSportsEvent.setDivision(inputSportsEvent.getDivision() + " - changed");
		this.sportsEventClient.update(inputSportsEvent);
		retrievedSportsEvent = this.sportsEventClient.get(inputSportsEvent.getId(), new String[] {});
		// set the expected program ids
		List<URI> expectedProgramIds = new ArrayList<>();
		expectedProgramIds.add(programSportsEvent.getProgramId());
		inputSportsEvent.setProgramIds(expectedProgramIds);
		SportsEventComparator.assertEquals(retrievedSportsEvent, inputSportsEvent);

		// create another program
		Program anotherProgram = this.programClient.create(this.programFactory.create());

		// create another program Sports Event
		ProgramSportsEvent anotherProgramSportsEvent = new ProgramSportsEvent();
		anotherProgramSportsEvent.setId(URI.create(this.programSportsEventClient.getBaseUrl() + "data/ProgramSportsEvent/" + this.objectIdProvider.nextId()));
		anotherProgramSportsEvent.setProgramId(anotherProgram.getId());
		anotherProgramSportsEvent.setSportsEventId(retrievedSportsEvent.getId());
		this.programSportsEventClient.create(anotherProgramSportsEvent);

		// update the sports event so that the cache is cleared
		inputSportsEvent.setDivision(inputSportsEvent.getDivision() + " - changed again");
		this.sportsEventClient.update(inputSportsEvent);
		retrievedSportsEvent = this.sportsEventClient.get(inputSportsEvent.getId(), new String[] {});

		// set the expected program ids
		expectedProgramIds.add(anotherProgramSportsEvent.getProgramId());
		inputSportsEvent.setProgramIds(expectedProgramIds);
		SportsEventComparator.assertEquals(retrievedSportsEvent, inputSportsEvent);

	}

	// Merlin: 1042
	@Test(groups = { "other" })
	public void crudSportsEventFeed() throws UnknownHostException {
		List<SportsEvent> inputSportsEvents = this.sportsEventFactory.create(5);

		@SuppressWarnings({ "unchecked" })
		URI[] sportsEventIds = (URI[]) CollectionUtils.collect(inputSportsEvents, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<SportsEvent> persistedSportsEvents = this.sportsEventClient.create(inputSportsEvents);
		ComparatorUtils.assertIdsAreEqual(inputSportsEvents, persistedSportsEvents);

		// RETRIEVE
		Feed<SportsEvent> retrievedSportsEvents = this.sportsEventClient.get(sportsEventIds, new String[] {});
		SportsEventComparator.assertEquals(retrievedSportsEvents, inputSportsEvents);

		// UPDATE
		for (int i = 1; i < inputSportsEvents.size(); i++) {
			inputSportsEvents.get(i).setDivision(inputSportsEvents.get(i).getDivision() + " - changed " + i);
			inputSportsEvents.get(i).setImageIds(null);
		}
		this.sportsEventClient.update(inputSportsEvents);
		for (int i = 1; i < inputSportsEvents.size(); i++) {
			inputSportsEvents.get(i).setImageIds(new ArrayList<URI>());
		}
		Feed<SportsEvent> retrievedAfterUpdate = this.sportsEventClient.get(sportsEventIds, new String[] {});
		SportsEventComparator.assertEquals(retrievedAfterUpdate, inputSportsEvents);

		// DELETE
		long deletedSportsEvents = this.sportsEventClient.delete(sportsEventIds);
		assertEquals(inputSportsEvents.size(), deletedSportsEvents);
		long notFoundSportsEvents = 0;
		for (SportsEvent sportsEvent : inputSportsEvents) {
			try {
				this.sportsEventClient.get(sportsEvent.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundSportsEvents++;
			}
		}
		assertEquals(notFoundSportsEvents, deletedSportsEvents, "Still found SportsEvent after deleting");
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(DataObjectField.title, null),
            new DataServiceField(DataObjectField.title, null),
			new DataServiceField(SportsEventField.leagueId, null), new DataServiceField(SportsEventField.city, null),
			new DataServiceField(SportsEventField.state, null), new DataServiceField(SportsEventField.country, null),
			new DataServiceField(SportsEventField.sportType, null), new DataServiceField(SportsEventField.conference, null),
			new DataServiceField(SportsEventField.division, null), new DataServiceField(SportsEventField.venue, null),
			// If not set on create defaults to 'AudienceAvailable', or
			// 'Editorial' if
			// ID has editorial suffix
			new DataServiceField(SportsEventField.merlinResourceType, MerlinResourceType.AudienceAvailable), };

	@Test(groups = { TestGroup.gbTest })
	public void testSportsEventCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(sportsEventClient, sportsEventFactory.create(), SportsEventComparator.class,
				this.defaultValues, new DataServiceField[] { new DataServiceField(SportsEventField.programIds, new ArrayList<URI>()),
						new DataServiceField(SportsEventField.imageIds, new ArrayList<URI>()),
						new DataServiceField(SportsEventField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(SportsEventField.selectedImages, new ArrayList<MainImageInfo>()), });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSportsEventCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(sportsEventClient, sportsEventFactory.create(), SportsEventComparator.class,
				this.defaultValues, new DataServiceField[] { new DataServiceField(SportsEventField.programIds, new ArrayList<URI>()),
						new DataServiceField(SportsEventField.imageIds, new ArrayList<URI>()),
						new DataServiceField(SportsEventField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(SportsEventField.selectedImages, new ArrayList<MainImageInfo>()), });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSportsEventUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.title, "sportsEvent title"));
		createValues.add(new DataServiceField(SportsEventField.leagueId, sportsLeagueClient.create(sportsLeagueFactory.create()).getId()));
		createValues.add(new DataServiceField(SportsEventField.city, "sportsEvent city"));
		createValues.add(new DataServiceField(SportsEventField.state, "sportsEvent state"));
		createValues.add(new DataServiceField(SportsEventField.country, "sportsEvent country"));
		createValues.add(new DataServiceField(SportsEventField.sportType, "Volleyball"));
		createValues.add(new DataServiceField(SportsEventField.conference, "sportsEvent conference"));
		createValues.add(new DataServiceField(SportsEventField.division, "sportsEvent division"));
		createValues.add(new DataServiceField(SportsEventField.venue, "sportsEvent venue"));
		createValues.add(new DataServiceField(SportsEventField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(sportsEventClient, sportsEventFactory.create(), SportsEventComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(SportsEventField.programIds, new ArrayList<URI>()),
						new DataServiceField(SportsEventField.imageIds, new ArrayList<URI>()),
						new DataServiceField(SportsEventField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(SportsEventField.selectedImages, new ArrayList<MainImageInfo>()) });
	}

    @Test(groups = { TestGroup.gbTest })
    public void testSportsEventUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(SportsEventField.leagueId, sportsLeagueClient.create(sportsLeagueFactory.create()).getId()));
		createValues.add(new DataServiceField(SportsEventField.city, "sportsEvent city"));
		createValues.add(new DataServiceField(SportsEventField.state, "sportsEvent state"));
		createValues.add(new DataServiceField(SportsEventField.country, "sportsEvent country"));
		createValues.add(new DataServiceField(SportsEventField.sportType, "Volleyball"));
		createValues.add(new DataServiceField(SportsEventField.conference, "sportsEvent conference"));
		createValues.add(new DataServiceField(SportsEventField.division, "sportsEvent division"));
		createValues.add(new DataServiceField(SportsEventField.venue, "sportsEvent venue"));
		createValues.add(new DataServiceField(SportsEventField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(sportsEventClient, sportsEventFactory.create(), SportsEventComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(SportsEventField.programIds, new ArrayList<URI>()),
						new DataServiceField(SportsEventField.imageIds, new ArrayList<URI>()),
						new DataServiceField(SportsEventField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(SportsEventField.selectedImages, new ArrayList<MainImageInfo>()) });
	}

}
