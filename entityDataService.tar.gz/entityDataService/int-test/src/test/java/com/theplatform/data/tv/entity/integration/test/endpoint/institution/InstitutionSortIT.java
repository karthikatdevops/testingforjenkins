package com.theplatform.data.tv.entity.integration.test.endpoint.institution;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.test.InstitutionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * GreenBuild test for sorting of Institution
 * 
 * @author clai200
 * @since 4/7/2011
 * 
 */
public class InstitutionSortIT extends EntityTestBase {


	private static final int TEST_LIST_SIZE = 4;

	private List<Institution> institutions;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		institutions = this.institutionFactory.create(TEST_LIST_SIZE);
		this.institutionClient.create(institutions);

	}

	@Test(groups = { TestGroup.gbTest })
	public void testSortInstitutionByTitleAlphabetically() {
		institutions.get(3).setTitle("A");
		institutions.get(0).setTitle("B");
		institutions.get(1).setTitle("C");
		institutions.get(2).setTitle("D");

		this.institutionClient.update(institutions);

		// SORT EXPECTED
		List<Institution> expectedSortedInstitutions = new ArrayList<>(institutions.size());
		expectedSortedInstitutions.add(institutions.get(3));
		expectedSortedInstitutions.add(institutions.get(0));
		expectedSortedInstitutions.add(institutions.get(1));
		expectedSortedInstitutions.add(institutions.get(2));

		// RETRIVE WHITH SORTING
		String sortFiedld = "title";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortFiedld, sortDescending);
		Feed<Institution> retrievedInstitutions = this.institutionClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		InstitutionComparator.assertEquals(retrievedInstitutions, expectedSortedInstitutions);
	}
}
