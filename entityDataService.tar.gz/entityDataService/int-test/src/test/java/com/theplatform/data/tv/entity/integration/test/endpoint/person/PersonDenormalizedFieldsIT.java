package com.theplatform.data.tv.entity.integration.test.endpoint.person;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * This test (and others like it) is meant to validate that the Person client does not return denormalized
 * entities (from associated endpoints) that are marked (have their MRT set to something)
 * other than AudienceAvailable
 * <p/>
 * Author: Vincent Fumo (vfumo) : vincent_fumo@cable.comcast.com
 * Created Date: 3/13/14
 */
@Test(groups = {"person", "denormalizedFields", TestGroup.gbTest})
public class PersonDenormalizedFieldsIT extends EntityTestBase {

    public void gettingAPersonShouldNotReturnNonAACredits() {
        Person entity = personFactory.create();
        personClient.create(entity);
        URI entityId = entity.getId();

        Credit relatedEntity = creditFactory.create();
        relatedEntity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        relatedEntity.setPersonId(entityId);
        creditClient.create(relatedEntity);
        URI creditId = relatedEntity.getId();

        // 1) make sure that we get the relatedEntity (since it's AA)
        Person retrievedEntity = personClient.get(entityId, new String[]{PersonField.credits.name()});
        List<CreditAssociation> associations = retrievedEntity.getCredits();
        assertThat(associations.size(), is(1));

        CreditAssociation ca = associations.get(0);
        assertThat(ca.getCreditId(), is(creditId));

        // 2) change the relatedEntity to be non AA
        relatedEntity.setMerlinResourceType(MerlinResourceType.Inactive);
        creditClient.update(relatedEntity);

        // 3) validate that the relatedEntity doesn't return
        // note: we change the fields returned so we aren't dealing with a stale cache
        retrievedEntity = personClient.get(entityId, new String[]{PersonField.merlinResourceType.name(), PersonField.credits.name()});
        associations = retrievedEntity.getCredits();
        assertThat(associations.size(), is(0));
    }
}
