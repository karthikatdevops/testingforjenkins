package com.theplatform.data.tv.entity.integration.test.endpoint.tag;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.fields.TagField;
import com.theplatform.data.tv.entity.api.test.TagComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;


@Test(groups= {"tag", "crud"})
public class TagCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void crudSingleTag() throws UnknownHostException {
		Tag tag = this.tagFactory.create();

		// CREATE
		Tag persistedTag = this.tagClient.create(tag);
		assertEquals(persistedTag.getId(), tag.getId(), "Tag ids should match after creation");

		// RETRIEVE
		Tag retrievedTag = this.tagClient.get(tag.getId(), new String[] {});
		// Since tag.name should be populated from Tag.title, need to set in
		// expected value
		tag.setName(tag.getTitle());
		TagComparator.assertEquals(retrievedTag, tag);

		// UPDATE
		tag.setName(null);
		tag.setTitle(tag.getTitle() + " - changed");
		this.tagClient.update(tag);

		Tag retrievedAfterUpdate = this.tagClient.get(tag.getId(), new String[] {});
		// Since tag.name should be populated from Tag.title, need to set in
		// expected value
		tag.setName(tag.getTitle());
		TagComparator.assertEquals(retrievedAfterUpdate, tag);
		assertFalse(retrievedTag.getTitle().equals(retrievedAfterUpdate.getTitle()));

		// DELETE
		long deletedObjects = this.tagClient.delete(tag.getId());
		assertEquals(1, deletedObjects);

		try {
			this.tagClient.get(tag.getId(), new String[] {});
			fail("Tag should not be found after deleting it");
		} catch (ObjectNotFoundException e) {
			// ok
		}
	}

	@Test(groups = { "other" })
	public void crudTagFeed() throws UnknownHostException {
		List<Tag> tags = this.tagFactory.create(15);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] tagIds = (URI[]) CollectionUtils.collect(tags, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<Tag> persistedTags = this.tagClient.create(tags);
		ComparatorUtils.assertIdsAreEqual(tags, persistedTags);

		// RETRIEVE
		Feed<Tag> retrievedTags = this.tagClient.get(tagIds, new String[] {});
		for (Tag tag : tags) {
			// Since tag.name should be populated from Tag.title, need to set in
			// expected value
			tag.setName(tag.getTitle());
		}
		TagComparator.assertEquals(retrievedTags, tags);

		// DELETE
		long deletedTags = this.tagClient.delete(tagIds);
		assertEquals(tags.size(), deletedTags);

		long notFoundTags = 0;
		for (Tag tag : tags) {
			try {
				this.tagClient.get(tag.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundTags++;
			}
		}
		assertEquals(notFoundTags, deletedTags, "Still found tags after deleting");
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] {
	// If not set on create defaults to 'AudienceAvailable', or 'Editorial' if
	// ID has editorial suffix
	new DataServiceField(TagField.merlinResourceType, MerlinResourceType.AudienceAvailable), };

	@Test(groups = { TestGroup.gbTest })
	public void testTagCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		Tag tag = tagFactory.create();
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(tagClient, tag, TagComparator.class, this.defaultValues,
				new DataServiceField[] { new DataServiceField(TagField.name, tag.getTitle()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testTagCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		Tag tag = tagFactory.create();
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(tagClient, tag, TagComparator.class, this.defaultValues,
				new DataServiceField[] { new DataServiceField(TagField.name, tag.getTitle()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testTagUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		Tag tag = tagFactory.create();
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(TagField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(tagClient, tag, TagComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] { new DataServiceField(TagField.name, tag.getTitle()) });
	}

	@Test(groups = TestGroup.gbTest)
	public void testUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		Tag tag = tagFactory.create();
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(TagField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(tagClient, tag, TagComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] { new DataServiceField(TagField.name, tag.getTitle()) });
	}

}
