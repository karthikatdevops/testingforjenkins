package com.theplatform.data.tv.entity.integration.test.endpoint.entitycollection;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.LinkedList;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.fields.EntityCollectionField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.OverrideField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.test.EntityCollectionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author jethrolai
 * @since 01/23/2012
 */
@Test(groups={"entityCollection", "crud"})
public class EntityCollectionUpdateIT extends EntityTestBase {



	@Test(groups = { TestGroup.gbTest })
	public void testEntityCollectionAddProgram() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		List<Program> programs = this.programFactory.create(2);
		Feed<Program> persistedPrograms = programClient.create(programs, (String[]) null);
		List<URI> programIds = new LinkedList<URI>();

		for (Program program : persistedPrograms.getEntries()) {
			programIds.add(program.getId());
		}

		EntityCollection entityCollection = this.entityCollectionFactory.create(new DataServiceField(EntityCollectionField.entityIds, programIds),
                new DataServiceField(EntityCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		EntityCollection retrievedEntityCollection = this.entityCollectionClient.create(entityCollection, (String[]) null);
		entityCollection.setId(retrievedEntityCollection.getId());
		entityCollection.setOwnerId(retrievedEntityCollection.getOwnerId());
		
		EntityCollectionComparator.assertEquals(retrievedEntityCollection, entityCollection);

		retrievedEntityCollection.getEntityIds().add(this.programClient.create(this.programFactory.create()).getId());

		this.entityCollectionClient.update(retrievedEntityCollection);

		EntityCollectionComparator.assertEquals(this.entityCollectionClient.get(retrievedEntityCollection.getId(), null), retrievedEntityCollection);

	}

	@Test(groups = { TestGroup.gbTest, "SprintN" })
	public void testEntityCollectionRemoveOneProgram() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
	ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		List<Program> programs = this.programFactory.create(2);
		Feed<Program> persistedPrograms = programClient.create(programs, (String[]) null);
		List<URI> programIds = new LinkedList<URI>();
		
		for (Program program : persistedPrograms.getEntries()) {
			programIds.add(program.getId());
		}
		
		EntityCollection entityCollection = this.entityCollectionFactory.create(new DataServiceField(EntityCollectionField.entityIds, programIds),
                new DataServiceField(EntityCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		EntityCollection retrievedEntityCollection = this.entityCollectionClient.create(entityCollection, (String[]) null);
		entityCollection.setId(retrievedEntityCollection.getId());
		entityCollection.setOwnerId(retrievedEntityCollection.getOwnerId());
		EntityCollectionComparator.assertEquals(retrievedEntityCollection, entityCollection);
		
		retrievedEntityCollection.getEntityIds().remove(retrievedEntityCollection.getEntityIds().size()-1);
		
		this.entityCollectionClient.update(retrievedEntityCollection);
		
		EntityCollectionComparator.assertEquals(this.entityCollectionClient.get(retrievedEntityCollection.getId(), null), retrievedEntityCollection);
		
	}
}
