package com.theplatform.data.tv.entity.integration.test.endpoint.videogame;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Videogame;
import com.theplatform.data.tv.entity.api.test.VideogameComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 12/3/14
 */
@Test(groups = { "videogame", "sort", TestGroup.gbTest })
public class VideogameSortIT extends EntityTestBase {

	private static final int NUM_TO_CREATE = 4;
	private List<Videogame> entityList;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		entityList = videogameFactory.create(NUM_TO_CREATE);
		entityList.get(0).setId(URI.create(baseUrl + "/data/Videogame/" + objectIdProvider.nextId()));
		entityList.get(0).setTitle("2");
		entityList.get(1).setId(URI.create(baseUrl + "/data/Videogame/" + objectIdProvider.nextId()));
		entityList.get(1).setTitle("4");
		entityList.get(2).setId(URI.create(baseUrl + "/data/Videogame/" + objectIdProvider.nextId()));
		entityList.get(2).setTitle("3");
		entityList.get(3).setId(URI.create(baseUrl + "/data/Videogame/" + objectIdProvider.nextId()));
		entityList.get(3).setTitle("1");
		videogameClient.create(entityList, new String[] {});
	}

	@Test
	public void testSortAscendingRelatedProgramById() throws UnknownHostException {
		// SORT EXPECTED
		List<Videogame> expectedSortedEntities = new ArrayList<>(NUM_TO_CREATE);
		expectedSortedEntities.add(entityList.get(3));
		expectedSortedEntities.add(entityList.get(0));
		expectedSortedEntities.add(entityList.get(2));
		expectedSortedEntities.add(entityList.get(1));

		// RETRIEVE WITH SORTING
		Sort requestSort = new Sort("title", false);
		Feed<Videogame> retreivedEntities = videogameClient.getAll(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		VideogameComparator comparator = new VideogameComparator();
        comparator.assertEquals(retreivedEntities, expectedSortedEntities);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableField() throws UnknownHostException {
		// RETRIVE WHITH SORTING
		String sortField = "mediumSynopsis";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortField, sortDescending);
		videogameClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
	}
}
