package com.theplatform.data.tv.entity.integration.test.endpoint.entitymessage;

import com.theplatform.contrib.testing.comparator.DataObjectComparator;
import com.theplatform.contrib.testing.crud.CrudTestBase;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.contrib.testing.provider.GBTestIdProvider;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.NamespacedField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.EntityMessageClient;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.EntityMessage;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.fields.EntityMessageField;
import com.theplatform.data.tv.entity.api.fields.VideogameField;
import com.theplatform.data.tv.entity.api.test.EntityMessageComparator;
import com.theplatform.data.tv.entity.test.api.data.factory.EntityMessageFactory;
import com.theplatform.data.tv.entity.test.api.data.factory.ProgramFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/23/15
 */
@Test(groups = {"crud", "entitymessage", TestGroup.gbTest}, enabled = true)
public class EntityMessageCRUDIT extends CrudTestBase<EntityMessage> {

    @Resource
    protected EntityMessageClient entityMessageClient;

    @Resource
    protected EntityMessageFactory entityMessageFactory;

    @Resource
    protected EntityMessageComparator entityMessageComparator;

    @Resource
    protected GBTestIdProvider objectIdProvider;

    @Autowired
    protected ProgramClient programClient;

    @Autowired
    protected ProgramFactory programFactory;

    @Override
    protected ValueProvider<Long> getValueProvider() {
        return objectIdProvider;
    }

    @Override
    protected DataServiceClient<EntityMessage> getClient() {
        return entityMessageClient;
    }

    @Override
    protected DataObjectComparator<EntityMessage> getComparator() {
        return entityMessageComparator;
    }

    @Override
    protected DataObjectFactory<EntityMessage, EntityMessageClient> getDataObjectFactory() {
        return entityMessageFactory;
    }

    @Override
    protected Map<NamespacedField, Object> getUpdateValues(EntityMessage originalObject) {
        Map<NamespacedField, Object> updateValues = new HashMap<>();

        Program anotherProgram = programClient.create(programFactory.create());

        updateValues.put(DataObjectField.title, "new title");
        updateValues.put(EntityMessageField.entityId, anotherProgram.getId());
        updateValues.put(EntityMessageField.freeText, "new freeText");
        updateValues.put(EntityMessageField.type, "new type");
        updateValues.put(EntityMessageField.priority, 2);
        updateValues.put(EntityMessageField.merlinResourceType, MerlinResourceType.Temporary);

        return updateValues;
    }

    @Override
    protected void populateDependencies(EntityMessage rawObject) {
    }

    @Override
    protected Set<NamespacedField> getRequiredFields() {
        Set<NamespacedField> required = new HashSet<>();

        required.add(DataObjectField.title);
        required.add(EntityMessageField.entityId);
        required.add(EntityMessageField.freeText);
        required.add(EntityMessageField.type);

        return required;
    }

    @Override
    protected Set<NamespacedField> getNullableFields() {
        Set<NamespacedField> nullable = new HashSet<>();

        nullable.add(DataObjectField.description);
        nullable.add(EntityMessageField.priority);

        return nullable;
    }
}
