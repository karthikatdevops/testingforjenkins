package com.theplatform.data.tv.entity.integration.test.endpoint.entitycollection;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.OverrideField;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollectionType;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.fields.EntityCollectionField;
import com.theplatform.data.tv.entity.api.test.EntityCollectionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

/**
 * GreenBuild test for CRUD operations of EntityCollection
 * 
 * @author jethrolai
 * @since 9/1/2011
 * 
 */
@Test(groups = { "entityCollection", "crud" })
public class EntityCollectionCRUDIT extends EntityTestBase {

	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void crudSingleEntityCollection() throws UnknownHostException, IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		List<URI> entityIds = getPersistedEntityIds(3);

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("Primary", entityIds.get(0));

		EntityCollection entity = this.entityCollectionFactory.create(new DataServiceField(EntityCollectionField.entityIds, entityIds),
                new DataServiceField(EntityCollectionField.primaryEntities, primaryEntities),
                new DataServiceField(EntityCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable));

		// CREATE
		EntityCollection persistedEntity = this.entityCollectionClient.create(entity, (String[]) null);
		entity.setMerlinResourceType(persistedEntity.getMerlinResourceType());

		EntityCollectionComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		EntityCollection retrievedEntity = this.entityCollectionClient.get(entity.getId(), new String[] {});
		EntityCollectionComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setDescription(entity.getDescription().concat(" updated"));
		entity.setTitle(entity.getTitle().concat(" updated"));
		entity.setType(entity.getType().equals(EntityCollectionType.ADIPackage.getFriendlyName()) ? EntityCollectionType.MovieFranchise.getFriendlyName()
				: EntityCollectionType.ADIPackage.getFriendlyName());
		entity.setSubtype(entity.getSubtype() == null ? "subtype" : entity.getSubtype().concat(" updated"));
		entity.getPrimaryEntities().put("English", entityIds.get(1));

		this.entityCollectionClient.update(entity);

		EntityCollection retrievedAfterUpdate = this.entityCollectionClient.get(entity.getId(), new String[] {});
		EntityCollectionComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = this.entityCollectionClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.entityCollectionClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("EntityCollection should not be found after deleting it");
	}

	private List<URI> getPersistedEntityIds(int amount) {
		List<Program> programs = this.programFactory.create(amount);

		Feed<Program> persistedPrograms = this.programClient.create(programs);

		if (programs.get(0).getId() == null) {
			int counter = 0;
			for (Program program : persistedPrograms.getEntries())
				programs.get(counter++).setId(program.getId());
		}

		URI[] persistedProgramIds = (URI[]) CollectionUtils.collect(programs, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		return Arrays.asList(persistedProgramIds);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] {
			// If not set on create defaults to 'AudienceAvailable', or
			// 'Editorial' if ID has editorial suffix
			new DataServiceField(DataObjectField.description, null), new DataServiceField(EntityCollectionField.subtype, null),
			new DataServiceField(EntityCollectionField.entityIds, new ArrayList<URI>()),
			new DataServiceField(EntityCollectionField.primaryEntities, new HashMap<String, URI>()),
			new DataServiceField(EntityCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable), };

	@Test(groups = { TestGroup.gbTest })
	public void testEntityCollectionCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(entityCollectionClient, entityCollectionFactory.create(),
				EntityCollectionComparator.class, this.defaultValues, new DataServiceField[] {
						new DataServiceField(EntityCollectionField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(EntityCollectionField.selectedImages, new ArrayList<MainImageInfo>()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testEntityCollectionCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(entityCollectionClient, entityCollectionFactory.create(),
				EntityCollectionComparator.class, this.defaultValues, new DataServiceField[] {
						new DataServiceField(EntityCollectionField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(EntityCollectionField.selectedImages, new ArrayList<MainImageInfo>()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testEntityCollectionUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		List<DataServiceField> createValues = new ArrayList<DataServiceField>();
		createValues.add(new DataServiceField(DataObjectField.description, "entityCollection description"));
		createValues.add(new DataServiceField(EntityCollectionField.entityIds, new ArrayList<URI>()));
		createValues.add(new DataServiceField(EntityCollectionField.primaryEntities, new HashMap<String, URI>()));
		createValues.add(new DataServiceField(EntityCollectionField.subtype, "entityCollection subtype"));
		createValues.add(new DataServiceField(EntityCollectionField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(entityCollectionClient, entityCollectionFactory.create(),
				EntityCollectionComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(EntityCollectionField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(EntityCollectionField.selectedImages, new ArrayList<MainImageInfo>()) });
	}

	@Test(groups = TestGroup.gbTest)
	public void testEntityCollectionUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<DataServiceField>();
		createValues.add(new DataServiceField(DataObjectField.description, "entityCollection description"));
		createValues.add(new DataServiceField(EntityCollectionField.entityIds, new ArrayList<URI>()));
		createValues.add(new DataServiceField(EntityCollectionField.primaryEntities, new HashMap<String, URI>()));
		createValues.add(new DataServiceField(EntityCollectionField.subtype, "entityCollection subtype"));
		createValues.add(new DataServiceField(EntityCollectionField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(entityCollectionClient, entityCollectionFactory.create(),
				EntityCollectionComparator.class, defaultValues, createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
						new DataServiceField(EntityCollectionField.mainImages, new HashMap<String, MediaFile>()),
						new DataServiceField(EntityCollectionField.selectedImages, new ArrayList<MainImageInfo>()) });
	}

}
