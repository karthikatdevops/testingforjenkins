package com.theplatform.data.tv.entity.integration.test.endpoint.sportsleague;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.SportsLeague;
import com.theplatform.data.tv.entity.api.fields.SportsLeagueField;
import com.theplatform.data.tv.entity.api.test.SportsLeagueComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */

@Test(groups = { "sportsLeague", "crud" })
public class SportsLeagueCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void crudSportsLeagueEntry() throws UnknownHostException {
		SportsLeague inputSportsLeague = this.sportsLeagueFactory.create();

		// CREATE
		SportsLeague persistedSportsLeague = this.sportsLeagueClient.create(inputSportsLeague);
		assertEquals(persistedSportsLeague.getId(), inputSportsLeague.getId(), "SportsLeague ids should match after creation");

		// RETRIEVE
		SportsLeague retrievedSportsLeague = this.sportsLeagueClient.get(persistedSportsLeague.getId(), new String[] {});
		SportsLeagueComparator.assertEquals(retrievedSportsLeague, inputSportsLeague);

		// UPDATE
		inputSportsLeague.setTitle("some different title for update");
		inputSportsLeague.setDescription("some different description for update");
		this.sportsLeagueClient.update(inputSportsLeague);
		SportsLeague retrievedAfterUpdate = this.sportsLeagueClient.get(inputSportsLeague.getId(), new String[] {});
		SportsLeagueComparator.assertEquals(retrievedAfterUpdate, inputSportsLeague);

		// DELETE
		long deletedObjects = this.sportsLeagueClient.delete(inputSportsLeague.getId());
		assertEquals(deletedObjects, 1);
		try {
			this.sportsLeagueClient.get(inputSportsLeague.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		fail("SportsLeague should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudSportsLeagueFeed() throws UnknownHostException {
		List<SportsLeague> inputSportsLeagues = this.sportsLeagueFactory.create(5);

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] sportsLeagueIds = (URI[]) CollectionUtils.collect(inputSportsLeagues, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<SportsLeague> persistedSportsLeagues = this.sportsLeagueClient.create(inputSportsLeagues);
		ComparatorUtils.assertIdsAreEqual(inputSportsLeagues, persistedSportsLeagues);

		// RETRIEVE
		Feed<SportsLeague> retrievedSportsLeagues = this.sportsLeagueClient.get(sportsLeagueIds, new String[] {});
		SportsLeagueComparator.assertEquals(retrievedSportsLeagues, inputSportsLeagues);

		// UPDATE
		for (int i = 1; i < inputSportsLeagues.size(); i++) {
			inputSportsLeagues.get(i).setTitle("some different title for update " + 1);
			inputSportsLeagues.get(i).setDescription("some different description for update " + i);
		}
		this.sportsLeagueClient.update(inputSportsLeagues);
		Feed<SportsLeague> retrievedAfterUpdate = this.sportsLeagueClient.get(sportsLeagueIds, new String[] {});
		SportsLeagueComparator.assertEquals(retrievedAfterUpdate, inputSportsLeagues);

		// DELETE
		long deletedSportsLeagues = this.sportsLeagueClient.delete(sportsLeagueIds);
		assertEquals(deletedSportsLeagues, inputSportsLeagues.size());
		long notFoundSportsLeagues = 0;
		for (SportsLeague sportsLeague : inputSportsLeagues) {
			try {
				this.sportsLeagueClient.get(sportsLeague.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundSportsLeagues++;
			}
		}
		assertEquals(notFoundSportsLeagues, deletedSportsLeagues, "Still found SportsLeague after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSportsLeagueDefaultFieldValues() {
		SportsLeague expected = sportsLeagueFactory.create();
		expected.setTitle(null);
		expected.setDescription(null);
		expected.setMerlinResourceType(null);

		SportsLeague actual = sportsLeagueClient.create(expected, new String[] {});
		expected.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		SportsLeagueComparator.assertEquals(actual, expected);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(DataObjectField.title, null),
			new DataServiceField(DataObjectField.description, null),
			// If not set on create defaults to 'AudienceAvailable', or
			// 'Editorial' if
			// ID has editorial suffix
			new DataServiceField(SportsLeagueField.merlinResourceType, MerlinResourceType.AudienceAvailable), };

	@Test(groups = { TestGroup.gbTest })
	public void testSportsLeagueCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(sportsLeagueClient, sportsLeagueFactory.create(), SportsLeagueComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSportsLeagueCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(sportsLeagueClient, sportsLeagueFactory.create(), SportsLeagueComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSportsLeagueUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.title, "sportsLeague title"));
		createValues.add(new DataServiceField(DataObjectField.description, "sportsLeague description"));
		createValues.add(new DataServiceField(SportsLeagueField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(sportsLeagueClient, sportsLeagueFactory.create(), SportsLeagueComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

    @Test(groups = { TestGroup.gbTest })
	public void testSportsLeagueUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "sportsLeague description"));
		createValues.add(new DataServiceField(SportsLeagueField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(sportsLeagueClient, sportsLeagueFactory.create(), SportsLeagueComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

}
