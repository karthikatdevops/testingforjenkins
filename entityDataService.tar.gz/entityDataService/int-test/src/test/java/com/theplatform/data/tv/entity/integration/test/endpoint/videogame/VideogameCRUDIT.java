package com.theplatform.data.tv.entity.integration.test.endpoint.videogame;

import com.google.common.collect.Lists;
import com.theplatform.contrib.data.api.objects.EsrbRating;
import com.theplatform.contrib.testing.comparator.DataObjectComparator;
import com.theplatform.contrib.testing.crud.CrudTestBase;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.contrib.testing.provider.GBTestIdProvider;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.NamespacedField;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.VideogameClient;
import com.theplatform.data.tv.entity.api.data.objects.Videogame;
import com.theplatform.data.tv.entity.api.fields.VideogameField;
import com.theplatform.data.tv.entity.api.test.VideogameComparator;
import com.theplatform.data.tv.entity.test.api.data.factory.VideogameFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 12/3/14
 */
@Test(groups = {"crud", "videogame", TestGroup.gbTest}, enabled = true)
public class VideogameCRUDIT extends CrudTestBase<Videogame> {

    @Autowired
    @Qualifier("baseEntityUrl")
    private String baseEntityUrl;

    @Resource
    protected VideogameClient videogameClient;

    @Resource
    protected VideogameFactory videogameFactory;

    @Resource
    protected VideogameComparator videogameComparator;

    @Resource
    protected GBTestIdProvider objectIdProvider;

    @Override
    protected ValueProvider<Long> getValueProvider() { return objectIdProvider; }

    @Override
    protected DataServiceClient<Videogame> getClient() {
        return videogameClient;
    }

    @Override
    protected DataObjectComparator<Videogame> getComparator() {
        return videogameComparator;
    }

    @Override
    protected DataObjectFactory<Videogame, VideogameClient> getDataObjectFactory() {
        return videogameFactory;
    }

    @Override
    protected Map<NamespacedField, Object> getUpdateValues(Videogame originalObject) {
        Map<NamespacedField, Object> updateValues = new HashMap<>();


        updateValues.put(DataObjectField.title, "newTitle");

        updateValues.put(VideogameField.shortTitle, "new-shortTitle");
        updateValues.put(VideogameField.mediumTitle, "new-mediumTitle");
        updateValues.put(VideogameField.longTitle, "new-longTitle");
        updateValues.put(VideogameField.shortTitle, "new-shortTitle");
        updateValues.put(VideogameField.shortSynopsis, "new-shortSynopsis");
        updateValues.put(VideogameField.mediumSynopsis, "new-mediumSynopsis");
        updateValues.put(VideogameField.longSynopsis, "new-longSynopsis");
        updateValues.put(VideogameField.nativeId, "new-nativeId");
        updateValues.put(VideogameField.releaseDate, new DateOnly(1999, 1, 1));
        updateValues.put(VideogameField.attributionString, "new-attributionString");
        updateValues.put(VideogameField.singlePlayer, false);
        updateValues.put(VideogameField.minPlayers, 3);
        updateValues.put(VideogameField.maxPlayers, 5);
        updateValues.put(VideogameField.languages, Lists.newArrayList("spa"));
        EsrbRating esrbRating = new EsrbRating();
        esrbRating.setRating("Teen");
        updateValues.put(VideogameField.contentRatings, Lists.newArrayList(esrbRating));
        updateValues.put(VideogameField.tagIds, Lists.newArrayList(URI.create("http://new/uri")));
        updateValues.put(VideogameField.selectedImages, new ArrayList<>());

        MerlinResourceType oMerlinResourceType = originalObject.getMerlinResourceType();
        if (oMerlinResourceType != null && oMerlinResourceType != MerlinResourceType.Temporary) {
            updateValues.put(VideogameField.merlinResourceType, MerlinResourceType.Temporary);
        } else {
            updateValues.put(VideogameField.merlinResourceType, MerlinResourceType.AudienceAvailable);
        }

        return updateValues;
    }

    @Override
    protected void populateDependencies(Videogame rawObject) {
    }

    @Override
    protected Set<NamespacedField> getRequiredFields() {
        Set<NamespacedField> required = new HashSet<>();

        required.add(VideogameField.type);
        required.add(VideogameField.nativeId);

        return required;
    }

    @Override
    protected Set<NamespacedField> getNullableFields() {
        Set<NamespacedField> nullable = new HashSet<>();

        nullable.add(DataObjectField.title);
        nullable.add(VideogameField.shortTitle);
        nullable.add(VideogameField.mediumTitle);
        nullable.add(VideogameField.longTitle);
        nullable.add(VideogameField.shortSynopsis);
        nullable.add(VideogameField.mediumSynopsis);
        nullable.add(VideogameField.longSynopsis);
        nullable.add(VideogameField.languages);
        nullable.add(VideogameField.contentRatings);
        nullable.add(VideogameField.releaseDate);
        nullable.add(VideogameField.attributionString);
        nullable.add(VideogameField.singlePlayer);
        nullable.add(VideogameField.multiPlayer);
        nullable.add(VideogameField.minPlayers);
        nullable.add(VideogameField.maxPlayers);
        nullable.add(VideogameField.selectedImages);

        return nullable;
    }

}
