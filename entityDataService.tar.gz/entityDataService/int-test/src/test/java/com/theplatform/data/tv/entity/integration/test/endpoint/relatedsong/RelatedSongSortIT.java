package com.theplatform.data.tv.entity.integration.test.endpoint.relatedsong;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.RelatedSong;
import com.theplatform.data.tv.entity.api.data.objects.RelatedSongType;
import com.theplatform.data.tv.entity.api.fields.RelatedSongField;
import com.theplatform.data.tv.entity.api.test.RelatedSongComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "relatedSong", "sort" })
public class RelatedSongSortIT extends EntityTestBase {

	public void testRelatedSongSortById() {

		List<RelatedSong> relatedSongs = this.relatedSongFactory.create(4);

		Long id1 = this.objectIdProvider.nextId(), id2 = this.objectIdProvider.nextId(), id3 = this.objectIdProvider.nextId(), id4 = this.objectIdProvider
				.nextId();

		Assert.assertTrue(id1 < id2);
		Assert.assertTrue(id2 < id3);
		Assert.assertTrue(id3 < id4);

		relatedSongs.get(3).setId(URI.create(this.getBaseUrl().concat("/data/RelatedSong/" + id1)));
		relatedSongs.get(0).setId(URI.create(this.getBaseUrl().concat("/data/RelatedSong/" + id2)));
		relatedSongs.get(1).setId(URI.create(this.getBaseUrl().concat("/data/RelatedSong/" + id3)));
		relatedSongs.get(2).setId(URI.create(this.getBaseUrl().concat("/data/RelatedSong/" + id4)));

		relatedSongs.set(3, this.relatedSongClient.create(relatedSongs.get(3), new String[] {}));
		relatedSongs.set(0, this.relatedSongClient.create(relatedSongs.get(0), new String[] {}));
		relatedSongs.set(1, this.relatedSongClient.create(relatedSongs.get(1), new String[] {}));
		relatedSongs.set(2, this.relatedSongClient.create(relatedSongs.get(2), new String[] {}));

		List<RelatedSong> expected = new ArrayList<>(relatedSongs.size());
		expected.add(relatedSongs.get(3));
		expected.add(relatedSongs.get(0));
		expected.add(relatedSongs.get(1));
		expected.add(relatedSongs.get(2));

		Sort requestSort = new Sort(DataObjectField.id.getLocalName(), false);
		Feed<RelatedSong> actual = this.relatedSongClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);

		RelatedSongComparator.assertEquals(actual, expected);
	}

	public void testRelatedSongSortBySourceSongId() {
		final URI songId1 = this.songClient.create(this.songFactory.create()).getId();
		final URI songId2 = this.songClient.create(this.songFactory.create()).getId();
		final URI songId3 = this.songClient.create(this.songFactory.create()).getId();
		final URI songId4 = this.songClient.create(this.songFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(songId1) < URIUtils.getIdValue(songId2));
		Assert.assertTrue(URIUtils.getIdValue(songId2) < URIUtils.getIdValue(songId3));
		Assert.assertTrue(URIUtils.getIdValue(songId3) < URIUtils.getIdValue(songId4));

		List<RelatedSong> relatedSongs = this.relatedSongFactory.create(4);
		relatedSongs.get(0).setSourceSongId(songId1);
		relatedSongs.get(3).setSourceSongId(songId2);
		relatedSongs.get(1).setSourceSongId(songId3);
		relatedSongs.get(2).setSourceSongId(songId4);

		this.relatedSongClient.create(relatedSongs);

		List<RelatedSong> expected = new ArrayList<>(relatedSongs.size());
		expected.add(relatedSongs.get(0));
		expected.add(relatedSongs.get(3));
		expected.add(relatedSongs.get(1));
		expected.add(relatedSongs.get(2));

		Feed<RelatedSong> actual = this.relatedSongClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(RelatedSongField.sourceSongId.getLocalName(), false) }, null, false);

		RelatedSongComparator.assertEquals(actual, expected);
	}

	public void testRelatedSongSortByTargetSongId() {
		final URI songId1 = this.songClient.create(this.songFactory.create()).getId();
		final URI songId2 = this.songClient.create(this.songFactory.create()).getId();
		final URI songId3 = this.songClient.create(this.songFactory.create()).getId();
		final URI songId4 = this.songClient.create(this.songFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(songId1) < URIUtils.getIdValue(songId2));
		Assert.assertTrue(URIUtils.getIdValue(songId2) < URIUtils.getIdValue(songId3));
		Assert.assertTrue(URIUtils.getIdValue(songId3) < URIUtils.getIdValue(songId4));

		List<RelatedSong> relatedSongs = this.relatedSongFactory.create(4);
		relatedSongs.get(0).setTargetSongId(songId1);
		relatedSongs.get(3).setTargetSongId(songId2);
		relatedSongs.get(1).setTargetSongId(songId3);
		relatedSongs.get(2).setTargetSongId(songId4);

		this.relatedSongClient.create(relatedSongs);

		List<RelatedSong> expected = new ArrayList<>(relatedSongs.size());
		expected.add(relatedSongs.get(0));
		expected.add(relatedSongs.get(3));
		expected.add(relatedSongs.get(1));
		expected.add(relatedSongs.get(2));

		Feed<RelatedSong> actual = this.relatedSongClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(RelatedSongField.targetSongId.getLocalName(), false) }, null, false);

		RelatedSongComparator.assertEquals(actual, expected);
	}

	public void testRelatedSongSortByType() {
		List<RelatedSong> relatedSongs = this.relatedSongFactory.create(1);
		relatedSongs.get(0).setType(RelatedSongType.IsSimilar.getFriendlyName());

		this.relatedSongClient.create(relatedSongs);

		List<RelatedSong> expected = new ArrayList<>(relatedSongs.size());
		expected.add(relatedSongs.get(0));

		Feed<RelatedSong> retrievedPrograms = this.relatedSongClient.getOwned(new String[] {}, new Query[] {},
				new Sort[] { new Sort(RelatedSongField.type.getLocalName(), false) }, null, false);

		RelatedSongComparator.assertEquals(retrievedPrograms, expected);
	}

}
