package com.theplatform.data.tv.entity.integration.test;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.theplatform.authentication.token.api.exception.AuthenticationException;
import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;

@Test(groups = { "auth",TestGroup.gbTest })
public class AuthProxyTestIT extends EntityTestBase {

	private String accountId;
	private URI programId;

	private ProgramClient firstProgramClient;

	private ProgramClient noAuthProgramClient;

	private Set<URI> programIds;

	@BeforeClass(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		noAuthProgramClient = new ProgramClient(this.getBaseUrl(), new NoAuthHeader());
		programIds = new HashSet<>();
	}

	public void testClientInjection() throws AuthenticationException {
		Assert.assertNull(this.accountId);
		Assert.assertNotNull(this.programClient);
		Assert.assertNotNull(this.programClient.getAuthorization().getAccountIds());
		Assert.assertNotNull(this.programClient.getAuthorization().getAccountIds()[0]);
		accountId = this.programClient.getAuthorization().getAccountIds()[0];

	}

	@Test(dependsOnMethods="testClientInjection")
	public void testResetClients() throws AuthenticationException {
		Assert.assertNotNull(this.accountId);
		Assert.assertNotNull(this.programClient);
		Assert.assertNotNull(this.programClient.getAuthorization().getAccountIds());
		Assert.assertNotNull(this.programClient.getAuthorization().getAccountIds()[0]);
		Assert.assertNotEquals(programClient.getAuthorization().getAccountIds()[0], accountId);

	}

	public void testCreateProgramFirst() throws AuthenticationException {
		Program program = this.programFactory.create();
		Assert.assertFalse(programIds.contains(program.getId()), "programFactory created a Program with an id which is already used before.");
		programIds.add(programId);
		Assert.assertNull(program.getOwnerId());
		try {
			this.noAuthProgramClient.get(program.getId(), new String[] {});
			Assert.fail("Program id: " + program.getId() + " has been used. ");
		} catch (ObjectNotFoundException e) {
			// Id is not used by any Program instance
		}

		Assert.assertEquals(this.programClient.getAuthorization().getAccountIds().length, 1);
		Assert.assertNotNull(this.programClient.getAuthorization().getAccountIds()[0]);
		firstProgramClient = this.programClient;

		Program programCreated = null;
		try {
			programCreated = this.programClient.create(program, new String[] {});
		} catch (ObjectNotFoundException e) {
			try {
				this.noAuthProgramClient.get(program.getId(), new String[] {});
				Assert.fail("Got an ObjectNotFoundException during creation of Program:" + program.getId()
						+ ". but this program didn't exist until this creation.");
			} catch (ObjectNotFoundException ie) {
				Assert.fail("Got an ObjectNotFoundException during creation of Program:" + program.getId()
						+ ". and this program still doesn't exist after this creation.");
			}
		}
		Assert.assertEquals(programCreated.getOwnerId().toString(), this.programClient.getAuthorization().getAccountIds()[0]);
		Assert.assertEquals(programCreated.getId(), program.getId());
		programId = programCreated.getId();
	}

	@Test(dependsOnMethods = "testCreateProgramFirst")
	public void testCreateProgramSecond() throws AuthenticationException {
		Assert.assertNotEquals(firstProgramClient.getAuthorization().getAccountIds()[0], this.programClient.getAuthorization().getAccountIds()[0]);
		Program program = this.programFactory.create();
		Assert.assertFalse(programIds.contains(program.getId()), "programFactory created a Program with an id which is already used before.");
		programIds.add(programId);
		Assert.assertNull(program.getOwnerId());
		Assert.assertNotEquals(this.programClient.getAuthorization().getAccountIds()[0].toString(), firstProgramClient.getAuthorization().getAccountIds()[0]);
		try {
			this.noAuthProgramClient.get(program.getId(), new String[] {});
			Assert.fail("Program id: " + program.getId() + " has been used. ");
		} catch (ObjectNotFoundException e) {
			// Id is not used by any Program instance
		}

		Program existingProgram = firstProgramClient.get(programId, new String[] {});
		Assert.assertEquals(existingProgram.getId(), programId);
		Assert.assertNotEquals(program.getId(), existingProgram.getId());
		Program programCreated = null;
		try {
			programCreated = this.programClient.create(program, new String[] {});
		} catch (ObjectNotFoundException e) {
			try {
				this.noAuthProgramClient.get(program.getId(), new String[] {});
				Assert.fail("Got an ObjectNotFoundException during creation of Program:" + program.getId()
						+ ". but this program didn't exist until this creation.");
			} catch (ObjectNotFoundException ie) {
				Assert.fail("Got an ObjectNotFoundException during creation of Program:" + program.getId()
						+ ". and this program still doesn't exist after this creation.");
			}
		}
		Assert.assertEquals(programCreated.getOwnerId().toString(), this.programClient.getAuthorization().getAccountIds()[0].toString());
		Assert.assertNotEquals(URIUtils.getIdValue(programCreated.getOwnerId()).toString(), firstProgramClient.getAuthorization().getAccountIds()[0]);

	}

}
