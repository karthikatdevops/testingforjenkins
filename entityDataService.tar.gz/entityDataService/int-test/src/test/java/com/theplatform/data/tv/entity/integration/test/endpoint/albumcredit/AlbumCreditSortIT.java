package com.theplatform.data.tv.entity.integration.test.endpoint.albumcredit;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.AlbumCredit;
import com.theplatform.data.tv.entity.api.test.AlbumCreditComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "albumCredit", "sort"})
public class AlbumCreditSortIT extends EntityTestBase {

	public void testAlbumCreditSortByGuid() {
		List<AlbumCredit> albumCredits = albumCreditFactory.create(4);
		albumCredits.get(0).setGuid("1");
		albumCredits.get(3).setGuid("2");
		albumCredits.get(1).setGuid("3");
		albumCredits.get(2).setGuid("4");

		this.albumCreditClient.create(albumCredits);

		List<AlbumCredit> expectedSortedAlbumCredits = new ArrayList<>(albumCredits.size());
		expectedSortedAlbumCredits.add(albumCredits.get(0));
		expectedSortedAlbumCredits.add(albumCredits.get(3));
		expectedSortedAlbumCredits.add(albumCredits.get(1));
		expectedSortedAlbumCredits.add(albumCredits.get(2));

		Feed<AlbumCredit> retrievedAlbumCredits = this.albumCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("guid", false) },
				null, false);

		AlbumCreditComparator.assertEquals(retrievedAlbumCredits, expectedSortedAlbumCredits);
	}

	public void testAlbumCreditSortByType() {
		List<AlbumCredit> albumCredits = albumCreditFactory.create(2);
		albumCredits.get(0).setType("Primary Artist");
		albumCredits.get(1).setType("Guest Artist");

		this.albumCreditClient.create(albumCredits);

		List<AlbumCredit> expectedSortedAlbumCredits = new ArrayList<>(albumCredits.size());
		expectedSortedAlbumCredits.add(albumCredits.get(1));
		expectedSortedAlbumCredits.add(albumCredits.get(0));

		Feed<AlbumCredit> retrievedAlbumCredits = this.albumCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("type", false) },
				null, false);

		AlbumCreditComparator.assertEquals(retrievedAlbumCredits, expectedSortedAlbumCredits);
	}

	public void testAlbumCreditSortByRank() {
		List<AlbumCredit> albumCredits = albumCreditFactory.create(4);
		albumCredits.get(0).setRank(1);
		albumCredits.get(3).setRank(2);
		albumCredits.get(1).setRank(3);
		albumCredits.get(2).setRank(4);

		this.albumCreditClient.create(albumCredits);

		List<AlbumCredit> expectedSortedAlbumCredits = new ArrayList<>(albumCredits.size());
		expectedSortedAlbumCredits.add(albumCredits.get(0));
		expectedSortedAlbumCredits.add(albumCredits.get(3));
		expectedSortedAlbumCredits.add(albumCredits.get(1));
		expectedSortedAlbumCredits.add(albumCredits.get(2));

		Feed<AlbumCredit> retrievedAlbumCredits = this.albumCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("rank", false) },
				null, false);

		AlbumCreditComparator.assertEquals(retrievedAlbumCredits, expectedSortedAlbumCredits);
	}

	public void testAlbumCreditSortByPersonId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI personId1 = this.personClient.create(personFactory.create()).getId();
		URI personId2 = this.personClient.create(personFactory.create()).getId();
		URI personId3 = this.personClient.create(personFactory.create()).getId();
		URI personId4 = this.personClient.create(personFactory.create()).getId();

		Assert.assertTrue(URIUtils.getIdValue(personId1) < URIUtils.getIdValue(personId2));
		Assert.assertTrue(URIUtils.getIdValue(personId2) < URIUtils.getIdValue(personId3));
		Assert.assertTrue(URIUtils.getIdValue(personId3) < URIUtils.getIdValue(personId4));

		List<AlbumCredit> albumCredits = albumCreditFactory.create(4);
		albumCredits.get(0).setPersonId(personId1);
		albumCredits.get(3).setPersonId(personId2);
		albumCredits.get(1).setPersonId(personId3);
		albumCredits.get(2).setPersonId(personId4);

		this.albumCreditClient.create(albumCredits);

		List<AlbumCredit> expectedSortedAlbumCredits = new ArrayList<>(albumCredits.size());
		expectedSortedAlbumCredits.add(albumCredits.get(0));
		expectedSortedAlbumCredits.add(albumCredits.get(3));
		expectedSortedAlbumCredits.add(albumCredits.get(1));
		expectedSortedAlbumCredits.add(albumCredits.get(2));

		Feed<AlbumCredit> retrievedAlbumCredits = this.albumCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("personId", false) },
				null, false);

		AlbumCreditComparator.assertEquals(retrievedAlbumCredits, expectedSortedAlbumCredits);
	}

	public void testAlbumCreditSortByAlbumId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI albumId1 = this.albumClient.create(albumFactory.create()).getId();
		URI albumId2 = this.albumClient.create(albumFactory.create()).getId();
		URI albumId3 = this.albumClient.create(albumFactory.create()).getId();
		URI albumId4 = this.albumClient.create(albumFactory.create()).getId();
		
		Assert.assertTrue(URIUtils.getIdValue(albumId1) < URIUtils.getIdValue(albumId2));
		Assert.assertTrue(URIUtils.getIdValue(albumId2) < URIUtils.getIdValue(albumId3));
		Assert.assertTrue(URIUtils.getIdValue(albumId3) < URIUtils.getIdValue(albumId4));


		List<AlbumCredit> albumCredits = albumCreditFactory.create(4);
		albumCredits.get(0).setAlbumId(albumId1);
		albumCredits.get(3).setAlbumId(albumId2);
		albumCredits.get(1).setAlbumId(albumId3);
		albumCredits.get(2).setAlbumId(albumId4);

		this.albumCreditClient.create(albumCredits);

		List<AlbumCredit> expectedSortedAlbumCredits = new ArrayList<>(albumCredits.size());
		expectedSortedAlbumCredits.add(albumCredits.get(0));
		expectedSortedAlbumCredits.add(albumCredits.get(3));
		expectedSortedAlbumCredits.add(albumCredits.get(1));
		expectedSortedAlbumCredits.add(albumCredits.get(2));

		Feed<AlbumCredit> retrievedAlbumCredits = this.albumCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("albumId", false) },
				null, false);

		AlbumCreditComparator.assertEquals(retrievedAlbumCredits, expectedSortedAlbumCredits);
	}

	public void testAlbumCreditSortByActive() {
		List<AlbumCredit> albumCredits = albumCreditFactory.create(2);
		albumCredits.get(0).setActive(true);
		albumCredits.get(1).setActive(false);

		this.albumCreditClient.create(albumCredits);

		List<AlbumCredit> expectedSortedAlbumCredits = new ArrayList<>(albumCredits.size());
		expectedSortedAlbumCredits.add(albumCredits.get(1));
		expectedSortedAlbumCredits.add(albumCredits.get(0));

		Feed<AlbumCredit> retrievedAlbumCredits = this.albumCreditClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("active", false) },
				null, false);

		AlbumCreditComparator.assertEquals(retrievedAlbumCredits, expectedSortedAlbumCredits);
	}

}
