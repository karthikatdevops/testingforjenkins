package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { "program", "validation" })
public class ProgramValidationSportsSubtitleIT extends EntityTestBase {

	private final ProgramType[] validProgramTypes = new ProgramType[] { ProgramType.SportingEvent, ProgramType.Episode, ProgramType.Other,
			ProgramType.SeriesMaster };

	@DataProvider
	public Object[][] validProgramTypeProvider() {
		List<Object[]> argumentList = new ArrayList<>();
		for (ProgramType programType : validProgramTypes) {
			argumentList.add(new Object[] { programType });
		}

		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	@DataProvider
	public Object[][] invalidProgramTypeProvider() {
		List<Object[]> argumentList = new ArrayList<>();
		for (ProgramType programType : ProgramType.values()) {
			if (containsProgramType(programType, validProgramTypes))
				continue;
			argumentList.add(new Object[] { programType });
		}

		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	private boolean containsProgramType(ProgramType programType, ProgramType[] programTypeArray) {
		List<ProgramType> programTypeList = Arrays.asList(programTypeArray);

		return programTypeList.contains(programType);
	}

	@Test(enabled = true, groups = { TestGroup.gbTest }, dataProvider = "validProgramTypeProvider")
	public void testSettingSportsSubtitleForValidProgramTypes(ProgramType programType) {

		Program program = this.programFactory.create(new DataServiceField(ProgramField.type, programType),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		program.setType(programType);

		program.setSportsSubtitle(programType.toString() + program.getSportsSubtitle());
		URI programId = this.programClient.create(program).getId();

		Program retrievedProgram = this.programClient.get(programId, null);

		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(enabled = true, groups = { TestGroup.gbTest }, dataProvider = "invalidProgramTypeProvider", expectedExceptions = ValidationException.class)
	public void testSettingSportsSubtitleForInvalidProgramTypes(ProgramType programType) throws ValidationException {

		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,programType),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		program.setType(programType);

		program.setSportsSubtitle(programType.toString() + program.getSportsSubtitle());
		URI programId = this.programClient.create(program).getId();

		Program retrievedProgram = this.programClient.get(programId, null);

		// an exception should have been thrown at this point
	}

}
