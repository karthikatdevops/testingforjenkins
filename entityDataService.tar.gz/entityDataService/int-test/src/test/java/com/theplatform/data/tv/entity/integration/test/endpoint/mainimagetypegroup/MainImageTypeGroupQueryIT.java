package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagetypegroup;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.StringUtil;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageTypeGroup;
import com.theplatform.data.tv.image.api.test.MainImageTypeGroupComparator;


@Test(groups = { TestGroup.gbTest, "mainImageTypeGroup", "query" })
public class MainImageTypeGroupQueryIT extends EntityTestBase {


	public void testMainImageTypeGroupQueryByTitleNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		MainImageTypeGroup entity = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(new DataServiceField(DataObjectField.title, "title".concat(""+new Random().nextInt()))),
				new String[] {});
		Query[] queries = new Query[] { new ByTitle(entity.getTitle().concat(StringUtil.generateRandomString(2))) };
		Feed<MainImageTypeGroup> results = this.mainImageTypeGroupClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageTypeGroup should be found");
	}
	public void testMainImageTypeGroupQueryByTitleListNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		MainImageTypeGroup entity = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(new DataServiceField(DataObjectField.title, "title".concat(""+new Random().nextInt()))),
				new String[] {});
		Query[] queries = new Query[] { new ByTitle(Arrays.asList(entity.getTitle().concat(StringUtil.generateRandomString(2)))) };
		Feed<MainImageTypeGroup> results = this.mainImageTypeGroupClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No MainImageTypeGroup should be found");
	}
	public void testMainImageTypeGroupQueryByTitleOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String title1 = "title 1".concat(StringUtil.generateRandomString());
		final String title2 = "title 2".concat(StringUtil.generateRandomString());

		this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(new DataServiceField(DataObjectField.title, title1)));

		MainImageTypeGroup expectedMainImageTypeGroup = this.mainImageTypeGroupClient.create(
				this.mainImageTypeGroupFactory.create(new DataServiceField(DataObjectField.title, title2)), new String[] {});
		Query[] queries = new Query[] { new ByTitle(title2) };
		Feed<MainImageTypeGroup> results = this.mainImageTypeGroupClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageTypeGroup should be found");

		MainImageTypeGroupComparator.assertEquals(results.getEntries().get(0), expectedMainImageTypeGroup);
	}

	public void testMainImageTypeGroupQueryByTitleListOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String title1 = "title 1".concat(StringUtil.generateRandomString());
		final String title2 = "title 2".concat(StringUtil.generateRandomString());

		this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(new DataServiceField(DataObjectField.title, title1)));

		MainImageTypeGroup expectedMainImageTypeGroup = this.mainImageTypeGroupClient.create(
				this.mainImageTypeGroupFactory.create(new DataServiceField(DataObjectField.title, title2)), new String[] {});
		Query[] queries = new Query[] { new ByTitle(Arrays.asList(title2, "dummy title".concat(StringUtil.generateRandomString()))) };
		Feed<MainImageTypeGroup> results = this.mainImageTypeGroupClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one MainImageTypeGroup should be found");

		MainImageTypeGroupComparator.assertEquals(results.getEntries().get(0), expectedMainImageTypeGroup);
	}

	// byTitle with single value can't find multiple result because title must
	// be unique for all MainImageTypeGroup

	public void testMainImageTypeGroupQueryByTitleListMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String title1 = "title 1".concat(StringUtil.generateRandomString());
		final String title2 = "title 2".concat(StringUtil.generateRandomString());

		MainImageTypeGroup mainImageTypeGroup1=	this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create( new DataServiceField(DataObjectField.title, title1)), new String[]{});
		MainImageTypeGroup mainImageTypeGroup2 = this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create( new DataServiceField(DataObjectField.title, title2)), new String[]{});
		this.mainImageTypeGroupClient.create(this.mainImageTypeGroupFactory.create(new DataServiceField(DataObjectField.title, "dummy title".concat(StringUtil.generateRandomString()))));

		Query[] queries = new Query[] { new ByTitle(Arrays.asList(title1, title2)) };
		Feed<MainImageTypeGroup> results = this.mainImageTypeGroupClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two MainImageTypeGroups should be found");

		Map<URI, MainImageTypeGroup> resultMap = new HashMap<>();
		for (MainImageTypeGroup MainImageTypeGroup : results.getEntries())
			resultMap.put(MainImageTypeGroup.getId(), MainImageTypeGroup);

		MainImageTypeGroupComparator.assertEquals(resultMap.get(mainImageTypeGroup1.getId()), mainImageTypeGroup1);
		MainImageTypeGroupComparator.assertEquals(resultMap.get(mainImageTypeGroup2.getId()), mainImageTypeGroup2);
	}
}
