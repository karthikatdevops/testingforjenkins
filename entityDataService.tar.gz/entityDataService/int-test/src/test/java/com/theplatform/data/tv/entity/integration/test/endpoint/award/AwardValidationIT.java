package com.theplatform.data.tv.entity.integration.test.endpoint.award;

import java.lang.reflect.InvocationTargetException;

import com.theplatform.data.tv.entity.api.fields.AwardField;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * GreenBuild test for validation of Award including verification of various
 * invalid creations
 * 
 * @author clai200
 * @since 4/5/2011
 * 
 */
@Test(groups = { TestGroup.gbTest, "award", "validation" })
public class AwardValidationIT extends EntityTestBase {



	/**
	 * Test of creation of an Award instance with null title, non-null
	 * description and rank. Creation should fail due to null title which is
	 * required for Award
	 */
	@Test(expectedExceptions = ValidationException.class)
	public void testAwardValidationCreateWithNullTitle() {
		Award input = this.awardFactory.create();

		input.setTitle(null);
		input.setDescription("test description");
		input.setRank(new Integer(1));

		this.awardClient.create(input);
	}

	/**
	 * Test of creation of an Award instance with empty title, non-null
	 * description and rank. Creation should fail due to empty title which is
	 * required for Award
	 */
	@Test(expectedExceptions = ValidationException.class)
	public void testAwardValidationCreateWithEmptyTitle() {
		Award input = this.awardFactory.create();

		input.setTitle("");
		input.setDescription("test description");
		input.setRank(new Integer(1));

		this.awardClient.create(input);
	}

	/**
	 * Test of creation of an Award instance with over max length title,
	 * non-null description and rank. Creation should fail due to over long
	 * title which is required for Award
	 */
	@Test(expectedExceptions = ValidationException.class)
	public void testAwardValidationCreateWithOverMaxTitleLength() {
		Award input = this.awardFactory.create();

		// each line is 50 charactor long
		input.setTitle("abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde" + "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde" + "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde" + "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
				+ "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde" + "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde");
		input.setDescription("test description");
		input.setRank(new Integer(1));

		this.awardClient.create(input);
	}
	
	
	//Rank
	
	
	@Test(expectedExceptions = ValidationException.class)
	public void testAwardCreateNegativeRank() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.awardClient.create(this.awardFactory.create(new DataServiceField(AwardField.rank, -1)));
	}
	@Test(expectedExceptions = ValidationException.class)
	public void testAwardCreateZeroRank() throws IllegalArgumentException, SecurityException,
	IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.awardClient.create(this.awardFactory.create(new DataServiceField(AwardField.rank, 0)));
	}
	public void testAwardCreatePositiveRank() throws IllegalArgumentException, SecurityException,
	IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.awardClient.create(this.awardFactory.create(new DataServiceField(AwardField.rank, 1)));
	}
	public void testAwardCreateNullRank() throws IllegalArgumentException, SecurityException,
	IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.awardClient.create(this.awardFactory.create(new DataServiceField(AwardField.rank, null)));
	}



}
