package com.theplatform.data.tv.entity.integration.test.endpoint.relatedperson;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.tv.entity.api.fields.RelatedPersonField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.relatedperson.BySourcePersonId;
import com.theplatform.data.tv.entity.api.client.query.relatedperson.ByTargetPersonId;
import com.theplatform.data.tv.entity.api.client.query.relatedperson.ByType;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPerson;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPersonType;
import com.theplatform.data.tv.entity.api.test.RelatedPersonComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "relatedPerson", "query" })
public class RelatedPersonQueryIT extends EntityTestBase {

	public void testRelatedPersonQueryBySourcePersonIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedPersonClient.create(this.relatedPersonFactory.create());
		Query[] queries = new Query[] { new BySourcePersonId(URIUtils.getIdValue(personClient.create(personFactory.create()).getId())) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedPerson should be found");
	}

	public void testRelatedPersonQueryBySourcePersonIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI personId = personClient.create(personFactory.create()).getId();
		RelatedPerson expected = this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.sourcePersonId, personId)),
				new String[] {});
		this.relatedPersonClient.create(this.relatedPersonFactory.create());

		Query[] queries = new Query[] { new BySourcePersonId(URIUtils.getIdValue(personId)) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedPerson should be found");

		RelatedPersonComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedPersonQueryBySourcePersonIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI personId = personClient.create(personFactory.create()).getId();
		this.relatedPersonClient.create(this.relatedPersonFactory.create());

		List<RelatedPerson> expectedRelatedPersons = this.relatedPersonClient.create(
				this.relatedPersonFactory.create(2, new DataServiceField(RelatedPersonField.sourcePersonId, personId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySourcePersonId(URIUtils.getIdValue(personId)) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedPersons should be found");

		Map<URI, RelatedPerson> resultMap = new HashMap<>();
		for (RelatedPerson relatedPerson : results.getEntries())
			resultMap.put(relatedPerson.getId(), relatedPerson);

		for (RelatedPerson expected : expectedRelatedPersons)
			RelatedPersonComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testRelatedPersonQueryByTargetPersonIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedPersonClient.create(this.relatedPersonFactory.create());
		Query[] queries = new Query[] { new ByTargetPersonId(URIUtils.getIdValue(personClient.create(personFactory.create()).getId())) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedPerson should be found");
	}

	public void testRelatedPersonQueryByTargetPersonIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI personId = personClient.create(personFactory.create()).getId();
		RelatedPerson expected = this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.targetPersonId, personId)),
				new String[] {});
		this.relatedPersonClient.create(this.relatedPersonFactory.create());

		Query[] queries = new Query[] { new ByTargetPersonId(URIUtils.getIdValue(personId)) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedPerson should be found");

		RelatedPersonComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedPersonQueryByTargetPersonIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI personId = personClient.create(personFactory.create()).getId();
		this.relatedPersonClient.create(this.relatedPersonFactory.create());

		List<RelatedPerson> expectedRelatedPersons = this.relatedPersonClient.create(
				this.relatedPersonFactory.create(2, new DataServiceField(RelatedPersonField.targetPersonId, personId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByTargetPersonId(URIUtils.getIdValue(personId)) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedPersons should be found");

		Map<URI, RelatedPerson> resultMap = new HashMap<>();
		for (RelatedPerson relatedPerson : results.getEntries())
			resultMap.put(relatedPerson.getId(), relatedPerson);

		for (RelatedPerson expected : expectedRelatedPersons)
			RelatedPersonComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testRelatedPersonQueryByTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.type, RelatedPersonType.hasSimilarMusic.getFriendlyName())));
		Query[] queries = new Query[] { new ByType(RelatedPersonType.followedMusic.getFriendlyName()) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedPerson should be found");
	}

	public void testRelatedPersonQueryByTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		RelatedPerson expected = this.relatedPersonClient.create(
				this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.type, RelatedPersonType.hasSimilarMusic.getFriendlyName())), new String[] {});
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.type, RelatedPersonType.influencedMusic.getFriendlyName())));

		Query[] queries = new Query[] { new ByType(RelatedPersonType.hasSimilarMusic.getFriendlyName()) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedPerson should be found");

		RelatedPersonComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedPersonQueryByTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.type, RelatedPersonType.collaboratorWith.getFriendlyName())));

		List<RelatedPerson> expectedRelatedPersons = this.relatedPersonClient.create(
				this.relatedPersonFactory.create(2, new DataServiceField(RelatedPersonField.type, RelatedPersonType.hasSimilarMusic.getFriendlyName())), new String[] {})
				.getEntries();
		Query[] queries = new Query[] { new ByType(RelatedPersonType.hasSimilarMusic.getFriendlyName()) };

		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedPersons should be found");

		Map<URI, RelatedPerson> resultMap = new HashMap<>();
		for (RelatedPerson relatedPerson : results.getEntries()) {
			resultMap.put(relatedPerson.getId(), relatedPerson);
		}

		for (RelatedPerson expected : expectedRelatedPersons)
			RelatedPersonComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testRelatedPersonQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedPerson should be found");
	}

	public void testRelatedPersonQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		RelatedPerson expected = this.relatedPersonClient.create(
				this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {});
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.merlinResourceType, MerlinResourceType.Editorial)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedPerson should be found");

		RelatedPersonComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedPersonQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedPersonClient.create(this.relatedPersonFactory.create(new DataServiceField(RelatedPersonField.merlinResourceType, MerlinResourceType.Editorial)));
		List<RelatedPerson> expectedRelatedPersons = this.relatedPersonClient.create(
				this.relatedPersonFactory.create(2, new DataServiceField(RelatedPersonField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {})
				.getEntries();
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<RelatedPerson> results = this.relatedPersonClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedPersons should be found");

		Map<URI, RelatedPerson> resultMap = new HashMap<>();
		for (RelatedPerson relatedPerson : results.getEntries()) {
			resultMap.put(relatedPerson.getId(), relatedPerson);
		}

		for (RelatedPerson expected : expectedRelatedPersons)
			RelatedPersonComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

}
