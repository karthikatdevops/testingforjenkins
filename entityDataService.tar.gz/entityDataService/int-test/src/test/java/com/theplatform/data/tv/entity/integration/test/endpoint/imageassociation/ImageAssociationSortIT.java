package com.theplatform.data.tv.entity.integration.test.endpoint.imageassociation;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;
import com.theplatform.data.tv.image.api.fields.ImageAssociationField;
import com.theplatform.data.tv.image.api.test.ImageAssociationComparator;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * Basic Sort tests for ImageAssociation
 */
@Test(groups = { "imageAssociation", "sort", TestGroup.gbTest })
public class ImageAssociationSortIT extends EntityTestBase {

	private static final int TEST_LIST_SIZE = 4;

	private List<ImageAssociation> imageAssociations;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		imageAssociations = this.imageAssociationFactory.create(TEST_LIST_SIZE);

	}

	public void testImageAssociationSortById() {

		Long id1 = this.objectIdProvider.nextId(), id2 = this.objectIdProvider.nextId(), id3 = this.objectIdProvider.nextId(), id4 = this.objectIdProvider
				.nextId();

		Assert.assertTrue(id1 < id2);
		Assert.assertTrue(id2 < id3);
		Assert.assertTrue(id3 < id4);

		imageAssociations.get(3).setId(URI.create(this.getBaseUrl().concat("/data/ImageAssociation/" + id1)));
		imageAssociations.get(0).setId(URI.create(this.getBaseUrl().concat("/data/ImageAssociation/" + id2)));
		imageAssociations.get(1).setId(URI.create(this.getBaseUrl().concat("/data/ImageAssociation/" + id3)));
		imageAssociations.get(2).setId(URI.create(this.getBaseUrl().concat("/data/ImageAssociation/" + id4)));

		imageAssociations.set(3, this.imageAssociationClient.create(imageAssociations.get(3), new String[] {}));
		imageAssociations.set(0, this.imageAssociationClient.create(imageAssociations.get(0), new String[] {}));
		imageAssociations.set(1, this.imageAssociationClient.create(imageAssociations.get(1), new String[] {}));
		imageAssociations.set(2, this.imageAssociationClient.create(imageAssociations.get(2), new String[] {}));

		// SORT EXPECTED
		List<ImageAssociation> expectedSortedImageAssociations = new ArrayList<>(imageAssociations.size());
		expectedSortedImageAssociations.add(imageAssociations.get(3));
		expectedSortedImageAssociations.add(imageAssociations.get(0));
		expectedSortedImageAssociations.add(imageAssociations.get(1));
		expectedSortedImageAssociations.add(imageAssociations.get(2));

		// RETRIVE WHITH SORTING
		Sort requestSort = new Sort(DataObjectField.id.getLocalName(), false);
		Feed<ImageAssociation> retrievedimageAssociations = this.imageAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort },
				null, false);

		ImageAssociationComparator.assertEquals(retrievedimageAssociations, expectedSortedImageAssociations);
	}

	public void testImageAssociationSortByIsDefault() {

		imageAssociations.get(0).setIsDefault(false);
		imageAssociations.get(1).setIsDefault(true);

		imageAssociations.set(0, this.imageAssociationClient.create(imageAssociations.get(0), new String[] {}));
		imageAssociations.set(1, this.imageAssociationClient.create(imageAssociations.get(1), new String[] {}));

		// SORT EXPECTED
		List<ImageAssociation> expectedSortedImageAssociations = new ArrayList<>(imageAssociations.size());
		expectedSortedImageAssociations.add(imageAssociations.get(0));
		expectedSortedImageAssociations.add(imageAssociations.get(1));

		// RETRIVE WHITH SORTING
		Sort requestSort = new Sort(ImageAssociationField.isDefault.getLocalName(), false);
		Feed<ImageAssociation> retrievedimageAssociations = this.imageAssociationClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort },
				null, false);

		ImageAssociationComparator.assertEquals(retrievedimageAssociations, expectedSortedImageAssociations);
	}

}
