package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.RequestParameters;
import com.theplatform.data.api.client.query.ById;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author jcoelho
 * @since 2/23/16
 */
public class ProgramTagsIdFilterIT extends EntityTestBase {

    @Test
    public void fetchProgramWithTagsFiltered_returnCorrectProgram() {

        // Create Program
        Program inputProgram = programFactory.create();
        programClient.create(inputProgram);

        // Create Association
        List<Tag> tags = tagFactory.create(2);
        tagClient.create(tags);

        List<TagAssociation> inputTagAssociations = tagAssociationFactory.create(2);
        inputTagAssociations.get(0).setEntityId(inputProgram.getId());
        inputTagAssociations.get(0).setTagId(tags.get(0).getId());
        inputTagAssociations.get(1).setEntityId(inputProgram.getId());
        inputTagAssociations.get(1).setTagId(tags.get(1).getId());

        tagAssociationClient.create(inputTagAssociations);

        // RETRIEVE
        Query[] queries = new Query[]{new ById(URIUtils.getIdValue(inputProgram.getId()))};
        RequestParameters requestParams = new RequestParameters();
        Map<String, String> params = new HashMap<>();
        params.put("tagIdsFilter", URIUtils.getIdValue(tags.get(0).getId()).toString() + "|" + URIUtils.getIdValue(tags.get(1).getId()).toString());

        requestParams.setParameters(params);
        Feed<Program> feed = programClient.getAll(new String[]{"id", ProgramField.tagIds.getLocalName()}, queries, new Sort[]{}, null, null, requestParams);

        Assert.assertEquals(feed.getEntryCount().longValue(), 1);
        Assert.assertEquals(feed.getEntries().get(0).getTagIds().size(), 2);
    }
}
