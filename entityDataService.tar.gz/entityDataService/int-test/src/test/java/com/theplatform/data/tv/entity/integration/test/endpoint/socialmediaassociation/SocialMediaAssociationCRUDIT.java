package com.theplatform.data.tv.entity.integration.test.endpoint.socialmediaassociation;

import com.theplatform.contrib.testing.comparator.DataObjectComparator;
import com.theplatform.contrib.testing.crud.CrudTestBase;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.contrib.testing.provider.GBTestIdProvider;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.NamespacedField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.test.api.data.factory.SocialMediaAssociationFactory;
import com.theplatform.data.tv.social.api.client.SocialMediaAssociationClient;
import com.theplatform.data.tv.social.api.data.objects.SocialMediaAssociation;
import com.theplatform.data.tv.social.api.data.objects.SocialMediaType;
import com.theplatform.data.tv.social.api.fields.SocialMediaAssociationField;
import com.theplatform.data.tv.social.api.test.SocialMediaAssociationComparator;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.Test;

import javax.annotation.Resource;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Test(groups = {"crud", "socialMediaAssociation", TestGroup.gbTest}, enabled = true)
public class SocialMediaAssociationCRUDIT extends CrudTestBase<SocialMediaAssociation> {

    @Autowired
    @Qualifier("baseEntityUrl")
    private String baseEntityUrl;

    @Resource
    protected SocialMediaAssociationClient smaClient;

    @Resource
    protected SocialMediaAssociationFactory smaFactory;

    @Resource
    protected SocialMediaAssociationComparator smaComparator;

    @Resource
    protected GBTestIdProvider objectIdProvider;

    @Override
    protected ValueProvider<Long> getValueProvider() {
        return objectIdProvider;
    }

    @Override
    protected DataServiceClient<SocialMediaAssociation> getClient() {
        return smaClient;
    }

    @Override
    protected DataObjectComparator<SocialMediaAssociation> getComparator() {
        return smaComparator;
    }

    @Override
    protected DataObjectFactory<SocialMediaAssociation, SocialMediaAssociationClient> getDataObjectFactory() {
        return smaFactory;
    }

    @Override
    protected Map<NamespacedField, Object> getUpdateValues(SocialMediaAssociation originalObject) {
        Map<NamespacedField, Object> updateValues = new HashMap<>();

        SocialMediaType oMediaType = SocialMediaType.getByFriendlyName(originalObject.getType());
        SocialMediaType mediaType = SocialMediaType.FACEBOOK;

        if (oMediaType == mediaType)
            mediaType = SocialMediaType.TWITTER;

        updateValues.put(SocialMediaAssociationField.type, mediaType.getFriendlyName());

        updateValues.put(SocialMediaAssociationField.identifier, originalObject.getIdentifier() + " updated");

        URI uEntityId = null;
        try {
            URI oEntityId = originalObject.getEntityId();
            if (oEntityId == null) {
                uEntityId = URI.create(baseEntityUrl.concat("/data/Person/" + objectIdProvider.nextId()));
            } else {
                String actualPath = StringUtils.substringBeforeLast(oEntityId.toString(), "/");
                String newPath = actualPath + "/" + objectIdProvider.nextId();
                uEntityId = new URI(newPath);
            }
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        updateValues.put(SocialMediaAssociationField.entityId, uEntityId);

        updateValues.put(SocialMediaAssociationField.primary, !originalObject.getPrimary());

        MerlinResourceType oMerlinResourceType = originalObject.getMerlinResourceType();
        if (oMerlinResourceType != null && oMerlinResourceType != MerlinResourceType.Temporary) {
            updateValues.put(SocialMediaAssociationField.merlinResourceType, MerlinResourceType.Temporary);
        } else {
            updateValues.put(SocialMediaAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable);
        }

        return updateValues;
    }

    @Override
    protected void populateDependencies(SocialMediaAssociation rawObject) {
        // we need to make sure that each object has a unique userId
        // rawObject.setUserId("userId" + objectIdProvider.nextId());
    }

    @Override
    protected Set<NamespacedField> getRequiredFields() {
        Set<NamespacedField> required = new HashSet<>();

        required.add(SocialMediaAssociationField.type);
        required.add(SocialMediaAssociationField.identifier);

        return required;
    }

    @Override
    protected Set<NamespacedField> getNullableFields() {
        Set<NamespacedField> nullable = new HashSet<>();
        return nullable;
    }

}
