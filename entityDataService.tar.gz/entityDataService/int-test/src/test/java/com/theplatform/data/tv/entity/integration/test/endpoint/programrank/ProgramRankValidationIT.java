package com.theplatform.data.tv.entity.integration.test.endpoint.programrank;

import java.lang.reflect.InvocationTargetException;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.entity.api.fields.ProgramRankField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "programRank", "validation" })
public class ProgramRankValidationIT extends EntityTestBase {

	public void testProgramRankValidTypes() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.type, "Algorithmic")));
		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.type, "Gross")));
		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.type, "Cumulative")));
	}

	@Test(dataProvider = "invalidTypes", expectedExceptions = ValidationException.class)
	public void testProgramRankInvalidTypes(String invalidType) throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.programRankClient.create(this.programRankFactory.create(new DataServiceField(ProgramRankField.type, invalidType)));
	}

	@DataProvider
	public Object[][] invalidTypes() {
		return new Object[][] { { "" }, { "faksetype" }, { null }, { "algorithmic" }, { "GROSS" } };
	}

	public void testProgramRankUniqueTypeAndProgramId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		ProgramRank programRank1 = this.programRankClient.create(this.programRankFactory.create(), new String[] {});
		ProgramRank programRank2 = this.programRankFactory.create(new DataServiceField(ProgramRankField.type,
				programRank1.getType().equals("Algorithmic") ? "Gross" : "Algorithmic"));
		Assert.assertNotEquals(programRank1.getType(), programRank2.getType());
		Assert.assertNotEquals(programRank1.getProgramId(), programRank2.getProgramId());
		programRankClient.create(programRank2);

	}

	public void testProgramRankUniqueSameTypeAndDifferentProgramIds() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		ProgramRank programRank1 = this.programRankClient.create(this.programRankFactory.create(), new String[] {});
		ProgramRank programRank2 = this.programRankFactory.create(new DataServiceField(ProgramRankField.type, programRank1.getType()));
		Assert.assertEquals(programRank1.getType(), programRank2.getType());
		Assert.assertNotEquals(programRank1.getProgramId(), programRank2.getProgramId());
		programRankClient.create(programRank2);

	}

	public void testProgramRankUniqueDifferentTypesAndSameProgramIds() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		ProgramRank programRank1 = this.programRankClient.create(this.programRankFactory.create(), new String[] {});
		ProgramRank programRank2 = this.programRankFactory.create(new DataServiceField(ProgramRankField.type,
				programRank1.getType().equals("Algorithmic") ? "Gross" : "Algorithmic"),
				new DataServiceField(ProgramRankField.programId, programRank1.getProgramId()));
		Assert.assertNotEquals(programRank1.getType(), programRank2.getType());
		Assert.assertEquals(programRank1.getProgramId(), programRank2.getProgramId());
		programRankClient.create(programRank2);

	}

	@Test( expectedExceptions = ValidationException.class)
	public void testProgramRankUniqueSameTypesAndSameProgramIds() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		ProgramRank programRank1 = this.programRankClient.create(this.programRankFactory.create(), new String[] {});
		ProgramRank programRank2 = this.programRankFactory.create(new DataServiceField(ProgramRankField.type, programRank1.getType()), new DataServiceField(
				ProgramRankField.programId, programRank1.getProgramId()));
		Assert.assertEquals(programRank1.getType(), programRank2.getType());
		Assert.assertEquals(programRank1.getProgramId(), programRank2.getProgramId());
		programRankClient.create(programRank2);

	}

}
