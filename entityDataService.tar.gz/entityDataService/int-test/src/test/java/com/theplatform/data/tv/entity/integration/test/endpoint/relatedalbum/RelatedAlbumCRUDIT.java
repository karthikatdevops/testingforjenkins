package com.theplatform.data.tv.entity.integration.test.endpoint.relatedalbum;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.RelatedAlbum;
import com.theplatform.data.tv.entity.api.fields.RelatedAlbumField;
import com.theplatform.data.tv.entity.api.test.RelatedAlbumComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { "relatedAlbum", "crud" })
public class RelatedAlbumCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testSingleRelatedAlbumCrud() {
		RelatedAlbum entity = this.relatedAlbumFactory.create();

		// CREATE
		RelatedAlbum persistedEntity = this.relatedAlbumClient.create(entity, new String[] {});
		RelatedAlbumComparator.assertEquals(persistedEntity, entity);

		// RETRIEVE
		RelatedAlbum retrievedEntity = this.relatedAlbumClient.get(entity.getId(), new String[] {});
		RelatedAlbumComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setSourceAlbumId(this.albumClient.create(this.albumFactory.create()).getId());
		entity.setTargetAlbumId(this.albumClient.create(this.albumFactory.create()).getId());
		// there is only one type (IsSimilar) for now
		// entity.setType(entity.getType() != null && entity.getType() !=
		// RelatedAlbumType.IsSimilar.getFriendlyName() ?
		// RelatedAlbumType.IsSimilar
		// .getFriendlyName() : RelatedAlbumType.IsSimilar.getFriendlyName());
		entity.setRank(entity.getRank() != null ? entity.getRank() + 1 : 1);

		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		this.relatedAlbumClient.update(entity);

		RelatedAlbum retrievedAfterUpdate = this.relatedAlbumClient.get(entity.getId(), new String[] {});
		RelatedAlbumComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = this.relatedAlbumClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.relatedAlbumClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("RelatedAlbum should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testRelatedAlbumFeedCrud() throws UnknownHostException {
		List<RelatedAlbum> entities = this.relatedAlbumFactory.create(5);

		// CREATE
		Feed<RelatedAlbum> persistedEntities = this.relatedAlbumClient.create(entities, new String[] {});

		Assert.assertEquals((long) persistedEntities.getEntryCount(), entities.size());
		for (int i = 0; i < persistedEntities.getEntryCount(); i++)
			RelatedAlbumComparator.assertEquals(persistedEntities.getEntries().get(i), entities.get(i));

		URI[] entityIds = new URI[entities.size()];
		for (int i = 0; i < entityIds.length; i++)
			entityIds[i] = entities.get(i).getId();

		// RETRIEVE
		Feed<RelatedAlbum> retrievedEntities = this.relatedAlbumClient.get(entityIds, new String[] {});
		for (int i = 0; i < retrievedEntities.getEntryCount(); i++)
			RelatedAlbumComparator.assertEquals(retrievedEntities.getEntries().get(i), entities.get(i));

		// DELETE
		long deletedEntities = this.relatedAlbumClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (RelatedAlbum entity : entities) {
			try {
				this.relatedAlbumClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedAlbumDefaultFieldValues() {
		RelatedAlbum entity = this.relatedAlbumFactory.create();

		entity.setRank(null);
		entity.setMerlinResourceType(null);
		RelatedAlbum actual = this.relatedAlbumClient.create(entity, new String[] {});

		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		RelatedAlbumComparator.assertEquals(actual, entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(RelatedAlbumField.rank, null),
			new DataServiceField(RelatedAlbumField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedAlbumCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(relatedAlbumClient, relatedAlbumFactory.create(), RelatedAlbumComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedAlbumCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(relatedAlbumClient, relatedAlbumFactory.create(), RelatedAlbumComparator.class,
				this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testRelatedAlbumUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(RelatedAlbumField.rank, 1));
		createValues.add(new DataServiceField(RelatedAlbumField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(relatedAlbumClient, relatedAlbumFactory.create(), RelatedAlbumComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testRelatedAlbumUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(RelatedAlbumField.rank, 1));
		createValues.add(new DataServiceField(RelatedAlbumField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(relatedAlbumClient, relatedAlbumFactory.create(), RelatedAlbumComparator.class,
				defaultValues, createValues.toArray(new DataServiceField[] {}), null);
	}
}
