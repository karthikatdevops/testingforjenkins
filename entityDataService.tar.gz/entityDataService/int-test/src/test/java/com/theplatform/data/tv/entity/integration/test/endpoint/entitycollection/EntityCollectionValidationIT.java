package com.theplatform.data.tv.entity.integration.test.endpoint.entitycollection;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollectionType;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * GreenBuild test for validation of EntityCollection including verification of
 * various invalid creations
 * 
 * @author jethrolai
 * 
 */
@Test(groups = { "entityCollection", "validation" })
public class EntityCollectionValidationIT extends EntityTestBase {


	private final static String[] INVALID_TYPES = new String[] { "subtype", "23asdf", "", null, " adfa ", "IDSFD", "XXX" };


	@DataProvider(name = "validTypes")
	public Object[][] validTypes() {
		List<Object[]> argumentList = new ArrayList<Object[]>();
		Object[][] argumentSet = new Object[EntityCollectionType.values().length][];

		for (EntityCollectionType type : EntityCollectionType.values()) {
			argumentList.add(new Object[] { type.getFriendlyName() });
		}
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	/**
	 * Test the creation of EntityCollection with valid Types
	 */
	@Test(groups = { TestGroup.gbTest }, dataProvider = "validTypes")
	public void testCreationWithValidTypes(String type) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();

		entityCollection.setType(type);
		entityCollection.setSubtype("subtype");

		this.entityCollectionClient.create(entityCollection);

		// Pass test if no ValidationException is thrown at this point

	}

	@DataProvider(name = "invalidTypeProvider")
	public Object[][] invalidTypeProvider() {
		int setIndex = 0;
		Object[][] arguementSet = new Object[INVALID_TYPES.length][];
		for (String type : INVALID_TYPES) {
			arguementSet[setIndex] = new Object[] { type };
			setIndex++;
		}

		return arguementSet;
	}

	/**
	 * Test of creation of EntityCollection with invalid types
	 */
	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class, dataProvider = "invalidTypeProvider")
	public void testCreationWithInvalidTypes(String invalidType) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();

		entityCollection.setType(invalidType);
		entityCollection.setSubtype("subtype");

		this.entityCollectionClient.create(entityCollection);

	}

	/**
	 * If subtype in ('Language' or 'Content' or 'All'), type must = 'Variant'
	 */
	@Test(enabled = true, groups = { TestGroup.gbTest })
	public void testCreationWithValidSubtypesWithVariantType() {
		final String[] validVariantSubtypes = { "Language", "Content", "All" };

		for (String subtype : validVariantSubtypes) {
			EntityCollection entityCollection = this.entityCollectionFactory.create();

			entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
			entityCollection.setSubtype(subtype);

			this.entityCollectionClient.create(entityCollection);
		}

	}

	@DataProvider
	public Object[][] variantSubtypes() {
		final String[] variantSubtypes = new String[] { "Language", "Content", "All" };
		List<Object[]> argumentList = new ArrayList<Object[]>();
		Object[][] argumentSet = new Object[variantSubtypes.length][];

		for (String subtype : variantSubtypes)

			argumentList.add(new Object[] { subtype });

		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	/**
	 * If subtype in ('Language' or 'Content' or 'All'), type must = 'Variant'
	 * 
	 * @throws Exception
	 *             disabled for debugging 01/05/2012
	 */

	@Test(enabled = true, groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class, dataProvider = "variantSubtypes")
	public void testCreationWithVariantSubtypesWithNonVariantType(String subtype) {

		EntityCollection entityCollection = this.entityCollectionFactory.create();

		entityCollection.setType(EntityCollectionType.ADIPackage.getFriendlyName());
		entityCollection.setSubtype(subtype);

		this.entityCollectionClient.create(entityCollection);

	}

	@DataProvider
	public Object[][] languageOrContentSubtypes() {
		final String[] variantSubtypes = new String[] { "Language", "Content" };
		List<Object[]> argumentList = new ArrayList<Object[]>();
		Object[][] argumentSet = new Object[variantSubtypes.length][];

		for (String subtype : variantSubtypes)

			argumentList.add(new Object[] { subtype });

		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	@Test(groups = { TestGroup.gbTest }, dataProvider = "languageOrContentSubtypes")
	public void testNullPrimaryEntitiesWithLanguageOrContentSubtype(String subtype) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();

		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype(subtype);
		entityCollection.setPrimaryEntities(null);

		this.entityCollectionClient.create(entityCollection);
	}

	@Test(groups = { TestGroup.gbTest }, dataProvider = "languageOrContentSubtypes")
	public void testEmptyPrimaryEntitiesWithLanguageOrContentSubtype(String subtype) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();

		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype(subtype);
		entityCollection.setPrimaryEntities(new HashMap<String, URI>());

		this.entityCollectionClient.create(entityCollection);
	}

	@Test(groups = { TestGroup.gbTest }, dataProvider = "languageOrContentSubtypes")
	public void testSinglePrimaryEntitiesWithLanguageOrContentSubtype(String subtype) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype(subtype);

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("Primary", entityIds.get(0));
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);
	}

	@Test(groups = { TestGroup.gbTest }, dataProvider = "languageOrContentSubtypes", expectedExceptions = ValidationException.class)
	public void testSinglePrimaryEntitiesWithLanguageOrContentSubtypeNonPrimaryMapKey(String subtype) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype(subtype);

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("English", entityIds.get(0));
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);
	}

	@Test(groups = { TestGroup.testBug }, dataProvider = "languageOrContentSubtypes", expectedExceptions = ValidationException.class)
	// @Test(groups = { TestGroup.gbTest }, dataProvider =
	// "languageOrContentSubtypes", expectedExceptions =
	// ValidationException.class)
	public void testSinglePrimaryEntitiesWithLanguageOrContentSubtypeNonExistingEntity(String subtype) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programFactory.create().getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype(subtype);

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("Primary", entityIds.get(0));
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);
	}

	@Test(groups = { TestGroup.gbTest }, dataProvider = "languageOrContentSubtypes", expectedExceptions = ValidationException.class)
	public void testSinglePrimaryEntitiesWithLanguageOrContentSubtypeEntityNotInEntityIds(String subtype) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype(subtype);

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("Primary", programClient.create(programFactory.create()).getId());
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);
	}

	@DataProvider
	public Object[][] validPrimaryEntityKeys() {
		final String[] validPrimaryEntityKeys = new String[] { "Primary", "English", "Spanish" };
		List<Object[]> argumentList = new ArrayList<Object[]>();
		Object[][] argumentSet = new Object[validPrimaryEntityKeys.length][];

		for (String subtype : validPrimaryEntityKeys)

			argumentList.add(new Object[] { subtype });

		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	@Test(groups = { TestGroup.gbTest }, dataProvider = "validPrimaryEntityKeys")
	public void testSinglePrimaryEntitiesWithAllSubtypeEntity(String primaryEntityKey) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype("All");

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put(primaryEntityKey, entityIds.get(0));
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class, dataProvider = "validPrimaryEntityKeys")
	public void testSinglePrimaryEntitiesWithAllSubtypeEntityNonExistingEntityId(String primaryEntityKey) {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype("All");

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put(primaryEntityKey, programClient.create(programFactory.create()).getId());
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testTwoPrimaryEntitiesWithAllSubtypeEntity() {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype("All");

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("Primary", entityIds.get(0));
		primaryEntities.put("English", entityIds.get(0));
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);

		entityCollection = this.entityCollectionFactory.create();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype("All");

		primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("Primary", entityIds.get(0));
		primaryEntities.put("Spanish", entityIds.get(0));
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testTwoPrimaryEntitiesWithAllSubtypeEntityNonExistingEntityId() {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype("All");

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("Primary", entityIds.get(0));
		primaryEntities.put("English", entityIds.get(0));
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);

		entityCollection = this.entityCollectionFactory.create();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype("All");

		primaryEntities = new HashMap<String, URI>();
		URI nonExistingEntityId = programClient.create(programFactory.create()).getId();
		primaryEntities.put("Primary", nonExistingEntityId);
		primaryEntities.put("Spanish", nonExistingEntityId);
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testThreePrimaryEntitiesWithAllSubtypeEntityOneEntityId() {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype("All");

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("Primary", entityIds.get(0));
		primaryEntities.put("English", entityIds.get(0));
		primaryEntities.put("Spanish", entityIds.get(0));
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);

	}

	@Test(groups = { TestGroup.gbTest })
	public void testThreePrimaryEntitiesWithAllSubtypeEntityDifferentEntityId() {
		EntityCollection entityCollection = this.entityCollectionFactory.create();
		List<URI> entityIds = new ArrayList<URI>();
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityIds.add(programClient.create(programFactory.create()).getId());
		entityCollection.setEntityIds(entityIds);
		entityCollection.setType(EntityCollectionType.Variant.getFriendlyName());
		entityCollection.setSubtype("All");

		Map<String, URI> primaryEntities = new HashMap<String, URI>();
		primaryEntities.put("Primary", entityIds.get(0));
		primaryEntities.put("English", entityIds.get(0));
		primaryEntities.put("Spanish", entityIds.get(1));
		entityCollection.setPrimaryEntities(primaryEntities);

		this.entityCollectionClient.create(entityCollection);

	}

}
