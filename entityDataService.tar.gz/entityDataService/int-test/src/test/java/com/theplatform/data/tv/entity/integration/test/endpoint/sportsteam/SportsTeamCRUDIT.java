package com.theplatform.data.tv.entity.integration.test.endpoint.sportsteam;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.fields.SportsTeamField;
import com.theplatform.data.tv.entity.api.test.SportsTeamComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */
@Test(groups = { "sportsTeam", "crud" })
public class SportsTeamCRUDIT extends EntityTestBase {
	@Test(groups = { TestGroup.gbTest })
	public void crudSportsTeamEntry() throws UnknownHostException {
		SportsTeam inputSportsTeam = this.sportsTeamFactory.create();

		// CREATE
		SportsTeam persistedSportsTeam = this.sportsTeamClient.create(inputSportsTeam);
		assertEquals(persistedSportsTeam.getId(), inputSportsTeam.getId(), "SportsTeam ids should match after creation");

		// RETRIEVE
		SportsTeam retrievedSportsTeam = this.sportsTeamClient.get(persistedSportsTeam.getId(), new String[] {});
		SportsTeamComparator.assertEquals(retrievedSportsTeam, inputSportsTeam);

		// UPDATE
		inputSportsTeam.setNickName(inputSportsTeam.getNickName() + " - changed");
		this.sportsTeamClient.update(inputSportsTeam);
		SportsTeam retrievedAfterUpdate = this.sportsTeamClient.get(inputSportsTeam.getId(), new String[] {});
		SportsTeamComparator.assertEquals(retrievedAfterUpdate, inputSportsTeam);

		// DELETE
		long deletedObjects = this.sportsTeamClient.delete(inputSportsTeam.getId());
		assertEquals(deletedObjects, 1);
		try {
			this.sportsTeamClient.get(inputSportsTeam.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}
		fail("SportsTeam should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void crudSportsTeamFeed() throws UnknownHostException {
		List<SportsTeam> inputSportsTeams = this.sportsTeamFactory.create(5);

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] sportsTeamIds = (URI[]) CollectionUtils.collect(inputSportsTeams, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<SportsTeam> persistedSportsTeams = this.sportsTeamClient.create(inputSportsTeams);
		ComparatorUtils.assertIdsAreEqual(inputSportsTeams, persistedSportsTeams.getEntries());

		// RETRIEVE
		Feed<SportsTeam> retrievedSportsTeams = this.sportsTeamClient.get(sportsTeamIds, new String[] {});
		SportsTeamComparator.assertEquals(retrievedSportsTeams, inputSportsTeams);

		// UPDATE
		for (int i = 1; i < inputSportsTeams.size(); i++) {
			inputSportsTeams.get(i).setNickName(inputSportsTeams.get(i).getNickName() + " - changed " + i);
			inputSportsTeams.get(i).setImageIds(null);
		}
		this.sportsTeamClient.update(inputSportsTeams);
		for (int i = 1; i < inputSportsTeams.size(); i++) {
			inputSportsTeams.get(i).setImageIds(new ArrayList<URI>());
		}
		Feed<SportsTeam> retrievedAfterUpdate = this.sportsTeamClient.get(sportsTeamIds, new String[] {});
		SportsTeamComparator.assertEquals(retrievedAfterUpdate, inputSportsTeams);

		// DELETE
		long deletedSportsTeams = this.sportsTeamClient.delete(sportsTeamIds);
		assertEquals(deletedSportsTeams, inputSportsTeams.size());
		long notFoundSportsTeams = 0;
		for (SportsTeam sportsTeam : inputSportsTeams) {
			try {
				this.sportsTeamClient.get(sportsTeam.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundSportsTeams++;
			}
		}
		assertEquals(notFoundSportsTeams, deletedSportsTeams, "Still found SportsTeam after deleting");
	}
	
	private final DataServiceField[] defaultValues = new DataServiceField[] {
			new DataServiceField(SportsTeamField.representingName, null), 
			new DataServiceField(SportsTeamField.nickName, null),
            new DataServiceField(SportsTeamField.leagueId, null),
            new DataServiceField(SportsTeamField.parentSportsTeamId, null),
            new DataServiceField(SportsTeamField.city, null),
			new DataServiceField(SportsTeamField.state, null), 
			new DataServiceField(SportsTeamField.country, null), 
			new DataServiceField(SportsTeamField.conference, null), 
			new DataServiceField(SportsTeamField.division, null),
            new DataServiceField(SportsTeamField.sportType, null),
            new DataServiceField(SportsTeamField.type, null),
            new DataServiceField(SportsTeamField.gender, null),
			new DataServiceField(SportsTeamField.coach, null), 
			new DataServiceField(SportsTeamField.coachPersonId, null), 
			new DataServiceField(SportsTeamField.venue, null), 
			new DataServiceField(SportsTeamField.shortBio, null),
			new DataServiceField(SportsTeamField.mediumBio, null),
			new DataServiceField(SportsTeamField.longBio, null),
			// If not set on create defaults to 'AudienceAvailable', or 'Editorial' if
			// ID has editorial suffix
			new DataServiceField(SportsTeamField.merlinResourceType, MerlinResourceType.AudienceAvailable), 
			};

	@Test(groups = { TestGroup.gbTest })
	public void testSportsTeamCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(sportsTeamClient, sportsTeamFactory.create(), SportsTeamComparator.class, this.defaultValues,
				new DataServiceField[] { 
			new DataServiceField(SportsTeamField.imageIds, new ArrayList<URI>()),
			new DataServiceField(SportsTeamField.mainImages, new HashMap<String,MediaFile>()),
			new DataServiceField(SportsTeamField.selectedImages, new ArrayList<MainImageInfo>()),
		});
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSportsTeamCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(sportsTeamClient, sportsTeamFactory.create(), SportsTeamComparator.class, this.defaultValues,
				new DataServiceField[] { 
			new DataServiceField(SportsTeamField.imageIds, new ArrayList<URI>()),
			new DataServiceField(SportsTeamField.mainImages, new HashMap<String,MediaFile>()),
			new DataServiceField(SportsTeamField.selectedImages, new ArrayList<MainImageInfo>()),
		});
	}

	@Test(groups = { TestGroup.gbTest })
	public void testSportsTeamUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(SportsTeamField.representingName, "sportsTeam representingName"));
		createValues.add(new DataServiceField(SportsTeamField.nickName, "sportsTeam nickName"));
        createValues.add(new DataServiceField(SportsTeamField.leagueId, sportsLeagueClient.create(sportsLeagueFactory.create()).getId()));
        createValues.add(new DataServiceField(SportsTeamField.parentSportsTeamId, sportsTeamClient.create(sportsTeamFactory.create()).getId()));
		createValues.add(new DataServiceField(SportsTeamField.city, "sportsTeam city"));
		createValues.add(new DataServiceField(SportsTeamField.state, "sportsTeam state"));
		createValues.add(new DataServiceField(SportsTeamField.country, "sportsTeam country"));
		createValues.add(new DataServiceField(SportsTeamField.conference, "sportsTeam conference"));
		createValues.add(new DataServiceField(SportsTeamField.division, "sportsTeam division"));
        createValues.add(new DataServiceField(SportsTeamField.sportType, "Volleyball"));
        createValues.add(new DataServiceField(SportsTeamField.type, "Team"));
		createValues.add(new DataServiceField(SportsTeamField.gender, "Male"));
		createValues.add(new DataServiceField(SportsTeamField.coach, "sportsTeam coach"));
		createValues.add(new DataServiceField(SportsTeamField.coachPersonId, personClient.create(personFactory.create()).getId()));
		createValues.add(new DataServiceField(SportsTeamField.venue, "sportsTeam venue"));
		createValues.add(new DataServiceField(SportsTeamField.merlinResourceType, MerlinResourceType.Temporary));
		createValues.add(new DataServiceField(SportsTeamField.shortBio, "sportsTeam shortBio"));
		createValues.add(new DataServiceField(SportsTeamField.mediumBio, "sportsTeam mediumBio"));
		createValues.add(new DataServiceField(SportsTeamField.longBio, "sportsTeam longBio"));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(sportsTeamClient, sportsTeamFactory.create(), SportsTeamComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] { 
			new DataServiceField(SportsTeamField.imageIds, new ArrayList<URI>()),
			new DataServiceField(SportsTeamField.mainImages, new HashMap<String,MediaFile>()),
			new DataServiceField(SportsTeamField.selectedImages, new ArrayList<MainImageInfo>())}
		);
	}

	@Test(groups = TestGroup.gbTest)
	public void testSportsTeamUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(SportsTeamField.representingName, "sportsTeam representingName"));
		createValues.add(new DataServiceField(SportsTeamField.nickName, "sportsTeam nickName"));
		createValues.add(new DataServiceField(SportsTeamField.leagueId, sportsLeagueClient.create(sportsLeagueFactory.create()).getId()));
        createValues.add(new DataServiceField(SportsTeamField.parentSportsTeamId, sportsTeamClient.create(sportsTeamFactory.create()).getId()));
		createValues.add(new DataServiceField(SportsTeamField.city, "sportsTeam city"));
		createValues.add(new DataServiceField(SportsTeamField.state, "sportsTeam state"));
		createValues.add(new DataServiceField(SportsTeamField.country, "sportsTeam country"));
		createValues.add(new DataServiceField(SportsTeamField.conference, "sportsTeam conference"));
		createValues.add(new DataServiceField(SportsTeamField.division, "sportsTeam division"));
		createValues.add(new DataServiceField(SportsTeamField.sportType, "Volleyball"));
        createValues.add(new DataServiceField(SportsTeamField.type, "Team"));
		createValues.add(new DataServiceField(SportsTeamField.gender, "Male"));
		createValues.add(new DataServiceField(SportsTeamField.coach, "sportsTeam coach"));
		createValues.add(new DataServiceField(SportsTeamField.coachPersonId, personClient.create(personFactory.create()).getId()));
		createValues.add(new DataServiceField(SportsTeamField.venue, "sportsTeam venue"));
		createValues.add(new DataServiceField(SportsTeamField.merlinResourceType, MerlinResourceType.Temporary));
		createValues.add(new DataServiceField(SportsTeamField.shortBio, "sportsTeam shortBio"));
		createValues.add(new DataServiceField(SportsTeamField.mediumBio, "sportsTeam mediumBio"));
		createValues.add(new DataServiceField(SportsTeamField.longBio, "sportsTeam longBio"));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(sportsTeamClient, sportsTeamFactory.create(), SportsTeamComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), new DataServiceField[] {
			new DataServiceField(SportsTeamField.imageIds, new ArrayList<URI>()),
			new DataServiceField(SportsTeamField.mainImages, new HashMap<String,MediaFile>()),
			new DataServiceField(SportsTeamField.selectedImages, new ArrayList<MainImageInfo>())}
		);
	}

}
