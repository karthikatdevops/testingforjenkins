package com.theplatform.data.tv.entity.integration.test.endpoint.sportsevent;

import static org.testng.Assert.assertEquals;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.entity.api.client.query.sportsevent.ByLeagueId;
import com.theplatform.data.tv.entity.api.client.query.sportsevent.BySportType;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.test.SportsEventComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * 
 * @author clai200
 * @since 4/8/2011
 */
@Test(groups = { "sportsEvent", "query" })
public class SportsEventQueryIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void testQuerySportsEventByTitle() throws UnknownHostException {
		List<SportsEvent> inputSportsEvents = this.sportsEventFactory.create(3);
		inputSportsEvents.get(1).setTitle("some new title");
		sportsEventClient.create(inputSportsEvents);
		Query queries[] = new Query[] { new ByTitle(inputSportsEvents.get(1).getTitle()) };
		Feed<SportsEvent> retrievedSportsEvent = sportsEventClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedSportsEvent.getEntries().size(), 1, "Not getting SportsEvents using query byTitle");
		SportsEventComparator.assertEquals(retrievedSportsEvent.getEntries().get(0), inputSportsEvents.get(1));
	}

	@Test(groups = { TestGroup.gbTest })
	public void testQuerySportsEventBySportType() throws UnknownHostException {
		List<SportsEvent> inputSportsEvents = this.sportsEventFactory.create(3);
		inputSportsEvents.get(2).setSportType("Golf");
		sportsEventClient.create(inputSportsEvents);
		Query queries[] = new Query[] { new BySportType(inputSportsEvents.get(2).getSportType()), };
		Feed<SportsEvent> retrievedSportsEvents = sportsEventClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedSportsEvents.getEntries().size(), 1, "Not getting SportsEvents using query bySportType");
		SportsEventComparator.assertEquals(retrievedSportsEvents.getEntries().get(0), inputSportsEvents.get(2));
	}

	@Test(groups = { TestGroup.gbTest })
	public void testQuerySportsEventByLeagueId() throws UnknownHostException {
		List<SportsEvent> inputSportsEvents = this.sportsEventFactory.create(3);
		inputSportsEvents.get(0).setLeagueId(this.sportsLeagueClient.create(this.sportsLeagueFactory.create()).getId());
		sportsEventClient.create(inputSportsEvents);
		Query queries[] = new Query[] { new ByLeagueId(URIUtils.getIdValue(inputSportsEvents.get(0).getLeagueId())) };
		Feed<SportsEvent> retrievedSportsEvents = sportsEventClient.getAll(null, queries, null, null, null);
		assertEquals(retrievedSportsEvents.getEntries().size(), 1, "Not getting SportsEvents using query byLeagueId");
		SportsEventComparator.assertEquals(retrievedSportsEvents.getEntries().get(0), inputSportsEvents.get(0));
	}

	@Test(groups = { TestGroup.testBug})
	public void testQuerySportsEventByAllQueryCombination() throws UnknownHostException {
		List<SportsEvent> inputSportsEvents = this.sportsEventFactory.create(5);
		inputSportsEvents.get(2).setSportType("Football");
		inputSportsEvents.get(4).setSportType("Football");
		sportsEventClient.create(inputSportsEvents);
		List<String> titles = new ArrayList<>();
		titles.add(inputSportsEvents.get(2).getTitle());
		titles.add(inputSportsEvents.get(4).getTitle());

		List<Long> leagueIds = new ArrayList<>();
		leagueIds.add(LocalUriConverter.convertUriToID(inputSportsEvents.get(2).getLeagueId()));
		leagueIds.add(LocalUriConverter.convertUriToID(inputSportsEvents.get(4).getLeagueId()));

		Query queries[] = new Query[] { new ByTitle(titles), new BySportType(inputSportsEvents.get(2).getSportType()), new ByLeagueId(leagueIds) };

		Sort sorts[] = new Sort[] { new Sort("id", true) };
		Feed<SportsEvent> retrievedSportsEvents = sportsEventClient.getAll(null, queries, sorts, null, null);
		assertEquals(retrievedSportsEvents.getEntries().size(), 2, "Not get all SportsEvents using query combination");

		assertEquals(retrievedSportsEvents.getEntryCount().longValue(), 2, "Not get all SportsEvents using query combination");

		// to make comparision for all fields
		SportsEventComparator.assertEquals(retrievedSportsEvents.getEntries().get(0), inputSportsEvents.get(4));
		SportsEventComparator.assertEquals(retrievedSportsEvents.getEntries().get(1), inputSportsEvents.get(2));
	}

}
