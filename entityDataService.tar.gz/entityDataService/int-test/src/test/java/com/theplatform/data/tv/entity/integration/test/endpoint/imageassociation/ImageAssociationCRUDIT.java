package com.theplatform.data.tv.entity.integration.test.endpoint.imageassociation;

import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.comparator.ComparatorUtils;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.image.api.fields.ImageAssociationField;
import com.theplatform.data.tv.image.api.test.ImageAssociationComparator;
import com.theplatform.data.tv.ingest.type.ProviderType;
import com.theplatform.module.exception.ValidationException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

/**
 * Basic CRUD tests for ImageAssociations
 * 
 * @since 4/7/2011
 */
@Test(groups = { "imageAssociation", "crud" })
public class ImageAssociationCRUDIT extends EntityTestBase {



	@Test(groups = { TestGroup.gbTest })
	public void crudSingleImageAssociation() throws UnknownHostException {
		ImageAssociation imageAssociation = this.imageAssociationFactory.create();

		// CREATE
		ImageAssociation persistedImageAssociation = this.imageAssociationClient.create(imageAssociation, new String[] {});
		ImageAssociationComparator.assertEquals(persistedImageAssociation, imageAssociation);

		// RETRIEVE
		ImageAssociation retrievedImageAssociation = this.imageAssociationClient.get(imageAssociation.getId(), new String[] {});
		ImageAssociationComparator.assertEquals(retrievedImageAssociation, imageAssociation);

		// UPDATE
		imageAssociation.setEntityId(this.programClient.create(programFactory.create()).getId());
		
		MediaId mediaId = new MediaId();
		if (imageAssociation.getMediaId()!= null){
		mediaId.setAccountGuid(imageAssociation.getMediaId().getAccountGuid()==null? "accountGuid": imageAssociation.getMediaId().getAccountGuid().concat(" updated"));
		mediaId.setServiceGuid(imageAssociation.getMediaId().getServiceGuid()==null? "serviceGuid": imageAssociation.getMediaId().getServiceGuid().concat(" updated"));
		mediaId.setMediaGuid(imageAssociation.getMediaId().getMediaGuid()==null? "mediaGuid": imageAssociation.getMediaId().getMediaGuid().concat(" updated"));
		} else {
			mediaId.setAccountGuid("accountGuid"); 
			mediaId.setServiceGuid("serviceGuid"); 
			mediaId.setMediaGuid("mediaGuid");
		}
		imageAssociation.setMediaId(mediaId);
		this.imageAssociationClient.update(imageAssociation);

		ImageAssociation retrievedAfterUpdate = this.imageAssociationClient.get(imageAssociation.getId(), new String[] {});
		ImageAssociationComparator.assertEquals(retrievedAfterUpdate, imageAssociation);

		// DELETE
		long deletedObjects = this.imageAssociationClient.delete(imageAssociation.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.imageAssociationClient.get(imageAssociation.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("ImageAssociation should not be found after deleting it");
	}

	@Test(groups = { TestGroup.gbTest })
	public void sparceUpdateImageAssociationMRT() throws Exception {
		ImageAssociation imageAssociation = this.imageAssociationFactory.create();

		// CREATE
		ImageAssociation persistedImageAssociation = this.imageAssociationClient.create(imageAssociation, new String[] {});
		ImageAssociationComparator.assertEquals(persistedImageAssociation, imageAssociation);

		// UPDATE
		ImageAssociation sparceImageAssociation = new ImageAssociation();
		sparceImageAssociation.setId(persistedImageAssociation.getId());
		sparceImageAssociation.setOwnerId(persistedImageAssociation.getOwnerId());
		sparceImageAssociation.setMerlinResourceType(MerlinResourceType.Inactive);
		
		this.imageAssociationClient.update(sparceImageAssociation);

		persistedImageAssociation.setMerlinResourceType(MerlinResourceType.Inactive);
		
		ImageAssociation retrievedAfterUpdate = this.imageAssociationClient.get(imageAssociation.getId(), new String[] {});
		ImageAssociationComparator.assertEquals(retrievedAfterUpdate, persistedImageAssociation);
	}

	@Test(groups = { TestGroup.gbTest })
	public void updateImageAssociationMRTLowToHigh() throws Exception {
		ImageAssociation imageAssociation = this.imageAssociationFactory.create();
		imageAssociation.setMerlinResourceType(MerlinResourceType.Inactive);
		
		// CREATE
		ImageAssociation persistedImageAssociation = this.imageAssociationClient.create(imageAssociation, new String[] {});
		ImageAssociationComparator.assertEquals(persistedImageAssociation, imageAssociation);

		// UPDATE
		ImageAssociation updatedImageAssociation = new ImageAssociation();
		updatedImageAssociation.setId(persistedImageAssociation.getId());
		updatedImageAssociation.setOwnerId(persistedImageAssociation.getOwnerId());
		updatedImageAssociation.setMerlinResourceType(MerlinResourceType.Temporary);
		
		this.imageAssociationClient.update(updatedImageAssociation);

		persistedImageAssociation.setMerlinResourceType(MerlinResourceType.Temporary);
		
		ImageAssociation retrievedAfterUpdate = this.imageAssociationClient.get(imageAssociation.getId(), new String[] {});
		ImageAssociationComparator.assertEquals(retrievedAfterUpdate, persistedImageAssociation);
	}
	
	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void updateImageAssociationMRTNToEditorial() throws Exception {
		ImageAssociation imageAssociation = this.imageAssociationFactory.create();
		imageAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		
		// CREATE
		ImageAssociation persistedImageAssociation = this.imageAssociationClient.create(imageAssociation, new String[] {});
		ImageAssociationComparator.assertEquals(persistedImageAssociation, imageAssociation);

		// UPDATE
		ImageAssociation updatedImageAssociation = new ImageAssociation();
		updatedImageAssociation.setId(persistedImageAssociation.getId());
		updatedImageAssociation.setOwnerId(persistedImageAssociation.getOwnerId());
		updatedImageAssociation.setMerlinResourceType(MerlinResourceType.Editorial);
		
		this.imageAssociationClient.update(updatedImageAssociation);
	}
	
	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void createImageAssociationMRTNToEditorial() throws Exception {
		ImageAssociation imageAssociation = this.imageAssociationFactory.create();
		imageAssociation.setMerlinResourceType(MerlinResourceType.Editorial);
		
		// CREATE
		this.imageAssociationClient.create(imageAssociation, new String[] {});
	}
	
	@Test(groups = { TestGroup.gbTest })
	public void updateImageAssociationMRTNToNonEditorial() throws Exception {
		URI id = URI.create(imageAssociationClient.getRequestUrl() + "/" + 
	             String.valueOf(objectIdProvider.nextId()) + 
	             String.valueOf(ProviderType.EDITORIAL_ENTITY_BASE.getTypeSuffix()));
		
		ImageAssociation imageAssociation = this.imageAssociationFactory.create();
		imageAssociation.setMerlinResourceType(MerlinResourceType.Editorial);
		imageAssociation.setId(id);
		
		// CREATE
		ImageAssociation persistedImageAssociation = this.imageAssociationClient.create(imageAssociation, new String[] {});
		ImageAssociationComparator.assertEquals(persistedImageAssociation, imageAssociation);

		// UPDATE
		ImageAssociation updatedImageAssociation = new ImageAssociation();
		updatedImageAssociation.setId(persistedImageAssociation.getId());
		updatedImageAssociation.setOwnerId(persistedImageAssociation.getOwnerId());
		updatedImageAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		
		this.imageAssociationClient.update(updatedImageAssociation);
		
		imageAssociation = this.imageAssociationClient.get(id, new String[] {ImageAssociationField.merlinResourceType.getLocalName()});
		
		Assert.assertNotNull(imageAssociation);
		Assert.assertTrue(imageAssociation.getMerlinResourceType() == MerlinResourceType.Editorial);
	}
	
	@Test(groups = { TestGroup.gbTest })
	public void createImageAssociationMRTNToNonEditorial() throws Exception {
		URI id = URI.create(imageAssociationClient.getRequestUrl() + "/" + 
	             String.valueOf(objectIdProvider.nextId()) + 
	             String.valueOf(ProviderType.EDITORIAL_ENTITY_BASE.getTypeSuffix()));
		
		ImageAssociation imageAssociation = this.imageAssociationFactory.create();
		imageAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		imageAssociation.setId(id);
		
		// CREATE
		imageAssociation = this.imageAssociationClient.create(imageAssociation, new String[] {ImageAssociationField.merlinResourceType.getLocalName()});
		
		Assert.assertNotNull(imageAssociation);
		Assert.assertTrue(imageAssociation.getMerlinResourceType() == MerlinResourceType.Editorial);
	}
	
	@Test(groups = { "other" })
	public void crudImageAssociationFeed() throws UnknownHostException {
		List<ImageAssociation> imageAssociations = this.imageAssociationFactory.create(5);
		// CREATE
		Feed<ImageAssociation> persistedImageAssociations = this.imageAssociationClient.create(imageAssociations);
		if (imageAssociations.get(0).getId() == null) {
			int counter = 0;
			for (ImageAssociation imageAssociation : persistedImageAssociations.getEntries())
				imageAssociations.get(counter++).setId(imageAssociation.getId());
		}

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] ImageAssociationIds = (URI[]) CollectionUtils.collect(imageAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		ComparatorUtils.assertIdsAreEqual(imageAssociations, persistedImageAssociations.getEntries());

		// RETRIEVE
		Feed<ImageAssociation> retrievedImageAssociations = this.imageAssociationClient.get(ImageAssociationIds, new String[] {});
		ImageAssociationComparator.assertEquals(retrievedImageAssociations, imageAssociations);

		// DELETE
		long deletedImageAssociations = this.imageAssociationClient.delete(ImageAssociationIds);
		assertEquals(imageAssociations.size(), deletedImageAssociations);

		long notFoundImageAssociations = 0;
		for (ImageAssociation ImageAssociation : imageAssociations) {
			try {
				this.imageAssociationClient.get(ImageAssociation.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundImageAssociations++;
			}
		}
		assertEquals(notFoundImageAssociations, deletedImageAssociations, "Still found ImageAssociations after deleting");
	}

	//TODO MERLIN-9373
	@Test(groups = { TestGroup.testBug })
	public void crudSingleImageAssociationWithPreferForMainImageType() throws UnknownHostException {
		ImageAssociation imageAssociation = this.imageAssociationFactory.create();
		MainImageType mainImageType = this.mainImageTypeClient.create(this.mainImageTypeFactory.create());
		List<URI> preferForMainImageTypeIds = Arrays.asList(mainImageType.getId());
		imageAssociation.setPreferForMainImageTypeIds(preferForMainImageTypeIds);
		ImageAssociation association = this.imageAssociationClient.create(imageAssociation);
		this.imageAssociationClient.delete(association.getId());
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] {
			new DataServiceField(ImageAssociationField.isDefault, false),
			new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, new ArrayList<URI>()),
			// merlinResourceType default to leastVisible(entity, image)
			new DataServiceField(ImageAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable) };

	@Test(groups = { TestGroup.gbTest })
	public void testImageAssociationCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(imageAssociationClient, imageAssociationFactory.create(),
				ImageAssociationComparator.class, this.defaultValues, new DataServiceField[] { new DataServiceField(
						ImageAssociationField.preferForMainImageTypes, new ArrayList<String>()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testImageAssociationCreateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(imageAssociationClient, imageAssociationFactory.create(),
				ImageAssociationComparator.class, this.defaultValues, new DataServiceField[] { new DataServiceField(
						ImageAssociationField.preferForMainImageTypes, new ArrayList<String>()) });
	}

	@Test(groups = { TestGroup.gbTest })
	public void testImageAssociationUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		Feed<MainImageType> mainImageTypes = mainImageTypeClient.create(mainImageTypeFactory.create(2), new String[] {});

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ImageAssociationField.isDefault, true));
		createValues.add(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypes.getEntries().get(0).getId(),
				mainImageTypes.getEntries().get(1).getId())));
		createValues.add(new DataServiceField(ImageAssociationField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(
				imageAssociationClient,
				imageAssociationFactory.create(),
				ImageAssociationComparator.class,
				defaultValues,
				createValues.toArray(new DataServiceField[] {}),
				new DataServiceField[] {
						new DataServiceField(ImageAssociationField.preferForMainImageTypes, Arrays.asList(mainImageTypes.getEntries().get(0).getTitle(),
								mainImageTypes.getEntries().get(1).getTitle())),
						new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypes.getEntries().get(0).getId(),
								mainImageTypes.getEntries().get(1).getId())) });
	}

	@Test(groups = TestGroup.gbTest)
	public void testImageAssociationUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		Feed<MainImageType> mainImageTypes = mainImageTypeClient.create(mainImageTypeFactory.create(2), new String[] {});

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ImageAssociationField.isDefault, true));
		createValues.add(new DataServiceField(ImageAssociationField.preferForMainImageTypeIds, Arrays.asList(mainImageTypes.getEntries().get(0).getId(),
				mainImageTypes.getEntries().get(1).getId())));
		createValues.add(new DataServiceField(ImageAssociationField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(
				imageAssociationClient,
				imageAssociationFactory.create(),
				ImageAssociationComparator.class,
				defaultValues,
				createValues.toArray(new DataServiceField[] {}),
				null);
	}

}
