package com.theplatform.data.tv.entity.integration.test.endpoint.review;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.fields.ReviewField;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.OverrideField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Review;
import com.theplatform.data.tv.entity.api.test.ReviewComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;

/**
 * 
 * @author jethrolai
 * @since 11/4/2011
 */
@Test(groups = { "review", "sort", TestGroup.gbTest })
public class ReviewSortIT extends EntityTestBase {

    @DataProvider
    public Object[][] invalidSorts() {
        List<Object[]> argumentList = new ArrayList<Object[]>();
        argumentList.add(new Object[] { new Sort("summary", false) });
        argumentList.add(new Object[] { new Sort("description", false) });
        argumentList.add(new Object[] { new Sort("review", false) });
        argumentList.add(new Object[] { new Sort("recommendation", false) });
        argumentList.add(new Object[] { new Sort("starRating", false) });
        argumentList.add(new Object[] { new Sort("source", false) });
        argumentList.add(new Object[] { new Sort("contentRatings", false) });

        Object[][] argumentSet = new Object[argumentList.size()][];
        argumentList.toArray(argumentSet);
        return argumentSet;
    }

    @Test(dataProvider = "invalidSorts", expectedExceptions = BadParameterException.class)
    public void testReviewSortByNonSortableField(Sort invalidSort) throws Exception {
        this.reviewClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { invalidSort }, null, false);
    }

    public void testReviewSortById() throws Exception {
        List<Review> entities = this.reviewFactory.create(5);
        Feed<Review> retrievedEntities = this.reviewClient.create(entities, (String[]) null);
        List<Review> expectedEntities = sortById(retrievedEntities.getEntries());
        Feed<Review> actuals = this.reviewClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { new Sort("id", false) }, null, false);
        ReviewComparator.assertEquals(actuals, expectedEntities);
    }

    public void testReviewSortByGuid() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, Exception {
        testReviewSortByValidSort(getReviewWithDifferentGuid(), new Sort("guid", false));
    }

    public void testReviewSortByProgramId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, Exception {
        testReviewSortByValidSort(getReviewWithDifferentProgramId(), new Sort("programId", false));
    }

    public void testReviewSortByProvider() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
            ClassNotFoundException, InstantiationException, NoSuchMethodException, Exception {
        testReviewSortByValidSort(getReviewWithDifferentProvider(), new Sort("Provider", false));
    }

    private List<Review> getReviewWithDifferentGuid() throws Exception {
        List<Review> entities = new ArrayList<Review>();
        entities.add(this.reviewFactory.create(new DataServiceField(DataObjectField.guid, "A")));
        entities.add(this.reviewFactory.create(new DataServiceField(DataObjectField.guid, "B")));
        entities.add(this.reviewFactory.create(new DataServiceField(DataObjectField.guid, "C")));
        entities.add(this.reviewFactory.create(new DataServiceField(DataObjectField.guid, "D")));
        return entities;
    }

    private List<Review> getReviewWithDifferentProgramId() throws Exception {
        return this.reviewFactory.create(4);
    }

    private List<Review> getReviewWithDifferentProvider() throws Exception {
        List<Review> entities = new ArrayList<Review>();
        entities.add(this.reviewFactory.create(new DataServiceField(ReviewField.provider, "columbia")));
        entities.add(this.reviewFactory.create(new DataServiceField(ReviewField.provider, "fiji")));

        return entities;
    }

    private void testReviewSortByValidSort(List<Review> entities, Sort sort) throws IllegalArgumentException, SecurityException, IllegalAccessException,
            InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException {

        List<Review> createdEntities = this.reviewClient.create(entities).getEntries();
        for (int i = 0; i < entities.size(); i++) {
            entities.get(i).setId(createdEntities.get(i).getId());
        }
        Feed<Review> actuals = this.reviewClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { sort }, null, false);
        ReviewComparator.assertEquals(actuals, entities);
    }

    private class ComparableDataObject implements Comparable<ComparableDataObject> {

        private Review dataObject;

        public ComparableDataObject(Review dataObject) {
            super();
            this.dataObject = dataObject;
        }

        @Override
        public int compareTo(ComparableDataObject target) {
            return (int) (URIUtils.getIdValue(dataObject.getId()) - (URIUtils.getIdValue(target.getDataObject().getId())));
        }

        public Review getDataObject() {
            return dataObject;
        }

        public void setDataObject(Review dataObject) {
            this.dataObject = dataObject;
        }

    }

    private List<Review> sortById(List<Review> entities) {
        List<ComparableDataObject> entitiesToSort = new LinkedList<ComparableDataObject>();
        for (Review dataObject : entities) {
            entitiesToSort.add(new ComparableDataObject(dataObject));
        }
        Collections.sort(entitiesToSort);

        entities.clear();

        for (ComparableDataObject comparableDataObject : entitiesToSort) {
            entities.add(comparableDataObject.getDataObject());
        }
        return entities;
    }
}
