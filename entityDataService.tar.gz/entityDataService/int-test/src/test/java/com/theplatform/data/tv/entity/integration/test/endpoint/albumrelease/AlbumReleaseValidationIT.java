package com.theplatform.data.tv.entity.integration.test.endpoint.albumrelease;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;

import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseField;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.TestNGDataProviderUtil;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "albumRelease", "validation" })
public class AlbumReleaseValidationIT extends EntityTestBase {

	@Test(dataProvider = "validProductForms")
	public void testAlbumReleaseCreateValidProductForm(String validProductForm) throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.productForm, validProductForm)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseCreateInvalidProductForm() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.productForm, "")));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.productForm, "safd")));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.productForm, "SINGLE")));
	}

	@DataProvider
	public Object[][] validProductForms() {
		return TestNGDataProviderUtil.generateDataProvider(new Object[] { "Single" }, new Object[] { "EP" }, new Object[] { "Maxi-Single" },
				new Object[] { "Album" }, new Object[] { "Ringle" }, new Object[] { null });
	}

	@Test(dataProvider = "validSoundTypes")
	public void testAlbumReleaseCreateValidSoundType(String validSoundType) throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.soundType, validSoundType)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseCreateInvalidSoundType() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.soundType, "")));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.soundType, "asdf")));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.soundType, "MIXED")));
	}

	@DataProvider
	public Object[][] validSoundTypes() {
		return TestNGDataProviderUtil.generateDataProvider(new Object[] { "Remastered" }, new Object[] { "Mixed" }, new Object[] { "Stereo" },
				new Object[] { "Mono" }, new Object[] { "Unknown" }, new Object[] { "Multichannel" }, new Object[] { null });
	}

	@Test(dataProvider = "validDomesticImports")
	public void testAlbumReleaseCreateValidDomesticImport(String validDomesticImport) throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.domesticImport, validDomesticImport)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseCreateInvalidDomesticImport() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.domesticImport, "")));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.domesticImport, "asdf")));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.domesticImport, "IMPORT")));
	}

	@DataProvider
	public Object[][] validDomesticImports() {
		return TestNGDataProviderUtil.generateDataProvider(new Object[] { "Domestic" }, new Object[] { "Import" }, new Object[] { null });
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseCreateDurationLessThanZero() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.duration, -1)));
	}

	public void testAlbumReleaseCreateDurationMoreThanZero() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.duration, 1)));
	}

	@Test(groups = TestGroup.testBug)
	public void testAlbumReleaseCreateDurationEqualToZero() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.duration, 0)));
	}

	@Test(groups = TestGroup.testBug, expectedExceptions = ValidationException.class)
	public void testAlbumReleaseCreateNullAlbumId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId, null)));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseCreateNonpersistedAlbumId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.albumId,this.albumFactory.create().getId())));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testAlbumReleaseCreateNonLocalAlbumId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localAlbumId = this.albumClient.create(this.albumFactory.create()).getId();

		this.albumReleaseClient.create(this.albumReleaseFactory.create(AlbumReleaseField.albumId, this.albumFactory.create(
                new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9003/linearDataService/data/Album/" + URIUtils.getIdValue(localAlbumId)))).getId()));
	}

	public void testAlbumReleaseCreateNullContentRatings() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.contentRatings, null)));
    }

	public void testAlbumReleaseCreateEmptyContentRatings() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.contentRatings, new ArrayList<Rating>())));
	}

	@Test(groups = TestGroup.testBug, dataProvider = "validContentRatings")
	public void testAlbumReleaseCreateValidContentRatings(Rating validContentRating) throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.contentRatings, Arrays.asList(validContentRating))));
	}

	@DataProvider
	public Object[][] validContentRatings() {

		Rating validMpaaRating = new Rating();
		validMpaaRating.setScheme("urn:mpaa");
		Rating validVChipRating = new Rating();
		validVChipRating.setScheme("urn:v-chip");
		Rating validCsmRating = new Rating();
		validCsmRating.setScheme("urn:csm");
		Rating validRiaaRating = new Rating();
		validRiaaRating.setScheme("urn:riaa");
		validRiaaRating.setRating("true");

		return TestNGDataProviderUtil.generateDataProvider(new Object[] { validMpaaRating }, new Object[] { validVChipRating },
				new Object[] { validCsmRating }, new Object[] { validRiaaRating });
	}

	@Test(groups = TestGroup.testBug, dataProvider = "invalidContentRatings", expectedExceptions = ValidationException.class)
	public void testAlbumReleaseCreateInvalidContentRatings(Rating invalidContentRating) throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.contentRatings, Arrays.asList(invalidContentRating))));
	}

	@DataProvider
	public Object[][] invalidContentRatings() {

		Rating invalidRatingScheme1 = new Rating();
		invalidRatingScheme1.setScheme("urn:mpaa2");
		Rating invalidRatingScheme2 = new Rating();
		invalidRatingScheme2.setScheme("URN:MPAA");
		Rating invalidRatingRiaa1 = new Rating();
		invalidRatingRiaa1.setScheme("urn:riaa");
		invalidRatingRiaa1.setRating("not boolean");
		Rating invalidRatingRiaa2 = new Rating();
		invalidRatingRiaa2.setScheme("urn:riaa");
		invalidRatingRiaa2.setRating(null);

		return TestNGDataProviderUtil.generateDataProvider(new Object[] { invalidRatingScheme1 }, new Object[] { invalidRatingScheme2 },
				new Object[] { invalidRatingRiaa1 }, new Object[] { invalidRatingRiaa2 });
	}

}
