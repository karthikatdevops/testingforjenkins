package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.ProgramTeamAssociationField;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.QueryType;
import com.theplatform.contrib.service.converter.UriToLongConverter;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.query.program.ByLocal;
import com.theplatform.data.tv.entity.api.client.query.program.BySportsTeamId;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
@Deprecated
@Test(groups = { "program", "query" })
public class ProgramQueryNonEditorialIT extends EntityTestBase {

	private static final Sort SORT_BY_ID_ASC[] = new Sort[] { new Sort("id", false) };
	private static final List<Program> EMPTY_PROGRAM_FEED = new ArrayList<>();


	@Test(groups = TestGroup.testBug)
	public void testGetProgramsByLocal() {
		List<Program> programs = this.programFactory.create(6);
		// Possible values for local
		programs.get(0).setLocal(true);
		programs.get(1).setLocal(false);
		programs.get(2).setLocal(null); // will default to false after persisted
		programs.get(3).setLocal(true);
		programs.get(4).setLocal(false);
		programs.get(5).setLocal(null); // will default to false after persisted

		this.programClient.create(programs);

		/*
		 * We need to set expectations; even though local was null for these
		 * programs, they default to false so we want to set that explicitly on
		 * the expected programs.
		 */
		programs.get(2).setLocal(false); // will default to false after
											// persisted
		programs.get(5).setLocal(false); // will default to false after
											// persisted

		Feed<Program> retrievedPrograms = null;
		List<Program> expectedPrograms = null;

		// Query ByLocal=true should only return those that are created as true
		retrievedPrograms = this.programClient.getAll(null, new Query[] { new ByLocal(true) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = Arrays.asList(programs.get(0), programs.get(3));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		// Query ByLocal=false should return those that are created as false or
		// null
		retrievedPrograms = this.programClient.getAll(null, new Query[] { new ByLocal(false) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = Arrays.asList(programs.get(1), programs.get(2), programs.get(4), programs.get(5));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);
	}

	@Test(groups = { "other" })
	public void testGetProgramsBySportsTeamId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		List<Program> programs = this.programFactory.create(4, new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		this.programClient.create(programs);

		List<SportsTeam> sportsTeams = this.sportsTeamFactory.create(3);
		this.sportsTeamClient.create(sportsTeams);

		// Populate an array of SportsTeamId longs so it's easier to generate
		// queries using the long identifiers later
		Long[] teamIds = new Long[sportsTeams.size()];
		int index = 0;
		for (SportsTeam sportsTeam : sportsTeams) {
			teamIds[index] = UriToLongConverter.convertUriToID(sportsTeam.getId());
			index++;
		}

		// programs(0) no sportsTeamAssociations

		// programs(1)
		ProgramTeamAssociation pta1 = this.programTeamAssociationFactory.create(new DataServiceField(ProgramTeamAssociationField.programId, programs.get(1).getId()),
				new DataServiceField(ProgramTeamAssociationField.sportsTeamId, sportsTeams.get(0).getId()));
		this.programTeamAssociationClient.create(pta1);

		// programs(2)
		this.programTeamAssociationClient.create(this.programTeamAssociationFactory.create(new DataServiceField(ProgramTeamAssociationField.programId, programs.get(2).getId()),
				new DataServiceField(ProgramTeamAssociationField.sportsTeamId, sportsTeams.get(0).getId())));
		this.programTeamAssociationClient.create(this.programTeamAssociationFactory.create(new DataServiceField(ProgramTeamAssociationField.programId, programs.get(2).getId()), new DataServiceField(ProgramTeamAssociationField.sportsTeamId, sportsTeams.get(1).getId())));

		// programs(3)
		this.programTeamAssociationClient.create(this.programTeamAssociationFactory.create(new DataServiceField(ProgramTeamAssociationField.programId, programs.get(3).getId()), new DataServiceField(ProgramTeamAssociationField.sportsTeamId, sportsTeams.get(0).getId())));
		this.programTeamAssociationClient.create(this.programTeamAssociationFactory.create(new DataServiceField(ProgramTeamAssociationField.programId, programs.get(3).getId()), new DataServiceField(ProgramTeamAssociationField.sportsTeamId, sportsTeams.get(1).getId())));
		this.programTeamAssociationClient.create(this.programTeamAssociationFactory.create(new DataServiceField(ProgramTeamAssociationField.programId, programs.get(3).getId()), new DataServiceField(ProgramTeamAssociationField.sportsTeamId, sportsTeams.get(2).getId())));

		Feed<Program> retrievedPrograms = null;
		List<Program> expectedPrograms = null;

		// Query for 1 programId
		retrievedPrograms = this.programClient.getAll(null, new Query[] { new BySportsTeamId(99999l) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = EMPTY_PROGRAM_FEED;
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		retrievedPrograms = this.programClient.getAll(null, new Query[] { new BySportsTeamId(teamIds[0]) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = Arrays.asList(programs.get(1), programs.get(2), programs.get(3));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		retrievedPrograms = this.programClient.getAll(null, new Query[] { new BySportsTeamId(teamIds[1]) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = Arrays.asList(programs.get(2), programs.get(3));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		retrievedPrograms = this.programClient.getAll(null, new Query[] { new BySportsTeamId(teamIds[2]) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = Arrays.asList(programs.get(3));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		// AND Query for 2 programIds
		retrievedPrograms = this.programClient.getAll(null, new Query[] { new BySportsTeamId(Arrays.asList(new Long[] { teamIds[0], teamIds[1] }),
				QueryType.AND) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = Arrays.asList(programs.get(2), programs.get(3));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		retrievedPrograms = this.programClient.getAll(null, new Query[] { new BySportsTeamId(Arrays.asList(new Long[] { teamIds[0], teamIds[2] }),
				QueryType.AND) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = Arrays.asList(programs.get(3));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		// OR Query for 2 programIds
		retrievedPrograms = this.programClient.getAll(null,
				new Query[] { new BySportsTeamId(Arrays.asList(new Long[] { teamIds[1], teamIds[2] }), QueryType.OR) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = Arrays.asList(programs.get(2), programs.get(3));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		// AND Query for 3 programIds
		retrievedPrograms = this.programClient.getAll(null, new Query[] { new BySportsTeamId(Arrays.asList(new Long[] { teamIds[0], teamIds[1], teamIds[2] }),
				QueryType.AND) }, SORT_BY_ID_ASC, null, true);
		expectedPrograms = Arrays.asList(programs.get(3));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);
	}
}
