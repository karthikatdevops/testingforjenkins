package com.theplatform.data.tv.entity.integration.test.endpoint.entitycollection;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.client.ClientUtils;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollectionMetadataManagementInfo;
import com.theplatform.data.tv.entity.api.test.EntityCollectionMetadataManagementInfoComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * Tests for the {@link EntityCollectionMetadataManagementInfo} specific
 * behavior.
 * 
 * @author gservente
 * 
 */
@Test(groups = { "entityCollection", TestGroup.gbTest})
public class EntityCollectionMmiIT extends EntityTestBase {

	public void testEntityCollectionCreateWithAnEcmmi() {
		EntityCollectionMetadataManagementInfo ecMmi = new EntityCollectionMetadataManagementInfo();
		List<URI> entitiesIdToAppend = Arrays.asList(URI.create(this.programClient.getRequestUrl() + "/1111"),
				URI.create(this.programClient.getRequestUrl() + "/3333"));
		List<URI> entitiesIdToRemove = Arrays.asList(URI.create(this.programClient.getRequestUrl() + "/2222"));
		HashMap<String, URI> primaryEntitiesToAppend = new HashMap<>();
		primaryEntitiesToAppend.put("Content", URI.create(this.programClient.getRequestUrl() + "/4444"));
		List<String> primaryEntitiesToRemove = Arrays.asList("Language");

		ecMmi.setAppendEntityIds(entitiesIdToAppend);
		ecMmi.setRemoveEntityIds(entitiesIdToRemove);
		ecMmi.setAppendPrimaryEntities(primaryEntitiesToAppend);
		ecMmi.setRemovePrimaryEntities(primaryEntitiesToRemove);

		EntityCollection ec = entityCollectionFactory.create();
		ec.setMetadataManagementInfo(ecMmi);
		EntityCollection createdEc = this.entityCollectionClient.create(ec, new String[]{});
		EntityCollectionMetadataManagementInfoComparator.assertEquals(createdEc.getMetadataManagementInfo(), ecMmi);
	}

	public void testEntityCollectionUpdateWithAnEcmmi() {
		EntityCollectionMetadataManagementInfo ecMmi = new EntityCollectionMetadataManagementInfo();
		List<URI> entitiesIdToAppend = Arrays.asList(URI.create(this.programClient.getRequestUrl() + "/1111"),
				URI.create(this.programClient.getRequestUrl() + "/3333"));
		List<URI> entitiesIdToRemove = Arrays.asList(URI.create(this.programClient.getRequestUrl() + "/2222"));
		HashMap<String, URI> primaryEntitiesToAppend = new HashMap<>();
		primaryEntitiesToAppend.put("Content", URI.create(this.programClient.getRequestUrl() + "/4444"));
		List<String> primaryEntitiesToRemove = Arrays.asList("Language");

		ecMmi.setAppendEntityIds(entitiesIdToAppend);
		ecMmi.setRemoveEntityIds(entitiesIdToRemove);
		ecMmi.setAppendPrimaryEntities(primaryEntitiesToAppend);
		ecMmi.setRemovePrimaryEntities(primaryEntitiesToRemove);

		EntityCollection ec = entityCollectionFactory.create();
		ec.setMetadataManagementInfo(ecMmi);
		EntityCollection createdEc = this.entityCollectionClient.create(ec, ClientUtils.ALL_FIELDS);
		EntityCollectionMetadataManagementInfoComparator.assertEquals(createdEc.getMetadataManagementInfo(), ecMmi);

		primaryEntitiesToRemove = Arrays.asList("Language", "Content");
		ecMmi.setRemovePrimaryEntities(primaryEntitiesToRemove);
		createdEc.setMetadataManagementInfo(ecMmi);

		EntityCollection updatedEc = this.entityCollectionClient.update(createdEc, ClientUtils.ALL_FIELDS);
		EntityCollectionMetadataManagementInfoComparator.assertEquals(updatedEc.getMetadataManagementInfo(), ecMmi);
	}
}
