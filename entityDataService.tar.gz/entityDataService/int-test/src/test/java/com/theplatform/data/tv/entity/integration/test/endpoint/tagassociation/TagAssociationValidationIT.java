package com.theplatform.data.tv.entity.integration.test.endpoint.tagassociation;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;

import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.client.query.ByGuid;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author jethrolai
 * 
 */
@Test(groups = { "tagAssociation", "validation", TestGroup.gbTest })
public class TagAssociationValidationIT extends EntityTestBase {

	@Test(expectedExceptions = ValidationException.class)
	public void testTagAssociationValidationCreateWithNonPersistedProgram() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, this.programFactory.create().getId())));
	}

	public void testTagAssociationValidationCreateWithValidProgram() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, this.programClient.create(
				this.programFactory.create()).getId())));
	}

	public void testTagAssociationValidationCreateDeleteProgramBeforeDeletingTagAssociation() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI programId = this.programClient.create(this.programFactory.create()).getId();
		String tagAssociationGuid = this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, programId)),
				new String[] { "guid" }).getGuid();
		this.programClient.delete(programId);
		try {
			this.programClient.get(programId, new String[] {});
			Assert.fail("Failed to delete Program");
		} catch (ObjectNotFoundException onf) {
			// program has been deleted.
			Assert.assertEquals(
					(long) this.tagAssociationClient.getAll(null, new Query[] { new ByGuid(tagAssociationGuid) }, null, null, true).getEntryCount(), 0);
		}

	}

	public void testTagAssociationValidationCreateDeleteProgramAfterDeletingTagAssociation() throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI programId = this.programClient.create(this.programFactory.create()).getId();
		URI tagAssociationId = this.tagAssociationClient.create(this.tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId, programId))).getId();
		this.tagAssociationClient.delete(tagAssociationId);
		this.programClient.delete(programId);

	}
	
	
	
	@Test(expectedExceptions = ValidationException.class, groups = { "core", "SprintS" })
	public void testTagAssociationValidationNegativeRank() {
		TagAssociation tagAssociation = tagAssociationFactory.create();
		tagAssociation.setRank(-1);
		// CREATE
		this.tagAssociationClient.create(tagAssociation);
	}

	
	@Test(expectedExceptions = ValidationException.class, groups = { "core", "SprintS" })
	public void testTagAssociationValidationZeroRank() {
		TagAssociation tagAssociation = tagAssociationFactory.create();
		tagAssociation.setRank(0);
		// CREATE
		this.tagAssociationClient.create(tagAssociation);
	}

	
	@Test( groups = { "core", "SprintS" })
	public void testTagAssociationValidationPositiveRank() {
		TagAssociation tagAssociation = tagAssociationFactory.create();
		tagAssociation.setRank(1);
		// CREATE
		this.tagAssociationClient.create(tagAssociation);
	}

	@Test( groups = { "core", "SprintS" })
	public void testTagAssociationValidationNullRank() {
		TagAssociation tagAssociation = tagAssociationFactory.create();
		tagAssociation.setRank(null);
		// CREATE
		this.tagAssociationClient.create(tagAssociation);
	}

}
