package com.theplatform.data.tv.entity.integration.test.endpoint.review;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.theplatform.data.tv.entity.api.fields.ProgramField;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.data.objects.Review;
import com.theplatform.data.tv.entity.api.fields.ReviewField;
import com.theplatform.data.tv.entity.api.test.ReviewComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.media.api.data.objects.Rating;

@Test(groups = { "review", "crud" })
public class ReviewCRUDIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest })
	public void crudSingleReview() throws UnknownHostException {
		Review entity = this.reviewFactory.create();

		// CREATE & RETRIEVE
		Review reviewCreated = this.reviewClient.create(entity, new String[] {});
		entity.setId(reviewCreated.getId());
		ReviewComparator.assertEquals(reviewCreated, entity);
		ReviewComparator.assertEquals(this.reviewClient.get(entity.getId(), null), entity);

		// UPDATE
		entity.setProgramId(this.programClient.create(this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie))).getId());
		entity.setProvider(entity.getProvider().concat(" updated"));
		entity.setSummary(entity.getSummary().concat(" updated"));
		entity.setDescription(entity.getDescription().concat(" updated"));
		entity.setReview(entity.getReview().concat(" updated"));
		entity.setRecommendation(entity.getRecommendation().concat(" updated"));
		entity.setStarRating(entity.getStarRating() + 1);
		entity.setSource(entity.getSource().concat(" update"));
		Rating newRating = new Rating();
		newRating.setScheme("urn:csm");
		newRating.setRating("notForKids=0,targetAge=6,offAge=4,onAge=6,rating=on");
		entity.getContentRatings().add(newRating);
		this.reviewClient.update(entity);

		ReviewComparator.assertEquals(this.reviewClient.get(entity.getId(), null), entity);

		// DELETE
		long deletedObjects = this.reviewClient.delete(entity.getId());
		Assert.assertEquals(deletedObjects, 1);

		try {
			this.reviewClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		Assert.fail("Review:".concat(entity.getId().toString()).concat("should not be found after deleting it"));
	}

	@Test(groups = { "other" })
	public void crudReviewFeed() throws UnknownHostException {
		List<Review> entities = this.reviewFactory.create(3);

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] entityIds = (URI[]) CollectionUtils.collect(entities, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		this.reviewClient.create(entities);

		// RETRIEVE
		Feed<Review> retrievedEntities = this.reviewClient.get(entityIds, new String[] {});
		ReviewComparator.assertEquals(retrievedEntities, entities);

		// DELETE
		long deletedEntities = this.reviewClient.delete(entityIds);
		Assert.assertEquals(deletedEntities, entities.size());

		long notFoundEntities = 0;
		for (Review entity : entities) {
			try {
				this.reviewClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntities++;
			}
		}
		Assert.assertEquals(notFoundEntities, deletedEntities, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testReviewDefaultFieldValue() throws UnknownHostException {
		Review entity = this.reviewFactory.create();
		entity.setSummary(null);
		entity.setDescription(null);
		entity.setReview(null);
		entity.setRecommendation(null);
		entity.setStarRating(null);
		entity.setSource(null);
		entity.setContentRatings(null);

		URI entityId = this.reviewClient.create(entity).getId();
		entity.setId(entityId);
		ReviewComparator.assertEquals(this.reviewClient.get(entityId, null), entity);
	}

	private final DataServiceField[] defaultValues = new DataServiceField[] { new DataServiceField(ReviewField.summary, null),
			new DataServiceField(DataObjectField.description, null), new DataServiceField(ReviewField.review, null),
			new DataServiceField(ReviewField.recommendation, null), new DataServiceField(ReviewField.starRating, null),
			new DataServiceField(ReviewField.source, null), new DataServiceField(ReviewField.contentRatings, new ArrayList<Rating>()), };

	@Test(groups = { TestGroup.gbTest })
	public void testReviewCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {

		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(reviewClient, reviewFactory.create(), ReviewComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testReviewCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(reviewClient, reviewFactory.create(), ReviewComparator.class, this.defaultValues, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testReviewUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException {
		Rating rating = new Rating();
		 rating.setScheme("urn:mpaa");
		 rating.setRating("rating");
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ReviewField.summary, "review summary"));
		createValues.add(new DataServiceField(DataObjectField.description, "review description"));
		createValues.add(new DataServiceField(ReviewField.review, "review review"));
		createValues.add(new DataServiceField(ReviewField.recommendation, "review recommendation"));
		createValues.add(new DataServiceField(ReviewField.starRating, 3));
		createValues.add(new DataServiceField(ReviewField.source, "review source"));
		createValues.add(new DataServiceField(ReviewField.contentRatings, Arrays.asList(rating)));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(reviewClient, reviewFactory.create(), ReviewComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testReviewUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(ReviewField.summary, "review summary"));
		createValues.add(new DataServiceField(DataObjectField.description, "review description"));
		createValues.add(new DataServiceField(ReviewField.review, "review review"));
		createValues.add(new DataServiceField(ReviewField.recommendation, "review recommendation"));
		createValues.add(new DataServiceField(ReviewField.starRating, 3));
		createValues.add(new DataServiceField(ReviewField.source, "review source"));
		createValues.add(new DataServiceField(ReviewField.contentRatings, Arrays.asList(new Rating())));

		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(reviewClient, reviewFactory.create(), ReviewComparator.class, defaultValues,
				createValues.toArray(new DataServiceField[] {}), null);

	}

}
