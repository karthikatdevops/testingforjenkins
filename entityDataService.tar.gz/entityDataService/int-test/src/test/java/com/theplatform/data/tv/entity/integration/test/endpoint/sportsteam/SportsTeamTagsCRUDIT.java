package com.theplatform.data.tv.entity.integration.test.endpoint.sportsteam;

import com.theplatform.contrib.testing.factory.decorator.PersistingDataObjectFactoryDecorator;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.util.MerlinUriUtil;
import com.theplatform.data.api.client.RequestParameters;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.TagClient;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.fields.SportsTeamField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static org.testng.Assert.*;

/**
 * @author jcoelho
 * @since 1/11/16.
 */
@Test(groups = {"sportsTeam"})
public class SportsTeamTagsCRUDIT extends EntityTestBase {

    private PersistingDataObjectFactoryDecorator<Tag, TagClient> persistingTagFactory;

    private PersistingDataObjectFactoryDecorator<Tag, TagClient> getPersistingTagFactory() {
        if(persistingTagFactory == null) {
            persistingTagFactory = new PersistingDataObjectFactoryDecorator<>(tagFactory);
        }

        return persistingTagFactory;
    }

    @Test(groups = {TestGroup.gbTest})
    public void crudSingleTag() throws UnknownHostException {
        // Create SportsTeam and Tag and then attempt to associate the two
        SportsTeam sportsTeam = sportsTeamFactory.create();
        sportsTeamClient.create(sportsTeam);

        List<Tag> tags = getPersistingTagFactory().create(2);

        TagAssociation inputTagAssociation = new TagAssociation();
        inputTagAssociation.setEntityId(sportsTeam.getId());
        inputTagAssociation.setTagId(tags.get(0).getId());
        inputTagAssociation = tagAssociationClient.create(inputTagAssociation, new String[]{});

        // Retrieve and confirm that the SportsTeam has a tag
        sportsTeamClient.update(sportsTeam);
        SportsTeam retrievedSportsTeam = sportsTeamClient.get(sportsTeam.getId(), new String[]{SportsTeamField.tagIds.getLocalName()});
        assertEquals(retrievedSportsTeam.getTagIds().size(), 1);
        assertEquals(tags.get(0).getId(), retrievedSportsTeam.getTagIds().get(0));

        // Retrieve TA and confirm there is one of it
        TagAssociation retrievedInputTagAssociation = tagAssociationClient.get(inputTagAssociation.getId(), new String[]{});
        assertEquals(inputTagAssociation.getEntityId(), retrievedInputTagAssociation.getEntityId());

        // UPDATE tag association (with new tag) & sportsTeam both and retrieve sportsTeam
        inputTagAssociation.setTagId(tags.get(1).getId());
        tagAssociationClient.update(inputTagAssociation);
        sportsTeamClient.update(sportsTeam);
        SportsTeam retrieveAfterUpdateOnce = sportsTeamClient.get(sportsTeam.getId(), new String[]{SportsTeamField.tagIds.getLocalName()});
        assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 1, "Updated SportsTeam has one Tag");
        assertEquals(tags.get(1).getId(), retrieveAfterUpdateOnce.getTagIds().get(0));

        // DELETE tag, update sportsTeam & retrieve sportsTeam
        tagAssociationClient.delete(inputTagAssociation.getId());
        sportsTeamClient.update(sportsTeam);
        SportsTeam retrieveAfterUpdateAgain = sportsTeamClient.get(sportsTeam.getId(), new String[]{});
        assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0, "Updated SportsTeam has no Tag");

        delete(sportsTeam);
    }

    /**
     * 1 ) Create SportsTeam 2 ) Get SportsTeam; validate that doesn't have any tags 3
     * ) Create Tag 4 ) Create Tag Association which link to tag & SportsTeam 5 )
     * Get SportsTeam; validate that it has correct Tag Association 6 ) Update tag
     * 7 ) Update tag association 8 ) Get SportsTeam; validate that it has updated
     * Tag Association 9 ) Delete Tag Association 10) Get SportsTeam; validate that
     * doesn't have any Tag Association
     *
     * @throws UnknownHostException Exception
     */
    @Test(groups = {TestGroup.gbTest})
    public void crudSingleCachingTag() throws UnknownHostException {
        // Create SportsTeam
        SportsTeam sportsTeam = sportsTeamFactory.create();
        sportsTeamClient.create(sportsTeam);
        // RETRIEVE
        SportsTeam retrievedSportsTeamOnce = sportsTeamClient.get(sportsTeam.getId(), new String[]{SportsTeamField.tagIds.getLocalName()});
        assertEquals(retrievedSportsTeamOnce.getTagIds().size(), 0);
        // Create Association
        Tag tag = getPersistingTagFactory().create();
        TagAssociation inputTagAssociation = getSportsTeamTagAssociationFactory().create();
        inputTagAssociation.setEntityId(sportsTeam.getId());
        inputTagAssociation.setTagId(tag.getId());
        tagAssociationClient.create(inputTagAssociation);

        sportsTeamClient.update(sportsTeam);
        // RETRIEVE
        SportsTeam retrievedSportsTeamAgain = sportsTeamClient.get(sportsTeam.getId(), new String[]{SportsTeamField.tagIds.getLocalName()});
        assertEquals(retrievedSportsTeamAgain.getTagIds().size(), 1);
        assertEquals(tag.getId(), retrievedSportsTeamAgain.getTagIds().get(0));

        // UPDATE tag association & sportsTeam both and retrieve sportsTeam
        tag = tagFactory.create();
        tagClient.create(tag);
        inputTagAssociation.setTagId(tag.getId());
        tagAssociationClient.update(inputTagAssociation);
        sportsTeamClient.update(sportsTeam);
        SportsTeam retrieveAfterUpdateOnce = sportsTeamClient.get(sportsTeam.getId(), new String[]{SportsTeamField.tagIds.getLocalName()});
        assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 1);
        assertEquals(tag.getId(), retrieveAfterUpdateOnce.getTagIds().get(0));

        // DELETE tag, update sportsTeam & retrieve sportsTeam
        tagAssociationClient.delete(inputTagAssociation.getId());
        sportsTeamClient.update(sportsTeam);
        SportsTeam retrieveAfterUpdateAgain = sportsTeamClient.get(sportsTeam.getId(), new String[]{SportsTeamField.tagIds.getLocalName()});
        assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0);

        delete(sportsTeam);
    }

    /**
     * 1 ) Create SportsTeam 2 ) Get SportsTeam; validate that doesn't have any tags 3
     * ) Create Tag Association which link to SportsTeam 4 ) Get SportsTeam; validate
     * that it has correct Tag Association 5 ) Update Tag Association 6 ) Get
     * SportsTeam; validate that it has updated Tag Association 7 ) Delete Tag
     * Association 8 ) Get SportsTeam; validate that doesn't have any Tag
     * Association
     *
     * @throws UnknownHostException Exception
     */
    @Test
    public void crudSingleCacheInvalidationTag() throws UnknownHostException {
        // Create SportsTeam
        SportsTeam inputSportsTeam = sportsTeamFactory.create();
        sportsTeamClient.create(inputSportsTeam);
        // RETRIEVE
        SportsTeam retrievedSportsTeamOnce = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
        assertEquals(retrievedSportsTeamOnce.getTagIds().size(), 0, "SportsTeam has no Tag");
        assertEquals(retrievedSportsTeamOnce.getVersion(), new Long("0"), "Before creating tags link to SportsTeam then version should be zero");

        // Create Association
        TagAssociation inputTagAssociation = getSportsTeamTagAssociationFactory().create();
        inputTagAssociation.setEntityId(inputSportsTeam.getId());
        tagAssociationClient.create(inputTagAssociation);
        // RETRIEVE
        SportsTeam retrievedSportsTeamAgain = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
        assertEquals(retrievedSportsTeamAgain.getTagIds().size(), 1, "Created SportsTeam has one Tag");
        assertEquals(inputTagAssociation.getTagId(), retrievedSportsTeamAgain.getTagIds().get(0));
        assertEquals(retrievedSportsTeamAgain.getVersion(), new Long("1"), "After created tags link to SportsTeam then version should be one");

        // UPDATE association & sportsTeam both and retrieve sportsTeam
        Tag tag = getPersistingTagFactory().create();
        inputTagAssociation.setTagId(tag.getId());
        tagAssociationClient.update(inputTagAssociation);
        SportsTeam retrieveAfterUpdateOnce = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
        assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 1, "Updated SportsTeam has one Tag");
        assertEquals(inputTagAssociation.getTagId(), retrieveAfterUpdateOnce.getTagIds().get(0));
        assertEquals(retrieveAfterUpdateOnce.getVersion(), new Long("2"), "After updating tags which link to SportsTeam then version should be two");

        // DELETE association & retrieve sportsTeam, the version should be bumped up
        tagAssociationClient.delete(inputTagAssociation.getId());
        SportsTeam retrieveAfterUpdateAgain = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
        assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0, "Updated SportsTeam has no Tag");

        delete(inputSportsTeam);
    }

    @Test
    public void crudCollectionOfTags() throws UnknownHostException {
        // Create SportsTeam
        SportsTeam inputSportsTeam = sportsTeamFactory.create();
        sportsTeamClient.create(inputSportsTeam);
        // RETRIEVE
        SportsTeam retrievedSportsTeamOnce = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
        assertEquals(retrievedSportsTeamOnce.getTagIds().size(), 0, "SportsTeam has no Tag");
        // Create Association
        List<Tag> inputTags = tagFactory.create(5);
        tagClient.create(inputTags);
        List<TagAssociation> inputTagAssociations = getSportsTeamTagAssociationFactory().create(5);
        @SuppressWarnings({"unchecked", "ToArrayCallWithZeroLengthArrayArgument"})
        URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[]{});
        for (int i = 0; i < 5; i++) {
            inputTagAssociations.get(i).setEntityId(inputSportsTeam.getId());
            inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());
        }
        tagAssociationClient.create(inputTagAssociations);
        // RETRIEVE
        sportsTeamClient.update(inputSportsTeam);
        SportsTeam retrievedSportsTeamAgain = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
        assertEquals(retrievedSportsTeamAgain.getTagIds().size(), 5, "Created SportsTeam has five Tags");
        for (int i = 0; i < 5; i++) {
            assertEquals(inputTags.get(i).getId(), retrievedSportsTeamAgain.getTagIds().get(i));
        }

        // UPDATE tag association & SportsTeam both and retrieve SportsTeam
        inputTags = tagFactory.create(5);
        tagClient.create(inputTags);
        for (int i = 0; i < 5; i++) {
            inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());
        }
        tagAssociationClient.update(inputTagAssociations);
        sportsTeamClient.update(inputSportsTeam);
        SportsTeam retrieveAfterUpdateOnce = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
        assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 5, "Updated SportsTeam has five Tag");
        for (int i = 0; i < 5; i++) {
            assertEquals(inputTags.get(i).getId(), retrieveAfterUpdateOnce.getTagIds().get(i));
        }

        // DELETE tag, update sportsTeam & retrieve sportsTeam
        tagAssociationClient.delete(tagAssociationIds);
        sportsTeamClient.update(inputSportsTeam);
        SportsTeam retrieveAfterUpdateAgain = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
        assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0, "Updated SportsTeam has no Tag");

        delete(inputSportsTeam);
    }

    @Test
    public void crudCollectionOfTagsCaching() throws UnknownHostException, InterruptedException {
        // Create SportsTeam
        SportsTeam sportsTeam = sportsTeamFactory.create();
        sportsTeamClient.create(sportsTeam);
        // RETRIEVE
        SportsTeam retrievedSportsTeamOnce = sportsTeamClient.get(sportsTeam.getId(), new String[]{SportsTeamField.tagIds.getLocalName()});
        assertEquals(retrievedSportsTeamOnce.getTagIds().size(), 0);

        sportsTeamClient.update(sportsTeam);
        // Create Association
        List<Tag> inputTags = tagFactory.create(5);
        tagClient.create(inputTags);
        List<TagAssociation> inputTagAssociations = getSportsTeamTagAssociationFactory().create(5);
        @SuppressWarnings({"unchecked"})
        URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[]{});
        for (int i = 0; i < 5; i++) {
            inputTagAssociations.get(i).setEntityId(sportsTeam.getId());
            inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());
        }
        tagAssociationClient.create(inputTagAssociations);

        sportsTeamClient.update(sportsTeam);
        // RETRIEVE
        SportsTeam retrievedSportsTeamAgain = sportsTeamClient.get(sportsTeam.getId(), new String[]{SportsTeamField.tagIds.getLocalName()});
        assertEquals(retrievedSportsTeamAgain.getTagIds().size(), 5);
        for (int i = 0; i < 5; i++)
            assertEquals(inputTags.get(i).getId(), retrievedSportsTeamAgain.getTagIds().get(i));

        // UPDATE tag association & sportsTeam both and retrieve sportsTeam
        inputTags = tagFactory.create(5);
        tagClient.create(inputTags);
        for (int i = 0; i < 5; i++)
            inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());

        tagAssociationClient.update(inputTagAssociations);
        sportsTeamClient.update(sportsTeam);

        SportsTeam retrieveAfterUpdateOnce = sportsTeamClient.get(sportsTeam.getId(), new String[]{});
        assertEquals(retrieveAfterUpdateOnce.getTagIds().size(), 5);
        sportsTeamClient.update(sportsTeam);
        for (int i = 0; i < 5; i++)
            assertEquals(inputTags.get(i).getId(), retrieveAfterUpdateOnce.getTagIds().get(i));

        // DELETE tag, update sportsTeam & retrieve sportsTeam
        tagAssociationClient.delete(tagAssociationIds);

        SportsTeam retrieveAfterUpdateAgain = sportsTeamClient.get(sportsTeam.getId(), new String[]{});
        assertEquals(retrieveAfterUpdateAgain.getTagIds().size(), 0);

        delete(sportsTeam);
    }

    @Test
    public void crudCollectionOfCacheInvalidationTags() throws UnknownHostException {
        // Create 3  SportsTeams and verify that they don't have any tags and the version is 0
        List<SportsTeam> inputSportsTeams = sportsTeamFactory.create(3);
        @SuppressWarnings({"unchecked", "ToArrayCallWithZeroLengthArrayArgument"})
        URI[] sportsTeamIds = (URI[]) CollectionUtils.collect(inputSportsTeams, TransformerUtils.invokerTransformer("getId")).toArray(new URI[]{});
        sportsTeamClient.create(inputSportsTeams);
        // RETRIEVE
        Feed<SportsTeam> retrievedSportsTeamOnce = sportsTeamClient.get(sportsTeamIds, new String[]{});
        retrievedSportsTeamOnce.getEntries().forEach((sportsTeam) -> {
            assertEquals(sportsTeam.getTagIds().size(), 0, "SportsTeam has no Tag");
            assertEquals(sportsTeam.getVersion(), new Long("0"), "Before creating tags link to SportsTeam, version should be zero");
        });

        // Create Association
        List<TagAssociation> inputTagAssociations = getSportsTeamTagAssociationFactory().create(3);
        @SuppressWarnings({"unchecked", "ToArrayCallWithZeroLengthArrayArgument"})
        URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[]{});

        inputTagAssociations.get(0).setEntityId(inputSportsTeams.get(0).getId());
        inputTagAssociations.get(1).setEntityId(inputSportsTeams.get(1).getId());
        inputTagAssociations.get(2).setEntityId(inputSportsTeams.get(1).getId());
        tagAssociationClient.create(inputTagAssociations);
        // RETRIEVE
        Feed<SportsTeam> retrievedSportsTeamAgain = sportsTeamClient.get(sportsTeamIds, new String[]{});
        for (SportsTeam sportsTeam : retrievedSportsTeamAgain.getEntries()) {
            if (inputSportsTeams.get(0).getId().equals(sportsTeam.getId())) {
                assertEquals(sportsTeam.getVersion(), new Long("1"), "After create SportsTeam version should be one");
                assertEquals(sportsTeam.getTagIds().size(), 1, "This sportsTeam has one tag");
                assertEquals(sportsTeam.getTagIds().get(0), inputTagAssociations.get(0).getTagId(), "is sportsTeam has right tag ?");
            } else if (inputSportsTeams.get(1).getId().equals(sportsTeam.getId())) {
                assertEquals(sportsTeam.getVersion(), new Long("1"), "After create SportsTeam version should be one");
                assertEquals(sportsTeam.getTagIds().size(), 2, "This sportsTeam has two tags");
                assertEquals(sportsTeam.getTagIds(),
                        Arrays.asList(inputTagAssociations.get(1).getTagId(), inputTagAssociations.get(2).getTagId()),
                        "is sportsTeam has right tag ?");
            } else {
                assertEquals(sportsTeam.getVersion(), new Long("0"), "After create SportsTeam version should be one");
                assertEquals(sportsTeam.getTagIds().size(), 0, "This sportsTeam has no tag");
            }
        }

        // UPDATE association & sportsTeam both and retrieve sportsTeam
        List<Tag> inputTags = getPersistingTagFactory().create(3);
        for (int i = 0; i < 3; i++)
            inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());

        tagAssociationClient.update(inputTagAssociations);
        Feed<SportsTeam> retrieveAfterUpdateOnce = sportsTeamClient.get(sportsTeamIds, new String[]{});
        for (SportsTeam sportsTeam : retrieveAfterUpdateOnce.getEntries()) {
            if (inputSportsTeams.get(0).getId().equals(sportsTeam.getId())) {
                assertEquals(sportsTeam.getVersion(), new Long("2"), "After create SportsTeam version should be one");
                assertEquals(sportsTeam.getTagIds().size(), 1, "This sportsTeam has one tag");
                assertEquals(sportsTeam.getTagIds().get(0), inputTagAssociations.get(0).getTagId(), "is sportsTeam has right tag ?");
            } else if (inputSportsTeams.get(1).getId().equals(sportsTeam.getId())) {
                assertEquals(sportsTeam.getVersion(), new Long("2"), "After create SportsTeam version should be one");
                assertEquals(sportsTeam.getTagIds().size(), 2, "This sportsTeam has two tags");
                assertEquals(sportsTeam.getTagIds(),
                        Arrays.asList(inputTagAssociations.get(1).getTagId(), inputTagAssociations.get(2).getTagId()),
                        "is sportsTeam has right tag ?");
            } else {
                assertEquals(sportsTeam.getVersion(), new Long("0"), "After create SportsTeam version should be one");
                assertEquals(sportsTeam.getTagIds().size(), 0, "This sportsTeam has no tag");
            }
        }

        // DELETE association, update sportsTeam & retrieve sportsTeam
        tagAssociationClient.delete(tagAssociationIds);
        Feed<SportsTeam> retrieveAfterUpdateAgain = sportsTeamClient.get(sportsTeamIds, new String[]{});
        for (SportsTeam sportsTeam : retrieveAfterUpdateAgain.getEntries()) {
            if (inputSportsTeams.get(0).getId().equals(sportsTeam.getId())) {
                assertEquals(sportsTeam.getVersion(), new Long("3"), "After create SportsTeam version should be one");
                assertEquals(sportsTeam.getTagIds().size(), 0, "This sportsTeam has one tag");
            } else if (inputSportsTeams.get(1).getId().equals(sportsTeam.getId())) {
                assertEquals(sportsTeam.getVersion(), new Long("3"), "After create SportsTeam version should be one");
                assertEquals(sportsTeam.getTagIds().size(), 0, "This sportsTeam has two tags");
            } else {
                assertEquals(sportsTeam.getVersion(), new Long("0"), "After create SportsTeam version should be one");
                assertEquals(sportsTeam.getTagIds().size(), 0, "This sportsTeam has no tag");
            }
        }

        inputSportsTeams.forEach(this::delete);
    }

    @Test
    public void crudTagIdsFilterTest() throws UnknownHostException {
        // Create SportsTeam
        SportsTeam inputSportsTeam = sportsTeamFactory.create();
        sportsTeamClient.create(inputSportsTeam);

        // Create Association
        List<Tag> inputTags = getPersistingTagFactory().create(5);

        List<TagAssociation> inputTagAssociations = getSportsTeamTagAssociationFactory().create(5);
        inputTagAssociations.forEach((ta) -> ta.setEntityId(inputSportsTeam.getId()));
        for (int i = 0; i < inputTags.size(); i++)
            inputTagAssociations.get(i).setTagId(inputTags.get(i).getId());
        tagAssociationClient.create(inputTagAssociations);

        // RETRIEVE
        sportsTeamClient.update(inputSportsTeam);
        SportsTeam retrievedSportsTeamAgain = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
        assertEquals(retrievedSportsTeamAgain.getTagIds().size(), 5, "Created SportsTeam has five Tags");

        // Retrieve sportsTeam with tagIdsFilter parameter and make sure only the selected tags are returned:
        HashMap<String, String> parameters = new HashMap<>();
        parameters.put("tagIdsFilter", MerlinUriUtil.getIdValue(inputTags.get(1).getId()) + "");
        RequestParameters requestParameters = new RequestParameters();
        requestParameters.setParameters(parameters);
        retrievedSportsTeamAgain = sportsTeamClient.get(inputSportsTeam.getId(), new String[]{SportsTeamField.tagIds.getLocalName()}, requestParameters);
        assertNotNull(retrievedSportsTeamAgain.getTagIds());
        assertEquals(retrievedSportsTeamAgain.getTagIds().size(), 1, "Filtered SportsTeam has one Tags");

        assertTrue(retrievedSportsTeamAgain.getTagIds().get(0).equals(inputTags.get(1).getId()));

        delete(inputSportsTeam);
    }

    private void delete(SportsTeam inputSportsTeam) {
        // DELETE SportsTeam (It's part of cleaning up database at the end of each
        // test case)
        long deletedObjects = sportsTeamClient.delete(inputSportsTeam.getId());
        assertEquals(1, deletedObjects);
        try {
            sportsTeamClient.get(inputSportsTeam.getId(), new String[]{});
            fail("SportsTeam should not be found after deleting it");
        } catch (ObjectNotFoundException e) {
            // ok
        }
    }
}
