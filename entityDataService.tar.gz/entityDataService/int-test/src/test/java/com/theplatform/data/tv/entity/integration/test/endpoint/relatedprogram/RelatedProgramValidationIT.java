package com.theplatform.data.tv.entity.integration.test.endpoint.relatedprogram;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgramType;
import com.theplatform.data.tv.entity.api.fields.RelatedProgramField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author jethrolai
 * @since 2/16/2012
 */
@Test(groups = { TestGroup.gbTest, "relatedProgram", "validation" })
public class RelatedProgramValidationIT extends EntityTestBase {

	@DataProvider
	public Object[][] allRelatedProgramTypes() {
		List<Object[]> relatedProgramTypes = new ArrayList<>();
		for (RelatedProgramType type : RelatedProgramType.values()) {
			relatedProgramTypes.add(new Object[] { type });
		}

		Object[][] typeArray = new Object[relatedProgramTypes.size()][];
		relatedProgramTypes.toArray(typeArray);
		return typeArray;
	}

	@Test(groups = { TestGroup.gbTest, "relatedProgram" }, dataProvider = "allRelatedProgramTypes")
	public void testRelatedProgramCreateWithValidRelatedProgramType(RelatedProgramType type) {

		this.relatedProgramClient.create(this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.type, type.getFriendlyName())));

	}

	@DataProvider
	public Object[][] invalidRelatedProgramTypes() {
		List<Object[]> relatedProgramTypes = new ArrayList<>();
		relatedProgramTypes.add(new Object[] { "" });
		relatedProgramTypes.add(new Object[] { "asdf" });
		relatedProgramTypes.add(new Object[] { "  hasspinoff" });
		relatedProgramTypes.add(new Object[] { "  HasSpinOff " });
		relatedProgramTypes.add(new Object[] { "HasSpinOff " });
		relatedProgramTypes.add(new Object[] { " HasSpinOff" });

		Object[][] typeArray = new Object[relatedProgramTypes.size()][];
		relatedProgramTypes.toArray(typeArray);
		return typeArray;
	}

	@Test(groups = { TestGroup.gbTest, "relatedProgram" }, expectedExceptions = ValidationException.class, dataProvider = "invalidRelatedProgramTypes")
	public void testRelatedProgramCreateWithValidRelatedProgramType(String invalidType) {

		this.relatedProgramClient.create(this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.type, invalidType)));

	}

	@DataProvider
	public Object[][] invalidProgramIds() {
		List<Object[]> relatedProgramTypes = new ArrayList<>();
		relatedProgramTypes.add(new Object[] { URI.create(this.getBaseUrl() + "/data/TvSeason/" + this.objectIdProvider.nextId()) });
		relatedProgramTypes.add(new Object[] { URI.create("http://fakeEntityHost/data/TvSeason/" + this.objectIdProvider.nextId()) });
		relatedProgramTypes.add(new Object[] { this.relatedProgramFactory.create().getId() });

		Object[][] typeArray = new Object[relatedProgramTypes.size()][];
		relatedProgramTypes.toArray(typeArray);
		return typeArray;
	}

	@Test(groups = { TestGroup.gbTest, "relatedProgram" }, expectedExceptions = ValidationException.class, dataProvider = "invalidProgramIds")
	public void testRelatedProgramCreateWithInvalidSourceProgram(URI invalidSourceProgramId) {
		this.relatedProgramClient.create(this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.sourceProgramId, invalidSourceProgramId)));
	}

	@Test(groups = { TestGroup.gbTest, "relatedProgram" }, expectedExceptions = ValidationException.class, dataProvider = "invalidProgramIds")
	public void testRelatedProgramCreateWithInvalidTargetProgram(URI invalidTargetProgramId) {
		this.relatedProgramClient.create(this.relatedProgramFactory.create(new DataServiceField(RelatedProgramField.targetProgramId, invalidTargetProgramId)));
	}
}
