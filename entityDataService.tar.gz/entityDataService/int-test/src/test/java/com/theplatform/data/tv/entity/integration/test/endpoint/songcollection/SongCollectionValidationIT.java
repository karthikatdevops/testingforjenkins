package com.theplatform.data.tv.entity.integration.test.endpoint.songcollection;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.Arrays;
import java.util.List;

import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseField;
import com.theplatform.data.tv.entity.api.fields.SongCollectionField;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.TestNGDataProviderUtil;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

@Test(groups = { TestGroup.gbTest, "songCollection", "validation" })
public class SongCollectionValidationIT extends EntityTestBase {

	@Test(dataProvider = "validTypes")
	public void testSongCollectionCreateValidTypes(String validType) throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.type, validType)));
	}

	@Test(dataProvider = "invalidTypes", expectedExceptions = ValidationException.class)
	public void testSongCollectionCreateInvalidTypes(String invalidType) throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.soundType, "")));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.soundType, "asdf")));
		this.albumReleaseClient.create(this.albumReleaseFactory.create(new DataServiceField(AlbumReleaseField.soundType, "MIXED")));
	}

	@DataProvider
	public Object[][] validTypes() {
		return new Object[][] { { "Variant" } };
	}

	@DataProvider
	public Object[][] invalidTypes() {
		return TestNGDataProviderUtil.generateDataProvider(new Object[] { "VARIANT" }, new Object[] { null }, new Object[] { "sfadsf" },
				new Object[] { "variant" });
	}

	public void testSongCollectionCreateNullSongIds() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.songIds, null)));
	}

	@Test( expectedExceptions = ValidationException.class)
	public void testSongCollectionCreateNonpersistedSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		List<URI> id = Arrays.asList(this.songFactory.create().getId());
		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.songIds, id)));
		id = null;
	}

	@Test( expectedExceptions = ValidationException.class)
	public void testSongCollectionCreateNonLocalSongId() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI localSongId = this.songClient.create(this.songFactory.create()).getId();

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.songIds, Arrays.asList(this.songFactory.create(
				new DataServiceField(DataObjectField.id, URI.create("http://fakehost:9003/entityDataService/data/Song/" + URIUtils.getIdValue(localSongId)))).getId()))));
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testSongCollectionCreatePrimarySongIdNotInSongIds() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCollectionClient.create(this.songCollectionFactory.create(
				new DataServiceField(SongCollectionField.songIds, Arrays.asList(songClient.create(songFactory.create()).getId())), new DataServiceField(SongCollectionField.primarySongId,
						songClient.create(songFactory.create()).getId())));
	}
}
