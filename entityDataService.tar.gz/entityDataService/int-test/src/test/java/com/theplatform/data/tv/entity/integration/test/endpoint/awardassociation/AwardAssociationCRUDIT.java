package com.theplatform.data.tv.entity.integration.test.endpoint.awardassociation;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.GBCommonTestCollection;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.exception.ObjectNotFoundException;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import com.theplatform.data.tv.entity.api.fields.AwardAssociationField;
import com.theplatform.data.tv.entity.api.test.AwardAssociationComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * GreenBuild test for CRUD operations of AwardAssociation
 * 
 * @author clai200
 * @since 4/5/2011
 * 
 */
@Test(groups = { TestGroup.gbTest, "awardAssociation", "crud" })
public class AwardAssociationCRUDIT extends EntityTestBase {



	@Test(groups = { TestGroup.gbTest })
	public void testCrudSingleAwardAssociation() throws UnknownHostException {
		AwardAssociation entity = this.awardAssociationFactory.create();

		// CREATE
		this.awardAssociationClient.create(entity);

		// RETRIEVE
		AwardAssociation retrievedEntity = this.awardAssociationClient.get(entity.getId(), new String[] {});
		AwardAssociationComparator.assertEquals(retrievedEntity, entity);

		// UPDATE
		entity.setDescription(entity.getDescription() != null ? entity.getDescription() + "update" : "entity description");
		entity.setYear(entity.getYear() + 1);
		entity.setAwardStatus(entity.getAwardStatus().equals("Winner") ? "Nominee" : "Winner");
		entity.setAwardType(entity.getAwardType().equals("Person") ? "Program" : "Person");
		entity.setAwardId(this.awardClient.create(this.awardFactory.create()).getId());
		entity.setInstitutionId(this.institutionClient.create(this.institutionFactory.create()).getId());
		entity.setProgramId(this.programClient.create(programFactory.create()).getId());
		entity.setPersonId(this.personClient.create(personFactory.create()).getId());
		entity.setAwardShowId(this.programClient.create(programFactory.create()).getId());
		entity.setMerlinResourceType(entity.getMerlinResourceType() != null && entity.getMerlinResourceType() != MerlinResourceType.Temporary ? MerlinResourceType.Temporary
				: MerlinResourceType.AudienceAvailable);
		this.awardAssociationClient.update(entity);

		AwardAssociation retrievedAfterUpdate = this.awardAssociationClient.get(entity.getId(), new String[] {});
		AwardAssociationComparator.assertEquals(retrievedAfterUpdate, entity);

		// DELETE
		long deletedObjects = this.awardAssociationClient.delete(entity.getId());
		assertEquals(deletedObjects, 1);

		try {
			this.awardAssociationClient.get(entity.getId(), new String[] {});
		} catch (ObjectNotFoundException e) {
			// ok
			return;
		}

		fail("The deleted instance of AwardAssociation should not be found after deleting it");
	}

	@Test(groups = { "other" })
	public void testCrudAwardAssociationFeed() throws UnknownHostException {
		List<AwardAssociation> entities = this.awardAssociationFactory.create(5);
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] entityIds = (URI[]) CollectionUtils.collect(entities, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// CREATE
		Feed<AwardAssociation> persistedEntities = this.awardAssociationClient.create(entities, (String[]) null);
		AwardAssociationComparator.assertEquals(persistedEntities, entities);

		// RETRIEVE
		Feed<AwardAssociation> retrievedEntities = this.awardAssociationClient.get(entityIds, new String[] {});
		AwardAssociationComparator.assertEquals(retrievedEntities, entities);

		// DELETE
		long deletedEntityAmount = this.awardAssociationClient.delete(entityIds);
		assertEquals(deletedEntityAmount, entities.size());

		long notFoundEntityAmount = 0;
		for (AwardAssociation entity : entities) {
			try {
				this.awardAssociationClient.get(entity.getId(), new String[] {});
			} catch (ObjectNotFoundException e) {
				notFoundEntityAmount++;
			}
		}
		assertEquals(notFoundEntityAmount, deletedEntityAmount, "Still found entities after deleting");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAwardAssociationDefaultFieldValuesProgramId() {
		AwardAssociation entity = this.awardAssociationFactory.create();
		entity.setAwardType("Person");
		entity.setPersonId(this.personClient.create(personFactory.create()).getId());
		entity.setDescription(null);
		entity.setProgramId(null);

		entity.setAwardShowId(null);
		entity.setMerlinResourceType(null);

		this.awardAssociationClient.create(entity);

		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

		AwardAssociationComparator.assertEquals(this.awardAssociationClient.get(entity.getId(), new String[] {}), entity);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAwardAssociationDefaultFieldValuesPersonId() {
		AwardAssociation entity = this.awardAssociationFactory.create();
		entity.setAwardType("Program");
		entity.setProgramId(this.programClient.create(programFactory.create()).getId());
		entity.setPersonId(null);
		entity.setDescription(null);
		entity.setAwardShowId(null);
		entity.setMerlinResourceType(null);
		this.awardAssociationClient.create(entity);

		entity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		AwardAssociationComparator.assertEquals(this.awardAssociationClient.get(entity.getId(), new String[] {}), entity);
	}

	private final DataServiceField[] defaultValuesWithoutPerson = new DataServiceField[] { new DataServiceField(DataObjectField.description, null),
			new DataServiceField(AwardAssociationField.programId, null), new DataServiceField(AwardAssociationField.awardShowId, null),
			// merlinResourceType is default to leastVisible(program, award,
			// person)
			new DataServiceField(AwardAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable), };
	private final DataServiceField[] defaultValuesWithoutProgram = new DataServiceField[] { new DataServiceField(DataObjectField.description, null),
			new DataServiceField(AwardAssociationField.personId, null), new DataServiceField(AwardAssociationField.awardShowId, null),
			// merlinResourceType is default to leastVisible(program, award,
			// person)
			new DataServiceField(AwardAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable), };

	@Test(groups = { TestGroup.gbTest })
	public void testAwardAssociationPersonTypeCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(awardAssociationClient, awardAssociationFactory.create(new DataServiceField(
				AwardAssociationField.awardType, "Person"), new DataServiceField(AwardAssociationField.personId, personClient.create(personFactory.create())
				.getId())), AwardAssociationComparator.class, this.defaultValuesWithoutPerson, null);
	}
	@Test(groups = { TestGroup.gbTest })
	public void testAwardAssociationProgramTypeCreateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
	InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {
		GBCommonTestCollection.testCreateWithAllNullNonRequiredFields(awardAssociationClient, awardAssociationFactory.create(new DataServiceField(
				AwardAssociationField.awardType, "Program"), new DataServiceField(AwardAssociationField.programId, programClient.create(programFactory.create())
						.getId())), AwardAssociationComparator.class, this.defaultValuesWithoutProgram, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAwardAssociationPersonTypeCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(awardAssociationClient, awardAssociationFactory.create(new DataServiceField(AwardAssociationField.awardType, "Person"),new DataServiceField(AwardAssociationField.personId, personClient.create(personFactory.create()).getId())),
				AwardAssociationComparator.class, this.defaultValuesWithoutPerson, null);
	}
	@Test(groups = { TestGroup.gbTest })
	public void testAwardAssociationProgramTypeCreateSetNUllToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
	InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {
		GBCommonTestCollection.testCreateSetNUllToAllNonRequiredFields(awardAssociationClient, awardAssociationFactory.create(new DataServiceField(AwardAssociationField.awardType, "Program"),new DataServiceField(AwardAssociationField.personId,null),new DataServiceField(AwardAssociationField.programId, programClient.create(programFactory.create()).getId())),
				AwardAssociationComparator.class, this.defaultValuesWithoutProgram, null);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testAwardAssociationPersonTypeUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {

		// an assumption made in this test is all dependent objects are
		// AudienceAvailable

		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "awardAssociation description"));
		createValues.add(new DataServiceField(AwardAssociationField.personId, personClient.create(personFactory.create()).getId()));
		createValues.add(new DataServiceField(AwardAssociationField.awardType, "Person"));
		// awardShowId is not populated not
		createValues.add(new DataServiceField(AwardAssociationField.merlinResourceType, MerlinResourceType.Temporary));

		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(awardAssociationClient, awardAssociationFactory.create(new DataServiceField(AwardAssociationField.programId, null)),
				AwardAssociationComparator.class, defaultValuesWithoutPerson, createValues.toArray(new DataServiceField[] {}), null);
	}
	@Test(groups = { TestGroup.gbTest })
	public void testAwardAssociationProgramTypeUpdateWithAllNullNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
	InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {
		
		// an assumption made in this test is all dependent objects are
		// AudienceAvailable
		
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "awardAssociation description"));
		createValues.add(new DataServiceField(AwardAssociationField.programId, programClient.create(programFactory.create()).getId()));
		createValues.add(new DataServiceField(AwardAssociationField.awardType, "Program"));
		// awardShowId is not populated not
		createValues.add(new DataServiceField(AwardAssociationField.merlinResourceType, MerlinResourceType.Temporary));
		
		GBCommonTestCollection.testUpdateWithAllNullNonRequiredFields(awardAssociationClient, awardAssociationFactory.create(new DataServiceField(AwardAssociationField.personId, null)),
				AwardAssociationComparator.class, defaultValuesWithoutProgram, createValues.toArray(new DataServiceField[] {}), null);
	}

	@Test(groups = TestGroup.gbTest)
	public void testAwardAssociationPersonTypeUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {
		// an assumption made in this test is all dependent objects are
				// AudienceAvailable

				List<DataServiceField> createValues = new ArrayList<>();
				createValues.add(new DataServiceField(DataObjectField.description, "awardAssociation description"));
				createValues.add(new DataServiceField(AwardAssociationField.personId, personClient.create(personFactory.create()).getId()));
				createValues.add(new DataServiceField(AwardAssociationField.awardType, "Person"));
				// awardShowId is not populated not
				createValues.add(new DataServiceField(AwardAssociationField.merlinResourceType, MerlinResourceType.Temporary));

				GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(awardAssociationClient, awardAssociationFactory.create(new DataServiceField(AwardAssociationField.programId, null)),
						AwardAssociationComparator.class, defaultValuesWithoutPerson, createValues.toArray(new DataServiceField[] {}), null);
	}
	@Test(groups = TestGroup.gbTest)
	public void testAwardAssociationProgramTypeUpdateSetNullToAllNonRequiredFields() throws IllegalArgumentException, SecurityException, IllegalAccessException,
	InvocationTargetException, NoSuchMethodException, ClassNotFoundException, InstantiationException, NoSuchFieldException {
		// an assumption made in this test is all dependent objects are
		// AudienceAvailable
		
		List<DataServiceField> createValues = new ArrayList<>();
		createValues.add(new DataServiceField(DataObjectField.description, "awardAssociation description"));
		createValues.add(new DataServiceField(AwardAssociationField.programId, programClient.create(programFactory.create()).getId()));
		createValues.add(new DataServiceField(AwardAssociationField.awardType, "Program"));
		// awardShowId is not populated not
		createValues.add(new DataServiceField(AwardAssociationField.merlinResourceType, MerlinResourceType.Temporary));
		
		GBCommonTestCollection.testUpdateSetNullToAllNonRequiredFields(awardAssociationClient, awardAssociationFactory.create(new DataServiceField(AwardAssociationField.programId, null)),
				AwardAssociationComparator.class, defaultValuesWithoutProgram, createValues.toArray(new DataServiceField[] {}), null);
	}

}
