package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.client.query.SearchQuery;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.*;

@Test(groups = { "program" })
public class ProgramSearchQueryIT extends EntityTestBase {

	@Test(groups = { TestGroup.gbTest }, enabled=true)
	public void testGetProgramsByLucene() {
		List<Program> programs = this.programFactory.create(7,new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		// Possible values for local
		programs.get(0).setTitle(programs.get(0).getTitle() + " Caterpillar");
		programs.get(1).setTitle(programs.get(1).getTitle() + " Monkey");
		programs.get(1).setSportsSubtitle("Tiny Caterpillars");
		programs.get(1).setType(ProgramType.SportingEvent);
		programs.get(1).setReleaseDate(null);
		programs.get(2).setTitle(programs.get(2).getTitle() + " Snow Leopard");
		programs.get(3).setTitle(programs.get(3).getTitle() + " Leopard" );
		programs.get(3).setSportsSubtitle("Monkey Shine");
		programs.get(3).setType(ProgramType.SportingEvent);
		programs.get(3).setReleaseDate(null);
		programs.get(4).setTitle(programs.get(4).getTitle() + " Flying Monkeys");
		programs.get(5).setTitle(programs.get(5).getTitle() + " Climbing Monkey");
		programs.get(6).setTitle(programs.get(6).getTitle() + " The Latest");
		programs.get(6).setProductionEpisodeNumber("101");

		this.programClient.create(programs);
		
		// Wait for some arbitrary amount of time so notification can be picked up by 
		// entityIndexer and it can push the programs into solr
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) { }
				
		Feed<Program> retrievedPrograms = null;
		List<Program> expectedPrograms = null;

		retrievedPrograms = this.programClient.getAll(null, new Query[] { new SearchQuery("Butterfly") }, null, null, true);
		Assert.assertEquals(retrievedPrograms.getEntryCount(), new Long(0));
		
		retrievedPrograms = this.programClient.getAll(null, new Query[] { new SearchQuery("Caterpillar") }, null, null, true);
		expectedPrograms = Arrays.asList(programs.get(0));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		retrievedPrograms = this.programClient.getAll(null, new Query[] { new SearchQuery("Leopard") }, null, null, true);
		expectedPrograms = Arrays.asList(programs.get(2), programs.get(3));
		List<Program> sortedPrograms = sortDataObjectsById(retrievedPrograms);
		for (int i=0; i<expectedPrograms.size();i++)
		ProgramComparator.assertEquals(sortedPrograms.get(i), expectedPrograms.get(i));
		
		retrievedPrograms = this.programClient.getAll(null, new Query[] { new SearchQuery("Monkey") }, null, null, true);
		expectedPrograms = Arrays.asList(programs.get(1), programs.get(4), programs.get(5));
		sortedPrograms = sortDataObjectsById(retrievedPrograms);
		
		retrievedPrograms = this.programClient.getAll(null, new Query[] { new SearchQuery("sportsSubtitle:Tiny") }, null, null, true);
		expectedPrograms = Arrays.asList(programs.get(1));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);

		retrievedPrograms = this.programClient.getAll(null, new Query[] { new SearchQuery("productionEpisodeNumber:101") }, null, null, true);
		expectedPrograms = Arrays.asList(programs.get(6));
		ProgramComparator.assertEquals(retrievedPrograms, expectedPrograms);
	}

	private <T extends DataObject> List<T> sortDataObjectsById(Feed<T> feed) {
		List<T> entries = feed.getEntries();
		Collections.sort(entries, new Comparator<T>() {
			@Override public int compare(T o1, T o2) {
				if (o1 == null && o2 == null) { return 0; }
				if (o1 == null) { return -1; }
				if (o2 == null) { return 1; }
				return (int) (URIUtils.getIdValue(o1.getId()) - URIUtils.getIdValue(o2.getId()));
			}
		});
		return entries;
	}

}
