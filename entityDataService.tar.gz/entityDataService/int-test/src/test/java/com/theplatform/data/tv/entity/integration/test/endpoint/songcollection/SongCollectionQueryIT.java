package com.theplatform.data.tv.entity.integration.test.endpoint.songcollection;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.api.client.query.ByTitlePrefix;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.fields.SongCollectionField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.ByTitle;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.programsongassociation.BySongId;
import com.theplatform.data.tv.entity.api.client.query.songcollection.ByPrimarySongId;
import com.theplatform.data.tv.entity.api.client.query.songcollection.BySubtype;
import com.theplatform.data.tv.entity.api.data.objects.SongCollection;
import com.theplatform.data.tv.entity.api.test.SongCollectionComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

@Test(groups = { TestGroup.gbTest, "query", "songCollection" })
public class SongCollectionQueryIT extends EntityTestBase {

	public void testSongCollectionQueryByTitleNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(DataObjectField.title, "title")));
		Query[] queries = new Query[] { new ByTitle("title altered") };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCollection should be found");
	}

	public void testSongCollectionQueryByTitleOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		final String title1 = "title 1";
		final String title2 = "title 2";

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(DataObjectField.title, title1)));

		SongCollection expectedSongCollection = this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(DataObjectField.title, title2)),
				new String[] {});
		Query[] queries = new Query[] { new ByTitle(title2) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCollection should be found");

		SongCollectionComparator.assertEquals(results.getEntries().get(0), expectedSongCollection);
	}

	public void testSongCollectionQueryByTitleMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final String title1 = "title 1";
		final String title2 = "title 2";

		this.songCollectionClient.create(this.songCollectionFactory.create(3, new DataServiceField(DataObjectField.title, title1)));

		List<SongCollection> expectedSongCollections = this.songCollectionClient.create(
				this.songCollectionFactory.create(2, new DataServiceField(DataObjectField.title, title2)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByTitle(title2) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCollections should be found");

		Map<URI, SongCollection> resultMap = new HashMap<>();
		for (SongCollection songCollection : results.getEntries()) {
			resultMap.put(songCollection.getId(), songCollection);
		}

		for (SongCollection expected : expectedSongCollections)
			SongCollectionComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testSongCollectionQueryByTitlePrefixNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(DataObjectField.title, "title")));
		Query[] queries = new Query[] { new ByTitlePrefix("de") };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCollection should be found");
	}

	public void testSongCollectionQueryByTitlePrefixOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final String title1 = "1title 1";
		final String title2 = "2title 2";

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(DataObjectField.title, title1)));

		SongCollection expectedSongCollection = this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(DataObjectField.title, title2)),
				new String[] {});
		Query[] queries = new Query[] { new ByTitlePrefix(title2.substring(0, 3)) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCollection should be found");

		SongCollectionComparator.assertEquals(results.getEntries().get(0), expectedSongCollection);
	}

	public void testSongCollectionQueryByTitlePrefixMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final String title1 = "1title 1";
		final String title2 = "2title 2";

		this.songCollectionClient.create(this.songCollectionFactory.create(3, new DataServiceField(DataObjectField.title, title1)));

		List<SongCollection> expectedSongCollections = this.songCollectionClient.create(
				this.songCollectionFactory.create(2, new DataServiceField(DataObjectField.title, title2)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByTitlePrefix(title2.substring(0, 3)) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCollections should be found");

		Map<URI, SongCollection> resultMap = new HashMap<>();
		for (SongCollection songCollection : results.getEntries())
			resultMap.put(songCollection.getId(), songCollection);

		for (SongCollection expected : expectedSongCollections)
			SongCollectionComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	// No type query test because there is only one type

	public void testSongCollectionQueryBySubtypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.subtype, "Content")));
		Query[] queries = new Query[] { new BySubtype("Language") };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCollection should be found");
	}

	public void testSongCollectionQueryBySubtypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final String subtype1 = "Content";
		final String subtype2 = "Language";

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.subtype, subtype1)));

		SongCollection expectedSongCollection = this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.subtype, subtype2)),
				new String[] {});
		Query[] queries = new Query[] { new BySubtype(subtype2) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCollection should be found");

		SongCollectionComparator.assertEquals(results.getEntries().get(0), expectedSongCollection);
	}

	public void testSongCollectionQueryBySubtypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		final String subtype1 = "Content";
		final String subtype2 = "Language";

		this.songCollectionClient.create(this.songCollectionFactory.create(3, new DataServiceField(SongCollectionField.subtype, subtype1)));

		List<SongCollection> expectedSongCollections = this.songCollectionClient.create(
				this.songCollectionFactory.create(2, new DataServiceField(SongCollectionField.subtype, subtype2)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySubtype(subtype2) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCollections should be found");

		Map<URI, SongCollection> resultMap = new HashMap<>();
		for (SongCollection songCollection : results.getEntries())
			resultMap.put(songCollection.getId(), songCollection);

		for (SongCollection expected : expectedSongCollections)
			SongCollectionComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testSongCollectionQueryBySongIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.songIds, Arrays.asList(songClient
				.create(songFactory.create()).getId()))));
		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songClient.create(songFactory.create()).getId())) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCollection should be found");
	}

	public void testSongCollectionQueryBySongIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI songId = songClient.create(songFactory.create()).getId();
		SongCollection expected = this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.songIds, Arrays.asList(songId))),
				new String[] {});
		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.songIds, Arrays.asList(songClient
				.create(songFactory.create()).getId()))));

		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCollection should be found");

		SongCollectionComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongCollectionQueryBySongIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId = songClient.create(songFactory.create()).getId();
		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.songIds, Arrays.asList(songClient
				.create(songFactory.create()).getId()))));

		List<SongCollection> expectedSongCollections = this.songCollectionClient.create(
				this.songCollectionFactory.create(2, new DataServiceField(SongCollectionField.songIds, Arrays.asList(songId))), new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySongId(URIUtils.getIdValue(songId)) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCollections should be found");

		Map<URI, SongCollection> resultMap = new HashMap<>();
		for (SongCollection songCollection : results.getEntries())
			resultMap.put(songCollection.getId(), songCollection);

		for (SongCollection expected : expectedSongCollections)
			SongCollectionComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testSongCollectionQueryByPrimarySongIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId = songClient.create(songFactory.create()).getId();
		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.primarySongId, songId), new DataServiceField(SongCollectionField.songIds,
				Arrays.asList(songId))));
		Query[] queries = new Query[] { new ByPrimarySongId(URIUtils.getIdValue(songClient.create(songFactory.create()).getId())) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCollection should be found");
	}

	public void testSongCollectionQueryByPrimarySongIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI songId = songClient.create(songFactory.create()).getId();
		SongCollection expected = this.songCollectionClient.create(
				this.songCollectionFactory.create(new DataServiceField(SongCollectionField.primarySongId, songId), new DataServiceField(SongCollectionField.songIds, Arrays.asList(songId))),
				new String[] {});
		this.songCollectionClient.create(this.songCollectionFactory.create());

		Query[] queries = new Query[] { new ByPrimarySongId(URIUtils.getIdValue(songId)) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCollection should be found");

		SongCollectionComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongCollectionQueryByPrimarySongIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI songId1 = songClient.create(songFactory.create()).getId();
		URI songId2 = songClient.create(songFactory.create()).getId();

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.primarySongId, songId2), new DataServiceField(SongCollectionField.songIds,
				Arrays.asList(songId2))));

		List<SongCollection> expectedSongCollections = this.songCollectionClient.create(
				this.songCollectionFactory.create(2, new DataServiceField(SongCollectionField.primarySongId, songId1), new DataServiceField(SongCollectionField.songIds, Arrays.asList(songId1))),
				new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByPrimarySongId(URIUtils.getIdValue(songId1)) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCollections should be found");

		Map<URI, SongCollection> resultMap = new HashMap<>();
		for (SongCollection songCollection : results.getEntries())
			resultMap.put(songCollection.getId(), songCollection);

		for (SongCollection expected : expectedSongCollections)
			SongCollectionComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testSongCollectionQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No SongCollection should be found");
	}

	public void testSongCollectionQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		SongCollection expected = this.songCollectionClient.create(
				this.songCollectionFactory.create(new DataServiceField(SongCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {});
		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.merlinResourceType, MerlinResourceType.Editorial)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one SongCollection should be found");

		SongCollectionComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testSongCollectionQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.songCollectionClient.create(this.songCollectionFactory.create(new DataServiceField(SongCollectionField.merlinResourceType, MerlinResourceType.Editorial)));
		List<SongCollection> expectedSongCollections = this.songCollectionClient.create(
				this.songCollectionFactory.create(2, new DataServiceField(SongCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {})
				.getEntries();
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<SongCollection> results = this.songCollectionClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two SongCollections should be found");

		Map<URI, SongCollection> resultMap = new HashMap<>();
		for (SongCollection songCollection : results.getEntries()) {
			resultMap.put(songCollection.getId(), songCollection);
		}

		for (SongCollection expected : expectedSongCollections)
			SongCollectionComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

}
