package com.theplatform.data.tv.entity.integration.test.endpoint.person;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.factory.OverrideField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.PersonKnownForType;
import com.theplatform.data.tv.entity.api.data.objects.PersonType;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "person", "validation" })
public class PersonValidationIT extends EntityTestBase {



	public void testPersonValidationCreateWithValidPersonType() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.personType, PersonType.Band.getFriendlyName())));
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.personType, PersonType.Person.getFriendlyName())));
	}

	public void testPersonValidationCreateWithValidKnownForType() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.knownFor, new ArrayList<String>(Arrays
				.asList(new String[] { PersonKnownForType.Music.getFriendlyName() })))));
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.knownFor, new ArrayList<String>(Arrays
				.asList(new String[] { PersonKnownForType.Video.getFriendlyName() })))));
	}

	// TODO waiting for developer to add this validation, add this test back to core
	// after the validation is added
	@Test(groups = { TestGroup.notImplemented }, dataProvider = "invalidPersonTypes", expectedExceptions = ValidationException.class)
	public void testPersonValidationCreateWithInvalidPersonType(String invalidPersonType) throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.personType, invalidPersonType)));

	}

	@DataProvider
	protected Object[][] invalidPersonTypes() {
		List<Object[]> argumentList = new ArrayList<Object[]>();
		argumentList.add(new Object[] { null });
		argumentList.add(new Object[] { " " });
		argumentList.add(new Object[] { "adf" });
		argumentList.add(new Object[] { PersonType.Band.getFriendlyName().concat("updated") });
		argumentList.add(new Object[] { PersonType.Person.getFriendlyName().toLowerCase() });
		argumentList.add(new Object[] { PersonType.Band.getFriendlyName().toUpperCase() });
		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

	// TODO waiting for Xiang to add this validation, add this test back to core
	// after the validation is added
	@Test(groups = { TestGroup.notImplemented }, dataProvider = "invalidKnownFors", expectedExceptions = ValidationException.class)
	public void testPersonValidationCreateWithInvalidKnownFor(String[] invalidKnownFors) throws IllegalArgumentException, SecurityException,
			IllegalAccessException, InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.knownFor, new ArrayList<String>(Arrays.asList(invalidKnownFors)))));

	}

	@Test(expectedExceptions = ValidationException.class)
	public void testPersonValidationCreateWithInvalidKnownForNull() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.personClient.create(personFactory.create(new DataServiceField(PersonField.knownFor, null)));

	}

	@DataProvider
	protected Object[][] invalidKnownFors() {
		List<Object[]> argumentList = new ArrayList<Object[]>();
		argumentList.add(new Object[] { new String[] {} });
		argumentList.add(new Object[] { new String[] { "  " } });
		argumentList.add(new Object[] { new String[] { PersonKnownForType.Music.getFriendlyName().concat(" ") } });
		argumentList.add(new Object[] { new String[] { " ".concat(PersonKnownForType.Music.getFriendlyName()) } });
		argumentList.add(new Object[] { new String[] { PersonKnownForType.Music.getFriendlyName().toLowerCase() } });
		argumentList.add(new Object[] { new String[] { PersonKnownForType.Video.getFriendlyName().toUpperCase() } });
		argumentList.add(new Object[] { new String[] { PersonKnownForType.Video.getFriendlyName().toUpperCase(), "" } });
		argumentList.add(new Object[] { new String[] { PersonKnownForType.Video.getFriendlyName().toUpperCase(), "asdfgad" } });
		argumentList.add(new Object[] { new String[] { PersonKnownForType.Video.getFriendlyName().toUpperCase(), null } });
		Object[][] argumentSet = new Object[argumentList.size()][];
		argumentList.toArray(argumentSet);
		return argumentSet;
	}

}
