package com.theplatform.data.tv.entity.integration.test.endpoint.programsportsevent;

import java.net.URI;
import java.net.UnknownHostException;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author clai200
 * @since 4/7/2011
 */
@Test(groups = { "programSportsEvent", "validation", TestGroup.gbTest })
public class ProgramSportsEventValidationIT extends EntityTestBase {

	@Test(expectedExceptions = ValidationException.class)
	public void testValidatingProgramId() throws UnknownHostException {
		ProgramSportsEvent inputProgramSportsEvent = this.programSportsEventFactory.create();
		inputProgramSportsEvent.setProgramId(URI.create(this.getBaseUrl() + "/data/Program/" + this.objectIdProvider.nextId()));
		this.programSportsEventClient.create(inputProgramSportsEvent);
	}

	@Test(expectedExceptions = ValidationException.class)
	public void testValidatingSportsEventId() throws UnknownHostException {
		ProgramSportsEvent inputProgramSportsEvent = this.programSportsEventFactory.create();
		inputProgramSportsEvent.setSportsEventId(URI.create(this.getBaseUrl() + "/data/SportsEvent/" + this.objectIdProvider.nextId()));
		this.programSportsEventClient.create(inputProgramSportsEvent);
	}
}
