package com.theplatform.data.tv.entity.integration.test.endpoint.mainimagetype;

import static org.testng.Assert.assertEquals;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.Test;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.entity.api.test.MainImageTypeComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.client.MainImageTypeClient;
import com.theplatform.data.tv.image.api.data.objects.FallbackRule;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;

@Test(groups = { "mainImageType", "other" })
public class MainImageTypeCollectionCachingIT extends EntityTestBase {
	private MainImageTypeClient nodeA_Client;
	private MainImageTypeClient nodeB_Client;

	private String NODE_A_BASE_URL = "http://ccpdss-dt-f001-d.dt.ccp.cable.comcast.com:9002/entityDataService";
	private String NODE_B_BASE_URL = "http://ccpdss-dt-f002-d.dt.ccp.cable.comcast.com:9002/entityDataService";
	private String END_POINT_URL = "/data/MainImageType/";

	public MainImageTypeCollectionCachingIT() throws UnknownHostException {
		nodeA_Client = new MainImageTypeClient(NODE_A_BASE_URL, new NoAuthHeader());
		nodeB_Client = new MainImageTypeClient(NODE_B_BASE_URL, new NoAuthHeader());
	}

	@Test(enabled = false)
	public void testFallbackRulesCaching() throws UnknownHostException {
		MainImageType mainImageType = createMainImageType(NODE_A_BASE_URL);
		// CREATE
		MainImageType persistedMainImageType = nodeA_Client.create(mainImageType);

		// RETRIEVE
		MainImageType retrievedMainImageType = nodeA_Client.get(persistedMainImageType.getId(), new String[] {});
		MainImageTypeComparator.assertMainImageTypeEqual(retrievedMainImageType, mainImageType);

		retrievedMainImageType = nodeB_Client.get(URI.create(NODE_B_BASE_URL + END_POINT_URL + LocalUriConverter.convertUriToID(mainImageType.getId())),
				new String[] {});

		// UPDATE
		nodeA_Client.update(mainImageType);
		MainImageType retrievedAfterUpdateFromNodeA = nodeA_Client.get(mainImageType.getId(), new String[] {});
		MainImageType retrievedAfterUpdateFromNodeB = nodeB_Client.get(
				URI.create(NODE_B_BASE_URL + END_POINT_URL + LocalUriConverter.convertUriToID(mainImageType.getId())), new String[] {});

		// DELETE why this delete logic not in @After because this test only
		// deleting what it created....
		long deletedObjects = nodeA_Client.delete(mainImageType.getId());
		assertEquals(deletedObjects, 1);

		// why these lines at the end ? Because we want to delete. If below
		// lines failed then can not delete if deletion logic after these lines.
		// WHY one of the argument YES / NO ? Argument is about isNodeA or not.
		// mainImageType input has different base url then node B and in order
		// compare, it's require to check baseUrl
		MainImageTypeComparator.assertMainImageTypeEqual(retrievedAfterUpdateFromNodeA, mainImageType);
	}

	@Test(enabled = false)
	public void testImageTypesCaching() throws UnknownHostException {
		MainImageType mainImageType = createMainImageType(NODE_A_BASE_URL);
		// CREATE
		MainImageType persistedMainImageType = nodeA_Client.create(mainImageType);

		// RETRIEVE
		MainImageType retrievedMainImageType = nodeA_Client.get(persistedMainImageType.getId(), new String[] {});
		MainImageTypeComparator.assertMainImageTypeEqual(retrievedMainImageType, mainImageType);

		retrievedMainImageType = nodeB_Client.get(URI.create(NODE_B_BASE_URL + END_POINT_URL + LocalUriConverter.convertUriToID(mainImageType.getId())),
				new String[] {});

		// UPDATE
		nodeA_Client.update(mainImageType);
		MainImageType retrievedAfterUpdateFromNodeA = nodeA_Client.get(mainImageType.getId(), new String[] {});
		MainImageType retrievedAfterUpdateFromNodeB = nodeB_Client.get(
				URI.create(NODE_B_BASE_URL + END_POINT_URL + LocalUriConverter.convertUriToID(mainImageType.getId())), new String[] {});

		// DELETE why this delete logic not in @After because this test only
		// deleting what it created....
		long deletedObjects = nodeA_Client.delete(mainImageType.getId());
		assertEquals(deletedObjects, 1);

		// why these lines at the end ? Because we want to delete. If below
		// lines failed then can not delete if deletion logic after these lines.
	}

	@Test(enabled = false)
	public void testAssetTypesCaching() throws UnknownHostException {
		MainImageType mainImageType = createMainImageType(NODE_A_BASE_URL);
		// CREATE
		MainImageType persistedMainImageType = nodeA_Client.create(mainImageType);

		// RETRIEVE
		MainImageType retrievedMainImageType = nodeA_Client.get(persistedMainImageType.getId(), new String[] {});
		MainImageTypeComparator.assertMainImageTypeEqual(retrievedMainImageType, mainImageType);

		retrievedMainImageType = nodeB_Client.get(URI.create(NODE_B_BASE_URL + END_POINT_URL + LocalUriConverter.convertUriToID(mainImageType.getId())),
				new String[] {});

		// UPDATE
		nodeA_Client.update(mainImageType);
		MainImageType retrievedAfterUpdateFromNodeA = nodeA_Client.get(mainImageType.getId(), new String[] {});
		MainImageType retrievedAfterUpdateFromNodeB = nodeB_Client.get(
				URI.create(NODE_B_BASE_URL + END_POINT_URL + LocalUriConverter.convertUriToID(mainImageType.getId())), new String[] {});

		// DELETE why this delete logic not in @After because this test only
		// deleting what it created....
		long deletedObjects = nodeA_Client.delete(mainImageType.getId());
		assertEquals(deletedObjects, 1);

		// why these lines at the end ? Because we want to delete. If below
		// lines failed then can not delete if deletion logic after these lines.
	}

	/**
	 * 
	 * Compare List<String> imageTypes & assetTypes
	 * 
	 * @param expected
	 *            List<String>
	 * @param actual
	 *            List<String>
	 */
	private void assertLists(List<String> actual, List<String> expected) {
		assertEquals(actual.size(), expected.size(), "Size of ImageTypes");
		for (int i = 0; i < expected.size(); i++) {
			assertEquals(actual.get(i), expected.get(i));
		}
	}

	/**
	 * Creates a MainImageType
	 * 
	 * @param baseUrl
	 *            String
	 * @return A new MainImageType
	 */
	private MainImageType createMainImageType(String baseUrl) {
		MainImageType mainImageType = new MainImageType();
		mainImageType.setId(URI.create(baseUrl + END_POINT_URL + objectIdProvider.nextId()));
		mainImageType.setOwnerId(URI.create("http://an.owner.id/987"));
		// data service fields
		mainImageType.setTitle("Title" + System.currentTimeMillis());
		mainImageType.setEntityType("Program");
		return mainImageType;
	}

	/**
	 * Generate Asset Types
	 * 
	 * @return List<String>
	 */
	private List<String> generateAssetTypes() {
		return Arrays.asList("transparentBackground", "opaqueBackground");
	}

	/**
	 * Generate Image Types
	 * 
	 * @return List<String>
	 */
	private List<String> generateImageTypes() {
		return Arrays.asList("cinemascope", "straight");
	}

	/**
	 * Generate FallbackRules
	 * 
	 * @return lists List<FallbackRule>
	 */
	private List<FallbackRule> getFallbackRules() {
		List<FallbackRule> lists = new ArrayList<>();
		lists.add(getMainImageTypeFallbackRule());
		return lists;
	}

	/**
	 * Generate MainImageTypeFallbackRule
	 * 
	 * @return fallbackRule FallbackRule
	 */
	private FallbackRule getMainImageTypeFallbackRule() {
		String fallBackRuleBaseUrl = NODE_A_BASE_URL + END_POINT_URL;
		URI fallBackRuleId = URI.create(fallBackRuleBaseUrl + objectIdProvider.nextId());
		FallbackRule fallbackRule = new FallbackRule();
		fallbackRule.setFallbackRuleType("MainImageTypeFallback");
		fallbackRule.setFallbackMainImageTypeId(fallBackRuleId);
		return fallbackRule;
	}

	/**
	 * Assert MainImageType Fallback
	 * 
	 * @param expectedFallbackRules
	 *            List<FallbackRule>
	 * @param actualFallbackRules
	 *            List<FallbackRule>
	 */
	private void assertMainImageTypeFallback(List<FallbackRule> actualFallbackRules, List<FallbackRule> expectedFallbackRules) {
		assertEquals(actualFallbackRules.size(), expectedFallbackRules.size(), "Unexpected number of FallbackRules");
		for (int i = 0; i < expectedFallbackRules.size(); i++) {
			assertFallbackRulesAreEqual(actualFallbackRules.get(i), expectedFallbackRules.get(i));
		}
	}

	/**
	 * Assert FallbackRule
	 * 
	 * @param expected
	 *            FallbackRule
	 * @param actual
	 *            FallbackRule
	 */
	private void assertFallbackRulesAreEqual(FallbackRule actual, FallbackRule expected) {
		if (expected.getFallbackMainImageTypeId() != null)
			assertEquals(actual.getFallbackMainImageTypeId(),
					URI.create(NODE_B_BASE_URL + END_POINT_URL + LocalUriConverter.convertUriToID(expected.getFallbackMainImageTypeId())));
		else
			assertEquals(actual.getFallbackMainImageTypeId(), expected.getFallbackMainImageTypeId());
		assertEquals(actual.getFallbackRuleType(), expected.getFallbackRuleType());
	}
}
