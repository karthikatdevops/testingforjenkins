package com.theplatform.data.tv.entity.integration.test.endpoint.relatedprogram;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import com.theplatform.data.tv.entity.api.test.RelatedProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.module.exception.BadParameterException;

/**
 * 
 * Basic Sort tests for RelatedProgram. RelatedPorgram it doesn't has any
 * specific field sortable, so it only has tests methods for no sortable fields
 * and a base field.
 * 
 * @since 4/8/2011
 * 
 */
@Test(groups = { TestGroup.gbTest, "relatedProgram", "sort", TestGroup.testBug })
public class RelatedProgramSortIT extends EntityTestBase {

	private static final int RELATED_PROGRAMS_TO_CREATE = 4;
	private List<RelatedProgram> relatedPrograms;

	@BeforeClass(alwaysRun = true)
	public void setUp() throws UnknownHostException {
		// CREATE
		relatedPrograms = this.relatedProgramFactory.create(RELATED_PROGRAMS_TO_CREATE);
		relatedPrograms.get(0).setId(URI.create(this.getBaseUrl() + "/data/RelatedProgram/" + "6536839374452227400"));
		relatedPrograms.get(0).setGuid("2");
		relatedPrograms.get(1).setId(URI.create(this.getBaseUrl() + "/data/RelatedProgram/" + "6536839374452227401"));
		relatedPrograms.get(1).setGuid("4");
		relatedPrograms.get(2).setId(URI.create(this.getBaseUrl() + "/data/RelatedProgram/" + "6536839374452227402"));
		relatedPrograms.get(2).setGuid("3");
		relatedPrograms.get(3).setId(URI.create(this.getBaseUrl() + "/data/RelatedProgram/" + "6536839374452227403"));
		relatedPrograms.get(3).setGuid("1");
		this.relatedProgramClient.create(relatedPrograms, new String[]{});
	}
	
	@Test
	public void testSortAscendingRelatedProgramByGuid() throws UnknownHostException {
		// SORT EXPECTED
		List<RelatedProgram> expectedSortedRelatedPrograms = new ArrayList<>(relatedPrograms.size());
		expectedSortedRelatedPrograms.add(relatedPrograms.get(3));
		expectedSortedRelatedPrograms.add(relatedPrograms.get(0));
		expectedSortedRelatedPrograms.add(relatedPrograms.get(2));
		expectedSortedRelatedPrograms.add(relatedPrograms.get(1));

		// RETRIEVE WITH SORTING
		Sort requestSort = new Sort("guid", false);
		Feed<RelatedProgram> retrievedRelatedPrograms = this.relatedProgramClient.getOwned(new String[] {},
				new Query[] {}, new Sort[] { requestSort }, null, false);

		RelatedProgramComparator.assertEquals(retrievedRelatedPrograms, expectedSortedRelatedPrograms);
	}

	@Test(expectedExceptions = BadParameterException.class)
	public void testSortByNonSortableField() throws UnknownHostException {
		// RETRIVE WHITH SORTING
		String sortField = "justification";
		boolean sortDescending = false;
		Sort requestSort = new Sort(sortField, sortDescending);
		this.relatedProgramClient.getOwned(new String[] {}, new Query[] {}, new Sort[] { requestSort }, null, false);
	}
}
