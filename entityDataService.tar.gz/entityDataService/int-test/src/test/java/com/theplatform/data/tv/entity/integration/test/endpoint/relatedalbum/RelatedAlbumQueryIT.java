package com.theplatform.data.tv.entity.integration.test.endpoint.relatedalbum;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.theplatform.data.tv.entity.api.fields.RelatedAlbumField;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.relatedalbum.BySourceAlbumId;
import com.theplatform.data.tv.entity.api.client.query.relatedalbum.ByTargetAlbumId;
import com.theplatform.data.tv.entity.api.data.objects.RelatedAlbum;
import com.theplatform.data.tv.entity.api.test.RelatedAlbumComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;

/**
 * @author jethrolai
 * 
 */
@Test(groups = { TestGroup.gbTest, "relatedAlbum", "query" })
public class RelatedAlbumQueryIT extends EntityTestBase {

	public void testRelatedAlbumQueryBySourceAlbumIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedAlbumClient.create(this.relatedAlbumFactory.create());
		Query[] queries = new Query[] { new BySourceAlbumId(URIUtils.getIdValue(albumClient.create(albumFactory.create()).getId())) };
		Feed<RelatedAlbum> results = this.relatedAlbumClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedAlbum should be found");
	}

	public void testRelatedAlbumQueryBySourceAlbumIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI albumId = albumClient.create(albumFactory.create()).getId();
		RelatedAlbum expected = this.relatedAlbumClient
				.create(this.relatedAlbumFactory.create(new DataServiceField(RelatedAlbumField.sourceAlbumId, albumId)), new String[] {});
		this.relatedAlbumClient.create(this.relatedAlbumFactory.create());

		Query[] queries = new Query[] { new BySourceAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<RelatedAlbum> results = this.relatedAlbumClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedAlbum should be found");

		RelatedAlbumComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedAlbumQueryBySourceAlbumIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI albumId = albumClient.create(albumFactory.create()).getId();
		this.relatedAlbumClient.create(this.relatedAlbumFactory.create());

		List<RelatedAlbum> expectedRelatedAlbums = this.relatedAlbumClient.create(
				this.relatedAlbumFactory.create(2, new DataServiceField(RelatedAlbumField.sourceAlbumId, albumId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new BySourceAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<RelatedAlbum> results = this.relatedAlbumClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedAlbums should be found");

		Map<URI, RelatedAlbum> resultMap = new HashMap<>();
		for (RelatedAlbum relatedAlbum : results.getEntries())
			resultMap.put(relatedAlbum.getId(), relatedAlbum);

		for (RelatedAlbum expected : expectedRelatedAlbums)
			RelatedAlbumComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	public void testRelatedAlbumQueryByTargetAlbumIdNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedAlbumClient.create(this.relatedAlbumFactory.create());
		Query[] queries = new Query[] { new ByTargetAlbumId(URIUtils.getIdValue(albumClient.create(albumFactory.create()).getId())) };
		Feed<RelatedAlbum> results = this.relatedAlbumClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedAlbum should be found");
	}

	public void testRelatedAlbumQueryByTargetAlbumIdOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		URI albumId = albumClient.create(albumFactory.create()).getId();
		RelatedAlbum expected = this.relatedAlbumClient
				.create(this.relatedAlbumFactory.create(new DataServiceField(RelatedAlbumField.targetAlbumId, albumId)), new String[] {});
		this.relatedAlbumClient.create(this.relatedAlbumFactory.create());

		Query[] queries = new Query[] { new ByTargetAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<RelatedAlbum> results = this.relatedAlbumClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedAlbum should be found");

		RelatedAlbumComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedAlbumQueryByTargetAlbumIdMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		URI albumId = albumClient.create(albumFactory.create()).getId();
		this.relatedAlbumClient.create(this.relatedAlbumFactory.create());

		List<RelatedAlbum> expectedRelatedAlbums = this.relatedAlbumClient.create(
				this.relatedAlbumFactory.create(2, new DataServiceField(RelatedAlbumField.targetAlbumId, albumId)), new String[] {}).getEntries();
		Query[] queries = new Query[] { new ByTargetAlbumId(URIUtils.getIdValue(albumId)) };
		Feed<RelatedAlbum> results = this.relatedAlbumClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedAlbums should be found");

		Map<URI, RelatedAlbum> resultMap = new HashMap<>();
		for (RelatedAlbum relatedAlbum : results.getEntries())
			resultMap.put(relatedAlbum.getId(), relatedAlbum);

		for (RelatedAlbum expected : expectedRelatedAlbums)
			RelatedAlbumComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

	// No type query because there is only one type and type is required

	public void testRelatedAlbumQueryByMerlinResourceTypeNoMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		this.relatedAlbumClient.create(this.relatedAlbumFactory.create(new DataServiceField(RelatedAlbumField.merlinResourceType, MerlinResourceType.AudienceAvailable)));
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		Feed<RelatedAlbum> results = this.relatedAlbumClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 0, "No RelatedAlbum should be found");
	}

	public void testRelatedAlbumQueryByMerlinResourceTypeOneMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {

		RelatedAlbum expected = this.relatedAlbumClient.create(
				this.relatedAlbumFactory.create(new DataServiceField(RelatedAlbumField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {});
		this.relatedAlbumClient.create(this.relatedAlbumFactory.create(new DataServiceField(RelatedAlbumField.merlinResourceType, MerlinResourceType.Editorial)));

		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<RelatedAlbum> results = this.relatedAlbumClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 1, "Exact one RelatedAlbum should be found");

		RelatedAlbumComparator.assertEquals(results.getEntries().get(0), expected);
	}

	public void testRelatedAlbumQueryByMerlinResourceTypeMultipleMatch() throws IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		this.relatedAlbumClient.create(this.relatedAlbumFactory.create(new DataServiceField(RelatedAlbumField.merlinResourceType, MerlinResourceType.Editorial)));
		List<RelatedAlbum> expectedRelatedAlbums = this.relatedAlbumClient.create(
				this.relatedAlbumFactory.create(2, new DataServiceField(RelatedAlbumField.merlinResourceType, MerlinResourceType.AudienceAvailable)), new String[] {})
				.getEntries();
		Query[] queries = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		Feed<RelatedAlbum> results = this.relatedAlbumClient.getAll(null, queries, null, null, null);
		Assert.assertEquals(results.getEntries().size(), 2, "Exact two RelatedAlbums should be found");

		Map<URI, RelatedAlbum> resultMap = new HashMap<>();
		for (RelatedAlbum relatedAlbum : results.getEntries()) {
			resultMap.put(relatedAlbum.getId(), relatedAlbum);
		}

		for (RelatedAlbum expected : expectedRelatedAlbums)
			RelatedAlbumComparator.assertEquals(resultMap.get(expected.getId()), expected);
	}

}
