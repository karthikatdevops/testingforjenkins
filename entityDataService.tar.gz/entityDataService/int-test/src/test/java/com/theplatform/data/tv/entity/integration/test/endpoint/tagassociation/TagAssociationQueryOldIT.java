package com.theplatform.data.tv.entity.integration.test.endpoint.tagassociation;

import static org.testng.Assert.assertEquals;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.theplatform.contrib.data.api.client.query.ByMerlinResourceType;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.Sort;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.persistence.translator.converter.LocalUriConverter;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.client.query.ByEntityId;
import com.theplatform.data.tv.tag.api.client.query.ByEntityType;
import com.theplatform.data.tv.tag.api.client.query.ByTagId;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.test.TagAssociationComparator;

/**
 * 
 */
@Test(groups = { "tagAssociation", "query", TestGroup.testBug })
public class TagAssociationQueryOldIT extends EntityTestBase {
	private List<TagAssociation> inputTagAssociations;
	private List<TagAssociation> editorialTagAssociations;
	private List<TagAssociation> nonEditorialTagAssociations;
	private List<TagAssociation> inputTagAssociationsInAscOrder;
	public static final int NUM_TAG_ASSOCIATIONS = 15;
	public static final int NUM_EDITORIAL_TAG_ASSOCIATIONS = 5;
	public static final int NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS = NUM_TAG_ASSOCIATIONS - NUM_EDITORIAL_TAG_ASSOCIATIONS;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws UnknownHostException {

		inputTagAssociations = this.tagAssociationFactory.create(15);

		// nothing now

		inputTagAssociations.get(0).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227500"));
		inputTagAssociations.get(1).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227400"));
		inputTagAssociations.get(2).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227401"));
		inputTagAssociations.get(3).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227501"));
		inputTagAssociations.get(4).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227402"));
		inputTagAssociations.get(5).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227403"));
		inputTagAssociations.get(6).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227600"));
		inputTagAssociations.get(7).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227601"));
		inputTagAssociations.get(8).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227602"));
		inputTagAssociations.get(9).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227502"));
		inputTagAssociations.get(10).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227603"));
		inputTagAssociations.get(11).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227503"));
		inputTagAssociations.get(12).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227604"));
		inputTagAssociations.get(13).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227599"));
		inputTagAssociations.get(14).setId(URI.create(this.getBaseUrl() + "/data/TagAssociation/" + "6536839374452227605"));

		nonEditorialTagAssociations = new ArrayList<>(10);
		nonEditorialTagAssociations.add(inputTagAssociations.get(1));
		nonEditorialTagAssociations.add(inputTagAssociations.get(2));
		nonEditorialTagAssociations.add(inputTagAssociations.get(4));
		nonEditorialTagAssociations.add(inputTagAssociations.get(5));
		nonEditorialTagAssociations.add(inputTagAssociations.get(6));
		nonEditorialTagAssociations.add(inputTagAssociations.get(7));
		nonEditorialTagAssociations.add(inputTagAssociations.get(8));
		nonEditorialTagAssociations.add(inputTagAssociations.get(10));
		nonEditorialTagAssociations.add(inputTagAssociations.get(12));
		nonEditorialTagAssociations.add(inputTagAssociations.get(14));

		editorialTagAssociations = new ArrayList<>(5);
		editorialTagAssociations.add(inputTagAssociations.get(0));
		editorialTagAssociations.add(inputTagAssociations.get(3));
		editorialTagAssociations.add(inputTagAssociations.get(9));
		editorialTagAssociations.add(inputTagAssociations.get(11));
		editorialTagAssociations.add(inputTagAssociations.get(13));

		inputTagAssociationsInAscOrder = new ArrayList<>(15);
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(1));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(2));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(4));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(5));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(0));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(3));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(9));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(11));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(13));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(6));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(7));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(8));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(10));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(12));
		inputTagAssociationsInAscOrder.add(inputTagAssociations.get(14));

		this.tagAssociationClient.create(inputTagAssociations);
	}


	@Test
	public void testQueryEditorialTagAssociationByMerlinResourceType() throws UnknownHostException {
		// query
		Query queries[] = new Query[] { new ByMerlinResourceType(MerlinResourceType.Editorial) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.getAll(null, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_EDITORIAL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations using query ByMerlinResourceType=Editorial");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_EDITORIAL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count using query ByMerlinResourceType=Editorial");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_EDITORIAL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total entry count using query ByMerlinResourceType=Editorial");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, editorialTagAssociations);
	}

	public void testQueryAudienceTagAssociationByMerlinResourceType() {
		// query
		Query queries[] = new Query[] { new ByMerlinResourceType(MerlinResourceType.AudienceAvailable) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.getAll(null, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations using query ByMerlinResourceType=AudienceAvailable");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count using query ByMerlinResourceType=AudienceAvailable");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total entry count using query ByMerlinResourceType=AudienceAvailable");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);
	}

	@Test(groups = { "other" })
	public void testQueryAllTagAssociationByMerlinResourceType() {
		// query
		Query queries[] = new Query[] { new ByMerlinResourceType(Arrays.asList(new MerlinResourceType[] { MerlinResourceType.Editorial,
				MerlinResourceType.AudienceAvailable })) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.getAll(null, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_TAG_ASSOCIATIONS,
				"Not get all Tag Associations using query ByMerlinResourceType=AudienceAvailable & Editorial");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count using query ByMerlinResourceType=AudienceAvailable & Editorial");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_TAG_ASSOCIATIONS,
				"Not get Tag Associations total entry count using query ByMerlinResourceType=AudienceAvailable & Editorial");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, inputTagAssociationsInAscOrder);
	}

	public void testGetTagAssociationsByIdsAndNullQueries() {
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.get(tagAssociationIds, new String[] {}, null, sorts, null);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. get byIds & query null");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. get byIds & query null");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);
	}

	@Test(groups = { "other" })
	public void testGetTagAssociationsByIds() {
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.get(tagAssociationIds, new String[] {});
		assertEquals(retrievedIAs.getEntries().size(), NUM_TAG_ASSOCIATIONS, "Not get all Tag Associations with out using ByMerlinResourceType i.e. get byIds");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. get byIds");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, inputTagAssociations);
	}

	public void testGetTagAssociationsById() {
		TagAssociation retrievedIA = this.tagAssociationClient.get(inputTagAssociations.get(6).getId(), new String[] {});
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIA, inputTagAssociations.get(6));
	}

	public void testGetTagAssociationsByIdsAndByEntityIds() {
		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] tagAssociationIds = (URI[]) CollectionUtils.collect(inputTagAssociations, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});
		List<Long> entityIds = new ArrayList<>();
		for (TagAssociation tagAssociation : inputTagAssociations) {
			entityIds.add(LocalUriConverter.convertUriToID(tagAssociation.getEntityId()));
		}
		// query
		Query queries[] = new Query[] { new ByEntityId(entityIds) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.get(tagAssociationIds, new String[] {}, queries, sorts, null);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. get byIds & byEntityId");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. get byIds & byEntityId");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);
	}

	public void testGetTagAssociationsByEntityId() {
		List<Long> entityIds = new ArrayList<>();
		for (TagAssociation tagAssociation : inputTagAssociations) {
			entityIds.add(LocalUriConverter.convertUriToID(tagAssociation.getEntityId()));
		}
		// query
		Query queries[] = new Query[] { new ByEntityId(entityIds) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.getAll(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. getAll ByEntityId");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. getAll ByEntityId");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total results with out using ByMerlinResourceType i.e. getAll ByEntityId");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);

		retrievedIAs = this.tagAssociationClient.getOwned(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. getOwned ByEntityId");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. getOwned ByEntityId");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total results with out using ByMerlinResourceType i.e. getOwned ByEntityId");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);
	}

	public void testGetTagAssociationsByEntityType() {
		List<String> entityTypes = new ArrayList<>();
		entityTypes.add("Program");
		entityTypes.add("Station");
		// query
		Query queries[] = new Query[] { new ByEntityType(entityTypes) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.getAll(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. getAll byEntityType ");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. getAll byEntityType ");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total results with out using ByMerlinResourceType i.e. getAll byEntityType ");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);

		retrievedIAs = this.tagAssociationClient.getOwned(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. getOwned byEntityType ");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. getOwned byEntityType ");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total results with out using ByMerlinResourceType i.e. getOwned byEntityType ");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);
	}

	public void testGetTagAssociationsByTagIds() {
		List<Long> tagIds = new ArrayList<>();
		for (TagAssociation tagAssociation : inputTagAssociations) {
			tagIds.add(LocalUriConverter.convertUriToID(tagAssociation.getTagId()));
		}
		// query
		Query queries[] = new Query[] { new ByTagId(tagIds) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.getAll(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. getAll ByTagIds ");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. getAll ByTagIds ");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total results with out using ByMerlinResourceType i.e. getAll ByTagIds ");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);

		retrievedIAs = this.tagAssociationClient.getOwned(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. getOwned ByTagIds ");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. getOwned ByTagIds ");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total results with out using ByMerlinResourceType i.e. getOwned ByTagIds ");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);
	}

	public void testGetTagAssociationsByEntityIds() {
		List<Long> entityIds = new ArrayList<>();
		for (TagAssociation tagAssociation : inputTagAssociations) {
			entityIds.add(LocalUriConverter.convertUriToID(tagAssociation.getEntityId()));
		}
		// query
		Query queries[] = new Query[] { new ByEntityId(entityIds) };
		// sort
		Sort sorts[] = new Sort[] { new Sort("id", false) };
		Feed<TagAssociation> retrievedIAs = this.tagAssociationClient.getAll(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. getAll byEntityId ");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. getAll byEntityId ");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total results with out using ByMerlinResourceType i.e. getAll byEntityId ");

		retrievedIAs = this.tagAssociationClient.getOwned(new String[] {}, queries, sorts, null, true);
		assertEquals(retrievedIAs.getEntries().size(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get all Tag Associations with out using ByMerlinResourceType i.e. getOwned byEntityId ");
		assertEquals(retrievedIAs.getEntryCount().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations entry count with out using ByMerlinResourceType i.e. getOwned byEntityId ");
		assertEquals(retrievedIAs.getTotalResults().longValue(), NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS,
				"Not get Tag Associations total results with out using ByMerlinResourceType i.e. getOwned byEntityId ");
		// to make comparison for all fields
		TagAssociationComparator.assertEquals(retrievedIAs, nonEditorialTagAssociations);
	}

	@Test(groups = { "other" })
	public void testDeleteTagAssociationsById() {
		URI tagAssociationId = inputTagAssociations.get(0).getId();
		long count = this.tagAssociationClient.delete(tagAssociationId);
		assertEquals(count, 1, "Not delete TagAssociation using tag association id");
	}

	@Test(groups = { "other" })
	public void testDeleteTagAssociationsByIds() {
		URI[] tagAssociationIds = new URI[3];
		tagAssociationIds[0] = inputTagAssociations.get(1).getId();
		tagAssociationIds[1] = inputTagAssociations.get(3).getId();
		tagAssociationIds[2] = inputTagAssociations.get(12).getId();

		long count = this.tagAssociationClient.delete(tagAssociationIds);
		assertEquals(count, 3, "Not deleted all Tag Associations using byIds");
	}

	@Test(groups = { "other" })
	public void testDeleteTagAssociationsByEntityId() {
		List<Long> entityIds = new ArrayList<>();
		entityIds.add(LocalUriConverter.convertUriToID(inputTagAssociations.get(2).getEntityId()));
		entityIds.add(LocalUriConverter.convertUriToID(inputTagAssociations.get(4).getEntityId()));
		entityIds.add(LocalUriConverter.convertUriToID(inputTagAssociations.get(5).getEntityId()));
		entityIds.add(LocalUriConverter.convertUriToID(inputTagAssociations.get(9).getEntityId()));
		// query
		Query queries[] = new Query[] { new ByEntityId(entityIds) };
		long count = this.tagAssociationClient.delete(queries);
		assertEquals(count, 3, "Not delete TagAssociation using byEntityId query");
	}

	@Test(groups = { "other" })
	public void testDeleteTagAssociationsByTagId() {
		List<Long> tagIds = new ArrayList<>();
		tagIds.add(LocalUriConverter.convertUriToID(inputTagAssociations.get(6).getTagId()));
		tagIds.add(LocalUriConverter.convertUriToID(inputTagAssociations.get(11).getTagId()));
		tagIds.add(LocalUriConverter.convertUriToID(inputTagAssociations.get(13).getTagId()));
		tagIds.add(LocalUriConverter.convertUriToID(inputTagAssociations.get(7).getTagId()));
		tagIds.add(LocalUriConverter.convertUriToID(inputTagAssociations.get(14).getTagId()));
		// query
		Query queries[] = new Query[] { new ByTagId(tagIds) };
		long count = this.tagAssociationClient.delete(queries);
		assertEquals(count, 3, "Not delete TagAssociation using byTagId query");
	}

	@Test(groups = { "other" })
	public void testDeleteTagAssociationsByEntityType() {
		List<String> entityTypes = new ArrayList<>();
		entityTypes.add("Program");
		entityTypes.add("Station");
		// query
		Query queries[] = new Query[] { new ByEntityType(entityTypes) };
		long count = this.tagAssociationClient.delete(queries);
		assertEquals(count, NUM_AUDIENCE_AVAIL_TAG_ASSOCIATIONS, "Not delete TagAssociation using byEntityType query");
	}

}
