package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.api.objects.NamespacedField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author jethrolai
 * @since 1/24/2012 TODO groups change back to core and SprintN when Entity
 *        debugging is done
 */
@Test(groups = { "program" })
public class ProgramContentRatingsIT extends EntityTestBase {

    @Test(groups = { TestGroup.gbTest })
	public void testProgramAddingFirstMPAAContentRatingAfterCreate() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		program.setContentRatings(null);

		Program retrievedProgram = programClient.create(program, new String[] {});

		Assert.assertTrue(retrievedProgram.getContentRatings().isEmpty());

		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating);
		program.setContentRatings(contentRatings);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramAddingFirstVChipContentRatingAfterCreate() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		program.setContentRatings(null);

		Program retrievedProgram = programClient.create(program, new String[] {});

		Assert.assertTrue(retrievedProgram.getContentRatings().isEmpty());

		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramAddingSecondMPAAContentRatingAfterCreate() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating1 = new Rating();
		mpaaRating1.setRating("R");
		mpaaRating1.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating1);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});
		ProgramComparator.assertEquals(retrievedProgram, program);

		Rating mpaaRating2 = new Rating();
		mpaaRating2.setRating("R");
		mpaaRating2.setScheme("urn:mpaa");
		program.getContentRatings().add(mpaaRating2);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramAddingSecondVChipContentRatingAfterCreate() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating vChipRating1 = new Rating();
		vChipRating1.setRating("TVMA");
		vChipRating1.setScheme("urn:v-chip");
		contentRatings.add(vChipRating1);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});
		ProgramComparator.assertEquals(retrievedProgram, program);

		Rating vChipRating2 = new Rating();
		vChipRating2.setRating("TVMA");
		vChipRating2.setScheme("urn:v-chip");
		program.getContentRatings().add(vChipRating2);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramAddingFirstMPAAContentRatingAfterCreateWithFirstVChip() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);

		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		program.getContentRatings().add(mpaaRating);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramAddingFirstVChipContentRatingAfterCreateWithFirstMPAA() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		program.getContentRatings().add(vChipRating);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramAddingSecondMPAAContentRatingAfterCreateWithFirstVChipAndMPAA() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		contentRatings.add(vChipRating);

		Rating mpaaRating1 = new Rating();
		mpaaRating1.setRating("R");
		mpaaRating1.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating1);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);

		Rating mpaaRating2 = new Rating();
		mpaaRating2.setRating("R");
		mpaaRating2.setScheme("urn:mpaa");
		program.getContentRatings().add(mpaaRating2);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramAddingSecondVChipContentRatingAfterCreateWithFirstVChipAndMPAA() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating vChipRating1 = new Rating();
		vChipRating1.setRating("TVMA");
		vChipRating1.setScheme("urn:v-chip");
		contentRatings.add(vChipRating1);
		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);

		Rating vChipRating2 = new Rating();
		vChipRating2.setRating("TVMA");
		vChipRating2.setScheme("urn:v-chip");
		program.getContentRatings().add(vChipRating2);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramHasOneMPAAContentRating() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});
		program.setOwnerId(retrievedProgram.getOwnerId());
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramHasOneVChipContentRating() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});
		program.setOwnerId(retrievedProgram.getOwnerId());
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramHasOneVChipOneMPAAContentRating() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating);
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});
		program.setOwnerId(retrievedProgram.getOwnerId());
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramHasTwoMPAAContentRating() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating1 = new Rating();
		mpaaRating1.setRating("R");
		mpaaRating1.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating1);
		Rating mpaaRating2 = new Rating();
		mpaaRating2.setRating("R");
		mpaaRating2.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating2);
		program.setContentRatings(contentRatings);
		programClient.create(program, new String[] {});

		Assert.fail("A program cannot have two mpaa ratings in contentRatings");
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramHasTwoVChipContentRating() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();

		Rating vChipRating1 = new Rating();
		vChipRating1.setRating("TVMA");
		vChipRating1.setScheme("urn:v-chip");
		contentRatings.add(vChipRating1);
		Rating vChipRating2 = new Rating();
		vChipRating2.setRating("TVMA");
		vChipRating2.setScheme("urn:v-chip");
		contentRatings.add(vChipRating2);
		program.setContentRatings(contentRatings);
		programClient.create(program, new String[] {});

		Assert.fail("A program cannot have two v-chip ratings in contentRatings");
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramHasTwoMPAAOneVChipContentRating() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating1 = new Rating();
		mpaaRating1.setRating("R");
		mpaaRating1.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating1);
		Rating mpaaRating2 = new Rating();
		mpaaRating2.setRating("R");
		mpaaRating2.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating2);
		Rating vChipRating1 = new Rating();
		vChipRating1.setRating("TVMA");
		vChipRating1.setScheme("urn:v-chip");
		contentRatings.add(vChipRating1);
		program.setContentRatings(contentRatings);
		programClient.create(program, new String[] {});

		Assert.fail("A program cannot have two mpaa ratings in contentRatings");
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramHasTwoVChipOneMPAAContentRating() {
		Program program = this.programFactory.create(new DataServiceField(ProgramField.type,ProgramType.Concert),
                new DataServiceField(ProgramField.local, false), new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable),
                new DataServiceField(ProgramField.listByTitle, true), new DataServiceField(ProgramField.credits, new ArrayList<CreditAssociation>()));
		List<Rating> contentRatings = new ArrayList<Rating>();

		Rating vChipRating1 = new Rating();
		vChipRating1.setRating("TVMA");
		vChipRating1.setScheme("urn:v-chip");
		contentRatings.add(vChipRating1);
		Rating vChipRating2 = new Rating();
		vChipRating2.setRating("TVMA");
		vChipRating2.setScheme("urn:v-chip");
		contentRatings.add(vChipRating2);
		Rating mpaaRating1 = new Rating();
		mpaaRating1.setRating("R");
		mpaaRating1.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating1);
		program.setContentRatings(contentRatings);
		programClient.create(program, new String[] {});

		Assert.fail("A program cannot have two v-chip ratings in contentRatings");
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingMovieMPAAAndVChip() {
		Program program = this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating);
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingMovieNoMPAAButHasVChip() {
		Program program = this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	// TODO if all non movie types should be tested
	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingNonMovieMPAAAndVChip() {
		Program program = this.episodeProgramFactory.create(new DataServiceField(ProgramField.type, ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating);
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	// TODO if all non movie types should be tested
	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingNonMovieNoVChipButHasMPAA() {
		Program program = this.episodeProgramFactory.create(new DataServiceField(ProgramField.type, ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable));
		List<Rating> contentRatings = new ArrayList<Rating>();
		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		contentRatings.add(mpaaRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	// tests below are update cases for Program.contentRating

	@DataProvider
	private Object[][] nonMovieProgramTypes() {
		List<Object[]> nonMovieProgramTypeList = new ArrayList<Object[]>();
		for (ProgramType type : ProgramType.values()) {
			if (type != ProgramType.Movie) {
				nonMovieProgramTypeList.add(new Object[] { type });
			}
		}
		Object[][] argumentArray = new Object[nonMovieProgramTypeList.size()][];
		nonMovieProgramTypeList.toArray(argumentArray);
		return argumentArray;
	}

	private Rating getMPAARating() {
		Rating mpaaRating = new Rating();
		mpaaRating.setRating("R");
		mpaaRating.setScheme("urn:mpaa");
		return mpaaRating;
	}

	private Rating getVChipRating() {
		Rating vChipRating = new Rating();
		vChipRating.setRating("TVMA");
		vChipRating.setScheme("urn:v-chip");
		return vChipRating;
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingHasBothRemoveMPAAProgramTypeMovie() {
		testProgramContentRatingHasBothRemoveMPAA(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                        new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
                getMPAARating(), getVChipRating(), getMPAARating(),getVChipRating());
	}

	// @Test(groups = { TestGroup.gbTest }, dataProvider="nonMovieProgramTypes"
	// ) //not using all types for shortening the testing time
	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingHasBothRemoveMPAAProgramTypeNonMovie() {
		testProgramContentRatingHasBothRemoveMPAA(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                        new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
                getMPAARating(), getVChipRating(), getVChipRating(), getVChipRating());
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingHasBothRemoveMPAA(Program program, Rating mpaaRating, Rating vChipRating, Rating resultCreate, Rating resultUpdate) {

		List<Rating> contentRatings = new ArrayList<Rating>();
		contentRatings.add(mpaaRating);
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(new ArrayList<Rating>());
		program.getContentRatings().add(vChipRating);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingHasBothRemoveVChipProgramTypeMovie() {
		testProgramContentRatingHasBothRemoveVChip(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                        new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), getVChipRating(), getMPAARating(),
				getMPAARating());
	}

	// @Test(groups = { TestGroup.gbTest }, dataProvider="nonMovieProgramTypes"
	// ) //not using all types for shortening the testing time
	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingHasBothRemoveVChipProgramTypeNonMovie() {
		testProgramContentRatingHasBothRemoveVChip(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                        new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), getVChipRating(),
				getVChipRating(), getMPAARating());
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingHasBothRemoveVChip(Program program, Rating mpaaRating, Rating vChipRating, Rating resultCreate, Rating resultUpdate) {

		List<Rating> contentRatings = new ArrayList<Rating>();
		contentRatings.add(mpaaRating);
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(new ArrayList<Rating>());
		program.getContentRatings().add(mpaaRating);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	public void testProgramContentRatingHasBothRemoveBothProgramTypeMovie() {
		testProgramContentRatingHasBothRemoveBoth(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                        new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
                getMPAARating(), getVChipRating(), null);
	}

	public void testProgramContentRatingHasBothRemoveBothProgramTypeNonMovie() {
		testProgramContentRatingHasBothRemoveBoth(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type, ProgramType.Episode),
                        new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)),
                getMPAARating(), getVChipRating(), null);
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingHasBothRemoveBoth(Program program, Rating mpaaRating, Rating vChipRating, Rating result) {

		List<Rating> contentRatings = new ArrayList<Rating>();
		contentRatings.add(mpaaRating);
		vChipRating.setScheme("urn:v-chip");
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(null);
        program.setNullFields(new NamespacedField[]{ProgramField.contentRatings});
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	// FIXME @see MERLIN-6799
	public void testProgramContentRatingNoRatingAddMPAAProgramTypeMovie() {
		testProgramContentRatingNoRatingAddMPAA(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.local, false),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating());
	}

	// @Test(groups = { TestGroup.gbTest }, dataProvider="nonMovieProgramTypes"
	// ) //not using all types for shortening the testing time
	// FIXME @see MERLIN-6799
	public void testProgramContentRatingNoRatingAddMPAAProgramTypeNonMovie() {
		testProgramContentRatingNoRatingAddMPAA(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.local,false),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating());
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingNoRatingAddMPAA(Program program, Rating mpaaRating) {

		List<Rating> contentRatings = new ArrayList<Rating>();

		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(new ArrayList<Rating>());
		program.getContentRatings().add(mpaaRating);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	// FIXME @see MERLIN-6799
	public void testProgramContentRatingNoRatingAddVChipProgramTypeMovie() {
		testProgramContentRatingNoRatingAddVChip(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.local, false),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getVChipRating());
	}

	// @Test(groups = { TestGroup.gbTest }, dataProvider="nonMovieProgramTypes"
	// ) //not using all types for shortening the testing time
	// FIXME @see MERLIN-6799
	public void testProgramContentRatingNoRatingAddVChipProgramTypeNonMovie() {
		testProgramContentRatingNoRatingAddVChip(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)
               ), getVChipRating());
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingNoRatingAddVChip(Program program, Rating vchipRating) {

		List<Rating> contentRatings = new ArrayList<Rating>();

		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(new ArrayList<Rating>());
		program.getContentRatings().add(vchipRating);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	// FIXME @see MERLIN-6799
	public void testProgramContentRatingNoRatingAddBothProgramTypeMovie() {
		testProgramContentRatingNoRatingAddBoth(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), getVChipRating(), getMPAARating());
	}

	// @Test(groups = { TestGroup.gbTest }, dataProvider="nonMovieProgramTypes"
	// ) //not using all types for shortening the testing time
	// FIXME @see MERLIN-6799
	public void testProgramContentRatingNoRatingAddBothProgramTypeNonMovie() {
		testProgramContentRatingNoRatingAddBoth(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), getVChipRating(), getVChipRating());
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingNoRatingAddBoth(Program program, Rating mpaaRating, Rating vchipRating, Rating result) {

		List<Rating> contentRatings = new ArrayList<Rating>();

		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(new ArrayList<Rating>());
		program.getContentRatings().add(mpaaRating);
		program.getContentRatings().add(vchipRating);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingHasMPAAAddVChipProgramTypeMovie() {
		testProgramContentRatingHasMPAAAddVChip(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), getVChipRating(), getMPAARating());
	}

	// @Test(groups = { TestGroup.gbTest }, dataProvider="nonMovieProgramTypes"
	// ) //not using all types for shortening the testing time
	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingHasMPAAAddVChipProgramTypeNonMovie() {
		testProgramContentRatingHasMPAAAddVChip(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), getVChipRating(), getVChipRating());
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingHasMPAAAddVChip(Program program, Rating mpaaRating, Rating vChipRating, Rating result) {

		List<Rating> contentRatings = new ArrayList<Rating>();
		contentRatings.add(mpaaRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(new ArrayList<Rating>());
		program.getContentRatings().add(mpaaRating);
		program.getContentRatings().add(vChipRating);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	public void testProgramContentRatingHasMPAARemoveMPAAProgramTypeMovie() {
		testProgramContentRatingHasMPAARemoveMPAA(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), null);
	}

	public void testProgramContentRatingHasMPAARemoveMPAAProgramTypeNonMovie() {
		testProgramContentRatingHasMPAARemoveMPAA(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), null);
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingHasMPAARemoveMPAA(Program program, Rating mpaaRating, Rating result) {

		List<Rating> contentRatings = new ArrayList<Rating>();
		contentRatings.add(mpaaRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(null);
        program.setNullFields(new NamespacedField[]{ProgramField.contentRatings});
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingHasVChipAddMPAAProgramTypeMovie() {
		testProgramContentRatingHasVChipAddMPAA(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), getVChipRating(), getMPAARating());
	}

	// @Test(groups = { TestGroup.gbTest }, dataProvider="nonMovieProgramTypes"
	// ) //not using all types for shortening the testing time
	@Test(groups = { TestGroup.gbTest })
	public void testProgramContentRatingHasVChipAddMPAAProgramTypeNonMovie() {
		testProgramContentRatingHasVChipAddMPAA(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getMPAARating(), getVChipRating(), getVChipRating());
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingHasVChipAddMPAA(Program program, Rating mpaaRating, Rating vChipRating, Rating result) {

		List<Rating> contentRatings = new ArrayList<Rating>();
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(new ArrayList<Rating>());
		program.getContentRatings().add(mpaaRating);
		program.getContentRatings().add(vChipRating);
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

	public void testProgramContentRatingHasVChipRemoveVChipProgramTypeMovie() {
		testProgramContentRatingHasVChipRemoveVChip(this.movieProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Movie),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getVChipRating(), null);
	}

	public void testProgramContentRatingHasVChipRemoveVChipProgramTypeNonMovie() {
		testProgramContentRatingHasVChipRemoveVChip(this.episodeProgramFactory.create(new DataServiceField(ProgramField.type,ProgramType.Episode),
                new DataServiceField(ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable)), getVChipRating(), null);
	}

	/**
	 * 
	 * @param program
	 *            program should be an un persisted instance of Program endpoint
	 */
	private void testProgramContentRatingHasVChipRemoveVChip(Program program, Rating vChipRating, Rating result) {

		List<Rating> contentRatings = new ArrayList<Rating>();
		contentRatings.add(vChipRating);
		program.setContentRatings(contentRatings);
		Program retrievedProgram = programClient.create(program, new String[] {});

		ProgramComparator.assertEquals(retrievedProgram, program);
		program.setContentRatings(null);
        program.setNullFields(new NamespacedField[]{ProgramField.contentRatings});
		program.setImageIds(null);
		program.setTagIds(null);
		program.setSelectedImages(null);
		program.setCredits(null);
		programClient.update(program);
		program.setImageIds(new ArrayList<URI>());
		program.setTagIds(new ArrayList<URI>());
		program.setSelectedImages(new ArrayList<MainImageInfo>());
		program.setCredits(new ArrayList<CreditAssociation>());
		retrievedProgram = programClient.get(retrievedProgram.getId(), null);
		ProgramComparator.assertEquals(retrievedProgram, program);
	}

}
