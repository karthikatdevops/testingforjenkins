package com.theplatform.data.tv.entity.integration.test.endpoint.program;

import static org.testng.Assert.assertEquals;

import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.TransformerUtils;
import org.testng.annotations.Test;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.test.ProgramComparator;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.media.api.data.objects.Rating;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author clai200
 * @since 4/7/2011
 */
@Test(groups = { "program", "validation" })
public class ProgramValidationIT extends EntityTestBase {

	// TODO: enable ignore test cases later after fix

	private static final String[] CONTENTRATING_SCHEME_VALUES = { "urn:v-chip", "urn:mpaa" };
	private static final String[] CONTENTRATING_RATING_VALUES_FOR_MPAA = { "R", "NR", "PG13", "G", "PG", "NC17" };
	private static final String[] CONTENTRATING_RATING_VALUES_FOR_VCHIP = { "TVG", "TV14", "TVPG", "TVY", "TVMA", "TVY7" };
	private static final String[] CONTENTRATING_SUBRATING_VALUES_FOR_VCHIP = { "FV", "D", "L", "S", "V" };
	private static final String[] CONTENTRATING_SUBRATING_VALUES_FOR_MPAA = { "AT", "N", "BN", "SS", "SL", "V" };


	/**
	 * 
	 * EDS-1.3 V-001
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 */
	@Test(groups = TestGroup.testBug)
	public void testLegalContentRatingScheme() throws UnknownHostException {
		List<Program> inputPrograms = this.programFactory.create(2);
		inputPrograms.get(0).getContentRatings().get(0).setScheme(CONTENTRATING_SCHEME_VALUES[0]);
		inputPrograms.get(0).getContentRatings().get(0).setRating(CONTENTRATING_RATING_VALUES_FOR_VCHIP[0]);
		inputPrograms.get(0).getContentRatings().get(0).setSubRatings(CONTENTRATING_SUBRATING_VALUES_FOR_VCHIP);
		inputPrograms.get(1).getContentRatings().get(0).setScheme(CONTENTRATING_SCHEME_VALUES[1]);
		inputPrograms.get(1).getContentRatings().get(0).setRating(CONTENTRATING_RATING_VALUES_FOR_MPAA[0]);
		inputPrograms.get(1).getContentRatings().get(0).setSubRatings(CONTENTRATING_SUBRATING_VALUES_FOR_MPAA);

		// create
		Feed<Program> createdPrograms = this.programClient.create(inputPrograms);
		assertEquals(createdPrograms.getEntries().size(), 2, "Content contentRating scheme feed size is different");
		assertEquals(createdPrograms.getEntryCount().longValue(), 2, "Content contentRating scheme feed entry count is different");
		assertEquals(createdPrograms.getTotalResults().longValue(), 2, "Content contentRating scheme feed total result is different");

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// get
		Feed<Program> retrievedPrograms = this.programClient.get(programIds, new String[] {});
		ProgramComparator.assertEquals(retrievedPrograms, inputPrograms);
	}

	/**
	 * 
	 * EDS-1.3 V-002
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 */
	@Test(groups = TestGroup.testBug)
	public void testLegalContentRatingRatingForVChip() throws UnknownHostException {
		List<Program> inputPrograms = this.programFactory.create(6);
		for (int i = 0; i < 6; i++) {
			inputPrograms.get(i).getContentRatings().get(0).setRating(CONTENTRATING_RATING_VALUES_FOR_VCHIP[i]);
		}
		// create
		Feed<Program> createdPrograms = this.programClient.create(inputPrograms);
		assertEquals(createdPrograms.getEntries().size(), 6, "Content contentRating rating (vChip) feed size is different");
		assertEquals(createdPrograms.getEntryCount().longValue(), 6, "Content contentRating rating (vChip) feed entry count is different");
		assertEquals(createdPrograms.getTotalResults().longValue(), 6, "Content contentRating rating (vChip) feed total result is different");

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// get
		Feed<Program> retrievedPrograms = this.programClient.get(programIds, new String[] {});
		ProgramComparator.assertEquals(retrievedPrograms, inputPrograms);
	}

	/**
	 * 
	 * EDS-1.3 V-003
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 */
	@Test(groups = TestGroup.testBug)
	public void testLegalContentRatingRatingForMPAA() throws UnknownHostException {
		List<Program> inputPrograms = this.programFactory.create(6);
		for (int i = 0; i < 6; i++) {
			inputPrograms.get(i).getContentRatings().get(0).setScheme(CONTENTRATING_SCHEME_VALUES[1]);
			inputPrograms.get(i).getContentRatings().get(0).setRating(CONTENTRATING_RATING_VALUES_FOR_MPAA[i]);
			inputPrograms.get(i).getContentRatings().get(0).setSubRatings(CONTENTRATING_SUBRATING_VALUES_FOR_MPAA);
		}
		// create
		Feed<Program> createdPrograms = this.programClient.create(inputPrograms);
		assertEquals(createdPrograms.getEntries().size(), 6, "Content contentRating rating (MPAA) feed size is different");
		assertEquals(createdPrograms.getEntryCount().longValue(), 6, "Content contentRating rating (MPAA) feed entry count is different");
		assertEquals(createdPrograms.getTotalResults().longValue(), 6, "Content contentRating rating (MPAA) feed total result is different");

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// get
		Feed<Program> retrievedPrograms = this.programClient.get(programIds, new String[] {});
		ProgramComparator.assertEquals(retrievedPrograms, inputPrograms);
	}

	/**
	 * 
	 * EDS-1.3 V-004
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 * @throws NoSuchFieldException
	 * @throws NoSuchMethodException
	 * @throws InstantiationException
	 * @throws ClassNotFoundException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 */
	@Test(groups = TestGroup.testBug)
	public void testLegalContentRatingSubRatingForVChip() throws UnknownHostException, IllegalArgumentException, SecurityException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
		List<Program> inputPrograms = this.programFactory.create(5, new DataServiceField("contentRatings", new ArrayList<Rating>()));

		for (int i = 0; i < 5; i++) {
			inputPrograms.get(i).getContentRatings().add(new Rating());
			inputPrograms.get(i).getContentRatings().get(0).setScheme(CONTENTRATING_SCHEME_VALUES[0]);
			inputPrograms.get(i).getContentRatings().get(0).setRating(CONTENTRATING_RATING_VALUES_FOR_VCHIP[i]);
			inputPrograms.get(i).getContentRatings().get(0).setSubRatings(CONTENTRATING_SUBRATING_VALUES_FOR_VCHIP);
		}
		// create
		Feed<Program> createdPrograms = this.programClient.create(inputPrograms);
		assertEquals(createdPrograms.getEntries().size(), 5, "Content contentRating subrating (vChip) feed size is different");
		assertEquals(createdPrograms.getEntryCount().longValue(), 5, "Content contentRating subrating (vChip) feed entry count is different");
		assertEquals(createdPrograms.getTotalResults().longValue(), 5, "Content contentRating subrating (vChip) feed total result is different");

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// get
		Feed<Program> retrievedPrograms = this.programClient.get(programIds, new String[] {});
		ProgramComparator.assertEquals(retrievedPrograms, inputPrograms);
	}

	/**
	 * 
	 * EDS-1.3 V-005
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 */
	@Test(groups = TestGroup.testBug)
	public void testLegalContentRatingSubRatingForMPAA() throws UnknownHostException {
		List<Program> inputPrograms = this.programFactory.create(6);
		for (int i = 0; i < 6; i++) {
			inputPrograms.get(i).getContentRatings().get(0).setScheme(CONTENTRATING_SCHEME_VALUES[1]);
			inputPrograms.get(i).getContentRatings().get(0).setRating(CONTENTRATING_RATING_VALUES_FOR_MPAA[i]);
			inputPrograms.get(i).getContentRatings().get(0).setSubRatings(CONTENTRATING_SUBRATING_VALUES_FOR_MPAA);
		}
		// create
		Feed<Program> createdPrograms = this.programClient.create(inputPrograms);
		assertEquals(createdPrograms.getEntries().size(), 6, "Content contentRating subrating (MPAA) feed size is different");
		assertEquals(createdPrograms.getEntryCount().longValue(), 6, "Content contentRating subrating (MPAA) feed entry count is different");
		assertEquals(createdPrograms.getTotalResults().longValue(), 6, "Content contentRating subrating (MPAA) feed total result is different");

		@SuppressWarnings({ "unchecked", "ToArrayCallWithZeroLengthArrayArgument" })
		URI[] programIds = (URI[]) CollectionUtils.collect(inputPrograms, TransformerUtils.invokerTransformer("getId")).toArray(new URI[] {});

		// get
		Feed<Program> retrievedPrograms = this.programClient.get(programIds, new String[] {});
		ProgramComparator.assertEquals(retrievedPrograms, inputPrograms);
	}

	/**
	 * 
	 * EDS-1.3 V-006
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 */
	@Test(expectedExceptions = ValidationException.class)
	public void testIllegalContentRatingScheme() throws UnknownHostException {
		Program inputProgram = this.programFactory.create();
		Rating rating = new Rating();
		inputProgram.setContentRatings(Arrays.asList(rating));
		inputProgram.getContentRatings().get(0).setScheme("Illegal Content Rating Scheme");
		this.programClient.create(inputProgram);
	}

	/**
	 * 
	 * EDS-1.3 V-007
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 */
	@Test(expectedExceptions = ValidationException.class)
	public void testIllegalContentRatingRatingForVChip() throws UnknownHostException {
		Program inputProgram = this.programFactory.create();
		Rating rating = new Rating();
		inputProgram.setContentRatings(Arrays.asList(rating));
		inputProgram.getContentRatings().get(0).setRating("Illegal Content Rating Rating");
		this.programClient.create(inputProgram);
	}

	/**
	 * 
	 * EDS-1.3 V-008
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 */
	@Test(expectedExceptions = ValidationException.class)
	public void testIllegalContentRatingRatingForMPAA() throws UnknownHostException {
		Program inputProgram = this.programFactory.create();
		Rating rating = new Rating();
		inputProgram.setContentRatings(Arrays.asList(rating));
		inputProgram.getContentRatings().get(0).setScheme(CONTENTRATING_SCHEME_VALUES[1]);
		inputProgram.getContentRatings().get(0).setSubRatings(CONTENTRATING_SUBRATING_VALUES_FOR_MPAA);
		inputProgram.getContentRatings().get(0).setRating("Illegal Content Rating Rating for MPAA");
		this.programClient.create(inputProgram);
	}

	/**
	 * 
	 * EDS-1.3 V-009
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 */
	@Test(expectedExceptions = ValidationException.class)
	public void testIllegalContentRatingSubratingsForVChip() throws UnknownHostException {
		Program inputProgram = this.programFactory.create();
		Rating rating = new Rating();
		inputProgram.setContentRatings(Arrays.asList(rating));
		String[] invalidSubRatings = { "Illegal Content Rating SubRating for VChip A", "Illegal Content Rating SubRating for VChip B",
				"Illegal Content Rating SubRating for VChip C" };
		inputProgram.getContentRatings().get(0).setSubRatings(invalidSubRatings);
		this.programClient.create(inputProgram);
	}

	/**
	 * 
	 * EDS-1.3 V-010
	 * 
	 * @throws UnknownHostException
	 *             if any issue creating program client
	 */
	@Test(expectedExceptions = ValidationException.class)
	public void testIllegalContentRatingSubratingsForMPAA() throws UnknownHostException {
		Program inputProgram = this.programFactory.create();
		Rating rating = new Rating();
		inputProgram.setContentRatings(Arrays.asList(rating));
		inputProgram.getContentRatings().get(0).setScheme(CONTENTRATING_SCHEME_VALUES[1]);
		inputProgram.getContentRatings().get(0).setRating(CONTENTRATING_RATING_VALUES_FOR_MPAA[1]);
		String[] invalidSubRatings = { "Illegal Content Rating SubRating for MPAA A", "Illegal Content Rating SubRating for MPAA B",
				"Illegal Content Rating SubRating for MPAA C" };
		inputProgram.getContentRatings().get(0).setSubRatings(invalidSubRatings);
		this.programClient.create(inputProgram);
	}

	// Program.contentRatings validation test will be implemented in
	// GBTestProgramContentRatings
}
