package com.theplatform.data.tv.entity.integration.test.merlinresourcetype;

import java.net.URI;

import org.testng.annotations.Test;

import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.SportsLeague;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.data.objects.TvSeason;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.module.exception.ValidationException;

/**
 * 
 * @author jethrolai
 * @since 9/17/2011
 */
@Test(groups = TestGroup.testBug)
public class MerlinResourceTypeRequirementNoOwnerIdIT extends EntityTestBase {
	// by default, all test data will be removed after class

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testCreditNoOwnerId() {
		Credit credit = new Credit();
		// TODO uncomment this line when the implementation is completed
		// credit.setMerlinResourceType(MerlinResourceType.Editorial);
		this.creditClient.create(credit);

		// TODO uncomment this line when the implementation is completed
		// credit.setMerlinResourceType(MerlinResourceType.Inactive);
		this.creditClient.create(credit);

		credit = this.creditFactory.create();
		// TODO uncomment this line when the implementation is completed
		// credit.setMerlinResourceType(MerlinResourceType.Temporary);
		this.creditClient.create(credit);

		// TODO uncomment this line when the implementation is completed
		// credit.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.creditClient.create(credit);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testPersonNoOwnerId() {
		Person person = new Person();
		// TODO uncomment this line when the implementation is completed
		// person.setMerlinResourceType(MerlinResourceType.Editorial);
		this.personClient.create(person);

		// TODO uncomment this line when the implementation is completed
		// person.setMerlinResourceType(MerlinResourceType.Inactive);
		this.personClient.create(person);

		person = this.personFactory.create();
		// TODO uncomment this line when the implementation is completed
		// person.setMerlinResourceType(MerlinResourceType.Temporary);
		this.personClient.create(person);

		// TODO uncomment this line when the implementation is completed
		// person.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.personClient.create(person);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramNoOwnerId() {
		Program program = new Program();
		program.setType(ProgramType.Concert);
		// TODO uncomment this line when the implementation is completed
		// program.setMerlinResourceType(MerlinResourceType.Editorial);
		this.programClient.create(program);

		// TODO uncomment this line when the implementation is completed
		// program.setMerlinResourceType(MerlinResourceType.Inactive);
		this.programClient.create(program);

		program = this.programFactory.create();
		// TODO uncomment this line when the implementation is completed
		// program.setMerlinResourceType(MerlinResourceType.Temporary);
		this.programClient.create(program);

		// TODO uncomment this line when the implementation is completed
		// program.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.programClient.create(program);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramMediaAssociationNoOwnerId() {
		ProgramMediaAssociation programMediaAssociation = new ProgramMediaAssociation();
//		programMediaAssociation.setOwnerId(URI.create(this.getOwnerId()));
		// TODO uncomment this line when the implementation is completed
		// //
		// programMediaAssociation.setMerlinResourceType(MerlinResourceType.Editorial);
		// this.programMediaAssociationClient.create(programMediaAssociation);
		//
		// // TODO uncomment this line when the implementation is completed
		// //
		// programMediaAssociation.setMerlinResourceType(MerlinResourceType.Inactive);
		// this.programMediaAssociationClient.create(programMediaAssociation);
		//
		// programMediaAssociation =
		// this.programMediaAssociationFactory.createProgramMediaAssociation();
		// // TODO uncomment this line when the implementation is completed
		// //
		// programMediaAssociation.setMerlinResourceType(MerlinResourceType.Temporary);
		// this.programMediaAssociationClient.create(programMediaAssociation);
		//
		// // TODO uncomment this line when the implementation is completed
		// //
		// programMediaAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		// this.programMediaAssociationClient.create(programMediaAssociation);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testTvSeasonNoOwnerId() {
		TvSeason tvSeason = new TvSeason();
		// TODO uncomment this line when the implementation is completed
		// tvSeason.setMerlinResourceType(MerlinResourceType.Editorial);
		this.tvSeasonClient.create(tvSeason);

		// TODO uncomment this line when the implementation is completed
		// tvSeason.setMerlinResourceType(MerlinResourceType.Inactive);
		this.tvSeasonClient.create(tvSeason);

		tvSeason = this.tvSeasonFactory.create();
		// TODO uncomment this line when the implementation is completed
		// tvSeason.setMerlinResourceType(MerlinResourceType.Temporary);
		this.tvSeasonClient.create(tvSeason);

		// TODO uncomment this line when the implementation is completed
		// tvSeason.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.tvSeasonClient.create(tvSeason);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testRelatedProgramNoOwnerId() {
		RelatedProgram relatedProgram = new RelatedProgram();
		// TODO uncomment this line when the implementation is completed
		// relatedProgram.setMerlinResourceType(MerlinResourceType.Editorial);
		this.relatedProgramClient.create(relatedProgram);

		// TODO uncomment this line when the implementation is completed
		// relatedProgram.setMerlinResourceType(MerlinResourceType.Inactive);
		this.relatedProgramClient.create(relatedProgram);

		relatedProgram = this.relatedProgramFactory.create();
		// TODO uncomment this line when the implementation is completed
		// relatedProgram.setMerlinResourceType(MerlinResourceType.Temporary);
		this.relatedProgramClient.create(relatedProgram);

		// TODO uncomment this line when the implementation is completed
		// relatedProgram.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.relatedProgramClient.create(relatedProgram);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testEntityCollectionNoOwnerId() {
		EntityCollection entityCollection = new EntityCollection();
		// TODO uncomment this line when the implementation is completed
		// entityCollection.setMerlinResourceType(MerlinResourceType.Editorial);
		this.entityCollectionClient.create(entityCollection);

		// TODO uncomment this line when the implementation is completed
		// entityCollection.setMerlinResourceType(MerlinResourceType.Inactive);
		this.entityCollectionClient.create(entityCollection);

		entityCollection = this.entityCollectionFactory.create();
		// TODO uncomment this line when the implementation is completed
		// entityCollection.setMerlinResourceType(MerlinResourceType.Temporary);
		this.entityCollectionClient.create(entityCollection);

		// TODO uncomment this line when the implementation is completed
		// entityCollection.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.entityCollectionClient.create(entityCollection);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testTagNoOwnerId() {
		Tag tag = new Tag();
		// TODO uncomment this line when the implementation is completed
		// tag.setMerlinResourceType(MerlinResourceType.Editorial);
		this.tagClient.create(tag);

		// TODO uncomment this line when the implementation is completed
		// tag.setMerlinResourceType(MerlinResourceType.Inactive);
		this.tagClient.create(tag);

		tag = this.tagFactory.create();
		// TODO uncomment this line when the implementation is completed
		// tag.setMerlinResourceType(MerlinResourceType.Temporary);
		this.tagClient.create(tag);

		// TODO uncomment this line when the implementation is completed
		// tag.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.tagClient.create(tag);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testTagAssociationNoOwnerId() {
		TagAssociation tagAssociation = new TagAssociation();
		// TODO uncomment this line when the implementation is completed
		// tagAssociation.setMerlinResourceType(MerlinResourceType.Editorial);
		this.tagAssociationClient.create(tagAssociation);

		// TODO uncomment this line when the implementation is completed
		// tagAssociation.setMerlinResourceType(MerlinResourceType.Inactive);
		this.tagAssociationClient.create(tagAssociation);

		tagAssociation = this.tagAssociationFactory.create();
		// TODO uncomment this line when the implementation is completed
		// tagAssociation.setMerlinResourceType(MerlinResourceType.Temporary);
		this.tagAssociationClient.create(tagAssociation);

		// TODO uncomment this line when the implementation is completed
		// tagAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.tagAssociationClient.create(tagAssociation);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testSportsTeamNoOwnerId() {
		SportsTeam sportsTeam = new SportsTeam();
		// TODO uncomment this line when the implementation is completed
		// sportsTeam.setMerlinResourceType(MerlinResourceType.Editorial);
		this.sportsTeamClient.create(sportsTeam);

		// TODO uncomment this line when the implementation is completed
		// sportsTeam.setMerlinResourceType(MerlinResourceType.Inactive);
		this.sportsTeamClient.create(sportsTeam);

		sportsTeam = this.sportsTeamFactory.create();
		// TODO uncomment this line when the implementation is completed
		// sportsTeam.setMerlinResourceType(MerlinResourceType.Temporary);
		this.sportsTeamClient.create(sportsTeam);

		// TODO uncomment this line when the implementation is completed
		// sportsTeam.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.sportsTeamClient.create(sportsTeam);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testSportsEventNoOwnerId() {
		SportsEvent sportsEvent = new SportsEvent();
		// TODO uncomment this line when the implementation is completed
		// sportsEvent.setMerlinResourceType(MerlinResourceType.Editorial);
		this.sportsEventClient.create(sportsEvent);

		// TODO uncomment this line when the implementation is completed
		// sportsEvent.setMerlinResourceType(MerlinResourceType.Inactive);
		this.sportsEventClient.create(sportsEvent);

		sportsEvent = this.sportsEventFactory.create();
		// TODO uncomment this line when the implementation is completed
		// sportsEvent.setMerlinResourceType(MerlinResourceType.Temporary);
		this.sportsEventClient.create(sportsEvent);

		// TODO uncomment this line when the implementation is completed
		// sportsEvent.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.sportsEventClient.create(sportsEvent);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramTeamAssociationNoOwnerId() {
		ProgramTeamAssociation programTeamAssociation = new ProgramTeamAssociation();
		// TODO uncomment this line when the implementation is completed
		// programTeamAssociation.setMerlinResourceType(MerlinResourceType.Editorial);
		this.programTeamAssociationClient.create(programTeamAssociation);

		// TODO uncomment this line when the implementation is completed
		// programTeamAssociation.setMerlinResourceType(MerlinResourceType.Inactive);
		this.programTeamAssociationClient.create(programTeamAssociation);

		programTeamAssociation = this.programTeamAssociationFactory.create();
		// TODO uncomment this line when the implementation is completed
		// programTeamAssociation.setMerlinResourceType(MerlinResourceType.Temporary);
		this.programTeamAssociationClient.create(programTeamAssociation);

		// TODO uncomment this line when the implementation is completed
		// programTeamAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.programTeamAssociationClient.create(programTeamAssociation);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testSportsLeagueNoOwnerId() {
		SportsLeague sportsLeague = new SportsLeague();
		// TODO uncomment this line when the implementation is completed
		// sportsLeague.setMerlinResourceType(MerlinResourceType.Editorial);
		this.sportsLeagueClient.create(sportsLeague);

		// TODO uncomment this line when the implementation is completed
		// sportsLeague.setMerlinResourceType(MerlinResourceType.Inactive);
		this.sportsLeagueClient.create(sportsLeague);

		sportsLeague = this.sportsLeagueFactory.create();
		// TODO uncomment this line when the implementation is completed
		// sportsLeague.setMerlinResourceType(MerlinResourceType.Temporary);
		this.sportsLeagueClient.create(sportsLeague);

		// TODO uncomment this line when the implementation is completed
		// sportsLeague.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.sportsLeagueClient.create(sportsLeague);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramSportsEventNoOwnerId() {
		ProgramSportsEvent programSportsEvent = new ProgramSportsEvent();
		// TODO uncomment this line when the implementation is completed
		// programSportsEvent.setMerlinResourceType(MerlinResourceType.Editorial);
		this.programSportsEventClient.create(programSportsEvent);

		// TODO uncomment this line when the implementation is completed
		// programSportsEvent.setMerlinResourceType(MerlinResourceType.Inactive);
		this.programSportsEventClient.create(programSportsEvent);

		programSportsEvent = this.programSportsEventFactory.create();
		// TODO uncomment this line when the implementation is completed
		// programSportsEvent.setMerlinResourceType(MerlinResourceType.Temporary);
		this.programSportsEventClient.create(programSportsEvent);

		// TODO uncomment this line when the implementation is completed
		// programSportsEvent.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.programSportsEventClient.create(programSportsEvent);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testProgramRankNoOwnerId() {

		// TODO Uncommented this test when ProgramRank's gb related class is
		// added

		ProgramRank programRank = new ProgramRank();
		// TODO uncomment this line when the implementation is completed
		// programRank.setMerlinResourceType(MerlinResourceType.Editorial);
		// this.programRankClient.create(programRank);
		//
		// // TODO uncomment this line when the implementation is completed
		// // programRank.setMerlinResourceType(MerlinResourceType.Inactive);
		// this.programRankClient.create(programRank);
		//
		// programRank = this.programRankFactory.createProgramRank();
		// // TODO uncomment this line when the implementation is completed
		// // programRank.setMerlinResourceType(MerlinResourceType.Temporary);
		// this.programRankClient.create(programRank);
		//
		// // TODO uncomment this line when the implementation is completed
		// //
		// programRank.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		// this.programRankClient.create(programRank);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testAwardNoOwnerId() {
		Award award = new Award();
		// TODO uncomment this line when the implementation is completed
		// award.setMerlinResourceType(MerlinResourceType.Editorial);
		this.awardClient.create(award);

		// TODO uncomment this line when the implementation is completed
		// award.setMerlinResourceType(MerlinResourceType.Inactive);
		this.awardClient.create(award);

		award = this.awardFactory.create();
		// TODO uncomment this line when the implementation is completed
		// award.setMerlinResourceType(MerlinResourceType.Temporary);
		this.awardClient.create(award);

		// TODO uncomment this line when the implementation is completed
		// award.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.awardClient.create(award);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testInstitutionNoOwnerId() {
		Institution institution = new Institution();
		// TODO uncomment this line when the implementation is completed
		// institution.setMerlinResourceType(MerlinResourceType.Editorial);
		this.institutionClient.create(institution);

		// TODO uncomment this line when the implementation is completed
		// institution.setMerlinResourceType(MerlinResourceType.Inactive);
		this.institutionClient.create(institution);

		institution = this.institutionFactory.create();
		// TODO uncomment this line when the implementation is completed
		// institution.setMerlinResourceType(MerlinResourceType.Temporary);
		this.institutionClient.create(institution);

		// TODO uncomment this line when the implementation is completed
		// institution.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.institutionClient.create(institution);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testAwardAssociationNoOwnerId() {
		AwardAssociation awardAssociation = new AwardAssociation();
		// TODO uncomment this line when the implementation is completed
		// awardAssociation.setMerlinResourceType(MerlinResourceType.Editorial);
		this.awardAssociationClient.create(awardAssociation);

		// TODO uncomment this line when the implementation is completed
		// awardAssociation.setMerlinResourceType(MerlinResourceType.Inactive);
		this.awardAssociationClient.create(awardAssociation);

		awardAssociation = this.awardAssociationFactory.create();
		// TODO uncomment this line when the implementation is completed
		// awardAssociation.setMerlinResourceType(MerlinResourceType.Temporary);
		this.awardAssociationClient.create(awardAssociation);

		// TODO uncomment this line when the implementation is completed
		// awardAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.awardAssociationClient.create(awardAssociation);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testImageAssociationNoOwnerId() {
		ImageAssociation imageAssociation = new ImageAssociation();
		// TODO uncomment this line when the implementation is completed
		// imageAssociation.setMerlinResourceType(MerlinResourceType.Editorial);
		this.imageAssociationClient.create(imageAssociation);

		// TODO uncomment this line when the implementation is completed
		// imageAssociation.setMerlinResourceType(MerlinResourceType.Inactive);
		this.imageAssociationClient.create(imageAssociation);

		imageAssociation = this.imageAssociationFactory.create();
		// TODO uncomment this line when the implementation is completed
		// imageAssociation.setMerlinResourceType(MerlinResourceType.Temporary);
		this.imageAssociationClient.create(imageAssociation);

		// TODO uncomment this line when the implementation is completed
		// imageAssociation.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.imageAssociationClient.create(imageAssociation);
	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testMainImageFileNoOwnerId() {
		MainImageFile mainImageFile = new MainImageFile();
		// TODO uncomment this line when the implementation is completed
		// mainImageFile.setMerlinResourceType(MerlinResourceType.Editorial);
		this.mainImageFileClient.create(mainImageFile);

		// TODO uncomment this line when the implementation is completed
		// mainImageFile.setMerlinResourceType(MerlinResourceType.Inactive);
		this.mainImageFileClient.create(mainImageFile);

		mainImageFile = this.mainImageFileFactory.create();
		// TODO uncomment this line when the implementation is completed
		// mainImageFile.setMerlinResourceType(MerlinResourceType.Temporary);
		this.mainImageFileClient.create(mainImageFile);

		// TODO uncomment this line when the implementation is completed
		// mainImageFile.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.mainImageFileClient.create(mainImageFile);

	}

	@Test(groups = { TestGroup.gbTest }, expectedExceptions = ValidationException.class)
	public void testMainImageTypeNoOwnerId() {
		MainImageType mainImageType = new MainImageType();
		// TODO uncomment this line when the implementation is completed
		// mainImageType.setMerlinResourceType(MerlinResourceType.Editorial);
		this.mainImageTypeClient.create(mainImageType);

		// TODO uncomment this line when the implementation is completed
		// mainImageType.setMerlinResourceType(MerlinResourceType.Inactive);
		this.mainImageTypeClient.create(mainImageType);

		mainImageType = this.mainImageTypeFactory.create();
		// TODO uncomment this line when the implementation is completed
		// mainImageType.setMerlinResourceType(MerlinResourceType.Temporary);
		this.mainImageTypeClient.create(mainImageType);

		// TODO uncomment this line when the implementation is completed
		// mainImageType.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
		this.mainImageTypeClient.create(mainImageType);

	}

}
