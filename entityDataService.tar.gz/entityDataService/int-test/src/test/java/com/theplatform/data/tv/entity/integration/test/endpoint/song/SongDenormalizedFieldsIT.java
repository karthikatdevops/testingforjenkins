package com.theplatform.data.tv.entity.integration.test.endpoint.song;

import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.contrib.testing.test.TestGroup;
import com.theplatform.contrib.util.MerlinUriUtil;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.query.albumreleasesongassociation.ByAlbumReleaseId;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseSongAssociationField;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.entity.api.fields.SongField;
import com.theplatform.data.tv.entity.integration.test.EntityTestBase;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

/**
 * This test (and others like it) is meant to validate that the Song client does not return denormalized
 * entities (from associated endpoints) that are marked (have their MRT set to something)
 * other than AudienceAvailable
 * <p/>
 * Author: Vincent Fumo (vfumo) : vincent_fumo@cable.comcast.com
 * Created Date: 3/14/14 (today was pi day)
 */
@Test(groups = {"song", "denormalizedFields", TestGroup.gbTest})
public class SongDenormalizedFieldsIT extends EntityTestBase {

    public void gettingASongShouldNotReturnNonAASongCredits() {
        Song entity = songFactory.create();
        songClient.create(entity);
        URI entityId = entity.getId();

        SongCredit relatedEntity = songCreditFactory.create();
        relatedEntity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        relatedEntity.setSongId(entityId);
        relatedEntity.setType("PrimaryArtist");
        songCreditClient.create(relatedEntity);
        URI personId = relatedEntity.getPersonId();

        // 1) make sure that we get the relatedEntity (since it's AA)
        Song retrievedEntity = songClient.get(entityId, new String[]{SongField.primaryPersonIds.name()});
        List<URI> associations = retrievedEntity.getPrimaryPersonIds();
        assertThat(associations.size(), is(1));

        URI association = associations.get(0);
        assertThat(association, is(personId));

        // 2) change the relatedEntity to be non AA
        relatedEntity.setMerlinResourceType(MerlinResourceType.Inactive);
        songCreditClient.update(relatedEntity);

        // 3) validate that the relatedEntity doesn't return
        // note: we change the fields returned so we aren't dealing with a stale cache
        retrievedEntity = songClient.get(entityId, new String[]{ProgramField.merlinResourceType.name(), ProgramField.credits.name()});
        associations = retrievedEntity.getPrimaryPersonIds();
        assertThat(associations, nullValue());
    }

    public void gettingASongShouldNotReturnNonAATagAssociations() {
        Song entity = songFactory.create();
        songClient.create(entity);
        URI entityId = entity.getId();

        TagAssociation relatedEntity = tagAssociationFactory.create(new DataServiceField(TagAssociationField.entityId,entityId));
        relatedEntity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        tagAssociationClient.create(relatedEntity);
        URI relatedEntityId = relatedEntity.getTagId();

        // 1) make sure that we get the relatedEntity (since it's AA)
        Song retrievedEntity = songClient.get(entityId, new String[]{SongField.tagIds.name()});
        List<URI> ids = retrievedEntity.getTagIds();
        assertThat(ids, hasItem(relatedEntityId));

        // 2) change the relatedEntity to be non AA
        relatedEntity.setMerlinResourceType(MerlinResourceType.Inactive);
        tagAssociationClient.update(relatedEntity);

        // 3) validate that the relatedEntity doesn't return
        // note: we change the fields returned so we aren't dealing with a stale cache
        retrievedEntity = songClient.get(entityId, new String[]{SongField.merlinResourceType.name(), SongField.tagIds.name()});
        ids = retrievedEntity.getTagIds();
        assertThat(ids, not(hasItem(relatedEntityId)));
    }

    public void gettingASongShouldNotReturnNonAAAlbumReleaseAssociations() {
        Song entity = songFactory.create();
        songClient.create(entity);
        URI entityId = entity.getId();

        AlbumRelease albumRelease = albumReleaseClient.create(albumReleaseFactory.create());
        URI albumReleaseId = albumRelease.getId();

        AlbumReleaseSongAssociation relatedEntity = albumReleaseSongAssociationFactory.create(new DataServiceField(AlbumReleaseSongAssociationField.albumReleaseId, albumReleaseId),
                new DataServiceField(AlbumReleaseSongAssociationField.songId, entityId));
        relatedEntity.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        albumReleaseSongAssociationClient.create(relatedEntity);

        // 1) make sure that we get the entity by the relatedEnityt (since it's AA)
        Feed<Song> retrievedEntities = songClient.getAll(new String[]{"id"}, new Query[]{new ByAlbumReleaseId(MerlinUriUtil.getIdValue(albumReleaseId))}, null, null, null);
        assertThat(retrievedEntities.getEntryCount(), is(1L));
        Song retrievedEntity = retrievedEntities.getEntries().get(0);
        assertThat(retrievedEntity.getId(), is(entityId));

        // 2) change the relatedEntity to be non AA
        relatedEntity.setMerlinResourceType(MerlinResourceType.Inactive);
        albumReleaseSongAssociationClient.update(relatedEntity);

        // 3) validate that the relatedEntity doesn't return
        // note: we change the fields returned so we aren't dealing with a stale cache
        retrievedEntities = songClient.getAll(new String[]{"id", "merlinResourceType"}, new Query[]{new ByAlbumReleaseId(MerlinUriUtil.getIdValue(albumReleaseId))}, null, null, null);
        assertThat(retrievedEntities.getEntryCount(), is(0L));
    }
}
