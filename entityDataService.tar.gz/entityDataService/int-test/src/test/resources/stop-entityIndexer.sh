#!/bin/bash

kill -9 $(cat entityIndexer.pid)
