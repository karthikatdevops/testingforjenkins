#! /bin/sh
java $* >entityIndexer.log 2>&1 &
echo $! >entityIndexer.pid
exit 0
