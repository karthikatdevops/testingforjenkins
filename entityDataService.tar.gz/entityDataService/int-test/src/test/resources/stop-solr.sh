#!/bin/sh

kill -9 $(cat solrTest/solr.pid)
