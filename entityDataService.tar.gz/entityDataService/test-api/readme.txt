STOP!!!

Before you add any source code to this module, ask yourself, "Self, should this code be in EntityCommons instead?"