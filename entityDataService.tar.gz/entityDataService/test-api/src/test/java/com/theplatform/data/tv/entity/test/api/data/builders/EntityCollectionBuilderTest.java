package com.theplatform.data.tv.entity.test.api.data.builders;

import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNull;
import static org.testng.Assert.assertTrue;

@Test
public class EntityCollectionBuilderTest {

    EntityCollectionBuilder entityCollectionBuilder;

    public EntityCollectionBuilderTest() {
        this.entityCollectionBuilder = new EntityCollectionBuilder();
    }

    public void tesType() {
        String expected = "Type value";
        EntityCollection entityCollection = entityCollectionBuilder.type(expected).build();
        assertEquals(entityCollection.getType(), expected);
    }

    public void testSubtype() {
        String expected = "Type value";
        EntityCollection entityCollection = entityCollectionBuilder.subtype(expected).build();
        assertEquals(entityCollection.getSubtype(), expected);
    }


    public void testEntityIds() {
        List<URI> expected = Arrays.asList(URI.create("http://localhost/1"), URI.create("http://localhost/2"));
        EntityCollection entityCollection = entityCollectionBuilder.entityIds(expected).build();
        assertListEqualsNoOrder(entityCollection.getEntityIds(), expected);
    }

    public void testImageIds() {
        List<URI> expected = Arrays.asList(URI.create("http://localhost/3"), URI.create("http://localhost/1"));
        EntityCollection entityCollection = entityCollectionBuilder.imageIds(expected).build();
        assertListEqualsNoOrder(entityCollection.getImageIds(), expected);
    }


    public void testMerlinResourceType() {
        MerlinResourceType expected = MerlinResourceType.AudienceAvailable;
        EntityCollection entityCollection = entityCollectionBuilder.merlinResourceType(expected).build();
        assertEquals(entityCollection.getMerlinResourceType(), expected);
    }

    private <T> void assertListEqualsNoOrder(List<T> actual, List<T> expected) {
        if (expected == null) {
            assertNull(actual);
        } else {
            assertEquals(actual.size(), expected.size());
            for (T expectedItem : expected) {
                assertTrue(actual.contains(expectedItem));
            }
        }
    }

    private <K, V extends DataObject> void assertMapEquals(Map<K, V> actual, HashMap<K, V> expected) {
        if (expected == null) {
            assertNull(actual);
        } else {
            for (K expectedKey : expected.keySet()) {
                assertTrue(actual.containsKey(expectedKey));
                assertEquals(actual.get(expectedKey).getId(), expected.get(expectedKey).getId());
            }
        }
    }

}
