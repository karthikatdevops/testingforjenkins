package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.field.ConsecutiveLongProvider;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.data.objects.TvSeason;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URI;
import java.net.UnknownHostException;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Test
public class ProgramFactoryTest {

    private ProgramFactory factory;
    private static final String BASE_URL = "http://localhost/dummyDataService/";

    public ProgramFactoryTest() throws UnknownHostException {
        ProgramClient programClient = mock(ProgramClient.class);
        when(programClient.getBaseUrl()).thenReturn(BASE_URL + "data/Program");
        when(programClient.getRequestUrl()).thenReturn(BASE_URL + "data/Program");
        when(programClient.getDataObjectClass()).thenReturn(Program.class);
        this.factory = new ProgramFactory(programClient, new ConsecutiveLongProvider());
    }

    public void testCreateSeries() {
        Program createDataObject = this.factory.createSeries();
        Assert.assertNotNull(createDataObject);
        Assert.assertNotNull(createDataObject.getId());
        Assert.assertNotNull(createDataObject.getType());
        Assert.assertNotNull(createDataObject.getCategory());
        Assert.assertNull(createDataObject.getRuntime());
        Assert.assertEquals(createDataObject.getType(), ProgramType.SeriesMaster);
    }

    public void testCreateSeriesEpisode() {
        Program createSeries = this.factory.createSeries();
        TvSeason season = new TvSeason();
        season.setId(URI.create("http://localhost/Program/1"));

        Program createDataObject = this.factory.createEpisode(createSeries, season);
        Assert.assertNotNull(createDataObject);
        Assert.assertNotNull(createDataObject.getId());
        Assert.assertNotNull(createDataObject.getType());
        Assert.assertNotNull(createDataObject.getCategory());
        Assert.assertEquals(createDataObject.getSeriesId(), createSeries.getId());
        Assert.assertEquals(createDataObject.getTvSeasonId(), season.getId());
        Assert.assertEquals(createDataObject.getType(), ProgramType.Episode);
    }

}
