package com.theplatform.data.tv.entity.test.api.data.builders;

import com.theplatform.data.tv.entity.api.data.objects.Tag;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

public class TagBuilderTest {

    TagBuilder tagBuilder = new TagBuilder();

    @Test
    public void testYear() {
        String expected = "Type value";
        Tag tag = tagBuilder.type(expected).build();

        assertEquals(tag.getType(), expected);
    }
}
