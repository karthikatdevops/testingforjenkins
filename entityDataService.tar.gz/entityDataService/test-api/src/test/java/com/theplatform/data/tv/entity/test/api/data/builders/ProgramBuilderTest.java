package com.theplatform.data.tv.entity.test.api.data.builders;

import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import org.testng.annotations.Test;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class ProgramBuilderTest {

    ProgramBuilder pb = new ProgramBuilder();

    @Test
    public void testYear() {
        Integer expected = 1997;
        Program p = pb.year(expected).build();

        assertEquals(p.getYear(), expected);
    }

    @Test
    public void testShortSynopsis() {
        String expected = "a shortSynopsis";
        Program p = pb.shortSynopsis(expected).build();

        assertEquals(p.getShortSynopsis(), expected);
    }

    @Test
    public void testMediumSynopsis() {
        String expected = "a mediumSynopsis";
        Program p = pb.mediumSynopsis(expected).build();

        assertEquals(p.getMediumSynopsis(), expected);
    }

    @Test
    public void testLongSynopsis() {
        String expected = "a longSynopsis";
        Program p = pb.longSynopsis(expected).build();

        assertEquals(p.getLongSynopsis(), expected);
    }

    @Test
    public void testRuntime() {
        Integer expected = 6;
        Program p = pb.runtime(expected).build();

        assertEquals(p.getRuntime(), expected);
    }

    @Test
    public void testType() {
        ProgramType expected = ProgramType.Movie;
        Program p = pb.type(expected).build();

        assertEquals(p.getType(), expected);
    }

    @Test
    public void testLanguage() {
        String expected = "a language";
        Program p = pb.language(expected).build();

        assertEquals(p.getLanguage(), expected);
    }


    @Test
    public void testPartNumber() {
        Integer expected = 2;
        Program p = pb.partNumber(expected).build();

        assertEquals(p.getPartNumber(), expected);
    }

    @Test
    public void testTotalParts() {
        Integer expected = 9;
        Program p = pb.totalParts(expected).build();

        assertEquals(p.getTotalParts(), expected);
    }

    @Test
    public void testSortTitle() {
        String expected = "a sortTitle";
        Program p = pb.sortTitle(expected).build();

        assertEquals(p.getSortTitle(), expected);
    }

    @Test
    public void testStarRating() {
        Integer expected = 4;
        Program p = pb.starRating(expected).build();

        assertEquals(p.getStarRating(), expected);
    }

    @Test
    public void testCategory() {
        String expected = "a category";
        Program p = pb.category(expected).build();

        assertEquals(p.getCategory(), expected);
    }

    @Test
    public void testOriginalAirDate() {
        DateOnly expected = new DateOnly();
        Program p = pb.originalAirDate(expected).build();

        assertEquals(p.getOriginalAirDate(), expected);
    }

    @Test
    public void testFirstRunCompanyId() {
        URI expected = URI.create("http://www.comcast.com");
        Program p = pb.firstRunCompanyId(expected).build();

        assertEquals(p.getFirstRunCompanyId(), expected);
    }

    @Test
    public void testAdult() {
        Boolean expected = true;
        Program p = pb.adult(expected).build();

        assertEquals(p.getAdult(), expected);
    }


    @Test
    public void testShortTitle() {
        String expected = "a shortTitle";
        Program p = pb.shortTitle(expected).build();

        assertEquals(p.getShortTitle(), expected);
    }

    @Test
    public void testMediumTitle() {
        String expected = "a mediumTitle";
        Program p = pb.mediumTitle(expected).build();

        assertEquals(p.getMediumTitle(), expected);
    }

    @Test
    public void testLongTitle() {
        String expected = "a longTitle";
        Program p = pb.longTitle(expected).build();

        assertEquals(p.getLongTitle(), expected);
    }

    @Test
    public void testLocal() {
        Boolean expected = true;
        Program p = pb.local(expected).build();

        assertEquals(p.getLocal(), expected);
    }


    @Test
    public void testListByTitle() {
        Boolean expected = true;
        Program p = pb.listByTitle(expected).build();

        assertEquals(p.getListByTitle(), expected);
    }

    @Test
    public void testReleaseDate() {
        DateOnly expected = new DateOnly();
        Program p = pb.releaseDate(expected).build();

        assertEquals(p.getReleaseDate(), expected);
    }

    @Test
    public void testSeriesId() {
        URI expected = URI.create("http://www.comcast.net");
        Program p = pb.seriesId(expected).build();

        assertEquals(p.getSeriesId(), expected);
    }

    @Test
    public void testTvSeasonId() {
        URI expected = URI.create("http://www.cable.comcast.com");
        Program p = pb.tvSeasonId(expected).build();

        assertEquals(p.getTvSeasonId(), expected);
    }

    @Test
    public void testTvSeasonNumber() {
        Integer expected = 6;
        Program p = pb.tvSeasonNumber(expected).build();

        assertEquals(p.getTvSeasonNumber(), expected);
    }

    @Test
    public void testTvSeasonEpisodeNumber() {
        Integer expected = 3;
        Program p = pb.tvSeasonEpisodeNumber(expected).build();

        assertEquals(p.getTvSeasonEpisodeNumber(), expected);
    }

    @Test
    public void testSeriesEpisodeNumber() {
        Integer expected = 4;
        Program p = pb.seriesEpisodeNumber(expected).build();

        assertEquals(p.getSeriesEpisodeNumber(), expected);
    }

    @Test
    public void testEpisodeTitle() {
        String expected = "a episodeTitle";
        Program p = pb.episodeTitle(expected).build();

        assertEquals(p.getEpisodeTitle(), expected);
    }

    @Test
    public void testFirstAirDate() {
        DateOnly expected = new DateOnly();
        Program p = pb.firstAirDate(expected).build();

        assertEquals(p.getFirstAirDate(), expected);
    }

    @Test
    public void testLastAirDate() {
        DateOnly expected = new DateOnly();
        Program p = pb.lastAirDate(expected).build();

        assertEquals(p.getLastAirDate(), expected);
    }

    @Test
    public void testCredits() {
        List<CreditAssociation> expected = new ArrayList<>();
        Program p = pb.credits(expected).build();

        assertEquals(p.getCredits(), expected);
    }

    @Test
    public void testTagIds() {
        List<URI> expected = new ArrayList<>();
        Program p = pb.tagIds(expected).build();

        assertEquals(p.getTagIds(), expected);
    }

    @Test
    public void testImageIds() {
        List<URI> expected = new ArrayList<>();
        Program p = pb.imageIds(expected).build();

        assertEquals(p.getImageIds(), expected);
    }

}
