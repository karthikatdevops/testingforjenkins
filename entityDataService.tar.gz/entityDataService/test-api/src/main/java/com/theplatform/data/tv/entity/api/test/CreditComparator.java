package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.image.api.test.MainImageInfoComparator;
import org.testng.Assert;

import java.util.List;

/**
 * Provides comparison utility
 *
 * @since 4/6/2011
 */
public class CreditComparator {

    private CreditComparator() {

    }

    public static void assertEquals(Credit actual, Credit expected) {
        Assert.assertEquals(actual.getId(), expected.getId());

        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getPartName(), expected.getPartName());
        Assert.assertEquals(actual.getRank(), expected.getRank());
        Assert.assertEquals(actual.getCameo(), expected.getCameo());


        Assert.assertEquals(actual.getPersonId(), expected.getPersonId());
        PersonAssociationComparator.assertEquals(actual.getPerson(), expected.getPerson());
        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        ProgramAssociationComparator.assertEquals(actual.getProgram(), expected.getProgram());

        Assert.assertEquals(actual.getActive(), expected.getActive());
        Assert.assertEquals(actual.getImageIds(), expected.getImageIds());

        Assert.assertEquals(actual.getMainImages(), expected.getMainImages());

        MainImageInfoComparator.assertEquals(actual.getSelectedImages(), expected.getSelectedImages());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());

    }

    public static void assertEquals(Feed<Credit> actualCreditFeed, List<Credit> expectedCredits) {
        List<Credit> actualCredits = actualCreditFeed.getEntries();
        Assert.assertEquals(actualCredits.size(), expectedCredits.size(), "Unexpected number of Credits");
        for (int i = 0; i < expectedCredits.size(); i++)
            assertEquals(actualCredits.get(i), expectedCredits.get(i));

    }
}