package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.MediaIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.DataObject;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.image.api.client.ImageAssociationClient;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociationMetadataManagementInfo;
import com.theplatform.data.tv.image.api.fields.ImageAssociationField;

import java.net.URI;
import java.util.ArrayList;

public class ImageAssociationFactory<E extends DataObject, EC extends DataServiceClient<E>, I extends DataObject, IC extends DataServiceClient<I>>
        extends DataObjectFactoryImpl<ImageAssociation, ImageAssociationClient> {

    private DataObjectFactory<E, EC> entityFactory;
    private DataObjectFactory<I, IC> imageFactory;

    public ImageAssociationFactory(ImageAssociationClient imageAssociationClient, DataObjectFactory<E, EC> entityFactory,
                                   ValueProvider<Long> idProvider) {
        super(imageAssociationClient, ImageAssociation.class, idProvider);

        this.entityFactory = entityFactory;

        this.addPresetFieldsOverrides(
                ImageAssociationField.entityId, new DataObjectIdProvider(entityFactory),
                ImageAssociationField.mediaId, new MediaIdProvider(idProvider),
                ImageAssociationField.preferForMainImageTypeIds, new ArrayList<URI>(),
                ImageAssociationField.isDefault, false,
                ImageAssociationField.preferForMainImageTypes, new ArrayList<String>(),
                ImageAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new ImageAssociationMetadataManagementInfo()
        );

    }

    public ImageAssociationFactory(ImageAssociationClient imageAssociationClient, DataObjectFactory<E, EC> entityFactory,
                                   DataObjectFactory<I, IC> imageFactory,
                                   ValueProvider<Long> idProvider) {
        this(imageAssociationClient, entityFactory, idProvider);


    }


    public DataObjectFactory<E, EC> getEntityFactory() {
        return entityFactory;
    }

    public DataObjectFactory<I, IC> getImageFactory() {
        return imageFactory;
    }
}
