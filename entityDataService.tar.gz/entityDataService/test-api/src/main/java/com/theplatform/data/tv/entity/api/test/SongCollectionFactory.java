package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.data.objects.SongCollection;

public class SongCollectionFactory extends EndpointFactory<SongCollection> {


}
