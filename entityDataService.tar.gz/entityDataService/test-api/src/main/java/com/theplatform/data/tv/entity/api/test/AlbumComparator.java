package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.DateOnlyComparator;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Album;
import org.testng.Assert;

import java.util.List;

public class AlbumComparator {

    private AlbumComparator() {

    }

    public static void assertEquals(Album actual, Album expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getTitle(), expected.getTitle());
        Assert.assertEquals(actual.getSortTitle(), expected.getSortTitle());
        Assert.assertEquals(actual.getDescription(), expected.getDescription());
        Assert.assertEquals(actual.getLanguage(), expected.getLanguage());
        Assert.assertEquals(actual.getCountry(), expected.getCountry());
        DateOnlyComparator.assertEquals(actual.getOriginalReleaseDate(), expected.getOriginalReleaseDate());
        Assert.assertEquals(actual.getPrimaryPersonIds(), expected.getPrimaryPersonIds());
        Assert.assertEquals(actual.getImageIds(), expected.getImageIds());
        Assert.assertEquals(actual.getTagIds(), expected.getTagIds());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<Album> actual, List<Album> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));

    }
}
