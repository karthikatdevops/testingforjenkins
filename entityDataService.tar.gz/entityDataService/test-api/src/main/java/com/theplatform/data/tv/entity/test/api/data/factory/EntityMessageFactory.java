package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.EntityMessageClient;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.EntityMessage;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.fields.EntityMessageField;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/23/15
 */
public class EntityMessageFactory extends DataObjectFactoryImpl<EntityMessage, EntityMessageClient> {

    public EntityMessageFactory(EntityMessageClient client, ValueProvider<Long> idProvider, DataObjectFactory<Program, ProgramClient> programFactory) {
        super(client, EntityMessage.class, idProvider);

        addPresetFieldsOverrides(
                DataObjectField.title, "title",
                EntityMessageField.entityId, new DataObjectIdProvider(programFactory),
                EntityMessageField.freeText, "freeText",
                EntityMessageField.type, "type",
                EntityMessageField.priority, 1,
                EntityMessageField.merlinResourceType, MerlinResourceType.AudienceAvailable
        );
    }

}
