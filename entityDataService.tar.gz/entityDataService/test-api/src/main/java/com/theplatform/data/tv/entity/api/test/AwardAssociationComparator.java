package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import org.testng.Assert;

import java.util.List;

/**
 * Comparative utility for AwardAssociation, mainly for equality assertion
 *
 * @author clai200
 * @since 4/5/2011
 */
public class AwardAssociationComparator {

    private AwardAssociationComparator() {

    }

    /**
     * Verify the equality of two AwardAssociation objects
     *
     * @param actual
     * @param expected
     */
    public static void assertEquals(AwardAssociation actual, AwardAssociation expected) {
        Assert.assertEquals(actual.getId(), expected.getId());

        Assert.assertEquals(actual.getDescription(), expected.getDescription());
        Assert.assertEquals(actual.getYear(), expected.getYear());
        Assert.assertEquals(actual.getAwardStatus(), expected.getAwardStatus());
        Assert.assertEquals(actual.getAwardType(), expected.getAwardType());
        Assert.assertEquals(actual.getAwardId(), expected.getAwardId());
        Assert.assertEquals(actual.getInstitutionId(), expected.getInstitutionId());
        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        Assert.assertEquals(actual.getPersonId(), expected.getPersonId());

        Assert.assertEquals(actual.getAwardShowId(), expected.getAwardShowId());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<AwardAssociation> actualFeed, List<AwardAssociation> expectedObjects) {
        List<AwardAssociation> actualAwardAssociations = actualFeed.getEntries();

        Assert.assertEquals(actualAwardAssociations.size(), expectedObjects.size(), "Unexpected number of AwardAssociations");

        for (int i = 0; i < expectedObjects.size(); i++)
            assertEquals(actualAwardAssociations.get(i), expectedObjects.get(i));

    }

}
