package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.image.api.client.MainImageTypeClient;
import com.theplatform.data.tv.image.api.data.objects.ImageCriteria;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.image.api.fields.MainImageTypeField;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;

import java.net.URI;
import java.util.ArrayList;

public class MainImageTypeFactory extends DataObjectFactoryImpl<MainImageType, MainImageTypeClient> {

    public MainImageTypeFactory(MainImageTypeClient mainImageTypeClient, ValueProvider<Long> idProvider) {
        super(mainImageTypeClient, MainImageType.class, idProvider);

        this.addPresetFieldsOverrides(
                MainImageTypeField.entityType, MerlinEntityType.PROGRAM.name(),
                DataObjectField.title, "Title",
                MainImageTypeField.alias, "Main Image Type " + idProvider.getValue(),
                MainImageTypeField.imageCriteria, new ArrayList<ImageCriteria>(),
                MainImageTypeField.entityQuery, "entity query",
                MainImageTypeField.mainImageTypeGroupIds, new ArrayList<URI>(),
                MainImageTypeField.defaultImageCriteria, new ArrayList<ImageCriteria>(),
                MainImageTypeField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo());


    }
}
