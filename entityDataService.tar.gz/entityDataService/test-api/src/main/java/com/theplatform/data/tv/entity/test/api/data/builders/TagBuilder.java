package com.theplatform.data.tv.entity.test.api.data.builders;

import com.theplatform.contrib.testing.builder.DataObjectBuilder;
import com.theplatform.data.tv.entity.api.data.objects.Tag;

public class TagBuilder extends DataObjectBuilder<Tag, TagBuilder> {

    public TagBuilder() {
        super(new Tag());
    }

    public TagBuilder(Tag template) {
        super(template);
    }

    @Override
    protected TagBuilder newBuilder(Tag newTemplate) {
        return new TagBuilder(newTemplate);
    }

    public TagBuilder type(String type) {
        Tag newTemplate = this.cloneTemplate();
        newTemplate.setType(type);
        return newBuilder(newTemplate);
    }
}
