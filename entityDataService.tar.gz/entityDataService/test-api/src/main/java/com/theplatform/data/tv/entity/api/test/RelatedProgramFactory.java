package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;

import java.net.URI;

/**
 * @author jethrolai
 */
public class RelatedProgramFactory extends EndpointFactory<RelatedProgram> {

    private ProgramClient programClient;

    private ProgramEndpointFactory programFactory;

    @Override
    public RelatedProgram create() {
        RelatedProgram relatedProgram = super.create();
        relatedProgram.setTargetProgramId(this.programClient.create(this.programFactory.create()).getId());
        relatedProgram.setSourceProgramId(this.programClient.create(this.programFactory.create()).getId());
        return relatedProgram;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }

    public ProgramEndpointFactory getProgramFactory() {
        return programFactory;
    }

    public void setProgramFactory(ProgramEndpointFactory programFactory) {
        this.programFactory = programFactory;
    }

    public Program getEmbeddedProgram(URI programId) {
        Program program = programClient.get(programId, new String[]{});

        return program;
    }

}
