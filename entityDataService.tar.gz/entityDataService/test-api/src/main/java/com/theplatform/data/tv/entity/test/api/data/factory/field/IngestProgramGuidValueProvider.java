package com.theplatform.data.tv.entity.test.api.data.factory.field;

import com.theplatform.contrib.testing.factory.field.FieldValueProvider;
import com.theplatform.contrib.testing.util.URIUtils;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.ingest.IdFormatter;
import com.theplatform.data.tv.ingest.IdMapper;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.data.tv.ingest.type.ProviderType;

import java.net.URI;


/**
 * ValueProvider that creates an builds a guid (String) with the provided objectId.
 *
 * @author jfuentes
 */
public class IngestProgramGuidValueProvider implements FieldValueProvider<Program, String> {

    @Override
    public String getFieldValue(Program dataObject) {
        URI objectId = dataObject.getId();
        Long ingestId = URIUtils.getIdValue(objectId);
        int suffix = URIUtils.getIdSuffix(objectId);
        ProviderType provider = ProviderType.valueOf(suffix);
        MerlinEntityType entityType = MerlinEntityType.PROGRAM;
        String rawId = IdMapper.formatId(provider, entityType, ingestId.toString(), IdFormatter.IdFormat.INGEST, IdFormatter.IdFormat.RAW);
        ProgramType subType = dataObject.getType();
        return "THIS WILL AUTO GENERATE A GUID FROM THIS INGEST ID URL: " +
                dataObject.getId().toString() +
                "\nas a combination of: " +
                "\nEndpoint: " + entityType +
                "\nProvider: " + provider +
                "\nSubtype: " + subType +
                "\nNativeId: " + rawId;  //To change body of implemented methods use File | Settings | File Templates.
    }

}
