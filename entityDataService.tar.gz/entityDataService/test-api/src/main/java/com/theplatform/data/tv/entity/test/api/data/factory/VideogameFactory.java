package com.theplatform.data.tv.entity.test.api.data.factory;

import com.google.common.collect.Lists;
import com.theplatform.contrib.data.api.objects.EsrbRating;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.VideogameClient;
import com.theplatform.data.tv.entity.api.data.objects.Videogame;
import com.theplatform.data.tv.entity.api.fields.VideogameField;

import java.net.URI;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 12/3/14
 */
public class VideogameFactory extends DataObjectFactoryImpl<Videogame, VideogameClient> {

    public VideogameFactory(VideogameClient client, ValueProvider<Long> idProvider) {
        super(client, Videogame.class, idProvider);

        EsrbRating rating = new EsrbRating();
        rating.setScheme("ESRB");
        rating.setRating("Teen");
        rating.setSubRatings(new String[]{"Violence"});
        rating.setInteractiveElements(new String[]{"Music Downloads Not Rated by the ESRB"});

        addPresetFieldsOverrides(
                DataObjectField.title, new PrefixedIdFieldProvider("title"),
                VideogameField.shortTitle, "shortTitle",
                VideogameField.mediumTitle, "mediumTitle",
                VideogameField.longTitle, "longTitle",
                VideogameField.shortSynopsis, "shortSynopsis",
                VideogameField.mediumSynopsis, "mediumSynopsis",
                VideogameField.longSynopsis, "longSynopsis",
                VideogameField.type, "Game",
                VideogameField.nativeId, new PrefixedIdFieldProvider("nativeId"),
                VideogameField.releaseDate, new DateOnly(1900, 1, 1),
                VideogameField.attributionString, "attributionString",
                VideogameField.singlePlayer, true,
                VideogameField.multiPlayer, true,
                VideogameField.minPlayers, 2,
                VideogameField.maxPlayers, 4,
                VideogameField.languages, Lists.newArrayList("eng"),
                VideogameField.contentRatings, Lists.newArrayList(rating),
                VideogameField.tagIds, Lists.newArrayList(URI.create("http://some/uri")),
                VideogameField.merlinResourceType, MerlinResourceType.AudienceAvailable
        );
    }

}
