package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.FieldValueProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;
import com.theplatform.media.api.data.objects.Rating;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

public class EpisodeProgramFactory extends DataObjectFactoryImpl<Program, ProgramClient> {

    private final DataObjectFactory<Program, ProgramClient> seriesMasterFactory;

    public EpisodeProgramFactory(ProgramClient client, final DataObjectFactory<Program, ProgramClient> seriesMasterFactory, ValueProvider<Long> idProvider) {
        this(client, seriesMasterFactory, idProvider, null);

    }

    public EpisodeProgramFactory(ProgramClient client, final DataObjectFactory<Program, ProgramClient> seriesMasterFactory, ValueProvider<Long> idProvider, FieldValueProvider<Program, String> guidValueProvider) {
        super(client, Program.class, idProvider);

        this.seriesMasterFactory = seriesMasterFactory;

        Rating rating = new Rating();
        rating.setScheme("urn:v-chip");
        rating.setRating("TV14");

        this.addPresetFieldsOverrides(
                ProgramField.type, ProgramType.Episode,
                ProgramField.category, ProgramCategory.Other.getFriendlyName(),
                ProgramField.seriesId, new DataObjectIdProvider(seriesMasterFactory),
                ProgramField.local, false,
                ProgramField.credits, new ArrayList<CreditAssociation>(),
                ProgramField.tagIds, new ArrayList<URI>(),
                ProgramField.imageIds, new ArrayList<URI>(),
                ProgramField.seriesEpisodeNumber, 1,
                ProgramField.tvSeasonNumber, 1,
                ProgramField.episodeTitle, "episode title",
                ProgramField.productionEpisodeNumber, "productionEpisodeNumber",
                ProgramField.tvSeasonEpisodeNumber, 1,
                ProgramField.mainImages, new HashMap<String, MediaFile>(),
                ProgramField.selectedImages, new ArrayList<MainImageInfo>(),
                ProgramField.listByTitle, true,
                DataObjectField.title, "title"
        );

        if (guidValueProvider != null) {
            this.addPresetFieldsOverrides(DataObjectField.guid, guidValueProvider);
        }

    }

    public DataObjectFactory<Program, ProgramClient> getSeriesMasterFactory() {
        return seriesMasterFactory;
    }

}
