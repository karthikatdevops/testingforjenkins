package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.ReviewClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.Review;
import com.theplatform.data.tv.entity.api.fields.ReviewField;
import com.theplatform.media.api.data.objects.Rating;

import java.util.ArrayList;

public class ReviewFactory extends DataObjectFactoryImpl<Review, ReviewClient> {

    private DataObjectFactory<Program, ProgramClient> programFactory;

    public ReviewFactory(ReviewClient client, DataObjectFactory<Program, ProgramClient> programFactory) {
        this(client, programFactory, null);
    }


    public ReviewFactory(ReviewClient client, DataObjectFactory<Program, ProgramClient> programFactory, ValueProvider<Long> idProvider) {
        super(client, Review.class, idProvider);

        this.programFactory = programFactory;
        this.addPresetFieldsOverrides(
                ReviewField.programId, new DataObjectIdProvider(this.programFactory),
                ReviewField.provider, "Just a provider",
                ReviewField.summary, "Summary",
                ReviewField.recommendation, "recommendation",
                ReviewField.starRating, 1,
                ReviewField.source, "source",
                ReviewField.review, "review",
                ReviewField.contentRatings, new ArrayList<Rating>(),
                ReviewField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }

    public DataObjectFactory<Program, ProgramClient> getProgramFactory() {
        return this.programFactory;
    }

}
