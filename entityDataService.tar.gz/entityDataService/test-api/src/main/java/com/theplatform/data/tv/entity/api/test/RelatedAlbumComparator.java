package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.RelatedAlbum;
import org.testng.Assert;

import java.util.List;

public class RelatedAlbumComparator {

    public static void assertEquals(RelatedAlbum actual, RelatedAlbum expected) {

        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getSourceAlbumId(), expected.getSourceAlbumId());
        Assert.assertEquals(actual.getTargetAlbumId(), expected.getTargetAlbumId());
        Assert.assertEquals(actual.getRank(), expected.getRank());
        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<RelatedAlbum> actual, List<RelatedAlbum> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));

    }
}
