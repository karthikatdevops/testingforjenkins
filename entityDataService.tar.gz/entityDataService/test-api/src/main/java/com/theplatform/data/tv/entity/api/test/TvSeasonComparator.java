package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.TvSeason;
import org.testng.Assert;

import java.util.List;

public class TvSeasonComparator {

    private TvSeasonComparator() {

    }

    public static void assertEquals(TvSeason actual, TvSeason expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getSeriesId(), expected.getSeriesId());
        Assert.assertEquals(actual.getTvSeasonNumber(), expected.getTvSeasonNumber());
        Assert.assertEquals(actual.getStartYear(), expected.getStartYear());
        Assert.assertEquals(actual.getEndYear(), expected.getEndYear());
        Assert.assertEquals(actual.getDescription(), expected.getDescription());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<TvSeason> actual, List<TvSeason> expected) {
        List<TvSeason> actualTvSeasons = actual.getEntries();
        Assert.assertEquals(actualTvSeasons.size(), expected.size(), "Unexpected number of tvSeasons");
        for (int i = 0; i < expected.size(); i++)
            assertEquals(actualTvSeasons.get(i), expected.get(i));
    }
}
