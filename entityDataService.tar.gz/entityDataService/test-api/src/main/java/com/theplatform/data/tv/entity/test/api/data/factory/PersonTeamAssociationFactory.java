package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.client.PersonTeamAssociationClient;
import com.theplatform.data.tv.entity.api.client.SportsTeamClient;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.PersonTeamAssociation;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.fields.PersonTeamAssociationField;

public class PersonTeamAssociationFactory extends DataObjectFactoryImpl<PersonTeamAssociation, PersonTeamAssociationClient> {

    private final DataObjectFactory<Person, PersonClient> personFactory;
    private final DataObjectFactory<SportsTeam, SportsTeamClient> sportsTeamFactory;

    public PersonTeamAssociationFactory(
            PersonTeamAssociationClient ptaClient,
            DataObjectFactory<Person, PersonClient> personFactory,
            DataObjectFactory<SportsTeam, SportsTeamClient> sportsTeamFactory, ValueProvider<Long> idProvider) {
        super(ptaClient, PersonTeamAssociation.class, idProvider);
        this.personFactory = personFactory;
        this.sportsTeamFactory = sportsTeamFactory;
        this.addPresetFieldsOverrides(
                PersonTeamAssociationField.personId, new DataObjectIdProvider(this.getPersonFactory()),
                PersonTeamAssociationField.sportsTeamId, new DataObjectIdProvider(this.getSportsTeamFactory()),
                PersonTeamAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable
        );
    }

    public DataObjectFactory<Person, PersonClient> getPersonFactory() {
        return personFactory;
    }

    public DataObjectFactory<SportsTeam, SportsTeamClient> getSportsTeamFactory() {
        return sportsTeamFactory;
    }
}
