package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.data.objects.RelatedSong;

public class RelatedSongFactory extends EndpointFactory<RelatedSong> {

    private SongClient songClient;
    private SongFactory songFactory;

    @Override
    public RelatedSong create() {
        RelatedSong relatedSong = super.create();
        relatedSong.setSourceSongId(this.songClient.create(this.songFactory.create()).getId());
        relatedSong.setTargetSongId(this.songClient.create(this.songFactory.create()).getId());

        return relatedSong;
    }

    public SongClient getSongClient() {
        return songClient;
    }

    public void setSongClient(SongClient songClient) {
        this.songClient = songClient;
    }

    public SongFactory getSongFactory() {
        return songFactory;
    }

    public void setSongFactory(SongFactory songFactory) {
        this.songFactory = songFactory;
    }

}
