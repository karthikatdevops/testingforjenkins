package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.RatingComparator;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.image.api.test.MainImageInfoComparator;
import org.testng.Assert;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Asserts equality on programs.
 *
 * @since 4/7/2011
 */
public class ProgramComparator {

    private ProgramComparator() {

    }

    public static void assertEquals(Program actual, Program expected) {
        assertEquals(actual, expected, true);
    }

    public static void assertEquals(Program actual, Program expected, Boolean checkId) {

        if (checkId) {
            Assert.assertEquals(actual.getId(), expected.getId(), "Asserting Program.id");
        }

        Assert.assertEquals(actual.getTitle(), expected.getTitle(), "Asserting Program.title");
        Assert.assertEquals(actual.getShortTitle(), expected.getShortTitle(), "Asserting Program.shortTitle");
        Assert.assertEquals(actual.getMediumTitle(), expected.getMediumTitle(), "Asserting Program.mediumTitle");
        Assert.assertEquals(actual.getLongTitle(), expected.getLongTitle(), "Asserting Program.longTitle");
        Assert.assertEquals(actual.getYear(), expected.getYear(), "Asserting Program.year");
        Assert.assertEquals(actual.getShortSynopsis(), expected.getShortSynopsis(), "Asserting Program.shortSynopsis");
        Assert.assertEquals(actual.getMediumSynopsis(), expected.getMediumSynopsis(), "Asserting Program.mediumSynopsis");
        Assert.assertEquals(actual.getLongSynopsis(), expected.getLongSynopsis(), "Asserting Program.longSynopsis");
        Assert.assertEquals(actual.getRuntime(), expected.getRuntime(), "Asserting Program.runtime");
        Assert.assertEquals(actual.getType(), expected.getType(), "Asserting Program.type");
        Assert.assertEquals(actual.getLanguage(), expected.getLanguage(), "Asserting Program.language");

        RatingComparator.assertEquals(actual.getContentRatings(), expected.getContentRatings());

        Assert.assertEquals(actual.getPartNumber(), expected.getPartNumber(), "Asserting Program.partNumber");
        Assert.assertEquals(actual.getTotalParts(), expected.getTotalParts(), "Asserting Program.totalParts");
        Assert.assertEquals(actual.getStarRating(), expected.getStarRating(), "Asserting Program.starRating");
        Assert.assertEquals(actual.getCategory(), expected.getCategory(), "Asserting Program.category");
        Assert.assertEquals(actual.getFirstRunCompanyId(), expected.getFirstRunCompanyId());
        Assert.assertEquals(actual.getAdult(), expected.getAdult());
        Assert.assertEquals(actual.getLocal(), expected.getLocal(), "Asserting Program.local");
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType(), "Asserting Program.merlinResourceType");
        Assert.assertEquals(actual.getListByTitle(), expected.getListByTitle(), "Asserting Program.listByTitle");
        Assert.assertEquals(actual.getSportsSubtitle(), expected.getSportsSubtitle());
        Assert.assertEquals(actual.getReleaseDate(), expected.getReleaseDate(), "Asserting Program.releaseDate");
        Assert.assertEquals(actual.getSeriesId(), expected.getSeriesId(), "Asserting Program.seriesId");
        Assert.assertEquals(actual.getTvSeasonId(), expected.getTvSeasonId(), "Asserting Program.tvSeasonId");
        Assert.assertEquals(actual.getOriginalAirDate(), expected.getOriginalAirDate(), "Asserting Program.originalAirDate");
        Assert.assertEquals(actual.getTvSeasonEpisodeNumber(), expected.getTvSeasonEpisodeNumber(), "Asserting Program.tvSeasonEpisodeNumber");
        Assert.assertEquals(actual.getSeriesEpisodeNumber(), expected.getSeriesEpisodeNumber(), "Asserting Program.seriesEpisodeNumber");
        Assert.assertEquals(actual.getTvSeasonNumber(), expected.getTvSeasonNumber(), "Asserting Program.tvSeasonNumber");
        Assert.assertEquals(actual.getEpisodeTitle(), expected.getEpisodeTitle(), "Asserting Program.episodeTitle");
        Assert.assertEquals(actual.getFirstAirDate(), expected.getFirstAirDate(), "Asserting Program.firstAirDate");
        Assert.assertEquals(actual.getLastAirDate(), expected.getLastAirDate(), "Asserting Program.lastAirDate");

        CreditAssociationComparator.assertEquals(actual.getCredits(), expected.getCredits());
        Assert.assertEquals(actual.getSortTitle(), expected.getSortTitle(), "Asserting Program.sortTitle");

        // Check if actual and expected have Tag IDs:
        if (actual.getTagIds() == null) {
            Assert.assertNull(expected.getTagIds());
        }
        // If they have Tag IDs, sort the lists and compare them. (If they have the same contents, they should
        // be considered equal, but if they're in different orders, a straight assertEquals will fail.)
        else {
            Assert.assertNotNull(expected.getTagIds());
            List<URI> actualTagIds = new ArrayList<>();
            actualTagIds.addAll(actual.getTagIds());
            Collections.sort(actualTagIds);
            List<URI> expectedTagIds = new ArrayList<>();
            expectedTagIds.addAll(expected.getTagIds());
            Collections.sort(expectedTagIds);
            Assert.assertEquals(actualTagIds, expectedTagIds);
        }

        Assert.assertEquals(actual.getImageIds(), expected.getImageIds());

        MainImageInfoComparator.assertEquals(actual.getSelectedImages(), expected.getSelectedImages());

    }

    public static void assertEquals(List<Program> expectedPrograms, List<Program> sortedPrograms) {
        for (int i = 0; i < expectedPrograms.size(); i++)
            assertEquals(sortedPrograms.get(i), expectedPrograms.get(i));
    }

    public static void assertEquals(Feed<Program> actualFeed, List<Program> expectedList) {
        List<Program> actualList = actualFeed.getEntries();

        Assert.assertEquals(actualList.size(), expectedList.size(), "The sizes of the actual feed and expected list of Programs are not equal.");
        for (int i = 0; i < expectedList.size(); i++)
            assertEquals(actualList.get(i), expectedList.get(i));

    }
}
