package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import org.testng.Assert;

import java.util.List;

public class SongComparator {

    public static void assertEquals(Song actual, Song expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getTitle(), expected.getTitle());
        Assert.assertEquals(actual.getSortTitle(), expected.getSortTitle());
        Assert.assertEquals(actual.getIsrc(), expected.getIsrc());
        Assert.assertEquals(actual.getDescription(), expected.getDescription());
        Assert.assertEquals(actual.getDuration(), expected.getDuration());
        Assert.assertEquals(actual.getPrimaryPersonIds(), expected.getPrimaryPersonIds());
        Assert.assertEquals(actual.getImageIds(), expected.getImageIds());
        Assert.assertEquals(actual.getTagIds(), expected.getTagIds());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<Song> actual, List<Song> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));

    }
}
