package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.SportsEventClient;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.fields.SportsEventField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

public class SportsEventFactory extends DataObjectFactoryImpl<SportsEvent, SportsEventClient> {

    public SportsEventFactory(SportsEventClient client, ValueProvider<Long> dataObjectIdProvider) {
        super(client, SportsEvent.class, dataObjectIdProvider);
        this.addPresetFieldsOverrides(
                SportsEventField.imageIds, new ArrayList<URI>(),
                SportsEventField.mainImages, new HashMap<String, MediaFile>(),
                SportsEventField.programIds, new ArrayList<URI>(),
                SportsEventField.selectedImages, new ArrayList<MainImageInfo>(),
                SportsEventField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()

        );
    }

}
