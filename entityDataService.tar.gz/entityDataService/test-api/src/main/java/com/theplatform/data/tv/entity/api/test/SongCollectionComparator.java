package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SongCollection;
import org.testng.Assert;

import java.util.List;

public class SongCollectionComparator {

    public static void assertEquals(SongCollection actual, SongCollection expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getTitle(), expected.getTitle());
        Assert.assertEquals(actual.getDescription(), expected.getDescription());
        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getSubtype(), expected.getSubtype());
        Assert.assertEquals(actual.getSongIds(), expected.getSongIds());
        Assert.assertEquals(actual.getPrimarySongId(), expected.getPrimarySongId());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());

    }

    public static void assertEquals(Feed<SongCollection> actual, List<SongCollection> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));

    }
}
