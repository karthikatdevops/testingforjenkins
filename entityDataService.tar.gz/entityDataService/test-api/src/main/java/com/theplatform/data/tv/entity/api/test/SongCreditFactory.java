package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;

public class SongCreditFactory extends EndpointFactory<SongCredit> {

    private PersonClient personClient;

    private PersonFactory personFactory;

    private SongClient songClient;

    private SongFactory songFactory;

    @Override
    public SongCredit create() {
        SongCredit songCredit = super.create();
        songCredit.setPersonId(this.personClient.create(personFactory.create()).getId());
        songCredit.setSongId(this.songClient.create(songFactory.create()).getId());
        return songCredit;

    }

    public PersonClient getPersonClient() {
        return personClient;
    }

    public void setPersonClient(PersonClient personClient) {
        this.personClient = personClient;
    }

    public PersonFactory getPersonFactory() {
        return personFactory;
    }

    public void setPersonFactory(PersonFactory personFactory) {
        this.personFactory = personFactory;
    }

    public SongClient getSongClient() {
        return songClient;
    }

    public void setSongClient(SongClient songClient) {
        this.songClient = songClient;
    }

    public SongFactory getSongFactory() {
        return songFactory;
    }

    public void setSongFactory(SongFactory songFactory) {
        this.songFactory = songFactory;
    }

}
