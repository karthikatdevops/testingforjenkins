package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociation;

public class ProgramSongAssociationFactory extends EndpointFactory<ProgramSongAssociation> {

    private ProgramClient programClient;
    private ProgramEndpointFactory programFactory;

    private SongClient songClient;
    private SongFactory songFactory;

    @Override
    public ProgramSongAssociation create() {

        ProgramSongAssociation programSongAssociation = super.create();
        Program program = this.programClient.create(programFactory.create(), new String[]{});
        programSongAssociation.setProgramId(program.getId());
        programSongAssociation.setSongId(this.songClient.create(songFactory.create()).getId());
        // read only field. set default value here for development convenience
        programSongAssociation.setProgramType(program.getType());
        return programSongAssociation;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }

    public ProgramEndpointFactory getProgramFactory() {
        return programFactory;
    }

    public void setProgramFactory(ProgramEndpointFactory programFactory) {
        this.programFactory = programFactory;
    }

    public SongClient getSongClient() {
        return songClient;
    }

    public void setSongClient(SongClient songClient) {
        this.songClient = songClient;
    }

    public SongFactory getSongFactory() {
        return songFactory;
    }

    public void setSongFactory(SongFactory songFactory) {
        this.songFactory = songFactory;
    }

}
