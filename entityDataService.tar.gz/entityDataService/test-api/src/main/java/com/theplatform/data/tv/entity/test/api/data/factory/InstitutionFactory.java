package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.InstitutionClient;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.fields.InstitutionField;

/**
 * Created by lemuri200 on 8/27/14.
 */
public class InstitutionFactory extends DataObjectFactoryImpl<Institution, InstitutionClient> {

    public InstitutionFactory(InstitutionClient client, ValueProvider<Long> idProvider) {
        super(client, Institution.class, idProvider);

        addPresetFieldsOverrides(
                InstitutionField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, new PrefixedIdFieldProvider("author"),
                DataObjectField.description, new PrefixedIdFieldProvider("description"),
                DataObjectField.title, new PrefixedIdFieldProvider("title"),
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }
}
