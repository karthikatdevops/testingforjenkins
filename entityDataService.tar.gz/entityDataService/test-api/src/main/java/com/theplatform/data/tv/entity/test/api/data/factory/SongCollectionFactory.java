package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.SongCollectionClient;
import com.theplatform.data.tv.entity.api.data.objects.SongCollection;
import com.theplatform.data.tv.entity.api.data.objects.SongCollectionType;
import com.theplatform.data.tv.entity.api.fields.SongCollectionField;

import java.net.URI;
import java.util.ArrayList;

/**
 * Created by lemuri200 on 9/2/14.
 */
public class SongCollectionFactory extends DataObjectFactoryImpl<SongCollection, SongCollectionClient> {

    public SongCollectionFactory(SongCollectionClient client, ValueProvider<Long> idProvider) {
        super(client, SongCollection.class, idProvider);

        addPresetFieldsOverrides(
                SongCollectionField.type, SongCollectionType.Variant.getFriendlyName(),
                SongCollectionField.songIds, new ArrayList<URI>(),
                SongCollectionField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                DataObjectField.title, "title",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }
}
