package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.image.api.test.MainImageInfoComparator;
import org.testng.Assert;

import java.util.HashSet;
import java.util.List;

/**
 * Asserts equality on Persons.
 *
 * @since 4/7/2011
 */
public class PersonComparator {

    private PersonComparator() {
    }

    public static void assertEquals(Person actual, Person expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getName(), expected.getName());
        Assert.assertEquals(actual.getPersonType(), expected.getPersonType());
        Assert.assertEquals(new HashSet<>(actual.getKnownFor()), new HashSet<>(expected.getKnownFor()));
        Assert.assertEquals(actual.getBirth(), expected.getBirth());
        Assert.assertEquals(actual.getDeath(), expected.getDeath());
        Assert.assertEquals(actual.getBirthplace(), expected.getBirthplace());
        Assert.assertEquals(actual.getShortBio(), expected.getShortBio());
        Assert.assertEquals(actual.getMediumBio(), expected.getMediumBio());
        Assert.assertEquals(actual.getLongBio(), expected.getLongBio());
        CreditAssociationComparator.assertEquals(actual.getCredits(), expected.getCredits());
        Assert.assertEquals(actual.getBirthName(), expected.getBirthName());
        Assert.assertEquals(actual.getSortName(), expected.getSortName());
        Assert.assertEquals(actual.getAliases(), expected.getAliases());
        Assert.assertEquals(actual.getImageIds(), expected.getImageIds());
//		Assert.assertEquals(actual.getMainImages(), expected.getMainImages());
        MainImageInfoComparator.assertEquals(actual.getSelectedImages(), expected.getSelectedImages());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());

    }

    public static void assertEquals(List<Person> expectedPersons, List<Person> sortedPersons) {
        for (int i = 0; i < expectedPersons.size(); i++)
            PersonComparator.assertEquals(sortedPersons.get(i), expectedPersons.get(i));
    }

    public static void assertEquals(Feed<Person> actualPersonFeed, List<Person> expectedPersons) {
        List<Person> actualPersons = actualPersonFeed.getEntries();
        Assert.assertEquals(actualPersons.size(), expectedPersons.size(), "Unexpected number of Persons");
        for (int i = 0; i < expectedPersons.size(); i++)
            assertEquals(actualPersons.get(i), expectedPersons.get(i));

    }
}