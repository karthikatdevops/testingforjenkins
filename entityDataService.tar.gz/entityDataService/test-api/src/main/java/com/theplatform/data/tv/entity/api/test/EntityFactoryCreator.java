package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.contrib.testing.provider.GBTestIdProvider;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.AlbumClient;
import com.theplatform.data.tv.entity.api.client.AlbumReleaseClient;
import com.theplatform.data.tv.entity.api.client.AwardClient;
import com.theplatform.data.tv.entity.api.client.InstitutionClient;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.client.SportsEventClient;
import com.theplatform.data.tv.entity.api.client.SportsTeamClient;
import com.theplatform.data.tv.entity.api.client.TagClient;
import com.theplatform.data.tv.entity.api.data.objects.*;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.media.api.data.objects.MediaFile;
import com.theplatform.media.api.data.objects.Rating;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author jethrolai
 */
public class EntityFactoryCreator {

    public static CreditFactory createCreditFactory(String entityBaseUrl, GBTestIdProvider idProvider, PersonClient personClient, PersonFactory personFactory,
                                                    ProgramClient entityClient, ProgramEndpointFactory entityFactory, PersonAssociationFactory personAssociationFactory,
                                                    ProgramAssociationFactory programAssociationFactory, Credit template) {
        CreditFactory creditFactory = new CreditFactory();
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        creditFactory.setBaseUrl(entityBaseUrl);
        creditFactory.setEndpointName("Credit");
        creditFactory.setEntityType(MerlinEntityType.CREDIT);
        creditFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        creditFactory.setPersonClient(personClient);
        creditFactory.setPersonFactory(personFactory);
        creditFactory.setProgramClient(entityClient);
        creditFactory.setProgramFactory(entityFactory);
        creditFactory.setPersonAssociationFactory(personAssociationFactory);
        creditFactory.setProgramAssociationFactory(programAssociationFactory);

        if (template == null) {
            template = new Credit();
            template.setCameo(false);
            template.setActive(true);
            template.setImageIds(new ArrayList<URI>());
            template.setSelectedImages(new ArrayList<MainImageInfo>());
            template.setMainImages(new HashMap<String, MediaFile>());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        creditFactory.setTemplateEndpoint(template);

        return creditFactory;
    }

    public static PersonFactory createPersonFactory(String entityBaseUrl, GBTestIdProvider idProvider, Person template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        PersonFactory personFactory = new PersonFactory();
        personFactory.setBaseUrl(entityBaseUrl);
        personFactory.setEndpointName("Person");
        personFactory.setEntityType(MerlinEntityType.PERSON);
        personFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = new Person();
            template.setName("person name");

            DateOnly birth = new DateOnly();
            birth.setMonth(12);
            birth.setDay(4);
            birth.setYear(1980);

            template.setBirth(birth);

            DateOnly death = new DateOnly();

            death.setYear(3000);
            death.setMonth(12);
            death.setDay(4);
            template.setDeath(death);

            template.setBirthplace("person's birthplace");
            template.setShortBio("person's short bio, normally 1-2 sentences");
            template.setMediumBio("person's medium bio, about one paragraph");
            template.setLongBio("person's long bio, about several paragraph");
            template.setBirthName("person's birth name");
            template.setSortName("person's sort name");

            List<String> aliases = new ArrayList<>();
            aliases.add("person's alias");
            template.setAliases(aliases);

            template.setImageIds(new ArrayList<URI>());
            template.setSelectedImages(new ArrayList<MainImageInfo>());

            template.setPersonType(PersonType.Person.getFriendlyName());

            List<String> knownFor = new ArrayList<>();
            knownFor.add(PersonKnownForType.Music.getFriendlyName());
            knownFor.add(PersonKnownForType.Video.getFriendlyName());
            template.setKnownFor(knownFor);

            template.setCredits(new ArrayList<CreditAssociation>());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        personFactory.setTemplateEndpoint(template);

        return personFactory;

    }

    public static ProgramEndpointFactory createProgramFactory(String entityBaseUrl, GBTestIdProvider idProvider) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ProgramEndpointFactory programFactory = new ProgramEndpointFactory();
        programFactory.setProgramMovieFactory(createProgramMovieFactory(entityBaseUrl, idProvider, null));
        programFactory.setProgramEpisodeFactory(createProgramEpisodeFactory(entityBaseUrl, idProvider, null));
        programFactory.setProgramSeriesMasterFactory(createProgramSeriesMasterFactory(entityBaseUrl, idProvider, null));
        return programFactory;
    }

    public static ProgramMovieFactory createProgramMovieFactory(String entityBaseUrl, GBTestIdProvider idProvider, Program template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ProgramMovieFactory programMovieFactory = new ProgramMovieFactory();
        programMovieFactory.setBaseUrl(entityBaseUrl);
        programMovieFactory.setEndpointName("Program");
        programMovieFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);
        programMovieFactory.setEntityType(MerlinEntityType.PROGRAM);

        if (template == null) {
            template = createCommonProgram();

            DateOnly releaseDate = new DateOnly();
            releaseDate.setYear(1999);
            releaseDate.setMonth(12);
            releaseDate.setDay(4);
            template.setType(ProgramType.Movie);
            template.setReleaseDate(releaseDate);
        }
        programMovieFactory.setTemplateEndpoint(template);

        return programMovieFactory;
    }

    public static ProgramEpisodeFactory createProgramEpisodeFactory(String entityBaseUrl, GBTestIdProvider idProvider, Program template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ProgramEpisodeFactory programEpisodeFactory = new ProgramEpisodeFactory();
        programEpisodeFactory.setBaseUrl(entityBaseUrl);
        programEpisodeFactory.setEndpointName("Program");
        programEpisodeFactory.setEntityType(MerlinEntityType.PROGRAM);

        programEpisodeFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = createCommonProgram();

            template.setType(ProgramType.Episode);

            template.setTvSeasonEpisodeNumber(4);
            template.setSeriesEpisodeNumber(5);
            template.setTvSeasonNumber(6);
            template.setEpisodeTitle("episode title");
        }
        programEpisodeFactory.setTemplateEndpoint(template);

        return programEpisodeFactory;
    }

    public static ProgramSeriesMasterFactory createProgramSeriesMasterFactory(String entityBaseUrl, GBTestIdProvider idProvider, Program template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ProgramSeriesMasterFactory programSeriesMasterFactory = new ProgramSeriesMasterFactory();
        programSeriesMasterFactory.setBaseUrl(entityBaseUrl);
        programSeriesMasterFactory.setEndpointName("Program");
        programSeriesMasterFactory.setEntityType(MerlinEntityType.PROGRAM);

        programSeriesMasterFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = createCommonProgram();

            template.setType(ProgramType.SeriesMaster);
            DateOnly firstAirDate = new DateOnly();
            firstAirDate.setDay(7);
            firstAirDate.setMonth(4);
            firstAirDate.setYear(1999);

            template.setFirstAirDate(firstAirDate);
            DateOnly lastAirDate = new DateOnly();
            lastAirDate.setDay(3);
            lastAirDate.setMonth(3);
            lastAirDate.setYear(2004);
            template.setLastAirDate(lastAirDate);
            template.setRuntime(null);
        }

        programSeriesMasterFactory.setTemplateEndpoint(template);

        return programSeriesMasterFactory;
    }

    private static Program createCommonProgram() {
        Program program = new Program();
        program.setTitle("program title");
        program.setShortTitle("program short title");
        program.setMediumTitle("program medium title");
        program.setYear(2005);
        program.setShortSynopsis("program shortSynopsis");
        program.setMediumSynopsis("program mediumSynopsis");
        program.setLongSynopsis("program longSynopsis");
        program.setRuntime(120);
        program.setType(ProgramType.Movie);
        program.setLanguage("eng");

        program.setPartNumber(2);
        program.setTotalParts(4);
        program.setStarRating(2);
        program.setCategory("Movie");
        program.setAdult(true);
        program.setLocal(true);

        program.setListByTitle(true);

        DateOnly originalAirDate = new DateOnly();
        originalAirDate.setDay(5);
        originalAirDate.setMonth(11);
        originalAirDate.setYear(2003);

        program.setOriginalAirDate(originalAirDate);
        program.setSortTitle("program sort title");

        program.setImageIds(new ArrayList<URI>());
        program.setTagIds(new ArrayList<URI>());
        program.setCredits(new ArrayList<CreditAssociation>());
        program.setSelectedImages(new ArrayList<MainImageInfo>());

        program.setMerlinResourceType(MerlinResourceType.AudienceAvailable);

        return program;
    }

    public static ProgramMediaAssociationFactory createProgramMediaAssociationFactory(String entityBaseUrl, GBTestIdProvider idProvider,
                                                                                      ProgramClient programClient, ProgramEndpointFactory programFactory, ProgramMediaAssociation template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ProgramMediaAssociationFactory programMediaAssociationFactory = new ProgramMediaAssociationFactory();
        programMediaAssociationFactory.setBaseUrl(entityBaseUrl);
        programMediaAssociationFactory.setEndpointName("ProgramMediaAssociation");
        programMediaAssociationFactory.setEntityType(MerlinEntityType.PROGRAMMEDIAASSOCIATION);

        programMediaAssociationFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        programMediaAssociationFactory.setProgramClient(programClient);
        programMediaAssociationFactory.setProgramFactory(programFactory);

        if (template == null) {
            template = new ProgramMediaAssociation();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        programMediaAssociationFactory.setTemplateEndpoint(template);

        return programMediaAssociationFactory;
    }

    public static ReviewFactory createReviewFactory(String entityBaseUrl, GBTestIdProvider idProvider, ProgramClient programClient,
                                                    ProgramEndpointFactory programFactory, Review template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ReviewFactory reviewFactory = new ReviewFactory();
        reviewFactory.setBaseUrl(entityBaseUrl);
        reviewFactory.setEndpointName("Review");
        reviewFactory.setEntityType(MerlinEntityType.REVIEW);
        reviewFactory.setProgramClient(programClient);
        reviewFactory.setProgramFactory(programFactory);

        reviewFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = new Review();
            template.setProvider("fiji");
            template.setSummary("review summary");
            template.setDescription("review description");
            template.setReview("review review");
            template.setRecommendation("review recommendation");
            template.setStarRating(3);
            template.setSource("review source");

            List<Rating> contentRatings = new ArrayList<>();
            Rating contentRating = new Rating();
            contentRating.setScheme("urn:mpaa");
            contentRating.setRating("R");
            contentRatings.add(contentRating);
            template.setContentRatings(contentRatings);
        }
        reviewFactory.setTemplateEndpoint(template);

        return reviewFactory;
    }

    public static TvSeasonFactory createTvSeasonFactory(String entityBaseUrl, GBTestIdProvider idProvider, ProgramClient programClient,
                                                        ProgramEndpointFactory programFactory, TvSeason template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        TvSeasonFactory tvSeasonFactory = new TvSeasonFactory();
        tvSeasonFactory.setBaseUrl(entityBaseUrl);
        tvSeasonFactory.setEndpointName("TvSeason");
        tvSeasonFactory.setEntityType(MerlinEntityType.TVSEASON);
        tvSeasonFactory.setProgramClient(programClient);
        tvSeasonFactory.setProgramFactory(programFactory);

        tvSeasonFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {

            template = new TvSeason();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        tvSeasonFactory.setTemplateEndpoint(template);

        return tvSeasonFactory;
    }

    public static RelatedProgramFactory createRelatedProgramFactory(String entityBaseUrl, GBTestIdProvider idProvider, ProgramClient programClient,
                                                                    ProgramEndpointFactory programFactory, RelatedProgram template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        RelatedProgramFactory relatedProgramFactory = new RelatedProgramFactory();
        relatedProgramFactory.setBaseUrl(entityBaseUrl);
        relatedProgramFactory.setEndpointName("RelatedProgram");
        relatedProgramFactory.setEntityType(MerlinEntityType.RELATEDPROGRAM);
        relatedProgramFactory.setProgramClient(programClient);
        relatedProgramFactory.setProgramFactory(programFactory);

        relatedProgramFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = new RelatedProgram();
            template.setType(RelatedProgramType.HasSpinoff.getFriendlyName());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        relatedProgramFactory.setTemplateEndpoint(template);

        return relatedProgramFactory;
    }

    public static EntityCollectionFactory createEntityCollectionFactory(String entityBaseUrl, GBTestIdProvider idProvider, EntityCollection template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        EntityCollectionFactory entityCollectionFactory = new EntityCollectionFactory();
        entityCollectionFactory.setBaseUrl(entityBaseUrl);
        entityCollectionFactory.setEndpointName("EntityCollection");
        entityCollectionFactory.setEntityType(MerlinEntityType.ENTITYCOLLECTION);

        entityCollectionFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {

            template = new EntityCollection();
            template.setTitle("Entity Collection title");
            template.setDescription("Entity Collection description");
            template.setType(EntityCollectionType.Variant.getFriendlyName());
            template.setSubtype("Language");
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
            template.setEntityIds(new ArrayList<URI>());
            template.setSelectedImages(new ArrayList<MainImageInfo>());
            template.setPrimaryEntities(new HashMap<String, URI>());
        }
        entityCollectionFactory.setTemplateEndpoint(template);
        return entityCollectionFactory;
    }

    public static TagFactory createTagFactory(String entityBaseUrl, GBTestIdProvider idProvider, Tag template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        TagFactory tagFactory = new TagFactory();
        tagFactory.setBaseUrl(entityBaseUrl);
        tagFactory.setEndpointName("Tag");
        tagFactory.setEntityType(MerlinEntityType.TAG);

        tagFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);
        if (template == null) {

            template = new Tag();
            template.setTitle("Very Funny");
            template.setType("Keyword");
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        tagFactory.setTemplateEndpoint(template);
        return tagFactory;
    }

    public static SportsTeamFactory createSportsTeamFactory(String entityBaseUrl, GBTestIdProvider idProvider, SportsTeam template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        SportsTeamFactory sportsTeamFactory = new SportsTeamFactory();
        sportsTeamFactory.setBaseUrl(entityBaseUrl);
        sportsTeamFactory.setEndpointName("SportsTeam");
        sportsTeamFactory.setEntityType(MerlinEntityType.SPORTSTEAM);

        sportsTeamFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = new SportsTeam();
            template.setImageIds(new ArrayList<URI>());
            template.setSelectedImages(new ArrayList<MainImageInfo>());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
            template.setShortBio("This is short bio information");
            template.setMediumBio("This is medium bio information");
            template.setLongBio("This is long bio information");
        }
        sportsTeamFactory.setTemplateEndpoint(template);
        return sportsTeamFactory;
    }

    public static SportsEventFactory createSportsEventFactory(String entityBaseUrl, GBTestIdProvider idProvider, SportsEvent template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        SportsEventFactory sportsEventFactory = new SportsEventFactory();
        sportsEventFactory.setBaseUrl(entityBaseUrl);
        sportsEventFactory.setEndpointName("SportsEvent");
        sportsEventFactory.setEntityType(MerlinEntityType.SPORTSEVENT);
        sportsEventFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {

            template = new SportsEvent();
            template.setImageIds(new ArrayList<URI>());
            template.setProgramIds(new ArrayList<URI>());
            template.setSelectedImages(new ArrayList<MainImageInfo>());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        sportsEventFactory.setTemplateEndpoint(template);

        return sportsEventFactory;
    }

    public static ProgramTeamAssociationFactory createProgramTeamAssociationFactory(String entityBaseUrl, GBTestIdProvider idProvider,
                                                                                    ProgramClient programClient, ProgramEndpointFactory programFactory, SportsTeamClient sportsTeamClient, SportsTeamFactory sportsTeamFactory,
                                                                                    ProgramTeamAssociation template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ProgramTeamAssociationFactory programTeamAssociationFactory = new ProgramTeamAssociationFactory();
        programTeamAssociationFactory.setBaseUrl(entityBaseUrl);
        programTeamAssociationFactory.setEndpointName("ProgramTeamAssociation");
        programTeamAssociationFactory.setEntityType(MerlinEntityType.PROGRAMTEAMASSOCIATION);

        programTeamAssociationFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        programTeamAssociationFactory.setProgramClient(programClient);
        programTeamAssociationFactory.setProgramFactory(programFactory);
        programTeamAssociationFactory.setSportsTeamClient(sportsTeamClient);
        programTeamAssociationFactory.setSportsTeamFactory(sportsTeamFactory);

        if (template == null) {

            template = new ProgramTeamAssociation();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        programTeamAssociationFactory.setTemplateEndpoint(template);

        return programTeamAssociationFactory;
    }

    public static SportsLeagueFactory createSportsLeagueFactory(String entityBaseUrl, GBTestIdProvider idProvider, SportsLeague template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        SportsLeagueFactory sportsLeagueFactory = new SportsLeagueFactory();
        sportsLeagueFactory.setBaseUrl(entityBaseUrl);
        sportsLeagueFactory.setEndpointName("SportsLeague");
        sportsLeagueFactory.setEntityType(MerlinEntityType.SPORTSLEAGUE);

        sportsLeagueFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = new SportsLeague();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        sportsLeagueFactory.setTemplateEndpoint(template);
        return sportsLeagueFactory;
    }

    public static ProgramSportsEventFactory createProgramSportsEventFactory(String entityBaseUrl, GBTestIdProvider idProvider, ProgramClient programClient,
                                                                            ProgramEndpointFactory programFactory, SportsEventClient sportsEventClient, SportsEventFactory sportsEventFactory, ProgramSportsEvent template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ProgramSportsEventFactory programSportsEventFactory = new ProgramSportsEventFactory();
        programSportsEventFactory.setBaseUrl(entityBaseUrl);
        programSportsEventFactory.setEndpointName("ProgramSportsEvent");
        programSportsEventFactory.setEntityType(MerlinEntityType.PROGRAMSPORTSEVENT);

        programSportsEventFactory.setProgramClient(programClient);
        programSportsEventFactory.setProgramFactory(programFactory);
        programSportsEventFactory.setSportsEventClient(sportsEventClient);
        programSportsEventFactory.setSportsEventFactory(sportsEventFactory);
        programSportsEventFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);
        if (template == null) {

            template = new ProgramSportsEvent();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        programSportsEventFactory.setTemplateEndpoint(template);

        return programSportsEventFactory;
    }

    public static ProgramRankFactory createProgramRankFactory(String entityBaseUrl, GBTestIdProvider idProvider, ProgramClient programClient,
                                                              ProgramEndpointFactory programFactory, ProgramRank template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ProgramRankFactory programRankFactory = new ProgramRankFactory();
        programRankFactory.setBaseUrl(entityBaseUrl);
        programRankFactory.setEndpointName("ProgramRank");
        programRankFactory.setProgramClient(programClient);
        programRankFactory.setProgramFactory(programFactory);

        // This doesn't really matter because the id of programRank is generated
        programRankFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);
        if (template == null) {

            template = new ProgramRank();
            template.setType("Algorithmic");
            template.setRank(0.5f);
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        programRankFactory.setTemplateEndpoint(template);

        return programRankFactory;
    }

    public static AwardFactory createAwardFactory(String entityBaseUrl, GBTestIdProvider idProvider, Award template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        AwardFactory awardFactory = new AwardFactory();
        awardFactory.setBaseUrl(entityBaseUrl);
        awardFactory.setEndpointName("Award");
        awardFactory.setEntityType(MerlinEntityType.AWARD);
        awardFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = new Award();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
            template.setTitle("Award title");
            template.setDescription("Award description");
            template.setRank(1);
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        awardFactory.setTemplateEndpoint(template);
        return awardFactory;
    }

    public static InstitutionFactory createInstitutionFactory(String entityBaseUrl, GBTestIdProvider idProvider, Institution template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        InstitutionFactory institutionFactory = new InstitutionFactory();
        institutionFactory.setBaseUrl(entityBaseUrl);
        institutionFactory.setEndpointName("Institution");
        institutionFactory.setEntityType(MerlinEntityType.INSTITUTION);
        institutionFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = new Institution();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
            template.setTitle("Institution title");
            template.setDescription("Institution description");
        }
        institutionFactory.setTemplateEndpoint(template);
        return institutionFactory;
    }

    public static AwardAssociationFactory createAwardAssociationFactory(String entityBaseUrl, GBTestIdProvider idProvider, AwardClient awardClient,
                                                                        AwardFactory awardFactory, InstitutionClient institutionClient, InstitutionFactory institutionFactory, PersonClient personClient,
                                                                        PersonFactory personFactory, AwardAssociation template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        AwardAssociationFactory awardAssociationFactory = new AwardAssociationFactory();
        awardAssociationFactory.setBaseUrl(entityBaseUrl);
        awardAssociationFactory.setEndpointName("AwardAssociation");
        awardAssociationFactory.setEntityType(MerlinEntityType.AWARDASSOCIATION);
        awardAssociationFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        awardAssociationFactory.setAwardClient(awardClient);
        awardAssociationFactory.setAwardFactory(awardFactory);

        awardAssociationFactory.setInstitutionClient(institutionClient);
        awardAssociationFactory.setInstitutionFactory(institutionFactory);

        awardAssociationFactory.setPersonClient(personClient);
        awardAssociationFactory.setPersonFactory(personFactory);

        if (template == null) {

            template = new AwardAssociation();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
            template.setDescription("Award description");
            template.setYear(2012);
            template.setAwardStatus("Winner");
            template.setAwardType("Person");
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        awardAssociationFactory.setTemplateEndpoint(template);
        return awardAssociationFactory;
    }

    public static AlbumFactory createAlbumFactory(String entityBaseUrl, GBTestIdProvider idProvider, Album template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        AlbumFactory albumFactory = new AlbumFactory();
        albumFactory.setBaseUrl(entityBaseUrl);
        albumFactory.setEndpointName("Album");
        albumFactory.setEntityType(MerlinEntityType.ALBUM);

        albumFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {

            template = new Album();
            template.setPrimaryPersonIds(new ArrayList<URI>());
            template.setImageIds(new ArrayList<URI>());
            template.setTagIds(new ArrayList<URI>());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        albumFactory.setTemplateEndpoint(template);
        return albumFactory;
    }

    public static AlbumCreditFactory createAlbumCreditFactory(String entityBaseUrl, GBTestIdProvider idProvider, PersonClient personClient,
                                                              PersonFactory personFactory, AlbumClient albumClient, AlbumFactory albumFactory, AlbumCredit template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        AlbumCreditFactory albumCreditFactory = new AlbumCreditFactory();
        albumCreditFactory.setBaseUrl(entityBaseUrl);
        albumCreditFactory.setEndpointName("AlbumCredit");
        albumCreditFactory.setEntityType(MerlinEntityType.ALBUMCREDIT);
        albumCreditFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        albumCreditFactory.setPersonClient(personClient);
        albumCreditFactory.setPersonFactory(personFactory);
        albumCreditFactory.setAlbumClient(albumClient);
        albumCreditFactory.setAlbumFactory(albumFactory);

        if (template == null) {
            template = new AlbumCredit();
            template.setActive(true);
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        albumCreditFactory.setTemplateEndpoint(template);

        return albumCreditFactory;
    }

    public static AlbumReleaseFactory createAlbumReleaseFactory(String entityBaseUrl, GBTestIdProvider idProvider, AlbumClient albumClient,
                                                                AlbumFactory albumFactory, AlbumRelease template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        AlbumReleaseFactory albumReleaseFactory = new AlbumReleaseFactory();
        albumReleaseFactory.setBaseUrl(entityBaseUrl);
        albumReleaseFactory.setEndpointName("AlbumRelease");
        albumReleaseFactory.setEntityType(MerlinEntityType.ALBUMRELEASE);

        albumReleaseFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);
        albumReleaseFactory.setAlbumClient(albumClient);
        albumReleaseFactory.setAlbumFactory(albumFactory);

        if (template == null) {

            template = new AlbumRelease();
            template.setMainRelease(false);
            template.setContentRatings(new ArrayList<Rating>());
            template.setImageIds(new ArrayList<URI>());
            template.setTagIds(new ArrayList<URI>());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        albumReleaseFactory.setTemplateEndpoint(template);

        return albumReleaseFactory;
    }

    public static SongFactory createSongFactory(String entityBaseUrl, GBTestIdProvider idProvider, Song template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        SongFactory songFactory = new SongFactory();
        songFactory.setBaseUrl(entityBaseUrl);
        songFactory.setEndpointName("Song");
        songFactory.setEntityType(MerlinEntityType.SONG);
        songFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = new Song();
            template.setPrimaryPersonIds(new ArrayList<URI>());
            template.setImageIds(new ArrayList<URI>());
            template.setTagIds(new ArrayList<URI>());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        songFactory.setTemplateEndpoint(template);
        return songFactory;
    }

    public static SongCreditFactory createSongCreditFactory(String entityBaseUrl, GBTestIdProvider idProvider, PersonClient personClient,
                                                            PersonFactory personFactory, SongClient songClient, SongFactory songFactory, SongCredit template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        SongCreditFactory songCreditFactory = new SongCreditFactory();
        songCreditFactory.setBaseUrl(entityBaseUrl);
        songCreditFactory.setEndpointName("SongCredit");
        songCreditFactory.setEntityType(MerlinEntityType.SONGCREDIT);
        songCreditFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);
        songCreditFactory.setPersonClient(personClient);
        songCreditFactory.setPersonFactory(personFactory);
        songCreditFactory.setSongClient(songClient);
        songCreditFactory.setSongFactory(songFactory);

        if (template == null) {

            template = new SongCredit();
            template.setActive(true);
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        songCreditFactory.setTemplateEndpoint(template);

        return songCreditFactory;
    }

    public static RelatedPersonFactory createRelatedPersonFactory(String entityBaseUrl, GBTestIdProvider idProvider, PersonClient personClient,
                                                                  PersonFactory personFactory, RelatedPerson template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        RelatedPersonFactory relatedPersonFactory = new RelatedPersonFactory();
        relatedPersonFactory.setBaseUrl(entityBaseUrl);
        relatedPersonFactory.setEndpointName("RelatedPerson");
        relatedPersonFactory.setEntityType(MerlinEntityType.RELATEDPERSON);
        relatedPersonFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        relatedPersonFactory.setPersonClient(personClient);
        relatedPersonFactory.setPersonFactory(personFactory);
        if (template == null) {

            template = new RelatedPerson();
            template.setType(RelatedPersonType.hasSimilarMusic.getFriendlyName());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        relatedPersonFactory.setTemplateEndpoint(template);

        return relatedPersonFactory;
    }

    public static RelatedAlbumFactory createRelatedAlbumFactory(String entityBaseUrl, GBTestIdProvider idProvider, AlbumClient albumClient,
                                                                AlbumFactory albumFactory, RelatedAlbum template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        RelatedAlbumFactory relatedAlbumFactory = new RelatedAlbumFactory();
        relatedAlbumFactory.setBaseUrl(entityBaseUrl);
        relatedAlbumFactory.setEndpointName("RelatedAlbum");
        relatedAlbumFactory.setEntityType(MerlinEntityType.RELATEDALBUM);
        relatedAlbumFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        relatedAlbumFactory.setAlbumClient(albumClient);
        relatedAlbumFactory.setAlbumFactory(albumFactory);

        if (template == null) {
            template = new RelatedAlbum();
            template.setType(RelatedAlbumType.IsSimilar.getFriendlyName());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        relatedAlbumFactory.setTemplateEndpoint(template);

        return relatedAlbumFactory;
    }

    public static RelatedSongFactory createRelatedSongFactory(String entityBaseUrl, GBTestIdProvider idProvider, SongClient songClient,
                                                              SongFactory songFactory, RelatedSong template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        RelatedSongFactory relatedSongFactory = new RelatedSongFactory();
        relatedSongFactory.setBaseUrl(entityBaseUrl);
        relatedSongFactory.setEndpointName("RelatedSong");
        relatedSongFactory.setEntityType(MerlinEntityType.RELATEDSONG);
        relatedSongFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        relatedSongFactory.setSongClient(songClient);
        relatedSongFactory.setSongFactory(songFactory);

        if (template == null) {
            template = new RelatedSong();
            template.setType(RelatedSongType.IsSimilar.getFriendlyName());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }

        relatedSongFactory.setTemplateEndpoint(template);
        return relatedSongFactory;
    }

    public static AlbumReleaseSongAssociationFactory createAlbumReleaseSongAssociationFactory(
            String entityBaseUrl,
            GBTestIdProvider idProvider,
            AlbumReleaseSongAssociation template,
            AlbumReleaseClient albumReleaseClient,
            AlbumReleaseFactory albumReleaseFactory,
            SongClient songClient,
            SongFactory songFactory) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        AlbumReleaseSongAssociationFactory albumReleaseSongAssociationFactory = new AlbumReleaseSongAssociationFactory();
        albumReleaseSongAssociationFactory.setBaseUrl(entityBaseUrl);
        albumReleaseSongAssociationFactory.setEndpointName("AlbumReleaseSongAssociation");
        albumReleaseSongAssociationFactory.setEntityType(MerlinEntityType.ALBUMRELEASESONGASSOCIATION);
        albumReleaseSongAssociationFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);
        albumReleaseSongAssociationFactory.setAlbumReleaseClient(albumReleaseClient);
        albumReleaseSongAssociationFactory.setAlbumReleaseFactory(albumReleaseFactory);
        albumReleaseSongAssociationFactory.setSongClient(songClient);
        albumReleaseSongAssociationFactory.setSongFactory(songFactory);

        if (template == null) {
            template = new AlbumReleaseSongAssociation();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        albumReleaseSongAssociationFactory.setTemplateEndpoint(template);

        return albumReleaseSongAssociationFactory;
    }

    public static ProgramSongAssociationFactory createProgramSongAssociationFactory(String entityBaseUrl, GBTestIdProvider idProvider,
                                                                                    ProgramClient programClient, ProgramEndpointFactory programFactory, SongClient songClient, SongFactory songFactory, ProgramSongAssociation template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        ProgramSongAssociationFactory programSongAssociationFactory = new ProgramSongAssociationFactory();
        programSongAssociationFactory.setBaseUrl(entityBaseUrl);
        programSongAssociationFactory.setEndpointName("ProgramSongAssociation");
        programSongAssociationFactory.setEntityType(MerlinEntityType.PROGRAMSONGASSOCIATION);
        programSongAssociationFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        programSongAssociationFactory.setProgramClient(programClient);
        programSongAssociationFactory.setProgramFactory(programFactory);
        programSongAssociationFactory.setSongClient(songClient);
        programSongAssociationFactory.setSongFactory(songFactory);
        if (template == null) {

            template = new ProgramSongAssociation();
            template.setType(ProgramSongAssociationType.MusicVideo.getFriendlyName());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        programSongAssociationFactory.setTemplateEndpoint(template);

        return programSongAssociationFactory;
    }

    public static SongCollectionFactory createSongCollectionFactory(String entityBaseUrl, GBTestIdProvider idProvider, SongCollection template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        SongCollectionFactory songCollectionFactory = new SongCollectionFactory();
        songCollectionFactory.setBaseUrl(entityBaseUrl);
        songCollectionFactory.setEndpointName("SongCollection");
        songCollectionFactory.setEntityType(MerlinEntityType.SONGCOLLECTION);

        songCollectionFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        if (template == null) {
            template = new SongCollection();
            template.setTitle("song collection title");
            template.setType(SongCollectionType.Variant.getFriendlyName());
            template.setSongIds(new ArrayList<URI>());
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
        }
        songCollectionFactory.setTemplateEndpoint(template);

        return songCollectionFactory;
    }

    public static TagAssociationFactory createTagAssociationFactory(String entityBaseUrl, GBTestIdProvider idProvider, DataServiceClient entityClient,
                                                                    EndpointFactory entityFactory, TagClient tagClient, TagFactory tagFactory, TagAssociation template) {
        entityBaseUrl = entityBaseUrl.charAt(entityBaseUrl.length() - 1) == '/' ? entityBaseUrl.substring(0, entityBaseUrl.length() - 1) : entityBaseUrl;
        TagAssociationFactory tagAssociationFactory = new TagAssociationFactory();
        tagAssociationFactory.setBaseUrl(entityBaseUrl);
        tagAssociationFactory.setEndpointName("TagAssociation");
        tagAssociationFactory.setEntityType(MerlinEntityType.TAGASSOCIATION);
        tagAssociationFactory.setIdProvider(idProvider == null ? new GBTestIdProvider() : idProvider);

        tagAssociationFactory.setEntityClient(entityClient);
        tagAssociationFactory.setEntityFactory(entityFactory);
        tagAssociationFactory.setTagClient(tagClient);
        tagAssociationFactory.setTagFactory(tagFactory);

        if (template == null) {
            template = new TagAssociation();
            template.setMerlinResourceType(MerlinResourceType.AudienceAvailable);
            template.setPrimary(true);
        }
        tagAssociationFactory.setTemplateEndpoint(template);

        return tagAssociationFactory;
    }

    public static PersonAssociationFactory createPersonAssociationFactory(PersonClient personClient) {
        PersonAssociationFactory personAssociationFactory = new PersonAssociationFactory();
        personAssociationFactory.setPersonClient(personClient);
        return personAssociationFactory;

    }

    public static ProgramAssociationFactory createProgramAssociationFactory(ProgramClient programClient) {
        ProgramAssociationFactory programAssociationFactory = new ProgramAssociationFactory();
        programAssociationFactory.setProgramClient(programClient);
        return programAssociationFactory;

    }

}