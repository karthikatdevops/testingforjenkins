package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.ProgramTeamAssociationClient;
import com.theplatform.data.tv.entity.api.client.SportsTeamClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.fields.ProgramTeamAssociationField;

public class ProgramTeamAssociationFactory extends DataObjectFactoryImpl<ProgramTeamAssociation, ProgramTeamAssociationClient> {

    private final DataObjectFactory<Program, ProgramClient> programFactory;
    private final DataObjectFactory<SportsTeam, SportsTeamClient> sportsTeamFactory;

    public ProgramTeamAssociationFactory(
            ProgramTeamAssociationClient ptaClient,
            DataObjectFactory<Program, ProgramClient> programFactory,
            DataObjectFactory<SportsTeam, SportsTeamClient> sportsTeamFactory, ValueProvider<Long> idProvider) {
        super(ptaClient, ProgramTeamAssociation.class, idProvider);
        this.programFactory = programFactory;
        this.sportsTeamFactory = sportsTeamFactory;
        this.addPresetFieldsOverrides(
                ProgramTeamAssociationField.programId, new DataObjectIdProvider(this.getProgramFactory()),
                ProgramTeamAssociationField.sportsTeamId, new DataObjectIdProvider(this.getSportsTeamFactory()),
                ProgramTeamAssociationField.competition, Boolean.FALSE,
                ProgramTeamAssociationField.homeAway, "Neutral",
                ProgramTeamAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable
        );
    }

    public DataObjectFactory<Program, ProgramClient> getProgramFactory() {
        return programFactory;
    }

    public DataObjectFactory<SportsTeam, SportsTeamClient> getSportsTeamFactory() {
        return sportsTeamFactory;
    }

}
