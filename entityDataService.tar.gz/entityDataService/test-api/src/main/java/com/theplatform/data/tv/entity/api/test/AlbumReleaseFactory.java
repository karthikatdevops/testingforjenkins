package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.AlbumClient;
import com.theplatform.data.tv.entity.api.data.objects.Album;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;

/**
 * @author jethrolai
 */
public class AlbumReleaseFactory extends EndpointFactory<AlbumRelease> {

    private AlbumClient albumClient;

    private AlbumFactory albumFactory;


    @Override
    public AlbumRelease create() {
        AlbumRelease albumRelease = super.create();


        Album album = albumFactory.create();
        albumClient.create(album);

        albumRelease.setAlbumId(album.getId());
        return albumRelease;
    }

    public AlbumClient getAlbumClient() {
        return albumClient;
    }

    public void setAlbumClient(AlbumClient albumClient) {
        this.albumClient = albumClient;
    }

    public AlbumFactory getAlbumFactory() {
        return albumFactory;
    }

    public void setAlbumFactory(AlbumFactory albumFactory) {
        this.albumFactory = albumFactory;
    }

}
