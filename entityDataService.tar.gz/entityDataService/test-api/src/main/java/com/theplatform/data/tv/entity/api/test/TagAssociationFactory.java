package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.api.client.DataServiceClient;
import com.theplatform.data.tv.entity.api.client.TagClient;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;

import java.net.URI;

@SuppressWarnings("rawtypes")
public class TagAssociationFactory extends EndpointFactory<TagAssociation> {


    private EndpointFactory entityFactory;

    private DataServiceClient entityClient;

    private TagFactory tagFactory;

    private TagClient tagClient;

    @SuppressWarnings("unchecked")
    @Override
    public TagAssociation create() {
        TagAssociation tagAssociation = super.create();
        tagAssociation.setEntityId(entityClient.create(entityFactory.create()).getId());
        tagAssociation.setTagId(tagClient.create(tagFactory.create()).getId());
        return tagAssociation;
    }

    public TagAssociation create(URI entityId) {
        TagAssociation tagAssociation = super.create();
        tagAssociation.setEntityId(entityId);
        tagAssociation.setTagId(tagClient.create(tagFactory.create()).getId());
        return tagAssociation;
    }

    public EndpointFactory getEntityFactory() {
        return entityFactory;
    }

    public void setEntityFactory(EndpointFactory entityFactory) {
        this.entityFactory = entityFactory;
    }

    public DataServiceClient getEntityClient() {
        return entityClient;
    }

    public void setEntityClient(DataServiceClient entityClient) {
        this.entityClient = entityClient;
    }

    public TagFactory getTagFactory() {
        return tagFactory;
    }

    public void setTagFactory(TagFactory tagFactory) {
        this.tagFactory = tagFactory;
    }

    public TagClient getTagClient() {
        return tagClient;
    }

    public void setTagClient(TagClient tagClient) {
        this.tagClient = tagClient;
    }

}