package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.image.api.client.MainImageTypeGroupClient;
import com.theplatform.data.tv.image.api.data.objects.MainImageTypeGroup;
import com.theplatform.data.tv.image.api.fields.MainImageTypeGroupField;

/**
 * Created by lemuri200 on 8/29/14.
 */
public class MainImageTypeGroupFactory extends DataObjectFactoryImpl<MainImageTypeGroup, MainImageTypeGroupClient> {

    public MainImageTypeGroupFactory(MainImageTypeGroupClient client, ValueProvider<Long> idProvider) {
        super(client, MainImageTypeGroup.class, idProvider);

        addPresetFieldsOverrides(
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                DataObjectField.title, "title",
                MainImageTypeGroupField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }
}
