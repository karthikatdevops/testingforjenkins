package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.data.objects.Program;


/**
 * @author jethrolai
 * @since 12/20/2011
 */
public class ProgramMovieFactory extends EndpointFactory<Program> {


}
