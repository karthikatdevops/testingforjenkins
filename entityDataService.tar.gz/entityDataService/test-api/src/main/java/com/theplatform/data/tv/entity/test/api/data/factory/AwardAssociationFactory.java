package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.AwardAssociationClient;
import com.theplatform.data.tv.entity.api.client.AwardClient;
import com.theplatform.data.tv.entity.api.client.InstitutionClient;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;
import com.theplatform.data.tv.entity.api.data.objects.AwardStatus;
import com.theplatform.data.tv.entity.api.data.objects.AwardType;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.fields.AwardAssociationField;

/**
 * Created by lemuri200 on 8/27/14.
 */
public class AwardAssociationFactory extends DataObjectFactoryImpl<AwardAssociation, AwardAssociationClient> {

    public AwardAssociationFactory(AwardAssociationClient client,
                                   DataObjectFactory<Award, AwardClient> awardFactory,
                                   DataObjectFactory<Institution, InstitutionClient> institutionFactory,
                                   DataObjectFactory<Person, PersonClient> personFactory,
                                   DataObjectFactory<Program, ProgramClient> programFactory,
                                   ValueProvider<Long> idProvider) {
        super(client, AwardAssociation.class, idProvider);

        addPresetFieldsOverrides(
                AwardAssociationField.year, 1900,
                AwardAssociationField.awardStatus, AwardStatus.FestivalScreening.getFriendlyName(),
                AwardAssociationField.awardType, AwardType.Person.getFriendlyName(),
                AwardAssociationField.awardId, new DataObjectIdProvider(awardFactory),
                AwardAssociationField.institutionId, new DataObjectIdProvider(institutionFactory),
                AwardAssociationField.programId, new DataObjectIdProvider(programFactory),
                AwardAssociationField.personId, new DataObjectIdProvider(personFactory),
                AwardAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, new PrefixedIdFieldProvider("author"),
                DataObjectField.description, new PrefixedIdFieldProvider("description"),
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }
}
