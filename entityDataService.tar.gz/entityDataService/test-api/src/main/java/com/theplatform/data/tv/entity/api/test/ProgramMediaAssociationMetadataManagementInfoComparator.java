package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.MetadataManagementInfoComparator;
import com.theplatform.data.tv.entity.api.client.query.programmediaassociation.CategoryPathUtils;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociationMetadataManagementInfo;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: kgaitt200
 * Date: 6/27/14
 * Time: 11:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProgramMediaAssociationMetadataManagementInfoComparator {

    private ProgramMediaAssociationMetadataManagementInfoComparator() {

    }

    public static void assertEquals(ProgramMediaAssociationMetadataManagementInfo actual, ProgramMediaAssociationMetadataManagementInfo expected) {
        List<String> normalizedAppend = normalizePaths(expected.getAppendCategoryPaths());
        List<String> normalizedRemove = normalizePaths(expected.getRemoveCategoryPaths());
        Assert.assertEquals(actual.getAppendCategoryPaths(), normalizedAppend);
        Assert.assertEquals(actual.getRemoveCategoryPaths(), normalizedRemove);
        MetadataManagementInfoComparator.assertEquals(actual, expected);
    }

    public static List<String> normalizePaths(List<String> paths) {
        if (paths == null) {
            return null;
        }
        List<String> normalizedPaths = new ArrayList<>();
        for (String path : paths) {
            normalizedPaths.add(CategoryPathUtils.normalizePathAndToLowerCase(path));
        }
        return normalizedPaths;
    }

    public static void assertEquals(List<ProgramMediaAssociationMetadataManagementInfo> actual, List<ProgramMediaAssociationMetadataManagementInfo> expected) {
        if (actual == null && expected == null)
            return;
        if ((actual != null && expected == null) || (actual == null && expected != null))
            Assert.fail("Only one of actual and expected inputs is null");
        Assert.assertEquals(actual.size(), expected.size(), "Actual and expected ProgramMediaAssociationMetadataManagementInfo list don't have the same size. ");
        for (int i = 0; i < actual.size(); i++)
            ProgramMediaAssociationMetadataManagementInfoComparator.assertEquals(actual.get(i), expected.get(i));

    }

}
