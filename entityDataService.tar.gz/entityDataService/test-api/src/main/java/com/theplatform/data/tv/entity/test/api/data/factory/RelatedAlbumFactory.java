package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.AlbumClient;
import com.theplatform.data.tv.entity.api.client.RelatedAlbumClient;
import com.theplatform.data.tv.entity.api.data.objects.Album;
import com.theplatform.data.tv.entity.api.data.objects.RelatedAlbum;
import com.theplatform.data.tv.entity.api.data.objects.RelatedAlbumType;
import com.theplatform.data.tv.entity.api.fields.RelatedAlbumField;

/**
 * Created by lemuri200 on 9/2/14.
 */
public class RelatedAlbumFactory extends DataObjectFactoryImpl<RelatedAlbum, RelatedAlbumClient> {

    public RelatedAlbumFactory(RelatedAlbumClient client, DataObjectFactory<Album, AlbumClient> albumFactory,
                               ValueProvider<Long> idProvider) {
        super(client, RelatedAlbum.class, idProvider);

        addPresetFieldsOverrides(
                RelatedAlbumField.sourceAlbumId, new DataObjectIdProvider(albumFactory),
                RelatedAlbumField.targetAlbumId, new DataObjectIdProvider(albumFactory),
                RelatedAlbumField.rank, 1,
                RelatedAlbumField.type, RelatedAlbumType.IsSimilar.getFriendlyName(),
                RelatedAlbumField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }
}
