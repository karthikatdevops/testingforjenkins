package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.SportsTeamClient;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeamType;
import com.theplatform.data.tv.entity.api.fields.SportsTeamField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

public class SportsTeamFactory extends DataObjectFactoryImpl<SportsTeam, SportsTeamClient> {

    public SportsTeamFactory(SportsTeamClient client, ValueProvider<Long> dataObjectIdProvider) {
        super(client, SportsTeam.class, dataObjectIdProvider);

        addPresetFieldsOverrides(
                SportsTeamField.imageIds, new ArrayList<URI>(),
                SportsTeamField.mainImages, new HashMap<String, MediaFile>(),
                SportsTeamField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                SportsTeamField.selectedImages, new ArrayList<MainImageInfo>(),
                SportsTeamField.type, SportsTeamType.Team.getFriendlyName(),
                SportsTeamField.tagIds, new ArrayList<URI>(),
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo(),
                SportsTeamField.shortBio, new PrefixedIdFieldProvider("shortBio"),
                SportsTeamField.mediumBio, new PrefixedIdFieldProvider("mediumBio"),
                SportsTeamField.longBio, new PrefixedIdFieldProvider("longBio")
        );

    }

    public void addDefaultValueProviders(Object... defaultMetadata) {
        this.addPresetFieldsOverrides(defaultMetadata);
    }
}
