package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.AlbumClient;
import com.theplatform.data.tv.entity.api.data.objects.Album;
import com.theplatform.data.tv.entity.api.fields.AlbumField;

import java.net.URI;
import java.util.ArrayList;

public class AlbumFactory extends DataObjectFactoryImpl<Album, AlbumClient> {

    public AlbumFactory(AlbumClient client, ValueProvider<Long> idProvider) {
        super(client, Album.class, idProvider);

        this.addPresetFieldsOverrides(
                AlbumField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                AlbumField.sortTitle, new PrefixedIdFieldProvider("title"),
                AlbumField.language, "eng",
                AlbumField.country, new PrefixedIdFieldProvider("country"),
                AlbumField.originalReleaseDate, new DateOnly(1900, 1, 1),
                AlbumField.primaryPersonIds, new ArrayList<URI>(),
                AlbumField.imageIds, new ArrayList<URI>(),
                AlbumField.tagIds, new ArrayList<URI>(),
                DataObjectField.author, new PrefixedIdFieldProvider("author"),
                DataObjectField.description, new PrefixedIdFieldProvider("description"),
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }

}
