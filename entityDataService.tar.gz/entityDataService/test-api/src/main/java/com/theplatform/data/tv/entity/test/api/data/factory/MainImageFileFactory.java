package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.MediaIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.image.api.client.MainImageFileClient;
import com.theplatform.data.tv.image.api.client.MainImageTypeClient;
import com.theplatform.data.tv.image.api.data.objects.ImageCredit;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;
import com.theplatform.data.tv.image.api.fields.MainImageFileField;

/**
 * Created by lemuri200 on 8/29/14.
 */
public class MainImageFileFactory extends DataObjectFactoryImpl<MainImageFile, MainImageFileClient> {

    public MainImageFileFactory(MainImageFileClient client, DataObjectFactory<Program, ProgramClient> programFactory, DataObjectFactory<MainImageType, MainImageTypeClient> mainImageTypeFactory, ValueProvider<Long> idProvider) {
        super(client, MainImageFile.class, idProvider);

        ImageCredit imageCredit = new ImageCredit();
        imageCredit.setDistributor("distributor");
        imageCredit.setPhotographer("photographer");

        addPresetFieldsOverrides(
                MainImageFileField.entityId, new DataObjectIdProvider(programFactory),
                MainImageFileField.url, "url",
                MainImageFileField.width, 100,
                MainImageFileField.height, 100,
                MainImageFileField.mainImageTypeId, new DataObjectIdProvider(mainImageTypeFactory),
                MainImageFileField.mainImageType, new MainImageType(),
                MainImageFileField.is3D, false,
                MainImageFileField.size, 100,
                MainImageFileField.format, "jpg",
                MainImageFileField.imageCredit, imageCredit,
                MainImageFileField.requiresAttribution, false,
                MainImageFileField.mediaId, new MediaIdProvider(idProvider),
                MainImageFileField.mediaFileGuid, "mediaFileGuid",
                MainImageFileField.isDefault, true,
                MainImageFileField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );

    }
}
