package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.PersonAssociation;

import java.net.URI;

public class PersonAssociationFactory {

    private PersonClient personClient;

    public PersonAssociation create(URI personId) {
        Person person = this.personClient.get(personId, new String[]{"name", "birth"});
        PersonAssociation personAssociation = new PersonAssociation();
        personAssociation.setBirth(person.getBirth());
        personAssociation.setName(person.getName());
        personAssociation.setPersonId(personId);
        return personAssociation;
    }

    public PersonClient getPersonClient() {
        return personClient;
    }

    public void setPersonClient(PersonClient personClient) {
        this.personClient = personClient;
    }

}
