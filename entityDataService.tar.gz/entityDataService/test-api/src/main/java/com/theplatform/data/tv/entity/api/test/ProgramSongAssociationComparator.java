package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociation;
import org.testng.Assert;

import java.util.List;

public class ProgramSongAssociationComparator {

    public static void assertEquals(ProgramSongAssociation actual, ProgramSongAssociation expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        Assert.assertEquals(actual.getSongId(), expected.getSongId());
        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getProgramType(), expected.getProgramType());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<ProgramSongAssociation> actual, List<ProgramSongAssociation> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));

    }
}
