package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.AlbumClient;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.data.objects.AlbumCredit;

import java.net.URI;

public class AlbumCreditFactory extends EndpointFactory<AlbumCredit> {

    private AlbumClient albumClient;

    private AlbumFactory albumFactory;

    private PersonClient personClient;

    private PersonFactory personFactory;

    @Override
    public AlbumCredit create() {
        AlbumCredit endpoint = super.create();
        endpoint.setPersonId(personClient.create(personFactory.create()).getId());
        endpoint.setAlbumId(albumClient.create(albumFactory.create()).getId());

        return endpoint;
    }

    public AlbumCredit create(URI albumId) {
        AlbumCredit endpoint = super.create();
        endpoint.setPersonId(personClient.create(personFactory.create()).getId());
        endpoint.setAlbumId(albumId);

        return endpoint;
    }

    public AlbumClient getAlbumClient() {
        return albumClient;
    }

    public void setAlbumClient(AlbumClient albumClient) {
        this.albumClient = albumClient;
    }

    public AlbumFactory getAlbumFactory() {
        return albumFactory;
    }

    public void setAlbumFactory(AlbumFactory albumFactory) {
        this.albumFactory = albumFactory;
    }

    public PersonClient getPersonClient() {
        return personClient;
    }

    public void setPersonClient(PersonClient personClient) {
        this.personClient = personClient;
    }

    public PersonFactory getPersonFactory() {
        return personFactory;
    }

    public void setPersonFactory(PersonFactory personFactory) {
        this.personFactory = personFactory;
    }

}
