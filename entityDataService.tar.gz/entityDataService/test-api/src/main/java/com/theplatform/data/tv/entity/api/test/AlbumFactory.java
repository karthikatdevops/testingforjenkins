package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.data.objects.Album;

/**
 * @author jethrolai
 */
public class AlbumFactory extends EndpointFactory<Album> {

}
