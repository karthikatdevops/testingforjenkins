package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.AwardClient;
import com.theplatform.data.tv.entity.api.client.InstitutionClient;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.data.objects.AwardAssociation;

/**
 * @author jethrolai
 */
public class AwardAssociationFactory extends EndpointFactory<AwardAssociation> {

    private AwardFactory awardFactory;

    private AwardClient awardClient;

    private InstitutionClient institutionClient;

    private InstitutionFactory institutionFactory;

    private PersonClient personClient;

    private PersonFactory personFactory;

    @Override
    public AwardAssociation create() {
        AwardAssociation awardAssociation = super.create();
        awardAssociation.setAwardId(awardClient.create(awardFactory.create()).getId());
        awardAssociation.setInstitutionId(institutionClient.create(institutionFactory.create()).getId());
        awardAssociation.setAwardType("Person");
        awardAssociation.setPersonId(this.personClient.create(personFactory.create()).getId());
        return awardAssociation;
    }

    public AwardFactory getAwardFactory() {
        return awardFactory;
    }

    public void setAwardFactory(AwardFactory awardFactory) {
        this.awardFactory = awardFactory;
    }

    public AwardClient getAwardClient() {
        return awardClient;
    }

    public void setAwardClient(AwardClient awardClient) {
        this.awardClient = awardClient;
    }

    public InstitutionClient getInstitutionClient() {
        return institutionClient;
    }

    public void setInstitutionClient(InstitutionClient institutionClient) {
        this.institutionClient = institutionClient;
    }

    public InstitutionFactory getInstitutionFactory() {
        return institutionFactory;
    }

    public void setInstitutionFactory(InstitutionFactory institutionFactory) {
        this.institutionFactory = institutionFactory;
    }

    public PersonClient getPersonClient() {
        return personClient;
    }

    public void setPersonClient(PersonClient personClient) {
        this.personClient = personClient;
    }

    public PersonFactory getPersonFactory() {
        return personFactory;
    }

    public void setPersonFactory(PersonFactory personFactory) {
        this.personFactory = personFactory;
    }

}
