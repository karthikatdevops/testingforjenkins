package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.FieldValueProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;
import com.theplatform.media.api.data.objects.Rating;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

public class SeriesMasterProgramFactory extends DataObjectFactoryImpl<Program, ProgramClient> {

    public SeriesMasterProgramFactory(ProgramClient client, ValueProvider<Long> idProvider) {
        this(client, idProvider, null);
    }

    public SeriesMasterProgramFactory(ProgramClient client, ValueProvider<Long> idProvider, FieldValueProvider<Program, String> guidValueProvider) {
        super(client, Program.class, idProvider);

        Rating rating = new Rating();
        rating.setScheme("urn:v-chip");
        rating.setRating("TV14");
        rating.setSubRatings(new String[]{"L"});

        DateOnly dateOnly = new DateOnly(1970, 1, 1);
        this.addPresetFieldsOverrides(
                ProgramField.type, ProgramType.SeriesMaster,
                ProgramField.category, ProgramCategory.Other.getFriendlyName(),
                ProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                ProgramField.lastAirDate, dateOnly,
                ProgramField.firstAirDate, dateOnly,
                ProgramField.local, false,
                DataObjectField.title, "title",
                ProgramField.listByTitle, true,
                ProgramField.tagIds, new ArrayList<URI>(),
                ProgramField.imageIds, new ArrayList<URI>(),
                ProgramField.selectedImages, new ArrayList<MainImageInfo>(),
                ProgramField.mainImages, new HashMap<String, MediaFile>(),
                ProgramField.credits, new ArrayList<CreditAssociation>()

        );

        if (guidValueProvider != null) {
            this.addPresetFieldsOverrides(DataObjectField.guid, guidValueProvider);
        }
    }

}
