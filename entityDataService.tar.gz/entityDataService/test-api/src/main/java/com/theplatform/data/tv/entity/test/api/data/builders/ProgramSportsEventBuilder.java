package com.theplatform.data.tv.entity.test.api.data.builders;

import com.theplatform.contrib.testing.builder.MerlinDataObjectBuilder;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;

import java.net.URI;

public class ProgramSportsEventBuilder extends MerlinDataObjectBuilder<ProgramSportsEvent, ProgramSportsEventBuilder> {

    public ProgramSportsEventBuilder() {
        this(new ProgramSportsEvent());
    }

    public ProgramSportsEventBuilder(ProgramSportsEvent template) {
        super(template);
    }

    @Override
    protected ProgramSportsEventBuilder newBuilder(ProgramSportsEvent newTemplate) {
        return new ProgramSportsEventBuilder(newTemplate);
    }

    public ProgramSportsEventBuilder programId(URI programId) {
        ProgramSportsEvent newTemplate = super.cloneTemplate();
        newTemplate.setProgramId(programId);
        return newBuilder(newTemplate);
    }

    public ProgramSportsEventBuilder sportsTeamId(URI sportsEventId) {
        ProgramSportsEvent newTemplate = super.cloneTemplate();
        newTemplate.setSportsEventId(sportsEventId);
        return newBuilder(newTemplate);
    }

}
