package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.FieldValueProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;
import com.theplatform.media.api.data.objects.Rating;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

public class MovieProgramFactory extends DataObjectFactoryImpl<Program, ProgramClient> {

    public MovieProgramFactory(ProgramClient client) {
        super(client);
        this.addPresetFieldsOverrides(
                ProgramField.type, ProgramType.Movie,
                ProgramField.category, ProgramCategory.Movie.getFriendlyName());
    }

    public MovieProgramFactory(ProgramClient client, ValueProvider<Long> idLongValueProvider) {
        this(client, idLongValueProvider, null);

    }

    public MovieProgramFactory(ProgramClient client, ValueProvider<Long> idLongValueProvider, FieldValueProvider<Program, String> guidValueProvider) {
        super(client, idLongValueProvider);

        DateOnly dateOnly = new DateOnly(1970, 1, 1);

        Rating rating = new Rating();
        rating.setScheme("urn:v-chip");
        rating.setRating("TV14");
        rating.setSubRatings(new String[]{"L"});

        this.addPresetFieldsOverrides(
                ProgramField.type, ProgramType.Movie,
                ProgramField.category, ProgramCategory.Movie.getFriendlyName(),
                ProgramField.local, false,
                DataObjectField.title, "title",
                ProgramField.listByTitle, true,
                ProgramField.tagIds, new ArrayList<URI>(),
                ProgramField.imageIds, new ArrayList<URI>(),
                ProgramField.selectedImages, new ArrayList<MainImageInfo>(),
                ProgramField.mainImages, new HashMap<String, MediaFile>(),
                ProgramField.credits, new ArrayList<CreditAssociation>(),
                ProgramField.releaseDate, dateOnly
        );

        if (guidValueProvider != null) {
            this.addPresetFieldsOverrides(DataObjectField.guid, guidValueProvider);
        }
    }

}
