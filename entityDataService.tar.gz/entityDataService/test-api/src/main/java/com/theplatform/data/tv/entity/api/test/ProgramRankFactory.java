package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import org.apache.commons.lang.SerializationUtils;

public class ProgramRankFactory extends EndpointFactory<ProgramRank> {

    private ProgramClient programClient;

    private ProgramEndpointFactory programFactory;

    @Override
    public ProgramRank create() {

        // no need to set id
        ProgramRank programRank = (ProgramRank) SerializationUtils.clone(templateEndpoint);
        Program program = programClient.create(programFactory.create(), new String[]{});
        programRank.setProgramId(program.getId());
        programRank.setProgram(program);

        return programRank;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }

    public ProgramEndpointFactory getProgramFactory() {
        return programFactory;
    }

    public void setProgramFactory(ProgramEndpointFactory programFactory) {
        this.programFactory = programFactory;
    }

}
