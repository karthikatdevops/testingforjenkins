package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.client.SongCreditClient;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;
import com.theplatform.data.tv.entity.api.fields.SongCreditField;

public class SongCreditFactory extends DataObjectFactoryImpl<SongCredit, SongCreditClient> {

    private DataObjectFactory<Person, PersonClient> personFactory;
    private DataObjectFactory<Song, SongClient> songFactory;

    public SongCreditFactory(SongCreditClient client, DataObjectFactory<Person, PersonClient> personFactory, DataObjectFactory<Song, SongClient> songFactory,
                             ValueProvider<Long> idProvider) {
        super(client, idProvider);

        this.personFactory = personFactory;
        this.songFactory = songFactory;

        this.addPresetFieldsOverrides(
                SongCreditField.personId, new DataObjectIdProvider(personFactory),
                SongCreditField.songId, new DataObjectIdProvider(songFactory),
                SongCreditField.type, "FeaturedArtist",
                SongCreditField.rank, 1,
                SongCreditField.active, true,
                SongCreditField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description"
        );

    }

    public SongCreditFactory(SongCreditClient client,
                             ValueProvider<Long> idProvider) {
        super(client, idProvider);
    }

    public DataObjectFactory<Person, PersonClient> getPersonFactory() {
        return personFactory;
    }

    public DataObjectFactory<Song, SongClient> getSongFactory() {
        return songFactory;
    }


}
