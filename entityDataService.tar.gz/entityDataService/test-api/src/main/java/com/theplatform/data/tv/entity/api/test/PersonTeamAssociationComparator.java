package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.DataObjectComparator;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.PersonTeamAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import org.testng.Assert;

import java.util.List;

/**
 * @author clai200
 * @since 4/7/2011
 */
public class PersonTeamAssociationComparator extends DataObjectComparator<PersonTeamAssociation> {


    public void assertEquals(PersonTeamAssociation expected,
                             PersonTeamAssociation actual) {

        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getPersonId(), expected.getPersonId());
        Assert.assertEquals(actual.getSportsTeamId(), expected.getSportsTeamId());
        Assert.assertEquals(actual.getNativeId(), expected.getNativeId());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());

    }

    public void assertEquals(Feed<PersonTeamAssociation> actualPersonTeamAssociationFeed,
                             List<PersonTeamAssociation> expectedPersonTeamAssociations) {

        List<PersonTeamAssociation> actualPersonTeamAssociations = actualPersonTeamAssociationFeed.getEntries();
        Assert.assertEquals(actualPersonTeamAssociations.size(), expectedPersonTeamAssociations.size(), "Unexpected number of PersonTeamAssociations");

        for (int i = 0; i < expectedPersonTeamAssociations.size(); i++) {
            assertEquals(actualPersonTeamAssociations.get(i), expectedPersonTeamAssociations.get(i));
        }
    }

}
