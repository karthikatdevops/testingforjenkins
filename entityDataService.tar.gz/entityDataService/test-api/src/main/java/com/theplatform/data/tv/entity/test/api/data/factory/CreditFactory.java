package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.CreditClient;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Credit;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.PersonAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramAssociation;
import com.theplatform.data.tv.entity.api.fields.CreditField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

public class CreditFactory extends DataObjectFactoryImpl<Credit, CreditClient> {

    private DataObjectFactory<Person, PersonClient> personFactory;

    private DataObjectFactory<Program, ProgramClient> programFactory;

    public CreditFactory(CreditClient creditClient, DataObjectFactory<Person, PersonClient> personFactory, DataObjectFactory<Program, ProgramClient> programFactory,
                         ValueProvider<Long> idProvider) {
        super(creditClient, Credit.class, idProvider);

        this.personFactory = personFactory;
        this.programFactory = programFactory;

        DataObjectIdProvider personIdProvider = new DataObjectIdProvider(personFactory);
        DataObjectIdProvider programIdProvider = new DataObjectIdProvider(programFactory);

        this.addPresetFieldsOverrides(
                CreditField.personId, personIdProvider,
                CreditField.programId, programIdProvider,
                CreditField.rank, 1,
                CreditField.program, new ProgramAssociation(),
                CreditField.person, new PersonAssociation(),
                CreditField.cameo, false,
                CreditField.imageIds, new ArrayList<URI>(),
                CreditField.mainImages, new HashMap<String, MediaFile>(),
                CreditField.active, true,
                CreditField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                CreditField.selectedImages, new ArrayList<MainImageInfo>(),
                CreditField.entityId, programIdProvider,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()

        );
    }

    public CreditFactory(CreditClient creditClient, ValueProvider<Long> idProvider) {
        super(creditClient, Credit.class, idProvider);
    }

    public DataObjectFactory<Person, PersonClient> getPersonFactory() {
        return personFactory;
    }

    public DataObjectFactory<Program, ProgramClient> getProgramFactory() {
        return programFactory;
    }

}
