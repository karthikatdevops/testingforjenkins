package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.ConsecutiveLongProvider;
import com.theplatform.contrib.testing.factory.field.SuffixedStringValueProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.client.EntityCollectionClient;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollectionType;
import com.theplatform.data.tv.entity.api.fields.EntityCollectionField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

public class EntityCollectionFactory extends DataObjectFactoryImpl<EntityCollection, EntityCollectionClient> {

    public EntityCollectionFactory(EntityCollectionClient client, ValueProvider<Long> idProvider) {
        super(client, EntityCollection.class, idProvider);
        addPresetFieldsOverrides(
                DataObjectField.title, new SuffixedStringValueProvider("Entity Collection Title - ", new ConsecutiveLongProvider()),
                EntityCollectionField.type, EntityCollectionType.Variant.getFriendlyName(),
                EntityCollectionField.subtype, "Language",
                EntityCollectionField.entityIds, new ArrayList<URI>(),
                EntityCollectionField.imageIds, new ArrayList<URI>(),
                EntityCollectionField.mainImages, new HashMap<String, MediaFile>(),
                EntityCollectionField.primaryEntities, new HashMap<String, URI>(),
                EntityCollectionField.selectedImages, new ArrayList<MainImageInfo>(),
                DataObjectField.description, "description"
        );
    }
}