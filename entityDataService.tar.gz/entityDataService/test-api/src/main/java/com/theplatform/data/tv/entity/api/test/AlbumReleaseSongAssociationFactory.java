package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.AlbumReleaseClient;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Song;

import java.net.URI;

public class AlbumReleaseSongAssociationFactory extends EndpointFactory<AlbumReleaseSongAssociation> {

    private AlbumReleaseClient albumReleaseClient;
    private SongClient songClient;
    private AlbumReleaseFactory albumReleaseFactory;
    private SongFactory songFactory;

    public AlbumReleaseSongAssociation create() {

        AlbumRelease albumRelease = albumReleaseClient.create(albumReleaseFactory.create());
        Song song = songClient.create(songFactory.create());

        AlbumReleaseSongAssociation albumReleaseSongAssociation = super.create();
        albumReleaseSongAssociation.setAlbumReleaseId(albumRelease.getId());
        albumReleaseSongAssociation.setSongId(song.getId());

        return albumReleaseSongAssociation;
    }

    public AlbumReleaseSongAssociation create(URI albumReleaseId) {

        AlbumReleaseSongAssociation albumReleaseSongAssociation = super.create();
        albumReleaseSongAssociation.setAlbumReleaseId(albumReleaseId);

        Song song = songClient.create(songFactory.create());
        albumReleaseSongAssociation.setSongId(song.getId());

        return albumReleaseSongAssociation;
    }

    public AlbumReleaseSongAssociation create(URI albumReleaseId, URI songId) {

        AlbumReleaseSongAssociation albumReleaseSongAssociation = super.create();
        albumReleaseSongAssociation.setAlbumReleaseId(albumReleaseId);
        albumReleaseSongAssociation.setSongId(songId);

        return albumReleaseSongAssociation;
    }

    public AlbumReleaseClient getAlbumReleaseClient() {
        return albumReleaseClient;
    }

    public void setAlbumReleaseClient(AlbumReleaseClient albumReleaseClient) {
        this.albumReleaseClient = albumReleaseClient;
    }

    public SongClient getSongClient() {
        return songClient;
    }

    public void setSongClient(SongClient songClient) {
        this.songClient = songClient;
    }

    public AlbumReleaseFactory getAlbumReleaseFactory() {
        return albumReleaseFactory;
    }

    public void setAlbumReleaseFactory(AlbumReleaseFactory albumReleaseFactory) {
        this.albumReleaseFactory = albumReleaseFactory;
    }

    public SongFactory getSongFactory() {
        return songFactory;
    }

    public void setSongFactory(SongFactory songFactory) {
        this.songFactory = songFactory;
    }


}
