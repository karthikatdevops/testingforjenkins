package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.contrib.testing.provider.IdProviderImpl;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.RelatedProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgramMetadataManagementInfo;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgramType;
import com.theplatform.data.tv.entity.api.fields.RelatedProgramField;


public class RelatedProgramFactory extends DataObjectFactoryImpl<RelatedProgram, RelatedProgramClient> {

    public RelatedProgramFactory(RelatedProgramClient client, ValueProvider<Long> idProvider, DataObjectFactory<Program, ProgramClient> programFactory) {
        super(client, RelatedProgram.class, idProvider);
        this.addPresetFieldsOverrides(
                RelatedProgramField.sourceProgramId, new DataObjectIdProvider(programFactory),
                RelatedProgramField.targetProgramId, new DataObjectIdProvider(programFactory),
                RelatedProgramField.type, RelatedProgramType.IsRelated.getFriendlyName(),
                RelatedProgramField.justification, "justification",
                RelatedProgramField.sourceProgram, new Program(),
                RelatedProgramField.targetProgram, new Program(),
                RelatedProgramField.rank, 1,
                RelatedProgramField.score, new Float(1),
                RelatedProgramField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new RelatedProgramMetadataManagementInfo()

        );

    }

    public RelatedProgramFactory(RelatedProgramClient client, ProgramFactory programFactory) {
        this(client, new IdProviderImpl(), programFactory);
    }
}
