package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.FieldValueProvider;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.TagClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.tag.api.client.TagAssociationClient;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociationMetadataManagementInfo;
import com.theplatform.data.tv.tag.api.fields.TagAssociationField;

/**
 * User: jdoto200
 * Date: 6/8/12
 * Time: 8:59 AM
 */
public class TagAssociationFactory extends DataObjectFactoryImpl<TagAssociation, TagAssociationClient> {


    public TagAssociationFactory(TagAssociationClient client, DataObjectFactory<Program, ProgramClient> programFactory,
                                 DataObjectFactory<Tag, TagClient> tagFactory, ValueProvider<Long> dataObjectIdProvider) {
        super(client, TagAssociation.class, dataObjectIdProvider);
        this.addPresetFieldsOverrides(
                DataObjectField.title, new PrefixedIdFieldProvider("TagAssociationName"),
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                TagAssociationField.entityId, new DataObjectIdProvider(programFactory),
                TagAssociationField.tagId, new DataObjectIdProvider(tagFactory),
                TagAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                TagAssociationField.primary, false,
                TagAssociationField.rank, 1,
                ManagedMerlinDataObjectField.metadataManagementInfo, new TagAssociationMetadataManagementInfo()
        );

    }

    public TagAssociationFactory(TagAssociationClient client, ValueProvider<Long> dataObjectIdProvider, FieldValueProvider<TagAssociation, String> guidValueProvider) {
        super(client, dataObjectIdProvider);

        if (guidValueProvider != null) {
            this.addPresetFieldsOverrides(DataObjectField.guid, guidValueProvider);
        }

    }

    public TagAssociationFactory(TagAssociationClient client, ValueProvider<Long> dataObjectIdProvider) {
        super(client, dataObjectIdProvider);
        this.addPresetFieldsOverrides(
                DataObjectField.title, new PrefixedIdFieldProvider("TagAssociationName"));
    }

}