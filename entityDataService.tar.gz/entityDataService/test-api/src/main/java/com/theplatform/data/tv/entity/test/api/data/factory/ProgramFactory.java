package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.FieldValueProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.data.objects.TvSeason;
import com.theplatform.data.tv.entity.api.fields.ProgramField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

import static com.theplatform.contrib.util.SortTitleHelper.convertToSortTitle;

/**
 * Factory that creates default programs for tests
 * <p>
 * <p>NOTE: If you decide to update the title field in the test, the sort title will also need to be updated using
 * the SortTitleHelper. Why ? - Combine has logic that generates 'sortTitle' (from the 'title' field) if it hasn't
 * been editorially overridden. This factory pre-computes the 'sortTitle' from the 'title' field to help while asserting
 * DataObject equality. </p>
 */
public class ProgramFactory extends DataObjectFactoryImpl<Program, ProgramClient> {

    public static final String DEFAULT_TITLE = "title";

    private final EpisodeProgramFactory episodeProgramFactory;
    private final MovieProgramFactory movieProgramFactory;
    private final SeriesMasterProgramFactory seriesMasterProgramFactory;

    public ProgramFactory(ProgramClient client, ValueProvider<Long> idProvider) {
        this(client, idProvider, null);
    }

    public ProgramFactory(ProgramClient client, ValueProvider<Long> idProvider, FieldValueProvider<Program, String> guidGenerator) {
        super(client, Program.class, idProvider);

        if (guidGenerator != null) {
            this.addPresetFieldsOverrides(DataObjectField.guid, guidGenerator);
        }

        this.movieProgramFactory = new MovieProgramFactory(client, idProvider, guidGenerator);
        this.seriesMasterProgramFactory = new SeriesMasterProgramFactory(client, idProvider, guidGenerator);
        this.episodeProgramFactory = new EpisodeProgramFactory(client, seriesMasterProgramFactory, idProvider, guidGenerator);

        addPresetFieldsOverrides(
                ProgramField.type, ProgramType.Other,
                ProgramField.category, ProgramCategory.Other.getFriendlyName(),
                ProgramField.tagIds, new ArrayList<URI>(),
                ProgramField.imageIds, new ArrayList<URI>(),
                ProgramField.selectedImages, new ArrayList<MainImageInfo>(),
                ProgramField.mainImages, new HashMap<String, MediaFile>(),
                DataObjectField.title, DEFAULT_TITLE,
                ProgramField.sortTitle, convertToSortTitle(DEFAULT_TITLE)
        );
    }

    public Program createEpisode(Program seriesMaster, TvSeason season) {
        return this.episodeProgramFactory.create(ProgramField.seriesId, seriesMaster.getId(), ProgramField.tvSeasonId, season.getId());
    }

    public Program createSeries() {
        return this.seriesMasterProgramFactory.create();
    }

    public Program createMovie() {
        return this.movieProgramFactory.create();
    }

}
