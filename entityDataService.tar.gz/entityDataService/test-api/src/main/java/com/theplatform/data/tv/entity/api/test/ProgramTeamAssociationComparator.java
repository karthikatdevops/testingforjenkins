package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;
import org.testng.Assert;

import java.util.List;

/**
 * @author clai200
 * @since 4/7/2011
 */
public class ProgramTeamAssociationComparator {

    private ProgramTeamAssociationComparator() {

    }

    public static void assertEquals(ProgramTeamAssociation expected,
                                    ProgramTeamAssociation actual) {
        Assert.assertEquals(actual.getId(), expected.getId());

        // sports Event fields
        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        Assert.assertEquals(actual.getSportsTeamId(), expected.getSportsTeamId());
        Assert.assertEquals(actual.getHomeAway(), expected.getHomeAway());
        Assert.assertEquals(actual.getCompetition(), expected.getCompetition());


        //might not need this assertion because it's not editorial
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<ProgramTeamAssociation> actualProgramTeamAssociationFeed,
                                    List<ProgramTeamAssociation> expectedProgramTeamAssociations) {
        List<ProgramTeamAssociation> actualProgramTeamAssociations = actualProgramTeamAssociationFeed.getEntries();
        Assert.assertEquals(actualProgramTeamAssociations.size(), expectedProgramTeamAssociations.size(), "Unexpected number of ProgramTeamAssociations");
        for (int i = 0; i < expectedProgramTeamAssociations.size(); i++)
            assertEquals(actualProgramTeamAssociations.get(i), expectedProgramTeamAssociations.get(i));

    }

}
