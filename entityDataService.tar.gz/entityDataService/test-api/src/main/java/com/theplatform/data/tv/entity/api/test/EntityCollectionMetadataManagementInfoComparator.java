package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.MetadataManagementInfoComparator;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollectionMetadataManagementInfo;
import org.testng.Assert;

import java.util.List;

public class EntityCollectionMetadataManagementInfoComparator {

    private EntityCollectionMetadataManagementInfoComparator() {

    }

    public static void assertEquals(EntityCollectionMetadataManagementInfo actual, EntityCollectionMetadataManagementInfo expected) {
        Assert.assertEquals(actual.getAppendEntityIds(), expected.getAppendEntityIds());
        Assert.assertEquals(actual.getRemoveEntityIds(), expected.getRemoveEntityIds());
        Assert.assertEquals(actual.getAppendPrimaryEntities(), expected.getAppendPrimaryEntities());
        Assert.assertEquals(actual.getRemovePrimaryEntities(), expected.getRemovePrimaryEntities());
        MetadataManagementInfoComparator.assertEquals(actual, expected);
    }

    public static void assertEquals(List<EntityCollectionMetadataManagementInfo> actual, List<EntityCollectionMetadataManagementInfo> expected) {
        if (actual == null && expected == null)
            return;
        if ((actual != null && expected == null) || (actual == null && expected != null))
            Assert.fail("Only one of actual and expected inputs is null");
        Assert.assertEquals(actual.size(), expected.size(), "Actual and expected EntityCollectionMetadataManagementInfo list don't have the same size. ");
        for (int i = 0; i < actual.size(); i++)
            EntityCollectionMetadataManagementInfoComparator.assertEquals(actual.get(i), expected.get(i));

    }

}
