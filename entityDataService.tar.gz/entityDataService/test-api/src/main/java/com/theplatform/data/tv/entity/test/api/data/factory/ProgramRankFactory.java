package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.ProgramRankClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRankType;
import com.theplatform.data.tv.entity.api.fields.ProgramRankField;

public class ProgramRankFactory extends DataObjectFactoryImpl<ProgramRank, ProgramRankClient> {

    private DataObjectFactory<Program, ProgramClient> programFactory;

    public ProgramRankFactory(ProgramRankClient client, DataObjectFactory<Program, ProgramClient> programFactory, ValueProvider<Long> idProvider) {
        super(client, ProgramRank.class, idProvider);
        this.programFactory = programFactory;
        this.addPresetFieldsOverrides(
                ProgramRankField.programId, new DataObjectIdProvider(this.programFactory),
                ProgramRankField.rank, new Float(1.0),
                ProgramRankField.program, new Program(),
                ProgramRankField.type, ProgramRankType.Algorithmic.getFriendlyName(),
                ProgramRankField.validAsOf, new DateOnly(1970, 1, 1),
                ProgramRankField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }

    public ProgramRankFactory(ProgramRankClient client, ValueProvider<Long> idProvider) {
        super(client, idProvider);
    }

}
