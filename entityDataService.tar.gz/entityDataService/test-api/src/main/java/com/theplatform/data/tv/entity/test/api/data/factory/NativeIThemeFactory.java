package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.FieldValueProvider;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.TranslationIngestObjectGuidValueProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.client.TagClient;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.data.objects.TagType;
import com.theplatform.data.tv.entity.api.fields.TagField;
import com.theplatform.data.tv.ingest.type.MerlinEntityType;

public class NativeIThemeFactory extends DataObjectFactoryImpl<Tag, TagClient> {

    public NativeIThemeFactory(TagClient client, ValueProvider<Long> idProvider) {
        super(client, Tag.class, idProvider);

        FieldValueProvider<Tag, String> customGuidProvider = new FieldValueProvider<Tag, String>() {
            @Override
            public String getFieldValue(Tag dataObject) {
                TranslationIngestObjectGuidValueProvider genericProvider = new TranslationIngestObjectGuidValueProvider();
                String preguid = genericProvider.getFieldValue(dataObject);
                if (preguid != null) {
                    preguid = preguid.replace(MerlinEntityType.TAG.getTypeString(), MerlinEntityType.NATIVEITHEME.getTypeString());
                }
                return preguid;
            }
        };

        addPresetFieldsOverrides(
                DataObjectField.title, new PrefixedIdFieldProvider(TagType.NativeITheme.getFriendlyName()),
                TagField.type, TagType.NativeITheme.getFriendlyName(),
                DataObjectField.guid, customGuidProvider);
    }
}
