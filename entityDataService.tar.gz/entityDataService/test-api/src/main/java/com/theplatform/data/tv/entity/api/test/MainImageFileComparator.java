package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;

import java.util.List;

import static org.testng.Assert.assertEquals;

/**
 * Asserts equality on MainImageFile
 *
 * @since 4/7/2011 .
 * @deprecated use comparator in imageCommon instead
 */
public class MainImageFileComparator {

    private MainImageFileComparator() {

    }

    public static void assertMainImageFileEqual(MainImageFile actual, MainImageFile expected) {
        assertEquals(actual.getId(), expected.getId());
        assertEquals(actual.getEntityId(), expected.getEntityId());
        assertEquals(actual.getMainImageTypeId(), expected.getMainImageTypeId());
        assertEquals(actual.getUrl(), expected.getUrl());
        assertEquals(actual.getWidth(), expected.getWidth());
        assertEquals(actual.getHeight(), expected.getHeight());
    }

    public static void assertMainImageFilesEqual(Feed<MainImageFile> actualMainImageFileFeed,
                                                 List<MainImageFile> expectedMainImageFiles) {
        List<MainImageFile> actualMainImageFiles = actualMainImageFileFeed.getEntries();
        assertEquals(actualMainImageFiles.size(), expectedMainImageFiles.size(), "Unexpected number of MainImageFiles");
        for (int i = 0; i < expectedMainImageFiles.size(); i++) {
            assertMainImageFileEqual(actualMainImageFiles.get(i), expectedMainImageFiles.get(i));
        }
    }
}