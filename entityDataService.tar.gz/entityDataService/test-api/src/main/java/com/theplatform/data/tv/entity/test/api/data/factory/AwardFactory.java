package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.AwardClient;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import com.theplatform.data.tv.entity.api.fields.AwardField;

/**
 * Created by lemuri200 on 8/27/14.
 */
public class AwardFactory extends DataObjectFactoryImpl<Award, AwardClient> {

    public AwardFactory(AwardClient client, ValueProvider<Long> idProvider) {
        super(client, Award.class, idProvider);

        addPresetFieldsOverrides(
                AwardField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                AwardField.rank, 1,
                DataObjectField.title, "title",
                DataObjectField.author, new PrefixedIdFieldProvider("author"),
                DataObjectField.description, new PrefixedIdFieldProvider("description"),
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }
}
