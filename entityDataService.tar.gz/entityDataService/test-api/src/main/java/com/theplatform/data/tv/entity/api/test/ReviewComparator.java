package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.RatingComparator;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Review;
import org.testng.Assert;

import java.util.List;

/**
 * @author jethrolai
 * @since 10/30/2011
 */
public class ReviewComparator {
    private ReviewComparator() {

    }

    public static void assertEquals(Review actual, Review expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        Assert.assertEquals(actual.getProvider(), expected.getProvider());
        Assert.assertEquals(actual.getSummary(), expected.getSummary());
        Assert.assertEquals(actual.getDescription(), expected.getDescription());
        Assert.assertEquals(actual.getReview(), expected.getReview());
        Assert.assertEquals(actual.getRecommendation(), expected.getRecommendation());
        Assert.assertEquals(actual.getStarRating(), expected.getStarRating());
        RatingComparator.assertEquals(actual.getContentRatings(), expected.getContentRatings());
    }

    public static void assertEquals(Feed<Review> actualFeed, List<Review> expectedList) {
        List<Review> actualList = actualFeed.getEntries();

        Assert.assertEquals(actualList.size(), expectedList.size(), "The sizes of the actual feed and expected list of Reviews are not equal.");
        for (int i = 0; i < expectedList.size(); i++)
            assertEquals(actualList.get(i), expectedList.get(i));

    }
}
