package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.DataObjectComparator;
import com.theplatform.data.tv.entity.api.data.objects.RatingsMapping;
import org.testng.Assert;

/**
 * Created by lemuri200 on 6/2/15.
 */
public class RatingsMappingComparator extends DataObjectComparator<RatingsMapping> {
    @Override
    public void assertEquals(RatingsMapping actual, RatingsMapping expected) {
        super.assertEquals(actual, expected);

        if (actual != null && expected != null) {
            Assert.assertEquals(actual.getTitle(), expected.getTitle());
            Assert.assertEquals(actual.getSourceRatingSystem(), expected.getSourceRatingSystem());
            Assert.assertEquals(actual.getTargetRatingSystem(), expected.getTargetRatingSystem());
            areMapsMerlinEqual(actual.getRatingsMap(), expected.getRatingsMap());
        }
    }
}
