package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.AlbumReleaseClient;
import com.theplatform.data.tv.entity.api.client.AlbumReleaseSongAssociationClient;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseSongAssociationField;

public class AlbumReleaseSongAssociationFactory extends DataObjectFactoryImpl<AlbumReleaseSongAssociation, AlbumReleaseSongAssociationClient> {

    private DataObjectFactory<AlbumRelease, AlbumReleaseClient> albumReleaseFactory;
    private DataObjectFactory<Song, SongClient> songFactory;

    public AlbumReleaseSongAssociationFactory(
            AlbumReleaseSongAssociationClient client,
            ValueProvider<Long> idProvider,
            DataObjectFactory<AlbumRelease, AlbumReleaseClient> albumReleaseFactory,
            DataObjectFactory<Song, SongClient> songFactory
    ) {
        super(client, AlbumReleaseSongAssociation.class, idProvider);

        if (albumReleaseFactory == null) {
            throw new IllegalArgumentException("The argument 'albumReleaseFactory' cannot be null");
        }
        if (songFactory == null) {
            throw new IllegalArgumentException("The argument 'songFactory' cannot be null");
        }

        this.albumReleaseFactory = albumReleaseFactory;
        this.songFactory = songFactory;

        this.addPresetFieldsOverrides(
                AlbumReleaseSongAssociationField.albumReleaseId, new DataObjectIdProvider(this.albumReleaseFactory),
                AlbumReleaseSongAssociationField.songId, new DataObjectIdProvider(this.songFactory),
                AlbumReleaseSongAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, new PrefixedIdFieldProvider("author"),
                DataObjectField.description, new PrefixedIdFieldProvider("description"),
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }

    public AlbumReleaseSongAssociationFactory(
            AlbumReleaseSongAssociationClient client,
            ValueProvider<Long> idProvider) {
        super(client, idProvider);
    }

    public DataObjectFactory<AlbumRelease, AlbumReleaseClient> getAlbumReleaseFactory() {
        return albumReleaseFactory;
    }

    public DataObjectFactory<Song, SongClient> getSongFactory() {
        return songFactory;
    }

}
