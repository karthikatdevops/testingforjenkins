package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.data.objects.Program;

/**
 * @author jethrolai
 */
public class ProgramEpisodeFactory extends EndpointFactory<Program> {

}
