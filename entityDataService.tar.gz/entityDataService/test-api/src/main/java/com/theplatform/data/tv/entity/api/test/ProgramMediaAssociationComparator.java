package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import org.testng.Assert;

import java.util.List;

public class ProgramMediaAssociationComparator {

    public static void assertEquals(ProgramMediaAssociation actual, ProgramMediaAssociation expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        Assert.assertEquals(actual.getMediaGuid(), expected.getMediaGuid());
        Assert.assertEquals(actual.getMediaId(), expected.getMediaId());
        Assert.assertEquals(actual.getMezzanineMediaId(), expected.getMezzanineMediaId());
        Assert.assertEquals(actual.getDistributionId(), expected.getDistributionId());
        Assert.assertEquals(actual.getProviderId(), expected.getProviderId());
        Assert.assertEquals(actual.getTitleAssetId(), expected.getTitleAssetId());
        Assert.assertEquals(actual.getTitlePaid(), expected.getTitlePaid());
        Assert.assertEquals(actual.getContentAssetId(), expected.getContentAssetId());
        Assert.assertEquals(actual.getProgramType(), expected.getProgramType());
        Assert.assertEquals(actual.getProvider(), expected.getProvider());
        Assert.assertEquals(actual.getCompanyId(), expected.getCompanyId());
        Assert.assertEquals(actual.getAvailableDate(), expected.getAvailableDate());
        Assert.assertEquals(actual.getExpirationDate(), expected.getExpirationDate());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<ProgramMediaAssociation> actual, List<ProgramMediaAssociation> expected) {
        List<ProgramMediaAssociation> actualList = actual.getEntries();
        Assert.assertEquals(actualList.size(), expected.size(), "Unexpected number of ProgramTeamAssociations");
        for (int i = 0; i < expected.size(); i++) {
            assertEquals(actualList.get(i), expected.get(i));
        }
    }
}
