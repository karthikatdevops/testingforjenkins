package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.PersonKnownForType;
import com.theplatform.data.tv.entity.api.data.objects.PersonType;
import com.theplatform.data.tv.entity.api.fields.PersonField;
import com.theplatform.data.tv.image.api.data.objects.MainImageInfo;
import com.theplatform.media.api.data.objects.MediaFile;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;


public class PersonFactory extends DataObjectFactoryImpl<Person, PersonClient> {

    public PersonFactory(PersonClient personClient, ValueProvider<Long> idLongValueProvider) {
        super(personClient, Person.class, idLongValueProvider);

        DateOnly dateOnly = new DateOnly(1970, 1, 1);

        this.addPresetFieldsOverrides(
                PersonField.personType, PersonType.Person.getFriendlyName(),
                PersonField.knownFor, Arrays.asList(PersonKnownForType.Video.getFriendlyName()),
                PersonField.name, new PrefixedIdFieldProvider("name"),
                PersonField.birth, dateOnly,
                PersonField.death, dateOnly,
                PersonField.shortBio, new PrefixedIdFieldProvider("shortBio"),
                PersonField.mediumBio, new PrefixedIdFieldProvider("mediumBio"),
                PersonField.longBio, new PrefixedIdFieldProvider("longBio"),
                PersonField.credits, new ArrayList<CreditAssociation>(),
                PersonField.birthName, new PrefixedIdFieldProvider("birthName"),
                PersonField.sortName, new PrefixedIdFieldProvider("sortName"),
                PersonField.aliases, new ArrayList<String>(),
                PersonField.imageIds, new ArrayList<URI>(),
                PersonField.mainImages, new HashMap<String, MediaFile>(),
                PersonField.birthplace, new PrefixedIdFieldProvider("birthplace"),
                PersonField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                PersonField.selectedImages, new ArrayList<MainImageInfo>(),
                DataObjectField.author, new PrefixedIdFieldProvider("author"),
                DataObjectField.description, new PrefixedIdFieldProvider("description"),
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()

        );
    }

}
