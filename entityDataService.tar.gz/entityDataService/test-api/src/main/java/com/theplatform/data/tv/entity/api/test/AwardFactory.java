package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.data.objects.Award;

/**
 * @author jethrolai
 */
public class AwardFactory extends EndpointFactory<Award> {

}
