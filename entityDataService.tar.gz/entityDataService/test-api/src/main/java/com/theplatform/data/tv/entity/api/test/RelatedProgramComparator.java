package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;
import org.testng.Assert;

import java.util.List;

/**
 * User: lmartin Asserts equality on Related Programs.
 *
 * @since 4/8/2011
 */
public class RelatedProgramComparator {

    private RelatedProgramComparator() {

    }

    public static void assertEquals(RelatedProgram actual, RelatedProgram expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getSourceProgramId(), expected.getSourceProgramId());
        assertEmbeddedProgramEquals(actual.getSourceProgram(), expected.getSourceProgram());
        Assert.assertEquals(actual.getTargetProgramId(), expected.getTargetProgramId());
        assertEmbeddedProgramEquals(actual.getTargetProgram(), expected.getTargetProgram());
        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getJustification(), expected.getJustification());
    }

    private static void assertEmbeddedProgramEquals(Program actual, Program expected) {

        if (actual == null && expected == null)
            return;
        if ((actual == null && expected != null) || (actual != null && expected == null))
            Assert.fail("Only one of actual and expected RelatedProgram.sourceProgram/targetProgram is null.");

        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getTitle(), expected.getTitle());
        Assert.assertEquals(actual.getYear(), expected.getYear());
        Assert.assertEquals(actual.getShortSynopsis(), expected.getShortSynopsis());
        Assert.assertEquals(actual.getMediumSynopsis(), expected.getMediumSynopsis());
        Assert.assertEquals(actual.getLongSynopsis(), expected.getLongSynopsis());
        Assert.assertEquals(actual.getRuntime(), expected.getRuntime());
        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getLanguage(), expected.getLanguage());
        Assert.assertEquals(actual.getPartNumber(), expected.getPartNumber());
        Assert.assertEquals(actual.getTotalParts(), expected.getTotalParts());
        Assert.assertEquals(actual.getReleaseDate(), expected.getReleaseDate());
        Assert.assertEquals(actual.getStarRating(), expected.getStarRating());
        Assert.assertEquals(actual.getSeriesId(), expected.getSeriesId());
        Assert.assertEquals(actual.getTvSeasonId(), expected.getTvSeasonId());
        Assert.assertEquals(actual.getOriginalAirDate(), expected.getOriginalAirDate());
        Assert.assertEquals(actual.getTvSeasonEpisodeNumber(), expected.getTvSeasonEpisodeNumber());
        Assert.assertEquals(actual.getFirstAirDate(), expected.getFirstAirDate());
        Assert.assertEquals(actual.getLastAirDate(), expected.getLastAirDate());

    }

    public static void assertEquals(Feed<RelatedProgram> actualRelatedProgramFeed, List<RelatedProgram> expectedRelatedPrograms) {
        List<RelatedProgram> actualRelatedPrograms = actualRelatedProgramFeed.getEntries();
        Assert.assertEquals(actualRelatedPrograms.size(), expectedRelatedPrograms.size(), "Unexpected number of RelatedPrograms");
        for (int i = 0; i < expectedRelatedPrograms.size(); i++)
            assertEquals(actualRelatedPrograms.get(i), expectedRelatedPrograms.get(i));

    }
}