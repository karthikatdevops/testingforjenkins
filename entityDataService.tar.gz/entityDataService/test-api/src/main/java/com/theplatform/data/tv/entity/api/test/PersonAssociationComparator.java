package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.DateOnlyComparator;
import com.theplatform.data.tv.entity.api.data.objects.PersonAssociation;
import org.testng.Assert;

public class PersonAssociationComparator {

    private PersonAssociationComparator() {

    }

    public static void assertEquals(PersonAssociation actual, PersonAssociation expected) {
        if (actual == null && expected == null)
            return;
        if ((actual != null && expected == null) || (actual == null && expected != null))
            Assert.fail("Only one of actual and expected PersonAssociation is null");

        Assert.assertEquals(actual.getPersonId(), expected.getPersonId());
        Assert.assertEquals(actual.getName(), expected.getName());
        DateOnlyComparator.assertEquals(actual.getBirth(), expected.getBirth());
    }
}
