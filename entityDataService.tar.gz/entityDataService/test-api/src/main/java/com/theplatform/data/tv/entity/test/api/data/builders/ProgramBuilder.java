package com.theplatform.data.tv.entity.test.api.data.builders;

import com.theplatform.contrib.testing.builder.MerlinDataObjectBuilder;
import com.theplatform.data.api.objects.type.DateOnly;
import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;

import java.net.URI;
import java.util.List;

/**
 * This class provides an easy way to initialize Programs:
 * <pre>
 * {@code
 * ProgramBuilder pb = new ProgramBuilder();
 * Program p1 = pb.build()      // same as calling new Program()
 * Program p2 = pb.year(1997).rating("R").build();
 *
 * // ProgramBuilders are immutable:
 * ProgramBuilder pulpFictionBuilder = pb.title("Pulp Fiction");
 * Program p3 = pb.build()      // still same as calling new Program()
 * Program pulpFiction = pulpFictionBuilder.language("English").build();
 * }
 * </pre>
 */
public class ProgramBuilder
        extends MerlinDataObjectBuilder<Program, ProgramBuilder> {

    public ProgramBuilder() {
        this(new Program());
    }

    public ProgramBuilder(Program program) {
        super(program);
    }

    public ProgramBuilder year(Integer year) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setYear(year);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder shortSynopsis(String shortSynopsis) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setShortSynopsis(shortSynopsis);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder mediumSynopsis(String mediumSynopsis) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setMediumSynopsis(mediumSynopsis);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder longSynopsis(String longSynopsis) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setLongSynopsis(longSynopsis);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder runtime(Integer runtime) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setRuntime(runtime);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder type(ProgramType type) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setType(type);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder language(String language) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setLanguage(language);
        return newBuilder(newTemplate);
    }


    public ProgramBuilder partNumber(Integer partNumber) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setPartNumber(partNumber);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder totalParts(Integer totalParts) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setTotalParts(totalParts);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder sortTitle(String sortTitle) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setSortTitle(sortTitle);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder starRating(Integer starRating) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setStarRating(starRating);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder category(String category) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setCategory(category);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder originalAirDate(DateOnly originalAirDate) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setOriginalAirDate(originalAirDate);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder firstRunCompanyId(URI firstRunCompanyId) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setFirstRunCompanyId(firstRunCompanyId);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder adult(Boolean adult) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setAdult(adult);
        return newBuilder(newTemplate);
    }


    public ProgramBuilder shortTitle(String shortTitle) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setShortTitle(shortTitle);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder mediumTitle(String mediumTitle) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setMediumTitle(mediumTitle);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder longTitle(String longTitle) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setLongTitle(longTitle);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder local(Boolean local) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setLocal(local);
        return newBuilder(newTemplate);
    }


    public ProgramBuilder listByTitle(Boolean listByTitle) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setListByTitle(listByTitle);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder releaseDate(DateOnly releaseDate) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setReleaseDate(releaseDate);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder seriesId(URI seriesId) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setSeriesId(seriesId);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder tvSeasonId(URI tvSeasonId) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setTvSeasonId(tvSeasonId);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder tvSeasonNumber(Integer tvSeasonNumber) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setTvSeasonNumber(tvSeasonNumber);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder tvSeasonEpisodeNumber(Integer tvSeasonEpisodeNumber) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setTvSeasonEpisodeNumber(tvSeasonEpisodeNumber);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder seriesEpisodeNumber(Integer seriesEpisodeNumber) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setSeriesEpisodeNumber(seriesEpisodeNumber);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder episodeTitle(String episodeTitle) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setEpisodeTitle(episodeTitle);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder firstAirDate(DateOnly firstAirDate) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setFirstAirDate(firstAirDate);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder lastAirDate(DateOnly lastAirDate) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setLastAirDate(lastAirDate);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder credits(List<CreditAssociation> credits) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setCredits(credits);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder tagIds(List<URI> tagIds) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setTagIds(tagIds);
        return newBuilder(newTemplate);
    }

    public ProgramBuilder imageIds(List<URI> imageIds) {
        Program newTemplate = super.cloneTemplate();
        newTemplate.setImageIds(imageIds);
        return newBuilder(newTemplate);
    }


    @Override
    protected ProgramBuilder newBuilder(Program newTemplate) {
        return new ProgramBuilder(newTemplate);
    }
}
