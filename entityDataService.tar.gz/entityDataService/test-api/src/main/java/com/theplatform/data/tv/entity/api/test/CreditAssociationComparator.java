package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.tv.entity.api.data.objects.CreditAssociation;
import org.testng.Assert;

import java.util.List;

/**
 * Provides comparison utility
 *
 * @author clai200
 * @since 4/6/2011
 */
public class CreditAssociationComparator {

    private CreditAssociationComparator() {

    }

    public static void assertEquals(CreditAssociation actual, CreditAssociation expected) {
        if (actual == null && expected == null) return;
        if ((actual == null && expected != null) || (expected == null && actual != null))
            Assert.fail("Only one of actual and expected CreditAssociation is null.");
        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getRank(), expected.getRank());
        Assert.assertEquals(actual.getPartName(), expected.getPartName());
        Assert.assertEquals(actual.getCameo(), expected.getCameo());
        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        Assert.assertEquals(actual.getPersonName(), expected.getPersonName());
        Assert.assertEquals(actual.getProgramTitle(), expected.getProgramTitle());
        Assert.assertEquals(actual.getCreditId(), expected.getCreditId());
        Assert.assertEquals(actual.getPersonId(), expected.getPersonId());
        Assert.assertEquals(actual.getProgramYear(), expected.getProgramYear());
    }

    public static void assertEquals(List<CreditAssociation> actual,
                                    List<CreditAssociation> expected) {

        if (actual == null && expected == null) return;

        if ((actual == null && expected != null) || (expected == null && actual != null))
            Assert.fail("Only one of actual and expected CreditAssociation list is null.");

        Assert.assertEquals(actual.size(), expected.size(), "Unexpected number of Credits");
        for (int i = 0; i < expected.size(); i++) {
            Assert.assertEquals(actual.get(i), expected.get(i));
        }
    }

}