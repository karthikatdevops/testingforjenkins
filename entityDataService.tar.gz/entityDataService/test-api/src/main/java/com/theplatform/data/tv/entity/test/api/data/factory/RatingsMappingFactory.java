package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.objects.RatingScheme;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.RatingsMappingClient;
import com.theplatform.data.tv.entity.api.data.objects.RatingsMapping;
import com.theplatform.data.tv.entity.api.fields.RatingsMappingField;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by lemuri200 on 6/2/15.
 */
public class RatingsMappingFactory extends DataObjectFactoryImpl<RatingsMapping, RatingsMappingClient> {

    public RatingsMappingFactory(RatingsMappingClient client, ValueProvider<Long> idProvider) {
        super(client, RatingsMapping.class, idProvider);

        Map<String, String> ratingsMap = new HashMap<>();
        ratingsMap.put("G", "G");
        ratingsMap.put("PG", "PG");
        ratingsMap.put("PG-13", "14+");

        addPresetFieldsOverrides(
                RatingsMappingField.sourceRatingSystem, RatingScheme.MPAA.getScheme(),
                RatingsMappingField.targetRatingSystem, RatingScheme.AGVOT.getScheme(),
                RatingsMappingField.ratingsMap, ratingsMap,
                RatingsMappingField.merlinResourceType, MerlinResourceType.AudienceAvailable

        );

    }
}
