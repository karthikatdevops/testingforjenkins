package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.AlbumClient;
import com.theplatform.data.tv.entity.api.data.objects.RelatedAlbum;

public class RelatedAlbumFactory extends EndpointFactory<RelatedAlbum> {

    private AlbumClient albumClient;
    private AlbumFactory albumFactory;

    @Override
    public RelatedAlbum create() {
        RelatedAlbum relatedAlbum = super.create();
        relatedAlbum.setSourceAlbumId(this.albumClient.create(this.albumFactory.create()).getId());
        relatedAlbum.setTargetAlbumId(this.albumClient.create(this.albumFactory.create()).getId());

        return relatedAlbum;
    }

    public AlbumClient getAlbumClient() {
        return albumClient;
    }

    public void setAlbumClient(AlbumClient albumClient) {
        this.albumClient = albumClient;
    }

    public AlbumFactory getAlbumFactory() {
        return albumFactory;
    }

    public void setAlbumFactory(AlbumFactory albumFactory) {
        this.albumFactory = albumFactory;
    }

}
