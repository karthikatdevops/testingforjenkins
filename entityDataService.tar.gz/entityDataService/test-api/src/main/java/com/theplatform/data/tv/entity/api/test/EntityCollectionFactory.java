package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;

/**
 * @author jethrolai
 * @since 01/05/2012
 */
public class EntityCollectionFactory extends EndpointFactory<EntityCollection> {


}
