package com.theplatform.data.tv.entity.test.api.data.builders;

import com.theplatform.contrib.testing.builder.DataObjectBuilder;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

public class EntityCollectionBuilder
        extends
        DataObjectBuilder<EntityCollection, EntityCollectionBuilder> {

    public EntityCollectionBuilder() {
        this(new EntityCollection());
    }

    public EntityCollectionBuilder(EntityCollection template) {
        super(template);
    }

    @Override
    protected EntityCollectionBuilder newBuilder(
            EntityCollection entityCollectionTemplate) {
        return new EntityCollectionBuilder(entityCollectionTemplate);
    }

    public EntityCollectionBuilder type(String type) {
        EntityCollection entityCollection = this.cloneTemplate();
        entityCollection.setType(type);
        return this.newBuilder(entityCollection);
    }

    public EntityCollectionBuilder subtype(String subtype) {
        EntityCollection entityCollection = this.cloneTemplate();
        entityCollection.setSubtype(subtype);
        return this.newBuilder(entityCollection);
    }


    public EntityCollectionBuilder entityIds(List<URI> entityIds) {
        EntityCollection entityCollection = this.cloneTemplate();
        entityCollection.setEntityIds(new ArrayList<>(entityIds));
        return this.newBuilder(entityCollection);
    }

    public EntityCollectionBuilder imageIds(List<URI> imageIds) {
        EntityCollection entityCollection = this.cloneTemplate();
        entityCollection.setImageIds(new ArrayList<>(imageIds));
        return this.newBuilder(entityCollection);
    }

    public EntityCollectionBuilder merlinResourceType(MerlinResourceType merlinResourceType) {
        EntityCollection entityCollection = this.cloneTemplate();
        entityCollection.setMerlinResourceType(merlinResourceType);
        return this.newBuilder(entityCollection);
    }

}
