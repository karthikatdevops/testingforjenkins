package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.social.api.client.SocialMediaAssociationClient;
import com.theplatform.data.tv.social.api.data.objects.SocialMediaAssociation;
import com.theplatform.data.tv.social.api.data.objects.SocialMediaType;
import com.theplatform.data.tv.social.api.fields.SocialMediaAssociationField;

/**
 * Created by lemuri200 on 9/2/14.
 */
public class SocialMediaAssociationFactory extends DataObjectFactoryImpl<SocialMediaAssociation, SocialMediaAssociationClient> {

    public SocialMediaAssociationFactory(SocialMediaAssociationClient client,
                                         DataObjectFactory<Program, ProgramClient> programFactory,
                                         ValueProvider<Long> idProvider) {
        super(client, SocialMediaAssociation.class, idProvider);

        addPresetFieldsOverrides(
                SocialMediaAssociationField.type, SocialMediaType.FACEBOOK.getFriendlyName(),
                SocialMediaAssociationField.identifier, new PrefixedIdFieldProvider("identifier"),
                SocialMediaAssociationField.entityId, new DataObjectIdProvider(programFactory),
                SocialMediaAssociationField.primary, true,
                SocialMediaAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );

    }
}
