package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.EntityCollection;
import com.theplatform.data.tv.image.api.test.MainImageInfoComparator;
import org.testng.Assert;

import java.util.HashSet;
import java.util.List;

/**
 * Utility class that asserts equality of <code>EntityCollection</code>
 *
 * @author jethrolai
 * @since 9/1/2011
 */
public class EntityCollectionComparator {

    private EntityCollectionComparator() {

    }

    /**
     * Assert the equality of two EntityCollection objects
     *
     * @param actual
     * @param expected
     */
    public static void assertEquals(EntityCollection actual, EntityCollection expected) {
        Assert.assertEquals(actual.getId(), expected.getId(), "Assert EntityCollection.id. Expect \"" + expected.getId() + "\" but the actual value is \""
                + actual.getId() + "\"");

        Assert.assertEquals(actual.getTitle(), expected.getTitle(), "Assert EntityCollection.title. Expect \"" + expected.getTitle()
                + "\" but the actual value is \"" + actual.getTitle() + "\"");
        Assert.assertEquals(actual.getDescription(), expected.getDescription(), "Assert EntityCollection.description. Expect \"" + expected.getDescription()
                + "\" but the actual value is \"" + actual.getDescription() + "\"");
        Assert.assertEquals(actual.getType(), expected.getType(), "Assert EntityCollection.type. Expect \"" + expected.getType()
                + "\" but the actual value is \"" + actual.getType() + "\"");
        Assert.assertEquals(actual.getSubtype(), expected.getSubtype(), "Assert EntityCollection.subtype. Expect \"" + expected.getSubtype()
                + "\" but the actual value is \"" + actual.getSubtype() + "\"");
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType(), "Assert EntityCollection.merlinResourceType. Expect \""
                + expected.getMerlinResourceType() + "\" but the actual value is \"" + actual.getMerlinResourceType() + "\"");


        if ((actual != null && expected == null) || (expected != null && actual == null))
            Assert.fail("Only one of actual and expected EntityCollection.entityIds is null");
        else Assert.assertEquals(new HashSet<>(actual.getEntityIds()), new HashSet<>(expected.getEntityIds()));

        MainImageInfoComparator.assertEquals(actual.getSelectedImages(), expected.getSelectedImages());

        Assert.assertEquals(actual.getPrimaryEntities(), expected.getPrimaryEntities());

    }

    public static void assertEquals(Feed<EntityCollection> actualFeed, List<EntityCollection> expectedInstances) {
        List<EntityCollection> actualInstances = actualFeed.getEntries();
        Assert.assertEquals(actualInstances.size(), expectedInstances.size(), "Unexpected number of EntityCollections");
        for (int i = 0; i < expectedInstances.size(); i++)
            assertEquals(actualInstances.get(i), expectedInstances.get(i));

    }

}
