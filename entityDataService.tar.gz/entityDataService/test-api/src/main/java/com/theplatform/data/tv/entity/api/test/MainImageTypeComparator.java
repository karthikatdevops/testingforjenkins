package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.image.api.data.objects.FallbackRule;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;

import java.util.List;

import static org.testng.Assert.assertEquals;

/**
 * Asserts equality on MainImageType
 *
 * @since 4/7/2011 .
 * @deprecated use the comparator in imageCommon instead
 */
public class MainImageTypeComparator {

    private MainImageTypeComparator() {

    }

    public static void assertMainImageTypeEqual(MainImageType actual, MainImageType expected) {
        assertEquals(actual.getId(), expected.getId());

        assertEquals(actual.getTitle(), expected.getTitle());
        assertEquals(actual.getEntityType(), expected.getEntityType());
    }

    public static void assertMainImageTypesEqual(Feed<MainImageType> actualMainImageTypeFeed, List<MainImageType> expectedMainImageTypes) {
        List<MainImageType> actualMainImageTypes = actualMainImageTypeFeed.getEntries();

        assertEquals(actualMainImageTypes.size(), expectedMainImageTypes.size(), "Unexpected number of MainImageTypes");
        for (int i = 0; i < expectedMainImageTypes.size(); i++)
            assertMainImageTypeEqual(actualMainImageTypes.get(i), expectedMainImageTypes.get(i));

    }

    private static void assertMainImageTypeFallbackRules(List<FallbackRule> actualFallbackRules, List<FallbackRule> expectedFallbackRules) {
        assertEquals(actualFallbackRules.size(), expectedFallbackRules.size(), "Unexpected number of FallbackRules");
        for (int i = 0; i < expectedFallbackRules.size(); i++) {
            assertFallbackRulesEqual(actualFallbackRules.get(i), expectedFallbackRules.get(i));
        }
    }

    private static void assertFallbackRulesEqual(FallbackRule actual, FallbackRule expected) {
        assertEquals(actual.getFallbackMainImageTypeId(), expected.getFallbackMainImageTypeId());
        assertEquals(actual.getFallbackRuleType(), expected.getFallbackRuleType());
    }
}