package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.FieldValueProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCategory;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramField;

public class MusicVideoProgramFactory extends DataObjectFactoryImpl<Program, ProgramClient> {

    public MusicVideoProgramFactory(ProgramClient client, ValueProvider<Long> idProvider) {
        this(client, idProvider, null);

    }

    public MusicVideoProgramFactory(ProgramClient client, ValueProvider<Long> idProvider, FieldValueProvider<Program, String> guidValueProvider) {
        super(client, Program.class, idProvider);

        this.addPresetFieldsOverrides(
                ProgramField.type, ProgramType.MusicVideo,
                ProgramField.category, ProgramCategory.Music.getFriendlyName());
        if (guidValueProvider != null) {
            this.addPresetFieldsOverrides(DataObjectField.guid, guidValueProvider);
        }
    }

}
