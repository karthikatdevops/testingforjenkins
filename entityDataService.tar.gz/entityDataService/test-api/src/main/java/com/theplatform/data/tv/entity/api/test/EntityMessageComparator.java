package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.DataObjectComparator;
import com.theplatform.data.tv.entity.api.data.objects.EntityMessage;
import org.testng.Assert;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 6/23/15
 */
public class EntityMessageComparator extends DataObjectComparator<EntityMessage> {

    @Override
    public void assertEquals(EntityMessage actual, EntityMessage expected) {
        super.assertEquals(actual, expected);

        if (actual != null && expected != null) {
            Assert.assertEquals(actual.getTitle(), expected.getTitle());
            Assert.assertEquals(actual.getDescription(), expected.getDescription());
            Assert.assertEquals(actual.getEntityId(), expected.getEntityId());
            Assert.assertEquals(actual.getFreeText(), expected.getFreeText());
            Assert.assertEquals(actual.getType(), expected.getType());
            Assert.assertEquals(actual.getPriority(), expected.getPriority());
            Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
        }
    }
}