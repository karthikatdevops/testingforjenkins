package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.data.objects.PersonType;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPerson;

public class RelatedPersonFactory extends EndpointFactory<RelatedPerson> {

    private PersonClient personClient;
    private PersonFactory personFactory;

    @Override
    public RelatedPerson create() {
        RelatedPerson relatedPerson = super.create();
        try {
            relatedPerson.setSourcePersonId(this.personClient
                    .create(this.personFactory.create(new DataServiceField("personType", PersonType.Band.getFriendlyName()))).getId());
            relatedPerson.setTargetPersonId(this.personClient.create(
                    this.personFactory.create(new DataServiceField("personType", PersonType.Person.getFriendlyName()))).getId());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return relatedPerson;
    }

    public PersonClient getPersonClient() {
        return personClient;
    }

    public void setPersonClient(PersonClient personClient) {
        this.personClient = personClient;
    }

    public PersonFactory getPersonFactory() {
        return personFactory;
    }

    public void setPersonFactory(PersonFactory personFactory) {
        this.personFactory = personFactory;
    }

}
