package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramAssociation;

import java.net.URI;

public class ProgramAssociationFactory {

    private ProgramClient programClient;

    public ProgramAssociation create(URI programId) {
        Program program = this.programClient.get(programId, new String[]{"title", "year"});
        ProgramAssociation programAssociation = new ProgramAssociation();
        programAssociation.setProgramId(programId);
        programAssociation.setTitle(program.getTitle());
        programAssociation.setYear(program.getYear());
        return programAssociation;
    }

    public ProgramAssociation create(Program program) {
        ProgramAssociation programAssociation = new ProgramAssociation();
        programAssociation.setProgramId(program.getId());
        programAssociation.setTitle(program.getTitle());
        programAssociation.setYear(program.getYear());
        return programAssociation;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }


}
