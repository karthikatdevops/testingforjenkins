package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.ProgramSongAssociationClient;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSongAssociationType;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.fields.ProgramSongAssociationField;

public class ProgramSongAssociationFactory extends DataObjectFactoryImpl<ProgramSongAssociation, ProgramSongAssociationClient> {

    private DataObjectFactory<Program, ProgramClient> programFactory;
    private DataObjectFactory<Song, SongClient> songFactory;

    public ProgramSongAssociationFactory(
            ProgramSongAssociationClient client,
            ValueProvider<Long> idProvider,
            DataObjectFactory<Program, ProgramClient> programFactory,
            DataObjectFactory<Song, SongClient> songFactory
    ) {

        super(client, ProgramSongAssociation.class, idProvider);

        if (programFactory == null) {
            throw new IllegalArgumentException("The argument 'programFactory' cannot be null");
        }
        if (songFactory == null) {
            throw new IllegalArgumentException("The argument 'songFactory' cannot be null");
        }

        this.programFactory = programFactory;
        this.songFactory = songFactory;

        this.addPresetFieldsOverrides(
                ProgramSongAssociationField.programId, new DataObjectIdProvider(this.programFactory),
                ProgramSongAssociationField.songId, new DataObjectIdProvider(this.songFactory),
                ProgramSongAssociationField.type, ProgramSongAssociationType.MusicVideo.getFriendlyName(),
                ProgramSongAssociationField.programType, ProgramType.Other,
                ProgramSongAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );

    }

    public ProgramSongAssociationFactory(
            ProgramSongAssociationClient client,
            ValueProvider<Long> idProvider) {
        super(client, idProvider);
        this.addPresetFieldsOverrides(
                ProgramSongAssociationField.type, ProgramSongAssociationType.MusicVideo.getFriendlyName());
    }

    public DataObjectFactory<Program, ProgramClient> getProgramFactory() {
        return programFactory;
    }

    public DataObjectFactory<Song, SongClient> getSongFactory() {
        return songFactory;
    }

}
