package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SongCredit;
import org.testng.Assert;

import java.util.List;

public class SongCreditComparator {

    public static void assertEquals(SongCredit actual, SongCredit expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getRank(), expected.getRank());
        Assert.assertEquals(actual.getPersonId(), expected.getPersonId());
        Assert.assertEquals(actual.getSongId(), expected.getSongId());
        Assert.assertEquals(actual.getActive(), expected.getActive());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<SongCredit> actual, List<SongCredit> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));

    }
}
