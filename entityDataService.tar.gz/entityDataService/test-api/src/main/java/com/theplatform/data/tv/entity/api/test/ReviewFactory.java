package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Review;

public class ReviewFactory extends EndpointFactory<Review> {

    private ProgramClient programClient;

    private ProgramEndpointFactory programFactory;


    @Override
    public Review create() {
        Review endpoint = super.create();
        // For entityId, there is no foreign key constraint validation so we can
        // just set a fake one in template bean.
        endpoint.setProgramId(programClient.create(programFactory.create()).getId());
        return endpoint;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }

    public ProgramEndpointFactory getProgramFactory() {
        return programFactory;
    }

    public void setProgramFactory(ProgramEndpointFactory programFactory) {
        this.programFactory = programFactory;
    }

}
