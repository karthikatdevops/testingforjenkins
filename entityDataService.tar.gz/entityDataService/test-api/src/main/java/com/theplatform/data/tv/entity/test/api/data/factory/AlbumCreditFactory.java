package com.theplatform.data.tv.entity.test.api.data.factory;

//import com.sun.deploy.util.ParameterUtil;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.AlbumClient;
import com.theplatform.data.tv.entity.api.client.AlbumCreditClient;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.data.objects.Album;
import com.theplatform.data.tv.entity.api.data.objects.AlbumCredit;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.fields.AlbumCreditField;

/**
 * User: jdoto200
 * Date: 4/29/13
 * Time: 3:53 PM
 */
public class AlbumCreditFactory extends DataObjectFactoryImpl<AlbumCredit, AlbumCreditClient> {

    public AlbumCreditFactory(AlbumCreditClient client, DataObjectFactory<Album, AlbumClient> albumFactory,
                              DataObjectFactory<Person, PersonClient> personFactory, ValueProvider<Long> idProvider) {

        super(client, AlbumCredit.class, idProvider);

        addPresetFieldsOverrides(
                AlbumCreditField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                AlbumCreditField.type, "Primary Artist",
                AlbumCreditField.rank, 1,
                AlbumCreditField.albumId, new DataObjectIdProvider(albumFactory),
                AlbumCreditField.personId, new DataObjectIdProvider(personFactory),
                AlbumCreditField.active, false,
                DataObjectField.author, new PrefixedIdFieldProvider("author"),
                DataObjectField.description, new PrefixedIdFieldProvider("description"),
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }

    public AlbumCreditFactory(AlbumCreditClient client, ValueProvider<Long> idProvider) {
        super(client, idProvider);
    }

}

