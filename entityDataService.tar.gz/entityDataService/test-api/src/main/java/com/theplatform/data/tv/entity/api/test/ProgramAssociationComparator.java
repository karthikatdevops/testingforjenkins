package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.tv.entity.api.data.objects.ProgramAssociation;
import org.testng.Assert;

/**
 * @author jethrolai
 */
public class ProgramAssociationComparator {

    private ProgramAssociationComparator() {

    }

    public static void assertEquals(ProgramAssociation actual, ProgramAssociation expected) {
        if (actual == null && expected == null)
            return;
        if ((actual != null && expected == null) || (actual == null && expected != null))
            Assert.fail("Only one of actual and expected ProgramAssociation is null");

        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        Assert.assertEquals(actual.getYear(), expected.getYear());
        Assert.assertEquals(actual.getTitle(), expected.getTitle());
    }
}
