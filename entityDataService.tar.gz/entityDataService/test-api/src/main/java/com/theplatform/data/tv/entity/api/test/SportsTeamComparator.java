package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;
import com.theplatform.data.tv.image.api.test.MainImageInfoComparator;
import org.testng.Assert;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author clai200
 * @since 4/8/2011
 */
public class SportsTeamComparator {

    private SportsTeamComparator() {

    }

    public static void assertEquals(SportsTeam actualSportsTeam, SportsTeam expectedSportsTeam) {
        Assert.assertEquals(actualSportsTeam.getId(), expectedSportsTeam.getId());

        // sports team fields
        Assert.assertEquals(actualSportsTeam.getRepresentingName(), expectedSportsTeam.getRepresentingName());
        Assert.assertEquals(actualSportsTeam.getNickName(), expectedSportsTeam.getNickName());
        Assert.assertEquals(actualSportsTeam.getLeagueId(), expectedSportsTeam.getLeagueId());
        Assert.assertEquals(actualSportsTeam.getParentSportsTeamId(), expectedSportsTeam.getParentSportsTeamId());
        Assert.assertEquals(actualSportsTeam.getCity(), expectedSportsTeam.getCity());
        Assert.assertEquals(actualSportsTeam.getState(), expectedSportsTeam.getState());
        Assert.assertEquals(actualSportsTeam.getCountry(), expectedSportsTeam.getCountry());
        Assert.assertEquals(actualSportsTeam.getConference(), expectedSportsTeam.getConference());
        Assert.assertEquals(actualSportsTeam.getDivision(), expectedSportsTeam.getDivision());
        Assert.assertEquals(actualSportsTeam.getSportType(), expectedSportsTeam.getSportType());
        Assert.assertEquals(actualSportsTeam.getType(), expectedSportsTeam.getType());
        Assert.assertEquals(actualSportsTeam.getGender(), expectedSportsTeam.getGender());
        Assert.assertEquals(actualSportsTeam.getCoach(), expectedSportsTeam.getCoach());
        Assert.assertEquals(actualSportsTeam.getCoachPersonId(), expectedSportsTeam.getCoachPersonId());
        Assert.assertEquals(actualSportsTeam.getVenue(), expectedSportsTeam.getVenue());
        Assert.assertEquals(actualSportsTeam.getImageIds(), expectedSportsTeam.getImageIds());
        Assert.assertEquals(actualSportsTeam.getShortBio(), expectedSportsTeam.getShortBio());
        Assert.assertEquals(actualSportsTeam.getMediumBio(), expectedSportsTeam.getMediumBio());
        Assert.assertEquals(actualSportsTeam.getLongBio(), expectedSportsTeam.getLongBio());

        MainImageInfoComparator.assertEquals(actualSportsTeam.getSelectedImages(), expectedSportsTeam.getSelectedImages());

        Assert.assertEquals(actualSportsTeam.getMerlinResourceType(), expectedSportsTeam.getMerlinResourceType());

        // Check if actual and expected have Tag IDs:
        if (actualSportsTeam.getTagIds() == null) {
            Assert.assertNull(expectedSportsTeam.getTagIds());
        }
        // If they have Tag IDs, sort the lists and compare them. (If they have the same contents, they should
        // be considered equal, but if they're in different orders, a straight assertEquals will fail.)
        else {
            Assert.assertNotNull(expectedSportsTeam.getTagIds());
            List<URI> actualTagIds = new ArrayList<>();
            actualTagIds.addAll(actualSportsTeam.getTagIds());
            Collections.sort(actualTagIds);
            List<URI> expectedTagIds = new ArrayList<>();
            expectedTagIds.addAll(expectedSportsTeam.getTagIds());
            Collections.sort(expectedTagIds);
            Assert.assertEquals(actualTagIds, expectedTagIds);
        }

    }

    public static void assertEquals(List<SportsTeam> expectedTeams, List<SportsTeam> sortedTeams) {
        Assert.assertEquals(expectedTeams.size(), sortedTeams.size(), "Unexpected number of SportsTeams");
        for (int i = 0; i < expectedTeams.size(); i++)
            SportsTeamComparator.assertEquals(sortedTeams.get(i), expectedTeams.get(i));
    }

    public static void assertEquals(Feed<SportsTeam> actualSportsTeamFeed, List<SportsTeam> expectedSportsTeams) {
        List<SportsTeam> actualSportsTeams = actualSportsTeamFeed.getEntries();
        Assert.assertEquals(actualSportsTeams.size(), expectedSportsTeams.size(), "Unexpected number of SportsTeams");
        for (int i = 0; i < expectedSportsTeams.size(); i++) {
            assertEquals(actualSportsTeams.get(i), expectedSportsTeams.get(i));
        }
    }

}
