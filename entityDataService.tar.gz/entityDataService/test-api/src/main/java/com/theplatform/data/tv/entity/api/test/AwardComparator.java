package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Award;
import org.testng.Assert;

import java.util.List;

/**
 * Utility class that asserts equality of <code>Award</code>
 *
 * @author clai200
 * @since 4/05/2011
 */
public class AwardComparator {

    // Restrict public access
    private AwardComparator() {

    }

    /**
     * Compares Award's id, ownerId, title, description and rank property
     *
     * @param actual
     * @param expected
     */
    public static void assertEquals(Award actual, Award expected) {
        Assert.assertEquals(actual.getId(), expected.getId());

        Assert.assertEquals(actual.getTitle(), expected.getTitle());
        Assert.assertEquals(actual.getDescription(), expected.getDescription());
        Assert.assertEquals(actual.getRank(), expected.getRank());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<Award> actualFeed, List<Award> expectedAwards) {
        List<Award> actualAwards = actualFeed.getEntries();
        Assert.assertEquals(actualAwards.size(), expectedAwards.size(), "Unexpected number of Awards");
        for (int i = 0; i < expectedAwards.size(); i++)
            assertEquals(actualAwards.get(i), expectedAwards.get(i));

    }

}
