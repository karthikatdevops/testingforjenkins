package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SportsLeague;
import org.testng.Assert;

import java.util.List;

public class SportsLeagueComparator {

    private SportsLeagueComparator() {

    }

    public static void assertEquals(SportsLeague actual, SportsLeague expected) {
        Assert.assertEquals(actual.getId(), expected.getId());

        // sports Event fields
        Assert.assertEquals(actual.getTitle(), expected.getTitle());
        Assert.assertEquals(actual.getDescription(), expected.getDescription());

        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<SportsLeague> actual, List<SportsLeague> expected) {
        List<SportsLeague> actualSportsLeagues = actual.getEntries();
        Assert.assertEquals(actualSportsLeagues.size(), expected.size(), "Unexpected number of SportsLeagues");
        for (int i = 0; i < expected.size(); i++)
            assertEquals(actualSportsLeagues.get(i), expected.get(i));

    }

}
