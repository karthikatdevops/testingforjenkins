package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramRank;
import org.testng.Assert;

import java.util.List;

public class ProgramRankComparator {

    public static void assertEquals(ProgramRank actual, ProgramRank expected) {

        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getRank(), expected.getRank());
        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        ProgramComparator.assertEquals(actual.getProgram(), expected.getProgram());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());

    }

    public static void assertEquals(Feed<ProgramRank> actual, List<ProgramRank> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));
    }

}
