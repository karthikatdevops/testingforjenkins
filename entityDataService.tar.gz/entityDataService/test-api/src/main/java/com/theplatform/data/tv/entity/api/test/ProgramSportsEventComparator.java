package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import org.testng.Assert;

import java.util.List;

public class ProgramSportsEventComparator {

    private ProgramSportsEventComparator() {

    }

    public static void assertEquals(ProgramSportsEvent actual, ProgramSportsEvent expected) {
        Assert.assertEquals(actual.getId(), expected.getId());

        // program sports Event fields
        Assert.assertEquals(actual.getProgramId(), expected.getProgramId());
        Assert.assertEquals(actual.getSportsEventId(), expected.getSportsEventId());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<ProgramSportsEvent> actual,
                                    List<ProgramSportsEvent> expected) {
        List<ProgramSportsEvent> actualProgramSportsEvents = actual.getEntries();
        Assert.assertEquals(actualProgramSportsEvents.size(), expected.size(), "Unexpected number of ProgramSportsEvents");
        for (int i = 0; i < expected.size(); i++)
            assertEquals(actualProgramSportsEvents.get(i), expected.get(i));

    }

}
