package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.DataObjectComparator;
import com.theplatform.data.tv.entity.api.data.objects.Videogame;
import org.testng.Assert;

/**
 * Created by : Vincent Fumo (vincent_fumo@cable.comcast.com)
 * Created on : 12/3/14
 */
public class VideogameComparator extends DataObjectComparator<Videogame> {

    @Override
    public void assertEquals(Videogame actual, Videogame expected) {
        super.assertEquals(actual, expected);

        if (actual != null && expected != null) {
            Assert.assertEquals(actual.getTitle(), expected.getTitle());
            Assert.assertEquals(actual.getShortTitle(), expected.getShortTitle());
            Assert.assertEquals(actual.getMediumTitle(), expected.getMediumTitle());
            Assert.assertEquals(actual.getLongTitle(), expected.getLongTitle());
            Assert.assertEquals(actual.getShortSynopsis(), expected.getShortSynopsis());
            Assert.assertEquals(actual.getMediumSynopsis(), expected.getMediumSynopsis());
            Assert.assertEquals(actual.getLongSynopsis(), expected.getLongSynopsis());
            Assert.assertEquals(actual.getType(), expected.getType());
            Assert.assertEquals(actual.getNativeId(), expected.getNativeId());
            Assert.assertEquals(actual.getReleaseDate(), expected.getReleaseDate());
            Assert.assertEquals(actual.getAttributionString(), expected.getAttributionString());
            Assert.assertEquals(actual.getSinglePlayer(), expected.getSinglePlayer());
            Assert.assertEquals(actual.getMultiPlayer(), expected.getMultiPlayer());
            Assert.assertEquals(actual.getMinPlayers(), expected.getMinPlayers());
            Assert.assertEquals(actual.getMaxPlayers(), expected.getMaxPlayers());

            areCollectionsMerlinEqual(actual.getLanguages(), expected.getLanguages());
            areCollectionsMerlinEqual(actual.getContentRatings(), expected.getContentRatings());
            areCollectionsMerlinEqual(actual.getTagIds(), expected.getTagIds());
            areCollectionsMerlinEqual(actual.getSelectedImages(), expected.getSelectedImages());

        }
    }
}


