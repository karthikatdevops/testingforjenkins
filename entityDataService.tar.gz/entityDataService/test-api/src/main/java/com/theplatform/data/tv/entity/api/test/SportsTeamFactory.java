package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.data.objects.SportsTeam;

/**
 * @author jethrolai
 */
public class SportsTeamFactory extends EndpointFactory<SportsTeam> {


}
