package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.MediaIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.ProgramMediaAssociationClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociationMetadataManagementInfo;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;
import com.theplatform.data.tv.entity.api.fields.ProgramMediaAssociationField;

import java.util.HashSet;

/**
 * Created with IntelliJ IDEA.
 * User: jdoto200
 * Date: 7/29/13
 * Time: 1:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProgramMediaAssociationFactory extends DataObjectFactoryImpl<ProgramMediaAssociation, ProgramMediaAssociationClient> {

    private DataObjectFactory<Program, ProgramClient> programFactory;


    public ProgramMediaAssociationFactory(ProgramMediaAssociationClient client, ValueProvider<Long> idProvider, DataObjectFactory<Program, ProgramClient> programFactory, ValueProvider<MediaId> mediaIdValueProvider) {
        super(client, ProgramMediaAssociation.class, idProvider);
        this.addPresetFieldsOverrides(
                ProgramMediaAssociationField.programId, new DataObjectIdProvider(programFactory),
                ProgramMediaAssociationField.mediaId, new MediaIdProvider(idProvider),
                ProgramMediaAssociationField.mediaGuid, "mediaGuid",
                ProgramMediaAssociationField.programType, ProgramType.Other,
                ProgramMediaAssociationField.categoryPaths, new HashSet<String>(),
                ProgramMediaAssociationField.mezzanineMediaId, new MediaIdProvider(idProvider),
                ProgramMediaAssociationField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new ProgramMediaAssociationMetadataManagementInfo()
        );
    }

    public ProgramMediaAssociationFactory(ProgramMediaAssociationClient client, ValueProvider<Long> idProvider, ValueProvider<MediaId> mediaIdValueProvider) {
        this(client, idProvider, null, mediaIdValueProvider);

    }

    public ProgramMediaAssociationFactory(ProgramMediaAssociationClient client, ValueProvider<MediaId> mediaIdValueProvider) {
        this(client, null, null, mediaIdValueProvider);
    }

}