package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.client.RelatedPersonClient;
import com.theplatform.data.tv.entity.api.data.objects.Person;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPerson;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPersonType;
import com.theplatform.data.tv.entity.api.fields.RelatedPersonField;

import java.util.Date;

/**
 * Created by lemuri200 on 9/2/14.
 */
public class RelatedPersonFactory extends DataObjectFactoryImpl<RelatedPerson, RelatedPersonClient> {

    public RelatedPersonFactory(RelatedPersonClient client, DataObjectFactory<Person, PersonClient> personFactory,
                                ValueProvider<Long> idProvider) {
        super(client, RelatedPerson.class, idProvider);
        addPresetFieldsOverrides(
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                RelatedPersonField.sourcePersonId, new DataObjectIdProvider(personFactory),
                RelatedPersonField.targetPersonId, new DataObjectIdProvider(personFactory),
                RelatedPersonField.startDate, new Date(),
                RelatedPersonField.endDate, new Date(),
                RelatedPersonField.rank, 1,
                RelatedPersonField.type, RelatedPersonType.influencedMusic.getFriendlyName(),
                RelatedPersonField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()

        );
    }
}
