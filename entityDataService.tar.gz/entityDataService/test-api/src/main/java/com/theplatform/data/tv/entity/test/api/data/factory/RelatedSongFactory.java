package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.RelatedSongClient;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.data.objects.RelatedSong;
import com.theplatform.data.tv.entity.api.data.objects.RelatedSongType;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.fields.RelatedSongField;

/**
 * Created by lemuri200 on 9/2/14.
 */
public class RelatedSongFactory extends DataObjectFactoryImpl<RelatedSong, RelatedSongClient> {

    public RelatedSongFactory(RelatedSongClient client, DataObjectFactory<Song, SongClient> songFactory,
                              ValueProvider<Long> idProvider) {
        super(client, RelatedSong.class, idProvider);

        addPresetFieldsOverrides(
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                RelatedSongField.sourceSongId, new DataObjectIdProvider(songFactory),
                RelatedSongField.targetSongId, new DataObjectIdProvider(songFactory),
                RelatedSongField.rank, 1,
                RelatedSongField.type, RelatedSongType.IsSimilar.getFriendlyName(),
                RelatedSongField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );


    }
}

