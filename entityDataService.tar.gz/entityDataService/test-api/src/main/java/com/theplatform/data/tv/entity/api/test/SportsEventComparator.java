package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.image.api.test.MainImageInfoComparator;
import org.testng.Assert;

import java.util.List;

/**
 * @author clai200
 * @since 4/8/2011
 */
public class SportsEventComparator {

    private SportsEventComparator() {

    }

    public static void assertEquals(SportsEvent actualSportsEvent, SportsEvent expectedSportsEvent) {
        Assert.assertEquals(actualSportsEvent.getId(), expectedSportsEvent.getId());

        // data service fields
        Assert.assertEquals(actualSportsEvent.getTitle(), expectedSportsEvent.getTitle());

        // sports Event fields
        Assert.assertEquals(actualSportsEvent.getProgramIds(), expectedSportsEvent.getProgramIds());
        Assert.assertEquals(actualSportsEvent.getLeagueId(), expectedSportsEvent.getLeagueId());
        Assert.assertEquals(actualSportsEvent.getCity(), expectedSportsEvent.getCity());
        Assert.assertEquals(actualSportsEvent.getState(), expectedSportsEvent.getState());
        Assert.assertEquals(actualSportsEvent.getCountry(), expectedSportsEvent.getCountry());
        Assert.assertEquals(actualSportsEvent.getSportType(), expectedSportsEvent.getSportType());
        Assert.assertEquals(actualSportsEvent.getConference(), expectedSportsEvent.getConference());
        Assert.assertEquals(actualSportsEvent.getDivision(), expectedSportsEvent.getDivision());
        Assert.assertEquals(actualSportsEvent.getVenue(), expectedSportsEvent.getVenue());
        Assert.assertEquals(actualSportsEvent.getImageIds(), expectedSportsEvent.getImageIds());
        MainImageInfoComparator.assertEquals(actualSportsEvent.getSelectedImages(), expectedSportsEvent.getSelectedImages());
        Assert.assertEquals(actualSportsEvent.getMerlinResourceType(), expectedSportsEvent.getMerlinResourceType());
    }

    public static void assertEquals(Feed<SportsEvent> actualSportsEventFeed, List<SportsEvent> expectedSportsEvents) {
        List<SportsEvent> actualSportsEvents = actualSportsEventFeed.getEntries();
        Assert.assertEquals(actualSportsEvents.size(), expectedSportsEvents.size(), "Unexpected number of SportsEvents");
        for (int i = 0; i < expectedSportsEvents.size(); i++)
            assertEquals(actualSportsEvents.get(i), expectedSportsEvents.get(i));
    }

}
