package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.contrib.testing.provider.IdProviderImpl;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.ProgramSportsEventClient;
import com.theplatform.data.tv.entity.api.client.SportsEventClient;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;
import com.theplatform.data.tv.entity.api.fields.ProgramSportsEventField;

public class ProgramSportsEventFactory extends DataObjectFactoryImpl<ProgramSportsEvent, ProgramSportsEventClient> {

    private final DataObjectFactory<Program, ProgramClient> programFactory;
    private final DataObjectFactory<SportsEvent, SportsEventClient> sportsEventFactory;

    public ProgramSportsEventFactory(ProgramSportsEventClient programSportsEventClient,
                                     DataObjectFactory<Program, ProgramClient> programFactory,
                                     DataObjectFactory<SportsEvent, SportsEventClient> sportsEventFactory,
                                     ValueProvider<Long> idProvider) {
        super(programSportsEventClient, ProgramSportsEvent.class, idProvider);

        this.programFactory = programFactory;
        this.sportsEventFactory = sportsEventFactory;

        this.addPresetFieldsOverrides(ProgramSportsEventField.programId,
                new DataObjectIdProvider(this.programFactory),
                ProgramSportsEventField.sportsEventId, new DataObjectIdProvider(this.sportsEventFactory),
                ProgramSportsEventField.merlinResourceType, MerlinResourceType.AudienceAvailable
        );
    }

    public ProgramSportsEventFactory(ProgramSportsEventClient programSportsEventClient,
                                     DataObjectFactory<Program, ProgramClient> programFactory,
                                     DataObjectFactory<SportsEvent, SportsEventClient> sportsEventFactory) {
        this(programSportsEventClient, programFactory, sportsEventFactory, new IdProviderImpl());

    }


}
