package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.RelatedPerson;
import org.testng.Assert;

import java.util.Date;
import java.util.List;

public class RelatedPersonComparator {

    public static void assertEquals(RelatedPerson actual, RelatedPerson expected) {

        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getSourcePersonId(), expected.getSourcePersonId());
        Assert.assertEquals(actual.getTargetPersonId(), expected.getTargetPersonId());

        assertDateEqualsAccurateToSecond(actual.getStartDate(), expected.getStartDate());
        assertDateEqualsAccurateToSecond(actual.getEndDate(), expected.getEndDate());

        Assert.assertEquals(actual.getRank(), expected.getRank());
        Assert.assertEquals(actual.getType(), expected.getType());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());

    }

    private static void assertDateEqualsAccurateToSecond(Date actual, Date expected) {
        if (actual == null && expected == null)
            return;
        if ((actual != null && expected == null) || (actual == null && expected != null))
            Assert.fail("Only one of actual and expected RelatedPerson.startDate/endDate is null");
        Assert.assertEquals(actual.getTime() / 1000L, expected.getTime() / 1000L);

    }

    public static void assertEquals(Feed<RelatedPerson> actual, List<RelatedPerson> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));

    }
}
