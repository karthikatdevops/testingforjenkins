package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.TagClient;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import com.theplatform.data.tv.entity.api.data.objects.TagType;
import com.theplatform.data.tv.entity.api.fields.TagField;


public class TagFactory extends DataObjectFactoryImpl<Tag, TagClient> {


    public TagFactory(TagClient client, ValueProvider<Long> dataObjectIdProvider) {
        super(client, Tag.class, dataObjectIdProvider);
        this.addPresetFieldsOverrides(
                DataObjectField.title, new PrefixedIdFieldProvider("TagName"),
                TagField.type, TagType.Genre.getFriendlyName(),
                TagField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }
}
