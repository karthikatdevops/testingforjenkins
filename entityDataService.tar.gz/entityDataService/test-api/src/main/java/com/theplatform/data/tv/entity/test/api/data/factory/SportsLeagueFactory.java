package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.data.api.fields.ManagedMerlinDataObjectField;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.api.data.objects.MetadataManagementInfo;
import com.theplatform.data.tv.entity.api.client.SportsLeagueClient;
import com.theplatform.data.tv.entity.api.data.objects.SportsLeague;
import com.theplatform.data.tv.entity.api.fields.SportsLeagueField;

public class SportsLeagueFactory extends DataObjectFactoryImpl<SportsLeague, SportsLeagueClient> {

    public SportsLeagueFactory(SportsLeagueClient client, ValueProvider<Long> dataObjectIdProvider) {
        super(client, SportsLeague.class, dataObjectIdProvider);

        addPresetFieldsOverrides(
                SportsLeagueField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, "author",
                DataObjectField.description, "description",
                ManagedMerlinDataObjectField.metadataManagementInfo, new MetadataManagementInfo()
        );
    }

    public void addDefaultValueProviders(Object... defaultMetadata) {
        this.addPresetFieldsOverrides(defaultMetadata);
    }
}
