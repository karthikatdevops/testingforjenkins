package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.contrib.testing.field.DataServiceField;
import com.theplatform.data.tv.entity.api.data.objects.Program;
import com.theplatform.data.tv.entity.api.data.objects.ProgramType;

import java.util.List;

/**
 * @author jethrolai
 * @since 11/08/2011
 * <p>
 * TODO implenment ProgramFactory with different types
 */
public class ProgramEndpointFactory extends EndpointFactory<Program> {

    private ProgramMovieFactory programMovieFactory;

    private ProgramEpisodeFactory programEpisodeFactory;

    private ProgramSeriesMasterFactory programSeriesMasterFactory;

    @Override
    public Program create() {

        return programMovieFactory.create();
    }

    @Override
    public List<Program> create(int amount) {
        return programMovieFactory.create(amount);
    }

    @Override
    public List<Program> create(int amount, DataServiceField... fields) {
        return programMovieFactory.create(amount, fields);
    }

    @Override
    public Program create(DataServiceField... overrideFields) {
        return programMovieFactory.create(overrideFields);
    }

    public Program create(ProgramType type) {
        switch (type) {
            case Movie:
                return programMovieFactory.create();
            case SeriesMaster:
                return programSeriesMasterFactory.create();
            case Episode:
                return programEpisodeFactory.create();

            default:
                Program program = programMovieFactory.create();
                program.setType(type);
                if (!type.equals(ProgramType.Movie))
                    program.setReleaseDate(null);
                return program;
        }
    }

    public List<Program> create(ProgramType type, int amount) {
        switch (type) {
            case Movie:
                return programMovieFactory.create(amount);
            case SeriesMaster:
                return programSeriesMasterFactory.create(amount);
            case Episode:
                return programEpisodeFactory.create(amount);

            default:
                List<Program> programs = programMovieFactory.create(amount);

                for (Program program : programs) {
                    program.setType(type);
                    if (!type.equals(ProgramType.Movie))
                        program.setReleaseDate(null);
                }
                return programs;
        }
    }

    public Program create(ProgramType type, DataServiceField... overrideFields) {
        switch (type) {
            case Movie:
                return programMovieFactory.create(overrideFields);
            case SeriesMaster:
                return programSeriesMasterFactory.create(overrideFields);
            case Episode:
                return programEpisodeFactory.create(overrideFields);

            default:
                Program program = programMovieFactory.create(overrideFields);
                program.setType(type);

                if (!containsField("releaseDate", overrideFields) && !type.equals(ProgramType.Movie))
                    program.setReleaseDate(null);

                return program;
        }
    }

    private boolean containsField(String fieldName, DataServiceField[] overrideFields) {

        for (DataServiceField field : overrideFields)
            if (field.getName().equalsIgnoreCase(fieldName))
                return true;

        return false;
    }

    public List<Program> create(ProgramType type, int amount, DataServiceField... overrideFields) {
        switch (type) {
            case Movie:
                return programMovieFactory.create(amount, overrideFields);
            case SeriesMaster:
                return programSeriesMasterFactory.create(amount, overrideFields);
            case Episode:
                return programEpisodeFactory.create(amount, overrideFields);

            default:
                List<Program> programs = programMovieFactory.create(amount, overrideFields);

                for (Program program : programs) {
                    program.setType(type);
                    if (!containsField("releaseDate", overrideFields) && !type.equals(ProgramType.Movie)) {
                        program.setReleaseDate(null);
                    }
                }
                return programs;
        }
    }

    public ProgramMovieFactory getProgramMovieFactory() {
        return programMovieFactory;
    }

    public void setProgramMovieFactory(ProgramMovieFactory programMovieFactory) {
        this.programMovieFactory = programMovieFactory;
    }

    public ProgramEpisodeFactory getProgramEpisodeFactory() {
        return programEpisodeFactory;
    }

    public void setProgramEpisodeFactory(ProgramEpisodeFactory programEpisodeFactory) {
        this.programEpisodeFactory = programEpisodeFactory;
    }

    public ProgramSeriesMasterFactory getProgramSeriesMasterFactory() {
        return programSeriesMasterFactory;
    }

    public void setProgramSeriesMasterFactory(ProgramSeriesMasterFactory programSeriesMasterFactory) {
        this.programSeriesMasterFactory = programSeriesMasterFactory;
    }

}
