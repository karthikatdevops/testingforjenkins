package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.Credit;

/**
 * @author jethrolai
 * @since 01/18/2012
 */
public class CreditFactory extends EndpointFactory<Credit> {

    private PersonFactory personFactory;

    private PersonClient personClient;

    private ProgramEndpointFactory programFactory;

    private ProgramClient programClient;

    private PersonAssociationFactory personAssociationFactory;
    private ProgramAssociationFactory programAssociationFactory;

    @Override
    public Credit create() {
        Credit endpoint = super.create();

        endpoint.setProgramId(programClient.create(programFactory.create()).getId());
        endpoint.setEntityId(endpoint.getProgramId());
        endpoint.setProgram(programAssociationFactory.create(endpoint.getProgramId()));
        endpoint.setPersonId(personClient.create(personFactory.create()).getId());
        endpoint.setPerson(personAssociationFactory.create(endpoint.getPersonId()));
        return endpoint;
    }

    public PersonFactory getPersonFactory() {
        return personFactory;
    }

    public void setPersonFactory(PersonFactory personFactory) {
        this.personFactory = personFactory;
    }

    public PersonClient getPersonClient() {
        return personClient;
    }

    public void setPersonClient(PersonClient personClient) {
        this.personClient = personClient;
    }

    public PersonAssociationFactory getPersonAssociationFactory() {
        return personAssociationFactory;
    }

    public void setPersonAssociationFactory(PersonAssociationFactory personAssociationFactory) {
        this.personAssociationFactory = personAssociationFactory;
    }

    public ProgramAssociationFactory getProgramAssociationFactory() {
        return programAssociationFactory;
    }

    public void setProgramAssociationFactory(ProgramAssociationFactory programAssociationFactory) {
        this.programAssociationFactory = programAssociationFactory;
    }

    public ProgramEndpointFactory getProgramFactory() {
        return programFactory;
    }

    public void setProgramFactory(ProgramEndpointFactory programFactory) {
        this.programFactory = programFactory;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }

}
