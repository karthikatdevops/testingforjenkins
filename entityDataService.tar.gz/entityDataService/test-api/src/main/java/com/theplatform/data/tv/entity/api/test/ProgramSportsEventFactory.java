package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.SportsEventClient;
import com.theplatform.data.tv.entity.api.data.objects.ProgramSportsEvent;

public class ProgramSportsEventFactory extends EndpointFactory<ProgramSportsEvent> {

    private ProgramClient programClient;

    private ProgramEndpointFactory programFactory;

    private SportsEventClient sportsEventClient;

    private SportsEventFactory sportsEventFactory;

    @Override
    public ProgramSportsEvent create() {
        ProgramSportsEvent programSportsEvent = super.create();
        programSportsEvent.setProgramId(programClient.create(programFactory.create()).getId());
        programSportsEvent.setSportsEventId(sportsEventClient.create(sportsEventFactory.create()).getId());

        return programSportsEvent;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }

    public ProgramEndpointFactory getProgramFactory() {
        return programFactory;
    }

    public void setProgramFactory(ProgramEndpointFactory programFactory) {
        this.programFactory = programFactory;
    }

    public SportsEventClient getSportsEventClient() {
        return sportsEventClient;
    }

    public void setSportsEventClient(SportsEventClient sportsEventClient) {
        this.sportsEventClient = sportsEventClient;
    }

    public SportsEventFactory getSportsEventFactory() {
        return sportsEventFactory;
    }

    public void setSportsEventFactory(SportsEventFactory sportsEventFactory) {
        this.sportsEventFactory = sportsEventFactory;
    }

}
