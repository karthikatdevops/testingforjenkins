package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.api.objects.DataObjectField;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.SongClient;
import com.theplatform.data.tv.entity.api.data.objects.Song;
import com.theplatform.data.tv.entity.api.fields.SongField;

import java.net.URI;
import java.util.ArrayList;

public class SongFactory extends DataObjectFactoryImpl<Song, SongClient> {

    public SongFactory(SongClient client, ValueProvider<Long> idProvider) {
        super(client, Song.class, idProvider);

        addPresetFieldsOverrides(
                SongField.sortTitle, new PrefixedIdFieldProvider("title"),
                SongField.isrc, "isrc",
                SongField.duration, 100,
                SongField.primaryPersonIds, new ArrayList<URI>(),
                SongField.imageIds, new ArrayList<URI>(),
                SongField.tagIds, new ArrayList<URI>(),
                SongField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                DataObjectField.author, new PrefixedIdFieldProvider("author"),
                DataObjectField.description, new PrefixedIdFieldProvider("description")
        );

    }

}
