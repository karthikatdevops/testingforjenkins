package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.data.api.objects.MediaId;
import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMediaAssociation;
import org.apache.commons.lang.SerializationUtils;

import java.util.Random;

/**
 * @author jethrolai
 */
public class ProgramMediaAssociationFactory extends EndpointFactory<ProgramMediaAssociation> {

    private ProgramClient programClient;

    private ProgramEndpointFactory programFactory;

    @Override
    public ProgramMediaAssociation create() {

        // no need to set id
        ProgramMediaAssociation programMediaAssociation = (ProgramMediaAssociation) SerializationUtils.clone(templateEndpoint);
        programMediaAssociation.setProgramId(programClient.create(programFactory.create()).getId());
        programMediaAssociation.setMediaId(createMediaId());
        return programMediaAssociation;
    }

    private MediaId createMediaId() {
        MediaId mediaId = new MediaId();
        mediaId.setAccountGuid("fake accountGuid");
        mediaId.setServiceGuid("fake serviceGuid");
        Random random = new Random();
        mediaId.setMediaGuid("fake mediaGuid " + random.nextInt());
        return mediaId;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }

    public ProgramEndpointFactory getProgramFactory() {
        return programFactory;
    }

    public void setProgramFactory(ProgramEndpointFactory programFactory) {
        this.programFactory = programFactory;
    }

}