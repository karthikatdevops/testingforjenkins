package com.theplatform.data.tv.entity.test.api.data.factory;

import com.theplatform.contrib.testing.factory.DataObjectFactory;
import com.theplatform.contrib.testing.factory.DataObjectFactoryImpl;
import com.theplatform.contrib.testing.factory.field.DataObjectIdProvider;
import com.theplatform.contrib.testing.factory.field.PrefixedIdFieldProvider;
import com.theplatform.contrib.testing.factory.field.ValueProvider;
import com.theplatform.data.tv.api.data.objects.MerlinResourceType;
import com.theplatform.data.tv.entity.api.client.AlbumClient;
import com.theplatform.data.tv.entity.api.client.AlbumReleaseClient;
import com.theplatform.data.tv.entity.api.data.objects.Album;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import com.theplatform.data.tv.entity.api.fields.AlbumReleaseField;
import com.theplatform.media.api.data.objects.Rating;

import java.net.URI;
import java.util.ArrayList;

public class AlbumReleaseFactory extends DataObjectFactoryImpl<AlbumRelease, AlbumReleaseClient> {


    public AlbumReleaseFactory(AlbumReleaseClient client, DataObjectFactory<Album, AlbumClient> albumFactory, ValueProvider<Long> idProvider) {
        super(client, AlbumRelease.class, idProvider);

        this.addPresetFieldsOverrides(
                AlbumReleaseField.albumId, new DataObjectIdProvider(albumFactory),
                AlbumReleaseField.contentRatings, new ArrayList<Rating>(),
                AlbumReleaseField.sortTitle, new PrefixedIdFieldProvider("Title"),
                AlbumReleaseField.copyrightInfo, new PrefixedIdFieldProvider("copyright"),
                AlbumReleaseField.mainRelease, false,
                AlbumReleaseField.merlinResourceType, MerlinResourceType.AudienceAvailable,
                AlbumReleaseField.imageIds, new ArrayList<URI>(),
                AlbumReleaseField.tagIds, new ArrayList<URI>()
        );

    }

}
