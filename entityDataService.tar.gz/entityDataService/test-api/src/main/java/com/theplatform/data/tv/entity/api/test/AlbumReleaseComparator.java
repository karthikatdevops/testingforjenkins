package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.DateOnlyComparator;
import com.theplatform.contrib.testing.comparator.RatingComparator;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.AlbumRelease;
import org.testng.Assert;

import java.util.List;

public class AlbumReleaseComparator {

    public static void assertEquals(AlbumRelease actual, AlbumRelease expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getTitle(), expected.getTitle());
        Assert.assertEquals(actual.getSortTitle(), expected.getSortTitle());
        Assert.assertEquals(actual.getDescription(), expected.getDescription());
        Assert.assertEquals(actual.getCopyrightInfo(), expected.getCopyrightInfo());
        Assert.assertEquals(actual.getProductForm(), expected.getProductForm());
        Assert.assertEquals(actual.getSoundType(), expected.getSoundType());
        Assert.assertEquals(actual.getDomesticImport(), expected.getDomesticImport());
        Assert.assertEquals(actual.getDuration(), expected.getDuration());
        DateOnlyComparator.assertEquals(actual.getReleaseDate(), expected.getReleaseDate());
        DateOnlyComparator.assertEquals(actual.getDistributionDate(), expected.getDistributionDate());
        DateOnlyComparator.assertEquals(actual.getDiscontinuedDate(), expected.getDiscontinuedDate());
        Assert.assertEquals(actual.getAlbumId(), expected.getAlbumId());
        Assert.assertEquals(actual.getLabelCompanyId(), expected.getLabelCompanyId());
        Assert.assertEquals(actual.getDistributorCompanyId(), expected.getDistributorCompanyId());
        Assert.assertEquals(actual.getMainRelease(), expected.getMainRelease());
        RatingComparator.assertEquals(actual.getContentRatings(), expected.getContentRatings());
        Assert.assertEquals(actual.getImageIds(), expected.getImageIds());
        Assert.assertEquals(actual.getTagIds(), expected.getTagIds());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());

    }

    public static void assertEquals(Feed<AlbumRelease> actual, List<AlbumRelease> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));

    }
}
