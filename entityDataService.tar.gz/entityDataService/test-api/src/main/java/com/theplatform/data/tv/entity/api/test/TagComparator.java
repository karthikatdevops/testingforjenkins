package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Tag;
import org.testng.Assert;

import java.util.List;

public class TagComparator {

    private TagComparator() {

    }

    public static void assertEquals(Tag actual, Tag expected) {
        Assert.assertEquals(actual.getId(), expected.getId(), "Asserting equality of Tag.id failed. ");
        Assert.assertEquals(actual.getDescription(), expected.getDescription(), "Asserting equality of Tag.description failed. ");
        Assert.assertEquals(actual.getTitle(), expected.getTitle(), "Asserting equality of Tag.title failed. ");
        Assert.assertEquals(actual.getName(), expected.getName());
        Assert.assertEquals(actual.getType(), expected.getType(), "Asserting equality of Tag.type failed. ");

        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType(), "Asserting equality of Tag.merlinResourceType failed. ");
    }

    public static void assertEquals(Feed<Tag> actualFeed, List<Tag> expectedList) {
        List<Tag> actualList = actualFeed.getEntries();

        Assert.assertEquals(actualList.size(), expectedList.size(), "The sizes of the actual feed and expected list of Tags are not equal.");
        for (int i = 0; i < expectedList.size(); i++)
            assertEquals(actualList.get(i), expectedList.get(i));

    }
}
