package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.AlbumReleaseSongAssociation;
import org.testng.Assert;

import java.util.List;

public class AlbumReleaseSongAssociationComparator {

    public static void assertEquals(AlbumReleaseSongAssociation actual, AlbumReleaseSongAssociation expected) {
        Assert.assertEquals(actual.getId(), expected.getId());
        Assert.assertEquals(actual.getAlbumReleaseId(), expected.getAlbumReleaseId());
        Assert.assertEquals(actual.getSongId(), expected.getSongId());
        Assert.assertEquals(actual.getTrackNumber(), expected.getTrackNumber());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<AlbumReleaseSongAssociation> actual, List<AlbumReleaseSongAssociation> expected) {
        Assert.assertEquals(actual.getEntryCount().intValue(), expected.size());
        for (int i = 0; i < actual.getEntryCount(); i++)
            assertEquals(actual.getEntries().get(i), expected.get(i));

    }
}
