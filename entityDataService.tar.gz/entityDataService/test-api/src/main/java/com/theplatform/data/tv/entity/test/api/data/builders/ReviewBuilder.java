package com.theplatform.data.tv.entity.test.api.data.builders;

import com.theplatform.contrib.testing.builder.MerlinDataObjectBuilder;
import com.theplatform.data.tv.entity.api.data.objects.Review;
import com.theplatform.media.api.data.objects.Rating;

import java.net.URI;
import java.util.List;

public class ReviewBuilder extends MerlinDataObjectBuilder<Review, ReviewBuilder> {

    public ReviewBuilder() {
        this(new Review());
    }

    public ReviewBuilder(Review template) {
        super(template);
    }

    @Override
    protected ReviewBuilder newBuilder(Review newTemplate) {
        return new ReviewBuilder(newTemplate);
    }

    public ReviewBuilder programId(URI programId) {
        Review newTemplate = super.cloneTemplate();
        newTemplate.setProgramId(programId);
        return newBuilder(newTemplate);
    }

    public ReviewBuilder provider(String provider) {
        Review newTemplate = super.cloneTemplate();
        newTemplate.setProvider(provider);
        return newBuilder(newTemplate);
    }

    public ReviewBuilder summary(String summary) {
        Review newTemplate = super.cloneTemplate();
        newTemplate.setSummary(summary);
        return newBuilder(newTemplate);
    }

    public ReviewBuilder review(String review) {
        Review newTemplate = super.cloneTemplate();
        newTemplate.setReview(review);
        return newBuilder(newTemplate);
    }

    public ReviewBuilder recommendation(String recommendation) {
        Review newTemplate = super.cloneTemplate();
        newTemplate.setRecommendation(recommendation);
        return newBuilder(newTemplate);
    }

    public ReviewBuilder starRating(Integer starRating) {
        Review newTemplate = super.cloneTemplate();
        newTemplate.setStarRating(starRating);
        return newBuilder(newTemplate);
    }

    public ReviewBuilder source(String source) {
        Review newTemplate = super.cloneTemplate();
        newTemplate.setSource(source);
        return newBuilder(newTemplate);
    }

    public ReviewBuilder contentRatings(List<Rating> contentRatings) {
        Review newTemplate = super.cloneTemplate();
        newTemplate.setContentRatings(contentRatings);
        return newBuilder(newTemplate);
    }

    public ReviewBuilder addRating(Rating contentRating) {
        Review newTemplate = this.cloneTemplate();
        List<Rating> newContentRatings = newTemplate.getContentRatings();
        newContentRatings.add(contentRating);
        newTemplate.setContentRatings(newContentRatings);
        return newBuilder(newTemplate);
    }

    public ReviewBuilder addRatings(List<Rating> contentRatings) {
        Review newTemplate = super.cloneTemplate();
        List<Rating> newContentRatings = newTemplate.getContentRatings();
        newContentRatings.addAll(contentRatings);
        newTemplate.setContentRatings(newContentRatings);
        return newBuilder(newTemplate);
    }
}
