package com.theplatform.data.tv.entity.test.api.data.builders;

import com.theplatform.contrib.testing.builder.MerlinDataObjectBuilder;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;

import java.net.URI;

public class ProgramTeamAssociationBuilder extends MerlinDataObjectBuilder<ProgramTeamAssociation, ProgramTeamAssociationBuilder> {

    public ProgramTeamAssociationBuilder() {
        this(new ProgramTeamAssociation());
    }

    public ProgramTeamAssociationBuilder(ProgramTeamAssociation template) {
        super(template);
    }

    @Override
    protected ProgramTeamAssociationBuilder newBuilder(ProgramTeamAssociation newTemplate) {
        return new ProgramTeamAssociationBuilder(newTemplate);
    }

    public ProgramTeamAssociationBuilder programId(URI programId) {
        ProgramTeamAssociation newTemplate = super.cloneTemplate();
        newTemplate.setProgramId(programId);
        return newBuilder(newTemplate);
    }

    public ProgramTeamAssociationBuilder sportsTeamId(URI sportsTeamId) {
        ProgramTeamAssociation newTemplate = super.cloneTemplate();
        newTemplate.setSportsTeamId(sportsTeamId);
        return newBuilder(newTemplate);
    }

    public ProgramTeamAssociationBuilder homeAway(String homeAway) {
        ProgramTeamAssociation newTemplate = super.cloneTemplate();
        newTemplate.setHomeAway(homeAway);
        return newBuilder(newTemplate);
    }

    public ProgramTeamAssociationBuilder competition(Boolean competition) {
        ProgramTeamAssociation newTemplate = super.cloneTemplate();
        newTemplate.setCompetition(competition);
        return newBuilder(newTemplate);
    }


}
