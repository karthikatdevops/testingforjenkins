package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.factory.EndpointFactory;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.SportsTeamClient;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;

import java.net.URI;

public class ProgramTeamAssociationFactory extends EndpointFactory<ProgramTeamAssociation> {

    private ProgramClient programClient;
    private ProgramEndpointFactory programFactory;

    private SportsTeamClient sportsTeamClient;
    private SportsTeamFactory sportsTeamFactory;

    @Override
    public ProgramTeamAssociation create() {
        ProgramTeamAssociation programTeamAssociation = super.create();
        programTeamAssociation.setProgramId(this.programClient.create(this.programFactory.create()).getId());
        programTeamAssociation.setSportsTeamId(this.sportsTeamClient.create(this.sportsTeamFactory.create()).getId());
        return programTeamAssociation;
    }

    public ProgramTeamAssociation create(URI programId, URI teamId) {
        ProgramTeamAssociation programTeamAssociation = super.create();
        programTeamAssociation.setProgramId(programId);
        programTeamAssociation.setSportsTeamId(teamId);
        return programTeamAssociation;
    }

    public ProgramClient getProgramClient() {
        return programClient;
    }

    public void setProgramClient(ProgramClient programClient) {
        this.programClient = programClient;
    }

    public ProgramEndpointFactory getProgramFactory() {
        return programFactory;
    }

    public void setProgramFactory(ProgramEndpointFactory programFactory) {
        this.programFactory = programFactory;
    }

    public SportsTeamClient getSportsTeamClient() {
        return sportsTeamClient;
    }

    public void setSportsTeamClient(SportsTeamClient sportsTeamClient) {
        this.sportsTeamClient = sportsTeamClient;
    }

    public SportsTeamFactory getSportsTeamFactory() {
        return sportsTeamFactory;
    }

    public void setSportsTeamFactory(SportsTeamFactory sportsTeamFactory) {
        this.sportsTeamFactory = sportsTeamFactory;
    }

}
