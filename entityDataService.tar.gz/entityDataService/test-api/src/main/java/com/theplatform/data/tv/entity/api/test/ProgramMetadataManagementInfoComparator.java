package com.theplatform.data.tv.entity.api.test;

import com.theplatform.contrib.testing.comparator.MetadataManagementInfoComparator;
import com.theplatform.contrib.testing.comparator.RatingComparator;
import com.theplatform.data.tv.entity.api.data.objects.ProgramMetadataManagementInfo;
import com.theplatform.media.api.data.objects.Rating;
import org.testng.Assert;

import java.util.List;

/**
 * @author jcoelho
 */
public class ProgramMetadataManagementInfoComparator {

    private ProgramMetadataManagementInfoComparator() {

    }

    public static void assertEquals(ProgramMetadataManagementInfo actual, ProgramMetadataManagementInfo expected) {

        if (actual != null && expected != null) {
            if (actual.getAppendContentRatings() != null && expected.getAppendContentRatings() != null) {
                Assert.assertEquals(actual.getAppendContentRatings().size(), expected.getAppendContentRatings().size());
                if (actual.getAppendContentRatings().size() > 0)
                    RatingComparator.assertEquals(actual.getAppendContentRatings().get(0), expected.getAppendContentRatings().get(0));
            } else
                Assert.fail();
            Assert.assertEquals(actual.getRemoveContentRatingSchemes(), expected.getRemoveContentRatingSchemes());
            MetadataManagementInfoComparator.assertEquals(actual, expected);
        } else {
            Assert.assertNotNull(actual);
            Assert.assertNotNull(expected);
        }
    }

    public static void assertEquals(List<ProgramMetadataManagementInfo> actual, List<ProgramMetadataManagementInfo> expected) {
        if (actual == null && expected == null)
            return;
        if ((actual != null && expected == null) || (actual == null && expected != null))
            Assert.fail("Only one of actual and expected inputs is null");
        Assert.assertEquals(actual.size(), expected.size(), "Actual and expected ProgramMetadataManagementInfo list don't have the same size. ");
        for (int i = 0; i < actual.size(); i++)
            ProgramMetadataManagementInfoComparator.assertEquals(actual.get(i), expected.get(i));
    }
}
