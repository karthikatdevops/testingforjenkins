package com.theplatform.data.tv.entity.api.test;

import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.data.objects.Institution;
import org.testng.Assert;

import java.util.List;

/**
 * Utility class that asserts equality of <code>Institution</code>
 *
 * @author clai200
 * @since 4/7/2011
 */
public class InstitutionComparator {

    private InstitutionComparator() {

    }

    /**
     * Compares Institution's id, ownerId, title, description property
     *
     * @param actual
     * @param expected
     */
    public static void assertEquals(Institution actual, Institution expected) {
        Assert.assertEquals(actual.getId(), expected.getId());

        Assert.assertEquals(actual.getTitle(), expected.getTitle());
        Assert.assertEquals(actual.getDescription(), expected.getDescription());
        Assert.assertEquals(actual.getMerlinResourceType(), expected.getMerlinResourceType());
    }

    public static void assertEquals(Feed<Institution> actual, List<Institution> expected) {
        List<Institution> actualInstitutions = actual.getEntries();
        Assert.assertEquals(actualInstitutions.size(), expected.size(), "Unexpected number of Institutions");
        for (int i = 0; i < expected.size(); i++)
            assertEquals(actualInstitutions.get(i), expected.get(i));

    }

}
