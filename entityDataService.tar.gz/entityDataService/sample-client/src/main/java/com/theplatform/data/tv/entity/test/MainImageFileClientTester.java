package com.theplatform.data.tv.entity.test;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.image.api.client.MainImageFileClient;
import com.theplatform.data.tv.image.api.client.query.mainimagefile.ByMainImageTypeId;
import com.theplatform.data.tv.image.api.data.objects.MainImageFile;

public class MainImageFileClientTester {

	public static final String DEVF_BASE_URL = "http://ccpdss-dt-v006-d.dt.ccp.cable.comcast.com:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:9002/entityDataService/";
	public static final String INTEGRATION_TEST_BASE_URL_INGEST = "http://ccpdss-dt-v106-d.dt.ccp.cable.comcast.com:9011/entityIngest/";
	public static final String INTEGRATION_TEST_BASE_URL = "http://ccpdss-dt-v106-d.dt.ccp.cable.comcast.com:9002/entityDataService/";

	private MainImageFileClient client;
	private String baseUrl;

	public MainImageFileClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new MainImageFileClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		displayMainImageFiles(getMainImageFileByMainImageTypeId(101125L));
		//displayMainImageFiles(get100MainImageFiles());
	}

	public Feed<MainImageFile> getMainImageFileByMainImageTypeId(long id) {
		System.out.println("getMainImageFileByMainImageTypeId(" + id + ")");
		ByMainImageTypeId byMainImageTypeId = new ByMainImageTypeId(200L, 201L);
		return this.client.getAll(null, new Query[] {byMainImageTypeId}, null, new Range(0,1), true);
	}

	public MainImageFile getMainImageFileById(long id) {
		System.out.println("getMainImageFileById(" + id + ")");
		return this.client.get(URI.create(this.client.getRequestUrl() + "/" + id), null);
	}

	public Feed<MainImageFile> get100MainImageFiles() {
		System.out.println("get100MainImageFiles()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayMainImageFile(MainImageFile mainImageFile) {
		Feed<MainImageFile> feed = new Feed<MainImageFile>();
		feed.setEntries(Collections.singletonList(mainImageFile));
		displayMainImageFiles(feed);
	}

	public void displayMainImageFiles(Feed<MainImageFile> mainImageFiles) {
		for (MainImageFile mainImageFile : mainImageFiles.getEntries()) {
			System.out.println("\t" + mainImageFile.getId());	
			System.out.println("\t\t" + "entityId: " + mainImageFile.getEntityId());	
			System.out.println("\t\t" + "mainImageTypeId: " + mainImageFile.getMainImageTypeId());	
			System.out.println("\t\t" + "imageId: " + mainImageFile.getImageId());	
			System.out.println("\t\t" + "imageFileId: " + mainImageFile.getImageFileId());	
			System.out.println("\t\t" + "url: " + mainImageFile.getUrl());	
			System.out.println("\t\t" + "width: " + mainImageFile.getWidth());	
			System.out.println("\t\t" + "height: " + mainImageFile.getHeight());	
		}
	}

	public static void main(String args[]) throws Exception {
		MainImageFileClientTester mainImageFileClientTester = new MainImageFileClientTester();
		mainImageFileClientTester.run();
	}

}
