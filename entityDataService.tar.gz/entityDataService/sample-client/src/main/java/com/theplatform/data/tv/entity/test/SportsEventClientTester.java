package com.theplatform.data.tv.entity.test;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.SportsEventClient;
import com.theplatform.data.tv.entity.api.data.objects.SportsEvent;

public class SportsEventClientTester {

	public static final String DEVF_BASE_URL = "http://ccpdss-dt-v006-d.dt.ccp.cable.comcast.com:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:8088/entity/";

	private SportsEventClient client;
	private String baseUrl;

	public SportsEventClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new SportsEventClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		displaySportsEvents(getSportsEvents(1L, 100L));
	}

	public Feed<SportsEvent> getSportsEvents(long ... ids) {
		System.out.println("getSportsEvents(" + Arrays.asList(ids) + ")");
		return this.client.get(getIds(ids), null);
	}

	protected URI[] getIds(long ... ids) {
		URI[] uris = new URI[ids.length];
		for (int index=0; index<ids.length; index++) {
			long id = ids[index];
			uris[index] = URI.create(this.client.getRequestUrl() + "/" + id);
		}
		return uris;
	}

	public void displaySportsEvent(SportsEvent sportsEvent) {
		Feed<SportsEvent> feed = new Feed<SportsEvent>();
		feed.setEntries(Collections.singletonList(sportsEvent));
		displaySportsEvents(feed);
	}

	public void displaySportsEvents(Feed<SportsEvent> sportsEvents) {
		for (SportsEvent sportsEvent : sportsEvents.getEntries()) {
			System.out.println("\t" + sportsEvent.getId());
			System.out.println("\t\t" + "title: " + sportsEvent.getTitle());
			System.out.println("\t\t" + "city: " + sportsEvent.getCity());
			System.out.println("\t\t" + "state: " + sportsEvent.getState());
			System.out.println("\t\t" + "country: " + sportsEvent.getCountry());
			System.out.println("\t\t" + "conference: " + sportsEvent.getConference());
			System.out.println("\t\t" + "division: " + sportsEvent.getDivision());
			System.out.println("\t\t" + "sportType: " + sportsEvent.getSportType());
			System.out.println("\t\t" + "venue: " + sportsEvent.getVenue());
			System.out.println("\t\t" + "leagueId: " + sportsEvent.getLeagueId());			
			System.out.println("\t\t" + "programIds: " + sportsEvent.getProgramIds());			
		}
	}

	public static void main(String args[]) throws Exception {
		SportsEventClientTester sportsEventClientTester = new SportsEventClientTester();
		sportsEventClientTester.run();
	}

}
