package com.theplatform.data.tv.entity.test;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.contrib.data.api.client.query.QueryType;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.client.query.Query;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.ProgramClient;
import com.theplatform.data.tv.entity.api.client.query.program.BySportsTeamId;
import com.theplatform.data.tv.entity.api.data.objects.Program;

public class ProgramClientTester {

	public static final String DEVF_BASE_URL = "http://ccpdss-dt-v006-d.dt.ccp.cable.comcast.com:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:9002/entityDataService/";

	private ProgramClient client;
	private String baseUrl;

	public ProgramClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;

//		CacheOptions cacheOptions = new CacheOptions("entity", 10000);
//		CacheManager cacheManager = new CacheManager();
//		
//		ClientConfiguration clientConfiguration = new ClientConfiguration();
//		clientConfiguration.setCacheOptions(cacheOptions);
//		clientConfiguration.setCacheManager(cacheManager);
//		this.client = new ProgramClient(this.baseUrl, new NoAuthHeader(), clientConfiguration);
		this.client = new ProgramClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		displayProgram(getProgram(8728123872266612112L));
		//displayPrograms(get100Programs());
	}

	public Program getProgram(long id) {
		System.out.println("getProgram(" + id + ")");
		return this.client.get(URI.create(this.client.getRequestUrl() + "/" + id), null);
	}

	public Feed<Program> get100Programs() {
		System.out.println("get100Programs()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public Feed<Program> getBySportsTeamIds() {
		System.out.println("getBySportsTeamIds()");
		BySportsTeamId bySportsTeamId = new BySportsTeamId(Arrays.asList(1L, 2L), QueryType.AND);
		return this.client.getAll(null, new Query[] {bySportsTeamId}, null, new Range(1, 100), false);
	}

	public void displayProgram(Program program) {
		Feed<Program> feed = new Feed<Program>();
		feed.setEntries(Collections.singletonList(program));
		displayPrograms(feed);
	}

	public void displayPrograms(Feed<Program> programs) {
		for (Program program : programs.getEntries()) {
			System.out.println("\t" + program.getId());	
			System.out.println("\t\t" + "title: " + program.getTitle());	
			System.out.println("\t\t" + "type: " + program.getType());	
			System.out.println("\t\t" + "category: " + program.getCategory());	
		}
	}

	public static void main(String args[]) throws Exception {
		ProgramClientTester programClientTester = new ProgramClientTester();
		programClientTester.run();
	}

}
