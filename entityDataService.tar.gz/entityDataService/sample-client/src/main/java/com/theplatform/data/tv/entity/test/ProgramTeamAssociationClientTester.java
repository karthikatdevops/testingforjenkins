package com.theplatform.data.tv.entity.test;

import java.net.URI;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.ProgramTeamAssociationClient;
import com.theplatform.data.tv.entity.api.data.objects.ProgramTeamAssociation;

public class ProgramTeamAssociationClientTester {

	public static final String CACTUS_BASE_URL = "http://cactus.chalybs.net:9002/entityDataService/";
	public static final String FALCON_BASE_URL = "http://falcon.chalybs.net:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:9002/entityDataService/";

	private ProgramTeamAssociationClient client;
	private String baseUrl;

	public ProgramTeamAssociationClientTester() throws Exception {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new ProgramTeamAssociationClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		displayProgramTeamAssociation(createProgramTeamAssociation(1L, 200112L, 8944834969164478119L));
		//displayProgramTeamAssociations(get100ProgramTeamAssociations());
	}

	public ProgramTeamAssociation createProgramTeamAssociation(Long id, Long programId, Long sportsTeamId) throws Exception {
		System.out.println("createProgramTeamAssociation(" + programId + ", " + sportsTeamId + ")");
		ProgramTeamAssociation programTeamAssociation = new ProgramTeamAssociation();
		programTeamAssociation.setId(new URI(this.client.getRequestUrl() + "/" + id));
		programTeamAssociation.setProgramId(new URI(this.client.getRequestUrl() + "/" + programId));
		programTeamAssociation.setSportsTeamId(new URI(this.client.getRequestUrl() + "/" + sportsTeamId));
		programTeamAssociation.setOwnerId(new URI("urn:gene:rules:153"));
		return this.client.create(programTeamAssociation, null);
	}
	
	public Feed<ProgramTeamAssociation> get100ProgramTeamAssociations() {
		System.out.println("get100ProgramTeamAssociations()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayProgramTeamAssociation(ProgramTeamAssociation programTeamAssociation) {
		Feed<ProgramTeamAssociation> feed = new Feed<ProgramTeamAssociation>();
		feed.setEntries(Collections.singletonList(programTeamAssociation));
		displayProgramTeamAssociations(feed);
	}

	public void displayProgramTeamAssociations(Feed<ProgramTeamAssociation> programTeamAssociations) {
		for (ProgramTeamAssociation programTeamAssociation : programTeamAssociations.getEntries()) {
			System.out.println("\t" + programTeamAssociation.getId());	
			System.out.println("\t\t" + "programId: " + programTeamAssociation.getProgramId());	
			System.out.println("\t\t" + "sportsTeamId: " + programTeamAssociation.getSportsTeamId());
		}
	}

	public static void main(String args[]) throws Exception {
		ProgramTeamAssociationClientTester programTeamAssociation = new ProgramTeamAssociationClientTester();
		programTeamAssociation.run();
	}

}
