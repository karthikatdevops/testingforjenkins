package com.theplatform.data.tv.entity.test;

import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.image.api.client.MainImageTypeClient;
import com.theplatform.data.tv.image.api.data.objects.MainImageType;

public class MainImageTypeClientTester {

	public static final String CACTUS_BASE_URL = "http://cactus.chalybs.net:9002/entityDataService/";
	public static final String FALCON_BASE_URL = "http://falcon.chalybs.net:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:9002/entityDataService/";

	private MainImageTypeClient client;
	private String baseUrl;

	public MainImageTypeClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new MainImageTypeClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		displayMainImageTypes(get100MainImageTypes());
	}
 
	public Feed<MainImageType> get100MainImageTypes() {
		System.out.println("getAllMainImageTypes()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayMainImageType(MainImageType mainImageType) {
		Feed<MainImageType> feed = new Feed<MainImageType>();
		feed.setEntries(Collections.singletonList(mainImageType));
		displayMainImageTypes(feed);
	}

	public void displayMainImageTypes(Feed<MainImageType> mainImageTypes) {
		for (MainImageType mainImageType : mainImageTypes.getEntries()) {
			System.out.println("\t" + mainImageType.getId());	
			System.out.println("\t\t" + "title: " + mainImageType.getTitle());	
			System.out.println("\t\t" + "entityType: " + mainImageType.getEntityType());	
			System.out.println("\t\t" + "width: " + mainImageType.getWidth());	
			System.out.println("\t\t" + "height: " + mainImageType.getHeight());	
		}
	}

	public static void main(String args[]) throws Exception {
		MainImageTypeClientTester mainImageTypeClientTester = new MainImageTypeClientTester();
		mainImageTypeClientTester.run();
	}

}
