package com.theplatform.data.tv.entity.test;

import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.image.api.client.ImageAssociationClient;
import com.theplatform.data.tv.image.api.data.objects.ImageAssociation;

public class ImageAssociationClientTester {

	public static final String CACTUS_BASE_URL = "http://cactus.chalybs.net:9002/entityDataService/";
	public static final String FALCON_BASE_URL = "http://falcon.chalybs.net:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:9002/entityDataService/";

	private ImageAssociationClient client;
	private String baseUrl;

	public ImageAssociationClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new ImageAssociationClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		//displayImageAssociations(get100ImageAssociations());
	}

	public Feed<ImageAssociation> get100ImageAssociations() {
		System.out.println("get100ImageAssociations()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayImageAssociation(ImageAssociation imageAssociation) {
		Feed<ImageAssociation> feed = new Feed<ImageAssociation>();
		feed.setEntries(Collections.singletonList(imageAssociation));
		displayImageAssociations(feed);
	}

	public void displayImageAssociations(Feed<ImageAssociation> imageAssociations) {
		for (ImageAssociation imageAssociation : imageAssociations.getEntries()) {
			System.out.println("\t" + imageAssociation.getId());	
			System.out.println("\t\t" + "entityId: " + imageAssociation.getEntityId());	
			System.out.println("\t\t" + "imageId: " + imageAssociation.getImageId());	
			System.out.println("\t\t" + "index: " + imageAssociation.getIndex());	
		}
	}

	public static void main(String args[]) throws Exception {
		ImageAssociationClientTester imageAssociationClientTester = new ImageAssociationClientTester();
		imageAssociationClientTester.run();
	}

}
