package com.theplatform.data.tv.entity.test;

import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.TvSeasonClient;
import com.theplatform.data.tv.entity.api.data.objects.TvSeason;

public class TvSeasonClientTester {

	public static final String CACTUS_BASE_URL = "http://cactus.chalybs.net:9002/entityDataService/";
	public static final String FALCON_BASE_URL = "http://falcon.chalybs.net:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:8088/entity/";

	private TvSeasonClient client;
	private String baseUrl;

	public TvSeasonClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new TvSeasonClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		//displayTvSeasons(get100TvSeasons());
	}

	public Feed<TvSeason> get100TvSeasons() {
		System.out.println("get100TvSeasons()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayTvSeason(TvSeason tvSeason) {
		Feed<TvSeason> feed = new Feed<TvSeason>();
		feed.setEntries(Collections.singletonList(tvSeason));
		displayTvSeasons(feed);
	}

	public void displayTvSeasons(Feed<TvSeason> tvSeasons) {
		for (TvSeason tvSeason : tvSeasons.getEntries()) {
			System.out.println("\t" + tvSeason.getId());	
			System.out.println("\t\t" + "seriesId " + tvSeason.getSeriesId());	
			System.out.println("\t\t" + "tvSeasonNumber " + tvSeason.getTvSeasonNumber());	
			System.out.println("\t\t" + "startYear " + tvSeason.getStartYear());	
			System.out.println("\t\t" + "endYear " + tvSeason.getEndYear());	
			System.out.println("\t\t" + "description " + tvSeason.getDescription());	
		}
	}

	public static void main(String args[]) throws Exception {
		TvSeasonClientTester tvSeasonClientTester = new TvSeasonClientTester();
		tvSeasonClientTester.run();
	}

}
