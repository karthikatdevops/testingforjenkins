package com.theplatform.data.tv.entity.test;

import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.ProgramCollectionClient;
import com.theplatform.data.tv.entity.api.data.objects.ProgramCollection;

public class ProgramCollectionClientTester {

	public static final String CACTUS_BASE_URL = "http://cactus.chalybs.net:9002/entityDataService/";
	public static final String FALCON_BASE_URL = "http://falcon.chalybs.net:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:9002/entityDataService/";

	private ProgramCollectionClient client;
	private String baseUrl;

	public ProgramCollectionClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new ProgramCollectionClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		displayProgramCollections(get100ProgramCollections());
	}

	public Feed<ProgramCollection> get100ProgramCollections() {
		System.out.println("get100ProgramCollections()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayProgramCollection(ProgramCollection programCollection) {
		Feed<ProgramCollection> feed = new Feed<ProgramCollection>();
		feed.setEntries(Collections.singletonList(programCollection));
		displayProgramCollections(feed);
	}

	public void displayProgramCollections(Feed<ProgramCollection> programCollections) {
		for (ProgramCollection programCollection : programCollections.getEntries()) {
			System.out.println("\t" + programCollection.getId());	
			System.out.println("\t\t" + "name: " + programCollection.getName());	
			System.out.println("\t\t" + "description: " + programCollection.getDescription());	
			System.out.println("\t\t" + "type : " + programCollection.getType());	
			System.out.println("\t\t" + "programIds : " + programCollection.getProgramIds());	
		}
	}

	public static void main(String args[]) throws Exception {
		ProgramCollectionClientTester programCollectionClientTester = new ProgramCollectionClientTester();
		programCollectionClientTester.run();
	}

}
