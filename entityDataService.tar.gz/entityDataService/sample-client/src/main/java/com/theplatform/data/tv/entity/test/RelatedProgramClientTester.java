package com.theplatform.data.tv.entity.test;

import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.RelatedProgramClient;
import com.theplatform.data.tv.entity.api.data.objects.RelatedProgram;

public class RelatedProgramClientTester {

	public static final String CACTUS_BASE_URL = "http://cactus.chalybs.net:9002/entityDataService/";
	public static final String FALCON_BASE_URL = "http://falcon.chalybs.net:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:8088/entity/";

	private RelatedProgramClient client;
	private String baseUrl;

	public RelatedProgramClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new RelatedProgramClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		//displayRelatedPrograms(get100RelatedPrograms());
	}

	public Feed<RelatedProgram> get100RelatedPrograms() {
		System.out.println("get100RelatedPrograms()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayRelatedProgram(RelatedProgram relatedProgram) {
		Feed<RelatedProgram> feed = new Feed<RelatedProgram>();
		feed.setEntries(Collections.singletonList(relatedProgram));
		displayRelatedPrograms(feed);
	}

	public void displayRelatedPrograms(Feed<RelatedProgram> relatedPrograms) {
		for (RelatedProgram relatedProgram : relatedPrograms.getEntries()) {
			System.out.println("\t" + relatedProgram.getId());	
			System.out.println("\t\t" + "sourceProgramId: " + relatedProgram.getSourceProgramId());	
			System.out.println("\t\t" + "type: " + relatedProgram.getType());	
			System.out.println("\t\t" + "targetProgramId: " + relatedProgram.getTargetProgramId());	
			System.out.println("\t\t" + "justification: " + relatedProgram.getJustification());	
		}
	}

	public static void main(String args[]) throws Exception {
		RelatedProgramClientTester relatedProgramClientTester = new RelatedProgramClientTester();
		relatedProgramClientTester.run();
	}

}
