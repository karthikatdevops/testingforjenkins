package com.theplatform.data.tv.entity.test;

import java.net.URI;
import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.PersonClient;
import com.theplatform.data.tv.entity.api.data.objects.Person;

public class PersonClientTester {

	public static final String DEVF_BASE_URL = "http://ccpdss-dt-v006-d.dt.ccp.cable.comcast.com:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:9002/entityDataService/";

	private PersonClient client;
	private String baseUrl;

	public PersonClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new PersonClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		displayPerson(getById(9149571743022155111L));
		//displayPersons(get100Persons());
	}

	public Person getById(long id) {
		System.out.println("getById(" + id + ")");
		return this.client.get(URI.create(client.getRequestUrl() + "/" + id), null);
	}

	public Feed<Person> get100Persons() {
		System.out.println("get100Persons()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayPerson(Person person) {
		Feed<Person> feed = new Feed<Person>();
		feed.setEntries(Collections.singletonList(person));
		displayPersons(feed);
	}

	public void displayPersons(Feed<Person> persons) {
		for (Person person : persons.getEntries()) {
			System.out.println("\t" + person.getId());	
			System.out.println("\t\t" + "name: " + person.getName());	
			System.out.println("\t\t" + "birth: " + person.getBirth());	
			System.out.println("\t\t" + "death: " + person.getDeath());	
			System.out.println("\t\t" + "shortBio: " + person.getShortBio());	
			System.out.println("\t\t" + "mediumBio: " + person.getMediumBio());	
			System.out.println("\t\t" + "longBio: " + person.getLongBio());	
			System.out.println("\t\t" + "birthName: " + person.getBirthName());	
			System.out.println("\t\t" + "sortName: " + person.getSortName());	
			System.out.println("\t\t" + "aliases: " + person.getAliases());	
		}
	}

	public static void main(String args[]) throws Exception {
		PersonClientTester personClientTester = new PersonClientTester();
		personClientTester.run();
	}

}
