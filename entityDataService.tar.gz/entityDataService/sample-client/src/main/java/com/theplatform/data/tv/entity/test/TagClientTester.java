package com.theplatform.data.tv.entity.test;

import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.TagClient;
import com.theplatform.data.tv.entity.api.data.objects.Tag;

public class TagClientTester {

	public static final String CACTUS_BASE_URL = "http://cactus.chalybs.net:9002/entityDataService/";
	public static final String FALCON_BASE_URL = "http://falcon.chalybs.net:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:8088/entity/";

	private TagClient client;
	private String baseUrl;

	public TagClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new TagClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		//displayTags(get100Tags());
	}

	public Feed<Tag> get100Tags() {
		System.out.println("get100Tags()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayTag(Tag tag) {
		Feed<Tag> feed = new Feed<Tag>();
		feed.setEntries(Collections.singletonList(tag));
		displayTags(feed);
	}

	public void displayTags(Feed<Tag> tags) {
		for (Tag tag : tags.getEntries()) {
			System.out.println("\t" + tag.getId());	
			System.out.println("\t\t" + "name: " + tag.getName());	
			System.out.println("\t\t" + "type: " + tag.getType());	
		}
	}

	public static void main(String args[]) throws Exception {
		TagClientTester tagClientTester = new TagClientTester();
		tagClientTester.run();
	}

}
