package com.theplatform.data.tv.entity.test;

import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.tag.api.client.TagAssociationClient;
import com.theplatform.data.tv.tag.api.data.objects.TagAssociation;

public class TagAssociationClientTester {

	public static final String CACTUS_BASE_URL = "http://cactus.chalybs.net:9002/entityDataService/";
	public static final String FALCON_BASE_URL = "http://falcon.chalybs.net:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:8088/entity/";

	private TagAssociationClient client;
	private String baseUrl;

	public TagAssociationClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new TagAssociationClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		//displayTagAssociations(get100TagAssociations());
	}

	public Feed<TagAssociation> get100TagAssociations() {
		System.out.println("get100TagAssociations()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayTagAssociation(TagAssociation tagAssociation) {
		Feed<TagAssociation> feed = new Feed<TagAssociation>();
		feed.setEntries(Collections.singletonList(tagAssociation));
		displayTagAssociations(feed);
	}

	public void displayTagAssociations(Feed<TagAssociation> tagAssociations) {
		for (TagAssociation tagAssociation : tagAssociations.getEntries()) {
			System.out.println("\t" + tagAssociation.getId());	
			System.out.println("\t\t" + "entityId: " + tagAssociation.getEntityId());	
			System.out.println("\t\t" + "tagId: " + tagAssociation.getTagId());	
		}
	}

	public static void main(String args[]) throws Exception {
		TagAssociationClientTester tagAssociationClientTester = new TagAssociationClientTester();
		tagAssociationClientTester.run();
	}

}
