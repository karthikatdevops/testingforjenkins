package com.theplatform.data.tv.entity.test;

import java.net.UnknownHostException;
import java.util.Collections;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.data.api.Range;
import com.theplatform.data.api.objects.Feed;
import com.theplatform.data.tv.entity.api.client.CreditClient;
import com.theplatform.data.tv.entity.api.data.objects.Credit;

public class CreditClientTester {

	public static final String CACTUS_BASE_URL = "http://cactus.chalybs.net:9002/entityDataService/";
	public static final String FALCON_BASE_URL = "http://falcon.chalybs.net:9002/entityDataService/";
	public static final String LOCAL_BASE_URL = "http://localhost:9002/entityDataService/";

	private CreditClient client;
	private String baseUrl;

	public CreditClientTester() throws UnknownHostException {
		this.baseUrl = LOCAL_BASE_URL;
		this.client = new CreditClient(this.baseUrl, new NoAuthHeader());
	}

	public void run() throws Exception {
		//displayCredits(get100Credits());
	}

	public Feed<Credit> get100Credits() {
		System.out.println("get100Credits()");
		return this.client.getAll(null, null, null, new Range(1, 100), false);
	}

	public void displayCredit(Credit credit) {
		Feed<Credit> feed = new Feed<Credit>();
		feed.setEntries(Collections.singletonList(credit));
		displayCredits(feed);
	}

	public void displayCredits(Feed<Credit> credits) {
		for (Credit credit : credits.getEntries()) {
			System.out.println("\t" + credit.getId());	
			System.out.println("\t\t" + "type: " + credit.getType());	
			System.out.println("\t\t" + "partName: " + credit.getPartName());	
			System.out.println("\t\t" + "rank: " + credit.getRank());	
			System.out.println("\t\t" + "cameo: " + credit.getCameo());	
			System.out.println("\t\t" + "personId: " + credit.getPersonId());	
			System.out.println("\t\t" + "programId: " + credit.getProgramId());	
		}
	}

	public static void main(String args[]) throws Exception {
		CreditClientTester creditClientTester = new CreditClientTester();
		creditClientTester.run();
	}

}
