package com.theplatform.data.tv.entity.test;

import java.net.UnknownHostException;
import java.util.List;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;

import com.theplatform.contrib.client.NoAuthHeader;
import com.theplatform.contrib.client.TokenAuthHeader;
import com.theplatform.data.api.client.statistics.ClientRequestStatistics;
import com.theplatform.data.notification.api.client.NotificationClient;
import com.theplatform.data.notification.api.client.NotificationCommitter;
import com.theplatform.data.notification.api.client.NotificationListener;
import com.theplatform.data.notification.api.objects.Notification;

public class NotificationClientTester {

    private final static Logger log = Logger.getLogger(NotificationClientTester.class);
    
	public static final String LOCAL_BASE_URL = "http://mpxfacade.po.ccp.cable.comcast.com";
	public static final String CLIENT_ID = "aloder";
	public static final String TOKIN = "BCUnOwhUIY4iAiNNZ7g40dA_wFD1MIDP";

	private NotificationClient notificationClient;
	
	private static int timer = 0;
	
	private static ClientRequestStatistics requestStatisticsMBean = new ClientRequestStatistics();
	
	public NotificationClientTester() throws UnknownHostException {
	    if (TOKIN == null) {
	        this.notificationClient = new NotificationClient(LOCAL_BASE_URL, new NoAuthHeader(), CLIENT_ID);
	    } else {
	        this.notificationClient = new NotificationClient(LOCAL_BASE_URL, new TokenAuthHeader(TOKIN), CLIENT_ID);
	    }
		this.notificationClient.addListener(new TestListener());
		this.notificationClient.setRequestStatisticsMBean(requestStatisticsMBean);
		this.notificationClient.setPolling(false);
		this.notificationClient.setPollingInterval(1000);
		this.notificationClient.setMaximumNotificationBatchSize(1000);
		this.notificationClient.setAccountIds(new String[] {"XCAL POC Image Ingest Account"});
	}
	
	public void run() throws Exception {
		this.notificationClient.start();
		log.info("Done.");
//		this.notificationClient.stop();
	}
	
	private static class TestListener implements NotificationListener {
		@Override
		public void onException(Throwable arg0) {
			// no-op 
		}

		@Override
		public void receiveNotifications(List<Notification> notifications, NotificationCommitter committer) {
		    log.info("Got " + notifications.size() + " notifs at " + timer + " sec interval: " + notifications.get(0).getId() + " - " + notifications.get(notifications.size() - 1).getId());
		    HttpClient client = new HttpClient();
		    try {
		        GetMethod clientGet = new GetMethod("http://mpxfacade.po.ccp.cable.comcast.com/notify?token=" + TOKIN);
		        client.executeMethod(clientGet);
	            log.info("Latest notification is: " + clientGet.getResponseBodyAsString());
		    } catch (Exception e) {
		        log.error("Error retrieving latest notification", e);
		    }

			committer.commit();
		}
	}
	
    public static void main(String args[]) throws Exception {
    	NotificationClientTester notificationClientTester = new NotificationClientTester();
    	notificationClientTester.run();
    	
    	while (true) {
    	    Thread.sleep(5000);
    	    timer += 5;
//    	    log.info("Listening for " + timer + " seconds.");
//    	    if (requestStatisticsMBean != null) {
//    	        log.info("                  Queue size: " + requestStatisticsMBean.getQueueSize());
//    	        log.info("              Slice interval: " + requestStatisticsMBean.getSliceInterval());
//    	        log.info("                  Max slices: " + requestStatisticsMBean.getMaxSlices());
//    	        log.info("                  Total Reqs: " + requestStatisticsMBean.getTotalRequestCount());
//    	        log.info("         Total Reqs last min: " + requestStatisticsMBean.getTotalRequestCount1Minute());
//    	        log.info("Total Ave Resp time last min: " + requestStatisticsMBean.getTotalAverageResponseTime1Minute());
//    	    }
    	}
    }
	
}
